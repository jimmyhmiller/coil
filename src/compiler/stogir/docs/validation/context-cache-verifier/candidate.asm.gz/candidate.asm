
/Users/jimmyhmiller/Documents/Code/projects/coil-stogir/.worktrees/call-parameter-specialization/build/context-cache-verifier/candidate.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <_gap_verify_graph>:
       0:      	sub	sp, sp, #0x1e0
       4:      	str	x29, [sp]
       8:      	str	x30, [sp, #0x8]
       c:      	mov	x29, sp
      10:      	str	x19, [sp, #0x1d0]
      14:      	add	x8, sp, #0x10
      18:      	mov	x19, x0
      1c:      	mov	x1, #0x8                ; =8
      20:      	bl	0x20 <_gap_verify_graph+0x20>
		0000000000000020:  ARM64_RELOC_BRANCH26	_stogir.verify.integer-operations-target
      24:      	add	x16, sp, #0x10
      28:      	ldr	w0, [x16]
      2c:      	lsr	x16, x0, #0
      30:      	cmp	x16, #0x1
      34:      	b.eq	0x50 <_gap_verify_graph+0x50>
      38:      	b.lo	0x40 <_gap_verify_graph+0x40>
      3c:      	b	0x54 <_gap_verify_graph+0x54>
      40:      	cmp	x16, #0x0
      44:      	b.eq	0x4c <_gap_verify_graph+0x4c>
      48:      	b	0x54 <_gap_verify_graph+0x54>
      4c:      	b	0x60 <_gap_verify_graph+0x60>
      50:      	b	0x58 <_gap_verify_graph+0x58>
      54:      	b	0xa8 <_gap_verify_graph+0xa8>
      58:      	movn	x0, #0x0, lsl #48
      5c:      	b	0x94 <_gap_verify_graph+0x94>
      60:      	movz	x0, #0x0, lsl #48
      64:      	b	0x84 <_gap_verify_graph+0x84>
      68:      	add	x1, x0, #0x8
      6c:      	add	x16, sp, #0x30
      70:      	add	x2, x16, x0
      74:      	add	x0, x19, x0
      78:      	ldr	x0, [x0]
      7c:      	str	x0, [x2]
      80:      	mov	x0, x1
      84:      	cmp	x0, #0x1a0
      88:      	b.lo	0x68 <_gap_verify_graph+0x68>
      8c:      	add	x16, sp, #0x30
      90:      	ldr	x0, [x16, #0x8]
      94:      	ldr	x19, [sp, #0x1d0]
      98:      	ldr	x29, [sp]
      9c:      	ldr	x30, [sp, #0x8]
      a0:      	add	sp, sp, #0x1e0
      a4:      	ret
      a8:      	brk	#0
      ac:      	b	0xa8 <_gap_verify_graph+0xa8>

00000000000000b0 <_stogir.verify.integer-operations-target>:
      b0:      	sub	sp, sp, #0x70
      b4:      	str	x29, [sp]
      b8:      	str	x30, [sp, #0x8]
      bc:      	mov	x29, sp
      c0:      	str	x19, [sp, #0x50]
      c4:      	str	x20, [sp, #0x58]
      c8:      	str	x21, [sp, #0x60]
      cc:      	mov	x19, x8
      d0:      	add	x8, sp, #0x10
      d4:      	mov	x20, x0
      d8:      	mov	w21, w1
      dc:      	bl	0xdc <_stogir.verify.integer-operations-target+0x2c>
		00000000000000dc:  ARM64_RELOC_BRANCH26	_stogir.verify.structure
      e0:      	add	x16, sp, #0x10
      e4:      	ldr	w0, [x16]
      e8:      	lsr	x16, x0, #0
      ec:      	cmp	x16, #0x1
      f0:      	b.eq	0x10c <_stogir.verify.integer-operations-target+0x5c>
      f4:      	b.lo	0xfc <_stogir.verify.integer-operations-target+0x4c>
      f8:      	b	0x110 <_stogir.verify.integer-operations-target+0x60>
      fc:      	cmp	x16, #0x0
     100:      	b.eq	0x108 <_stogir.verify.integer-operations-target+0x58>
     104:      	b	0x110 <_stogir.verify.integer-operations-target+0x60>
     108:      	b	0x138 <_stogir.verify.integer-operations-target+0x88>
     10c:      	b	0x114 <_stogir.verify.integer-operations-target+0x64>
     110:      	b	0x18c <_stogir.verify.integer-operations-target+0xdc>
     114:      	add	x16, sp, #0x10
     118:      	orr	x0, x16, xzr
     11c:      	add	x0, x0, #0x8
     120:      	add	x16, sp, #0x10
     124:      	ldr	x1, [x16, #0x8]
     128:      	ldr	x0, [x0, #0x8]
     12c:      	mov	x2, x0
     130:      	mov	x0, #0x1                ; =1
     134:      	b	0x164 <_stogir.verify.integer-operations-target+0xb4>
     138:      	lsr	w21, w21, #0
     13c:      	add	x8, sp, #0x30
     140:      	mov	x0, x20
     144:      	mov	w1, w21
     148:      	bl	0x148 <_stogir.verify.integer-operations-target+0x98>
		0000000000000148:  ARM64_RELOC_BRANCH26	_stogir.verify.integer-operations-target-structured
     14c:      	add	x16, sp, #0x30
     150:      	ldr	x0, [x16]
     154:      	add	x16, sp, #0x30
     158:      	ldr	x1, [x16, #0x8]
     15c:      	add	x16, sp, #0x30
     160:      	ldr	x2, [x16, #0x10]
     164:      	str	x0, [x19]
     168:      	str	x1, [x19, #0x8]
     16c:      	str	x2, [x19, #0x10]
     170:      	ldr	x19, [sp, #0x50]
     174:      	ldr	x20, [sp, #0x58]
     178:      	ldr	x21, [sp, #0x60]
     17c:      	ldr	x29, [sp]
     180:      	ldr	x30, [sp, #0x8]
     184:      	add	sp, sp, #0x70
     188:      	ret
     18c:      	brk	#0
     190:      	b	0x18c <_stogir.verify.integer-operations-target+0xdc>

0000000000000194 <_coil.core.Len$coil.arraylist.ArrayList$len__stogir.node.Node>:
     194:      	ldr	x0, [x0, #0x8]
     198:      	ret
     19c:      	udf	#0x0

00000000000001a0 <_stogir.verify.structure>:
     1a0:      	sub	sp, sp, #0x180
     1a4:      	str	x29, [sp, #0x10]
     1a8:      	str	x30, [sp, #0x18]
     1ac:      	add	x29, sp, #0x10
     1b0:      	str	x19, [sp, #0x130]
     1b4:      	str	x20, [sp, #0x138]
     1b8:      	str	x21, [sp, #0x140]
     1bc:      	str	x22, [sp, #0x148]
     1c0:      	str	x23, [sp, #0x150]
     1c4:      	str	x24, [sp, #0x158]
     1c8:      	str	x25, [sp, #0x160]
     1cc:      	str	x26, [sp, #0x168]
     1d0:      	str	x27, [sp, #0x170]
     1d4:      	str	x28, [sp, #0x178]
     1d8:      	adrp	x16, 0x0 <_gap_verify_graph>
		00000000000001d8:  ARM64_RELOC_PAGE21	l_stogir.304
     1dc:      	ldr	x16, [x16]
		00000000000001dc:  ARM64_RELOC_PAGEOFF12	l_stogir.304
     1e0:      	orr	x19, x16, xzr
     1e4:      	add	x1, x0, #0x78
     1e8:      	ldr	x20, [x0, #0x8]
     1ec:      	mov	x21, x8
     1f0:      	mov	x22, x0
     1f4:      	mov	x0, x1
     1f8:      	bl	0x1f8 <_stogir.verify.structure+0x58>
		00000000000001f8:  ARM64_RELOC_BRANCH26	_coil.core.Len$coil.arraylist.ArrayList$len__i32
     1fc:      	cmp	x20, x0
     200:      	b.ne	0x55c <_stogir.verify.structure+0x3bc>
     204:      	mov	x0, x19
     208:      	movz	x1, #0x0, lsl #48
     20c:      	adrp	x16, 0x0 <_gap_verify_graph>
		000000000000020c:  ARM64_RELOC_PAGE21	l_stogir.305
     210:      	ldr	x16, [x16]
		0000000000000210:  ARM64_RELOC_PAGEOFF12	l_stogir.305
     214:      	orr	x20, x16, xzr
     218:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000218:  ARM64_RELOC_PAGE21	l_stogir.306
     21c:      	ldr	x16, [x16]
		000000000000021c:  ARM64_RELOC_PAGEOFF12	l_stogir.306
     220:      	orr	x23, x16, xzr
     224:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000224:  ARM64_RELOC_PAGE21	l_stogir.307
     228:      	ldr	x16, [x16]
		0000000000000228:  ARM64_RELOC_PAGEOFF12	l_stogir.307
     22c:      	orr	x24, x16, xzr
     230:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000230:  ARM64_RELOC_PAGE21	l_stogir.308
     234:      	ldr	x16, [x16]
		0000000000000234:  ARM64_RELOC_PAGEOFF12	l_stogir.308
     238:      	orr	x25, x16, xzr
     23c:      	adrp	x16, 0x0 <_gap_verify_graph>
		000000000000023c:  ARM64_RELOC_PAGE21	l_stogir.309
     240:      	ldr	x16, [x16]
		0000000000000240:  ARM64_RELOC_PAGEOFF12	l_stogir.309
     244:      	orr	x26, x16, xzr
     248:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000248:  ARM64_RELOC_PAGE21	l_stogir.310
     24c:      	ldr	x16, [x16]
		000000000000024c:  ARM64_RELOC_PAGEOFF12	l_stogir.310
     250:      	orr	x27, x16, xzr
     254:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000254:  ARM64_RELOC_PAGE21	l_stogir.311
     258:      	ldr	x16, [x16]
		0000000000000258:  ARM64_RELOC_PAGEOFF12	l_stogir.311
     25c:      	orr	x28, x16, xzr
     260:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000260:  ARM64_RELOC_PAGE21	l_stogir.312
     264:      	ldr	x16, [x16]
		0000000000000264:  ARM64_RELOC_PAGEOFF12	l_stogir.312
     268:      	orr	x2, x16, xzr
     26c:      	adrp	x16, 0x0 <_gap_verify_graph>
		000000000000026c:  ARM64_RELOC_PAGE21	l_stogir.313
     270:      	ldr	x16, [x16]
		0000000000000270:  ARM64_RELOC_PAGEOFF12	l_stogir.313
     274:      	orr	x3, x16, xzr
     278:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000278:  ARM64_RELOC_PAGE21	l_stogir.314
     27c:      	ldr	x16, [x16]
		000000000000027c:  ARM64_RELOC_PAGEOFF12	l_stogir.314
     280:      	orr	x4, x16, xzr
     284:      	add	x5, x22, #0x110
     288:      	add	x6, x22, #0x78
     28c:      	add	x7, x22, #0x28
     290:      	add	x8, x22, #0x50
     294:      	add	x9, x22, #0x78
     298:      	add	x10, x22, #0x28
     29c:      	add	x11, x22, #0x50
     2a0:      	add	x12, x5, #0x28
     2a4:      	mov	x13, x0
     2a8:      	mov	x14, x1
     2ac:      	mov	x0, #0x1                ; =1
     2b0:      	movz	x1, #0x0, lsl #48
     2b4:      	b	0x348 <_stogir.verify.structure+0x1a8>
     2b8:      	mov	x1, x19
     2bc:      	ldr	x2, [sp, #0x58]
     2c0:      	mov	x3, #0x16               ; =22
     2c4:      	b	0x2f0 <_stogir.verify.structure+0x150>
     2c8:      	mov	x0, x21
     2cc:      	str	x19, [sp, #0xc8]
     2d0:      	ldr	x19, [sp, #0x90]
     2d4:      	str	x28, [sp, #0xd0]
     2d8:      	mov	x21, x20
     2dc:      	str	x23, [sp, #0xb0]
     2e0:      	str	x24, [sp, #0xa8]
     2e4:      	mov	x1, x19
     2e8:      	ldr	x2, [sp, #0x50]
     2ec:      	mov	x3, #0x23               ; =35
     2f0:      	ldr	x19, [sp, #0x48]
     2f4:      	ldr	x20, [sp, #0x50]
     2f8:      	ldr	x23, [sp, #0x58]
     2fc:      	ldr	x24, [sp, #0x60]
     300:      	ldr	x28, [sp, #0x80]
     304:      	ldr	x4, [sp, #0x40]
     308:      	ldr	x5, [sp, #0xc8]
     30c:      	ldr	x12, [sp, #0xd0]
     310:      	mov	x6, x21
     314:      	ldr	x21, [sp, #0x88]
     318:      	ldr	x7, [sp, #0xb0]
     31c:      	ldr	x8, [sp, #0xa8]
     320:      	mov	x9, x25
     324:      	ldr	x25, [sp, #0x68]
     328:      	mov	x10, x26
     32c:      	ldr	x26, [sp, #0x70]
     330:      	mov	x11, x27
     334:      	ldr	x27, [sp, #0x78]
     338:      	mov	x13, x2
     33c:      	ldr	x2, [sp, #0x30]
     340:      	mov	x14, x3
     344:      	ldr	x3, [sp, #0x38]
     348:      	str	x2, [sp, #0x30]
     34c:      	mov	x2, x19
     350:      	str	x3, [sp, #0x38]
     354:      	str	x4, [sp, #0x40]
     358:      	str	x1, [sp, #0x90]
     35c:      	mov	x1, x14
     360:      	str	x13, [sp, #0x98]
     364:      	str	x14, [sp, #0xa0]
     368:      	str	x19, [sp, #0x48]
     36c:      	mov	x19, x5
     370:      	str	x20, [sp, #0x50]
     374:      	mov	x20, x6
     378:      	str	x23, [sp, #0x58]
     37c:      	mov	x23, x7
     380:      	str	x24, [sp, #0x60]
     384:      	mov	x24, x8
     388:      	str	x25, [sp, #0x68]
     38c:      	mov	x25, x9
     390:      	str	x26, [sp, #0x70]
     394:      	mov	x26, x10
     398:      	str	x27, [sp, #0x78]
     39c:      	mov	x27, x11
     3a0:      	str	x28, [sp, #0x80]
     3a4:      	mov	x28, x12
     3a8:      	str	x21, [sp, #0x88]
     3ac:      	mov	x21, x0
     3b0:      	mov	x0, x13
     3b4:      	movz	x3, #0x0, lsl #48
     3b8:      	bl	0x3b8 <_stogir.verify.structure+0x218>
		00000000000003b8:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
     3bc:      	cmp	x0, #0x0
     3c0:      	b.eq	0xd58 <_stogir.verify.structure+0xbb8>
     3c4:      	ldr	x0, [x22, #0x8]
     3c8:      	cmp	x21, x0
     3cc:      	b.ge	0xd60 <_stogir.verify.structure+0xbc0>
     3d0:      	lsl	x0, x21, #4
     3d4:      	lsl	x1, x21, #2
     3d8:      	ldr	x2, [x22]
     3dc:      	add	x0, x0, x2
     3e0:      	ldr	x0, [x0]
     3e4:      	ldr	x2, [x22, #0x78]
     3e8:      	add	x1, x1, x2
     3ec:      	ldr	w1, [x1]
     3f0:      	sxtw	x1, w1
     3f4:      	cmp	x1, #0x0
     3f8:      	b.lt	0x2c8 <_stogir.verify.structure+0x128>
     3fc:      	mov	x17, #0xffff            ; =65535
     400:      	cmp	x1, x17
     404:      	b.gt	0xd68 <_stogir.verify.structure+0xbc8>
     408:      	uxtb	w2, w0
     40c:      	orr	x3, x2, xzr
     410:      	lsr	w3, w3, #0
     414:      	str	w3, [sp, #0xc0]
     418:      	str	x24, [sp, #0xa8]
     41c:      	mov	x24, x0
     420:      	mov	w0, w3
     424:      	str	x23, [sp, #0xb0]
     428:      	mov	x23, x1
     42c:      	str	x20, [sp, #0xb8]
     430:      	mov	w20, w2
     434:      	bl	0x434 <_stogir.verify.structure+0x294>
		0000000000000434:  ARM64_RELOC_BRANCH26	_stogir.opcode.valid?
     438:      	cmp	x0, #0x0
     43c:      	b.eq	0xd88 <_stogir.verify.structure+0xbe8>
     440:      	lsr	w24, w24, #0
     444:      	ubfx	x0, x24, #8, #8
     448:      	orr	x1, x0, xzr
     44c:      	lsr	w1, w1, #0
     450:      	str	x19, [sp, #0xc8]
     454:      	mov	w19, w0
     458:      	mov	w0, w1
     45c:      	bl	0x45c <_stogir.verify.structure+0x2bc>
		000000000000045c:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
     460:      	cmp	x0, #0x0
     464:      	b.eq	0xda0 <_stogir.verify.structure+0xc00>
     468:      	ldr	w0, [sp, #0xc0]
     46c:      	bl	0x46c <_stogir.verify.structure+0x2cc>
		000000000000046c:  ARM64_RELOC_BRANCH26	_stogir.opcode.operand-slots
     470:      	lsr	w0, w0, #0
     474:      	sxtw	x0, w0
     478:      	cmp	x0, #0x0
     47c:      	b.lt	0xb0c <_stogir.verify.structure+0x96c>
     480:      	ldr	w0, [sp, #0xc0]
     484:      	bl	0x484 <_stogir.verify.structure+0x2e4>
		0000000000000484:  ARM64_RELOC_BRANCH26	_stogir.opcode.operand-slots
     488:      	lsr	w0, w0, #0
     48c:      	sxtw	x0, w0
     490:      	cmp	x23, x0
     494:      	b.eq	0xb0c <_stogir.verify.structure+0x96c>
     498:      	str	x28, [sp, #0xd0]
     49c:      	mov	x0, x21
     4a0:      	ldr	x21, [sp, #0xb8]
     4a4:      	ldr	x1, [sp, #0x90]
     4a8:      	ldr	x2, [sp, #0x60]
     4ac:      	mov	x3, #0x23               ; =35
     4b0:      	b	0x558 <_stogir.verify.structure+0x3b8>
     4b4:      	ldr	x0, [sp, #0x98]
     4b8:      	ldr	x1, [sp, #0xa0]
     4bc:      	ldr	x2, [sp, #0x48]
     4c0:      	movz	x3, #0x0, lsl #48
     4c4:      	bl	0x4c4 <_stogir.verify.structure+0x324>
		00000000000004c4:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
     4c8:      	cmp	x0, #0x0
     4cc:      	b.eq	0x4e4 <_stogir.verify.structure+0x344>
     4d0:      	and	x0, x19, #0xffffffff
     4d4:      	mov	x1, x0
     4d8:      	movz	x0, #0x0, lsl #48
     4dc:      	movz	x2, #0x0, lsl #48
     4e0:      	b	0x4f0 <_stogir.verify.structure+0x350>
     4e4:      	ldr	x1, [sp, #0x98]
     4e8:      	ldr	x2, [sp, #0xa0]
     4ec:      	mov	x0, #0x1                ; =1
     4f0:      	ldr	x3, [sp, #0x88]
     4f4:      	str	x0, [x3]
     4f8:      	str	x1, [x3, #0x8]
     4fc:      	str	x2, [x3, #0x10]
     500:      	ldr	x19, [sp, #0x130]
     504:      	ldr	x20, [sp, #0x138]
     508:      	ldr	x21, [sp, #0x140]
     50c:      	ldr	x22, [sp, #0x148]
     510:      	ldr	x23, [sp, #0x150]
     514:      	ldr	x24, [sp, #0x158]
     518:      	ldr	x25, [sp, #0x160]
     51c:      	ldr	x26, [sp, #0x168]
     520:      	ldr	x27, [sp, #0x170]
     524:      	ldr	x28, [sp, #0x178]
     528:      	ldr	x29, [sp, #0x10]
     52c:      	ldr	x30, [sp, #0x18]
     530:      	add	sp, sp, #0x180
     534:      	ret
     538:      	ldr	x0, [sp, #0x118]
     53c:      	add	x0, x24, x0
     540:      	ldr	x19, [sp, #0x90]
     544:      	add	x1, x19, #0x1
     548:      	lsr	w1, w1, #0
     54c:      	sxtw	x1, w1
     550:      	ldr	x2, [sp, #0x100]
     554:      	ldr	x3, [sp, #0x108]
     558:      	b	0x2c4 <_stogir.verify.structure+0x124>
     55c:      	adrp	x16, 0x0 <_gap_verify_graph>
		000000000000055c:  ARM64_RELOC_PAGE21	l_stogir.315
     560:      	ldr	x16, [x16]
		0000000000000560:  ARM64_RELOC_PAGEOFF12	l_stogir.315
     564:      	orr	x0, x16, xzr
     568:      	mov	x1, #0x2c               ; =44
     56c:      	b	0x20c <_stogir.verify.structure+0x6c>
     570:      	mov	x11, x9
     574:      	movz	x9, #0x0, lsl #48
     578:      	cmp	x9, #0x0
     57c:      	b.eq	0xdb4 <_stogir.verify.structure+0xc14>
     580:      	cmp	x0, #0x0
     584:      	b.eq	0xbe8 <_stogir.verify.structure+0xa48>
     588:      	ldr	x21, [sp, #0xb8]
     58c:      	ldr	x0, [sp, #0xb0]
     590:      	ldr	x4, [sp, #0xa8]
     594:      	mov	x3, x7
     598:      	mov	x5, x11
     59c:      	b	0xb74 <_stogir.verify.structure+0x9d4>
     5a0:      	mov	x0, x1
     5a4:      	ldr	x1, [sp, #0x120]
     5a8:      	b	0x5b4 <_stogir.verify.structure+0x414>
     5ac:      	mov	x0, x11
     5b0:      	ldr	x1, [sp, #0x120]
     5b4:      	b	0x6c4 <_stogir.verify.structure+0x524>
     5b8:      	lsr	x3, x2, #0
     5bc:      	str	x1, [sp, #0xf0]
     5c0:      	str	x2, [sp, #0xf8]
     5c4:      	mov	x2, x3
     5c8:      	str	w28, [sp, #0xe8]
     5cc:      	mov	x28, x0
     5d0:      	mov	x0, x1
     5d4:      	ldr	x1, [sp, #0x48]
     5d8:      	bl	0x5d8 <_stogir.verify.structure+0x438>
		00000000000005d8:  ARM64_RELOC_BRANCH26	_memcmp
     5dc:      	lsr	w0, w0, #0
     5e0:      	sxtw	x0, w0
     5e4:      	cmp	x0, #0x0
     5e8:      	cset	w0, eq
     5ec:      	ubfx	x0, x0, #0, #8
     5f0:      	ldr	x1, [sp, #0xf0]
     5f4:      	ldr	x2, [sp, #0xf8]
     5f8:      	b	0x608 <_stogir.verify.structure+0x468>
     5fc:      	ldr	x1, [sp, #0xf0]
     600:      	ldr	x2, [sp, #0xf8]
     604:      	movz	x0, #0x0, lsl #48
     608:      	cmp	x0, #0x0
     60c:      	b.eq	0x620 <_stogir.verify.structure+0x480>
     610:      	cmp	x28, x23
     614:      	cset	w0, le
     618:      	ubfx	x0, x0, #0, #8
     61c:      	b	0x624 <_stogir.verify.structure+0x484>
     620:      	movz	x0, #0x0, lsl #48
     624:      	cmp	x0, #0x0
     628:      	b.eq	0xdc8 <_stogir.verify.structure+0xc28>
     62c:      	lsr	w0, w28, #0
     630:      	str	x1, [sp, #0x100]
     634:      	mov	w1, w0
     638:      	str	x2, [sp, #0x108]
     63c:      	str	x23, [sp, #0x110]
     640:      	mov	w23, w0
     644:      	ldr	w0, [sp, #0xc0]
     648:      	bl	0x648 <_stogir.verify.structure+0x4a8>
		0000000000000648:  ARM64_RELOC_BRANCH26	_stogir.opcode.operand-code
     64c:      	add	x16, sp, #0x20
     650:      	str	x16, [sp]
     654:      	ldr	w1, [sp, #0xe8]
     658:      	mov	w2, w23
     65c:      	str	x21, [sp, #0x118]
     660:      	mov	x21, x0
     664:      	mov	x0, x22
     668:      	bl	0x668 <_stogir.verify.structure+0x4c8>
		0000000000000668:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
     66c:      	ldr	x16, [sp]
     670:      	str	x0, [x16]
     674:      	str	x1, [x16, #0x8]
     678:      	add	x16, sp, #0x20
     67c:      	ldr	x0, [x16]
     680:      	add	x16, sp, #0x20
     684:      	ldr	x1, [x16, #0x8]
     688:      	lsr	w0, w0, #0
     68c:      	lsr	x16, x0, #0
     690:      	cmp	x16, #0x1
     694:      	b.eq	0x6b0 <_stogir.verify.structure+0x510>
     698:      	b.lo	0x6a0 <_stogir.verify.structure+0x500>
     69c:      	b	0x6b4 <_stogir.verify.structure+0x514>
     6a0:      	cmp	x16, #0x0
     6a4:      	b.eq	0x6ac <_stogir.verify.structure+0x50c>
     6a8:      	b	0x6b4 <_stogir.verify.structure+0x514>
     6ac:      	b	0x6b8 <_stogir.verify.structure+0x518>
     6b0:      	b	0x718 <_stogir.verify.structure+0x578>
     6b4:      	b	0xcf0 <_stogir.verify.structure+0xb50>
     6b8:      	ldr	x21, [sp, #0xb8]
     6bc:      	ldr	x0, [sp, #0x80]
     6c0:      	mov	x1, #0x17               ; =23
     6c4:      	add	x2, x28, #0x1
     6c8:      	lsr	w2, w2, #0
     6cc:      	sxtw	x2, w2
     6d0:      	ldr	x23, [sp, #0x110]
     6d4:      	ldr	w28, [sp, #0xe8]
     6d8:      	str	x21, [sp, #0xb8]
     6dc:      	ldr	x21, [sp, #0x118]
     6e0:      	fmov	d31, x0
     6e4:      	mov	x0, x2
     6e8:      	mov	x2, x1
     6ec:      	fmov	x1, d31
     6f0:      	cmp	x2, #0x0
     6f4:      	b.ne	0xddc <_stogir.verify.structure+0xc3c>
     6f8:      	cmp	x2, #0x0
     6fc:      	b.ne	0x5b8 <_stogir.verify.structure+0x418>
     700:      	str	w28, [sp, #0xe8]
     704:      	mov	x28, x0
     708:      	str	x1, [sp, #0xf0]
     70c:      	str	x2, [sp, #0xf8]
     710:      	mov	x0, #0x1                ; =1
     714:      	b	0x5f0 <_stogir.verify.structure+0x450>
     718:      	lsr	w21, w21, #0
     71c:      	adrp	x16, 0x0 <_gap_verify_graph>
		000000000000071c:  ARM64_RELOC_PAGE21	l_stogir.316
     720:      	ldr	x16, [x16]
		0000000000000720:  ARM64_RELOC_PAGEOFF12	l_stogir.316
     724:      	ldr	w0, [x16]
     728:      	orr	x2, x21, xzr
     72c:      	cmp	x2, x0
     730:      	b.ne	0x73c <_stogir.verify.structure+0x59c>
     734:      	mov	x0, #0x1                ; =1
     738:      	b	0x754 <_stogir.verify.structure+0x5b4>
     73c:      	adrp	x16, 0x0 <_gap_verify_graph>
		000000000000073c:  ARM64_RELOC_PAGE21	l_stogir.317
     740:      	ldr	x16, [x16]
		0000000000000740:  ARM64_RELOC_PAGEOFF12	l_stogir.317
     744:      	ldr	w0, [x16]
     748:      	cmp	x2, x0
     74c:      	cset	w0, eq
     750:      	ubfx	x0, x0, #0, #8
     754:      	lsr	w1, w1, #0
     758:      	sxtw	x1, w1
     75c:      	cmp	x1, #0x0
     760:      	cset	w3, gt
     764:      	lsl	x4, x1, #2
     768:      	cmp	x1, #0x0
     76c:      	cset	w5, lt
     770:      	movz	x16, #0x0, lsl #48
     774:      	sub	x6, x16, x1
     778:      	sub	x7, x6, #0x1
     77c:      	lsl	x8, x7, #2
     780:      	cmp	x0, #0x0
     784:      	b.eq	0x7cc <_stogir.verify.structure+0x62c>
     788:      	uxtb	w16, w3
     78c:      	cmp	w16, wzr
     790:      	b.eq	0xa4c <_stogir.verify.structure+0x8ac>
     794:      	ldr	x9, [x22, #0x8]
     798:      	cmp	x1, x9
     79c:      	b.ge	0xa90 <_stogir.verify.structure+0x8f0>
     7a0:      	ldr	x9, [x25, #0x8]
     7a4:      	cmp	x1, x9
     7a8:      	b.ge	0xc4c <_stogir.verify.structure+0xaac>
     7ac:      	ldr	x9, [x22, #0x78]
     7b0:      	add	x9, x4, x9
     7b4:      	ldr	w9, [x9]
     7b8:      	sxtw	x9, w9
     7bc:      	cmp	x9, #0x0
     7c0:      	cset	w9, ge
     7c4:      	ubfx	x9, x9, #0, #8
     7c8:      	b	0xc50 <_stogir.verify.structure+0xab0>
     7cc:      	ldr	x9, [sp, #0x100]
     7d0:      	ldr	x10, [sp, #0x108]
     7d4:      	movz	x7, #0x0, lsl #48
     7d8:      	b	0x7f0 <_stogir.verify.structure+0x650>
     7dc:      	ldr	x7, [sp, #0x100]
     7e0:      	ldr	x10, [sp, #0x108]
     7e4:      	fmov	d31, x7
     7e8:      	mov	x7, x9
     7ec:      	fmov	x9, d31
     7f0:      	adrp	x16, 0x0 <_gap_verify_graph>
		00000000000007f0:  ARM64_RELOC_PAGE21	l_stogir.318
     7f4:      	ldr	x16, [x16]
		00000000000007f4:  ARM64_RELOC_PAGEOFF12	l_stogir.318
     7f8:      	ldr	w11, [x16]
     7fc:      	cmp	x2, x11
     800:      	b.ne	0xdf0 <_stogir.verify.structure+0xc50>
     804:      	cmp	x1, #0x0
     808:      	b.gt	0x9ec <_stogir.verify.structure+0x84c>
     80c:      	ldr	x12, [sp, #0xc8]
     810:      	ldr	x2, [sp, #0xd0]
     814:      	mov	x11, x9
     818:      	movz	x9, #0x0, lsl #48
     81c:      	lsr	w9, w9, #0
     820:      	lsr	x16, x9, #0
     824:      	cmp	x16, #0x1
     828:      	b.eq	0x844 <_stogir.verify.structure+0x6a4>
     82c:      	b.lo	0x834 <_stogir.verify.structure+0x694>
     830:      	b	0x848 <_stogir.verify.structure+0x6a8>
     834:      	cmp	x16, #0x0
     838:      	b.eq	0x840 <_stogir.verify.structure+0x6a0>
     83c:      	b	0x848 <_stogir.verify.structure+0x6a8>
     840:      	b	0x84c <_stogir.verify.structure+0x6ac>
     844:      	b	0x858 <_stogir.verify.structure+0x6b8>
     848:      	b	0xd50 <_stogir.verify.structure+0xbb0>
     84c:      	ldr	x9, [sp, #0x38]
     850:      	mov	x10, #0x21              ; =33
     854:      	b	0x85c <_stogir.verify.structure+0x6bc>
     858:      	mov	x9, x11
     85c:      	cmp	x21, #0xf
     860:      	b.hs	0x570 <_stogir.verify.structure+0x3d0>
     864:      	mov	x16, #0x1               ; =1
     868:      	lsl	x11, x16, x21
     86c:      	lsr	w11, w11, #0
     870:      	mov	x17, #0x5e1c            ; =24092
     874:      	and	x11, x11, x17
     878:      	lsr	w11, w11, #0
     87c:      	cmp	x11, #0x0
     880:      	cset	w11, eq
     884:      	uxtb	w16, w11
     888:      	cmp	w16, wzr
     88c:      	cset	x11, eq
     890:      	fmov	d31, x9
     894:      	mov	x9, x11
     898:      	fmov	x11, d31
     89c:      	b	0x578 <_stogir.verify.structure+0x3d8>
     8a0:      	lsr	w0, w21, #0
     8a4:      	lsr	w28, w0, #0
     8a8:      	cmp	x20, #0x78
     8ac:      	cset	w20, eq
     8b0:      	cmp	x19, #0x0
     8b4:      	cset	w19, eq
     8b8:      	mov	x2, x1
     8bc:      	ldr	x1, [sp, #0xd8]
     8c0:      	mov	x0, #0x1                ; =1
     8c4:      	b	0x6f0 <_stogir.verify.structure+0x550>
     8c8:      	ldr	x0, [sp, #0x78]
     8cc:      	mov	x1, #0x1b               ; =27
     8d0:      	b	0x964 <_stogir.verify.structure+0x7c4>
     8d4:      	lsr	x3, x2, #0
     8d8:      	str	x1, [sp, #0xd8]
     8dc:      	str	x2, [sp, #0xe0]
     8e0:      	mov	x2, x3
     8e4:      	str	x28, [sp, #0xd0]
     8e8:      	mov	x28, x0
     8ec:      	mov	x0, x1
     8f0:      	ldr	x1, [sp, #0x48]
     8f4:      	bl	0x8f4 <_stogir.verify.structure+0x754>
		00000000000008f4:  ARM64_RELOC_BRANCH26	_memcmp
     8f8:      	lsr	w0, w0, #0
     8fc:      	sxtw	x0, w0
     900:      	cmp	x0, #0x0
     904:      	cset	w0, eq
     908:      	ubfx	x0, x0, #0, #8
     90c:      	ldr	x1, [sp, #0xe0]
     910:      	b	0x91c <_stogir.verify.structure+0x77c>
     914:      	ldr	x1, [sp, #0xe0]
     918:      	movz	x0, #0x0, lsl #48
     91c:      	cmp	x0, #0x0
     920:      	b.eq	0x934 <_stogir.verify.structure+0x794>
     924:      	cmp	x28, x24
     928:      	cset	w0, lt
     92c:      	ubfx	x0, x0, #0, #8
     930:      	b	0x938 <_stogir.verify.structure+0x798>
     934:      	movz	x0, #0x0, lsl #48
     938:      	cmp	x0, #0x0
     93c:      	b.eq	0x8a0 <_stogir.verify.structure+0x700>
     940:      	add	x0, x28, x21
     944:      	ldr	x2, [x22, #0x78]
     948:      	lsl	x0, x0, #2
     94c:      	add	x0, x0, x2
     950:      	ldr	w0, [x0]
     954:      	sxtw	x0, w0
     958:      	cmn	x0, #0x1
     95c:      	b.ne	0x8c8 <_stogir.verify.structure+0x728>
     960:      	ldr	x0, [sp, #0xd8]
     964:      	add	x2, x28, #0x1
     968:      	ldr	x28, [sp, #0xd0]
     96c:      	fmov	d31, x0
     970:      	mov	x0, x2
     974:      	mov	x2, x1
     978:      	fmov	x1, d31
     97c:      	cmp	x2, #0x0
     980:      	b.ne	0xdfc <_stogir.verify.structure+0xc5c>
     984:      	cmp	x2, #0x0
     988:      	b.ne	0x8d4 <_stogir.verify.structure+0x734>
     98c:      	str	x28, [sp, #0xd0]
     990:      	mov	x28, x0
     994:      	str	x1, [sp, #0xd8]
     998:      	str	x2, [sp, #0xe0]
     99c:      	mov	x0, #0x1                ; =1
     9a0:      	b	0x90c <_stogir.verify.structure+0x76c>
     9a4:      	ldr	x0, [sp, #0x98]
     9a8:      	ldr	x1, [sp, #0xa0]
     9ac:      	add	x2, x23, #0x4
     9b0:      	ldr	x3, [x22, #0x8]
     9b4:      	asr	x16, x2, #63
     9b8:      	lsr	x16, x16, #62
     9bc:      	add	x2, x2, x16
     9c0:      	asr	x2, x2, #2
     9c4:      	orr	x24, x2, xzr
     9c8:      	add	x2, x24, x21
     9cc:      	cmp	x2, x3
     9d0:      	b.le	0x9dc <_stogir.verify.structure+0x83c>
     9d4:      	ldr	x0, [sp, #0x70]
     9d8:      	mov	x1, #0x15               ; =21
     9dc:      	mov	x2, x1
     9e0:      	mov	x1, x0
     9e4:      	mov	x0, #0x1                ; =1
     9e8:      	b	0x97c <_stogir.verify.structure+0x7dc>
     9ec:      	ldr	x2, [sp, #0xd0]
     9f0:      	ldr	x11, [x2, #0x8]
     9f4:      	cmp	x1, x11
     9f8:      	b.gt	0xe10 <_stogir.verify.structure+0xc70>
     9fc:      	sub	x11, x1, #0x1
     a00:      	ldr	x12, [sp, #0xc8]
     a04:      	ldr	x13, [x12, #0x28]
     a08:      	mov	x17, #0x18              ; =24
     a0c:      	mul	x11, x11, x17
     a10:      	add	x11, x11, x13
     a14:      	ldr	x13, [x11]
     a18:      	ldr	x11, [x11, #0x8]
     a1c:      	ldr	x14, [x12, #0x8]
     a20:      	cmp	x13, #0x0
     a24:      	b.lt	0xc30 <_stogir.verify.structure+0xa90>
     a28:      	cmp	x13, x14
     a2c:      	b.gt	0xc30 <_stogir.verify.structure+0xa90>
     a30:      	cmp	x11, #0x0
     a34:      	b.lt	0xc30 <_stogir.verify.structure+0xa90>
     a38:      	sub	x13, x14, x13
     a3c:      	cmp	x11, x13
     a40:      	b.gt	0xc30 <_stogir.verify.structure+0xa90>
     a44:      	mov	x11, #0x1               ; =1
     a48:      	b	0xc34 <_stogir.verify.structure+0xa94>
     a4c:      	uxtb	w16, w5
     a50:      	cmp	w16, wzr
     a54:      	b.eq	0xa98 <_stogir.verify.structure+0x8f8>
     a58:      	ldr	x9, [x26, #0x8]
     a5c:      	ldr	x10, [x27, #0x8]
     a60:      	cmp	x9, x10
     a64:      	b.ne	0xc44 <_stogir.verify.structure+0xaa4>
     a68:      	cmp	x6, x9
     a6c:      	b.gt	0xcbc <_stogir.verify.structure+0xb1c>
     a70:      	ldr	x9, [x22, #0x50]
     a74:      	add	x9, x8, x9
     a78:      	ldr	w9, [x9]
     a7c:      	sxtw	x9, w9
     a80:      	cmp	x9, #0x0
     a84:      	cset	w9, gt
     a88:      	ubfx	x9, x9, #0, #8
     a8c:      	b	0xcc0 <_stogir.verify.structure+0xb20>
     a90:      	movz	x9, #0x0, lsl #48
     a94:      	b	0xa9c <_stogir.verify.structure+0x8fc>
     a98:      	movz	x9, #0x0, lsl #48
     a9c:      	cmp	x9, #0x0
     aa0:      	b.eq	0xad0 <_stogir.verify.structure+0x930>
     aa4:      	uxtb	w16, w3
     aa8:      	cmp	w16, wzr
     aac:      	b.eq	0xac0 <_stogir.verify.structure+0x920>
     ab0:      	lsl	x7, x1, #4
     ab4:      	ldr	x9, [x22]
     ab8:      	add	x7, x7, x9
     abc:      	b	0xacc <_stogir.verify.structure+0x92c>
     ac0:      	lsl	x7, x7, #4
     ac4:      	ldr	x9, [x22, #0x28]
     ac8:      	add	x7, x7, x9
     acc:      	b	0xad4 <_stogir.verify.structure+0x934>
     ad0:      	movz	x7, #0x0, lsl #48
     ad4:      	cmp	x7, #0x0
     ad8:      	cset	w9, eq
     adc:      	uxtb	w16, w9
     ae0:      	cmp	w16, wzr
     ae4:      	cset	x9, eq
     ae8:      	cmp	x9, #0x0
     aec:      	b.eq	0x7dc <_stogir.verify.structure+0x63c>
     af0:      	ldr	w7, [x7]
     af4:      	uxtb	w7, w7
     af8:      	cmp	x7, #0x48
     afc:      	b.ne	0x7dc <_stogir.verify.structure+0x63c>
     b00:      	ldr	x7, [sp, #0x30]
     b04:      	mov	x10, #0x25              ; =37
     b08:      	b	0x7e4 <_stogir.verify.structure+0x644>
     b0c:      	ldr	w0, [sp, #0xc0]
     b10:      	bl	0xb10 <_stogir.verify.structure+0x970>
		0000000000000b10:  ARM64_RELOC_BRANCH26	_stogir.opcode.input-count
     b14:      	lsr	w0, w0, #0
     b18:      	sxtw	x0, w0
     b1c:      	cmn	x0, #0x1
     b20:      	b.ne	0x9a4 <_stogir.verify.structure+0x804>
     b24:      	ubfx	x0, x24, #16, #16
     b28:      	cmp	x23, x0
     b2c:      	b.eq	0x9a4 <_stogir.verify.structure+0x804>
     b30:      	ldr	x0, [sp, #0x68]
     b34:      	mov	x1, #0x24               ; =36
     b38:      	b	0x9ac <_stogir.verify.structure+0x80c>
     b3c:      	mov	x0, #0x1                ; =1
     b40:      	cmp	x0, #0x0
     b44:      	b.eq	0x5a0 <_stogir.verify.structure+0x400>
     b48:      	ldr	x0, [sp, #0x40]
     b4c:      	mov	x1, #0x1a               ; =26
     b50:      	b	0x5a8 <_stogir.verify.structure+0x408>
     b54:      	movz	x0, #0x0, lsl #48
     b58:      	ldr	x1, [sp, #0x128]
     b5c:      	cmp	x0, #0x0
     b60:      	b.eq	0xb3c <_stogir.verify.structure+0x99c>
     b64:      	movz	x0, #0x0, lsl #48
     b68:      	b	0xb40 <_stogir.verify.structure+0x9a0>
     b6c:      	movz	x3, #0x0, lsl #48
     b70:      	mov	x5, x11
     b74:      	cmp	x3, #0x0
     b78:      	b.eq	0xb9c <_stogir.verify.structure+0x9fc>
     b7c:      	str	x12, [sp, #0xc8]
     b80:      	str	x2, [sp, #0xd0]
     b84:      	str	x0, [sp, #0xb0]
     b88:      	str	x4, [sp, #0xa8]
     b8c:      	str	x10, [sp, #0x120]
     b90:      	mov	x1, x5
     b94:      	mov	x0, #0x1                ; =1
     b98:      	b	0xb5c <_stogir.verify.structure+0x9bc>
     b9c:      	cmp	x1, #0x0
     ba0:      	b.ne	0xe18 <_stogir.verify.structure+0xc78>
     ba4:      	mov	w1, w23
     ba8:      	str	x2, [sp, #0xd0]
     bac:      	str	x12, [sp, #0xc8]
     bb0:      	str	x10, [sp, #0x120]
     bb4:      	str	x0, [sp, #0xb0]
     bb8:      	ldr	w0, [sp, #0xc0]
     bbc:      	str	x4, [sp, #0xa8]
     bc0:      	str	x5, [sp, #0x128]
     bc4:      	bl	0xbc4 <_stogir.verify.structure+0xa24>
		0000000000000bc4:  ARM64_RELOC_BRANCH26	_stogir.opcode.operand-code
     bc8:      	lsr	w0, w0, #0
     bcc:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000bcc:  ARM64_RELOC_PAGE21	l_stogir.319
     bd0:      	ldr	x16, [x16]
		0000000000000bd0:  ARM64_RELOC_PAGEOFF12	l_stogir.319
     bd4:      	ldr	w1, [x16]
     bd8:      	cmp	x0, x1
     bdc:      	b.ne	0xcc4 <_stogir.verify.structure+0xb24>
     be0:      	mov	x0, #0x1                ; =1
     be4:      	b	0xc58 <_stogir.verify.structure+0xab8>
     be8:      	uxtb	w16, w3
     bec:      	cmp	w16, wzr
     bf0:      	b.eq	0xe34 <_stogir.verify.structure+0xc94>
     bf4:      	ldr	x0, [x22, #0x8]
     bf8:      	cmp	x1, x0
     bfc:      	b.ge	0xe3c <_stogir.verify.structure+0xc9c>
     c00:      	ldr	x21, [sp, #0xb8]
     c04:      	ldr	x0, [x21, #0x8]
     c08:      	cmp	x1, x0
     c0c:      	b.ge	0xce8 <_stogir.verify.structure+0xb48>
     c10:      	ldr	x0, [x22, #0x78]
     c14:      	add	x0, x4, x0
     c18:      	ldr	w0, [x0]
     c1c:      	sxtw	x0, w0
     c20:      	cmp	x0, #0x0
     c24:      	cset	w0, ge
     c28:      	ubfx	x0, x0, #0, #8
     c2c:      	b	0xcec <_stogir.verify.structure+0xb4c>
     c30:      	movz	x11, #0x0, lsl #48
     c34:      	fmov	d31, x9
     c38:      	mov	x9, x11
     c3c:      	fmov	x11, d31
     c40:      	b	0x81c <_stogir.verify.structure+0x67c>
     c44:      	movz	x9, #0x0, lsl #48
     c48:      	b	0xa9c <_stogir.verify.structure+0x8fc>
     c4c:      	movz	x9, #0x0, lsl #48
     c50:      	b	0xa94 <_stogir.verify.structure+0x8f4>
     c54:      	movz	x0, #0x0, lsl #48
     c58:      	b	0xb58 <_stogir.verify.structure+0x9b8>
     c5c:      	movz	x0, #0x0, lsl #48
     c60:      	ldr	x4, [sp, #0xa8]
     c64:      	mov	x3, x0
     c68:      	ldr	x0, [sp, #0xb0]
     c6c:      	b	0xb70 <_stogir.verify.structure+0x9d0>
     c70:      	uxtb	w16, w5
     c74:      	cmp	w16, wzr
     c78:      	b.eq	0xe44 <_stogir.verify.structure+0xca4>
     c7c:      	ldr	x0, [sp, #0xb0]
     c80:      	ldr	x3, [x0, #0x8]
     c84:      	ldr	x4, [sp, #0xa8]
     c88:      	ldr	x5, [x4, #0x8]
     c8c:      	cmp	x3, x5
     c90:      	b.ne	0xce0 <_stogir.verify.structure+0xb40>
     c94:      	cmp	x6, x3
     c98:      	b.gt	0xd14 <_stogir.verify.structure+0xb74>
     c9c:      	ldr	x3, [x22, #0x50]
     ca0:      	add	x3, x8, x3
     ca4:      	ldr	w3, [x3]
     ca8:      	sxtw	x3, w3
     cac:      	cmp	x3, #0x0
     cb0:      	cset	w3, gt
     cb4:      	ubfx	x3, x3, #0, #8
     cb8:      	b	0xd18 <_stogir.verify.structure+0xb78>
     cbc:      	movz	x9, #0x0, lsl #48
     cc0:      	b	0xc48 <_stogir.verify.structure+0xaa8>
     cc4:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000cc4:  ARM64_RELOC_PAGE21	l_stogir.320
     cc8:      	ldr	x16, [x16]
		0000000000000cc8:  ARM64_RELOC_PAGEOFF12	l_stogir.320
     ccc:      	ldr	w1, [x16]
     cd0:      	cmp	x0, x1
     cd4:      	b.ne	0xcf8 <_stogir.verify.structure+0xb58>
     cd8:      	mov	x0, #0x1                ; =1
     cdc:      	b	0xc58 <_stogir.verify.structure+0xab8>
     ce0:      	movz	x3, #0x0, lsl #48
     ce4:      	b	0xb70 <_stogir.verify.structure+0x9d0>
     ce8:      	movz	x0, #0x0, lsl #48
     cec:      	b	0xc60 <_stogir.verify.structure+0xac0>
     cf0:      	brk	#0
     cf4:      	b	0xcf0 <_stogir.verify.structure+0xb50>
     cf8:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000cf8:  ARM64_RELOC_PAGE21	l_stogir.321
     cfc:      	ldr	x16, [x16]
		0000000000000cfc:  ARM64_RELOC_PAGEOFF12	l_stogir.321
     d00:      	ldr	w1, [x16]
     d04:      	cmp	x0, x1
     d08:      	b.ne	0xd1c <_stogir.verify.structure+0xb7c>
     d0c:      	mov	x0, #0x1                ; =1
     d10:      	b	0xc58 <_stogir.verify.structure+0xab8>
     d14:      	movz	x3, #0x0, lsl #48
     d18:      	b	0xce4 <_stogir.verify.structure+0xb44>
     d1c:      	uxtb	w16, w20
     d20:      	cmp	w16, wzr
     d24:      	b.eq	0xc54 <_stogir.verify.structure+0xab4>
     d28:      	uxtb	w16, w19
     d2c:      	cmp	w16, wzr
     d30:      	b.eq	0xd48 <_stogir.verify.structure+0xba8>
     d34:      	sxtw	x23, w23
     d38:      	cmp	x23, #0x2
     d3c:      	cset	w0, eq
     d40:      	ubfx	x0, x0, #0, #8
     d44:      	b	0xd4c <_stogir.verify.structure+0xbac>
     d48:      	movz	x0, #0x0, lsl #48
     d4c:      	b	0xc58 <_stogir.verify.structure+0xab8>
     d50:      	brk	#0
     d54:      	b	0xd50 <_stogir.verify.structure+0xbb0>
     d58:      	ldr	x19, [sp, #0x90]
     d5c:      	b	0x4b4 <_stogir.verify.structure+0x314>
     d60:      	ldr	x19, [sp, #0x90]
     d64:      	b	0x4b4 <_stogir.verify.structure+0x314>
     d68:      	mov	x0, x21
     d6c:      	str	x19, [sp, #0xc8]
     d70:      	ldr	x19, [sp, #0x90]
     d74:      	str	x28, [sp, #0xd0]
     d78:      	mov	x21, x20
     d7c:      	str	x23, [sp, #0xb0]
     d80:      	str	x24, [sp, #0xa8]
     d84:      	b	0x2e4 <_stogir.verify.structure+0x144>
     d88:      	mov	x0, x21
     d8c:      	str	x19, [sp, #0xc8]
     d90:      	ldr	x19, [sp, #0x90]
     d94:      	str	x28, [sp, #0xd0]
     d98:      	ldr	x21, [sp, #0xb8]
     d9c:      	b	0x2b8 <_stogir.verify.structure+0x118>
     da0:      	mov	x0, x21
     da4:      	ldr	x19, [sp, #0x90]
     da8:      	str	x28, [sp, #0xd0]
     dac:      	ldr	x21, [sp, #0xb8]
     db0:      	b	0x2b8 <_stogir.verify.structure+0x118>
     db4:      	str	x12, [sp, #0xc8]
     db8:      	str	x2, [sp, #0xd0]
     dbc:      	ldr	x21, [sp, #0xb8]
     dc0:      	str	x10, [sp, #0x120]
     dc4:      	b	0x5ac <_stogir.verify.structure+0x40c>
     dc8:      	str	x21, [sp, #0x118]
     dcc:      	ldr	x21, [sp, #0xb8]
     dd0:      	str	x1, [sp, #0x100]
     dd4:      	str	x2, [sp, #0x108]
     dd8:      	b	0x538 <_stogir.verify.structure+0x398>
     ddc:      	str	w28, [sp, #0xe8]
     de0:      	mov	x28, x0
     de4:      	str	x1, [sp, #0xf0]
     de8:      	str	x2, [sp, #0xf8]
     dec:      	b	0x5fc <_stogir.verify.structure+0x45c>
     df0:      	ldr	x12, [sp, #0xc8]
     df4:      	ldr	x2, [sp, #0xd0]
     df8:      	b	0x85c <_stogir.verify.structure+0x6bc>
     dfc:      	str	x28, [sp, #0xd0]
     e00:      	mov	x28, x0
     e04:      	str	x1, [sp, #0xd8]
     e08:      	str	x2, [sp, #0xe0]
     e0c:      	b	0x914 <_stogir.verify.structure+0x774>
     e10:      	ldr	x12, [sp, #0xc8]
     e14:      	b	0x814 <_stogir.verify.structure+0x674>
     e18:      	str	x12, [sp, #0xc8]
     e1c:      	str	x2, [sp, #0xd0]
     e20:      	str	x0, [sp, #0xb0]
     e24:      	str	x4, [sp, #0xa8]
     e28:      	str	x5, [sp, #0x128]
     e2c:      	str	x10, [sp, #0x120]
     e30:      	b	0xb54 <_stogir.verify.structure+0x9b4>
     e34:      	ldr	x21, [sp, #0xb8]
     e38:      	b	0xc70 <_stogir.verify.structure+0xad0>
     e3c:      	ldr	x21, [sp, #0xb8]
     e40:      	b	0xc5c <_stogir.verify.structure+0xabc>
     e44:      	ldr	x0, [sp, #0xb0]
     e48:      	ldr	x4, [sp, #0xa8]
     e4c:      	b	0xb6c <_stogir.verify.structure+0x9cc>

0000000000000e50 <_stogir.verify.integer-operations-target-structured>:
     e50:      	sub	sp, sp, #0x470
     e54:      	str	x29, [sp, #0x10]
     e58:      	str	x30, [sp, #0x18]
     e5c:      	add	x29, sp, #0x10
     e60:      	str	x19, [sp, #0x420]
     e64:      	str	x20, [sp, #0x428]
     e68:      	str	x21, [sp, #0x430]
     e6c:      	str	x22, [sp, #0x438]
     e70:      	str	x23, [sp, #0x440]
     e74:      	str	x24, [sp, #0x448]
     e78:      	str	x25, [sp, #0x450]
     e7c:      	str	x26, [sp, #0x458]
     e80:      	str	x27, [sp, #0x460]
     e84:      	str	x28, [sp, #0x468]
     e88:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e88:  ARM64_RELOC_PAGE21	l_stogir.322
     e8c:      	ldr	x16, [x16]
		0000000000000e8c:  ARM64_RELOC_PAGEOFF12	l_stogir.322
     e90:      	orr	x2, x16, xzr
     e94:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e94:  ARM64_RELOC_PAGE21	l_stogir.323
     e98:      	ldr	x16, [x16]
		0000000000000e98:  ARM64_RELOC_PAGEOFF12	l_stogir.323
     e9c:      	orr	x19, x16, xzr
     ea0:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000ea0:  ARM64_RELOC_PAGE21	l_stogir.324
     ea4:      	ldr	x16, [x16]
		0000000000000ea4:  ARM64_RELOC_PAGEOFF12	l_stogir.324
     ea8:      	orr	x20, x16, xzr
     eac:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000eac:  ARM64_RELOC_PAGE21	l_stogir.325
     eb0:      	ldr	x16, [x16]
		0000000000000eb0:  ARM64_RELOC_PAGEOFF12	l_stogir.325
     eb4:      	orr	x21, x16, xzr
     eb8:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000eb8:  ARM64_RELOC_PAGE21	l_stogir.326
     ebc:      	ldr	x16, [x16]
		0000000000000ebc:  ARM64_RELOC_PAGEOFF12	l_stogir.326
     ec0:      	orr	x22, x16, xzr
     ec4:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000ec4:  ARM64_RELOC_PAGE21	l_stogir.327
     ec8:      	ldr	x16, [x16]
		0000000000000ec8:  ARM64_RELOC_PAGEOFF12	l_stogir.327
     ecc:      	orr	x23, x16, xzr
     ed0:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000ed0:  ARM64_RELOC_PAGE21	l_stogir.328
     ed4:      	ldr	x16, [x16]
		0000000000000ed4:  ARM64_RELOC_PAGEOFF12	l_stogir.328
     ed8:      	orr	x24, x16, xzr
     edc:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000edc:  ARM64_RELOC_PAGE21	l_stogir.329
     ee0:      	ldr	x16, [x16]
		0000000000000ee0:  ARM64_RELOC_PAGEOFF12	l_stogir.329
     ee4:      	orr	x25, x16, xzr
     ee8:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000ee8:  ARM64_RELOC_PAGE21	l_stogir.330
     eec:      	ldr	x16, [x16]
		0000000000000eec:  ARM64_RELOC_PAGEOFF12	l_stogir.330
     ef0:      	orr	x26, x16, xzr
     ef4:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000ef4:  ARM64_RELOC_PAGE21	l_stogir.331
     ef8:      	ldr	x16, [x16]
		0000000000000ef8:  ARM64_RELOC_PAGEOFF12	l_stogir.331
     efc:      	orr	x27, x16, xzr
     f00:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000f00:  ARM64_RELOC_PAGE21	l_stogir.332
     f04:      	ldr	x16, [x16]
		0000000000000f04:  ARM64_RELOC_PAGEOFF12	l_stogir.332
     f08:      	orr	x28, x16, xzr
     f0c:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000f0c:  ARM64_RELOC_PAGE21	l_stogir.333
     f10:      	ldr	x16, [x16]
		0000000000000f10:  ARM64_RELOC_PAGEOFF12	l_stogir.333
     f14:      	orr	x3, x16, xzr
     f18:      	lsr	w4, w1, #0
     f1c:      	lsr	w5, w1, #0
     f20:      	lsr	w1, w1, #0
     f24:      	add	x16, sp, #0x20
     f28:      	orr	x6, x16, xzr
     f2c:      	add	x16, sp, #0x30
     f30:      	orr	x7, x16, xzr
     f34:      	add	x7, x7, #0x8
     f38:      	add	x16, sp, #0x50
     f3c:      	orr	x9, x16, xzr
     f40:      	add	x9, x9, #0x8
     f44:      	add	x16, sp, #0xe0
     f48:      	orr	x10, x16, xzr
     f4c:      	add	x10, x10, #0x8
     f50:      	add	x16, sp, #0x100
     f54:      	orr	x11, x16, xzr
     f58:      	add	x11, x11, #0x8
     f5c:      	add	x16, sp, #0x120
     f60:      	orr	x12, x16, xzr
     f64:      	add	x12, x12, #0x8
     f68:      	add	x16, sp, #0x140
     f6c:      	orr	x13, x16, xzr
     f70:      	add	x13, x13, #0x8
     f74:      	add	x16, sp, #0x160
     f78:      	orr	x14, x16, xzr
     f7c:      	add	x14, x14, #0x8
     f80:      	add	x16, sp, #0x180
     f84:      	orr	x15, x16, xzr
     f88:      	add	x15, x15, #0x8
     f8c:      	str	w1, [sp, #0x230]
     f90:      	add	x16, sp, #0x1a0
     f94:      	orr	x1, x16, xzr
     f98:      	add	x1, x1, #0x8
     f9c:      	str	x1, [sp, #0x238]
     fa0:      	add	x16, sp, #0x1f0
     fa4:      	orr	x1, x16, xzr
     fa8:      	add	x1, x1, #0x8
     fac:      	str	x19, [sp, #0x240]
     fb0:      	str	x20, [sp, #0x250]
     fb4:      	str	x2, [sp, #0x248]
     fb8:      	mov	x2, #0x1                ; =1
     fbc:      	movz	x19, #0x0, lsl #48
     fc0:      	movz	x20, #0x0, lsl #48
     fc4:      	str	x1, [sp, #0x258]
     fc8:      	cmp	x20, #0x0
     fcc:      	cset	w1, eq
     fd0:      	uxtb	w16, w1
     fd4:      	cmp	w16, wzr
     fd8:      	b.eq	0x2440 <_stogir.verify.integer-operations-target-structured+0x15f0>
     fdc:      	str	x3, [sp, #0x260]
     fe0:      	ldr	x3, [x0, #0x8]
     fe4:      	cmp	x2, x3
     fe8:      	b.ge	0x244c <_stogir.verify.integer-operations-target-structured+0x15fc>
     fec:      	lsl	x1, x2, #4
     ff0:      	lsl	x3, x2, #2
     ff4:      	str	w4, [sp, #0x268]
     ff8:      	ldr	x4, [x0]
     ffc:      	add	x1, x1, x4
    1000:      	ldr	x4, [x1]
    1004:      	str	x20, [sp, #0x270]
    1008:      	uxtb	w20, w4
    100c:      	ldr	x1, [x1, #0x8]
    1010:      	str	x21, [sp, #0x278]
    1014:      	orr	x21, x20, xzr
    1018:      	add	x16, sp, #0x20
    101c:      	str	x4, [x16]
    1020:      	add	x16, sp, #0x20
    1024:      	str	x1, [x16, #0x8]
    1028:      	ldr	x1, [x0, #0x78]
    102c:      	add	x1, x3, x1
    1030:      	ldr	w1, [x1]
    1034:      	cmp	x21, #0xe
    1038:      	b.lt	0x1a24 <_stogir.verify.integer-operations-target-structured+0xbd4>
    103c:      	cmp	x21, #0x17
    1040:      	cset	w3, le
    1044:      	ubfx	x3, x3, #0, #8
    1048:      	cmp	x21, #0x1a
    104c:      	b.lt	0x1a2c <_stogir.verify.integer-operations-target-structured+0xbdc>
    1050:      	cmp	x21, #0x1e
    1054:      	b.gt	0x1a2c <_stogir.verify.integer-operations-target-structured+0xbdc>
    1058:      	mov	x4, #0x1                ; =1
    105c:      	cmp	x21, #0x1f
    1060:      	b.ne	0x1a64 <_stogir.verify.integer-operations-target-structured+0xc14>
    1064:      	str	x0, [sp, #0x280]
    1068:      	mov	x0, #0x1                ; =1
    106c:      	str	x0, [sp, #0x288]
    1070:      	lsr	w0, w2, #0
    1074:      	lsr	w1, w1, #0
    1078:      	lsr	w0, w0, #0
    107c:      	str	x8, [sp, #0x2d8]
    1080:      	str	w5, [sp, #0x2a0]
    1084:      	str	x6, [sp, #0x2a8]
    1088:      	str	x15, [sp, #0x2e8]
    108c:      	str	x2, [sp, #0x2f0]
    1090:      	mov	x2, x6
    1094:      	str	w1, [sp, #0x2f8]
    1098:      	str	x3, [sp, #0x300]
    109c:      	mov	w3, w1
    10a0:      	mov	w1, w0
    10a4:      	str	x4, [sp, #0x308]
    10a8:      	str	w0, [sp, #0x310]
    10ac:      	ldr	x0, [sp, #0x280]
    10b0:      	str	x22, [sp, #0x290]
    10b4:      	mov	x22, x13
    10b8:      	str	x23, [sp, #0x298]
    10bc:      	ldr	x23, [sp, #0x260]
    10c0:      	str	x24, [sp, #0x2b0]
    10c4:      	mov	x24, x7
    10c8:      	str	x25, [sp, #0x2b8]
    10cc:      	mov	x25, x9
    10d0:      	str	x26, [sp, #0x2c0]
    10d4:      	mov	x26, x10
    10d8:      	str	x27, [sp, #0x2c8]
    10dc:      	mov	x27, x11
    10e0:      	str	x28, [sp, #0x2d0]
    10e4:      	mov	x28, x12
    10e8:      	str	w20, [sp, #0x2e0]
    10ec:      	mov	x20, x14
    10f0:      	bl	0x10f0 <_stogir.verify.integer-operations-target-structured+0x2a0>
		00000000000010f0:  ARM64_RELOC_BRANCH26	_stogir.verify.classifications
    10f4:      	uxtb	w1, w0
    10f8:      	cmp	x1, #0x0
    10fc:      	cset	w1, ne
    1100:      	cmp	x21, #0x3d
    1104:      	b.lt	0x1adc <_stogir.verify.integer-operations-target-structured+0xc8c>
    1108:      	cmp	x21, #0x3f
    110c:      	b.gt	0x1adc <_stogir.verify.integer-operations-target-structured+0xc8c>
    1110:      	add	x8, sp, #0x30
    1114:      	ldr	w2, [sp, #0x268]
    1118:      	str	x0, [sp, #0x318]
    111c:      	ldr	x0, [sp, #0x280]
    1120:      	str	x20, [sp, #0x320]
    1124:      	mov	w20, w1
    1128:      	ldr	w1, [sp, #0x310]
    112c:      	bl	0x112c <_stogir.verify.integer-operations-target-structured+0x2dc>
		000000000000112c:  ARM64_RELOC_BRANCH26	_stogir.vector.validate
    1130:      	add	x16, sp, #0x30
    1134:      	ldr	w0, [x16]
    1138:      	lsr	x16, x0, #0
    113c:      	cmp	x16, #0x1
    1140:      	b.eq	0x115c <_stogir.verify.integer-operations-target-structured+0x30c>
    1144:      	b.lo	0x114c <_stogir.verify.integer-operations-target-structured+0x2fc>
    1148:      	b	0x1160 <_stogir.verify.integer-operations-target-structured+0x310>
    114c:      	cmp	x16, #0x0
    1150:      	b.eq	0x1158 <_stogir.verify.integer-operations-target-structured+0x308>
    1154:      	b	0x1160 <_stogir.verify.integer-operations-target-structured+0x310>
    1158:      	b	0x1b00 <_stogir.verify.integer-operations-target-structured+0xcb0>
    115c:      	b	0x1164 <_stogir.verify.integer-operations-target-structured+0x314>
    1160:      	b	0x23c4 <_stogir.verify.integer-operations-target-structured+0x1574>
    1164:      	add	x16, sp, #0x30
    1168:      	ldr	x0, [x16, #0x8]
    116c:      	ldr	x1, [x24, #0x8]
    1170:      	mov	x2, x1
    1174:      	mov	x1, x0
    1178:      	mov	x0, x19
    117c:      	mov	x19, x0
    1180:      	mov	x0, x1
    1184:      	mov	x1, x2
    1188:      	cmp	x21, #0x44
    118c:      	b.ne	0x1b28 <_stogir.verify.integer-operations-target-structured+0xcd8>
    1190:      	uxtb	w16, w20
    1194:      	cmp	w16, wzr
    1198:      	b.eq	0x1b18 <_stogir.verify.integer-operations-target-structured+0xcc8>
    119c:      	mov	x2, x1
    11a0:      	mov	x1, x0
    11a4:      	movz	x0, #0x0, lsl #48
    11a8:      	cmp	x0, #0x0
    11ac:      	b.eq	0x2458 <_stogir.verify.integer-operations-target-structured+0x1608>
    11b0:      	add	x8, sp, #0x50
    11b4:      	ldr	x0, [sp, #0x280]
    11b8:      	str	x1, [sp, #0x328]
    11bc:      	ldr	w1, [sp, #0x310]
    11c0:      	str	x2, [sp, #0x330]
    11c4:      	bl	0x11c4 <_stogir.verify.integer-operations-target-structured+0x374>
		00000000000011c4:  ARM64_RELOC_BRANCH26	_stogir.copy.validate
    11c8:      	add	x16, sp, #0x50
    11cc:      	ldr	w0, [x16]
    11d0:      	lsr	x16, x0, #0
    11d4:      	cmp	x16, #0x1
    11d8:      	b.eq	0x11f4 <_stogir.verify.integer-operations-target-structured+0x3a4>
    11dc:      	b.lo	0x11e4 <_stogir.verify.integer-operations-target-structured+0x394>
    11e0:      	b	0x11f8 <_stogir.verify.integer-operations-target-structured+0x3a8>
    11e4:      	cmp	x16, #0x0
    11e8:      	b.eq	0x11f0 <_stogir.verify.integer-operations-target-structured+0x3a0>
    11ec:      	b	0x11f8 <_stogir.verify.integer-operations-target-structured+0x3a8>
    11f0:      	b	0x1b38 <_stogir.verify.integer-operations-target-structured+0xce8>
    11f4:      	b	0x11fc <_stogir.verify.integer-operations-target-structured+0x3ac>
    11f8:      	b	0x1b50 <_stogir.verify.integer-operations-target-structured+0xd00>
    11fc:      	add	x16, sp, #0x50
    1200:      	ldr	x0, [x16, #0x8]
    1204:      	ldr	x1, [x25, #0x8]
    1208:      	mov	x2, x1
    120c:      	mov	x1, x0
    1210:      	mov	x0, x19
    1214:      	mov	x19, x0
    1218:      	mov	x0, x1
    121c:      	mov	x1, x2
    1220:      	cmp	x21, #0x1d
    1224:      	b.ne	0x1b64 <_stogir.verify.integer-operations-target-structured+0xd14>
    1228:      	mov	x2, x1
    122c:      	mov	x1, x0
    1230:      	mov	x0, #0x1                ; =1
    1234:      	cmp	x0, #0x0
    1238:      	b.eq	0x1b8c <_stogir.verify.integer-operations-target-structured+0xd3c>
    123c:      	add	x16, sp, #0x20
    1240:      	ldr	w0, [x16, #0xc]
    1244:      	sxtw	x0, w0
    1248:      	cmp	x0, #0x0
    124c:      	b.ne	0x1b84 <_stogir.verify.integer-operations-target-structured+0xd34>
    1250:      	movz	x0, #0x0, lsl #48
    1254:      	cmp	x0, #0x0
    1258:      	b.eq	0x2464 <_stogir.verify.integer-operations-target-structured+0x1614>
    125c:      	add	x16, sp, #0x20
    1260:      	ldr	w0, [x16, #0xc]
    1264:      	lsr	w0, w0, #0
    1268:      	add	x8, sp, #0x70
    126c:      	str	x1, [sp, #0x338]
    1270:      	mov	w1, w0
    1274:      	ldr	x0, [sp, #0x280]
    1278:      	str	x2, [sp, #0x340]
    127c:      	bl	0x127c <_stogir.verify.integer-operations-target-structured+0x42c>
		000000000000127c:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    1280:      	add	x16, sp, #0x70
    1284:      	ldr	w0, [x16]
    1288:      	lsr	x16, x0, #0
    128c:      	cmp	x16, #0x1
    1290:      	b.eq	0x12ac <_stogir.verify.integer-operations-target-structured+0x45c>
    1294:      	b.lo	0x129c <_stogir.verify.integer-operations-target-structured+0x44c>
    1298:      	b	0x12b0 <_stogir.verify.integer-operations-target-structured+0x460>
    129c:      	cmp	x16, #0x0
    12a0:      	b.eq	0x12a8 <_stogir.verify.integer-operations-target-structured+0x458>
    12a4:      	b	0x12b0 <_stogir.verify.integer-operations-target-structured+0x460>
    12a8:      	b	0x12b4 <_stogir.verify.integer-operations-target-structured+0x464>
    12ac:      	b	0x1b94 <_stogir.verify.integer-operations-target-structured+0xd44>
    12b0:      	b	0x1c48 <_stogir.verify.integer-operations-target-structured+0xdf8>
    12b4:      	ldr	x0, [sp, #0x240]
    12b8:      	mov	x1, #0x16               ; =22
    12bc:      	cmp	x21, #0x29
    12c0:      	b.lt	0x1c5c <_stogir.verify.integer-operations-target-structured+0xe0c>
    12c4:      	cmp	x21, #0x2b
    12c8:      	cset	w2, le
    12cc:      	ubfx	x2, x2, #0, #8
    12d0:      	fmov	d31, x0
    12d4:      	mov	x0, x2
    12d8:      	mov	x2, x1
    12dc:      	fmov	x1, d31
    12e0:      	cmp	x21, #0x2c
    12e4:      	cset	w3, eq
    12e8:      	cmp	x0, #0x0
    12ec:      	b.eq	0x1c6c <_stogir.verify.integer-operations-target-structured+0xe1c>
    12f0:      	mov	x0, #0x1                ; =1
    12f4:      	cmp	x0, #0x0
    12f8:      	b.eq	0x2470 <_stogir.verify.integer-operations-target-structured+0x1620>
    12fc:      	uxtb	w16, w3
    1300:      	cmp	w16, wzr
    1304:      	b.eq	0x247c <_stogir.verify.integer-operations-target-structured+0x162c>
    1308:      	add	x8, sp, #0xa0
    130c:      	ldr	x0, [sp, #0x280]
    1310:      	str	x1, [sp, #0x348]
    1314:      	ldr	w1, [sp, #0x310]
    1318:      	str	x2, [sp, #0x350]
    131c:      	bl	0x131c <_stogir.verify.integer-operations-target-structured+0x4cc>
		000000000000131c:  ARM64_RELOC_BRANCH26	_stogir.checked.validate-projection
    1320:      	add	x16, sp, #0xa0
    1324:      	ldr	x0, [x16]
    1328:      	add	x16, sp, #0xa0
    132c:      	ldr	x1, [x16, #0x8]
    1330:      	add	x16, sp, #0xa0
    1334:      	ldr	x2, [x16, #0x10]
    1338:      	mov	x3, x1
    133c:      	ldr	x1, [sp, #0x350]
    1340:      	mov	x4, x2
    1344:      	mov	x2, x0
    1348:      	ldr	x0, [sp, #0x348]
    134c:      	lsr	w2, w2, #0
    1350:      	lsr	x16, x2, #0
    1354:      	cmp	x16, #0x1
    1358:      	b.eq	0x1374 <_stogir.verify.integer-operations-target-structured+0x524>
    135c:      	b.lo	0x1364 <_stogir.verify.integer-operations-target-structured+0x514>
    1360:      	b	0x1378 <_stogir.verify.integer-operations-target-structured+0x528>
    1364:      	cmp	x16, #0x0
    1368:      	b.eq	0x1370 <_stogir.verify.integer-operations-target-structured+0x520>
    136c:      	b	0x1378 <_stogir.verify.integer-operations-target-structured+0x528>
    1370:      	b	0x1cb4 <_stogir.verify.integer-operations-target-structured+0xe64>
    1374:      	b	0x137c <_stogir.verify.integer-operations-target-structured+0x52c>
    1378:      	b	0x1cd4 <_stogir.verify.integer-operations-target-structured+0xe84>
    137c:      	mov	x0, x19
    1380:      	mov	x1, x3
    1384:      	mov	x2, x4
    1388:      	mov	x19, x0
    138c:      	mov	x0, x1
    1390:      	mov	x1, x2
    1394:      	cmp	x21, #0x7e
    1398:      	b.lt	0x1ce8 <_stogir.verify.integer-operations-target-structured+0xe98>
    139c:      	cmp	x21, #0x82
    13a0:      	cset	w2, le
    13a4:      	ubfx	x2, x2, #0, #8
    13a8:      	fmov	d31, x0
    13ac:      	mov	x0, x2
    13b0:      	mov	x2, x1
    13b4:      	fmov	x1, d31
    13b8:      	cmp	x0, #0x0
    13bc:      	b.eq	0x2488 <_stogir.verify.integer-operations-target-structured+0x1638>
    13c0:      	add	x8, sp, #0xe0
    13c4:      	ldr	x0, [sp, #0x280]
    13c8:      	str	x1, [sp, #0x358]
    13cc:      	ldr	w1, [sp, #0x310]
    13d0:      	str	x2, [sp, #0x360]
    13d4:      	bl	0x13d4 <_stogir.verify.integer-operations-target-structured+0x584>
		00000000000013d4:  ARM64_RELOC_BRANCH26	_stogir.atomic.validate
    13d8:      	add	x16, sp, #0xe0
    13dc:      	ldr	w0, [x16]
    13e0:      	lsr	x16, x0, #0
    13e4:      	cmp	x16, #0x1
    13e8:      	b.eq	0x1404 <_stogir.verify.integer-operations-target-structured+0x5b4>
    13ec:      	b.lo	0x13f4 <_stogir.verify.integer-operations-target-structured+0x5a4>
    13f0:      	b	0x1408 <_stogir.verify.integer-operations-target-structured+0x5b8>
    13f4:      	cmp	x16, #0x0
    13f8:      	b.eq	0x1400 <_stogir.verify.integer-operations-target-structured+0x5b0>
    13fc:      	b	0x1408 <_stogir.verify.integer-operations-target-structured+0x5b8>
    1400:      	b	0x1cf8 <_stogir.verify.integer-operations-target-structured+0xea8>
    1404:      	b	0x140c <_stogir.verify.integer-operations-target-structured+0x5bc>
    1408:      	b	0x1d10 <_stogir.verify.integer-operations-target-structured+0xec0>
    140c:      	add	x16, sp, #0xe0
    1410:      	ldr	x0, [x16, #0x8]
    1414:      	ldr	x1, [x26, #0x8]
    1418:      	mov	x2, x1
    141c:      	mov	x1, x0
    1420:      	mov	x0, x19
    1424:      	mov	x19, x0
    1428:      	mov	x0, x1
    142c:      	mov	x1, x2
    1430:      	cmp	x21, #0x60
    1434:      	b.ne	0x1d24 <_stogir.verify.integer-operations-target-structured+0xed4>
    1438:      	mov	x2, x1
    143c:      	mov	x1, x0
    1440:      	mov	x0, #0x1                ; =1
    1444:      	cmp	x0, #0x0
    1448:      	b.eq	0x2494 <_stogir.verify.integer-operations-target-structured+0x1644>
    144c:      	add	x8, sp, #0x100
    1450:      	ldr	x0, [sp, #0x280]
    1454:      	str	x1, [sp, #0x368]
    1458:      	ldr	w1, [sp, #0x310]
    145c:      	str	x2, [sp, #0x370]
    1460:      	bl	0x1460 <_stogir.verify.integer-operations-target-structured+0x610>
		0000000000001460:  ARM64_RELOC_BRANCH26	_stogir.terminal.validate
    1464:      	add	x16, sp, #0x100
    1468:      	ldr	w0, [x16]
    146c:      	lsr	x16, x0, #0
    1470:      	cmp	x16, #0x1
    1474:      	b.eq	0x1490 <_stogir.verify.integer-operations-target-structured+0x640>
    1478:      	b.lo	0x1480 <_stogir.verify.integer-operations-target-structured+0x630>
    147c:      	b	0x1494 <_stogir.verify.integer-operations-target-structured+0x644>
    1480:      	cmp	x16, #0x0
    1484:      	b.eq	0x148c <_stogir.verify.integer-operations-target-structured+0x63c>
    1488:      	b	0x1494 <_stogir.verify.integer-operations-target-structured+0x644>
    148c:      	b	0x1d44 <_stogir.verify.integer-operations-target-structured+0xef4>
    1490:      	b	0x1498 <_stogir.verify.integer-operations-target-structured+0x648>
    1494:      	b	0x1d5c <_stogir.verify.integer-operations-target-structured+0xf0c>
    1498:      	add	x16, sp, #0x100
    149c:      	ldr	x0, [x16, #0x8]
    14a0:      	ldr	x1, [x27, #0x8]
    14a4:      	mov	x2, x1
    14a8:      	mov	x1, x0
    14ac:      	mov	x0, x19
    14b0:      	mov	x19, x0
    14b4:      	mov	x0, x1
    14b8:      	mov	x1, x2
    14bc:      	cmp	x21, #0x75
    14c0:      	b.ne	0x1d70 <_stogir.verify.integer-operations-target-structured+0xf20>
    14c4:      	mov	x2, x1
    14c8:      	mov	x1, x0
    14cc:      	mov	x0, #0x1                ; =1
    14d0:      	cmp	x0, #0x0
    14d4:      	b.eq	0x24a0 <_stogir.verify.integer-operations-target-structured+0x1650>
    14d8:      	add	x8, sp, #0x120
    14dc:      	ldr	x0, [sp, #0x280]
    14e0:      	str	x1, [sp, #0x378]
    14e4:      	ldr	w1, [sp, #0x310]
    14e8:      	str	x2, [sp, #0x380]
    14ec:      	bl	0x14ec <_stogir.verify.integer-operations-target-structured+0x69c>
		00000000000014ec:  ARM64_RELOC_BRANCH26	_stogir.switch.validate
    14f0:      	add	x16, sp, #0x120
    14f4:      	ldr	w0, [x16]
    14f8:      	lsr	x16, x0, #0
    14fc:      	cmp	x16, #0x1
    1500:      	b.eq	0x151c <_stogir.verify.integer-operations-target-structured+0x6cc>
    1504:      	b.lo	0x150c <_stogir.verify.integer-operations-target-structured+0x6bc>
    1508:      	b	0x1520 <_stogir.verify.integer-operations-target-structured+0x6d0>
    150c:      	cmp	x16, #0x0
    1510:      	b.eq	0x1518 <_stogir.verify.integer-operations-target-structured+0x6c8>
    1514:      	b	0x1520 <_stogir.verify.integer-operations-target-structured+0x6d0>
    1518:      	b	0x1da0 <_stogir.verify.integer-operations-target-structured+0xf50>
    151c:      	b	0x1524 <_stogir.verify.integer-operations-target-structured+0x6d4>
    1520:      	b	0x1db8 <_stogir.verify.integer-operations-target-structured+0xf68>
    1524:      	add	x16, sp, #0x120
    1528:      	ldr	x0, [x16, #0x8]
    152c:      	ldr	x1, [x28, #0x8]
    1530:      	mov	x2, x1
    1534:      	mov	x1, x0
    1538:      	mov	x0, x19
    153c:      	mov	x19, x0
    1540:      	mov	x0, x1
    1544:      	mov	x1, x2
    1548:      	cmp	x21, #0x42
    154c:      	b.ne	0x1dcc <_stogir.verify.integer-operations-target-structured+0xf7c>
    1550:      	mov	x2, x1
    1554:      	mov	x1, x0
    1558:      	mov	x0, #0x1                ; =1
    155c:      	cmp	x0, #0x0
    1560:      	b.eq	0x24ac <_stogir.verify.integer-operations-target-structured+0x165c>
    1564:      	add	x8, sp, #0x140
    1568:      	ldr	x0, [sp, #0x280]
    156c:      	str	x1, [sp, #0x388]
    1570:      	ldr	w1, [sp, #0x310]
    1574:      	str	x2, [sp, #0x390]
    1578:      	bl	0x1578 <_stogir.verify.integer-operations-target-structured+0x728>
		0000000000001578:  ARM64_RELOC_BRANCH26	_stogir.stack.validate
    157c:      	add	x16, sp, #0x140
    1580:      	ldr	w0, [x16]
    1584:      	lsr	x16, x0, #0
    1588:      	cmp	x16, #0x1
    158c:      	b.eq	0x15a8 <_stogir.verify.integer-operations-target-structured+0x758>
    1590:      	b.lo	0x1598 <_stogir.verify.integer-operations-target-structured+0x748>
    1594:      	b	0x15ac <_stogir.verify.integer-operations-target-structured+0x75c>
    1598:      	cmp	x16, #0x0
    159c:      	b.eq	0x15a4 <_stogir.verify.integer-operations-target-structured+0x754>
    15a0:      	b	0x15ac <_stogir.verify.integer-operations-target-structured+0x75c>
    15a4:      	b	0x1e1c <_stogir.verify.integer-operations-target-structured+0xfcc>
    15a8:      	b	0x15b0 <_stogir.verify.integer-operations-target-structured+0x760>
    15ac:      	b	0x1e34 <_stogir.verify.integer-operations-target-structured+0xfe4>
    15b0:      	add	x16, sp, #0x140
    15b4:      	ldr	x0, [x16, #0x8]
    15b8:      	ldr	x1, [x22, #0x8]
    15bc:      	mov	x2, x1
    15c0:      	mov	x1, x0
    15c4:      	mov	x0, x19
    15c8:      	mov	x19, x0
    15cc:      	mov	x0, x1
    15d0:      	mov	x1, x2
    15d4:      	cmp	x21, #0x41
    15d8:      	b.ne	0x1e48 <_stogir.verify.integer-operations-target-structured+0xff8>
    15dc:      	mov	x2, x1
    15e0:      	mov	x1, x0
    15e4:      	mov	x0, #0x1                ; =1
    15e8:      	cmp	x0, #0x0
    15ec:      	b.eq	0x24b8 <_stogir.verify.integer-operations-target-structured+0x1668>
    15f0:      	add	x8, sp, #0x160
    15f4:      	ldr	x0, [sp, #0x280]
    15f8:      	str	x1, [sp, #0x398]
    15fc:      	ldr	w1, [sp, #0x310]
    1600:      	str	x2, [sp, #0x3a0]
    1604:      	ldr	w2, [sp, #0x2a0]
    1608:      	bl	0x1608 <_stogir.verify.integer-operations-target-structured+0x7b8>
		0000000000001608:  ARM64_RELOC_BRANCH26	_stogir.locals.validate
    160c:      	add	x16, sp, #0x160
    1610:      	ldr	w0, [x16]
    1614:      	lsr	x16, x0, #0
    1618:      	cmp	x16, #0x1
    161c:      	b.eq	0x163c <_stogir.verify.integer-operations-target-structured+0x7ec>
    1620:      	b.lo	0x1628 <_stogir.verify.integer-operations-target-structured+0x7d8>
    1624:      	b	0x1640 <_stogir.verify.integer-operations-target-structured+0x7f0>
    1628:      	cmp	x16, #0x0
    162c:      	b.eq	0x1634 <_stogir.verify.integer-operations-target-structured+0x7e4>
    1630:      	b	0x1640 <_stogir.verify.integer-operations-target-structured+0x7f0>
    1634:      	ldr	x1, [sp, #0x320]
    1638:      	b	0x1e88 <_stogir.verify.integer-operations-target-structured+0x1038>
    163c:      	b	0x1644 <_stogir.verify.integer-operations-target-structured+0x7f4>
    1640:      	b	0x1ea0 <_stogir.verify.integer-operations-target-structured+0x1050>
    1644:      	add	x16, sp, #0x160
    1648:      	ldr	x0, [x16, #0x8]
    164c:      	ldr	x1, [sp, #0x320]
    1650:      	ldr	x2, [x1, #0x8]
    1654:      	mov	x3, x2
    1658:      	mov	x2, x0
    165c:      	mov	x0, x19
    1660:      	mov	x19, x0
    1664:      	mov	x0, x2
    1668:      	mov	x2, x3
    166c:      	cmp	x21, #0x21
    1670:      	b.lt	0x1eb4 <_stogir.verify.integer-operations-target-structured+0x1064>
    1674:      	cmp	x21, #0x27
    1678:      	cset	w3, le
    167c:      	ubfx	x3, x3, #0, #8
    1680:      	fmov	d31, x0
    1684:      	mov	x0, x3
    1688:      	mov	x3, x2
    168c:      	fmov	x2, d31
    1690:      	cmp	x0, #0x0
    1694:      	b.eq	0x24c8 <_stogir.verify.integer-operations-target-structured+0x1678>
    1698:      	add	x8, sp, #0x180
    169c:      	ldr	x0, [sp, #0x280]
    16a0:      	str	x1, [sp, #0x320]
    16a4:      	ldr	w1, [sp, #0x310]
    16a8:      	str	x2, [sp, #0x3a8]
    16ac:      	ldr	w2, [sp, #0x230]
    16b0:      	str	x3, [sp, #0x3b0]
    16b4:      	bl	0x16b4 <_stogir.verify.integer-operations-target-structured+0x864>
		00000000000016b4:  ARM64_RELOC_BRANCH26	_stogir.conversion.validate
    16b8:      	add	x16, sp, #0x180
    16bc:      	ldr	w0, [x16]
    16c0:      	lsr	x16, x0, #0
    16c4:      	cmp	x16, #0x1
    16c8:      	b.eq	0x16e8 <_stogir.verify.integer-operations-target-structured+0x898>
    16cc:      	b.lo	0x16d4 <_stogir.verify.integer-operations-target-structured+0x884>
    16d0:      	b	0x16ec <_stogir.verify.integer-operations-target-structured+0x89c>
    16d4:      	cmp	x16, #0x0
    16d8:      	b.eq	0x16e0 <_stogir.verify.integer-operations-target-structured+0x890>
    16dc:      	b	0x16ec <_stogir.verify.integer-operations-target-structured+0x89c>
    16e0:      	ldr	x1, [sp, #0x2e8]
    16e4:      	b	0x1ec4 <_stogir.verify.integer-operations-target-structured+0x1074>
    16e8:      	b	0x16f0 <_stogir.verify.integer-operations-target-structured+0x8a0>
    16ec:      	b	0x1edc <_stogir.verify.integer-operations-target-structured+0x108c>
    16f0:      	add	x16, sp, #0x180
    16f4:      	ldr	x0, [x16, #0x8]
    16f8:      	ldr	x1, [sp, #0x2e8]
    16fc:      	ldr	x2, [x1, #0x8]
    1700:      	mov	x3, x2
    1704:      	mov	x2, x0
    1708:      	mov	x0, x19
    170c:      	mov	x19, x0
    1710:      	mov	x0, x2
    1714:      	mov	x2, x3
    1718:      	cmp	x21, #0x3c
    171c:      	b.ne	0x24dc <_stogir.verify.integer-operations-target-structured+0x168c>
    1720:      	add	x8, sp, #0x1a0
    1724:      	str	x1, [sp, #0x2e8]
    1728:      	ldr	w1, [sp, #0x310]
    172c:      	str	x0, [sp, #0x3b8]
    1730:      	ldr	x0, [sp, #0x280]
    1734:      	str	x2, [sp, #0x3c0]
    1738:      	bl	0x1738 <_stogir.verify.integer-operations-target-structured+0x8e8>
		0000000000001738:  ARM64_RELOC_BRANCH26	_stogir.conditional.validate
    173c:      	add	x16, sp, #0x1a0
    1740:      	ldr	w0, [x16]
    1744:      	lsr	x16, x0, #0
    1748:      	cmp	x16, #0x1
    174c:      	b.eq	0x176c <_stogir.verify.integer-operations-target-structured+0x91c>
    1750:      	b.lo	0x1758 <_stogir.verify.integer-operations-target-structured+0x908>
    1754:      	b	0x1770 <_stogir.verify.integer-operations-target-structured+0x920>
    1758:      	cmp	x16, #0x0
    175c:      	b.eq	0x1764 <_stogir.verify.integer-operations-target-structured+0x914>
    1760:      	b	0x1770 <_stogir.verify.integer-operations-target-structured+0x920>
    1764:      	ldr	x1, [sp, #0x238]
    1768:      	b	0x1ef0 <_stogir.verify.integer-operations-target-structured+0x10a0>
    176c:      	b	0x1774 <_stogir.verify.integer-operations-target-structured+0x924>
    1770:      	b	0x1f08 <_stogir.verify.integer-operations-target-structured+0x10b8>
    1774:      	add	x16, sp, #0x1a0
    1778:      	ldr	x0, [x16, #0x8]
    177c:      	ldr	x1, [sp, #0x238]
    1780:      	ldr	x2, [x1, #0x8]
    1784:      	mov	x3, x2
    1788:      	mov	x2, x0
    178c:      	mov	x0, x19
    1790:      	mov	x19, x0
    1794:      	mov	x0, x2
    1798:      	mov	x2, x3
    179c:      	cmp	x21, #0x78
    17a0:      	b.ne	0x24f0 <_stogir.verify.integer-operations-target-structured+0x16a0>
    17a4:      	add	x16, sp, #0x20
    17a8:      	ldr	w3, [x16]
    17ac:      	ubfx	x3, x3, #8, #8
    17b0:      	cmp	x3, #0x0
    17b4:      	b.ne	0x1f38 <_stogir.verify.integer-operations-target-structured+0x10e8>
    17b8:      	add	x16, sp, #0x20
    17bc:      	ldr	w3, [x16, #0x8]
    17c0:      	sxtw	x3, w3
    17c4:      	cmp	x3, #0x0
    17c8:      	b.ne	0x1f1c <_stogir.verify.integer-operations-target-structured+0x10cc>
    17cc:      	mov	x3, x2
    17d0:      	mov	x2, x0
    17d4:      	movz	x0, #0x0, lsl #48
    17d8:      	cmp	x0, #0x0
    17dc:      	b.eq	0x1f2c <_stogir.verify.integer-operations-target-structured+0x10dc>
    17e0:      	ldr	x0, [sp, #0x278]
    17e4:      	mov	x2, #0x1f               ; =31
    17e8:      	str	x1, [sp, #0x238]
    17ec:      	mov	x1, x2
    17f0:      	add	x2, x19, #0x1
    17f4:      	lsr	w2, w2, #0
    17f8:      	sxtw	x2, w2
    17fc:      	mov	x19, x2
    1800:      	ldr	x2, [sp, #0x318]
    1804:      	uxth	w2, w2
    1808:      	mov	w17, #0x8               ; =8
    180c:      	uxth	w16, w2
    1810:      	ubfx	w17, w17, #0, #4
    1814:      	lsr	w2, w16, w17
    1818:      	uxth	w2, w2
    181c:      	uxtb	w2, w2
    1820:      	cmp	x2, #0x0
    1824:      	b.eq	0x2500 <_stogir.verify.integer-operations-target-structured+0x16b0>
    1828:      	add	x8, sp, #0x1f0
    182c:      	str	x0, [sp, #0x3d8]
    1830:      	ldr	x0, [sp, #0x280]
    1834:      	str	x1, [sp, #0x3e0]
    1838:      	ldr	w1, [sp, #0x310]
    183c:      	str	x22, [sp, #0x3e8]
    1840:      	mov	x22, x2
    1844:      	bl	0x1844 <_stogir.verify.integer-operations-target-structured+0x9f4>
		0000000000001844:  ARM64_RELOC_BRANCH26	_stogir.floating.validate
    1848:      	add	x16, sp, #0x1f0
    184c:      	ldr	w0, [x16]
    1850:      	lsr	x16, x0, #0
    1854:      	cmp	x16, #0x1
    1858:      	b.eq	0x1878 <_stogir.verify.integer-operations-target-structured+0xa28>
    185c:      	b.lo	0x1864 <_stogir.verify.integer-operations-target-structured+0xa14>
    1860:      	b	0x187c <_stogir.verify.integer-operations-target-structured+0xa2c>
    1864:      	cmp	x16, #0x0
    1868:      	b.eq	0x1870 <_stogir.verify.integer-operations-target-structured+0xa20>
    186c:      	b	0x187c <_stogir.verify.integer-operations-target-structured+0xa2c>
    1870:      	ldr	x1, [sp, #0x258]
    1874:      	b	0x1ff0 <_stogir.verify.integer-operations-target-structured+0x11a0>
    1878:      	b	0x1880 <_stogir.verify.integer-operations-target-structured+0xa30>
    187c:      	b	0x2008 <_stogir.verify.integer-operations-target-structured+0x11b8>
    1880:      	add	x16, sp, #0x1f0
    1884:      	ldr	x0, [x16, #0x8]
    1888:      	ldr	x1, [sp, #0x258]
    188c:      	ldr	x2, [x1, #0x8]
    1890:      	mov	x3, x2
    1894:      	mov	x2, x0
    1898:      	mov	x0, x19
    189c:      	mov	x19, x0
    18a0:      	mov	x0, x2
    18a4:      	mov	x2, x3
    18a8:      	uxtb	w16, w20
    18ac:      	cmp	w16, wzr
    18b0:      	b.eq	0x201c <_stogir.verify.integer-operations-target-structured+0x11cc>
    18b4:      	mov	x3, x2
    18b8:      	mov	x2, x0
    18bc:      	movz	x0, #0x0, lsl #48
    18c0:      	cmp	x0, #0x0
    18c4:      	b.eq	0x2518 <_stogir.verify.integer-operations-target-structured+0x16c8>
    18c8:      	cmp	x22, #0x0
    18cc:      	b.eq	0x202c <_stogir.verify.integer-operations-target-structured+0x11dc>
    18d0:      	movz	x0, #0x0, lsl #48
    18d4:      	cmp	x0, #0x0
    18d8:      	b.eq	0x2524 <_stogir.verify.integer-operations-target-structured+0x16d4>
    18dc:      	ldr	x20, [sp, #0x300]
    18e0:      	cmp	x20, #0x0
    18e4:      	b.eq	0x2034 <_stogir.verify.integer-operations-target-structured+0x11e4>
    18e8:      	ldr	x22, [sp, #0x308]
    18ec:      	mov	x0, #0x1                ; =1
    18f0:      	cmp	x0, #0x0
    18f4:      	b.eq	0x2530 <_stogir.verify.integer-operations-target-structured+0x16e0>
    18f8:      	add	x16, sp, #0x210
    18fc:      	str	x16, [sp]
    1900:      	ldr	x0, [sp, #0x280]
    1904:      	str	x1, [sp, #0x258]
    1908:      	ldr	w1, [sp, #0x310]
    190c:      	str	x2, [sp, #0x3f0]
    1910:      	str	x3, [sp, #0x3f8]
    1914:      	mov	x2, #0x1                ; =1
    1918:      	bl	0x1918 <_stogir.verify.integer-operations-target-structured+0xac8>
		0000000000001918:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    191c:      	ldr	x16, [sp]
    1920:      	str	x0, [x16]
    1924:      	str	x1, [x16, #0x8]
    1928:      	add	x16, sp, #0x210
    192c:      	ldr	x0, [x16]
    1930:      	add	x16, sp, #0x210
    1934:      	ldr	x1, [x16, #0x8]
    1938:      	lsr	w0, w0, #0
    193c:      	lsr	x16, x0, #0
    1940:      	cmp	x16, #0x1
    1944:      	b.eq	0x1960 <_stogir.verify.integer-operations-target-structured+0xb10>
    1948:      	b.lo	0x1950 <_stogir.verify.integer-operations-target-structured+0xb00>
    194c:      	b	0x1964 <_stogir.verify.integer-operations-target-structured+0xb14>
    1950:      	cmp	x16, #0x0
    1954:      	b.eq	0x195c <_stogir.verify.integer-operations-target-structured+0xb0c>
    1958:      	b	0x1964 <_stogir.verify.integer-operations-target-structured+0xb14>
    195c:      	b	0x1968 <_stogir.verify.integer-operations-target-structured+0xb18>
    1960:      	b	0x2060 <_stogir.verify.integer-operations-target-structured+0x1210>
    1964:      	b	0x23ac <_stogir.verify.integer-operations-target-structured+0x155c>
    1968:      	str	x23, [sp, #0x260]
    196c:      	ldr	x0, [sp, #0x2b0]
    1970:      	mov	x1, #0x17               ; =23
    1974:      	add	x2, x19, #0x1
    1978:      	lsr	w2, w2, #0
    197c:      	sxtw	x2, w2
    1980:      	fmov	d31, x0
    1984:      	mov	x0, x2
    1988:      	mov	x2, x1
    198c:      	fmov	x1, d31
    1990:      	ldr	w3, [sp, #0x2f8]
    1994:      	sxtw	x3, w3
    1998:      	add	x3, x3, #0x4
    199c:      	asr	x16, x3, #63
    19a0:      	lsr	x16, x16, #62
    19a4:      	add	x3, x3, x16
    19a8:      	asr	x3, x3, #2
    19ac:      	ldr	x4, [sp, #0x2f0]
    19b0:      	add	x3, x3, x4
    19b4:      	ldr	x8, [sp, #0x2d8]
    19b8:      	ldr	x6, [sp, #0x2a8]
    19bc:      	ldr	x21, [sp, #0x278]
    19c0:      	ldr	x22, [sp, #0x290]
    19c4:      	ldr	x23, [sp, #0x298]
    19c8:      	ldr	w4, [sp, #0x268]
    19cc:      	mov	x7, x24
    19d0:      	ldr	x24, [sp, #0x2b0]
    19d4:      	mov	x9, x25
    19d8:      	ldr	x25, [sp, #0x2b8]
    19dc:      	mov	x10, x26
    19e0:      	ldr	x26, [sp, #0x2c0]
    19e4:      	mov	x11, x27
    19e8:      	ldr	x27, [sp, #0x2c8]
    19ec:      	mov	x12, x28
    19f0:      	ldr	x28, [sp, #0x2d0]
    19f4:      	ldr	x13, [sp, #0x3e8]
    19f8:      	ldr	w5, [sp, #0x2a0]
    19fc:      	ldr	x14, [sp, #0x320]
    1a00:      	ldr	x15, [sp, #0x2e8]
    1a04:      	mov	x19, x0
    1a08:      	ldr	x0, [sp, #0x280]
    1a0c:      	str	x1, [sp, #0x248]
    1a10:      	ldr	x1, [sp, #0x258]
    1a14:      	mov	x20, x2
    1a18:      	mov	x2, x3
    1a1c:      	ldr	x3, [sp, #0x260]
    1a20:      	b	0xfc4 <_stogir.verify.integer-operations-target-structured+0x174>
    1a24:      	movz	x3, #0x0, lsl #48
    1a28:      	b	0x1048 <_stogir.verify.integer-operations-target-structured+0x1f8>
    1a2c:      	cmp	x21, #0x2e
    1a30:      	b.lt	0x1a44 <_stogir.verify.integer-operations-target-structured+0xbf4>
    1a34:      	cmp	x21, #0x35
    1a38:      	b.gt	0x1a44 <_stogir.verify.integer-operations-target-structured+0xbf4>
    1a3c:      	mov	x4, #0x1                ; =1
    1a40:      	b	0x105c <_stogir.verify.integer-operations-target-structured+0x20c>
    1a44:      	cmp	x21, #0x3a
    1a48:      	b.ne	0x1a54 <_stogir.verify.integer-operations-target-structured+0xc04>
    1a4c:      	mov	x4, #0x1                ; =1
    1a50:      	b	0x1a40 <_stogir.verify.integer-operations-target-structured+0xbf0>
    1a54:      	cmp	x21, #0x3b
    1a58:      	cset	w4, eq
    1a5c:      	ubfx	x4, x4, #0, #8
    1a60:      	b	0x1a50 <_stogir.verify.integer-operations-target-structured+0xc00>
    1a64:      	cmp	x21, #0x20
    1a68:      	b.ne	0x1a78 <_stogir.verify.integer-operations-target-structured+0xc28>
    1a6c:      	str	x0, [sp, #0x280]
    1a70:      	mov	x0, #0x1                ; =1
    1a74:      	b	0x106c <_stogir.verify.integer-operations-target-structured+0x21c>
    1a78:      	cmp	x21, #0x2d
    1a7c:      	b.ne	0x1a8c <_stogir.verify.integer-operations-target-structured+0xc3c>
    1a80:      	str	x0, [sp, #0x280]
    1a84:      	mov	x0, #0x1                ; =1
    1a88:      	b	0x1a74 <_stogir.verify.integer-operations-target-structured+0xc24>
    1a8c:      	cmp	x21, #0x36
    1a90:      	b.ne	0x1aa0 <_stogir.verify.integer-operations-target-structured+0xc50>
    1a94:      	str	x0, [sp, #0x280]
    1a98:      	mov	x0, #0x1                ; =1
    1a9c:      	b	0x1a88 <_stogir.verify.integer-operations-target-structured+0xc38>
    1aa0:      	cmp	x21, #0x37
    1aa4:      	b.ne	0x1ab4 <_stogir.verify.integer-operations-target-structured+0xc64>
    1aa8:      	str	x0, [sp, #0x280]
    1aac:      	mov	x0, #0x1                ; =1
    1ab0:      	b	0x1a9c <_stogir.verify.integer-operations-target-structured+0xc4c>
    1ab4:      	cmp	x21, #0x38
    1ab8:      	b.ne	0x1ac8 <_stogir.verify.integer-operations-target-structured+0xc78>
    1abc:      	str	x0, [sp, #0x280]
    1ac0:      	mov	x0, #0x1                ; =1
    1ac4:      	b	0x1ab0 <_stogir.verify.integer-operations-target-structured+0xc60>
    1ac8:      	str	x0, [sp, #0x280]
    1acc:      	cmp	x21, #0x39
    1ad0:      	cset	w0, eq
    1ad4:      	ubfx	x0, x0, #0, #8
    1ad8:      	b	0x1ac4 <_stogir.verify.integer-operations-target-structured+0xc74>
    1adc:      	uxtb	w16, w1
    1ae0:      	cmp	w16, wzr
    1ae4:      	b.ne	0x1110 <_stogir.verify.integer-operations-target-structured+0x2c0>
    1ae8:      	str	x0, [sp, #0x318]
    1aec:      	str	x20, [sp, #0x320]
    1af0:      	mov	w20, w1
    1af4:      	ldr	x0, [sp, #0x248]
    1af8:      	ldr	x1, [sp, #0x270]
    1afc:      	b	0x1188 <_stogir.verify.integer-operations-target-structured+0x338>
    1b00:      	add	x0, x19, #0x1
    1b04:      	lsr	w0, w0, #0
    1b08:      	sxtw	x0, w0
    1b0c:      	ldr	x1, [sp, #0x248]
    1b10:      	ldr	x2, [sp, #0x270]
    1b14:      	b	0x117c <_stogir.verify.integer-operations-target-structured+0x32c>
    1b18:      	mov	x2, x1
    1b1c:      	mov	x1, x0
    1b20:      	mov	x0, #0x1                ; =1
    1b24:      	b	0x11a8 <_stogir.verify.integer-operations-target-structured+0x358>
    1b28:      	mov	x2, x1
    1b2c:      	mov	x1, x0
    1b30:      	movz	x0, #0x0, lsl #48
    1b34:      	b	0x11a8 <_stogir.verify.integer-operations-target-structured+0x358>
    1b38:      	add	x0, x19, #0x1
    1b3c:      	lsr	w0, w0, #0
    1b40:      	sxtw	x0, w0
    1b44:      	ldr	x1, [sp, #0x328]
    1b48:      	ldr	x2, [sp, #0x330]
    1b4c:      	b	0x1214 <_stogir.verify.integer-operations-target-structured+0x3c4>
    1b50:      	brk	#0
    1b54:      	b	0x1b50 <_stogir.verify.integer-operations-target-structured+0xd00>
    1b58:      	ldr	x0, [sp, #0x328]
    1b5c:      	ldr	x1, [sp, #0x330]
    1b60:      	b	0x1220 <_stogir.verify.integer-operations-target-structured+0x3d0>
    1b64:      	cmp	x21, #0x1e
    1b68:      	cset	w2, eq
    1b6c:      	ubfx	x2, x2, #0, #8
    1b70:      	fmov	d31, x0
    1b74:      	mov	x0, x2
    1b78:      	mov	x2, x1
    1b7c:      	fmov	x1, d31
    1b80:      	b	0x1234 <_stogir.verify.integer-operations-target-structured+0x3e4>
    1b84:      	mov	x0, #0x1                ; =1
    1b88:      	b	0x1254 <_stogir.verify.integer-operations-target-structured+0x404>
    1b8c:      	movz	x0, #0x0, lsl #48
    1b90:      	b	0x1254 <_stogir.verify.integer-operations-target-structured+0x404>
    1b94:      	add	x16, sp, #0x70
    1b98:      	ldr	x0, [x16, #0x8]
    1b9c:      	add	x16, sp, #0x20
    1ba0:      	ldr	w1, [x16, #0xc]
    1ba4:      	sxtw	x1, w1
    1ba8:      	cmp	x1, #0x0
    1bac:      	b.ge	0x1bd0 <_stogir.verify.integer-operations-target-structured+0xd80>
    1bb0:      	ldr	x1, [sp, #0x338]
    1bb4:      	ldr	x2, [sp, #0x340]
    1bb8:      	mov	x0, #0x1                ; =1
    1bbc:      	cmp	x0, #0x0
    1bc0:      	b.eq	0x1c3c <_stogir.verify.integer-operations-target-structured+0xdec>
    1bc4:      	ldr	x0, [sp, #0x250]
    1bc8:      	mov	x1, #0x2d               ; =45
    1bcc:      	b	0x12bc <_stogir.verify.integer-operations-target-structured+0x46c>
    1bd0:      	uxtb	w0, w0
    1bd4:      	cmp	x0, #0x83
    1bd8:      	b.ge	0x1c2c <_stogir.verify.integer-operations-target-structured+0xddc>
    1bdc:      	add	x1, x0, x23
    1be0:      	ldrb	w1, [x1]
    1be4:      	uxtb	w1, w1
    1be8:      	and	x1, x1, #0x2
    1bec:      	uxtb	w1, w1
    1bf0:      	cmp	x1, #0x0
    1bf4:      	cset	w1, eq
    1bf8:      	uxtb	w16, w1
    1bfc:      	cmp	w16, wzr
    1c00:      	cset	x1, eq
    1c04:      	cmp	x1, #0x0
    1c08:      	b.ne	0x1c34 <_stogir.verify.integer-operations-target-structured+0xde4>
    1c0c:      	cmp	x0, #0x65
    1c10:      	b.eq	0x1c34 <_stogir.verify.integer-operations-target-structured+0xde4>
    1c14:      	cmp	x0, #0x66
    1c18:      	b.eq	0x1c34 <_stogir.verify.integer-operations-target-structured+0xde4>
    1c1c:      	mov	x0, #0x1                ; =1
    1c20:      	ldr	x1, [sp, #0x338]
    1c24:      	ldr	x2, [sp, #0x340]
    1c28:      	b	0x1bbc <_stogir.verify.integer-operations-target-structured+0xd6c>
    1c2c:      	movz	x1, #0x0, lsl #48
    1c30:      	b	0x1be4 <_stogir.verify.integer-operations-target-structured+0xd94>
    1c34:      	movz	x0, #0x0, lsl #48
    1c38:      	b	0x1c20 <_stogir.verify.integer-operations-target-structured+0xdd0>
    1c3c:      	mov	x0, x1
    1c40:      	mov	x1, x2
    1c44:      	b	0x1bcc <_stogir.verify.integer-operations-target-structured+0xd7c>
    1c48:      	brk	#0
    1c4c:      	b	0x1c48 <_stogir.verify.integer-operations-target-structured+0xdf8>
    1c50:      	ldr	x0, [sp, #0x338]
    1c54:      	ldr	x1, [sp, #0x340]
    1c58:      	b	0x12bc <_stogir.verify.integer-operations-target-structured+0x46c>
    1c5c:      	mov	x2, x1
    1c60:      	mov	x1, x0
    1c64:      	movz	x0, #0x0, lsl #48
    1c68:      	b	0x12e0 <_stogir.verify.integer-operations-target-structured+0x490>
    1c6c:      	ubfx	x0, x3, #0, #8
    1c70:      	b	0x12f4 <_stogir.verify.integer-operations-target-structured+0x4a4>
    1c74:      	add	x8, sp, #0xc0
    1c78:      	ldr	x0, [sp, #0x280]
    1c7c:      	ldr	w1, [sp, #0x310]
    1c80:      	bl	0x1c80 <_stogir.verify.integer-operations-target-structured+0xe30>
		0000000000001c80:  ARM64_RELOC_BRANCH26	_stogir.checked.validate
    1c84:      	add	x16, sp, #0xc0
    1c88:      	ldr	x0, [x16]
    1c8c:      	add	x16, sp, #0xc0
    1c90:      	ldr	x1, [x16, #0x8]
    1c94:      	add	x16, sp, #0xc0
    1c98:      	ldr	x2, [x16, #0x10]
    1c9c:      	mov	x3, x1
    1ca0:      	ldr	x1, [sp, #0x350]
    1ca4:      	mov	x4, x2
    1ca8:      	mov	x2, x0
    1cac:      	ldr	x0, [sp, #0x348]
    1cb0:      	b	0x134c <_stogir.verify.integer-operations-target-structured+0x4fc>
    1cb4:      	add	x2, x19, #0x1
    1cb8:      	lsr	w2, w2, #0
    1cbc:      	sxtw	x2, w2
    1cc0:      	fmov	d31, x0
    1cc4:      	mov	x0, x2
    1cc8:      	mov	x2, x1
    1ccc:      	fmov	x1, d31
    1cd0:      	b	0x1388 <_stogir.verify.integer-operations-target-structured+0x538>
    1cd4:      	brk	#0
    1cd8:      	b	0x1cd4 <_stogir.verify.integer-operations-target-structured+0xe84>
    1cdc:      	ldr	x0, [sp, #0x348]
    1ce0:      	ldr	x1, [sp, #0x350]
    1ce4:      	b	0x1394 <_stogir.verify.integer-operations-target-structured+0x544>
    1ce8:      	mov	x2, x1
    1cec:      	mov	x1, x0
    1cf0:      	movz	x0, #0x0, lsl #48
    1cf4:      	b	0x13b8 <_stogir.verify.integer-operations-target-structured+0x568>
    1cf8:      	add	x0, x19, #0x1
    1cfc:      	lsr	w0, w0, #0
    1d00:      	sxtw	x0, w0
    1d04:      	ldr	x1, [sp, #0x358]
    1d08:      	ldr	x2, [sp, #0x360]
    1d0c:      	b	0x1424 <_stogir.verify.integer-operations-target-structured+0x5d4>
    1d10:      	brk	#0
    1d14:      	b	0x1d10 <_stogir.verify.integer-operations-target-structured+0xec0>
    1d18:      	ldr	x0, [sp, #0x358]
    1d1c:      	ldr	x1, [sp, #0x360]
    1d20:      	b	0x1430 <_stogir.verify.integer-operations-target-structured+0x5e0>
    1d24:      	cmp	x21, #0x79
    1d28:      	cset	w2, eq
    1d2c:      	ubfx	x2, x2, #0, #8
    1d30:      	fmov	d31, x0
    1d34:      	mov	x0, x2
    1d38:      	mov	x2, x1
    1d3c:      	fmov	x1, d31
    1d40:      	b	0x1444 <_stogir.verify.integer-operations-target-structured+0x5f4>
    1d44:      	add	x0, x19, #0x1
    1d48:      	lsr	w0, w0, #0
    1d4c:      	sxtw	x0, w0
    1d50:      	ldr	x1, [sp, #0x368]
    1d54:      	ldr	x2, [sp, #0x370]
    1d58:      	b	0x14b0 <_stogir.verify.integer-operations-target-structured+0x660>
    1d5c:      	brk	#0
    1d60:      	b	0x1d5c <_stogir.verify.integer-operations-target-structured+0xf0c>
    1d64:      	ldr	x0, [sp, #0x368]
    1d68:      	ldr	x1, [sp, #0x370]
    1d6c:      	b	0x14bc <_stogir.verify.integer-operations-target-structured+0x66c>
    1d70:      	cmp	x21, #0x6d
    1d74:      	b.lt	0x1d98 <_stogir.verify.integer-operations-target-structured+0xf48>
    1d78:      	cmp	x21, #0x6f
    1d7c:      	cset	w2, le
    1d80:      	ubfx	x2, x2, #0, #8
    1d84:      	fmov	d31, x0
    1d88:      	mov	x0, x2
    1d8c:      	mov	x2, x1
    1d90:      	fmov	x1, d31
    1d94:      	b	0x14d0 <_stogir.verify.integer-operations-target-structured+0x680>
    1d98:      	movz	x2, #0x0, lsl #48
    1d9c:      	b	0x1d84 <_stogir.verify.integer-operations-target-structured+0xf34>
    1da0:      	add	x0, x19, #0x1
    1da4:      	lsr	w0, w0, #0
    1da8:      	sxtw	x0, w0
    1dac:      	ldr	x1, [sp, #0x378]
    1db0:      	ldr	x2, [sp, #0x380]
    1db4:      	b	0x153c <_stogir.verify.integer-operations-target-structured+0x6ec>
    1db8:      	brk	#0
    1dbc:      	b	0x1db8 <_stogir.verify.integer-operations-target-structured+0xf68>
    1dc0:      	ldr	x0, [sp, #0x378]
    1dc4:      	ldr	x1, [sp, #0x380]
    1dc8:      	b	0x1548 <_stogir.verify.integer-operations-target-structured+0x6f8>
    1dcc:      	cmp	x21, #0x51
    1dd0:      	b.ne	0x1dec <_stogir.verify.integer-operations-target-structured+0xf9c>
    1dd4:      	mov	x2, #0x1                ; =1
    1dd8:      	fmov	d31, x0
    1ddc:      	mov	x0, x2
    1de0:      	mov	x2, x1
    1de4:      	fmov	x1, d31
    1de8:      	b	0x155c <_stogir.verify.integer-operations-target-structured+0x70c>
    1dec:      	cmp	x21, #0x52
    1df0:      	b.ne	0x1dfc <_stogir.verify.integer-operations-target-structured+0xfac>
    1df4:      	mov	x2, #0x1                ; =1
    1df8:      	b	0x1dd8 <_stogir.verify.integer-operations-target-structured+0xf88>
    1dfc:      	cmp	x21, #0x53
    1e00:      	b.ne	0x1e0c <_stogir.verify.integer-operations-target-structured+0xfbc>
    1e04:      	mov	x2, #0x1                ; =1
    1e08:      	b	0x1df8 <_stogir.verify.integer-operations-target-structured+0xfa8>
    1e0c:      	cmp	x21, #0x54
    1e10:      	cset	w2, eq
    1e14:      	ubfx	x2, x2, #0, #8
    1e18:      	b	0x1e08 <_stogir.verify.integer-operations-target-structured+0xfb8>
    1e1c:      	add	x0, x19, #0x1
    1e20:      	lsr	w0, w0, #0
    1e24:      	sxtw	x0, w0
    1e28:      	ldr	x1, [sp, #0x388]
    1e2c:      	ldr	x2, [sp, #0x390]
    1e30:      	b	0x15c8 <_stogir.verify.integer-operations-target-structured+0x778>
    1e34:      	brk	#0
    1e38:      	b	0x1e34 <_stogir.verify.integer-operations-target-structured+0xfe4>
    1e3c:      	ldr	x0, [sp, #0x388]
    1e40:      	ldr	x1, [sp, #0x390]
    1e44:      	b	0x15d4 <_stogir.verify.integer-operations-target-structured+0x784>
    1e48:      	cmp	x21, #0x48
    1e4c:      	b.ne	0x1e68 <_stogir.verify.integer-operations-target-structured+0x1018>
    1e50:      	mov	x2, #0x1                ; =1
    1e54:      	fmov	d31, x0
    1e58:      	mov	x0, x2
    1e5c:      	mov	x2, x1
    1e60:      	fmov	x1, d31
    1e64:      	b	0x15e8 <_stogir.verify.integer-operations-target-structured+0x798>
    1e68:      	cmp	x21, #0x55
    1e6c:      	b.lt	0x1e80 <_stogir.verify.integer-operations-target-structured+0x1030>
    1e70:      	cmp	x21, #0x58
    1e74:      	cset	w2, le
    1e78:      	ubfx	x2, x2, #0, #8
    1e7c:      	b	0x1e54 <_stogir.verify.integer-operations-target-structured+0x1004>
    1e80:      	movz	x2, #0x0, lsl #48
    1e84:      	b	0x1e7c <_stogir.verify.integer-operations-target-structured+0x102c>
    1e88:      	add	x0, x19, #0x1
    1e8c:      	lsr	w0, w0, #0
    1e90:      	sxtw	x0, w0
    1e94:      	ldr	x2, [sp, #0x398]
    1e98:      	ldr	x3, [sp, #0x3a0]
    1e9c:      	b	0x1660 <_stogir.verify.integer-operations-target-structured+0x810>
    1ea0:      	brk	#0
    1ea4:      	b	0x1ea0 <_stogir.verify.integer-operations-target-structured+0x1050>
    1ea8:      	ldr	x0, [sp, #0x398]
    1eac:      	ldr	x2, [sp, #0x3a0]
    1eb0:      	b	0x166c <_stogir.verify.integer-operations-target-structured+0x81c>
    1eb4:      	mov	x3, x2
    1eb8:      	mov	x2, x0
    1ebc:      	movz	x0, #0x0, lsl #48
    1ec0:      	b	0x1690 <_stogir.verify.integer-operations-target-structured+0x840>
    1ec4:      	add	x0, x19, #0x1
    1ec8:      	lsr	w0, w0, #0
    1ecc:      	sxtw	x0, w0
    1ed0:      	ldr	x2, [sp, #0x3a8]
    1ed4:      	ldr	x3, [sp, #0x3b0]
    1ed8:      	b	0x170c <_stogir.verify.integer-operations-target-structured+0x8bc>
    1edc:      	brk	#0
    1ee0:      	b	0x1edc <_stogir.verify.integer-operations-target-structured+0x108c>
    1ee4:      	ldr	x0, [sp, #0x3a8]
    1ee8:      	ldr	x2, [sp, #0x3b0]
    1eec:      	b	0x1718 <_stogir.verify.integer-operations-target-structured+0x8c8>
    1ef0:      	add	x0, x19, #0x1
    1ef4:      	lsr	w0, w0, #0
    1ef8:      	sxtw	x0, w0
    1efc:      	ldr	x2, [sp, #0x3b8]
    1f00:      	ldr	x3, [sp, #0x3c0]
    1f04:      	b	0x1790 <_stogir.verify.integer-operations-target-structured+0x940>
    1f08:      	brk	#0
    1f0c:      	b	0x1f08 <_stogir.verify.integer-operations-target-structured+0x10b8>
    1f10:      	ldr	x0, [sp, #0x3b8]
    1f14:      	ldr	x2, [sp, #0x3c0]
    1f18:      	b	0x179c <_stogir.verify.integer-operations-target-structured+0x94c>
    1f1c:      	mov	x3, x2
    1f20:      	mov	x2, x0
    1f24:      	mov	x0, #0x1                ; =1
    1f28:      	b	0x17d8 <_stogir.verify.integer-operations-target-structured+0x988>
    1f2c:      	mov	x0, x2
    1f30:      	mov	x2, x3
    1f34:      	b	0x17e8 <_stogir.verify.integer-operations-target-structured+0x998>
    1f38:      	add	x16, sp, #0x20
    1f3c:      	ldr	w3, [x16, #0x8]
    1f40:      	lsr	w3, w3, #0
    1f44:      	add	x8, sp, #0x1c0
    1f48:      	str	x1, [sp, #0x238]
    1f4c:      	mov	w1, w3
    1f50:      	str	x0, [sp, #0x3c8]
    1f54:      	ldr	x0, [sp, #0x280]
    1f58:      	str	x2, [sp, #0x3d0]
    1f5c:      	bl	0x1f5c <_stogir.verify.integer-operations-target-structured+0x110c>
		0000000000001f5c:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    1f60:      	add	x16, sp, #0x1c0
    1f64:      	ldr	w0, [x16]
    1f68:      	lsr	x16, x0, #0
    1f6c:      	cmp	x16, #0x1
    1f70:      	b.eq	0x1f8c <_stogir.verify.integer-operations-target-structured+0x113c>
    1f74:      	b.lo	0x1f7c <_stogir.verify.integer-operations-target-structured+0x112c>
    1f78:      	b	0x1f90 <_stogir.verify.integer-operations-target-structured+0x1140>
    1f7c:      	cmp	x16, #0x0
    1f80:      	b.eq	0x1f88 <_stogir.verify.integer-operations-target-structured+0x1138>
    1f84:      	b	0x1f90 <_stogir.verify.integer-operations-target-structured+0x1140>
    1f88:      	b	0x1f94 <_stogir.verify.integer-operations-target-structured+0x1144>
    1f8c:      	b	0x1fa0 <_stogir.verify.integer-operations-target-structured+0x1150>
    1f90:      	b	0x1fdc <_stogir.verify.integer-operations-target-structured+0x118c>
    1f94:      	ldr	x0, [sp, #0x290]
    1f98:      	mov	x1, #0x14               ; =20
    1f9c:      	b	0x17f0 <_stogir.verify.integer-operations-target-structured+0x9a0>
    1fa0:      	add	x16, sp, #0x1c0
    1fa4:      	ldr	x0, [x16, #0x8]
    1fa8:      	add	x16, sp, #0x20
    1fac:      	ldr	w1, [x16]
    1fb0:      	lsr	w0, w0, #0
    1fb4:      	ubfx	x1, x1, #8, #8
    1fb8:      	ubfx	x0, x0, #8, #8
    1fbc:      	cmp	x0, x1
    1fc0:      	b.ne	0x1fd0 <_stogir.verify.integer-operations-target-structured+0x1180>
    1fc4:      	ldr	x0, [sp, #0x3c8]
    1fc8:      	ldr	x1, [sp, #0x3d0]
    1fcc:      	b	0x1f9c <_stogir.verify.integer-operations-target-structured+0x114c>
    1fd0:      	ldr	x0, [sp, #0x298]
    1fd4:      	mov	x1, #0x1a               ; =26
    1fd8:      	b	0x1fcc <_stogir.verify.integer-operations-target-structured+0x117c>
    1fdc:      	brk	#0
    1fe0:      	b	0x1fdc <_stogir.verify.integer-operations-target-structured+0x118c>
    1fe4:      	ldr	x0, [sp, #0x3c8]
    1fe8:      	ldr	x1, [sp, #0x3d0]
    1fec:      	b	0x1800 <_stogir.verify.integer-operations-target-structured+0x9b0>
    1ff0:      	add	x0, x19, #0x1
    1ff4:      	lsr	w0, w0, #0
    1ff8:      	sxtw	x0, w0
    1ffc:      	ldr	x2, [sp, #0x3d8]
    2000:      	ldr	x3, [sp, #0x3e0]
    2004:      	b	0x189c <_stogir.verify.integer-operations-target-structured+0xa4c>
    2008:      	brk	#0
    200c:      	b	0x2008 <_stogir.verify.integer-operations-target-structured+0x11b8>
    2010:      	ldr	x0, [sp, #0x3d8]
    2014:      	ldr	x2, [sp, #0x3e0]
    2018:      	b	0x18a8 <_stogir.verify.integer-operations-target-structured+0xa58>
    201c:      	mov	x3, x2
    2020:      	mov	x2, x0
    2024:      	mov	x0, #0x1                ; =1
    2028:      	b	0x18c0 <_stogir.verify.integer-operations-target-structured+0xa70>
    202c:      	mov	x0, #0x1                ; =1
    2030:      	b	0x18d4 <_stogir.verify.integer-operations-target-structured+0xa84>
    2034:      	ldr	x22, [sp, #0x308]
    2038:      	cmp	x22, #0x0
    203c:      	b.eq	0x2048 <_stogir.verify.integer-operations-target-structured+0x11f8>
    2040:      	mov	x0, #0x1                ; =1
    2044:      	b	0x18f0 <_stogir.verify.integer-operations-target-structured+0xaa0>
    2048:      	ldr	x0, [sp, #0x288]
    204c:      	b	0x2044 <_stogir.verify.integer-operations-target-structured+0x11f4>
    2050:      	movz	x0, #0x0, lsl #48
    2054:      	b	0x18f0 <_stogir.verify.integer-operations-target-structured+0xaa0>
    2058:      	movz	x0, #0x0, lsl #48
    205c:      	b	0x18f0 <_stogir.verify.integer-operations-target-structured+0xaa0>
    2060:      	lsr	w1, w1, #0
    2064:      	lsr	w1, w1, #0
    2068:      	ldr	x0, [sp, #0x280]
    206c:      	bl	0x206c <_stogir.verify.integer-operations-target-structured+0x121c>
		000000000000206c:  ARM64_RELOC_BRANCH26	_stogir.graph.borrow-node
    2070:      	cmp	x0, #0x0
    2074:      	b.ne	0x2088 <_stogir.verify.integer-operations-target-structured+0x1238>
    2078:      	str	x23, [sp, #0x260]
    207c:      	ldr	x0, [sp, #0x2b0]
    2080:      	mov	x1, #0x17               ; =23
    2084:      	b	0x1974 <_stogir.verify.integer-operations-target-structured+0xb24>
    2088:      	ldr	w0, [x0]
    208c:      	add	x16, sp, #0x20
    2090:      	ldr	w1, [x16]
    2094:      	ubfx	x0, x0, #8, #8
    2098:      	orr	x2, x0, xzr
    209c:      	ubfx	x1, x1, #8, #8
    20a0:      	cmp	x1, #0x6
    20a4:      	b.ne	0x2210 <_stogir.verify.integer-operations-target-structured+0x13c0>
    20a8:      	cmp	x2, #0x6
    20ac:      	b.ne	0x2200 <_stogir.verify.integer-operations-target-structured+0x13b0>
    20b0:      	cmp	x21, #0x1a
    20b4:      	b.ne	0x21e8 <_stogir.verify.integer-operations-target-structured+0x1398>
    20b8:      	ldr	x3, [sp, #0x3f0]
    20bc:      	ldr	x4, [sp, #0x3f8]
    20c0:      	mov	x1, #0x1                ; =1
    20c4:      	mov	x21, x1
    20c8:      	mov	x1, x3
    20cc:      	mov	x3, x4
    20d0:      	cmp	x2, #0x1
    20d4:      	b.lt	0x2220 <_stogir.verify.integer-operations-target-structured+0x13d0>
    20d8:      	cmp	x2, #0xb
    20dc:      	cset	w4, le
    20e0:      	ubfx	x4, x4, #0, #8
    20e4:      	fmov	d31, x1
    20e8:      	mov	x1, x4
    20ec:      	mov	x4, x3
    20f0:      	fmov	x3, d31
    20f4:      	cmp	x1, #0x0
    20f8:      	b.eq	0x2230 <_stogir.verify.integer-operations-target-structured+0x13e0>
    20fc:      	movz	x1, #0x0, lsl #48
    2100:      	cmp	x1, #0x0
    2104:      	b.eq	0x2238 <_stogir.verify.integer-operations-target-structured+0x13e8>
    2108:      	str	x23, [sp, #0x260]
    210c:      	mov	x23, x2
    2110:      	mov	x1, x3
    2114:      	mov	x2, x4
    2118:      	mov	x0, #0x1                ; =1
    211c:      	cmp	x0, #0x0
    2120:      	b.eq	0x22c4 <_stogir.verify.integer-operations-target-structured+0x1474>
    2124:      	ldr	x0, [sp, #0x2b8]
    2128:      	mov	x1, #0x1c               ; =28
    212c:      	add	x16, sp, #0x20
    2130:      	ldr	w2, [x16]
    2134:      	cmp	x20, #0x0
    2138:      	b.eq	0x22d0 <_stogir.verify.integer-operations-target-structured+0x1480>
    213c:      	mov	x3, x0
    2140:      	mov	x0, #0x1                ; =1
    2144:      	lsr	w0, w0, #0
    2148:      	ubfx	x2, x2, #8, #8
    214c:      	sxtw	x0, w0
    2150:      	cmp	x2, x0
    2154:      	b.ne	0x22dc <_stogir.verify.integer-operations-target-structured+0x148c>
    2158:      	mov	x0, x3
    215c:      	cmp	x20, #0x0
    2160:      	b.eq	0x22e8 <_stogir.verify.integer-operations-target-structured+0x1498>
    2164:      	mov	x20, x0
    2168:      	mov	x0, #0x1                ; =1
    216c:      	cmp	x0, #0x0
    2170:      	b.eq	0x2544 <_stogir.verify.integer-operations-target-structured+0x16f4>
    2174:      	add	x16, sp, #0x220
    2178:      	str	x16, [sp]
    217c:      	ldr	x0, [sp, #0x280]
    2180:      	mov	x22, x1
    2184:      	ldr	w1, [sp, #0x310]
    2188:      	mov	x2, #0x2                ; =2
    218c:      	bl	0x218c <_stogir.verify.integer-operations-target-structured+0x133c>
		000000000000218c:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    2190:      	ldr	x16, [sp]
    2194:      	str	x0, [x16]
    2198:      	str	x1, [x16, #0x8]
    219c:      	add	x16, sp, #0x220
    21a0:      	ldr	x0, [x16]
    21a4:      	add	x16, sp, #0x220
    21a8:      	ldr	x1, [x16, #0x8]
    21ac:      	lsr	w0, w0, #0
    21b0:      	lsr	x16, x0, #0
    21b4:      	cmp	x16, #0x1
    21b8:      	b.eq	0x21d4 <_stogir.verify.integer-operations-target-structured+0x1384>
    21bc:      	b.lo	0x21c4 <_stogir.verify.integer-operations-target-structured+0x1374>
    21c0:      	b	0x21d8 <_stogir.verify.integer-operations-target-structured+0x1388>
    21c4:      	cmp	x16, #0x0
    21c8:      	b.eq	0x21d0 <_stogir.verify.integer-operations-target-structured+0x1380>
    21cc:      	b	0x21d8 <_stogir.verify.integer-operations-target-structured+0x1388>
    21d0:      	b	0x21dc <_stogir.verify.integer-operations-target-structured+0x138c>
    21d4:      	b	0x22f4 <_stogir.verify.integer-operations-target-structured+0x14a4>
    21d8:      	b	0x2398 <_stogir.verify.integer-operations-target-structured+0x1548>
    21dc:      	ldr	x0, [sp, #0x2c8]
    21e0:      	mov	x1, #0x1d               ; =29
    21e4:      	b	0x2084 <_stogir.verify.integer-operations-target-structured+0x1234>
    21e8:      	cmp	x21, #0x1b
    21ec:      	cset	w1, eq
    21f0:      	ubfx	x1, x1, #0, #8
    21f4:      	ldr	x3, [sp, #0x3f0]
    21f8:      	ldr	x4, [sp, #0x3f8]
    21fc:      	b	0x20c4 <_stogir.verify.integer-operations-target-structured+0x1274>
    2200:      	ldr	x3, [sp, #0x3f0]
    2204:      	ldr	x4, [sp, #0x3f8]
    2208:      	movz	x1, #0x0, lsl #48
    220c:      	b	0x20c4 <_stogir.verify.integer-operations-target-structured+0x1274>
    2210:      	ldr	x1, [sp, #0x3f0]
    2214:      	ldr	x3, [sp, #0x3f8]
    2218:      	movz	x21, #0x0, lsl #48
    221c:      	b	0x20d0 <_stogir.verify.integer-operations-target-structured+0x1280>
    2220:      	mov	x4, x3
    2224:      	mov	x3, x1
    2228:      	movz	x1, #0x0, lsl #48
    222c:      	b	0x20f4 <_stogir.verify.integer-operations-target-structured+0x12a4>
    2230:      	mov	x1, #0x1                ; =1
    2234:      	b	0x2100 <_stogir.verify.integer-operations-target-structured+0x12b0>
    2238:      	ldr	w1, [sp, #0x2e0]
    223c:      	lsr	w1, w1, #0
    2240:      	lsr	w0, w0, #0
    2244:      	ldr	x5, [sp, #0x288]
    2248:      	cmp	x5, #0x0
    224c:      	b.eq	0x254c <_stogir.verify.integer-operations-target-structured+0x16fc>
    2250:      	str	x3, [sp, #0x400]
    2254:      	str	x4, [sp, #0x408]
    2258:      	str	w1, [sp, #0x410]
    225c:      	str	w0, [sp, #0x418]
    2260:      	str	x23, [sp, #0x260]
    2264:      	mov	x23, x2
    2268:      	fmov	s31, w0
    226c:      	mov	w0, w1
    2270:      	fmov	w1, s31
    2274:      	bl	0x2274 <_stogir.verify.integer-operations-target-structured+0x1424>
		0000000000002274:  ARM64_RELOC_BRANCH26	_stogir.integer-unary.valid-type?
    2278:      	cmp	x0, #0x0
    227c:      	b.ne	0x2290 <_stogir.verify.integer-operations-target-structured+0x1440>
    2280:      	mov	x0, #0x1                ; =1
    2284:      	ldr	x1, [sp, #0x400]
    2288:      	ldr	x2, [sp, #0x408]
    228c:      	b	0x211c <_stogir.verify.integer-operations-target-structured+0x12cc>
    2290:      	cmp	x22, #0x0
    2294:      	b.eq	0x22bc <_stogir.verify.integer-operations-target-structured+0x146c>
    2298:      	ldr	w0, [sp, #0x410]
    229c:      	ldr	w1, [sp, #0x418]
    22a0:      	bl	0x22a0 <_stogir.verify.integer-operations-target-structured+0x1450>
		00000000000022a0:  ARM64_RELOC_BRANCH26	_stogir.integer-binary.valid-type?
    22a4:      	cmp	x0, #0x0
    22a8:      	cset	w0, ne
    22ac:      	uxtb	w16, w0
    22b0:      	cmp	w16, wzr
    22b4:      	cset	x0, eq
    22b8:      	b	0x2284 <_stogir.verify.integer-operations-target-structured+0x1434>
    22bc:      	movz	x0, #0x0, lsl #48
    22c0:      	b	0x22b8 <_stogir.verify.integer-operations-target-structured+0x1468>
    22c4:      	mov	x0, x1
    22c8:      	mov	x1, x2
    22cc:      	b	0x212c <_stogir.verify.integer-operations-target-structured+0x12dc>
    22d0:      	mov	x3, x0
    22d4:      	mov	x0, x23
    22d8:      	b	0x2144 <_stogir.verify.integer-operations-target-structured+0x12f4>
    22dc:      	ldr	x0, [sp, #0x2c0]
    22e0:      	mov	x1, #0x26               ; =38
    22e4:      	b	0x215c <_stogir.verify.integer-operations-target-structured+0x130c>
    22e8:      	mov	x20, x0
    22ec:      	mov	x0, x22
    22f0:      	b	0x216c <_stogir.verify.integer-operations-target-structured+0x131c>
    22f4:      	lsr	w1, w1, #0
    22f8:      	lsr	w1, w1, #0
    22fc:      	ldr	x0, [sp, #0x280]
    2300:      	bl	0x2300 <_stogir.verify.integer-operations-target-structured+0x14b0>
		0000000000002300:  ARM64_RELOC_BRANCH26	_stogir.graph.borrow-node
    2304:      	cmp	x0, #0x0
    2308:      	b.ne	0x2318 <_stogir.verify.integer-operations-target-structured+0x14c8>
    230c:      	ldr	x0, [sp, #0x2c8]
    2310:      	mov	x1, #0x1d               ; =29
    2314:      	b	0x21e4 <_stogir.verify.integer-operations-target-structured+0x1394>
    2318:      	ldr	w0, [x0]
    231c:      	ubfx	x0, x0, #8, #8
    2320:      	cmp	x23, x0
    2324:      	b.ne	0x2350 <_stogir.verify.integer-operations-target-structured+0x1500>
    2328:      	mov	x1, x20
    232c:      	mov	x0, #0x1                ; =1
    2330:      	cmp	x0, #0x0
    2334:      	b.eq	0x2384 <_stogir.verify.integer-operations-target-structured+0x1534>
    2338:      	movz	x0, #0x0, lsl #48
    233c:      	cmp	x0, #0x0
    2340:      	b.eq	0x238c <_stogir.verify.integer-operations-target-structured+0x153c>
    2344:      	ldr	x0, [sp, #0x2d0]
    2348:      	mov	x1, #0x1d               ; =29
    234c:      	b	0x2314 <_stogir.verify.integer-operations-target-structured+0x14c4>
    2350:      	cmp	x21, #0x0
    2354:      	b.eq	0x237c <_stogir.verify.integer-operations-target-structured+0x152c>
    2358:      	cmp	x0, #0x5
    235c:      	b.ne	0x236c <_stogir.verify.integer-operations-target-structured+0x151c>
    2360:      	mov	x0, #0x1                ; =1
    2364:      	mov	x1, x20
    2368:      	b	0x2330 <_stogir.verify.integer-operations-target-structured+0x14e0>
    236c:      	cmp	x0, #0xb
    2370:      	cset	w0, eq
    2374:      	ubfx	x0, x0, #0, #8
    2378:      	b	0x2364 <_stogir.verify.integer-operations-target-structured+0x1514>
    237c:      	movz	x0, #0x0, lsl #48
    2380:      	b	0x2364 <_stogir.verify.integer-operations-target-structured+0x1514>
    2384:      	mov	x0, #0x1                ; =1
    2388:      	b	0x233c <_stogir.verify.integer-operations-target-structured+0x14ec>
    238c:      	mov	x0, x1
    2390:      	mov	x1, x22
    2394:      	b	0x234c <_stogir.verify.integer-operations-target-structured+0x14fc>
    2398:      	brk	#0
    239c:      	b	0x2398 <_stogir.verify.integer-operations-target-structured+0x1548>
    23a0:      	mov	x0, x20
    23a4:      	mov	x1, x22
    23a8:      	b	0x21e4 <_stogir.verify.integer-operations-target-structured+0x1394>
    23ac:      	brk	#0
    23b0:      	b	0x23ac <_stogir.verify.integer-operations-target-structured+0x155c>
    23b4:      	mov	x0, x19
    23b8:      	ldr	x1, [sp, #0x3f0]
    23bc:      	ldr	x2, [sp, #0x3f8]
    23c0:      	b	0x1990 <_stogir.verify.integer-operations-target-structured+0xb40>
    23c4:      	brk	#0
    23c8:      	b	0x23c4 <_stogir.verify.integer-operations-target-structured+0x1574>
    23cc:      	uxtb	w16, w1
    23d0:      	cmp	w16, wzr
    23d4:      	b.eq	0x2430 <_stogir.verify.integer-operations-target-structured+0x15e0>
    23d8:      	and	x0, x19, #0xffffffff
    23dc:      	mov	x1, x0
    23e0:      	movz	x0, #0x0, lsl #48
    23e4:      	movz	x2, #0x0, lsl #48
    23e8:      	ldr	x3, [sp, #0x2d8]
    23ec:      	str	x0, [x3]
    23f0:      	str	x1, [x3, #0x8]
    23f4:      	str	x2, [x3, #0x10]
    23f8:      	ldr	x19, [sp, #0x420]
    23fc:      	ldr	x20, [sp, #0x428]
    2400:      	ldr	x21, [sp, #0x430]
    2404:      	ldr	x22, [sp, #0x438]
    2408:      	ldr	x23, [sp, #0x440]
    240c:      	ldr	x24, [sp, #0x448]
    2410:      	ldr	x25, [sp, #0x450]
    2414:      	ldr	x26, [sp, #0x458]
    2418:      	ldr	x27, [sp, #0x460]
    241c:      	ldr	x28, [sp, #0x468]
    2420:      	ldr	x29, [sp, #0x10]
    2424:      	ldr	x30, [sp, #0x18]
    2428:      	add	sp, sp, #0x470
    242c:      	ret
    2430:      	ldr	x1, [sp, #0x248]
    2434:      	ldr	x2, [sp, #0x270]
    2438:      	mov	x0, #0x1                ; =1
    243c:      	b	0x23e8 <_stogir.verify.integer-operations-target-structured+0x1598>
    2440:      	str	x8, [sp, #0x2d8]
    2444:      	str	x20, [sp, #0x270]
    2448:      	b	0x23cc <_stogir.verify.integer-operations-target-structured+0x157c>
    244c:      	str	x8, [sp, #0x2d8]
    2450:      	str	x20, [sp, #0x270]
    2454:      	b	0x23cc <_stogir.verify.integer-operations-target-structured+0x157c>
    2458:      	str	x1, [sp, #0x328]
    245c:      	str	x2, [sp, #0x330]
    2460:      	b	0x1b58 <_stogir.verify.integer-operations-target-structured+0xd08>
    2464:      	str	x1, [sp, #0x338]
    2468:      	str	x2, [sp, #0x340]
    246c:      	b	0x1c50 <_stogir.verify.integer-operations-target-structured+0xe00>
    2470:      	str	x1, [sp, #0x348]
    2474:      	str	x2, [sp, #0x350]
    2478:      	b	0x1cdc <_stogir.verify.integer-operations-target-structured+0xe8c>
    247c:      	str	x1, [sp, #0x348]
    2480:      	str	x2, [sp, #0x350]
    2484:      	b	0x1c74 <_stogir.verify.integer-operations-target-structured+0xe24>
    2488:      	str	x1, [sp, #0x358]
    248c:      	str	x2, [sp, #0x360]
    2490:      	b	0x1d18 <_stogir.verify.integer-operations-target-structured+0xec8>
    2494:      	str	x1, [sp, #0x368]
    2498:      	str	x2, [sp, #0x370]
    249c:      	b	0x1d64 <_stogir.verify.integer-operations-target-structured+0xf14>
    24a0:      	str	x1, [sp, #0x378]
    24a4:      	str	x2, [sp, #0x380]
    24a8:      	b	0x1dc0 <_stogir.verify.integer-operations-target-structured+0xf70>
    24ac:      	str	x1, [sp, #0x388]
    24b0:      	str	x2, [sp, #0x390]
    24b4:      	b	0x1e3c <_stogir.verify.integer-operations-target-structured+0xfec>
    24b8:      	str	x1, [sp, #0x398]
    24bc:      	ldr	x1, [sp, #0x320]
    24c0:      	str	x2, [sp, #0x3a0]
    24c4:      	b	0x1ea8 <_stogir.verify.integer-operations-target-structured+0x1058>
    24c8:      	str	x1, [sp, #0x320]
    24cc:      	ldr	x1, [sp, #0x2e8]
    24d0:      	str	x2, [sp, #0x3a8]
    24d4:      	str	x3, [sp, #0x3b0]
    24d8:      	b	0x1ee4 <_stogir.verify.integer-operations-target-structured+0x1094>
    24dc:      	str	x1, [sp, #0x2e8]
    24e0:      	ldr	x1, [sp, #0x238]
    24e4:      	str	x0, [sp, #0x3b8]
    24e8:      	str	x2, [sp, #0x3c0]
    24ec:      	b	0x1f10 <_stogir.verify.integer-operations-target-structured+0x10c0>
    24f0:      	str	x1, [sp, #0x238]
    24f4:      	str	x0, [sp, #0x3c8]
    24f8:      	str	x2, [sp, #0x3d0]
    24fc:      	b	0x1fe4 <_stogir.verify.integer-operations-target-structured+0x1194>
    2500:      	str	x22, [sp, #0x3e8]
    2504:      	mov	x22, x2
    2508:      	str	x0, [sp, #0x3d8]
    250c:      	str	x1, [sp, #0x3e0]
    2510:      	ldr	x1, [sp, #0x258]
    2514:      	b	0x2010 <_stogir.verify.integer-operations-target-structured+0x11c0>
    2518:      	ldr	x20, [sp, #0x300]
    251c:      	ldr	x22, [sp, #0x308]
    2520:      	b	0x2058 <_stogir.verify.integer-operations-target-structured+0x1208>
    2524:      	ldr	x20, [sp, #0x300]
    2528:      	ldr	x22, [sp, #0x308]
    252c:      	b	0x2050 <_stogir.verify.integer-operations-target-structured+0x1200>
    2530:      	str	x1, [sp, #0x258]
    2534:      	str	x23, [sp, #0x260]
    2538:      	str	x2, [sp, #0x3f0]
    253c:      	str	x3, [sp, #0x3f8]
    2540:      	b	0x23b4 <_stogir.verify.integer-operations-target-structured+0x1564>
    2544:      	mov	x22, x1
    2548:      	b	0x23a0 <_stogir.verify.integer-operations-target-structured+0x1550>
    254c:      	str	w1, [sp, #0x410]
    2550:      	str	w0, [sp, #0x418]
    2554:      	str	x23, [sp, #0x260]
    2558:      	mov	x23, x2
    255c:      	str	x3, [sp, #0x400]
    2560:      	str	x4, [sp, #0x408]
    2564:      	b	0x2290 <_stogir.verify.integer-operations-target-structured+0x1440>

0000000000002568 <_coil.core.Len$coil.arraylist.ArrayList$len__i32>:
    2568:      	ldr	x0, [x0, #0x8]
    256c:      	ret

0000000000002570 <_coil.core.Eq$slice<u8>$=>:
    2570:      	sub	sp, sp, #0x10
    2574:      	str	x29, [sp]
    2578:      	str	x30, [sp, #0x8]
    257c:      	mov	x29, sp
    2580:      	cmp	x1, x3
    2584:      	b.ne	0x25c4 <_coil.core.Eq$slice<u8>$=+0x54>
    2588:      	cmp	x1, #0x0
    258c:      	b.ne	0x2598 <_coil.core.Eq$slice<u8>$=+0x28>
    2590:      	mov	x0, #0x1                ; =1
    2594:      	b	0x25c0 <_coil.core.Eq$slice<u8>$=+0x50>
    2598:      	lsr	x1, x1, #0
    259c:      	fmov	d31, x1
    25a0:      	mov	x1, x2
    25a4:      	fmov	x2, d31
    25a8:      	bl	0x25a8 <_coil.core.Eq$slice<u8>$=+0x38>
		00000000000025a8:  ARM64_RELOC_BRANCH26	_memcmp
    25ac:      	lsr	w0, w0, #0
    25b0:      	sxtw	x0, w0
    25b4:      	cmp	x0, #0x0
    25b8:      	cset	w0, eq
    25bc:      	ubfx	x0, x0, #0, #8
    25c0:      	b	0x25c8 <_coil.core.Eq$slice<u8>$=+0x58>
    25c4:      	movz	x0, #0x0, lsl #48
    25c8:      	ldr	x29, [sp]
    25cc:      	ldr	x30, [sp, #0x8]
    25d0:      	add	sp, sp, #0x10
    25d4:      	ret

00000000000025d8 <_stogir.node.opcode>:
    25d8:      	ldr	w0, [x0]
    25dc:      	uxtb	w0, w0
    25e0:      	ret

00000000000025e4 <_stogir.opcode.valid?>:
    25e4:      	sxtw	x0, w0
    25e8:      	cmp	x0, #0x0
    25ec:      	b.lt	0x2600 <_stogir.opcode.valid?+0x1c>
    25f0:      	cmp	x0, #0x83
    25f4:      	cset	w0, lt
    25f8:      	ubfx	x0, x0, #0, #8
    25fc:      	b	0x2604 <_stogir.opcode.valid?+0x20>
    2600:      	movz	x0, #0x0, lsl #48
    2604:      	ret

0000000000002608 <_stogir.node.type-id>:
    2608:      	ldr	w0, [x0]
    260c:      	ubfx	x0, x0, #8, #8
    2610:      	ret

0000000000002614 <_stogir.types.valid?>:
    2614:      	sxtw	x0, w0
    2618:      	cmp	x0, #0x0
    261c:      	b.lt	0x2630 <_stogir.types.valid?+0x1c>
    2620:      	cmp	x0, #0xd
    2624:      	b.gt	0x2630 <_stogir.types.valid?+0x1c>
    2628:      	mov	x0, #0x1                ; =1
    262c:      	ret
    2630:      	cmp	x0, #0xf
    2634:      	b.le	0x266c <_stogir.types.valid?+0x58>
    2638:      	cmp	x0, #0x80
    263c:      	b.ge	0x2664 <_stogir.types.valid?+0x50>
    2640:      	and	x0, x0, #0xf
    2644:      	lsr	w0, w0, #0
    2648:      	sxtw	x0, w0
    264c:      	cmp	x0, #0x1
    2650:      	b.lt	0x2674 <_stogir.types.valid?+0x60>
    2654:      	cmp	x0, #0xd
    2658:      	cset	w0, le
    265c:      	ubfx	x0, x0, #0, #8
    2660:      	b	0x2678 <_stogir.types.valid?+0x64>
    2664:      	movz	x0, #0x0, lsl #48
    2668:      	b	0x2670 <_stogir.types.valid?+0x5c>
    266c:      	movz	x0, #0x0, lsl #48
    2670:      	ret
    2674:      	movz	x0, #0x0, lsl #48
    2678:      	b	0x2668 <_stogir.types.valid?+0x54>

000000000000267c <_stogir.opcode.operand-slots>:
    267c:      	sxtw	x0, w0
    2680:      	cmp	x0, #0x0
    2684:      	b.lt	0x26b0 <_stogir.opcode.operand-slots+0x34>
    2688:      	cmp	x0, #0x83
    268c:      	b.ge	0x26b0 <_stogir.opcode.operand-slots+0x34>
    2690:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x11b0>
		0000000000002690:  ARM64_RELOC_PAGE21	l_stogir.334
    2694:      	ldr	x16, [x16]
		0000000000002694:  ARM64_RELOC_PAGEOFF12	l_stogir.334
    2698:      	orr	x1, x16, xzr
    269c:      	lsr	x0, x0, #0
    26a0:      	add	x0, x0, x1
    26a4:      	ldrsb	w0, [x0]
    26a8:      	sxtb	x0, w0
    26ac:      	b	0x26b4 <_stogir.opcode.operand-slots+0x38>
    26b0:      	mov	x0, #-0x2               ; =-2
    26b4:      	ret

00000000000026b8 <_stogir.opcode.input-count>:
    26b8:      	sxtw	x0, w0
    26bc:      	cmp	x0, #0x0
    26c0:      	b.lt	0x26ec <_stogir.opcode.input-count+0x34>
    26c4:      	cmp	x0, #0x83
    26c8:      	b.ge	0x26ec <_stogir.opcode.input-count+0x34>
    26cc:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x11b0>
		00000000000026cc:  ARM64_RELOC_PAGE21	l_stogir.335
    26d0:      	ldr	x16, [x16]
		00000000000026d0:  ARM64_RELOC_PAGEOFF12	l_stogir.335
    26d4:      	orr	x1, x16, xzr
    26d8:      	lsr	x0, x0, #0
    26dc:      	add	x0, x0, x1
    26e0:      	ldrsb	w0, [x0]
    26e4:      	sxtb	x0, w0
    26e8:      	b	0x26f0 <_stogir.opcode.input-count+0x38>
    26ec:      	mov	x0, #-0x2               ; =-2
    26f0:      	ret

00000000000026f4 <_stogir.node.auxiliary>:
    26f4:      	ldr	w0, [x0]
    26f8:      	ubfx	x0, x0, #16, #16
    26fc:      	ret

0000000000002700 <_stogir.opcode.operand-code>:
    2700:      	sxtw	x0, w0
    2704:      	cmp	x0, #0x0
    2708:      	b.lt	0x2748 <_stogir.opcode.operand-code+0x48>
    270c:      	cmp	x0, #0x83
    2710:      	b.ge	0x2748 <_stogir.opcode.operand-code+0x48>
    2714:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x11b0>
		0000000000002714:  ARM64_RELOC_PAGE21	l_stogir.336
    2718:      	ldr	x16, [x16]
		0000000000002718:  ARM64_RELOC_PAGEOFF12	l_stogir.336
    271c:      	orr	x2, x16, xzr
    2720:      	lsl	x0, x0, #2
    2724:      	sxtw	x1, w1
    2728:      	add	x0, x0, x2
    272c:      	ldr	w0, [x0]
    2730:      	cmp	x1, #0x0
    2734:      	b.le	0x277c <_stogir.opcode.operand-code+0x7c>
    2738:      	cmp	x1, #0x4
    273c:      	b.le	0x2750 <_stogir.opcode.operand-code+0x50>
    2740:      	mov	x1, #0x4                ; =4
    2744:      	b	0x275c <_stogir.opcode.operand-code+0x5c>
    2748:      	movz	x0, #0x0, lsl #48
    274c:      	ret
    2750:      	sub	x1, x1, #0x1
    2754:      	lsr	w1, w1, #0
    2758:      	sxtw	x1, w1
    275c:      	lsl	x1, x1, #2
    2760:      	lsr	w1, w1, #0
    2764:      	ubfx	x1, x1, #0, #32
    2768:      	lsr	x0, x0, x1
    276c:      	lsr	w0, w0, #0
    2770:      	and	x0, x0, #0xf
    2774:      	lsr	w0, w0, #0
    2778:      	b	0x2780 <_stogir.opcode.operand-code+0x80>
    277c:      	movz	x0, #0x0, lsl #48
    2780:      	ret

0000000000002784 <_stogir.graph.operand>:
    2784:      	sub	sp, sp, #0x10
    2788:      	mov	x3, sp
    278c:      	sxtw	x1, w1
    2790:      	cmp	x1, #0x0
    2794:      	b.le	0x27d8 <_stogir.graph.operand+0x54>
    2798:      	lsl	x4, x1, #2
    279c:      	ldr	x5, [x0, #0x8]
    27a0:      	cmp	x1, x5
    27a4:      	b.ge	0x280c <_stogir.graph.operand+0x88>
    27a8:      	add	x5, x0, #0x78
    27ac:      	ldr	x5, [x5, #0x8]
    27b0:      	cmp	x1, x5
    27b4:      	b.ge	0x2804 <_stogir.graph.operand+0x80>
    27b8:      	ldr	x5, [x0, #0x78]
    27bc:      	add	x5, x4, x5
    27c0:      	ldr	w5, [x5]
    27c4:      	sxtw	x5, w5
    27c8:      	cmp	x5, #0x0
    27cc:      	cset	w5, ge
    27d0:      	ubfx	x5, x5, #0, #8
    27d4:      	b	0x2808 <_stogir.graph.operand+0x84>
    27d8:      	movz	x0, #0x0, lsl #48
    27dc:      	movz	x1, #0x0, lsl #48
    27e0:      	str	x0, [x3]
    27e4:      	str	x1, [x3, #0x8]
    27e8:      	ldr	x0, [sp]
    27ec:      	ldr	x1, [sp, #0x8]
    27f0:      	add	sp, sp, #0x10
    27f4:      	ret
    27f8:      	movz	x0, #0x0, lsl #48
    27fc:      	movz	x1, #0x0, lsl #48
    2800:      	b	0x27e0 <_stogir.graph.operand+0x5c>
    2804:      	movz	x5, #0x0, lsl #48
    2808:      	b	0x2810 <_stogir.graph.operand+0x8c>
    280c:      	movz	x5, #0x0, lsl #48
    2810:      	cmp	x5, #0x0
    2814:      	b.eq	0x27d8 <_stogir.graph.operand+0x54>
    2818:      	sxtw	x2, w2
    281c:      	cmp	x2, #0x1
    2820:      	b.lt	0x27f8 <_stogir.graph.operand+0x74>
    2824:      	ldr	x5, [x0, #0x78]
    2828:      	add	x4, x4, x5
    282c:      	ldr	w4, [x4]
    2830:      	sxtw	x4, w4
    2834:      	cmp	x2, x4
    2838:      	b.gt	0x27f8 <_stogir.graph.operand+0x74>
    283c:      	asr	x16, x2, #63
    2840:      	lsr	x16, x16, #62
    2844:      	add	x4, x2, x16
    2848:      	asr	x4, x4, #2
    284c:      	asr	x16, x2, #63
    2850:      	lsr	x16, x16, #62
    2854:      	add	x2, x2, x16
    2858:      	and	x2, x2, #0x3
    285c:      	sub	x2, x2, x16
    2860:      	ldr	x0, [x0]
    2864:      	add	x1, x4, x1
    2868:      	lsl	x2, x2, #2
    286c:      	lsl	x1, x1, #4
    2870:      	add	x0, x1, x0
    2874:      	add	x0, x2, x0
    2878:      	ldr	w0, [x0]
    287c:      	sxtw	x0, w0
    2880:      	and	x0, x0, #0xffffffff
    2884:      	mov	x1, x0
    2888:      	mov	x0, #0x1                ; =1
    288c:      	b	0x2800 <_stogir.graph.operand+0x7c>

0000000000002890 <_stogir.graph.borrow-node>:
    2890:      	sxtw	x1, w1
    2894:      	cmp	x1, #0x0
    2898:      	cset	w2, gt
    289c:      	movz	x16, #0x0, lsl #48
    28a0:      	sub	x3, x16, x1
    28a4:      	sub	x4, x3, #0x1
    28a8:      	uxtb	w16, w2
    28ac:      	cmp	w16, wzr
    28b0:      	b.eq	0x28f4 <_stogir.graph.borrow-node+0x64>
    28b4:      	ldr	x3, [x0, #0x8]
    28b8:      	cmp	x1, x3
    28bc:      	b.ge	0x2948 <_stogir.graph.borrow-node+0xb8>
    28c0:      	add	x3, x0, #0x78
    28c4:      	ldr	x3, [x3, #0x8]
    28c8:      	cmp	x1, x3
    28cc:      	b.ge	0x2990 <_stogir.graph.borrow-node+0x100>
    28d0:      	lsl	x3, x1, #2
    28d4:      	ldr	x5, [x0, #0x78]
    28d8:      	add	x3, x3, x5
    28dc:      	ldr	w3, [x3]
    28e0:      	sxtw	x3, w3
    28e4:      	cmp	x3, #0x0
    28e8:      	cset	w3, ge
    28ec:      	ubfx	x3, x3, #0, #8
    28f0:      	b	0x2994 <_stogir.graph.borrow-node+0x104>
    28f4:      	cmp	x1, #0x0
    28f8:      	b.ge	0x2950 <_stogir.graph.borrow-node+0xc0>
    28fc:      	add	x5, x0, #0x28
    2900:      	add	x6, x0, #0x50
    2904:      	ldr	x5, [x5, #0x8]
    2908:      	ldr	x6, [x6, #0x8]
    290c:      	cmp	x5, x6
    2910:      	b.ne	0x2940 <_stogir.graph.borrow-node+0xb0>
    2914:      	cmp	x3, x5
    2918:      	b.gt	0x2998 <_stogir.graph.borrow-node+0x108>
    291c:      	lsl	x3, x4, #2
    2920:      	ldr	x5, [x0, #0x50]
    2924:      	add	x3, x3, x5
    2928:      	ldr	w3, [x3]
    292c:      	sxtw	x3, w3
    2930:      	cmp	x3, #0x0
    2934:      	cset	w3, gt
    2938:      	ubfx	x3, x3, #0, #8
    293c:      	b	0x299c <_stogir.graph.borrow-node+0x10c>
    2940:      	movz	x3, #0x0, lsl #48
    2944:      	b	0x2954 <_stogir.graph.borrow-node+0xc4>
    2948:      	movz	x3, #0x0, lsl #48
    294c:      	b	0x2954 <_stogir.graph.borrow-node+0xc4>
    2950:      	movz	x3, #0x0, lsl #48
    2954:      	cmp	x3, #0x0
    2958:      	b.eq	0x2988 <_stogir.graph.borrow-node+0xf8>
    295c:      	uxtb	w16, w2
    2960:      	cmp	w16, wzr
    2964:      	b.eq	0x2978 <_stogir.graph.borrow-node+0xe8>
    2968:      	lsl	x1, x1, #4
    296c:      	ldr	x0, [x0]
    2970:      	add	x0, x1, x0
    2974:      	b	0x2984 <_stogir.graph.borrow-node+0xf4>
    2978:      	lsl	x1, x4, #4
    297c:      	ldr	x0, [x0, #0x28]
    2980:      	add	x0, x1, x0
    2984:      	b	0x298c <_stogir.graph.borrow-node+0xfc>
    2988:      	movz	x0, #0x0, lsl #48
    298c:      	ret
    2990:      	movz	x3, #0x0, lsl #48
    2994:      	b	0x294c <_stogir.graph.borrow-node+0xbc>
    2998:      	movz	x3, #0x0, lsl #48
    299c:      	b	0x2944 <_stogir.graph.borrow-node+0xb4>

00000000000029a0 <_stogir.strings.lookup>:
    29a0:      	sxtw	x1, w1
    29a4:      	cmp	x1, #0x0
    29a8:      	b.le	0x2a24 <_stogir.strings.lookup+0x84>
    29ac:      	add	x2, x0, #0x28
    29b0:      	ldr	x2, [x2, #0x8]
    29b4:      	cmp	x1, x2
    29b8:      	b.gt	0x2a24 <_stogir.strings.lookup+0x84>
    29bc:      	sub	x1, x1, #0x1
    29c0:      	mov	x17, #0x18              ; =24
    29c4:      	mul	x1, x1, x17
    29c8:      	ldr	x2, [x0, #0x28]
    29cc:      	add	x1, x1, x2
    29d0:      	ldr	x2, [x1]
    29d4:      	ldr	x1, [x1, #0x8]
    29d8:      	ldr	x3, [x0, #0x8]
    29dc:      	cmp	x2, #0x0
    29e0:      	b.lt	0x2a40 <_stogir.strings.lookup+0xa0>
    29e4:      	cmp	x2, x3
    29e8:      	b.gt	0x2a40 <_stogir.strings.lookup+0xa0>
    29ec:      	cmp	x1, #0x0
    29f0:      	b.lt	0x2a40 <_stogir.strings.lookup+0xa0>
    29f4:      	sub	x3, x3, x2
    29f8:      	cmp	x1, x3
    29fc:      	b.gt	0x2a40 <_stogir.strings.lookup+0xa0>
    2a00:      	add	x1, x1, x2
    2a04:      	lsr	x3, x2, #0
    2a08:      	sub	x1, x1, x2
    2a0c:      	ldr	x0, [x0]
    2a10:      	add	x0, x3, x0
    2a14:      	mov	x2, x1
    2a18:      	mov	x1, x0
    2a1c:      	mov	x0, #0x1                ; =1
    2a20:      	b	0x2a4c <_stogir.strings.lookup+0xac>
    2a24:      	movz	x0, #0x0, lsl #48
    2a28:      	movz	x1, #0x0, lsl #48
    2a2c:      	movz	x2, #0x0, lsl #48
    2a30:      	str	x0, [x8]
    2a34:      	str	x1, [x8, #0x8]
    2a38:      	str	x2, [x8, #0x10]
    2a3c:      	ret
    2a40:      	movz	x0, #0x0, lsl #48
    2a44:      	movz	x1, #0x0, lsl #48
    2a48:      	movz	x2, #0x0, lsl #48
    2a4c:      	b	0x2a30 <_stogir.strings.lookup+0x90>

0000000000002a50 <_stogir.uses.edge-code?>:
    2a50:      	ubfx	x0, x0, #0, #32
    2a54:      	cmp	x0, #0xf
    2a58:      	b.hs	0x2a8c <_stogir.uses.edge-code?+0x3c>
    2a5c:      	mov	x16, #0x1               ; =1
    2a60:      	lsl	x0, x16, x0
    2a64:      	lsr	w0, w0, #0
    2a68:      	mov	x17, #0x5e1c            ; =24092
    2a6c:      	and	x0, x0, x17
    2a70:      	lsr	w0, w0, #0
    2a74:      	cmp	x0, #0x0
    2a78:      	cset	w0, eq
    2a7c:      	uxtb	w16, w0
    2a80:      	cmp	w16, wzr
    2a84:      	cset	x0, eq
    2a88:      	b	0x2a90 <_stogir.uses.edge-code?+0x40>
    2a8c:      	movz	x0, #0x0, lsl #48
    2a90:      	ret

0000000000002a94 <_stogir.graph.contains?>:
    2a94:      	sxtw	x1, w1
    2a98:      	cmp	x1, #0x0
    2a9c:      	b.le	0x2ae0 <_stogir.graph.contains?+0x4c>
    2aa0:      	ldr	x2, [x0, #0x8]
    2aa4:      	cmp	x1, x2
    2aa8:      	b.ge	0x2b40 <_stogir.graph.contains?+0xac>
    2aac:      	add	x2, x0, #0x78
    2ab0:      	ldr	x2, [x2, #0x8]
    2ab4:      	cmp	x1, x2
    2ab8:      	b.ge	0x2b50 <_stogir.graph.contains?+0xbc>
    2abc:      	lsl	x1, x1, #2
    2ac0:      	ldr	x0, [x0, #0x78]
    2ac4:      	add	x0, x1, x0
    2ac8:      	ldr	w0, [x0]
    2acc:      	sxtw	x0, w0
    2ad0:      	cmp	x0, #0x0
    2ad4:      	cset	w0, ge
    2ad8:      	ubfx	x0, x0, #0, #8
    2adc:      	b	0x2b54 <_stogir.graph.contains?+0xc0>
    2ae0:      	cmp	x1, #0x0
    2ae4:      	b.ge	0x2b48 <_stogir.graph.contains?+0xb4>
    2ae8:      	add	x2, x0, #0x28
    2aec:      	add	x3, x0, #0x50
    2af0:      	ldr	x2, [x2, #0x8]
    2af4:      	ldr	x3, [x3, #0x8]
    2af8:      	cmp	x2, x3
    2afc:      	b.ne	0x2b60 <_stogir.graph.contains?+0xcc>
    2b00:      	movz	x16, #0x0, lsl #48
    2b04:      	sub	x3, x16, x1
    2b08:      	cmp	x3, x2
    2b0c:      	b.gt	0x2b58 <_stogir.graph.contains?+0xc4>
    2b10:      	movz	x16, #0x0, lsl #48
    2b14:      	sub	x1, x16, x1
    2b18:      	sub	x1, x1, #0x1
    2b1c:      	lsl	x1, x1, #2
    2b20:      	ldr	x0, [x0, #0x50]
    2b24:      	add	x0, x1, x0
    2b28:      	ldr	w0, [x0]
    2b2c:      	sxtw	x0, w0
    2b30:      	cmp	x0, #0x0
    2b34:      	cset	w0, gt
    2b38:      	ubfx	x0, x0, #0, #8
    2b3c:      	b	0x2b5c <_stogir.graph.contains?+0xc8>
    2b40:      	movz	x0, #0x0, lsl #48
    2b44:      	b	0x2b54 <_stogir.graph.contains?+0xc0>
    2b48:      	movz	x0, #0x0, lsl #48
    2b4c:      	b	0x2b5c <_stogir.graph.contains?+0xc8>
    2b50:      	movz	x0, #0x0, lsl #48
    2b54:      	b	0x2b5c <_stogir.graph.contains?+0xc8>
    2b58:      	movz	x0, #0x0, lsl #48
    2b5c:      	ret
    2b60:      	movz	x0, #0x0, lsl #48
    2b64:      	b	0x2b5c <_stogir.graph.contains?+0xc8>

0000000000002b68 <_stogir.opcode.optional-reference?>:
    2b68:      	sub	sp, sp, #0x30
    2b6c:      	str	x29, [sp]
    2b70:      	str	x30, [sp, #0x8]
    2b74:      	mov	x29, sp
    2b78:      	str	x19, [sp, #0x10]
    2b7c:      	str	x20, [sp, #0x18]
    2b80:      	str	x21, [sp, #0x20]
    2b84:      	lsr	w0, w0, #0
    2b88:      	lsr	w2, w2, #0
    2b8c:      	mov	w19, w0
    2b90:      	mov	w20, w1
    2b94:      	mov	w1, w2
    2b98:      	mov	w21, w2
    2b9c:      	bl	0x2b9c <_stogir.opcode.optional-reference?+0x34>
		0000000000002b9c:  ARM64_RELOC_BRANCH26	_stogir.opcode.operand-code
    2ba0:      	lsr	w0, w0, #0
    2ba4:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x11b0>
		0000000000002ba4:  ARM64_RELOC_PAGE21	l_stogir.337
    2ba8:      	ldr	x16, [x16]
		0000000000002ba8:  ARM64_RELOC_PAGEOFF12	l_stogir.337
    2bac:      	ldr	w1, [x16]
    2bb0:      	cmp	x0, x1
    2bb4:      	b.ne	0x2be0 <_stogir.opcode.optional-reference?+0x78>
    2bb8:      	mov	x0, #0x1                ; =1
    2bbc:      	b	0x2bc4 <_stogir.opcode.optional-reference?+0x5c>
    2bc0:      	movz	x0, #0x0, lsl #48
    2bc4:      	ldr	x19, [sp, #0x10]
    2bc8:      	ldr	x20, [sp, #0x18]
    2bcc:      	ldr	x21, [sp, #0x20]
    2bd0:      	ldr	x29, [sp]
    2bd4:      	ldr	x30, [sp, #0x8]
    2bd8:      	add	sp, sp, #0x30
    2bdc:      	ret
    2be0:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x11b0>
		0000000000002be0:  ARM64_RELOC_PAGE21	l_stogir.338
    2be4:      	ldr	x16, [x16]
		0000000000002be4:  ARM64_RELOC_PAGEOFF12	l_stogir.338
    2be8:      	ldr	w1, [x16]
    2bec:      	cmp	x0, x1
    2bf0:      	b.ne	0x2bfc <_stogir.opcode.optional-reference?+0x94>
    2bf4:      	mov	x0, #0x1                ; =1
    2bf8:      	b	0x2bc4 <_stogir.opcode.optional-reference?+0x5c>
    2bfc:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x11b0>
		0000000000002bfc:  ARM64_RELOC_PAGE21	l_stogir.339
    2c00:      	ldr	x16, [x16]
		0000000000002c00:  ARM64_RELOC_PAGEOFF12	l_stogir.339
    2c04:      	ldr	w1, [x16]
    2c08:      	cmp	x0, x1
    2c0c:      	b.ne	0x2c18 <_stogir.opcode.optional-reference?+0xb0>
    2c10:      	mov	x0, #0x1                ; =1
    2c14:      	b	0x2bc4 <_stogir.opcode.optional-reference?+0x5c>
    2c18:      	sxtw	x19, w19
    2c1c:      	cmp	x19, #0x78
    2c20:      	b.ne	0x2c44 <_stogir.opcode.optional-reference?+0xdc>
    2c24:      	sxtw	x20, w20
    2c28:      	cmp	x20, #0x0
    2c2c:      	b.ne	0x2bc0 <_stogir.opcode.optional-reference?+0x58>
    2c30:      	sxtw	x21, w21
    2c34:      	cmp	x21, #0x2
    2c38:      	cset	w0, eq
    2c3c:      	ubfx	x0, x0, #0, #8
    2c40:      	b	0x2bc4 <_stogir.opcode.optional-reference?+0x5c>
    2c44:      	movz	x0, #0x0, lsl #48
    2c48:      	b	0x2bc4 <_stogir.opcode.optional-reference?+0x5c>

0000000000002c4c <_stogir.integer-binary.operation?>:
    2c4c:      	sxtw	x0, w0
    2c50:      	cmp	x0, #0x1a
    2c54:      	b.lt	0x2c68 <_stogir.integer-binary.operation?+0x1c>
    2c58:      	cmp	x0, #0x1e
    2c5c:      	b.gt	0x2c68 <_stogir.integer-binary.operation?+0x1c>
    2c60:      	mov	x0, #0x1                ; =1
    2c64:      	b	0x2c9c <_stogir.integer-binary.operation?+0x50>
    2c68:      	cmp	x0, #0x2e
    2c6c:      	b.lt	0x2c80 <_stogir.integer-binary.operation?+0x34>
    2c70:      	cmp	x0, #0x35
    2c74:      	b.gt	0x2c80 <_stogir.integer-binary.operation?+0x34>
    2c78:      	mov	x0, #0x1                ; =1
    2c7c:      	b	0x2c9c <_stogir.integer-binary.operation?+0x50>
    2c80:      	cmp	x0, #0x3a
    2c84:      	b.ne	0x2c90 <_stogir.integer-binary.operation?+0x44>
    2c88:      	mov	x0, #0x1                ; =1
    2c8c:      	b	0x2c9c <_stogir.integer-binary.operation?+0x50>
    2c90:      	cmp	x0, #0x3b
    2c94:      	cset	w0, eq
    2c98:      	ubfx	x0, x0, #0, #8
    2c9c:      	ret

0000000000002ca0 <_stogir.integer-unary.operation?>:
    2ca0:      	sxtw	x0, w0
    2ca4:      	cmp	x0, #0x1f
    2ca8:      	b.ne	0x2cc4 <_stogir.integer-unary.operation?+0x24>
    2cac:      	mov	x0, #0x1                ; =1
    2cb0:      	b	0x2cc0 <_stogir.integer-unary.operation?+0x20>
    2cb4:      	cmp	x0, #0x39
    2cb8:      	cset	w0, eq
    2cbc:      	ubfx	x0, x0, #0, #8
    2cc0:      	ret
    2cc4:      	cmp	x0, #0x20
    2cc8:      	b.ne	0x2cd4 <_stogir.integer-unary.operation?+0x34>
    2ccc:      	mov	x0, #0x1                ; =1
    2cd0:      	b	0x2cc0 <_stogir.integer-unary.operation?+0x20>
    2cd4:      	cmp	x0, #0x2d
    2cd8:      	b.ne	0x2ce4 <_stogir.integer-unary.operation?+0x44>
    2cdc:      	mov	x0, #0x1                ; =1
    2ce0:      	b	0x2cc0 <_stogir.integer-unary.operation?+0x20>
    2ce4:      	cmp	x0, #0x36
    2ce8:      	b.ne	0x2cf4 <_stogir.integer-unary.operation?+0x54>
    2cec:      	mov	x0, #0x1                ; =1
    2cf0:      	b	0x2cc0 <_stogir.integer-unary.operation?+0x20>
    2cf4:      	cmp	x0, #0x37
    2cf8:      	b.ne	0x2d04 <_stogir.integer-unary.operation?+0x64>
    2cfc:      	mov	x0, #0x1                ; =1
    2d00:      	b	0x2cc0 <_stogir.integer-unary.operation?+0x20>
    2d04:      	cmp	x0, #0x38
    2d08:      	b.ne	0x2cb4 <_stogir.integer-unary.operation?+0x14>
    2d0c:      	mov	x0, #0x1                ; =1
    2d10:      	b	0x2cc0 <_stogir.integer-unary.operation?+0x20>

0000000000002d14 <_stogir.verify.classifications>:
    2d14:      	sub	sp, sp, #0xc0
    2d18:      	str	x29, [sp]
    2d1c:      	str	x30, [sp, #0x8]
    2d20:      	mov	x29, sp
    2d24:      	str	x19, [sp, #0x70]
    2d28:      	str	x20, [sp, #0x78]
    2d2c:      	str	x21, [sp, #0x80]
    2d30:      	str	x22, [sp, #0x88]
    2d34:      	str	x23, [sp, #0x90]
    2d38:      	str	x24, [sp, #0x98]
    2d3c:      	str	x25, [sp, #0xa0]
    2d40:      	str	x26, [sp, #0xa8]
    2d44:      	str	x27, [sp, #0xb0]
    2d48:      	str	x28, [sp, #0xb8]
    2d4c:      	ldr	w4, [x2]
    2d50:      	orr	x5, x4, xzr
    2d54:      	ubfx	x5, x5, #8, #8
    2d58:      	orr	x19, x5, xzr
    2d5c:      	cmp	x19, #0xf
    2d60:      	b.le	0x2d9c <_stogir.verify.classifications+0x88>
    2d64:      	cmp	x19, #0x80
    2d68:      	b.ge	0x2d90 <_stogir.verify.classifications+0x7c>
    2d6c:      	and	x5, x19, #0xf
    2d70:      	lsr	w5, w5, #0
    2d74:      	sxtw	x5, w5
    2d78:      	cmp	x5, #0x1
    2d7c:      	b.lt	0x335c <_stogir.verify.classifications+0x648>
    2d80:      	cmp	x5, #0xd
    2d84:      	cset	w5, le
    2d88:      	ubfx	x5, x5, #0, #8
    2d8c:      	b	0x3360 <_stogir.verify.classifications+0x64c>
    2d90:      	movz	x5, #0x0, lsl #48
    2d94:      	mov	x20, x5
    2d98:      	b	0x2da0 <_stogir.verify.classifications+0x8c>
    2d9c:      	movz	x20, #0x0, lsl #48
    2da0:      	uxtb	w21, w4
    2da4:      	orr	x4, x21, xzr
    2da8:      	lsr	w22, w4, #0
    2dac:      	mov	x23, x0
    2db0:      	mov	w0, w22
    2db4:      	mov	w24, w1
    2db8:      	mov	x25, x2
    2dbc:      	mov	w26, w3
    2dc0:      	bl	0x2dc0 <_stogir.verify.classifications+0xac>
		0000000000002dc0:  ARM64_RELOC_BRANCH26	_stogir.floating.operation?
    2dc4:      	cmp	x0, #0x0
    2dc8:      	b.eq	0x2de8 <_stogir.verify.classifications+0xd4>
    2dcc:      	cmp	x20, #0x0
    2dd0:      	cset	w0, ne
    2dd4:      	uxtb	w16, w0
    2dd8:      	cmp	w16, wzr
    2ddc:      	cset	x0, eq
    2de0:      	mov	x27, x0
    2de4:      	b	0x2dec <_stogir.verify.classifications+0xd8>
    2de8:      	movz	x27, #0x0, lsl #48
    2dec:      	cmp	x27, #0x0
    2df0:      	cset	w28, ne
    2df4:      	uxtb	w16, w28
    2df8:      	cmp	w16, wzr
    2dfc:      	b.eq	0x2e30 <_stogir.verify.classifications+0x11c>
    2e00:      	ldr	w0, [x25, #0x4]
    2e04:      	lsr	w0, w0, #0
    2e08:      	mov	w1, w0
    2e0c:      	mov	x0, x23
    2e10:      	bl	0x2e10 <_stogir.verify.classifications+0xfc>
		0000000000002e10:  ARM64_RELOC_BRANCH26	_stogir.graph.borrow-node
    2e14:      	cmp	x0, #0x0
    2e18:      	b.ne	0x2e24 <_stogir.verify.classifications+0x110>
    2e1c:      	movn	x0, #0x0, lsl #48
    2e20:      	b	0x2e2c <_stogir.verify.classifications+0x118>
    2e24:      	ldr	w0, [x0]
    2e28:      	ubfx	x0, x0, #8, #8
    2e2c:      	b	0x2e34 <_stogir.verify.classifications+0x120>
    2e30:      	movn	x0, #0x0, lsl #48
    2e34:      	lsr	w0, w0, #0
    2e38:      	sxtw	x0, w0
    2e3c:      	cmp	x0, #0xf
    2e40:      	cset	w1, gt
    2e44:      	cmp	x0, #0x80
    2e48:      	cset	w2, lt
    2e4c:      	and	x3, x0, #0xf
    2e50:      	lsr	w3, w3, #0
    2e54:      	sxtw	x3, w3
    2e58:      	cmp	x3, #0x1
    2e5c:      	cset	w4, ge
    2e60:      	cmp	x3, #0xd
    2e64:      	cset	w3, le
    2e68:      	cmp	x27, #0x0
    2e6c:      	b.eq	0x2ec4 <_stogir.verify.classifications+0x1b0>
    2e70:      	uxtb	w16, w1
    2e74:      	cmp	w16, wzr
    2e78:      	b.eq	0x3364 <_stogir.verify.classifications+0x650>
    2e7c:      	uxtb	w16, w2
    2e80:      	cmp	w16, wzr
    2e84:      	b.eq	0x3364 <_stogir.verify.classifications+0x650>
    2e88:      	uxtb	w16, w4
    2e8c:      	cmp	w16, wzr
    2e90:      	b.eq	0x3364 <_stogir.verify.classifications+0x650>
    2e94:      	uxtb	w16, w3
    2e98:      	cmp	w16, wzr
    2e9c:      	b.eq	0x3364 <_stogir.verify.classifications+0x650>
    2ea0:      	movz	x0, #0x0, lsl #48
    2ea4:      	b	0x2eac <_stogir.verify.classifications+0x198>
    2ea8:      	mov	x0, #0x1                ; =1
    2eac:      	mov	x19, x0
    2eb0:      	b	0x2ec8 <_stogir.verify.classifications+0x1b4>
    2eb4:      	movz	x3, #0x0, lsl #48
    2eb8:      	b	0x2f04 <_stogir.verify.classifications+0x1f0>
    2ebc:      	movz	x0, #0x0, lsl #48
    2ec0:      	b	0x2f0c <_stogir.verify.classifications+0x1f8>
    2ec4:      	movz	x19, #0x0, lsl #48
    2ec8:      	sxtw	x26, w26
    2ecc:      	ubfx	x21, x3, #0, #8
    2ed0:      	add	x27, x23, #0x78
    2ed4:      	add	x0, x23, #0x28
    2ed8:      	add	x3, x23, #0x50
    2edc:      	sxtw	x24, w24
    2ee0:      	add	x5, x23, #0x78
    2ee4:      	cmp	x24, #0x0
    2ee8:      	cset	w6, le
    2eec:      	lsl	x7, x24, #2
    2ef0:      	mov	x8, #0x1                ; =1
    2ef4:      	b	0x2ffc <_stogir.verify.classifications+0x2e8>
    2ef8:      	movz	x3, #0x0, lsl #48
    2efc:      	b	0x2f24 <_stogir.verify.classifications+0x210>
    2f00:      	movz	x3, #0x0, lsl #48
    2f04:      	b	0x2f34 <_stogir.verify.classifications+0x220>
    2f08:      	movz	x0, #0x0, lsl #48
    2f0c:      	ldr	x5, [sp, #0x58]
    2f10:      	ldr	x6, [sp, #0x50]
    2f14:      	ldr	x8, [sp, #0x48]
    2f18:      	ldr	x1, [sp, #0x60]
    2f1c:      	b	0x2fb4 <_stogir.verify.classifications+0x2a0>
    2f20:      	movz	x3, #0x0, lsl #48
    2f24:      	ldr	x6, [sp, #0x50]
    2f28:      	ldr	x8, [sp, #0x48]
    2f2c:      	b	0x2f34 <_stogir.verify.classifications+0x220>
    2f30:      	movz	x3, #0x0, lsl #48
    2f34:      	cmp	x3, #0x0
    2f38:      	b.eq	0x2f68 <_stogir.verify.classifications+0x254>
    2f3c:      	uxtb	w16, w2
    2f40:      	cmp	w16, wzr
    2f44:      	b.eq	0x2f58 <_stogir.verify.classifications+0x244>
    2f48:      	lsl	x0, x0, #4
    2f4c:      	ldr	x2, [x23]
    2f50:      	add	x0, x0, x2
    2f54:      	b	0x2f64 <_stogir.verify.classifications+0x250>
    2f58:      	lsl	x0, x4, #4
    2f5c:      	ldr	x2, [x23, #0x28]
    2f60:      	add	x0, x0, x2
    2f64:      	b	0x2f6c <_stogir.verify.classifications+0x258>
    2f68:      	movz	x0, #0x0, lsl #48
    2f6c:      	cmp	x0, #0x0
    2f70:      	b.eq	0x2fb0 <_stogir.verify.classifications+0x29c>
    2f74:      	ldr	w0, [x0]
    2f78:      	ubfx	x0, x0, #8, #8
    2f7c:      	cmp	x0, #0xf
    2f80:      	b.le	0x2fb0 <_stogir.verify.classifications+0x29c>
    2f84:      	cmp	x0, #0x80
    2f88:      	b.ge	0x2fb0 <_stogir.verify.classifications+0x29c>
    2f8c:      	and	x0, x0, #0xf
    2f90:      	lsr	w0, w0, #0
    2f94:      	sxtw	x0, w0
    2f98:      	cmp	x0, #0x1
    2f9c:      	b.lt	0x2fb0 <_stogir.verify.classifications+0x29c>
    2fa0:      	cmp	x0, #0xd
    2fa4:      	b.gt	0x2fb0 <_stogir.verify.classifications+0x29c>
    2fa8:      	mov	x0, #0x1                ; =1
    2fac:      	b	0x2fb4 <_stogir.verify.classifications+0x2a0>
    2fb0:      	ldr	x0, [sp, #0x40]
    2fb4:      	add	x2, x27, #0x1
    2fb8:      	lsr	w2, w2, #0
    2fbc:      	sxtw	x2, w2
    2fc0:      	mov	w4, w26
    2fc4:      	ldr	x26, [sp, #0x30]
    2fc8:      	mov	x27, x5
    2fcc:      	mov	x3, x8
    2fd0:      	mov	x7, x1
    2fd4:      	mov	w1, w21
    2fd8:      	ldr	x21, [sp, #0x20]
    2fdc:      	mov	x5, x20
    2fe0:      	mov	x20, x0
    2fe4:      	mov	x0, x6
    2fe8:      	mov	w6, w19
    2fec:      	ldr	x19, [sp, #0x38]
    2ff0:      	mov	x8, x2
    2ff4:      	mov	w2, w22
    2ff8:      	ldr	w22, [sp, #0x28]
    2ffc:      	cmp	x20, #0x0
    3000:      	b.ne	0x33c8 <_stogir.verify.classifications+0x6b4>
    3004:      	cmp	x8, x26
    3008:      	b.gt	0x33d4 <_stogir.verify.classifications+0x6c0>
    300c:      	lsr	w9, w8, #0
    3010:      	str	x0, [sp, #0x50]
    3014:      	mov	w0, w22
    3018:      	str	x3, [sp, #0x48]
    301c:      	str	x7, [sp, #0x60]
    3020:      	str	w9, [sp, #0x68]
    3024:      	str	x21, [sp, #0x20]
    3028:      	mov	w21, w1
    302c:      	mov	w1, w9
    3030:      	str	w22, [sp, #0x28]
    3034:      	mov	w22, w2
    3038:      	str	x26, [sp, #0x30]
    303c:      	mov	w26, w4
    3040:      	str	x19, [sp, #0x38]
    3044:      	mov	w19, w6
    3048:      	str	x20, [sp, #0x40]
    304c:      	mov	x20, x5
    3050:      	str	x27, [sp, #0x58]
    3054:      	mov	x27, x8
    3058:      	bl	0x3058 <_stogir.verify.classifications+0x344>
		0000000000003058:  ARM64_RELOC_BRANCH26	_stogir.opcode.operand-code
    305c:      	lsr	w0, w0, #0
    3060:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x2ec>
		0000000000003060:  ARM64_RELOC_PAGE21	l_stogir.340
    3064:      	ldr	x16, [x16]
		0000000000003064:  ARM64_RELOC_PAGEOFF12	l_stogir.340
    3068:      	ldr	w1, [x16]
    306c:      	cmp	x0, x1
    3070:      	b.eq	0x30a0 <_stogir.verify.classifications+0x38c>
    3074:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x2ec>
		0000000000003074:  ARM64_RELOC_PAGE21	l_stogir.341
    3078:      	ldr	x16, [x16]
		0000000000003078:  ARM64_RELOC_PAGEOFF12	l_stogir.341
    307c:      	ldr	w1, [x16]
    3080:      	cmp	x0, x1
    3084:      	b.eq	0x30a0 <_stogir.verify.classifications+0x38c>
    3088:      	ldr	x5, [sp, #0x58]
    308c:      	ldr	x6, [sp, #0x50]
    3090:      	ldr	x8, [sp, #0x48]
    3094:      	ldr	x1, [sp, #0x60]
    3098:      	ldr	x0, [sp, #0x40]
    309c:      	b	0x2fb4 <_stogir.verify.classifications+0x2a0>
    30a0:      	cmp	x27, #0x1
    30a4:      	b.ne	0x30e0 <_stogir.verify.classifications+0x3cc>
    30a8:      	uxtb	w16, w28
    30ac:      	cmp	w16, wzr
    30b0:      	b.eq	0x30e0 <_stogir.verify.classifications+0x3cc>
    30b4:      	uxtb	w16, w21
    30b8:      	cmp	w16, wzr
    30bc:      	b.eq	0x2f08 <_stogir.verify.classifications+0x1f4>
    30c0:      	uxtb	w16, w22
    30c4:      	cmp	w16, wzr
    30c8:      	b.eq	0x2ebc <_stogir.verify.classifications+0x1a8>
    30cc:      	uxtb	w16, w26
    30d0:      	cmp	w16, wzr
    30d4:      	b.eq	0x3294 <_stogir.verify.classifications+0x580>
    30d8:      	ldr	x0, [sp, #0x20]
    30dc:      	b	0x3298 <_stogir.verify.classifications+0x584>
    30e0:      	cmp	x27, #0x1
    30e4:      	b.ne	0x315c <_stogir.verify.classifications+0x448>
    30e8:      	ldr	w0, [x25, #0x4]
    30ec:      	sxtw	x0, w0
    30f0:      	ldr	x1, [sp, #0x60]
    30f4:      	lsr	w0, w0, #0
    30f8:      	sxtw	x0, w0
    30fc:      	cmp	x0, #0x0
    3100:      	cset	w2, gt
    3104:      	movz	x16, #0x0, lsl #48
    3108:      	sub	x3, x16, x0
    310c:      	sub	x4, x3, #0x1
    3110:      	uxtb	w16, w2
    3114:      	cmp	w16, wzr
    3118:      	b.eq	0x33e0 <_stogir.verify.classifications+0x6cc>
    311c:      	ldr	x3, [x23, #0x8]
    3120:      	cmp	x0, x3
    3124:      	b.ge	0x33e8 <_stogir.verify.classifications+0x6d4>
    3128:      	ldr	x5, [sp, #0x58]
    312c:      	ldr	x3, [x5, #0x8]
    3130:      	cmp	x0, x3
    3134:      	b.ge	0x2ef8 <_stogir.verify.classifications+0x1e4>
    3138:      	lsl	x3, x0, #2
    313c:      	ldr	x6, [x23, #0x78]
    3140:      	add	x3, x3, x6
    3144:      	ldr	w3, [x3]
    3148:      	sxtw	x3, w3
    314c:      	cmp	x3, #0x0
    3150:      	cset	w3, ge
    3154:      	ubfx	x3, x3, #0, #8
    3158:      	b	0x2efc <_stogir.verify.classifications+0x1e8>
    315c:      	cmp	x27, #0x2
    3160:      	b.ne	0x31c0 <_stogir.verify.classifications+0x4ac>
    3164:      	ldr	w0, [x25, #0x8]
    3168:      	sxtw	x0, w0
    316c:      	ldr	x1, [sp, #0x60]
    3170:      	b	0x30f4 <_stogir.verify.classifications+0x3e0>
    3174:      	cmp	x0, #0x0
    3178:      	b.ge	0x33f0 <_stogir.verify.classifications+0x6dc>
    317c:      	ldr	x6, [sp, #0x50]
    3180:      	ldr	x7, [x6, #0x8]
    3184:      	ldr	x8, [sp, #0x48]
    3188:      	ldr	x9, [x8, #0x8]
    318c:      	cmp	x7, x9
    3190:      	b.ne	0x2f00 <_stogir.verify.classifications+0x1ec>
    3194:      	cmp	x3, x7
    3198:      	b.gt	0x2eb4 <_stogir.verify.classifications+0x1a0>
    319c:      	lsl	x3, x4, #2
    31a0:      	ldr	x7, [x23, #0x50]
    31a4:      	add	x3, x3, x7
    31a8:      	ldr	w3, [x3]
    31ac:      	sxtw	x3, w3
    31b0:      	cmp	x3, #0x0
    31b4:      	cset	w3, gt
    31b8:      	ubfx	x3, x3, #0, #8
    31bc:      	b	0x2eb8 <_stogir.verify.classifications+0x1a4>
    31c0:      	cmp	x27, #0x3
    31c4:      	b.ne	0x3244 <_stogir.verify.classifications+0x530>
    31c8:      	ldr	w0, [x25, #0xc]
    31cc:      	sxtw	x0, w0
    31d0:      	ldr	x1, [sp, #0x60]
    31d4:      	b	0x3170 <_stogir.verify.classifications+0x45c>
    31d8:      	ldr	x0, [sp, #0x40]
    31dc:      	uxtb	w0, w0
    31e0:      	ldr	x1, [sp, #0x38]
    31e4:      	uxtb	w1, w1
    31e8:      	add	x16, sp, #0x10
    31ec:      	movz	w17, #0x0, lsl #16
    31f0:      	strh	w17, [x16]
    31f4:      	add	x16, sp, #0x10
    31f8:      	strb	w0, [x16]
    31fc:      	add	x16, sp, #0x10
    3200:      	strb	w1, [x16, #0x1]
    3204:      	add	x16, sp, #0x10
    3208:      	ldrh	w0, [x16]
    320c:      	ldr	x19, [sp, #0x70]
    3210:      	ldr	x20, [sp, #0x78]
    3214:      	ldr	x21, [sp, #0x80]
    3218:      	ldr	x22, [sp, #0x88]
    321c:      	ldr	x23, [sp, #0x90]
    3220:      	ldr	x24, [sp, #0x98]
    3224:      	ldr	x25, [sp, #0xa0]
    3228:      	ldr	x26, [sp, #0xa8]
    322c:      	ldr	x27, [sp, #0xb0]
    3230:      	ldr	x28, [sp, #0xb8]
    3234:      	ldr	x29, [sp]
    3238:      	ldr	x30, [sp, #0x8]
    323c:      	add	sp, sp, #0xc0
    3240:      	ret
    3244:      	uxtb	w16, w19
    3248:      	cmp	w16, wzr
    324c:      	b.eq	0x32ac <_stogir.verify.classifications+0x598>
    3250:      	ldr	x1, [sp, #0x60]
    3254:      	movz	x0, #0x0, lsl #48
    3258:      	movz	x2, #0x0, lsl #48
    325c:      	lsr	w0, w0, #0
    3260:      	lsr	x16, x0, #0
    3264:      	cmp	x16, #0x1
    3268:      	b.eq	0x3284 <_stogir.verify.classifications+0x570>
    326c:      	b.lo	0x3274 <_stogir.verify.classifications+0x560>
    3270:      	b	0x3288 <_stogir.verify.classifications+0x574>
    3274:      	cmp	x16, #0x0
    3278:      	b.eq	0x3280 <_stogir.verify.classifications+0x56c>
    327c:      	b	0x3288 <_stogir.verify.classifications+0x574>
    3280:      	b	0x328c <_stogir.verify.classifications+0x578>
    3284:      	b	0x329c <_stogir.verify.classifications+0x588>
    3288:      	b	0x33c0 <_stogir.verify.classifications+0x6ac>
    328c:      	movz	x0, #0x0, lsl #48
    3290:      	b	0x32a8 <_stogir.verify.classifications+0x594>
    3294:      	movz	x0, #0x0, lsl #48
    3298:      	b	0x2ec0 <_stogir.verify.classifications+0x1ac>
    329c:      	lsr	w2, w2, #0
    32a0:      	sxtw	x2, w2
    32a4:      	mov	x0, x2
    32a8:      	b	0x31d4 <_stogir.verify.classifications+0x4c0>
    32ac:      	ldr	x0, [x23, #0x8]
    32b0:      	cmp	x24, x0
    32b4:      	b.ge	0x33fc <_stogir.verify.classifications+0x6e8>
    32b8:      	ldr	x0, [x20, #0x8]
    32bc:      	cmp	x24, x0
    32c0:      	b.ge	0x3404 <_stogir.verify.classifications+0x6f0>
    32c4:      	ldr	x0, [x23, #0x78]
    32c8:      	ldr	x1, [sp, #0x60]
    32cc:      	add	x0, x1, x0
    32d0:      	ldr	w0, [x0]
    32d4:      	sxtw	x0, w0
    32d8:      	cmp	x0, #0x0
    32dc:      	b.lt	0x3254 <_stogir.verify.classifications+0x540>
    32e0:      	ldr	w0, [sp, #0x68]
    32e4:      	sxtw	x0, w0
    32e8:      	cmp	x0, #0x1
    32ec:      	b.lt	0x33a4 <_stogir.verify.classifications+0x690>
    32f0:      	ldr	x2, [x23, #0x78]
    32f4:      	add	x2, x1, x2
    32f8:      	ldr	w2, [x2]
    32fc:      	sxtw	x2, w2
    3300:      	cmp	x0, x2
    3304:      	b.gt	0x33a4 <_stogir.verify.classifications+0x690>
    3308:      	ldr	x2, [x23]
    330c:      	asr	x16, x0, #63
    3310:      	lsr	x16, x16, #62
    3314:      	add	x3, x0, x16
    3318:      	asr	x3, x3, #2
    331c:      	asr	x16, x0, #63
    3320:      	lsr	x16, x16, #62
    3324:      	add	x0, x0, x16
    3328:      	and	x0, x0, #0x3
    332c:      	sub	x0, x0, x16
    3330:      	add	x3, x3, x24
    3334:      	lsl	x0, x0, #2
    3338:      	lsl	x3, x3, #4
    333c:      	add	x2, x3, x2
    3340:      	add	x0, x0, x2
    3344:      	ldr	w0, [x0]
    3348:      	sxtw	x0, w0
    334c:      	and	x0, x0, #0xffffffff
    3350:      	mov	x2, x0
    3354:      	mov	x0, #0x1                ; =1
    3358:      	b	0x33ac <_stogir.verify.classifications+0x698>
    335c:      	movz	x5, #0x0, lsl #48
    3360:      	b	0x2d94 <_stogir.verify.classifications+0x80>
    3364:      	cmp	x21, #0x18
    3368:      	b.ne	0x3374 <_stogir.verify.classifications+0x660>
    336c:      	mov	x0, #0x1                ; =1
    3370:      	b	0x2eac <_stogir.verify.classifications+0x198>
    3374:      	cmp	x21, #0x19
    3378:      	b.ne	0x3384 <_stogir.verify.classifications+0x670>
    337c:      	mov	x0, #0x1                ; =1
    3380:      	b	0x2eac <_stogir.verify.classifications+0x198>
    3384:      	cmp	x19, #0xc
    3388:      	b.eq	0x2ea8 <_stogir.verify.classifications+0x194>
    338c:      	cmp	x19, #0xd
    3390:      	b.eq	0x2ea8 <_stogir.verify.classifications+0x194>
    3394:      	cmp	x0, #0xc
    3398:      	b.ne	0x33b0 <_stogir.verify.classifications+0x69c>
    339c:      	mov	x0, #0x1                ; =1
    33a0:      	b	0x33bc <_stogir.verify.classifications+0x6a8>
    33a4:      	movz	x0, #0x0, lsl #48
    33a8:      	movz	x2, #0x0, lsl #48
    33ac:      	b	0x325c <_stogir.verify.classifications+0x548>
    33b0:      	cmp	x0, #0xd
    33b4:      	cset	w0, eq
    33b8:      	ubfx	x0, x0, #0, #8
    33bc:      	b	0x2eac <_stogir.verify.classifications+0x198>
    33c0:      	brk	#0
    33c4:      	b	0x33c0 <_stogir.verify.classifications+0x6ac>
    33c8:      	str	x19, [sp, #0x38]
    33cc:      	str	x20, [sp, #0x40]
    33d0:      	b	0x31d8 <_stogir.verify.classifications+0x4c4>
    33d4:      	str	x19, [sp, #0x38]
    33d8:      	str	x20, [sp, #0x40]
    33dc:      	b	0x31d8 <_stogir.verify.classifications+0x4c4>
    33e0:      	ldr	x5, [sp, #0x58]
    33e4:      	b	0x3174 <_stogir.verify.classifications+0x460>
    33e8:      	ldr	x5, [sp, #0x58]
    33ec:      	b	0x2f20 <_stogir.verify.classifications+0x20c>
    33f0:      	ldr	x6, [sp, #0x50]
    33f4:      	ldr	x8, [sp, #0x48]
    33f8:      	b	0x2f30 <_stogir.verify.classifications+0x21c>
    33fc:      	ldr	x1, [sp, #0x60]
    3400:      	b	0x3254 <_stogir.verify.classifications+0x540>
    3404:      	ldr	x1, [sp, #0x60]
    3408:      	b	0x3254 <_stogir.verify.classifications+0x540>

000000000000340c <_stogir.vector-lanes.operation?>:
    340c:      	sxtw	x0, w0
    3410:      	cmp	x0, #0x3d
    3414:      	b.lt	0x3428 <_stogir.vector-lanes.operation?+0x1c>
    3418:      	cmp	x0, #0x3f
    341c:      	cset	w0, le
    3420:      	ubfx	x0, x0, #0, #8
    3424:      	b	0x342c <_stogir.vector-lanes.operation?+0x20>
    3428:      	movz	x0, #0x0, lsl #48
    342c:      	ret

0000000000003430 <_stogir.vector.validate>:
    3430:      	sub	sp, sp, #0x210
    3434:      	str	x29, [sp]
    3438:      	str	x30, [sp, #0x8]
    343c:      	mov	x29, sp
    3440:      	str	x19, [sp, #0x1c0]
    3444:      	str	x20, [sp, #0x1c8]
    3448:      	str	x21, [sp, #0x1d0]
    344c:      	str	x22, [sp, #0x1d8]
    3450:      	str	x23, [sp, #0x1e0]
    3454:      	str	x24, [sp, #0x1e8]
    3458:      	str	x25, [sp, #0x1f0]
    345c:      	str	x26, [sp, #0x1f8]
    3460:      	str	x27, [sp, #0x200]
    3464:      	str	x28, [sp, #0x208]
    3468:      	lsr	w19, w1, #0
    346c:      	mov	x20, x8
    3470:      	add	x8, sp, #0x10
    3474:      	mov	x21, x0
    3478:      	mov	w22, w1
    347c:      	mov	w1, w19
    3480:      	mov	w23, w2
    3484:      	bl	0x3484 <_stogir.vector.validate+0x54>
		0000000000003484:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    3488:      	add	x16, sp, #0x10
    348c:      	ldr	w0, [x16]
    3490:      	lsr	x16, x0, #0
    3494:      	cmp	x16, #0x1
    3498:      	b.eq	0x34b4 <_stogir.vector.validate+0x84>
    349c:      	b.lo	0x34a4 <_stogir.vector.validate+0x74>
    34a0:      	b	0x34b8 <_stogir.vector.validate+0x88>
    34a4:      	cmp	x16, #0x0
    34a8:      	b.eq	0x34b0 <_stogir.vector.validate+0x80>
    34ac:      	b	0x34b8 <_stogir.vector.validate+0x88>
    34b0:      	b	0x34bc <_stogir.vector.validate+0x8c>
    34b4:      	b	0x3554 <_stogir.vector.validate+0x124>
    34b8:      	b	0x377c <_stogir.vector.validate+0x34c>
    34bc:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x2ec>
		00000000000034bc:  ARM64_RELOC_PAGE21	l_stogir.342
    34c0:      	ldr	x16, [x16]
		00000000000034c0:  ARM64_RELOC_PAGEOFF12	l_stogir.342
    34c4:      	orr	x0, x16, xzr
    34c8:      	str	x20, [sp, #0x1a8]
    34cc:      	mov	x1, x0
    34d0:      	mov	x0, #0x1                ; =1
    34d4:      	mov	x2, #0x1a               ; =26
    34d8:      	b	0x350c <_stogir.vector.validate+0xdc>
    34dc:      	lsr	w23, w23, #0
    34e0:      	add	x8, sp, #0x70
    34e4:      	mov	x0, x21
    34e8:      	ldr	w1, [sp, #0x1a0]
    34ec:      	mov	w2, w23
    34f0:      	bl	0x34f0 <_stogir.vector.validate+0xc0>
		00000000000034f0:  ARM64_RELOC_BRANCH26	_stogir.conversion.validate
    34f4:      	add	x16, sp, #0x70
    34f8:      	ldr	x0, [x16]
    34fc:      	add	x16, sp, #0x70
    3500:      	ldr	x1, [x16, #0x8]
    3504:      	add	x16, sp, #0x70
    3508:      	ldr	x2, [x16, #0x10]
    350c:      	ldr	x3, [sp, #0x1a8]
    3510:      	str	x0, [x3]
    3514:      	str	x1, [x3, #0x8]
    3518:      	str	x2, [x3, #0x10]
    351c:      	ldr	x19, [sp, #0x1c0]
    3520:      	ldr	x20, [sp, #0x1c8]
    3524:      	ldr	x21, [sp, #0x1d0]
    3528:      	ldr	x22, [sp, #0x1d8]
    352c:      	ldr	x23, [sp, #0x1e0]
    3530:      	ldr	x24, [sp, #0x1e8]
    3534:      	ldr	x25, [sp, #0x1f0]
    3538:      	ldr	x26, [sp, #0x1f8]
    353c:      	ldr	x27, [sp, #0x200]
    3540:      	ldr	x28, [sp, #0x208]
    3544:      	ldr	x29, [sp]
    3548:      	ldr	x30, [sp, #0x8]
    354c:      	add	sp, sp, #0x210
    3550:      	ret
    3554:      	sxtw	x22, w22
    3558:      	add	x16, sp, #0x10
    355c:      	orr	x0, x16, xzr
    3560:      	cmp	x22, #0x0
    3564:      	cset	w24, le
    3568:      	add	x0, x0, #0x8
    356c:      	add	x16, sp, #0x10
    3570:      	ldr	x1, [x16, #0x8]
    3574:      	add	x16, sp, #0x40
    3578:      	str	x1, [x16]
    357c:      	ldr	x0, [x0, #0x8]
    3580:      	add	x16, sp, #0x40
    3584:      	str	x0, [x16, #0x8]
    3588:      	uxtb	w16, w24
    358c:      	cmp	w16, wzr
    3590:      	b.eq	0x35b4 <_stogir.vector.validate+0x184>
    3594:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x2ec>
		0000000000003594:  ARM64_RELOC_PAGE21	l_stogir.343
    3598:      	ldr	x16, [x16]
		0000000000003598:  ARM64_RELOC_PAGEOFF12	l_stogir.343
    359c:      	orr	x0, x16, xzr
    35a0:      	str	x20, [sp, #0x1a8]
    35a4:      	mov	x1, x0
    35a8:      	mov	x0, #0x1                ; =1
    35ac:      	mov	x2, #0x3b               ; =59
    35b0:      	b	0x350c <_stogir.vector.validate+0xdc>
    35b4:      	lsl	x25, x22, #2
    35b8:      	add	x16, sp, #0x40
    35bc:      	ldr	w26, [x16]
    35c0:      	uxtb	w0, w26
    35c4:      	ldr	x1, [x21, #0x78]
    35c8:      	orr	x27, x0, xzr
    35cc:      	cmp	x27, #0x44
    35d0:      	cset	w0, eq
    35d4:      	add	x1, x25, x1
    35d8:      	ldr	w28, [x1]
    35dc:      	cmp	x27, #0x24
    35e0:      	b.ne	0x3624 <_stogir.vector.validate+0x1f4>
    35e4:      	str	x20, [sp, #0x1a8]
    35e8:      	str	w19, [sp, #0x1a0]
    35ec:      	uxtb	w16, w0
    35f0:      	cmp	w16, wzr
    35f4:      	b.eq	0x34dc <_stogir.vector.validate+0xac>
    35f8:      	add	x8, sp, #0x50
    35fc:      	mov	x0, x21
    3600:      	ldr	w1, [sp, #0x1a0]
    3604:      	bl	0x3604 <_stogir.vector.validate+0x1d4>
		0000000000003604:  ARM64_RELOC_BRANCH26	_stogir.copy.validate
    3608:      	add	x16, sp, #0x50
    360c:      	ldr	x0, [x16]
    3610:      	add	x16, sp, #0x50
    3614:      	ldr	x1, [x16, #0x8]
    3618:      	add	x16, sp, #0x50
    361c:      	ldr	x2, [x16, #0x10]
    3620:      	b	0x350c <_stogir.vector.validate+0xdc>
    3624:      	uxtb	w16, w0
    3628:      	cmp	w16, wzr
    362c:      	b.ne	0x3ee4 <_stogir.vector.validate+0xab4>
    3630:      	cmp	x27, #0x3c
    3634:      	b.ne	0x36e8 <_stogir.vector.validate+0x2b8>
    3638:      	add	x8, sp, #0x90
    363c:      	mov	x0, x21
    3640:      	mov	w1, w19
    3644:      	bl	0x3644 <_stogir.vector.validate+0x214>
		0000000000003644:  ARM64_RELOC_BRANCH26	_stogir.conditional.validate
    3648:      	add	x16, sp, #0x90
    364c:      	ldr	x0, [x16]
    3650:      	add	x16, sp, #0x90
    3654:      	ldr	x1, [x16, #0x8]
    3658:      	add	x16, sp, #0x90
    365c:      	ldr	x2, [x16, #0x10]
    3660:      	str	x20, [sp, #0x1a8]
    3664:      	b	0x36e4 <_stogir.vector.validate+0x2b4>
    3668:      	cmp	x27, #0x41
    366c:      	cset	w0, eq
    3670:      	cmp	x27, #0x48
    3674:      	cset	w1, eq
    3678:      	cmp	x27, #0x55
    367c:      	cset	w2, ge
    3680:      	cmp	x27, #0x58
    3684:      	cset	w3, le
    3688:      	cmp	x27, #0x47
    368c:      	b.ne	0x3784 <_stogir.vector.validate+0x354>
    3690:      	str	x20, [sp, #0x1a8]
    3694:      	str	w19, [sp, #0x1a0]
    3698:      	mov	w19, w0
    369c:      	mov	w20, w1
    36a0:      	str	w2, [sp, #0x1b0]
    36a4:      	str	w3, [sp, #0x1b8]
    36a8:      	mov	x0, x21
    36ac:      	ldr	w1, [sp, #0x1a0]
    36b0:      	bl	0x36b0 <_stogir.vector.validate+0x280>
		00000000000036b0:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.node?
    36b4:      	cmp	x0, #0x0
    36b8:      	b.eq	0x37a8 <_stogir.vector.validate+0x378>
    36bc:      	add	x8, sp, #0xf0
    36c0:      	mov	x0, x21
    36c4:      	ldr	w1, [sp, #0x1a0]
    36c8:      	bl	0x36c8 <_stogir.vector.validate+0x298>
		00000000000036c8:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.validate
    36cc:      	add	x16, sp, #0xf0
    36d0:      	ldr	x0, [x16]
    36d4:      	add	x16, sp, #0xf0
    36d8:      	ldr	x1, [x16, #0x8]
    36dc:      	add	x16, sp, #0xf0
    36e0:      	ldr	x2, [x16, #0x10]
    36e4:      	b	0x350c <_stogir.vector.validate+0xdc>
    36e8:      	cmp	x27, #0x3d
    36ec:      	b.lt	0x3730 <_stogir.vector.validate+0x300>
    36f0:      	cmp	x27, #0x3f
    36f4:      	b.gt	0x3730 <_stogir.vector.validate+0x300>
    36f8:      	lsr	w23, w23, #0
    36fc:      	add	x8, sp, #0xb0
    3700:      	mov	x0, x21
    3704:      	mov	w1, w19
    3708:      	mov	w2, w23
    370c:      	bl	0x370c <_stogir.vector.validate+0x2dc>
		000000000000370c:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.validate
    3710:      	add	x16, sp, #0xb0
    3714:      	ldr	x0, [x16]
    3718:      	add	x16, sp, #0xb0
    371c:      	ldr	x1, [x16, #0x8]
    3720:      	add	x16, sp, #0xb0
    3724:      	ldr	x2, [x16, #0x10]
    3728:      	str	x20, [sp, #0x1a8]
    372c:      	b	0x36e4 <_stogir.vector.validate+0x2b4>
    3730:      	mov	x0, x21
    3734:      	mov	w1, w19
    3738:      	bl	0x3738 <_stogir.vector.validate+0x308>
		0000000000003738:  ARM64_RELOC_BRANCH26	_stogir.vector-comparison.node?
    373c:      	cmp	x0, #0x0
    3740:      	b.eq	0x3668 <_stogir.vector.validate+0x238>
    3744:      	lsr	w23, w23, #0
    3748:      	add	x8, sp, #0xd0
    374c:      	mov	x0, x21
    3750:      	mov	w1, w19
    3754:      	mov	w2, w23
    3758:      	bl	0x3758 <_stogir.vector.validate+0x328>
		0000000000003758:  ARM64_RELOC_BRANCH26	_stogir.vector-comparison.validate
    375c:      	add	x16, sp, #0xd0
    3760:      	ldr	x0, [x16]
    3764:      	add	x16, sp, #0xd0
    3768:      	ldr	x1, [x16, #0x8]
    376c:      	add	x16, sp, #0xd0
    3770:      	ldr	x2, [x16, #0x10]
    3774:      	str	x20, [sp, #0x1a8]
    3778:      	b	0x36e4 <_stogir.vector.validate+0x2b4>
    377c:      	brk	#0
    3780:      	b	0x377c <_stogir.vector.validate+0x34c>
    3784:      	cmp	x27, #0x4f
    3788:      	b.ne	0x3824 <_stogir.vector.validate+0x3f4>
    378c:      	str	x20, [sp, #0x1a8]
    3790:      	str	w19, [sp, #0x1a0]
    3794:      	mov	w19, w0
    3798:      	mov	w20, w1
    379c:      	str	w2, [sp, #0x1b0]
    37a0:      	str	w3, [sp, #0x1b8]
    37a4:      	b	0x36a8 <_stogir.vector.validate+0x278>
    37a8:      	uxtb	w16, w19
    37ac:      	cmp	w16, wzr
    37b0:      	b.ne	0x37f0 <_stogir.vector.validate+0x3c0>
    37b4:      	uxtb	w16, w20
    37b8:      	cmp	w16, wzr
    37bc:      	b.ne	0x37f0 <_stogir.vector.validate+0x3c0>
    37c0:      	ldr	w0, [sp, #0x1b0]
    37c4:      	uxtb	w16, w0
    37c8:      	cmp	w16, wzr
    37cc:      	b.eq	0x37e0 <_stogir.vector.validate+0x3b0>
    37d0:      	ldr	w0, [sp, #0x1b8]
    37d4:      	uxtb	w16, w0
    37d8:      	cmp	w16, wzr
    37dc:      	b.ne	0x37f0 <_stogir.vector.validate+0x3c0>
    37e0:      	movz	x0, #0x0, lsl #48
    37e4:      	movz	x1, #0x0, lsl #48
    37e8:      	movz	x2, #0x0, lsl #48
    37ec:      	b	0x3820 <_stogir.vector.validate+0x3f0>
    37f0:      	lsr	w23, w23, #0
    37f4:      	add	x8, sp, #0x110
    37f8:      	mov	x0, x21
    37fc:      	ldr	w1, [sp, #0x1a0]
    3800:      	mov	w2, w23
    3804:      	bl	0x3804 <_stogir.vector.validate+0x3d4>
		0000000000003804:  ARM64_RELOC_BRANCH26	_stogir.locals.validate
    3808:      	add	x16, sp, #0x110
    380c:      	ldr	x0, [x16]
    3810:      	add	x16, sp, #0x110
    3814:      	ldr	x1, [x16, #0x8]
    3818:      	add	x16, sp, #0x110
    381c:      	ldr	x2, [x16, #0x10]
    3820:      	b	0x36e4 <_stogir.vector.validate+0x2b4>
    3824:      	cmp	x27, #0x50
    3828:      	b.eq	0x3ef0 <_stogir.vector.validate+0xac0>
    382c:      	cmp	x27, #0x78
    3830:      	b.ne	0x3850 <_stogir.vector.validate+0x420>
    3834:      	str	x20, [sp, #0x1a8]
    3838:      	str	w19, [sp, #0x1a0]
    383c:      	mov	w19, w0
    3840:      	mov	w20, w1
    3844:      	str	w2, [sp, #0x1b0]
    3848:      	str	w3, [sp, #0x1b8]
    384c:      	b	0x36a8 <_stogir.vector.validate+0x278>
    3850:      	uxtb	w16, w0
    3854:      	cmp	w16, wzr
    3858:      	b.ne	0x3938 <_stogir.vector.validate+0x508>
    385c:      	uxtb	w16, w1
    3860:      	cmp	w16, wzr
    3864:      	b.ne	0x3938 <_stogir.vector.validate+0x508>
    3868:      	uxtb	w16, w2
    386c:      	cmp	w16, wzr
    3870:      	b.eq	0x3880 <_stogir.vector.validate+0x450>
    3874:      	uxtb	w16, w3
    3878:      	cmp	w16, wzr
    387c:      	b.ne	0x3938 <_stogir.vector.validate+0x508>
    3880:      	str	w2, [sp, #0x1b0]
    3884:      	str	w3, [sp, #0x1b8]
    3888:      	str	w19, [sp, #0x1a0]
    388c:      	str	x20, [sp, #0x1a8]
    3890:      	mov	w20, w1
    3894:      	mov	w1, w19
    3898:      	mov	w19, w0
    389c:      	mov	x0, x21
    38a0:      	bl	0x38a0 <_stogir.vector.validate+0x470>
		00000000000038a0:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.node?
    38a4:      	cmp	x0, #0x0
    38a8:      	b.ne	0x36a8 <_stogir.vector.validate+0x278>
    38ac:      	sxtw	x28, w28
    38b0:      	ubfx	x0, x26, #8, #8
    38b4:      	orr	x1, x0, xzr
    38b8:      	lsr	w19, w1, #0
    38bc:      	cmp	x27, #0x5b
    38c0:      	b.eq	0x3970 <_stogir.vector.validate+0x540>
    38c4:      	cmp	x27, #0x5c
    38c8:      	b.eq	0x3970 <_stogir.vector.validate+0x540>
    38cc:      	orr	x20, x0, xzr
    38d0:      	cmp	x27, #0x5d
    38d4:      	b.eq	0x39e8 <_stogir.vector.validate+0x5b8>
    38d8:      	cmp	x27, #0x5e
    38dc:      	b.eq	0x39e8 <_stogir.vector.validate+0x5b8>
    38e0:      	cmp	x27, #0x43
    38e4:      	b.ne	0x3a64 <_stogir.vector.validate+0x634>
    38e8:      	mov	w0, w19
    38ec:      	bl	0x38ec <_stogir.vector.validate+0x4bc>
		00000000000038ec:  ARM64_RELOC_BRANCH26	_stogir.types.vector?
    38f0:      	cmp	x0, #0x0
    38f4:      	b.eq	0x3d98 <_stogir.vector.validate+0x968>
    38f8:      	lsr	w23, w23, #0
    38fc:      	mov	w0, w19
    3900:      	mov	w1, w23
    3904:      	bl	0x3904 <_stogir.vector.validate+0x4d4>
		0000000000003904:  ARM64_RELOC_BRANCH26	_stogir.types.size
    3908:      	lsr	w0, w0, #0
    390c:      	sxtw	x0, w0
    3910:      	cmp	x0, #0x0
    3914:      	b.le	0x3d98 <_stogir.vector.validate+0x968>
    3918:      	cmp	x28, #0x3
    391c:      	b.lt	0x3d98 <_stogir.vector.validate+0x968>
    3920:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x2ec>
		0000000000003920:  ARM64_RELOC_PAGE21	l_stogir.344
    3924:      	ldr	x16, [x16]
		0000000000003924:  ARM64_RELOC_PAGEOFF12	l_stogir.344
    3928:      	orr	x0, x16, xzr
    392c:      	mov	x26, x0
    3930:      	movz	x27, #0x0, lsl #48
    3934:      	b	0x3dac <_stogir.vector.validate+0x97c>
    3938:      	str	x20, [sp, #0x1a8]
    393c:      	str	w19, [sp, #0x1a0]
    3940:      	mov	w19, w0
    3944:      	mov	w20, w1
    3948:      	str	w2, [sp, #0x1b0]
    394c:      	str	w3, [sp, #0x1b8]
    3950:      	b	0x36a8 <_stogir.vector.validate+0x278>
    3954:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x2ec>
		0000000000003954:  ARM64_RELOC_PAGE21	l_stogir.345
    3958:      	ldr	x16, [x16]
		0000000000003958:  ARM64_RELOC_PAGEOFF12	l_stogir.345
    395c:      	orr	x0, x16, xzr
    3960:      	mov	x1, x0
    3964:      	mov	x0, #0x1                ; =1
    3968:      	mov	x2, #0x19               ; =25
    396c:      	b	0x36e4 <_stogir.vector.validate+0x2b4>
    3970:      	cmp	x28, #0x2
    3974:      	b.ne	0x3954 <_stogir.vector.validate+0x524>
    3978:      	lsr	w23, w23, #0
    397c:      	add	x16, sp, #0x40
    3980:      	ldr	w0, [x16, #0x4]
    3984:      	add	x16, sp, #0x40
    3988:      	ldr	w1, [x16, #0x8]
    398c:      	lsr	w0, w0, #0
    3990:      	lsr	w1, w1, #0
    3994:      	add	x8, sp, #0x130
    3998:      	mov	w2, w23
    399c:      	mov	w3, w0
    39a0:      	mov	x0, x21
    39a4:      	mov	w4, w1
    39a8:      	mov	w1, w19
    39ac:      	bl	0x39ac <_stogir.vector.validate+0x57c>
		00000000000039ac:  ARM64_RELOC_BRANCH26	_stogir.vector.memory-inputs
    39b0:      	add	x16, sp, #0x130
    39b4:      	ldr	x0, [x16]
    39b8:      	add	x16, sp, #0x130
    39bc:      	ldr	x1, [x16, #0x8]
    39c0:      	add	x16, sp, #0x130
    39c4:      	ldr	x2, [x16, #0x10]
    39c8:      	b	0x396c <_stogir.vector.validate+0x53c>
    39cc:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x2ec>
		00000000000039cc:  ARM64_RELOC_PAGE21	l_stogir.346
    39d0:      	ldr	x16, [x16]
		00000000000039d0:  ARM64_RELOC_PAGEOFF12	l_stogir.346
    39d4:      	orr	x0, x16, xzr
    39d8:      	mov	x1, x0
    39dc:      	mov	x0, #0x1                ; =1
    39e0:      	mov	x2, #0x1a               ; =26
    39e4:      	b	0x396c <_stogir.vector.validate+0x53c>
    39e8:      	cmp	x28, #0x3
    39ec:      	b.ne	0x39cc <_stogir.vector.validate+0x59c>
    39f0:      	cmp	x20, #0x0
    39f4:      	b.ne	0x39cc <_stogir.vector.validate+0x59c>
    39f8:      	lsr	w23, w23, #0
    39fc:      	add	x16, sp, #0x40
    3a00:      	ldr	w0, [x16, #0x4]
    3a04:      	add	x16, sp, #0x40
    3a08:      	ldr	w1, [x16, #0x8]
    3a0c:      	lsr	w0, w0, #0
    3a10:      	add	x16, sp, #0x40
    3a14:      	ldr	w2, [x16, #0xc]
    3a18:      	lsr	w1, w1, #0
    3a1c:      	lsr	w2, w2, #0
    3a20:      	add	x8, sp, #0x150
    3a24:      	mov	w3, w1
    3a28:      	mov	w1, w23
    3a2c:      	mov	w4, w2
    3a30:      	mov	w2, w0
    3a34:      	mov	x0, x21
    3a38:      	bl	0x3a38 <_stogir.vector.validate+0x608>
		0000000000003a38:  ARM64_RELOC_BRANCH26	_stogir.vector.store-inputs
    3a3c:      	add	x16, sp, #0x150
    3a40:      	ldr	x0, [x16]
    3a44:      	add	x16, sp, #0x150
    3a48:      	ldr	x1, [x16, #0x8]
    3a4c:      	add	x16, sp, #0x150
    3a50:      	ldr	x2, [x16, #0x10]
    3a54:      	b	0x39e4 <_stogir.vector.validate+0x5b4>
    3a58:      	mov	x2, x8
    3a5c:      	mov	x0, #0x1                ; =1
    3a60:      	b	0x39e4 <_stogir.vector.validate+0x5b4>
    3a64:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x2ec>
		0000000000003a64:  ARM64_RELOC_PAGE21	l_stogir.347
    3a68:      	ldr	x16, [x16]
		0000000000003a68:  ARM64_RELOC_PAGEOFF12	l_stogir.347
    3a6c:      	orr	x0, x16, xzr
    3a70:      	mov	x1, x0
    3a74:      	mov	x0, #0x1                ; =1
    3a78:      	mov	x2, #0x28               ; =40
    3a7c:      	b	0x3a60 <_stogir.vector.validate+0x630>
    3a80:      	mov	x0, x1
    3a84:      	mov	x1, x27
    3a88:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x2ec>
		0000000000003a88:  ARM64_RELOC_PAGE21	l_stogir.348
    3a8c:      	ldr	x16, [x16]
		0000000000003a8c:  ARM64_RELOC_PAGEOFF12	l_stogir.348
    3a90:      	orr	x2, x16, xzr
    3a94:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x2ec>
		0000000000003a94:  ARM64_RELOC_PAGE21	l_stogir.349
    3a98:      	ldr	x16, [x16]
		0000000000003a98:  ARM64_RELOC_PAGEOFF12	l_stogir.349
    3a9c:      	orr	x3, x16, xzr
    3aa0:      	add	x4, x21, #0x78
    3aa4:      	add	x5, x21, #0x28
    3aa8:      	add	x6, x21, #0x50
    3aac:      	add	x7, x21, #0x78
    3ab0:      	mov	x8, x1
    3ab4:      	mov	x1, x0
    3ab8:      	mov	x0, #0x2                ; =2
    3abc:      	b	0x3b34 <_stogir.vector.validate+0x704>
    3ac0:      	lsr	w10, w10, #0
    3ac4:      	ubfx	x9, x10, #8, #8
    3ac8:      	cmp	x9, x20
    3acc:      	b.eq	0x3ad8 <_stogir.vector.validate+0x6a8>
    3ad0:      	mov	x1, x3
    3ad4:      	mov	x8, #0x1e               ; =30
    3ad8:      	b	0x3b28 <_stogir.vector.validate+0x6f8>
    3adc:      	movz	x9, #0x0, lsl #48
    3ae0:      	movz	x10, #0x0, lsl #48
    3ae4:      	b	0x3af0 <_stogir.vector.validate+0x6c0>
    3ae8:      	movz	x9, #0x0, lsl #48
    3aec:      	movz	x10, #0x0, lsl #48
    3af0:      	lsr	w9, w9, #0
    3af4:      	lsr	x16, x9, #0
    3af8:      	cmp	x16, #0x1
    3afc:      	b.eq	0x3b18 <_stogir.vector.validate+0x6e8>
    3b00:      	b.lo	0x3b08 <_stogir.vector.validate+0x6d8>
    3b04:      	b	0x3b1c <_stogir.vector.validate+0x6ec>
    3b08:      	cmp	x16, #0x0
    3b0c:      	b.eq	0x3b14 <_stogir.vector.validate+0x6e4>
    3b10:      	b	0x3b1c <_stogir.vector.validate+0x6ec>
    3b14:      	b	0x3b20 <_stogir.vector.validate+0x6f0>
    3b18:      	b	0x3b94 <_stogir.vector.validate+0x764>
    3b1c:      	b	0x3ecc <_stogir.vector.validate+0xa9c>
    3b20:      	mov	x1, x2
    3b24:      	mov	x8, #0x18               ; =24
    3b28:      	add	x0, x0, #0x1
    3b2c:      	lsr	w0, w0, #0
    3b30:      	sxtw	x0, w0
    3b34:      	cmp	x8, #0x0
    3b38:      	cset	w9, eq
    3b3c:      	uxtb	w16, w9
    3b40:      	cmp	w16, wzr
    3b44:      	b.eq	0x3ccc <_stogir.vector.validate+0x89c>
    3b48:      	cmp	x0, x28
    3b4c:      	b.gt	0x3ccc <_stogir.vector.validate+0x89c>
    3b50:      	uxtb	w16, w24
    3b54:      	cmp	w16, wzr
    3b58:      	b.ne	0x3ae8 <_stogir.vector.validate+0x6b8>
    3b5c:      	ldr	x9, [x21, #0x8]
    3b60:      	cmp	x22, x9
    3b64:      	b.ge	0x3c00 <_stogir.vector.validate+0x7d0>
    3b68:      	ldr	x9, [x7, #0x8]
    3b6c:      	cmp	x22, x9
    3b70:      	b.ge	0x3bf8 <_stogir.vector.validate+0x7c8>
    3b74:      	ldr	x9, [x21, #0x78]
    3b78:      	add	x9, x25, x9
    3b7c:      	ldr	w9, [x9]
    3b80:      	sxtw	x9, w9
    3b84:      	cmp	x9, #0x0
    3b88:      	cset	w9, ge
    3b8c:      	ubfx	x9, x9, #0, #8
    3b90:      	b	0x3bfc <_stogir.vector.validate+0x7cc>
    3b94:      	lsr	w10, w10, #0
    3b98:      	sxtw	x10, w10
    3b9c:      	cmp	x10, #0x0
    3ba0:      	cset	w9, gt
    3ba4:      	movz	x16, #0x0, lsl #48
    3ba8:      	sub	x11, x16, x10
    3bac:      	sub	x12, x11, #0x1
    3bb0:      	uxtb	w16, w9
    3bb4:      	cmp	w16, wzr
    3bb8:      	b.eq	0x3c88 <_stogir.vector.validate+0x858>
    3bbc:      	ldr	x11, [x21, #0x8]
    3bc0:      	cmp	x10, x11
    3bc4:      	b.ge	0x3d04 <_stogir.vector.validate+0x8d4>
    3bc8:      	ldr	x11, [x4, #0x8]
    3bcc:      	cmp	x10, x11
    3bd0:      	b.ge	0x3e18 <_stogir.vector.validate+0x9e8>
    3bd4:      	lsl	x11, x10, #2
    3bd8:      	ldr	x13, [x21, #0x78]
    3bdc:      	add	x11, x11, x13
    3be0:      	ldr	w11, [x11]
    3be4:      	sxtw	x11, w11
    3be8:      	cmp	x11, #0x0
    3bec:      	cset	w11, ge
    3bf0:      	ubfx	x11, x11, #0, #8
    3bf4:      	b	0x3e1c <_stogir.vector.validate+0x9ec>
    3bf8:      	movz	x9, #0x0, lsl #48
    3bfc:      	b	0x3c04 <_stogir.vector.validate+0x7d4>
    3c00:      	movz	x9, #0x0, lsl #48
    3c04:      	cmp	x9, #0x0
    3c08:      	b.eq	0x3ae8 <_stogir.vector.validate+0x6b8>
    3c0c:      	lsr	w9, w0, #0
    3c10:      	sxtw	x9, w9
    3c14:      	cmp	x9, #0x1
    3c18:      	b.lt	0x3adc <_stogir.vector.validate+0x6ac>
    3c1c:      	ldr	x10, [x21, #0x78]
    3c20:      	add	x10, x25, x10
    3c24:      	ldr	w10, [x10]
    3c28:      	sxtw	x10, w10
    3c2c:      	cmp	x9, x10
    3c30:      	b.gt	0x3adc <_stogir.vector.validate+0x6ac>
    3c34:      	ldr	x10, [x21]
    3c38:      	asr	x16, x9, #63
    3c3c:      	lsr	x16, x16, #62
    3c40:      	add	x11, x9, x16
    3c44:      	asr	x11, x11, #2
    3c48:      	asr	x16, x9, #63
    3c4c:      	lsr	x16, x16, #62
    3c50:      	add	x9, x9, x16
    3c54:      	and	x9, x9, #0x3
    3c58:      	sub	x9, x9, x16
    3c5c:      	add	x11, x11, x22
    3c60:      	lsl	x9, x9, #2
    3c64:      	lsl	x11, x11, #4
    3c68:      	add	x10, x11, x10
    3c6c:      	add	x9, x9, x10
    3c70:      	ldr	w9, [x9]
    3c74:      	sxtw	x9, w9
    3c78:      	and	x9, x9, #0xffffffff
    3c7c:      	mov	x10, x9
    3c80:      	mov	x9, #0x1                ; =1
    3c84:      	b	0x3ae4 <_stogir.vector.validate+0x6b4>
    3c88:      	cmp	x10, #0x0
    3c8c:      	b.ge	0x3d0c <_stogir.vector.validate+0x8dc>
    3c90:      	ldr	x13, [x5, #0x8]
    3c94:      	ldr	x14, [x6, #0x8]
    3c98:      	cmp	x13, x14
    3c9c:      	b.ne	0x3e10 <_stogir.vector.validate+0x9e0>
    3ca0:      	cmp	x11, x13
    3ca4:      	b.gt	0x3e48 <_stogir.vector.validate+0xa18>
    3ca8:      	lsl	x11, x12, #2
    3cac:      	ldr	x13, [x21, #0x50]
    3cb0:      	add	x11, x11, x13
    3cb4:      	ldr	w11, [x11]
    3cb8:      	sxtw	x11, w11
    3cbc:      	cmp	x11, #0x0
    3cc0:      	cset	w11, gt
    3cc4:      	ubfx	x11, x11, #0, #8
    3cc8:      	b	0x3e4c <_stogir.vector.validate+0xa1c>
    3ccc:      	uxtb	w16, w9
    3cd0:      	cmp	w16, wzr
    3cd4:      	b.eq	0x3a58 <_stogir.vector.validate+0x628>
    3cd8:      	lsr	w23, w23, #0
    3cdc:      	mov	w0, w19
    3ce0:      	mov	w1, w23
    3ce4:      	bl	0x3ce4 <_stogir.vector.validate+0x8b4>
		0000000000003ce4:  ARM64_RELOC_BRANCH26	_stogir.types.size
    3ce8:      	lsr	w0, w0, #0
    3cec:      	sxtw	x0, w0
    3cf0:      	and	x0, x0, #0xffffffff
    3cf4:      	mov	x1, x0
    3cf8:      	movz	x0, #0x0, lsl #48
    3cfc:      	movz	x2, #0x0, lsl #48
    3d00:      	b	0x3a60 <_stogir.vector.validate+0x630>
    3d04:      	movz	x11, #0x0, lsl #48
    3d08:      	b	0x3d10 <_stogir.vector.validate+0x8e0>
    3d0c:      	movz	x11, #0x0, lsl #48
    3d10:      	cmp	x11, #0x0
    3d14:      	b.eq	0x3d54 <_stogir.vector.validate+0x924>
    3d18:      	uxtb	w16, w9
    3d1c:      	cmp	w16, wzr
    3d20:      	b.eq	0x3d38 <_stogir.vector.validate+0x908>
    3d24:      	lsl	x9, x10, #4
    3d28:      	ldr	x10, [x21]
    3d2c:      	add	x9, x9, x10
    3d30:      	ldr	x9, [x9]
    3d34:      	b	0x3d48 <_stogir.vector.validate+0x918>
    3d38:      	lsl	x9, x12, #4
    3d3c:      	ldr	x10, [x21, #0x28]
    3d40:      	add	x9, x9, x10
    3d44:      	ldr	x9, [x9]
    3d48:      	mov	x10, x9
    3d4c:      	mov	x9, #0x1                ; =1
    3d50:      	b	0x3d5c <_stogir.vector.validate+0x92c>
    3d54:      	movz	x9, #0x0, lsl #48
    3d58:      	movz	x10, #0x0, lsl #48
    3d5c:      	lsr	w9, w9, #0
    3d60:      	lsr	x16, x9, #0
    3d64:      	cmp	x16, #0x1
    3d68:      	b.eq	0x3d84 <_stogir.vector.validate+0x954>
    3d6c:      	b.lo	0x3d74 <_stogir.vector.validate+0x944>
    3d70:      	b	0x3d88 <_stogir.vector.validate+0x958>
    3d74:      	cmp	x16, #0x0
    3d78:      	b.eq	0x3d80 <_stogir.vector.validate+0x950>
    3d7c:      	b	0x3d88 <_stogir.vector.validate+0x958>
    3d80:      	b	0x3d8c <_stogir.vector.validate+0x95c>
    3d84:      	b	0x3ac0 <_stogir.vector.validate+0x690>
    3d88:      	b	0x3ed4 <_stogir.vector.validate+0xaa4>
    3d8c:      	mov	x1, x2
    3d90:      	mov	x8, #0x18               ; =24
    3d94:      	b	0x3ad8 <_stogir.vector.validate+0x6a8>
    3d98:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x2ec>
		0000000000003d98:  ARM64_RELOC_PAGE21	l_stogir.350
    3d9c:      	ldr	x16, [x16]
		0000000000003d9c:  ARM64_RELOC_PAGEOFF12	l_stogir.350
    3da0:      	orr	x0, x16, xzr
    3da4:      	mov	x26, x0
    3da8:      	mov	x27, #0x20              ; =32
    3dac:      	add	x16, sp, #0x40
    3db0:      	ldr	w0, [x16, #0x4]
    3db4:      	lsr	w0, w0, #0
    3db8:      	add	x8, sp, #0x170
    3dbc:      	mov	w1, w0
    3dc0:      	mov	x0, x21
    3dc4:      	bl	0x3dc4 <_stogir.vector.validate+0x994>
		0000000000003dc4:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    3dc8:      	add	x16, sp, #0x170
    3dcc:      	ldr	w0, [x16]
    3dd0:      	lsr	x16, x0, #0
    3dd4:      	cmp	x16, #0x1
    3dd8:      	b.eq	0x3df4 <_stogir.vector.validate+0x9c4>
    3ddc:      	b.lo	0x3de4 <_stogir.vector.validate+0x9b4>
    3de0:      	b	0x3df8 <_stogir.vector.validate+0x9c8>
    3de4:      	cmp	x16, #0x0
    3de8:      	b.eq	0x3df0 <_stogir.vector.validate+0x9c0>
    3dec:      	b	0x3df8 <_stogir.vector.validate+0x9c8>
    3df0:      	b	0x3dfc <_stogir.vector.validate+0x9cc>
    3df4:      	b	0x3e20 <_stogir.vector.validate+0x9f0>
    3df8:      	b	0x3edc <_stogir.vector.validate+0xaac>
    3dfc:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x2ec>
		0000000000003dfc:  ARM64_RELOC_PAGE21	l_stogir.351
    3e00:      	ldr	x16, [x16]
		0000000000003e00:  ARM64_RELOC_PAGEOFF12	l_stogir.351
    3e04:      	orr	x0, x16, xzr
    3e08:      	mov	x1, #0x19               ; =25
    3e0c:      	b	0x3a88 <_stogir.vector.validate+0x658>
    3e10:      	movz	x11, #0x0, lsl #48
    3e14:      	b	0x3d10 <_stogir.vector.validate+0x8e0>
    3e18:      	movz	x11, #0x0, lsl #48
    3e1c:      	b	0x3d08 <_stogir.vector.validate+0x8d8>
    3e20:      	add	x16, sp, #0x170
    3e24:      	ldr	x0, [x16, #0x8]
    3e28:      	add	x16, sp, #0x40
    3e2c:      	ldr	w1, [x16, #0x4]
    3e30:      	sxtw	x1, w1
    3e34:      	cmp	x1, #0x0
    3e38:      	b.gt	0x3eb0 <_stogir.vector.validate+0xa80>
    3e3c:      	mov	x1, x26
    3e40:      	mov	x0, #0x1                ; =1
    3e44:      	b	0x3e94 <_stogir.vector.validate+0xa64>
    3e48:      	movz	x11, #0x0, lsl #48
    3e4c:      	b	0x3e14 <_stogir.vector.validate+0x9e4>
    3e50:      	add	x16, sp, #0x40
    3e54:      	ldr	w0, [x16, #0x4]
    3e58:      	sxtw	x0, w0
    3e5c:      	ldr	x1, [x21, #0x78]
    3e60:      	lsl	x0, x0, #2
    3e64:      	add	x0, x0, x1
    3e68:      	ldr	w0, [x0]
    3e6c:      	sxtw	x0, w0
    3e70:      	add	x0, x0, #0x1
    3e74:      	lsr	w0, w0, #0
    3e78:      	sxtw	x0, w0
    3e7c:      	cmp	x28, x0
    3e80:      	cset	w0, eq
    3e84:      	uxtb	w16, w0
    3e88:      	cmp	w16, wzr
    3e8c:      	cset	x0, eq
    3e90:      	mov	x1, x26
    3e94:      	cmp	x0, #0x0
    3e98:      	b.eq	0x3a80 <_stogir.vector.validate+0x650>
    3e9c:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x2ec>
		0000000000003e9c:  ARM64_RELOC_PAGE21	l_stogir.352
    3ea0:      	ldr	x16, [x16]
		0000000000003ea0:  ARM64_RELOC_PAGEOFF12	l_stogir.352
    3ea4:      	orr	x0, x16, xzr
    3ea8:      	mov	x1, #0x19               ; =25
    3eac:      	b	0x3a88 <_stogir.vector.validate+0x658>
    3eb0:      	uxtb	w0, w0
    3eb4:      	cmp	x0, #0x70
    3eb8:      	b.eq	0x3e50 <_stogir.vector.validate+0xa20>
    3ebc:      	cmp	x0, #0x71
    3ec0:      	b.eq	0x3e50 <_stogir.vector.validate+0xa20>
    3ec4:      	mov	x0, #0x1                ; =1
    3ec8:      	b	0x3e90 <_stogir.vector.validate+0xa60>
    3ecc:      	brk	#0
    3ed0:      	b	0x3ecc <_stogir.vector.validate+0xa9c>
    3ed4:      	brk	#0
    3ed8:      	b	0x3ed4 <_stogir.vector.validate+0xaa4>
    3edc:      	brk	#0
    3ee0:      	b	0x3edc <_stogir.vector.validate+0xaac>
    3ee4:      	str	x20, [sp, #0x1a8]
    3ee8:      	str	w19, [sp, #0x1a0]
    3eec:      	b	0x35ec <_stogir.vector.validate+0x1bc>
    3ef0:      	str	x20, [sp, #0x1a8]
    3ef4:      	str	w19, [sp, #0x1a0]
    3ef8:      	mov	w19, w0
    3efc:      	mov	w20, w1
    3f00:      	str	w2, [sp, #0x1b0]
    3f04:      	str	w3, [sp, #0x1b8]
    3f08:      	b	0x36a8 <_stogir.vector.validate+0x278>

0000000000003f0c <_stogir.copy.validate>:
    3f0c:      	sub	sp, sp, #0x40
    3f10:      	str	x29, [sp]
    3f14:      	str	x30, [sp, #0x8]
    3f18:      	mov	x29, sp
    3f1c:      	str	x19, [sp, #0x20]
    3f20:      	str	x20, [sp, #0x28]
    3f24:      	str	x21, [sp, #0x30]
    3f28:      	sxtw	x1, w1
    3f2c:      	lsl	x2, x1, #2
    3f30:      	cmp	x1, #0x0
    3f34:      	cset	w3, gt
    3f38:      	movz	x16, #0x0, lsl #48
    3f3c:      	sub	x4, x16, x1
    3f40:      	sub	x5, x4, #0x1
    3f44:      	uxtb	w16, w3
    3f48:      	cmp	w16, wzr
    3f4c:      	b.eq	0x3f8c <_stogir.copy.validate+0x80>
    3f50:      	ldr	x4, [x0, #0x8]
    3f54:      	cmp	x1, x4
    3f58:      	b.ge	0x3fe0 <_stogir.copy.validate+0xd4>
    3f5c:      	add	x4, x0, #0x78
    3f60:      	ldr	x4, [x4, #0x8]
    3f64:      	cmp	x1, x4
    3f68:      	b.ge	0x410c <_stogir.copy.validate+0x200>
    3f6c:      	ldr	x4, [x0, #0x78]
    3f70:      	add	x4, x2, x4
    3f74:      	ldr	w4, [x4]
    3f78:      	sxtw	x4, w4
    3f7c:      	cmp	x4, #0x0
    3f80:      	cset	w4, ge
    3f84:      	ubfx	x4, x4, #0, #8
    3f88:      	b	0x4110 <_stogir.copy.validate+0x204>
    3f8c:      	cmp	x1, #0x0
    3f90:      	b.ge	0x3fe8 <_stogir.copy.validate+0xdc>
    3f94:      	add	x6, x0, #0x28
    3f98:      	add	x7, x0, #0x50
    3f9c:      	ldr	x6, [x6, #0x8]
    3fa0:      	ldr	x7, [x7, #0x8]
    3fa4:      	cmp	x6, x7
    3fa8:      	b.ne	0x3fd8 <_stogir.copy.validate+0xcc>
    3fac:      	cmp	x4, x6
    3fb0:      	b.gt	0x4154 <_stogir.copy.validate+0x248>
    3fb4:      	lsl	x4, x5, #2
    3fb8:      	ldr	x6, [x0, #0x50]
    3fbc:      	add	x4, x4, x6
    3fc0:      	ldr	w4, [x4]
    3fc4:      	sxtw	x4, w4
    3fc8:      	cmp	x4, #0x0
    3fcc:      	cset	w4, gt
    3fd0:      	ubfx	x4, x4, #0, #8
    3fd4:      	b	0x4158 <_stogir.copy.validate+0x24c>
    3fd8:      	movz	x4, #0x0, lsl #48
    3fdc:      	b	0x3fec <_stogir.copy.validate+0xe0>
    3fe0:      	movz	x4, #0x0, lsl #48
    3fe4:      	b	0x3fec <_stogir.copy.validate+0xe0>
    3fe8:      	movz	x4, #0x0, lsl #48
    3fec:      	cmp	x4, #0x0
    3ff0:      	b.eq	0x4054 <_stogir.copy.validate+0x148>
    3ff4:      	uxtb	w16, w3
    3ff8:      	cmp	w16, wzr
    3ffc:      	b.eq	0x4024 <_stogir.copy.validate+0x118>
    4000:      	lsl	x3, x1, #4
    4004:      	ldr	x4, [x0]
    4008:      	add	x3, x3, x4
    400c:      	ldr	x4, [x3]
    4010:      	ldr	x3, [x3, #0x8]
    4014:      	fmov	d31, x3
    4018:      	mov	x3, x4
    401c:      	fmov	x4, d31
    4020:      	b	0x4044 <_stogir.copy.validate+0x138>
    4024:      	lsl	x3, x5, #4
    4028:      	ldr	x4, [x0, #0x28]
    402c:      	add	x3, x3, x4
    4030:      	ldr	x4, [x3]
    4034:      	ldr	x3, [x3, #0x8]
    4038:      	fmov	d31, x3
    403c:      	mov	x3, x4
    4040:      	fmov	x4, d31
    4044:      	mov	x5, x4
    4048:      	mov	x4, x3
    404c:      	mov	x3, #0x1                ; =1
    4050:      	b	0x4060 <_stogir.copy.validate+0x154>
    4054:      	movz	x3, #0x0, lsl #48
    4058:      	movz	x4, #0x0, lsl #48
    405c:      	movz	x5, #0x0, lsl #48
    4060:      	lsr	w3, w3, #0
    4064:      	lsr	x16, x3, #0
    4068:      	cmp	x16, #0x1
    406c:      	b.eq	0x4088 <_stogir.copy.validate+0x17c>
    4070:      	b.lo	0x4078 <_stogir.copy.validate+0x16c>
    4074:      	b	0x408c <_stogir.copy.validate+0x180>
    4078:      	cmp	x16, #0x0
    407c:      	b.eq	0x4084 <_stogir.copy.validate+0x178>
    4080:      	b	0x408c <_stogir.copy.validate+0x180>
    4084:      	b	0x4090 <_stogir.copy.validate+0x184>
    4088:      	b	0x40d4 <_stogir.copy.validate+0x1c8>
    408c:      	b	0x41e4 <_stogir.copy.validate+0x2d8>
    4090:      	adrp	x16, 0x4000 <_stogir.copy.validate+0xf4>
		0000000000004090:  ARM64_RELOC_PAGE21	l_stogir.353
    4094:      	ldr	x16, [x16]
		0000000000004094:  ARM64_RELOC_PAGEOFF12	l_stogir.353
    4098:      	orr	x0, x16, xzr
    409c:      	mov	x20, x8
    40a0:      	mov	x1, x0
    40a4:      	mov	x0, #0x1                ; =1
    40a8:      	mov	x2, #0x18               ; =24
    40ac:      	str	x0, [x20]
    40b0:      	str	x1, [x20, #0x8]
    40b4:      	str	x2, [x20, #0x10]
    40b8:      	ldr	x19, [sp, #0x20]
    40bc:      	ldr	x20, [sp, #0x28]
    40c0:      	ldr	x21, [sp, #0x30]
    40c4:      	ldr	x29, [sp]
    40c8:      	ldr	x30, [sp, #0x8]
    40cc:      	add	sp, sp, #0x40
    40d0:      	ret
    40d4:      	add	x16, sp, #0x10
    40d8:      	str	x4, [x16]
    40dc:      	add	x16, sp, #0x10
    40e0:      	str	x5, [x16, #0x8]
    40e4:      	cmp	x1, #0x0
    40e8:      	b.gt	0x4114 <_stogir.copy.validate+0x208>
    40ec:      	mov	x20, x8
    40f0:      	adrp	x16, 0x4000 <_stogir.copy.validate+0xf4>
		00000000000040f0:  ARM64_RELOC_PAGE21	l_stogir.354
    40f4:      	ldr	x16, [x16]
		00000000000040f4:  ARM64_RELOC_PAGEOFF12	l_stogir.354
    40f8:      	orr	x0, x16, xzr
    40fc:      	mov	x1, x0
    4100:      	mov	x0, #0x1                ; =1
    4104:      	mov	x2, #0x21               ; =33
    4108:      	b	0x40ac <_stogir.copy.validate+0x1a0>
    410c:      	movz	x4, #0x0, lsl #48
    4110:      	b	0x3fe4 <_stogir.copy.validate+0xd8>
    4114:      	uxtb	w1, w4
    4118:      	cmp	x1, #0x44
    411c:      	b.ne	0x4348 <_stogir.copy.validate+0x43c>
    4120:      	ldr	x1, [x0, #0x78]
    4124:      	add	x1, x2, x1
    4128:      	ldr	w1, [x1]
    412c:      	sxtw	x1, w1
    4130:      	cmp	x1, #0x2
    4134:      	b.ne	0x4350 <_stogir.copy.validate+0x444>
    4138:      	lsr	w4, w4, #0
    413c:      	ubfx	x1, x4, #8, #8
    4140:      	orr	x19, x1, xzr
    4144:      	cmp	x19, #0x0
    4148:      	b.ne	0x415c <_stogir.copy.validate+0x250>
    414c:      	mov	x20, x8
    4150:      	b	0x40f0 <_stogir.copy.validate+0x1e4>
    4154:      	movz	x4, #0x0, lsl #48
    4158:      	b	0x3fdc <_stogir.copy.validate+0xd0>
    415c:      	lsr	w1, w1, #0
    4160:      	mov	x20, x8
    4164:      	mov	x21, x0
    4168:      	mov	w0, w1
    416c:      	bl	0x416c <_stogir.copy.validate+0x260>
		000000000000416c:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
    4170:      	cmp	x0, #0x0
    4174:      	b.eq	0x40f0 <_stogir.copy.validate+0x1e4>
    4178:      	add	x16, sp, #0x10
    417c:      	ldr	w0, [x16, #0x4]
    4180:      	sxtw	x0, w0
    4184:      	cmp	x0, #0x0
    4188:      	cset	w1, gt
    418c:      	movz	x16, #0x0, lsl #48
    4190:      	sub	x2, x16, x0
    4194:      	sub	x3, x2, #0x1
    4198:      	uxtb	w16, w1
    419c:      	cmp	w16, wzr
    41a0:      	b.eq	0x4208 <_stogir.copy.validate+0x2fc>
    41a4:      	ldr	x2, [x21, #0x8]
    41a8:      	cmp	x0, x2
    41ac:      	b.ge	0x4254 <_stogir.copy.validate+0x348>
    41b0:      	add	x2, x21, #0x78
    41b4:      	ldr	x2, [x2, #0x8]
    41b8:      	cmp	x0, x2
    41bc:      	b.ge	0x4330 <_stogir.copy.validate+0x424>
    41c0:      	lsl	x2, x0, #2
    41c4:      	ldr	x4, [x21, #0x78]
    41c8:      	add	x2, x2, x4
    41cc:      	ldr	w2, [x2]
    41d0:      	sxtw	x2, w2
    41d4:      	cmp	x2, #0x0
    41d8:      	cset	w2, ge
    41dc:      	ubfx	x2, x2, #0, #8
    41e0:      	b	0x4334 <_stogir.copy.validate+0x428>
    41e4:      	brk	#0
    41e8:      	b	0x41e4 <_stogir.copy.validate+0x2d8>
    41ec:      	adrp	x16, 0x4000 <_stogir.copy.validate+0xf4>
		00000000000041ec:  ARM64_RELOC_PAGE21	l_stogir.355
    41f0:      	ldr	x16, [x16]
		00000000000041f0:  ARM64_RELOC_PAGEOFF12	l_stogir.355
    41f4:      	orr	x0, x16, xzr
    41f8:      	mov	x1, x0
    41fc:      	mov	x0, #0x1                ; =1
    4200:      	mov	x2, #0x20               ; =32
    4204:      	b	0x4108 <_stogir.copy.validate+0x1fc>
    4208:      	cmp	x0, #0x0
    420c:      	b.ge	0x425c <_stogir.copy.validate+0x350>
    4210:      	add	x4, x21, #0x28
    4214:      	add	x5, x21, #0x50
    4218:      	ldr	x4, [x4, #0x8]
    421c:      	ldr	x5, [x5, #0x8]
    4220:      	cmp	x4, x5
    4224:      	b.ne	0x4328 <_stogir.copy.validate+0x41c>
    4228:      	cmp	x2, x4
    422c:      	b.gt	0x4338 <_stogir.copy.validate+0x42c>
    4230:      	lsl	x2, x3, #2
    4234:      	ldr	x4, [x21, #0x50]
    4238:      	add	x2, x2, x4
    423c:      	ldr	w2, [x2]
    4240:      	sxtw	x2, w2
    4244:      	cmp	x2, #0x0
    4248:      	cset	w2, gt
    424c:      	ubfx	x2, x2, #0, #8
    4250:      	b	0x433c <_stogir.copy.validate+0x430>
    4254:      	movz	x2, #0x0, lsl #48
    4258:      	b	0x4260 <_stogir.copy.validate+0x354>
    425c:      	movz	x2, #0x0, lsl #48
    4260:      	cmp	x2, #0x0
    4264:      	b.eq	0x42a4 <_stogir.copy.validate+0x398>
    4268:      	uxtb	w16, w1
    426c:      	cmp	w16, wzr
    4270:      	b.eq	0x4288 <_stogir.copy.validate+0x37c>
    4274:      	lsl	x0, x0, #4
    4278:      	ldr	x1, [x21]
    427c:      	add	x0, x0, x1
    4280:      	ldr	x0, [x0]
    4284:      	b	0x4298 <_stogir.copy.validate+0x38c>
    4288:      	lsl	x0, x3, #4
    428c:      	ldr	x1, [x21, #0x28]
    4290:      	add	x0, x0, x1
    4294:      	ldr	x0, [x0]
    4298:      	mov	x1, x0
    429c:      	mov	x0, #0x1                ; =1
    42a0:      	b	0x42ac <_stogir.copy.validate+0x3a0>
    42a4:      	movz	x0, #0x0, lsl #48
    42a8:      	movz	x1, #0x0, lsl #48
    42ac:      	lsr	w0, w0, #0
    42b0:      	lsr	x16, x0, #0
    42b4:      	cmp	x16, #0x1
    42b8:      	b.eq	0x42d4 <_stogir.copy.validate+0x3c8>
    42bc:      	b.lo	0x42c4 <_stogir.copy.validate+0x3b8>
    42c0:      	b	0x42d8 <_stogir.copy.validate+0x3cc>
    42c4:      	cmp	x16, #0x0
    42c8:      	b.eq	0x42d0 <_stogir.copy.validate+0x3c4>
    42cc:      	b	0x42d8 <_stogir.copy.validate+0x3cc>
    42d0:      	b	0x42dc <_stogir.copy.validate+0x3d0>
    42d4:      	b	0x42f8 <_stogir.copy.validate+0x3ec>
    42d8:      	b	0x4340 <_stogir.copy.validate+0x434>
    42dc:      	adrp	x16, 0x4000 <_stogir.copy.validate+0xf4>
		00000000000042dc:  ARM64_RELOC_PAGE21	l_stogir.356
    42e0:      	ldr	x16, [x16]
		00000000000042e0:  ARM64_RELOC_PAGEOFF12	l_stogir.356
    42e4:      	orr	x0, x16, xzr
    42e8:      	mov	x1, x0
    42ec:      	mov	x0, #0x1                ; =1
    42f0:      	mov	x2, #0x13               ; =19
    42f4:      	b	0x4204 <_stogir.copy.validate+0x2f8>
    42f8:      	lsr	w1, w1, #0
    42fc:      	add	x16, sp, #0x10
    4300:      	ldr	w0, [x16]
    4304:      	ubfx	x1, x1, #8, #8
    4308:      	ubfx	x0, x0, #8, #8
    430c:      	cmp	x1, x0
    4310:      	b.ne	0x41ec <_stogir.copy.validate+0x2e0>
    4314:      	and	x0, x19, #0xffffffff
    4318:      	mov	x1, x0
    431c:      	movz	x0, #0x0, lsl #48
    4320:      	movz	x2, #0x0, lsl #48
    4324:      	b	0x4204 <_stogir.copy.validate+0x2f8>
    4328:      	movz	x2, #0x0, lsl #48
    432c:      	b	0x4260 <_stogir.copy.validate+0x354>
    4330:      	movz	x2, #0x0, lsl #48
    4334:      	b	0x4258 <_stogir.copy.validate+0x34c>
    4338:      	movz	x2, #0x0, lsl #48
    433c:      	b	0x432c <_stogir.copy.validate+0x420>
    4340:      	brk	#0
    4344:      	b	0x4340 <_stogir.copy.validate+0x434>
    4348:      	mov	x20, x8
    434c:      	b	0x40f0 <_stogir.copy.validate+0x1e4>
    4350:      	mov	x20, x8
    4354:      	b	0x40f0 <_stogir.copy.validate+0x1e4>

0000000000004358 <_stogir.graph.lookup>:
    4358:      	sxtw	x1, w1
    435c:      	cmp	x1, #0x0
    4360:      	cset	w2, gt
    4364:      	movz	x16, #0x0, lsl #48
    4368:      	sub	x3, x16, x1
    436c:      	sub	x4, x3, #0x1
    4370:      	uxtb	w16, w2
    4374:      	cmp	w16, wzr
    4378:      	b.eq	0x43bc <_stogir.graph.lookup+0x64>
    437c:      	ldr	x3, [x0, #0x8]
    4380:      	cmp	x1, x3
    4384:      	b.ge	0x4410 <_stogir.graph.lookup+0xb8>
    4388:      	add	x3, x0, #0x78
    438c:      	ldr	x3, [x3, #0x8]
    4390:      	cmp	x1, x3
    4394:      	b.ge	0x44b0 <_stogir.graph.lookup+0x158>
    4398:      	lsl	x3, x1, #2
    439c:      	ldr	x5, [x0, #0x78]
    43a0:      	add	x3, x3, x5
    43a4:      	ldr	w3, [x3]
    43a8:      	sxtw	x3, w3
    43ac:      	cmp	x3, #0x0
    43b0:      	cset	w3, ge
    43b4:      	ubfx	x3, x3, #0, #8
    43b8:      	b	0x44b4 <_stogir.graph.lookup+0x15c>
    43bc:      	cmp	x1, #0x0
    43c0:      	b.ge	0x4418 <_stogir.graph.lookup+0xc0>
    43c4:      	add	x5, x0, #0x28
    43c8:      	add	x6, x0, #0x50
    43cc:      	ldr	x5, [x5, #0x8]
    43d0:      	ldr	x6, [x6, #0x8]
    43d4:      	cmp	x5, x6
    43d8:      	b.ne	0x4408 <_stogir.graph.lookup+0xb0>
    43dc:      	cmp	x3, x5
    43e0:      	b.gt	0x44b8 <_stogir.graph.lookup+0x160>
    43e4:      	lsl	x3, x4, #2
    43e8:      	ldr	x5, [x0, #0x50]
    43ec:      	add	x3, x3, x5
    43f0:      	ldr	w3, [x3]
    43f4:      	sxtw	x3, w3
    43f8:      	cmp	x3, #0x0
    43fc:      	cset	w3, gt
    4400:      	ubfx	x3, x3, #0, #8
    4404:      	b	0x44bc <_stogir.graph.lookup+0x164>
    4408:      	movz	x3, #0x0, lsl #48
    440c:      	b	0x441c <_stogir.graph.lookup+0xc4>
    4410:      	movz	x3, #0x0, lsl #48
    4414:      	b	0x441c <_stogir.graph.lookup+0xc4>
    4418:      	movz	x3, #0x0, lsl #48
    441c:      	cmp	x3, #0x0
    4420:      	b.eq	0x4484 <_stogir.graph.lookup+0x12c>
    4424:      	uxtb	w16, w2
    4428:      	cmp	w16, wzr
    442c:      	b.eq	0x4454 <_stogir.graph.lookup+0xfc>
    4430:      	lsl	x1, x1, #4
    4434:      	ldr	x0, [x0]
    4438:      	add	x0, x1, x0
    443c:      	ldr	x1, [x0]
    4440:      	ldr	x0, [x0, #0x8]
    4444:      	fmov	d31, x0
    4448:      	mov	x0, x1
    444c:      	fmov	x1, d31
    4450:      	b	0x4474 <_stogir.graph.lookup+0x11c>
    4454:      	lsl	x1, x4, #4
    4458:      	ldr	x0, [x0, #0x28]
    445c:      	add	x0, x1, x0
    4460:      	ldr	x1, [x0]
    4464:      	ldr	x0, [x0, #0x8]
    4468:      	fmov	d31, x0
    446c:      	mov	x0, x1
    4470:      	fmov	x1, d31
    4474:      	mov	x2, x1
    4478:      	mov	x1, x0
    447c:      	mov	x0, #0x1                ; =1
    4480:      	b	0x4490 <_stogir.graph.lookup+0x138>
    4484:      	movz	x0, #0x0, lsl #48
    4488:      	movz	x1, #0x0, lsl #48
    448c:      	movz	x2, #0x0, lsl #48
    4490:      	str	x0, [x8]
    4494:      	str	x1, [x8, #0x8]
    4498:      	str	x2, [x8, #0x10]
    449c:      	movz	x17, #0x0, lsl #48
    44a0:      	str	x17, [x8, #0x18]
    44a4:      	movz	x17, #0x0, lsl #48
    44a8:      	str	x17, [x8, #0x20]
    44ac:      	ret
    44b0:      	movz	x3, #0x0, lsl #48
    44b4:      	b	0x4414 <_stogir.graph.lookup+0xbc>
    44b8:      	movz	x3, #0x0, lsl #48
    44bc:      	b	0x440c <_stogir.graph.lookup+0xb4>

00000000000044c0 <_stogir.opcode.block-start?>:
    44c0:      	sxtw	x0, w0
    44c4:      	cmp	x0, #0x0
    44c8:      	b.lt	0x44f0 <_stogir.opcode.block-start?+0x30>
    44cc:      	cmp	x0, #0x83
    44d0:      	b.ge	0x44f0 <_stogir.opcode.block-start?+0x30>
    44d4:      	adrp	x16, 0x4000 <_stogir.copy.validate+0xf4>
		00000000000044d4:  ARM64_RELOC_PAGE21	l_stogir.357
    44d8:      	ldr	x16, [x16]
		00000000000044d8:  ARM64_RELOC_PAGEOFF12	l_stogir.357
    44dc:      	orr	x1, x16, xzr
    44e0:      	lsr	x0, x0, #0
    44e4:      	add	x0, x0, x1
    44e8:      	ldrb	w0, [x0]
    44ec:      	b	0x44f4 <_stogir.opcode.block-start?+0x34>
    44f0:      	movz	x0, #0x0, lsl #48
    44f4:      	uxtb	w0, w0
    44f8:      	and	x0, x0, #0x2
    44fc:      	uxtb	w0, w0
    4500:      	cmp	x0, #0x0
    4504:      	cset	w0, eq
    4508:      	uxtb	w16, w0
    450c:      	cmp	w16, wzr
    4510:      	cset	x0, eq
    4514:      	ret

0000000000004518 <_stogir.checked.operation?>:
    4518:      	sxtw	x0, w0
    451c:      	cmp	x0, #0x29
    4520:      	b.lt	0x4534 <_stogir.checked.operation?+0x1c>
    4524:      	cmp	x0, #0x2b
    4528:      	cset	w0, le
    452c:      	ubfx	x0, x0, #0, #8
    4530:      	b	0x4538 <_stogir.checked.operation?+0x20>
    4534:      	movz	x0, #0x0, lsl #48
    4538:      	ret

000000000000453c <_stogir.checked.validate-projection>:
    453c:      	sub	sp, sp, #0x40
    4540:      	str	x29, [sp]
    4544:      	str	x30, [sp, #0x8]
    4548:      	mov	x29, sp
    454c:      	str	x19, [sp, #0x30]
    4550:      	sxtw	x1, w1
    4554:      	lsl	x2, x1, #2
    4558:      	cmp	x1, #0x0
    455c:      	cset	w3, gt
    4560:      	movz	x16, #0x0, lsl #48
    4564:      	sub	x4, x16, x1
    4568:      	sub	x5, x4, #0x1
    456c:      	uxtb	w16, w3
    4570:      	cmp	w16, wzr
    4574:      	b.eq	0x45b4 <_stogir.checked.validate-projection+0x78>
    4578:      	ldr	x4, [x0, #0x8]
    457c:      	cmp	x1, x4
    4580:      	b.ge	0x4608 <_stogir.checked.validate-projection+0xcc>
    4584:      	add	x4, x0, #0x78
    4588:      	ldr	x4, [x4, #0x8]
    458c:      	cmp	x1, x4
    4590:      	b.ge	0x46f4 <_stogir.checked.validate-projection+0x1b8>
    4594:      	ldr	x4, [x0, #0x78]
    4598:      	add	x4, x2, x4
    459c:      	ldr	w4, [x4]
    45a0:      	sxtw	x4, w4
    45a4:      	cmp	x4, #0x0
    45a8:      	cset	w4, ge
    45ac:      	ubfx	x4, x4, #0, #8
    45b0:      	b	0x46f8 <_stogir.checked.validate-projection+0x1bc>
    45b4:      	cmp	x1, #0x0
    45b8:      	b.ge	0x4610 <_stogir.checked.validate-projection+0xd4>
    45bc:      	add	x6, x0, #0x28
    45c0:      	add	x7, x0, #0x50
    45c4:      	ldr	x6, [x6, #0x8]
    45c8:      	ldr	x7, [x7, #0x8]
    45cc:      	cmp	x6, x7
    45d0:      	b.ne	0x4600 <_stogir.checked.validate-projection+0xc4>
    45d4:      	cmp	x4, x6
    45d8:      	b.gt	0x4760 <_stogir.checked.validate-projection+0x224>
    45dc:      	lsl	x4, x5, #2
    45e0:      	ldr	x6, [x0, #0x50]
    45e4:      	add	x4, x4, x6
    45e8:      	ldr	w4, [x4]
    45ec:      	sxtw	x4, w4
    45f0:      	cmp	x4, #0x0
    45f4:      	cset	w4, gt
    45f8:      	ubfx	x4, x4, #0, #8
    45fc:      	b	0x4764 <_stogir.checked.validate-projection+0x228>
    4600:      	movz	x4, #0x0, lsl #48
    4604:      	b	0x4614 <_stogir.checked.validate-projection+0xd8>
    4608:      	movz	x4, #0x0, lsl #48
    460c:      	b	0x4614 <_stogir.checked.validate-projection+0xd8>
    4610:      	movz	x4, #0x0, lsl #48
    4614:      	cmp	x4, #0x0
    4618:      	b.eq	0x4658 <_stogir.checked.validate-projection+0x11c>
    461c:      	uxtb	w16, w3
    4620:      	cmp	w16, wzr
    4624:      	b.eq	0x463c <_stogir.checked.validate-projection+0x100>
    4628:      	lsl	x3, x1, #4
    462c:      	ldr	x4, [x0]
    4630:      	add	x3, x3, x4
    4634:      	ldr	x3, [x3]
    4638:      	b	0x464c <_stogir.checked.validate-projection+0x110>
    463c:      	lsl	x3, x5, #4
    4640:      	ldr	x4, [x0, #0x28]
    4644:      	add	x3, x3, x4
    4648:      	ldr	x3, [x3]
    464c:      	mov	x4, x3
    4650:      	mov	x3, #0x1                ; =1
    4654:      	b	0x4660 <_stogir.checked.validate-projection+0x124>
    4658:      	movz	x3, #0x0, lsl #48
    465c:      	movz	x4, #0x0, lsl #48
    4660:      	lsr	w3, w3, #0
    4664:      	lsr	x16, x3, #0
    4668:      	cmp	x16, #0x1
    466c:      	b.eq	0x4688 <_stogir.checked.validate-projection+0x14c>
    4670:      	b.lo	0x4678 <_stogir.checked.validate-projection+0x13c>
    4674:      	b	0x468c <_stogir.checked.validate-projection+0x150>
    4678:      	cmp	x16, #0x0
    467c:      	b.eq	0x4684 <_stogir.checked.validate-projection+0x148>
    4680:      	b	0x468c <_stogir.checked.validate-projection+0x150>
    4684:      	b	0x4690 <_stogir.checked.validate-projection+0x154>
    4688:      	b	0x46b0 <_stogir.checked.validate-projection+0x174>
    468c:      	b	0x4768 <_stogir.checked.validate-projection+0x22c>
    4690:      	adrp	x16, 0x4000 <_stogir.copy.validate+0xf4>
		0000000000004690:  ARM64_RELOC_PAGE21	l_stogir.358
    4694:      	ldr	x16, [x16]
		0000000000004694:  ARM64_RELOC_PAGEOFF12	l_stogir.358
    4698:      	orr	x0, x16, xzr
    469c:      	mov	x19, x8
    46a0:      	mov	x1, x0
    46a4:      	mov	x0, #0x1                ; =1
    46a8:      	mov	x2, #0x10               ; =16
    46ac:      	b	0x46d4 <_stogir.checked.validate-projection+0x198>
    46b0:      	cmp	x1, #0x0
    46b4:      	b.gt	0x46fc <_stogir.checked.validate-projection+0x1c0>
    46b8:      	mov	x19, x8
    46bc:      	adrp	x16, 0x4000 <_stogir.copy.validate+0xf4>
		00000000000046bc:  ARM64_RELOC_PAGE21	l_stogir.359
    46c0:      	ldr	x16, [x16]
		00000000000046c0:  ARM64_RELOC_PAGEOFF12	l_stogir.359
    46c4:      	orr	x0, x16, xzr
    46c8:      	mov	x1, x0
    46cc:      	mov	x0, #0x1                ; =1
    46d0:      	mov	x2, #0x1c               ; =28
    46d4:      	str	x0, [x19]
    46d8:      	str	x1, [x19, #0x8]
    46dc:      	str	x2, [x19, #0x10]
    46e0:      	ldr	x19, [sp, #0x30]
    46e4:      	ldr	x29, [sp]
    46e8:      	ldr	x30, [sp, #0x8]
    46ec:      	add	sp, sp, #0x40
    46f0:      	ret
    46f4:      	movz	x4, #0x0, lsl #48
    46f8:      	b	0x460c <_stogir.checked.validate-projection+0xd0>
    46fc:      	uxtb	w1, w4
    4700:      	cmp	x1, #0x2c
    4704:      	b.ne	0x4770 <_stogir.checked.validate-projection+0x234>
    4708:      	lsr	w1, w4, #0
    470c:      	ubfx	x1, x1, #8, #8
    4710:      	cmp	x1, #0x1
    4714:      	b.ne	0x4778 <_stogir.checked.validate-projection+0x23c>
    4718:      	ldr	x1, [x0, #0x78]
    471c:      	add	x1, x2, x1
    4720:      	ldr	w1, [x1]
    4724:      	sxtw	x1, w1
    4728:      	cmp	x1, #0x1
    472c:      	b.ne	0x4780 <_stogir.checked.validate-projection+0x244>
    4730:      	lsr	x1, x4, #32
    4734:      	lsr	w1, w1, #0
    4738:      	mov	x19, x8
    473c:      	add	x8, sp, #0x10
    4740:      	bl	0x4740 <_stogir.checked.validate-projection+0x204>
		0000000000004740:  ARM64_RELOC_BRANCH26	_stogir.checked.projection
    4744:      	add	x16, sp, #0x10
    4748:      	ldr	x0, [x16]
    474c:      	add	x16, sp, #0x10
    4750:      	ldr	x1, [x16, #0x8]
    4754:      	add	x16, sp, #0x10
    4758:      	ldr	x2, [x16, #0x10]
    475c:      	b	0x46d4 <_stogir.checked.validate-projection+0x198>
    4760:      	movz	x4, #0x0, lsl #48
    4764:      	b	0x4604 <_stogir.checked.validate-projection+0xc8>
    4768:      	brk	#0
    476c:      	b	0x4768 <_stogir.checked.validate-projection+0x22c>
    4770:      	mov	x19, x8
    4774:      	b	0x46bc <_stogir.checked.validate-projection+0x180>
    4778:      	mov	x19, x8
    477c:      	b	0x46bc <_stogir.checked.validate-projection+0x180>
    4780:      	mov	x19, x8
    4784:      	b	0x46bc <_stogir.checked.validate-projection+0x180>

0000000000004788 <_stogir.checked.validate>:
    4788:      	sub	sp, sp, #0x30
    478c:      	str	x29, [sp]
    4790:      	str	x30, [sp, #0x8]
    4794:      	mov	x29, sp
    4798:      	str	x19, [sp, #0x10]
    479c:      	str	x20, [sp, #0x18]
    47a0:      	str	x21, [sp, #0x20]
    47a4:      	sxtw	x1, w1
    47a8:      	lsl	x2, x1, #2
    47ac:      	cmp	x1, #0x0
    47b0:      	cset	w3, gt
    47b4:      	movz	x16, #0x0, lsl #48
    47b8:      	sub	x4, x16, x1
    47bc:      	sub	x5, x4, #0x1
    47c0:      	uxtb	w16, w3
    47c4:      	cmp	w16, wzr
    47c8:      	b.eq	0x4808 <_stogir.checked.validate+0x80>
    47cc:      	ldr	x4, [x0, #0x8]
    47d0:      	cmp	x1, x4
    47d4:      	b.ge	0x485c <_stogir.checked.validate+0xd4>
    47d8:      	add	x4, x0, #0x78
    47dc:      	ldr	x4, [x4, #0x8]
    47e0:      	cmp	x1, x4
    47e4:      	b.ge	0x49e8 <_stogir.checked.validate+0x260>
    47e8:      	ldr	x4, [x0, #0x78]
    47ec:      	add	x4, x2, x4
    47f0:      	ldr	w4, [x4]
    47f4:      	sxtw	x4, w4
    47f8:      	cmp	x4, #0x0
    47fc:      	cset	w4, ge
    4800:      	ubfx	x4, x4, #0, #8
    4804:      	b	0x49ec <_stogir.checked.validate+0x264>
    4808:      	cmp	x1, #0x0
    480c:      	b.ge	0x4864 <_stogir.checked.validate+0xdc>
    4810:      	add	x6, x0, #0x28
    4814:      	add	x7, x0, #0x50
    4818:      	ldr	x6, [x6, #0x8]
    481c:      	ldr	x7, [x7, #0x8]
    4820:      	cmp	x6, x7
    4824:      	b.ne	0x4854 <_stogir.checked.validate+0xcc>
    4828:      	cmp	x4, x6
    482c:      	b.gt	0x49f0 <_stogir.checked.validate+0x268>
    4830:      	lsl	x4, x5, #2
    4834:      	ldr	x6, [x0, #0x50]
    4838:      	add	x4, x4, x6
    483c:      	ldr	w4, [x4]
    4840:      	sxtw	x4, w4
    4844:      	cmp	x4, #0x0
    4848:      	cset	w4, gt
    484c:      	ubfx	x4, x4, #0, #8
    4850:      	b	0x49f4 <_stogir.checked.validate+0x26c>
    4854:      	movz	x4, #0x0, lsl #48
    4858:      	b	0x4868 <_stogir.checked.validate+0xe0>
    485c:      	movz	x4, #0x0, lsl #48
    4860:      	b	0x4868 <_stogir.checked.validate+0xe0>
    4864:      	movz	x4, #0x0, lsl #48
    4868:      	cmp	x4, #0x0
    486c:      	b.eq	0x48d0 <_stogir.checked.validate+0x148>
    4870:      	uxtb	w16, w3
    4874:      	cmp	w16, wzr
    4878:      	b.eq	0x48a0 <_stogir.checked.validate+0x118>
    487c:      	lsl	x3, x1, #4
    4880:      	ldr	x4, [x0]
    4884:      	add	x3, x3, x4
    4888:      	ldr	x4, [x3]
    488c:      	ldr	x3, [x3, #0x8]
    4890:      	fmov	d31, x3
    4894:      	mov	x3, x4
    4898:      	fmov	x4, d31
    489c:      	b	0x48c0 <_stogir.checked.validate+0x138>
    48a0:      	lsl	x3, x5, #4
    48a4:      	ldr	x4, [x0, #0x28]
    48a8:      	add	x3, x3, x4
    48ac:      	ldr	x4, [x3]
    48b0:      	ldr	x3, [x3, #0x8]
    48b4:      	fmov	d31, x3
    48b8:      	mov	x3, x4
    48bc:      	fmov	x4, d31
    48c0:      	mov	x5, x4
    48c4:      	mov	x4, x3
    48c8:      	mov	x3, #0x1                ; =1
    48cc:      	b	0x48dc <_stogir.checked.validate+0x154>
    48d0:      	movz	x3, #0x0, lsl #48
    48d4:      	movz	x4, #0x0, lsl #48
    48d8:      	movz	x5, #0x0, lsl #48
    48dc:      	lsr	w3, w3, #0
    48e0:      	lsr	x16, x3, #0
    48e4:      	cmp	x16, #0x1
    48e8:      	b.eq	0x4904 <_stogir.checked.validate+0x17c>
    48ec:      	b.lo	0x48f4 <_stogir.checked.validate+0x16c>
    48f0:      	b	0x4908 <_stogir.checked.validate+0x180>
    48f4:      	cmp	x16, #0x0
    48f8:      	b.eq	0x4900 <_stogir.checked.validate+0x178>
    48fc:      	b	0x4908 <_stogir.checked.validate+0x180>
    4900:      	b	0x490c <_stogir.checked.validate+0x184>
    4904:      	b	0x496c <_stogir.checked.validate+0x1e4>
    4908:      	b	0x4c68 <_stogir.checked.validate+0x4e0>
    490c:      	adrp	x16, 0x4000 <_stogir.copy.validate+0xf4>
		000000000000490c:  ARM64_RELOC_PAGE21	l_stogir.360
    4910:      	ldr	x16, [x16]
		0000000000004910:  ARM64_RELOC_PAGEOFF12	l_stogir.360
    4914:      	orr	x0, x16, xzr
    4918:      	mov	x1, x0
    491c:      	mov	x0, #0x1                ; =1
    4920:      	mov	x2, #0x1a               ; =26
    4924:      	b	0x4940 <_stogir.checked.validate+0x1b8>
    4928:      	adrp	x16, 0x4000 <_stogir.copy.validate+0xf4>
		0000000000004928:  ARM64_RELOC_PAGE21	l_stogir.361
    492c:      	ldr	x16, [x16]
		000000000000492c:  ARM64_RELOC_PAGEOFF12	l_stogir.361
    4930:      	orr	x0, x16, xzr
    4934:      	mov	x1, x0
    4938:      	mov	x0, #0x1                ; =1
    493c:      	mov	x2, #0x26               ; =38
    4940:      	str	x0, [x8]
    4944:      	str	x1, [x8, #0x8]
    4948:      	str	x2, [x8, #0x10]
    494c:      	sub	sp, x29, #0x0
    4950:      	ldr	x19, [sp, #0x10]
    4954:      	ldr	x20, [sp, #0x18]
    4958:      	ldr	x21, [sp, #0x20]
    495c:      	ldr	x29, [sp]
    4960:      	ldr	x30, [sp, #0x8]
    4964:      	add	sp, sp, #0x30
    4968:      	ret
    496c:      	cmp	x1, #0x0
    4970:      	b.le	0x4928 <_stogir.checked.validate+0x1a0>
    4974:      	uxtb	w1, w4
    4978:      	cmp	x1, #0x29
    497c:      	b.lt	0x4928 <_stogir.checked.validate+0x1a0>
    4980:      	cmp	x1, #0x2b
    4984:      	b.gt	0x4928 <_stogir.checked.validate+0x1a0>
    4988:      	ldr	x1, [x0, #0x78]
    498c:      	add	x1, x2, x1
    4990:      	ldr	w1, [x1]
    4994:      	sxtw	x1, w1
    4998:      	cmp	x1, #0x2
    499c:      	b.ne	0x4928 <_stogir.checked.validate+0x1a0>
    49a0:      	lsr	w1, w4, #0
    49a4:      	mov	x2, sp
    49a8:      	sub	sp, sp, #0x10
    49ac:      	mov	x3, sp
    49b0:      	sub	sp, sp, #0x10
    49b4:      	mov	x6, sp
    49b8:      	ubfx	x1, x1, #8, #8
    49bc:      	cmp	x1, #0x1
    49c0:      	b.lt	0x4bf0 <_stogir.checked.validate+0x468>
    49c4:      	cmp	x1, #0xb
    49c8:      	b.gt	0x4bf0 <_stogir.checked.validate+0x468>
    49cc:      	cmp	x1, #0x1
    49d0:      	b.eq	0x4bf0 <_stogir.checked.validate+0x468>
    49d4:      	adrp	x16, 0x4000 <_stogir.copy.validate+0xf4>
		00000000000049d4:  ARM64_RELOC_PAGE21	l_stogir.362
    49d8:      	ldr	x16, [x16]
		00000000000049d8:  ARM64_RELOC_PAGEOFF12	l_stogir.362
    49dc:      	orr	x7, x16, xzr
    49e0:      	movz	x9, #0x0, lsl #48
    49e4:      	b	0x4c00 <_stogir.checked.validate+0x478>
    49e8:      	movz	x4, #0x0, lsl #48
    49ec:      	b	0x4860 <_stogir.checked.validate+0xd8>
    49f0:      	movz	x4, #0x0, lsl #48
    49f4:      	b	0x4858 <_stogir.checked.validate+0xd0>
    49f8:      	mov	x1, x3
    49fc:      	mov	x3, x4
    4a00:      	mov	x0, #0x1                ; =1
    4a04:      	mov	sp, x2
    4a08:      	mov	x2, x3
    4a0c:      	b	0x4940 <_stogir.checked.validate+0x1b8>
    4a10:      	movz	x5, #0x0, lsl #48
    4a14:      	movz	x6, #0x0, lsl #48
    4a18:      	lsr	w5, w5, #0
    4a1c:      	lsr	x16, x5, #0
    4a20:      	cmp	x16, #0x1
    4a24:      	b.eq	0x4a40 <_stogir.checked.validate+0x2b8>
    4a28:      	b.lo	0x4a30 <_stogir.checked.validate+0x2a8>
    4a2c:      	b	0x4a44 <_stogir.checked.validate+0x2bc>
    4a30:      	cmp	x16, #0x0
    4a34:      	b.eq	0x4a3c <_stogir.checked.validate+0x2b4>
    4a38:      	b	0x4a44 <_stogir.checked.validate+0x2bc>
    4a3c:      	b	0x4a48 <_stogir.checked.validate+0x2c0>
    4a40:      	b	0x4bd4 <_stogir.checked.validate+0x44c>
    4a44:      	b	0x4c80 <_stogir.checked.validate+0x4f8>
    4a48:      	mov	x3, x11
    4a4c:      	mov	x4, #0x22               ; =34
    4a50:      	mov	x5, x7
    4a54:      	cmp	x5, #0x2
    4a58:      	b.ge	0x4a84 <_stogir.checked.validate+0x2fc>
    4a5c:      	add	x6, x5, #0x1
    4a60:      	lsl	x5, x5, #2
    4a64:      	add	x5, x5, x10
    4a68:      	ldr	w5, [x5]
    4a6c:      	sxtw	x5, w5
    4a70:      	and	x5, x5, #0xffffffff
    4a74:      	mov	x7, x6
    4a78:      	mov	x6, x5
    4a7c:      	mov	x5, #0x1                ; =1
    4a80:      	b	0x4a90 <_stogir.checked.validate+0x308>
    4a84:      	mov	x7, x5
    4a88:      	movz	x5, #0x0, lsl #48
    4a8c:      	movz	x6, #0x0, lsl #48
    4a90:      	lsr	w5, w5, #0
    4a94:      	lsr	x16, x5, #0
    4a98:      	cmp	x16, #0x1
    4a9c:      	b.eq	0x4ab8 <_stogir.checked.validate+0x330>
    4aa0:      	b.lo	0x4aa8 <_stogir.checked.validate+0x320>
    4aa4:      	b	0x4abc <_stogir.checked.validate+0x334>
    4aa8:      	cmp	x16, #0x0
    4aac:      	b.eq	0x4ab4 <_stogir.checked.validate+0x32c>
    4ab0:      	b	0x4abc <_stogir.checked.validate+0x334>
    4ab4:      	b	0x4b24 <_stogir.checked.validate+0x39c>
    4ab8:      	b	0x4ac0 <_stogir.checked.validate+0x338>
    4abc:      	b	0x4c78 <_stogir.checked.validate+0x4f0>
    4ac0:      	lsr	w6, w6, #0
    4ac4:      	sxtw	x6, w6
    4ac8:      	cmp	x6, #0x0
    4acc:      	cset	w5, gt
    4ad0:      	movz	x16, #0x0, lsl #48
    4ad4:      	sub	x9, x16, x6
    4ad8:      	sub	x19, x9, #0x1
    4adc:      	uxtb	w16, w5
    4ae0:      	cmp	w16, wzr
    4ae4:      	b.eq	0x4b90 <_stogir.checked.validate+0x408>
    4ae8:      	ldr	x9, [x0, #0x8]
    4aec:      	cmp	x6, x9
    4af0:      	b.ge	0x4b88 <_stogir.checked.validate+0x400>
    4af4:      	ldr	x9, [x13, #0x8]
    4af8:      	cmp	x6, x9
    4afc:      	b.ge	0x4c60 <_stogir.checked.validate+0x4d8>
    4b00:      	lsl	x9, x6, #2
    4b04:      	ldr	x20, [x0, #0x78]
    4b08:      	add	x9, x9, x20
    4b0c:      	ldr	w9, [x9]
    4b10:      	sxtw	x9, w9
    4b14:      	cmp	x9, #0x0
    4b18:      	cset	w9, ge
    4b1c:      	ubfx	x9, x9, #0, #8
    4b20:      	b	0x4c64 <_stogir.checked.validate+0x4dc>
    4b24:      	cmp	x4, #0x0
    4b28:      	b.ne	0x49f8 <_stogir.checked.validate+0x270>
    4b2c:      	and	x0, x1, #0xffffffff
    4b30:      	mov	x1, x0
    4b34:      	movz	x0, #0x0, lsl #48
    4b38:      	movz	x3, #0x0, lsl #48
    4b3c:      	b	0x4a04 <_stogir.checked.validate+0x27c>
    4b40:      	lsl	x5, x19, #4
    4b44:      	ldr	x6, [x0, #0x28]
    4b48:      	add	x5, x5, x6
    4b4c:      	ldr	x5, [x5]
    4b50:      	mov	x6, x5
    4b54:      	mov	x5, #0x1                ; =1
    4b58:      	b	0x4a18 <_stogir.checked.validate+0x290>
    4b5c:      	movz	x9, #0x0, lsl #48
    4b60:      	cmp	x9, #0x0
    4b64:      	b.eq	0x4a10 <_stogir.checked.validate+0x288>
    4b68:      	uxtb	w16, w5
    4b6c:      	cmp	w16, wzr
    4b70:      	b.eq	0x4b40 <_stogir.checked.validate+0x3b8>
    4b74:      	lsl	x5, x6, #4
    4b78:      	ldr	x6, [x0]
    4b7c:      	add	x5, x5, x6
    4b80:      	ldr	x5, [x5]
    4b84:      	b	0x4b50 <_stogir.checked.validate+0x3c8>
    4b88:      	movz	x9, #0x0, lsl #48
    4b8c:      	b	0x4b60 <_stogir.checked.validate+0x3d8>
    4b90:      	cmp	x6, #0x0
    4b94:      	b.ge	0x4b5c <_stogir.checked.validate+0x3d4>
    4b98:      	ldr	x20, [x14, #0x8]
    4b9c:      	ldr	x21, [x15, #0x8]
    4ba0:      	cmp	x20, x21
    4ba4:      	b.ne	0x4c58 <_stogir.checked.validate+0x4d0>
    4ba8:      	cmp	x9, x20
    4bac:      	b.gt	0x4c70 <_stogir.checked.validate+0x4e8>
    4bb0:      	lsl	x9, x19, #2
    4bb4:      	ldr	x20, [x0, #0x50]
    4bb8:      	add	x9, x9, x20
    4bbc:      	ldr	w9, [x9]
    4bc0:      	sxtw	x9, w9
    4bc4:      	cmp	x9, #0x0
    4bc8:      	cset	w9, gt
    4bcc:      	ubfx	x9, x9, #0, #8
    4bd0:      	b	0x4c74 <_stogir.checked.validate+0x4ec>
    4bd4:      	lsr	w6, w6, #0
    4bd8:      	ubfx	x5, x6, #8, #8
    4bdc:      	cmp	x5, x1
    4be0:      	b.eq	0x4bec <_stogir.checked.validate+0x464>
    4be4:      	mov	x3, x12
    4be8:      	mov	x4, #0x28               ; =40
    4bec:      	b	0x4a50 <_stogir.checked.validate+0x2c8>
    4bf0:      	adrp	x16, 0x4000 <_stogir.copy.validate+0xf4>
		0000000000004bf0:  ARM64_RELOC_PAGE21	l_stogir.363
    4bf4:      	ldr	x16, [x16]
		0000000000004bf4:  ARM64_RELOC_PAGEOFF12	l_stogir.363
    4bf8:      	orr	x7, x16, xzr
    4bfc:      	mov	x9, #0x36               ; =54
    4c00:      	orr	x10, x6, xzr
    4c04:      	adrp	x16, 0x4000 <_stogir.copy.validate+0xf4>
		0000000000004c04:  ARM64_RELOC_PAGE21	l_stogir.364
    4c08:      	ldr	x16, [x16]
		0000000000004c08:  ARM64_RELOC_PAGEOFF12	l_stogir.364
    4c0c:      	orr	x11, x16, xzr
    4c10:      	adrp	x16, 0x4000 <_stogir.copy.validate+0xf4>
		0000000000004c10:  ARM64_RELOC_PAGE21	l_stogir.365
    4c14:      	ldr	x16, [x16]
		0000000000004c14:  ARM64_RELOC_PAGEOFF12	l_stogir.365
    4c18:      	orr	x12, x16, xzr
    4c1c:      	add	x13, x0, #0x78
    4c20:      	add	x14, x0, #0x28
    4c24:      	add	x15, x0, #0x50
    4c28:      	lsr	w5, w5, #0
    4c2c:      	lsr	x4, x4, #32
    4c30:      	lsr	w5, w5, #0
    4c34:      	lsr	w4, w4, #0
    4c38:      	str	w4, [x3]
    4c3c:      	str	w5, [x3, #0x4]
    4c40:      	ldr	x3, [x3]
    4c44:      	str	x3, [x6]
    4c48:      	mov	x3, x7
    4c4c:      	mov	x4, x9
    4c50:      	movz	x5, #0x0, lsl #48
    4c54:      	b	0x4a54 <_stogir.checked.validate+0x2cc>
    4c58:      	movz	x9, #0x0, lsl #48
    4c5c:      	b	0x4b60 <_stogir.checked.validate+0x3d8>
    4c60:      	movz	x9, #0x0, lsl #48
    4c64:      	b	0x4b8c <_stogir.checked.validate+0x404>
    4c68:      	brk	#0
    4c6c:      	b	0x4c68 <_stogir.checked.validate+0x4e0>
    4c70:      	movz	x9, #0x0, lsl #48
    4c74:      	b	0x4c5c <_stogir.checked.validate+0x4d4>
    4c78:      	brk	#0
    4c7c:      	b	0x4c78 <_stogir.checked.validate+0x4f0>
    4c80:      	brk	#0
    4c84:      	b	0x4c80 <_stogir.checked.validate+0x4f8>

0000000000004c88 <_stogir.atomic.operation?>:
    4c88:      	sxtw	x0, w0
    4c8c:      	cmp	x0, #0x7e
    4c90:      	b.lt	0x4ca4 <_stogir.atomic.operation?+0x1c>
    4c94:      	cmp	x0, #0x82
    4c98:      	cset	w0, le
    4c9c:      	ubfx	x0, x0, #0, #8
    4ca0:      	b	0x4ca8 <_stogir.atomic.operation?+0x20>
    4ca4:      	movz	x0, #0x0, lsl #48
    4ca8:      	ret

0000000000004cac <_stogir.atomic.validate>:
    4cac:      	sub	sp, sp, #0xf0
    4cb0:      	str	x29, [sp, #0x10]
    4cb4:      	str	x30, [sp, #0x18]
    4cb8:      	add	x29, sp, #0x10
    4cbc:      	str	x19, [sp, #0xa0]
    4cc0:      	str	x20, [sp, #0xa8]
    4cc4:      	str	x21, [sp, #0xb0]
    4cc8:      	str	x22, [sp, #0xb8]
    4ccc:      	str	x23, [sp, #0xc0]
    4cd0:      	str	x24, [sp, #0xc8]
    4cd4:      	str	x25, [sp, #0xd0]
    4cd8:      	str	x26, [sp, #0xd8]
    4cdc:      	str	x27, [sp, #0xe0]
    4ce0:      	str	x28, [sp, #0xe8]
    4ce4:      	sxtw	x2, w1
    4ce8:      	lsl	x3, x2, #2
    4cec:      	cmp	x2, #0x0
    4cf0:      	cset	w4, gt
    4cf4:      	movz	x16, #0x0, lsl #48
    4cf8:      	sub	x5, x16, x2
    4cfc:      	sub	x6, x5, #0x1
    4d00:      	uxtb	w16, w4
    4d04:      	cmp	w16, wzr
    4d08:      	b.eq	0x4d48 <_stogir.atomic.validate+0x9c>
    4d0c:      	ldr	x5, [x0, #0x8]
    4d10:      	cmp	x2, x5
    4d14:      	b.ge	0x4d9c <_stogir.atomic.validate+0xf0>
    4d18:      	add	x5, x0, #0x78
    4d1c:      	ldr	x5, [x5, #0x8]
    4d20:      	cmp	x2, x5
    4d24:      	b.ge	0x4f14 <_stogir.atomic.validate+0x268>
    4d28:      	ldr	x5, [x0, #0x78]
    4d2c:      	add	x5, x3, x5
    4d30:      	ldr	w5, [x5]
    4d34:      	sxtw	x5, w5
    4d38:      	cmp	x5, #0x0
    4d3c:      	cset	w5, ge
    4d40:      	ubfx	x5, x5, #0, #8
    4d44:      	b	0x4f18 <_stogir.atomic.validate+0x26c>
    4d48:      	cmp	x2, #0x0
    4d4c:      	b.ge	0x4da4 <_stogir.atomic.validate+0xf8>
    4d50:      	add	x7, x0, #0x28
    4d54:      	add	x9, x0, #0x50
    4d58:      	ldr	x7, [x7, #0x8]
    4d5c:      	ldr	x9, [x9, #0x8]
    4d60:      	cmp	x7, x9
    4d64:      	b.ne	0x4d94 <_stogir.atomic.validate+0xe8>
    4d68:      	cmp	x5, x7
    4d6c:      	b.gt	0x4fe8 <_stogir.atomic.validate+0x33c>
    4d70:      	lsl	x5, x6, #2
    4d74:      	ldr	x7, [x0, #0x50]
    4d78:      	add	x5, x5, x7
    4d7c:      	ldr	w5, [x5]
    4d80:      	sxtw	x5, w5
    4d84:      	cmp	x5, #0x0
    4d88:      	cset	w5, gt
    4d8c:      	ubfx	x5, x5, #0, #8
    4d90:      	b	0x4fec <_stogir.atomic.validate+0x340>
    4d94:      	movz	x5, #0x0, lsl #48
    4d98:      	b	0x4da8 <_stogir.atomic.validate+0xfc>
    4d9c:      	movz	x5, #0x0, lsl #48
    4da0:      	b	0x4da8 <_stogir.atomic.validate+0xfc>
    4da4:      	movz	x5, #0x0, lsl #48
    4da8:      	cmp	x5, #0x0
    4dac:      	b.eq	0x4e0c <_stogir.atomic.validate+0x160>
    4db0:      	uxtb	w16, w4
    4db4:      	cmp	w16, wzr
    4db8:      	b.eq	0x4de0 <_stogir.atomic.validate+0x134>
    4dbc:      	lsl	x4, x2, #4
    4dc0:      	ldr	x5, [x0]
    4dc4:      	add	x4, x4, x5
    4dc8:      	ldr	x5, [x4]
    4dcc:      	ldr	x4, [x4, #0x8]
    4dd0:      	fmov	d31, x4
    4dd4:      	mov	x4, x5
    4dd8:      	fmov	x5, d31
    4ddc:      	b	0x4e00 <_stogir.atomic.validate+0x154>
    4de0:      	lsl	x4, x6, #4
    4de4:      	ldr	x5, [x0, #0x28]
    4de8:      	add	x4, x4, x5
    4dec:      	ldr	x5, [x4]
    4df0:      	ldr	x4, [x4, #0x8]
    4df4:      	fmov	d31, x4
    4df8:      	mov	x4, x5
    4dfc:      	fmov	x5, d31
    4e00:      	mov	x19, x4
    4e04:      	mov	x4, #0x1                ; =1
    4e08:      	b	0x4e18 <_stogir.atomic.validate+0x16c>
    4e0c:      	movz	x4, #0x0, lsl #48
    4e10:      	movz	x19, #0x0, lsl #48
    4e14:      	movz	x5, #0x0, lsl #48
    4e18:      	lsr	w4, w4, #0
    4e1c:      	lsr	x16, x4, #0
    4e20:      	cmp	x16, #0x1
    4e24:      	b.eq	0x4e40 <_stogir.atomic.validate+0x194>
    4e28:      	b.lo	0x4e30 <_stogir.atomic.validate+0x184>
    4e2c:      	b	0x4e44 <_stogir.atomic.validate+0x198>
    4e30:      	cmp	x16, #0x0
    4e34:      	b.eq	0x4e3c <_stogir.atomic.validate+0x190>
    4e38:      	b	0x4e44 <_stogir.atomic.validate+0x198>
    4e3c:      	b	0x4e48 <_stogir.atomic.validate+0x19c>
    4e40:      	b	0x4ea8 <_stogir.atomic.validate+0x1fc>
    4e44:      	b	0x561c <_stogir.atomic.validate+0x970>
    4e48:      	adrp	x16, 0x4000 <_stogir.copy.validate+0xf4>
		0000000000004e48:  ARM64_RELOC_PAGE21	l_stogir.366
    4e4c:      	ldr	x16, [x16]
		0000000000004e4c:  ARM64_RELOC_PAGEOFF12	l_stogir.366
    4e50:      	orr	x0, x16, xzr
    4e54:      	mov	x24, x8
    4e58:      	mov	x1, x0
    4e5c:      	mov	x0, #0x1                ; =1
    4e60:      	mov	x2, #0x1a               ; =26
    4e64:      	str	x0, [x24]
    4e68:      	str	x1, [x24, #0x8]
    4e6c:      	str	x2, [x24, #0x10]
    4e70:      	ldr	x19, [sp, #0xa0]
    4e74:      	ldr	x20, [sp, #0xa8]
    4e78:      	ldr	x21, [sp, #0xb0]
    4e7c:      	ldr	x22, [sp, #0xb8]
    4e80:      	ldr	x23, [sp, #0xc0]
    4e84:      	ldr	x24, [sp, #0xc8]
    4e88:      	ldr	x25, [sp, #0xd0]
    4e8c:      	ldr	x26, [sp, #0xd8]
    4e90:      	ldr	x27, [sp, #0xe0]
    4e94:      	ldr	x28, [sp, #0xe8]
    4e98:      	ldr	x29, [sp, #0x10]
    4e9c:      	ldr	x30, [sp, #0x18]
    4ea0:      	add	sp, sp, #0xf0
    4ea4:      	ret
    4ea8:      	adrp	x16, 0x4000 <_stogir.copy.validate+0xf4>
		0000000000004ea8:  ARM64_RELOC_PAGE21	l_stogir.367
    4eac:      	ldr	x16, [x16]
		0000000000004eac:  ARM64_RELOC_PAGEOFF12	l_stogir.367
    4eb0:      	orr	x20, x16, xzr
    4eb4:      	uxtb	w4, w19
    4eb8:      	add	x16, sp, #0x20
    4ebc:      	str	x19, [x16]
    4ec0:      	orr	x21, x4, xzr
    4ec4:      	add	x16, sp, #0x20
    4ec8:      	str	x5, [x16, #0x8]
    4ecc:      	cmp	x2, #0x0
    4ed0:      	b.le	0x4f68 <_stogir.atomic.validate+0x2bc>
    4ed4:      	cmp	x21, #0x7e
    4ed8:      	b.lt	0x4f68 <_stogir.atomic.validate+0x2bc>
    4edc:      	cmp	x21, #0x82
    4ee0:      	b.gt	0x4f68 <_stogir.atomic.validate+0x2bc>
    4ee4:      	ldr	x2, [x0, #0x78]
    4ee8:      	add	x2, x3, x2
    4eec:      	ldr	w2, [x2]
    4ef0:      	cmp	x21, #0x83
    4ef4:      	b.ge	0x5548 <_stogir.atomic.validate+0x89c>
    4ef8:      	adrp	x16, 0x4000 <_stogir.copy.validate+0xf4>
		0000000000004ef8:  ARM64_RELOC_PAGE21	l_stogir.368
    4efc:      	ldr	x16, [x16]
		0000000000004efc:  ARM64_RELOC_PAGEOFF12	l_stogir.368
    4f00:      	orr	x3, x16, xzr
    4f04:      	add	x3, x21, x3
    4f08:      	ldrsb	w3, [x3]
    4f0c:      	sxtb	x3, w3
    4f10:      	b	0x554c <_stogir.atomic.validate+0x8a0>
    4f14:      	movz	x5, #0x0, lsl #48
    4f18:      	b	0x4da0 <_stogir.atomic.validate+0xf4>
    4f1c:      	mov	x19, x21
    4f20:      	mov	x21, x23
    4f24:      	cmp	x21, #0x0
    4f28:      	b.ne	0x4f58 <_stogir.atomic.validate+0x2ac>
    4f2c:      	cmp	x21, #0x0
    4f30:      	b.eq	0x53f0 <_stogir.atomic.validate+0x744>
    4f34:      	lsr	x0, x21, #0
    4f38:      	mov	x1, x20
    4f3c:      	mov	x2, x0
    4f40:      	mov	x0, x19
    4f44:      	bl	0x4f44 <_stogir.atomic.validate+0x298>
		0000000000004f44:  ARM64_RELOC_BRANCH26	_memcmp
    4f48:      	lsr	w0, w0, #0
    4f4c:      	sxtw	x0, w0
    4f50:      	cmp	x0, #0x0
    4f54:      	b.eq	0x53f0 <_stogir.atomic.validate+0x744>
    4f58:      	mov	x1, x19
    4f5c:      	mov	x2, x21
    4f60:      	mov	x0, #0x1                ; =1
    4f64:      	b	0x4e64 <_stogir.atomic.validate+0x1b8>
    4f68:      	adrp	x16, 0x4000 <_stogir.copy.validate+0xf4>
		0000000000004f68:  ARM64_RELOC_PAGE21	l_stogir.369
    4f6c:      	ldr	x16, [x16]
		0000000000004f6c:  ARM64_RELOC_PAGEOFF12	l_stogir.369
    4f70:      	orr	x2, x16, xzr
    4f74:      	mov	x22, x2
    4f78:      	mov	x23, #0x20              ; =32
    4f7c:      	add	x16, sp, #0x20
    4f80:      	ldr	w2, [x16, #0x4]
    4f84:      	lsr	w2, w2, #0
    4f88:      	mov	x24, x8
    4f8c:      	add	x8, sp, #0x30
    4f90:      	mov	x25, x0
    4f94:      	mov	w26, w1
    4f98:      	mov	w1, w2
    4f9c:      	bl	0x4f9c <_stogir.atomic.validate+0x2f0>
		0000000000004f9c:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    4fa0:      	add	x16, sp, #0x30
    4fa4:      	ldr	w0, [x16]
    4fa8:      	lsr	x16, x0, #0
    4fac:      	cmp	x16, #0x1
    4fb0:      	b.eq	0x4fcc <_stogir.atomic.validate+0x320>
    4fb4:      	b.lo	0x4fbc <_stogir.atomic.validate+0x310>
    4fb8:      	b	0x4fd0 <_stogir.atomic.validate+0x324>
    4fbc:      	cmp	x16, #0x0
    4fc0:      	b.eq	0x4fc8 <_stogir.atomic.validate+0x31c>
    4fc4:      	b	0x4fd0 <_stogir.atomic.validate+0x324>
    4fc8:      	b	0x4fd4 <_stogir.atomic.validate+0x328>
    4fcc:      	b	0x50d0 <_stogir.atomic.validate+0x424>
    4fd0:      	b	0x5654 <_stogir.atomic.validate+0x9a8>
    4fd4:      	adrp	x16, 0x4000 <_stogir.copy.validate+0xf4>
		0000000000004fd4:  ARM64_RELOC_PAGE21	l_stogir.370
    4fd8:      	ldr	x16, [x16]
		0000000000004fd8:  ARM64_RELOC_PAGEOFF12	l_stogir.370
    4fdc:      	orr	x0, x16, xzr
    4fe0:      	mov	x1, #0x16               ; =22
    4fe4:      	b	0x4ff8 <_stogir.atomic.validate+0x34c>
    4fe8:      	movz	x5, #0x0, lsl #48
    4fec:      	b	0x4d98 <_stogir.atomic.validate+0xec>
    4ff0:      	mov	x0, x1
    4ff4:      	mov	x1, x2
    4ff8:      	cmp	x21, #0x82
    4ffc:      	cset	w22, eq
    5000:      	lsr	w19, w19, #0
    5004:      	ubfx	x2, x19, #8, #8
    5008:      	orr	x19, x2, xzr
    500c:      	cmp	x19, #0x0
    5010:      	cset	w23, eq
    5014:      	uxtb	w16, w22
    5018:      	cmp	w16, wzr
    501c:      	b.eq	0x5044 <_stogir.atomic.validate+0x398>
    5020:      	uxtb	w16, w23
    5024:      	cmp	w16, wzr
    5028:      	b.eq	0x523c <_stogir.atomic.validate+0x590>
    502c:      	mov	x2, x0
    5030:      	movz	x0, #0x0, lsl #48
    5034:      	b	0x5244 <_stogir.atomic.validate+0x598>
    5038:      	mov	x0, x2
    503c:      	mov	x27, x1
    5040:      	b	0x5048 <_stogir.atomic.validate+0x39c>
    5044:      	mov	x27, x1
    5048:      	uxtb	w16, w22
    504c:      	cmp	w16, wzr
    5050:      	b.eq	0x5060 <_stogir.atomic.validate+0x3b4>
    5054:      	mov	x28, x0
    5058:      	movz	x0, #0x0, lsl #48
    505c:      	b	0x5068 <_stogir.atomic.validate+0x3bc>
    5060:      	mov	x28, x0
    5064:      	mov	x0, #0x1                ; =1
    5068:      	cmp	x0, #0x0
    506c:      	b.eq	0x50a0 <_stogir.atomic.validate+0x3f4>
    5070:      	add	x16, sp, #0x20
    5074:      	ldr	w0, [x16, #0x8]
    5078:      	lsr	w0, w0, #0
    507c:      	mov	w1, w0
    5080:      	mov	x0, x25
    5084:      	mov	x2, #0x6                ; =6
    5088:      	bl	0x5088 <_stogir.atomic.validate+0x3dc>
		0000000000005088:  ARM64_RELOC_BRANCH26	_stogir.atomic.ordinary?
    508c:      	cmp	x0, #0x0
    5090:      	b.eq	0x51f0 <_stogir.atomic.validate+0x544>
    5094:      	mov	x1, x28
    5098:      	movz	x0, #0x0, lsl #48
    509c:      	b	0x51f8 <_stogir.atomic.validate+0x54c>
    50a0:      	mov	x0, x19
    50a4:      	mov	x1, x28
    50a8:      	mov	x2, x27
    50ac:      	cmp	x21, #0x80
    50b0:      	cset	w19, eq
    50b4:      	uxtb	w16, w19
    50b8:      	cmp	w16, wzr
    50bc:      	b.eq	0x50fc <_stogir.atomic.validate+0x450>
    50c0:      	mov	x21, x1
    50c4:      	mov	x23, x2
    50c8:      	mov	x1, #0x1                ; =1
    50cc:      	b	0x5114 <_stogir.atomic.validate+0x468>
    50d0:      	add	x16, sp, #0x30
    50d4:      	ldr	x0, [x16, #0x8]
    50d8:      	add	x16, sp, #0x20
    50dc:      	ldr	w1, [x16, #0x4]
    50e0:      	sxtw	x1, w1
    50e4:      	cmp	x1, #0x0
    50e8:      	b.gt	0x52a8 <_stogir.atomic.validate+0x5fc>
    50ec:      	mov	x1, x22
    50f0:      	mov	x2, x23
    50f4:      	mov	x0, #0x1                ; =1
    50f8:      	b	0x528c <_stogir.atomic.validate+0x5e0>
    50fc:      	cmp	x21, #0x81
    5100:      	cset	w3, eq
    5104:      	ubfx	x3, x3, #0, #8
    5108:      	mov	x21, x1
    510c:      	mov	x1, x3
    5110:      	mov	x23, x2
    5114:      	lsr	w27, w0, #0
    5118:      	cmp	x1, #0x0
    511c:      	b.eq	0x4f1c <_stogir.atomic.validate+0x270>
    5120:      	lsr	w26, w26, #0
    5124:      	add	x16, sp, #0x90
    5128:      	str	x16, [sp]
    512c:      	mov	x0, x25
    5130:      	mov	w1, w26
    5134:      	mov	x2, #0x4                ; =4
    5138:      	bl	0x5138 <_stogir.atomic.validate+0x48c>
		0000000000005138:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    513c:      	ldr	x16, [sp]
    5140:      	str	x0, [x16]
    5144:      	str	x1, [x16, #0x8]
    5148:      	add	x16, sp, #0x90
    514c:      	ldr	x0, [x16]
    5150:      	add	x16, sp, #0x90
    5154:      	ldr	x1, [x16, #0x8]
    5158:      	lsr	w0, w0, #0
    515c:      	lsr	x16, x0, #0
    5160:      	cmp	x16, #0x1
    5164:      	b.eq	0x5180 <_stogir.atomic.validate+0x4d4>
    5168:      	b.lo	0x5170 <_stogir.atomic.validate+0x4c4>
    516c:      	b	0x5184 <_stogir.atomic.validate+0x4d8>
    5170:      	cmp	x16, #0x0
    5174:      	b.eq	0x517c <_stogir.atomic.validate+0x4d0>
    5178:      	b	0x5184 <_stogir.atomic.validate+0x4d8>
    517c:      	b	0x5188 <_stogir.atomic.validate+0x4dc>
    5180:      	b	0x5404 <_stogir.atomic.validate+0x758>
    5184:      	b	0x5664 <_stogir.atomic.validate+0x9b8>
    5188:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x354>
		0000000000005188:  ARM64_RELOC_PAGE21	l_stogir.371
    518c:      	ldr	x16, [x16]
		000000000000518c:  ARM64_RELOC_PAGEOFF12	l_stogir.371
    5190:      	orr	x0, x16, xzr
    5194:      	mov	x1, #0x1d               ; =29
    5198:      	b	0x51c4 <_stogir.atomic.validate+0x518>
    519c:      	mov	x0, x1
    51a0:      	mov	x1, x2
    51a4:      	mov	x2, x1
    51a8:      	mov	x1, x0
    51ac:      	mov	x0, x19
    51b0:      	b	0x50ac <_stogir.atomic.validate+0x400>
    51b4:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x354>
		00000000000051b4:  ARM64_RELOC_PAGE21	l_stogir.372
    51b8:      	ldr	x16, [x16]
		00000000000051b8:  ARM64_RELOC_PAGEOFF12	l_stogir.372
    51bc:      	orr	x0, x16, xzr
    51c0:      	mov	x1, #0x24               ; =36
    51c4:      	mov	x19, x0
    51c8:      	mov	x21, x1
    51cc:      	b	0x4f24 <_stogir.atomic.validate+0x278>
    51d0:      	mov	x0, #0x1                ; =1
    51d4:      	lsr	w0, w0, #0
    51d8:      	sxtw	x0, w0
    51dc:      	and	x0, x0, #0xffffffff
    51e0:      	mov	x1, x0
    51e4:      	movz	x0, #0x0, lsl #48
    51e8:      	movz	x2, #0x0, lsl #48
    51ec:      	b	0x4f64 <_stogir.atomic.validate+0x2b8>
    51f0:      	mov	x1, x28
    51f4:      	mov	x0, #0x1                ; =1
    51f8:      	cmp	x0, #0x0
    51fc:      	b.eq	0x5214 <_stogir.atomic.validate+0x568>
    5200:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x354>
		0000000000005200:  ARM64_RELOC_PAGE21	l_stogir.373
    5204:      	ldr	x16, [x16]
		0000000000005204:  ARM64_RELOC_PAGEOFF12	l_stogir.373
    5208:      	orr	x0, x16, xzr
    520c:      	mov	x1, #0x1b               ; =27
    5210:      	b	0x521c <_stogir.atomic.validate+0x570>
    5214:      	mov	x0, x1
    5218:      	mov	x1, x27
    521c:      	cmp	x21, #0x7f
    5220:      	b.ne	0x530c <_stogir.atomic.validate+0x660>
    5224:      	uxtb	w16, w23
    5228:      	cmp	w16, wzr
    522c:      	b.eq	0x5444 <_stogir.atomic.validate+0x798>
    5230:      	mov	x2, x0
    5234:      	movz	x0, #0x0, lsl #48
    5238:      	b	0x544c <_stogir.atomic.validate+0x7a0>
    523c:      	mov	x2, x0
    5240:      	mov	x0, #0x1                ; =1
    5244:      	cmp	x0, #0x0
    5248:      	b.eq	0x5038 <_stogir.atomic.validate+0x38c>
    524c:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x354>
		000000000000524c:  ARM64_RELOC_PAGE21	l_stogir.374
    5250:      	ldr	x16, [x16]
		0000000000005250:  ARM64_RELOC_PAGEOFF12	l_stogir.374
    5254:      	orr	x0, x16, xzr
    5258:      	mov	x1, #0x19               ; =25
    525c:      	b	0x503c <_stogir.atomic.validate+0x390>
    5260:      	mov	x1, x3
    5264:      	movz	x0, #0x0, lsl #48
    5268:      	uxtb	w0, w0
    526c:      	and	x0, x0, #0x4
    5270:      	uxtb	w0, w0
    5274:      	cmp	x0, #0x0
    5278:      	cset	w0, eq
    527c:      	uxtb	w16, w0
    5280:      	cmp	w16, wzr
    5284:      	cset	x0, eq
    5288:      	mov	x2, x23
    528c:      	cmp	x0, #0x0
    5290:      	b.eq	0x4ff0 <_stogir.atomic.validate+0x344>
    5294:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x354>
		0000000000005294:  ARM64_RELOC_PAGE21	l_stogir.375
    5298:      	ldr	x16, [x16]
		0000000000005298:  ARM64_RELOC_PAGEOFF12	l_stogir.375
    529c:      	orr	x0, x16, xzr
    52a0:      	mov	x1, #0x16               ; =22
    52a4:      	b	0x4ff8 <_stogir.atomic.validate+0x34c>
    52a8:      	uxtb	w0, w0
    52ac:      	cmp	x0, #0x83
    52b0:      	cset	w1, lt
    52b4:      	ubfx	x1, x1, #0, #8
    52b8:      	cmp	x1, #0x0
    52bc:      	cset	w1, ne
    52c0:      	uxtb	w16, w1
    52c4:      	cmp	w16, wzr
    52c8:      	b.eq	0x5524 <_stogir.atomic.validate+0x878>
    52cc:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x354>
		00000000000052cc:  ARM64_RELOC_PAGE21	l_stogir.376
    52d0:      	ldr	x16, [x16]
		00000000000052d0:  ARM64_RELOC_PAGEOFF12	l_stogir.376
    52d4:      	orr	x2, x16, xzr
    52d8:      	add	x2, x0, x2
    52dc:      	ldrb	w2, [x2]
    52e0:      	mov	x3, x22
    52e4:      	b	0x552c <_stogir.atomic.validate+0x880>
    52e8:      	add	x16, sp, #0x60
    52ec:      	ldr	x0, [x16, #0x8]
    52f0:      	lsr	w0, w0, #0
    52f4:      	ubfx	x0, x0, #8, #8
    52f8:      	mov	x1, x23
    52fc:      	mov	x2, x27
    5300:      	mov	x19, x0
    5304:      	mov	x0, x1
    5308:      	mov	x1, x2
    530c:      	cmp	x19, #0x2
    5310:      	b.ge	0x53b8 <_stogir.atomic.validate+0x70c>
    5314:      	mov	x2, x1
    5318:      	mov	x1, x0
    531c:      	mov	x0, #0x1                ; =1
    5320:      	b	0x53d4 <_stogir.atomic.validate+0x728>
    5324:      	mov	x1, x27
    5328:      	mov	x2, x23
    532c:      	movz	x0, #0x0, lsl #48
    5330:      	cmp	x0, #0x0
    5334:      	b.eq	0x519c <_stogir.atomic.validate+0x4f0>
    5338:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x354>
		0000000000005338:  ARM64_RELOC_PAGE21	l_stogir.377
    533c:      	ldr	x16, [x16]
		000000000000533c:  ARM64_RELOC_PAGEOFF12	l_stogir.377
    5340:      	orr	x0, x16, xzr
    5344:      	mov	x1, #0x22               ; =34
    5348:      	b	0x51a4 <_stogir.atomic.validate+0x4f8>
    534c:      	mov	x1, x27
    5350:      	mov	x0, #0x1                ; =1
    5354:      	mov	x2, x23
    5358:      	b	0x5330 <_stogir.atomic.validate+0x684>
    535c:      	mov	x27, x0
    5360:      	mov	x0, #0x1                ; =1
    5364:      	cmp	x0, #0x0
    5368:      	b.eq	0x5324 <_stogir.atomic.validate+0x678>
    536c:      	lsr	w0, w19, #0
    5370:      	add	x16, sp, #0x20
    5374:      	ldr	w1, [x16, #0xc]
    5378:      	lsr	w1, w1, #0
    537c:      	mov	w2, w0
    5380:      	mov	x0, x25
    5384:      	bl	0x5384 <_stogir.atomic.validate+0x6d8>
		0000000000005384:  ARM64_RELOC_BRANCH26	_stogir.atomic.ordinary?
    5388:      	cmp	x0, #0x0
    538c:      	b.eq	0x534c <_stogir.atomic.validate+0x6a0>
    5390:      	mov	x1, x27
    5394:      	movz	x0, #0x0, lsl #48
    5398:      	b	0x5354 <_stogir.atomic.validate+0x6a8>
    539c:      	mov	x0, x1
    53a0:      	mov	x23, x2
    53a4:      	cmp	x21, #0x7e
    53a8:      	b.ne	0x535c <_stogir.atomic.validate+0x6b0>
    53ac:      	mov	x27, x0
    53b0:      	movz	x0, #0x0, lsl #48
    53b4:      	b	0x5364 <_stogir.atomic.validate+0x6b8>
    53b8:      	cmp	x19, #0x5
    53bc:      	cset	w2, gt
    53c0:      	ubfx	x2, x2, #0, #8
    53c4:      	fmov	d31, x0
    53c8:      	mov	x0, x2
    53cc:      	mov	x2, x1
    53d0:      	fmov	x1, d31
    53d4:      	cmp	x0, #0x0
    53d8:      	b.eq	0x539c <_stogir.atomic.validate+0x6f0>
    53dc:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x354>
		00000000000053dc:  ARM64_RELOC_PAGE21	l_stogir.378
    53e0:      	ldr	x16, [x16]
		00000000000053e0:  ARM64_RELOC_PAGEOFF12	l_stogir.378
    53e4:      	orr	x0, x16, xzr
    53e8:      	mov	x23, #0x25              ; =37
    53ec:      	b	0x53a4 <_stogir.atomic.validate+0x6f8>
    53f0:      	uxtb	w16, w22
    53f4:      	cmp	w16, wzr
    53f8:      	b.eq	0x5430 <_stogir.atomic.validate+0x784>
    53fc:      	movz	x0, #0x0, lsl #48
    5400:      	b	0x51dc <_stogir.atomic.validate+0x530>
    5404:      	lsr	w1, w1, #0
    5408:      	uxtb	w16, w19
    540c:      	cmp	w16, wzr
    5410:      	b.eq	0x5578 <_stogir.atomic.validate+0x8cc>
    5414:      	sxtw	x1, w1
    5418:      	cmp	x1, #0x0
    541c:      	b.ge	0x5624 <_stogir.atomic.validate+0x978>
    5420:      	mov	x1, x21
    5424:      	mov	x2, x23
    5428:      	mov	x0, #0x1                ; =1
    542c:      	b	0x5638 <_stogir.atomic.validate+0x98c>
    5430:      	sxtw	x27, w27
    5434:      	cmp	x27, #0x0
    5438:      	b.ne	0x559c <_stogir.atomic.validate+0x8f0>
    543c:      	movz	x0, #0x0, lsl #48
    5440:      	b	0x51d4 <_stogir.atomic.validate+0x528>
    5444:      	mov	x2, x0
    5448:      	mov	x0, #0x1                ; =1
    544c:      	cmp	x0, #0x0
    5450:      	b.eq	0x546c <_stogir.atomic.validate+0x7c0>
    5454:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x354>
		0000000000005454:  ARM64_RELOC_PAGE21	l_stogir.379
    5458:      	ldr	x16, [x16]
		0000000000005458:  ARM64_RELOC_PAGEOFF12	l_stogir.379
    545c:      	orr	x0, x16, xzr
    5460:      	mov	x23, x0
    5464:      	mov	x27, #0x19              ; =25
    5468:      	b	0x5474 <_stogir.atomic.validate+0x7c8>
    546c:      	mov	x23, x2
    5470:      	mov	x27, x1
    5474:      	add	x16, sp, #0x20
    5478:      	ldr	w0, [x16, #0xc]
    547c:      	lsr	w0, w0, #0
    5480:      	add	x8, sp, #0x60
    5484:      	mov	w1, w0
    5488:      	mov	x0, x25
    548c:      	bl	0x548c <_stogir.atomic.validate+0x7e0>
		000000000000548c:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    5490:      	add	x16, sp, #0x60
    5494:      	ldr	w0, [x16]
    5498:      	lsr	x16, x0, #0
    549c:      	cmp	x16, #0x1
    54a0:      	b.eq	0x54bc <_stogir.atomic.validate+0x810>
    54a4:      	b.lo	0x54ac <_stogir.atomic.validate+0x800>
    54a8:      	b	0x54c0 <_stogir.atomic.validate+0x814>
    54ac:      	cmp	x16, #0x0
    54b0:      	b.eq	0x54b8 <_stogir.atomic.validate+0x80c>
    54b4:      	b	0x54c0 <_stogir.atomic.validate+0x814>
    54b8:      	b	0x54c4 <_stogir.atomic.validate+0x818>
    54bc:      	b	0x52e8 <_stogir.atomic.validate+0x63c>
    54c0:      	b	0x566c <_stogir.atomic.validate+0x9c0>
    54c4:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x354>
		00000000000054c4:  ARM64_RELOC_PAGE21	l_stogir.380
    54c8:      	ldr	x16, [x16]
		00000000000054c8:  ARM64_RELOC_PAGEOFF12	l_stogir.380
    54cc:      	orr	x0, x16, xzr
    54d0:      	mov	x1, x0
    54d4:      	mov	x0, x19
    54d8:      	mov	x2, #0x1a               ; =26
    54dc:      	b	0x5300 <_stogir.atomic.validate+0x654>
    54e0:      	mov	x2, #0x1                ; =1
    54e4:      	cmp	x2, #0x0
    54e8:      	b.eq	0x54fc <_stogir.atomic.validate+0x850>
    54ec:      	mov	x1, x3
    54f0:      	mov	x2, x23
    54f4:      	mov	x0, #0x1                ; =1
    54f8:      	b	0x528c <_stogir.atomic.validate+0x5e0>
    54fc:      	uxtb	w16, w1
    5500:      	cmp	w16, wzr
    5504:      	b.eq	0x5260 <_stogir.atomic.validate+0x5b4>
    5508:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x354>
		0000000000005508:  ARM64_RELOC_PAGE21	l_stogir.376
    550c:      	ldr	x16, [x16]
		000000000000550c:  ARM64_RELOC_PAGEOFF12	l_stogir.376
    5510:      	orr	x1, x16, xzr
    5514:      	add	x0, x0, x1
    5518:      	ldrb	w0, [x0]
    551c:      	mov	x1, x3
    5520:      	b	0x5268 <_stogir.atomic.validate+0x5bc>
    5524:      	mov	x3, x22
    5528:      	movz	x2, #0x0, lsl #48
    552c:      	uxtb	w2, w2
    5530:      	and	x2, x2, #0x1
    5534:      	uxtb	w2, w2
    5538:      	cmp	x2, #0x0
    553c:      	b.eq	0x54e0 <_stogir.atomic.validate+0x834>
    5540:      	movz	x2, #0x0, lsl #48
    5544:      	b	0x54e4 <_stogir.atomic.validate+0x838>
    5548:      	mov	x3, #-0x2               ; =-2
    554c:      	sxtw	x2, w2
    5550:      	lsr	w3, w3, #0
    5554:      	sxtw	x3, w3
    5558:      	cmp	x2, x3
    555c:      	b.ne	0x4f68 <_stogir.atomic.validate+0x2bc>
    5560:      	mov	x22, x20
    5564:      	movz	x23, #0x0, lsl #48
    5568:      	b	0x4f7c <_stogir.atomic.validate+0x2d0>
    556c:      	mov	x0, x1
    5570:      	mov	x1, x2
    5574:      	b	0x51c4 <_stogir.atomic.validate+0x518>
    5578:      	lsr	w1, w1, #0
    557c:      	mov	x0, x25
    5580:      	mov	w2, w27
    5584:      	bl	0x5584 <_stogir.atomic.validate+0x8d8>
		0000000000005584:  ARM64_RELOC_BRANCH26	_stogir.atomic.ordinary?
    5588:      	cmp	x0, #0x0
    558c:      	b.eq	0x51b4 <_stogir.atomic.validate+0x508>
    5590:      	mov	x0, x21
    5594:      	mov	x1, x23
    5598:      	b	0x51c4 <_stogir.atomic.validate+0x518>
    559c:      	cmp	x27, #0x1
    55a0:      	b.eq	0x51d0 <_stogir.atomic.validate+0x524>
    55a4:      	cmp	x27, #0x2
    55a8:      	b.eq	0x51d0 <_stogir.atomic.validate+0x524>
    55ac:      	cmp	x27, #0x7
    55b0:      	b.eq	0x51d0 <_stogir.atomic.validate+0x524>
    55b4:      	cmp	x27, #0x8
    55b8:      	b.eq	0x51d0 <_stogir.atomic.validate+0x524>
    55bc:      	cmp	x27, #0x3
    55c0:      	b.eq	0x565c <_stogir.atomic.validate+0x9b0>
    55c4:      	cmp	x27, #0x9
    55c8:      	b.eq	0x565c <_stogir.atomic.validate+0x9b0>
    55cc:      	cmp	x27, #0x4
    55d0:      	b.eq	0x5674 <_stogir.atomic.validate+0x9c8>
    55d4:      	cmp	x27, #0xa
    55d8:      	b.eq	0x5674 <_stogir.atomic.validate+0x9c8>
    55dc:      	cmp	x27, #0xd
    55e0:      	b.eq	0x5674 <_stogir.atomic.validate+0x9c8>
    55e4:      	cmp	x27, #0x5
    55e8:      	b.eq	0x567c <_stogir.atomic.validate+0x9d0>
    55ec:      	cmp	x27, #0xb
    55f0:      	b.eq	0x567c <_stogir.atomic.validate+0x9d0>
    55f4:      	cmp	x27, #0xc
    55f8:      	b.eq	0x567c <_stogir.atomic.validate+0x9d0>
    55fc:      	cmp	x27, #0x6
    5600:      	cset	w0, eq
    5604:      	uxtb	w16, w0
    5608:      	cmp	w16, wzr
    560c:      	mov	x16, #0x8               ; =8
    5610:      	movn	x17, #0x0, lsl #48
    5614:      	csel	x0, x16, x17, ne
    5618:      	b	0x5680 <_stogir.atomic.validate+0x9d4>
    561c:      	brk	#0
    5620:      	b	0x561c <_stogir.atomic.validate+0x970>
    5624:      	cmp	x1, #0x9
    5628:      	cset	w0, gt
    562c:      	ubfx	x0, x0, #0, #8
    5630:      	mov	x1, x21
    5634:      	mov	x2, x23
    5638:      	cmp	x0, #0x0
    563c:      	b.eq	0x556c <_stogir.atomic.validate+0x8c0>
    5640:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x354>
		0000000000005640:  ARM64_RELOC_PAGE21	l_stogir.381
    5644:      	ldr	x16, [x16]
		0000000000005644:  ARM64_RELOC_PAGEOFF12	l_stogir.381
    5648:      	orr	x0, x16, xzr
    564c:      	mov	x1, #0x1c               ; =28
    5650:      	b	0x5574 <_stogir.atomic.validate+0x8c8>
    5654:      	brk	#0
    5658:      	b	0x5654 <_stogir.atomic.validate+0x9a8>
    565c:      	mov	x0, #0x2                ; =2
    5660:      	b	0x51d4 <_stogir.atomic.validate+0x528>
    5664:      	brk	#0
    5668:      	b	0x5664 <_stogir.atomic.validate+0x9b8>
    566c:      	brk	#0
    5670:      	b	0x566c <_stogir.atomic.validate+0x9c0>
    5674:      	mov	x0, #0x4                ; =4
    5678:      	b	0x5660 <_stogir.atomic.validate+0x9b4>
    567c:      	mov	x0, #0x8                ; =8
    5680:      	b	0x5678 <_stogir.atomic.validate+0x9cc>

0000000000005684 <_stogir.terminal.operation?>:
    5684:      	sxtw	x0, w0
    5688:      	cmp	x0, #0x60
    568c:      	b.ne	0x5698 <_stogir.terminal.operation?+0x14>
    5690:      	mov	x0, #0x1                ; =1
    5694:      	b	0x56a4 <_stogir.terminal.operation?+0x20>
    5698:      	cmp	x0, #0x79
    569c:      	cset	w0, eq
    56a0:      	ubfx	x0, x0, #0, #8
    56a4:      	ret

00000000000056a8 <_stogir.terminal.validate>:
    56a8:      	sub	sp, sp, #0x50
    56ac:      	str	x29, [sp]
    56b0:      	str	x30, [sp, #0x8]
    56b4:      	mov	x29, sp
    56b8:      	str	x19, [sp, #0x40]
    56bc:      	sxtw	x1, w1
    56c0:      	lsl	x2, x1, #2
    56c4:      	cmp	x1, #0x0
    56c8:      	cset	w3, gt
    56cc:      	movz	x16, #0x0, lsl #48
    56d0:      	sub	x4, x16, x1
    56d4:      	sub	x5, x4, #0x1
    56d8:      	uxtb	w16, w3
    56dc:      	cmp	w16, wzr
    56e0:      	b.eq	0x5720 <_stogir.terminal.validate+0x78>
    56e4:      	ldr	x4, [x0, #0x8]
    56e8:      	cmp	x1, x4
    56ec:      	b.ge	0x5774 <_stogir.terminal.validate+0xcc>
    56f0:      	add	x4, x0, #0x78
    56f4:      	ldr	x4, [x4, #0x8]
    56f8:      	cmp	x1, x4
    56fc:      	b.ge	0x5898 <_stogir.terminal.validate+0x1f0>
    5700:      	ldr	x4, [x0, #0x78]
    5704:      	add	x4, x2, x4
    5708:      	ldr	w4, [x4]
    570c:      	sxtw	x4, w4
    5710:      	cmp	x4, #0x0
    5714:      	cset	w4, ge
    5718:      	ubfx	x4, x4, #0, #8
    571c:      	b	0x589c <_stogir.terminal.validate+0x1f4>
    5720:      	cmp	x1, #0x0
    5724:      	b.ge	0x577c <_stogir.terminal.validate+0xd4>
    5728:      	add	x6, x0, #0x28
    572c:      	add	x7, x0, #0x50
    5730:      	ldr	x6, [x6, #0x8]
    5734:      	ldr	x7, [x7, #0x8]
    5738:      	cmp	x6, x7
    573c:      	b.ne	0x576c <_stogir.terminal.validate+0xc4>
    5740:      	cmp	x4, x6
    5744:      	b.gt	0x58d8 <_stogir.terminal.validate+0x230>
    5748:      	lsl	x4, x5, #2
    574c:      	ldr	x6, [x0, #0x50]
    5750:      	add	x4, x4, x6
    5754:      	ldr	w4, [x4]
    5758:      	sxtw	x4, w4
    575c:      	cmp	x4, #0x0
    5760:      	cset	w4, gt
    5764:      	ubfx	x4, x4, #0, #8
    5768:      	b	0x58dc <_stogir.terminal.validate+0x234>
    576c:      	movz	x4, #0x0, lsl #48
    5770:      	b	0x5780 <_stogir.terminal.validate+0xd8>
    5774:      	movz	x4, #0x0, lsl #48
    5778:      	b	0x5780 <_stogir.terminal.validate+0xd8>
    577c:      	movz	x4, #0x0, lsl #48
    5780:      	cmp	x4, #0x0
    5784:      	b.eq	0x57e8 <_stogir.terminal.validate+0x140>
    5788:      	uxtb	w16, w3
    578c:      	cmp	w16, wzr
    5790:      	b.eq	0x57b8 <_stogir.terminal.validate+0x110>
    5794:      	lsl	x3, x1, #4
    5798:      	ldr	x4, [x0]
    579c:      	add	x3, x3, x4
    57a0:      	ldr	x4, [x3]
    57a4:      	ldr	x3, [x3, #0x8]
    57a8:      	fmov	d31, x3
    57ac:      	mov	x3, x4
    57b0:      	fmov	x4, d31
    57b4:      	b	0x57d8 <_stogir.terminal.validate+0x130>
    57b8:      	lsl	x3, x5, #4
    57bc:      	ldr	x4, [x0, #0x28]
    57c0:      	add	x3, x3, x4
    57c4:      	ldr	x4, [x3]
    57c8:      	ldr	x3, [x3, #0x8]
    57cc:      	fmov	d31, x3
    57d0:      	mov	x3, x4
    57d4:      	fmov	x4, d31
    57d8:      	mov	x5, x4
    57dc:      	mov	x4, x3
    57e0:      	mov	x3, #0x1                ; =1
    57e4:      	b	0x57f4 <_stogir.terminal.validate+0x14c>
    57e8:      	movz	x3, #0x0, lsl #48
    57ec:      	movz	x4, #0x0, lsl #48
    57f0:      	movz	x5, #0x0, lsl #48
    57f4:      	lsr	w3, w3, #0
    57f8:      	lsr	x16, x3, #0
    57fc:      	cmp	x16, #0x1
    5800:      	b.eq	0x581c <_stogir.terminal.validate+0x174>
    5804:      	b.lo	0x580c <_stogir.terminal.validate+0x164>
    5808:      	b	0x5820 <_stogir.terminal.validate+0x178>
    580c:      	cmp	x16, #0x0
    5810:      	b.eq	0x5818 <_stogir.terminal.validate+0x170>
    5814:      	b	0x5820 <_stogir.terminal.validate+0x178>
    5818:      	b	0x5824 <_stogir.terminal.validate+0x17c>
    581c:      	b	0x5844 <_stogir.terminal.validate+0x19c>
    5820:      	b	0x59b4 <_stogir.terminal.validate+0x30c>
    5824:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x354>
		0000000000005824:  ARM64_RELOC_PAGE21	l_stogir.382
    5828:      	ldr	x16, [x16]
		0000000000005828:  ARM64_RELOC_PAGEOFF12	l_stogir.382
    582c:      	orr	x0, x16, xzr
    5830:      	mov	x19, x8
    5834:      	mov	x1, x0
    5838:      	mov	x0, #0x1                ; =1
    583c:      	mov	x2, #0x21               ; =33
    5840:      	b	0x5878 <_stogir.terminal.validate+0x1d0>
    5844:      	add	x16, sp, #0x10
    5848:      	str	x4, [x16]
    584c:      	add	x16, sp, #0x10
    5850:      	str	x5, [x16, #0x8]
    5854:      	cmp	x1, #0x0
    5858:      	b.gt	0x58a0 <_stogir.terminal.validate+0x1f8>
    585c:      	mov	x19, x8
    5860:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x354>
		0000000000005860:  ARM64_RELOC_PAGE21	l_stogir.383
    5864:      	ldr	x16, [x16]
		0000000000005864:  ARM64_RELOC_PAGEOFF12	l_stogir.383
    5868:      	orr	x0, x16, xzr
    586c:      	mov	x1, x0
    5870:      	mov	x0, #0x1                ; =1
    5874:      	mov	x2, #0x1b               ; =27
    5878:      	str	x0, [x19]
    587c:      	str	x1, [x19, #0x8]
    5880:      	str	x2, [x19, #0x10]
    5884:      	ldr	x19, [sp, #0x40]
    5888:      	ldr	x29, [sp]
    588c:      	ldr	x30, [sp, #0x8]
    5890:      	add	sp, sp, #0x50
    5894:      	ret
    5898:      	movz	x4, #0x0, lsl #48
    589c:      	b	0x5778 <_stogir.terminal.validate+0xd0>
    58a0:      	uxtb	w4, w4
    58a4:      	orr	x1, x4, xzr
    58a8:      	cmp	x1, #0x60
    58ac:      	cset	w3, eq
    58b0:      	cmp	x1, #0x79
    58b4:      	cset	w1, eq
    58b8:      	uxtb	w16, w3
    58bc:      	cmp	w16, wzr
    58c0:      	b.ne	0x58e0 <_stogir.terminal.validate+0x238>
    58c4:      	uxtb	w16, w1
    58c8:      	cmp	w16, wzr
    58cc:      	b.ne	0x58e0 <_stogir.terminal.validate+0x238>
    58d0:      	mov	x19, x8
    58d4:      	b	0x5860 <_stogir.terminal.validate+0x1b8>
    58d8:      	movz	x4, #0x0, lsl #48
    58dc:      	b	0x5770 <_stogir.terminal.validate+0xc8>
    58e0:      	add	x16, sp, #0x10
    58e4:      	ldr	w5, [x16]
    58e8:      	ubfx	x5, x5, #8, #8
    58ec:      	cmp	x5, #0x0
    58f0:      	b.ne	0x59bc <_stogir.terminal.validate+0x314>
    58f4:      	uxtb	w16, w3
    58f8:      	cmp	w16, wzr
    58fc:      	mov	x16, #0x1               ; =1
    5900:      	mov	x17, #0x3               ; =3
    5904:      	csel	x3, x16, x17, ne
    5908:      	lsr	w3, w3, #0
    590c:      	sxtw	x3, w3
    5910:      	ldr	x5, [x0, #0x78]
    5914:      	add	x2, x2, x5
    5918:      	ldr	w2, [x2]
    591c:      	sxtw	x2, w2
    5920:      	cmp	x2, x3
    5924:      	b.ne	0x59c4 <_stogir.terminal.validate+0x31c>
    5928:      	uxtb	w16, w1
    592c:      	cmp	w16, wzr
    5930:      	b.eq	0x5990 <_stogir.terminal.validate+0x2e8>
    5934:      	add	x16, sp, #0x10
    5938:      	ldr	w2, [x16, #0x8]
    593c:      	sxtw	x2, w2
    5940:      	cmp	x2, #0x0
    5944:      	b.eq	0x5990 <_stogir.terminal.validate+0x2e8>
    5948:      	mov	x19, x8
    594c:      	b	0x5860 <_stogir.terminal.validate+0x1b8>
    5950:      	movz	x1, #0x0, lsl #48
    5954:      	lsr	w2, w2, #0
    5958:      	lsr	w4, w4, #0
    595c:      	lsr	w1, w1, #0
    5960:      	mov	w3, w1
    5964:      	mov	w1, w4
    5968:      	mov	x19, x8
    596c:      	add	x8, sp, #0x20
    5970:      	bl	0x5970 <_stogir.terminal.validate+0x2c8>
		0000000000005970:  ARM64_RELOC_BRANCH26	_stogir.terminal.inputs
    5974:      	add	x16, sp, #0x20
    5978:      	ldr	x0, [x16]
    597c:      	add	x16, sp, #0x20
    5980:      	ldr	x1, [x16, #0x8]
    5984:      	add	x16, sp, #0x20
    5988:      	ldr	x2, [x16, #0x10]
    598c:      	b	0x5878 <_stogir.terminal.validate+0x1d0>
    5990:      	add	x16, sp, #0x10
    5994:      	ldr	w2, [x16, #0x4]
    5998:      	uxtb	w16, w1
    599c:      	cmp	w16, wzr
    59a0:      	b.eq	0x5950 <_stogir.terminal.validate+0x2a8>
    59a4:      	add	x16, sp, #0x10
    59a8:      	ldr	w1, [x16, #0xc]
    59ac:      	sxtw	x1, w1
    59b0:      	b	0x5954 <_stogir.terminal.validate+0x2ac>
    59b4:      	brk	#0
    59b8:      	b	0x59b4 <_stogir.terminal.validate+0x30c>
    59bc:      	mov	x19, x8
    59c0:      	b	0x5860 <_stogir.terminal.validate+0x1b8>
    59c4:      	mov	x19, x8
    59c8:      	b	0x5860 <_stogir.terminal.validate+0x1b8>

00000000000059cc <_stogir.switch.operation?>:
    59cc:      	sxtw	x0, w0
    59d0:      	cmp	x0, #0x75
    59d4:      	b.ne	0x59e8 <_stogir.switch.operation?+0x1c>
    59d8:      	mov	x0, #0x1                ; =1
    59dc:      	b	0x59e4 <_stogir.switch.operation?+0x18>
    59e0:      	movz	x0, #0x0, lsl #48
    59e4:      	ret
    59e8:      	cmp	x0, #0x6d
    59ec:      	b.lt	0x59e0 <_stogir.switch.operation?+0x14>
    59f0:      	cmp	x0, #0x6f
    59f4:      	cset	w0, le
    59f8:      	ubfx	x0, x0, #0, #8
    59fc:      	b	0x59e4 <_stogir.switch.operation?+0x18>

0000000000005a00 <_stogir.switch.validate>:
    5a00:      	sub	sp, sp, #0x70
    5a04:      	str	x29, [sp]
    5a08:      	str	x30, [sp, #0x8]
    5a0c:      	mov	x29, sp
    5a10:      	str	x19, [sp, #0x60]
    5a14:      	sxtw	x1, w1
    5a18:      	lsl	x2, x1, #2
    5a1c:      	cmp	x1, #0x0
    5a20:      	cset	w3, gt
    5a24:      	movz	x16, #0x0, lsl #48
    5a28:      	sub	x4, x16, x1
    5a2c:      	sub	x5, x4, #0x1
    5a30:      	uxtb	w16, w3
    5a34:      	cmp	w16, wzr
    5a38:      	b.eq	0x5a78 <_stogir.switch.validate+0x78>
    5a3c:      	ldr	x4, [x0, #0x8]
    5a40:      	cmp	x1, x4
    5a44:      	b.ge	0x5acc <_stogir.switch.validate+0xcc>
    5a48:      	add	x4, x0, #0x78
    5a4c:      	ldr	x4, [x4, #0x8]
    5a50:      	cmp	x1, x4
    5a54:      	b.ge	0x5bf0 <_stogir.switch.validate+0x1f0>
    5a58:      	ldr	x4, [x0, #0x78]
    5a5c:      	add	x4, x2, x4
    5a60:      	ldr	w4, [x4]
    5a64:      	sxtw	x4, w4
    5a68:      	cmp	x4, #0x0
    5a6c:      	cset	w4, ge
    5a70:      	ubfx	x4, x4, #0, #8
    5a74:      	b	0x5bf4 <_stogir.switch.validate+0x1f4>
    5a78:      	cmp	x1, #0x0
    5a7c:      	b.ge	0x5ad4 <_stogir.switch.validate+0xd4>
    5a80:      	add	x6, x0, #0x28
    5a84:      	add	x7, x0, #0x50
    5a88:      	ldr	x6, [x6, #0x8]
    5a8c:      	ldr	x7, [x7, #0x8]
    5a90:      	cmp	x6, x7
    5a94:      	b.ne	0x5ac4 <_stogir.switch.validate+0xc4>
    5a98:      	cmp	x4, x6
    5a9c:      	b.gt	0x5c2c <_stogir.switch.validate+0x22c>
    5aa0:      	lsl	x4, x5, #2
    5aa4:      	ldr	x6, [x0, #0x50]
    5aa8:      	add	x4, x4, x6
    5aac:      	ldr	w4, [x4]
    5ab0:      	sxtw	x4, w4
    5ab4:      	cmp	x4, #0x0
    5ab8:      	cset	w4, gt
    5abc:      	ubfx	x4, x4, #0, #8
    5ac0:      	b	0x5c30 <_stogir.switch.validate+0x230>
    5ac4:      	movz	x4, #0x0, lsl #48
    5ac8:      	b	0x5ad8 <_stogir.switch.validate+0xd8>
    5acc:      	movz	x4, #0x0, lsl #48
    5ad0:      	b	0x5ad8 <_stogir.switch.validate+0xd8>
    5ad4:      	movz	x4, #0x0, lsl #48
    5ad8:      	cmp	x4, #0x0
    5adc:      	b.eq	0x5b40 <_stogir.switch.validate+0x140>
    5ae0:      	uxtb	w16, w3
    5ae4:      	cmp	w16, wzr
    5ae8:      	b.eq	0x5b10 <_stogir.switch.validate+0x110>
    5aec:      	lsl	x3, x1, #4
    5af0:      	ldr	x4, [x0]
    5af4:      	add	x3, x3, x4
    5af8:      	ldr	x4, [x3]
    5afc:      	ldr	x3, [x3, #0x8]
    5b00:      	fmov	d31, x3
    5b04:      	mov	x3, x4
    5b08:      	fmov	x4, d31
    5b0c:      	b	0x5b30 <_stogir.switch.validate+0x130>
    5b10:      	lsl	x3, x5, #4
    5b14:      	ldr	x4, [x0, #0x28]
    5b18:      	add	x3, x3, x4
    5b1c:      	ldr	x4, [x3]
    5b20:      	ldr	x3, [x3, #0x8]
    5b24:      	fmov	d31, x3
    5b28:      	mov	x3, x4
    5b2c:      	fmov	x4, d31
    5b30:      	mov	x5, x4
    5b34:      	mov	x4, x3
    5b38:      	mov	x3, #0x1                ; =1
    5b3c:      	b	0x5b4c <_stogir.switch.validate+0x14c>
    5b40:      	movz	x3, #0x0, lsl #48
    5b44:      	movz	x4, #0x0, lsl #48
    5b48:      	movz	x5, #0x0, lsl #48
    5b4c:      	lsr	w3, w3, #0
    5b50:      	lsr	x16, x3, #0
    5b54:      	cmp	x16, #0x1
    5b58:      	b.eq	0x5b74 <_stogir.switch.validate+0x174>
    5b5c:      	b.lo	0x5b64 <_stogir.switch.validate+0x164>
    5b60:      	b	0x5b78 <_stogir.switch.validate+0x178>
    5b64:      	cmp	x16, #0x0
    5b68:      	b.eq	0x5b70 <_stogir.switch.validate+0x170>
    5b6c:      	b	0x5b78 <_stogir.switch.validate+0x178>
    5b70:      	b	0x5b7c <_stogir.switch.validate+0x17c>
    5b74:      	b	0x5b9c <_stogir.switch.validate+0x19c>
    5b78:      	b	0x5d30 <_stogir.switch.validate+0x330>
    5b7c:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x354>
		0000000000005b7c:  ARM64_RELOC_PAGE21	l_stogir.384
    5b80:      	ldr	x16, [x16]
		0000000000005b80:  ARM64_RELOC_PAGEOFF12	l_stogir.384
    5b84:      	orr	x0, x16, xzr
    5b88:      	mov	x19, x8
    5b8c:      	mov	x1, x0
    5b90:      	mov	x0, #0x1                ; =1
    5b94:      	mov	x2, #0x1a               ; =26
    5b98:      	b	0x5bd0 <_stogir.switch.validate+0x1d0>
    5b9c:      	add	x16, sp, #0x10
    5ba0:      	str	x4, [x16]
    5ba4:      	add	x16, sp, #0x10
    5ba8:      	str	x5, [x16, #0x8]
    5bac:      	cmp	x1, #0x0
    5bb0:      	b.gt	0x5bf8 <_stogir.switch.validate+0x1f8>
    5bb4:      	mov	x19, x8
    5bb8:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x354>
		0000000000005bb8:  ARM64_RELOC_PAGE21	l_stogir.385
    5bbc:      	ldr	x16, [x16]
		0000000000005bbc:  ARM64_RELOC_PAGEOFF12	l_stogir.385
    5bc0:      	orr	x0, x16, xzr
    5bc4:      	mov	x1, x0
    5bc8:      	mov	x0, #0x1                ; =1
    5bcc:      	mov	x2, #0x20               ; =32
    5bd0:      	str	x0, [x19]
    5bd4:      	str	x1, [x19, #0x8]
    5bd8:      	str	x2, [x19, #0x10]
    5bdc:      	ldr	x19, [sp, #0x60]
    5be0:      	ldr	x29, [sp]
    5be4:      	ldr	x30, [sp, #0x8]
    5be8:      	add	sp, sp, #0x70
    5bec:      	ret
    5bf0:      	movz	x4, #0x0, lsl #48
    5bf4:      	b	0x5ad0 <_stogir.switch.validate+0xd0>
    5bf8:      	uxtb	w4, w4
    5bfc:      	orr	x1, x4, xzr
    5c00:      	cmp	x1, #0x75
    5c04:      	cset	w3, eq
    5c08:      	uxtb	w16, w3
    5c0c:      	cmp	w16, wzr
    5c10:      	b.ne	0x5c34 <_stogir.switch.validate+0x234>
    5c14:      	cmp	x1, #0x6d
    5c18:      	b.lt	0x5d38 <_stogir.switch.validate+0x338>
    5c1c:      	cmp	x1, #0x6f
    5c20:      	b.le	0x5c34 <_stogir.switch.validate+0x234>
    5c24:      	mov	x19, x8
    5c28:      	b	0x5bb8 <_stogir.switch.validate+0x1b8>
    5c2c:      	movz	x4, #0x0, lsl #48
    5c30:      	b	0x5ac8 <_stogir.switch.validate+0xc8>
    5c34:      	add	x16, sp, #0x10
    5c38:      	ldr	w5, [x16]
    5c3c:      	ubfx	x5, x5, #8, #8
    5c40:      	cmp	x5, #0x0
    5c44:      	b.ne	0x5d40 <_stogir.switch.validate+0x340>
    5c48:      	ldr	x5, [x0, #0x78]
    5c4c:      	add	x2, x2, x5
    5c50:      	ldr	w2, [x2]
    5c54:      	cmp	x1, #0x6d
    5c58:      	b.eq	0x5ccc <_stogir.switch.validate+0x2cc>
    5c5c:      	cmp	x1, #0x6e
    5c60:      	b.eq	0x5ccc <_stogir.switch.validate+0x2cc>
    5c64:      	mov	x1, #0x2                ; =2
    5c68:      	b	0x5cd0 <_stogir.switch.validate+0x2d0>
    5c6c:      	lsr	w4, w4, #0
    5c70:      	add	x16, sp, #0x10
    5c74:      	ldr	w1, [x16, #0x4]
    5c78:      	add	x16, sp, #0x10
    5c7c:      	ldr	w2, [x16, #0x8]
    5c80:      	lsr	w1, w1, #0
    5c84:      	add	x16, sp, #0x10
    5c88:      	ldr	w3, [x16, #0xc]
    5c8c:      	lsr	w2, w2, #0
    5c90:      	lsr	w3, w3, #0
    5c94:      	add	x8, sp, #0x40
    5c98:      	fmov	s31, w1
    5c9c:      	mov	w1, w4
    5ca0:      	mov	w4, w3
    5ca4:      	mov	w3, w2
    5ca8:      	fmov	w2, s31
    5cac:      	bl	0x5cac <_stogir.switch.validate+0x2ac>
		0000000000005cac:  ARM64_RELOC_BRANCH26	_stogir.switch.case-inputs
    5cb0:      	add	x16, sp, #0x40
    5cb4:      	ldr	x0, [x16]
    5cb8:      	add	x16, sp, #0x40
    5cbc:      	ldr	x1, [x16, #0x8]
    5cc0:      	add	x16, sp, #0x40
    5cc4:      	ldr	x2, [x16, #0x10]
    5cc8:      	b	0x5bd0 <_stogir.switch.validate+0x1d0>
    5ccc:      	mov	x1, #0x3                ; =3
    5cd0:      	sxtw	x2, w2
    5cd4:      	lsr	w1, w1, #0
    5cd8:      	sxtw	x1, w1
    5cdc:      	cmp	x2, x1
    5ce0:      	b.ne	0x5d48 <_stogir.switch.validate+0x348>
    5ce4:      	uxtb	w16, w3
    5ce8:      	cmp	w16, wzr
    5cec:      	b.eq	0x5d50 <_stogir.switch.validate+0x350>
    5cf0:      	add	x16, sp, #0x10
    5cf4:      	ldr	w1, [x16, #0x4]
    5cf8:      	add	x16, sp, #0x10
    5cfc:      	ldr	w2, [x16, #0x8]
    5d00:      	lsr	w1, w1, #0
    5d04:      	lsr	w2, w2, #0
    5d08:      	mov	x19, x8
    5d0c:      	add	x8, sp, #0x20
    5d10:      	bl	0x5d10 <_stogir.switch.validate+0x310>
		0000000000005d10:  ARM64_RELOC_BRANCH26	_stogir.switch.switch-inputs
    5d14:      	add	x16, sp, #0x20
    5d18:      	ldr	x0, [x16]
    5d1c:      	add	x16, sp, #0x20
    5d20:      	ldr	x1, [x16, #0x8]
    5d24:      	add	x16, sp, #0x20
    5d28:      	ldr	x2, [x16, #0x10]
    5d2c:      	b	0x5cc8 <_stogir.switch.validate+0x2c8>
    5d30:      	brk	#0
    5d34:      	b	0x5d30 <_stogir.switch.validate+0x330>
    5d38:      	mov	x19, x8
    5d3c:      	b	0x5bb8 <_stogir.switch.validate+0x1b8>
    5d40:      	mov	x19, x8
    5d44:      	b	0x5bb8 <_stogir.switch.validate+0x1b8>
    5d48:      	mov	x19, x8
    5d4c:      	b	0x5bb8 <_stogir.switch.validate+0x1b8>
    5d50:      	mov	x19, x8
    5d54:      	b	0x5c6c <_stogir.switch.validate+0x26c>

0000000000005d58 <_stogir.stack.operation?>:
    5d58:      	sxtw	x0, w0
    5d5c:      	cmp	x0, #0x42
    5d60:      	b.ne	0x5d7c <_stogir.stack.operation?+0x24>
    5d64:      	mov	x0, #0x1                ; =1
    5d68:      	b	0x5d78 <_stogir.stack.operation?+0x20>
    5d6c:      	cmp	x0, #0x54
    5d70:      	cset	w0, eq
    5d74:      	ubfx	x0, x0, #0, #8
    5d78:      	ret
    5d7c:      	cmp	x0, #0x51
    5d80:      	b.ne	0x5d8c <_stogir.stack.operation?+0x34>
    5d84:      	mov	x0, #0x1                ; =1
    5d88:      	b	0x5d78 <_stogir.stack.operation?+0x20>
    5d8c:      	cmp	x0, #0x52
    5d90:      	b.ne	0x5d9c <_stogir.stack.operation?+0x44>
    5d94:      	mov	x0, #0x1                ; =1
    5d98:      	b	0x5d78 <_stogir.stack.operation?+0x20>
    5d9c:      	cmp	x0, #0x53
    5da0:      	b.ne	0x5d6c <_stogir.stack.operation?+0x14>
    5da4:      	mov	x0, #0x1                ; =1
    5da8:      	b	0x5d78 <_stogir.stack.operation?+0x20>

0000000000005dac <_stogir.stack.validate>:
    5dac:      	sub	sp, sp, #0x90
    5db0:      	str	x29, [sp]
    5db4:      	str	x30, [sp, #0x8]
    5db8:      	mov	x29, sp
    5dbc:      	str	x19, [sp, #0x60]
    5dc0:      	str	x20, [sp, #0x68]
    5dc4:      	str	x21, [sp, #0x70]
    5dc8:      	str	x22, [sp, #0x78]
    5dcc:      	str	x23, [sp, #0x80]
    5dd0:      	sxtw	x1, w1
    5dd4:      	lsl	x2, x1, #2
    5dd8:      	cmp	x1, #0x0
    5ddc:      	cset	w3, gt
    5de0:      	movz	x16, #0x0, lsl #48
    5de4:      	sub	x4, x16, x1
    5de8:      	cmp	x1, #0x0
    5dec:      	cset	w5, lt
    5df0:      	sub	x6, x4, #0x1
    5df4:      	lsl	x7, x6, #2
    5df8:      	uxtb	w16, w3
    5dfc:      	cmp	w16, wzr
    5e00:      	b.eq	0x5e40 <_stogir.stack.validate+0x94>
    5e04:      	ldr	x9, [x0, #0x8]
    5e08:      	cmp	x1, x9
    5e0c:      	b.ge	0x5ec0 <_stogir.stack.validate+0x114>
    5e10:      	add	x9, x0, #0x78
    5e14:      	ldr	x9, [x9, #0x8]
    5e18:      	cmp	x1, x9
    5e1c:      	b.ge	0x602c <_stogir.stack.validate+0x280>
    5e20:      	ldr	x9, [x0, #0x78]
    5e24:      	add	x9, x2, x9
    5e28:      	ldr	w9, [x9]
    5e2c:      	sxtw	x9, w9
    5e30:      	cmp	x9, #0x0
    5e34:      	cset	w9, ge
    5e38:      	ubfx	x9, x9, #0, #8
    5e3c:      	b	0x6030 <_stogir.stack.validate+0x284>
    5e40:      	uxtb	w16, w5
    5e44:      	cmp	w16, wzr
    5e48:      	b.eq	0x5ec8 <_stogir.stack.validate+0x11c>
    5e4c:      	add	x9, x0, #0x28
    5e50:      	add	x10, x0, #0x50
    5e54:      	ldr	x9, [x9, #0x8]
    5e58:      	ldr	x10, [x10, #0x8]
    5e5c:      	cmp	x9, x10
    5e60:      	b.ne	0x5e8c <_stogir.stack.validate+0xe0>
    5e64:      	cmp	x4, x9
    5e68:      	b.gt	0x6034 <_stogir.stack.validate+0x288>
    5e6c:      	ldr	x9, [x0, #0x50]
    5e70:      	add	x9, x7, x9
    5e74:      	ldr	w9, [x9]
    5e78:      	sxtw	x9, w9
    5e7c:      	cmp	x9, #0x0
    5e80:      	cset	w9, gt
    5e84:      	ubfx	x9, x9, #0, #8
    5e88:      	b	0x6038 <_stogir.stack.validate+0x28c>
    5e8c:      	movz	x9, #0x0, lsl #48
    5e90:      	b	0x5ecc <_stogir.stack.validate+0x120>
    5e94:      	uxtb	w16, w9
    5e98:      	cmp	w16, wzr
    5e9c:      	b.eq	0x605c <_stogir.stack.validate+0x2b0>
    5ea0:      	mov	x22, x8
    5ea4:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x354>
		0000000000005ea4:  ARM64_RELOC_PAGE21	l_stogir.386
    5ea8:      	ldr	x16, [x16]
		0000000000005ea8:  ARM64_RELOC_PAGEOFF12	l_stogir.386
    5eac:      	orr	x0, x16, xzr
    5eb0:      	mov	x1, x0
    5eb4:      	mov	x0, #0x1                ; =1
    5eb8:      	mov	x2, #0x19               ; =25
    5ebc:      	b	0x5f8c <_stogir.stack.validate+0x1e0>
    5ec0:      	movz	x9, #0x0, lsl #48
    5ec4:      	b	0x5ecc <_stogir.stack.validate+0x120>
    5ec8:      	movz	x9, #0x0, lsl #48
    5ecc:      	lsl	x10, x1, #4
    5ed0:      	lsl	x6, x6, #4
    5ed4:      	cmp	x9, #0x0
    5ed8:      	b.eq	0x5f34 <_stogir.stack.validate+0x188>
    5edc:      	uxtb	w16, w3
    5ee0:      	cmp	w16, wzr
    5ee4:      	b.eq	0x5f08 <_stogir.stack.validate+0x15c>
    5ee8:      	ldr	x9, [x0]
    5eec:      	add	x9, x10, x9
    5ef0:      	ldr	x11, [x9]
    5ef4:      	ldr	x9, [x9, #0x8]
    5ef8:      	fmov	d31, x9
    5efc:      	mov	x9, x11
    5f00:      	fmov	x11, d31
    5f04:      	b	0x5f24 <_stogir.stack.validate+0x178>
    5f08:      	ldr	x9, [x0, #0x28]
    5f0c:      	add	x9, x6, x9
    5f10:      	ldr	x11, [x9]
    5f14:      	ldr	x9, [x9, #0x8]
    5f18:      	fmov	d31, x9
    5f1c:      	mov	x9, x11
    5f20:      	fmov	x11, d31
    5f24:      	mov	x12, x11
    5f28:      	mov	x11, x9
    5f2c:      	mov	x9, #0x1                ; =1
    5f30:      	b	0x5f40 <_stogir.stack.validate+0x194>
    5f34:      	movz	x9, #0x0, lsl #48
    5f38:      	movz	x11, #0x0, lsl #48
    5f3c:      	movz	x12, #0x0, lsl #48
    5f40:      	lsr	w9, w9, #0
    5f44:      	lsr	x16, x9, #0
    5f48:      	cmp	x16, #0x1
    5f4c:      	b.eq	0x5f68 <_stogir.stack.validate+0x1bc>
    5f50:      	b.lo	0x5f58 <_stogir.stack.validate+0x1ac>
    5f54:      	b	0x5f6c <_stogir.stack.validate+0x1c0>
    5f58:      	cmp	x16, #0x0
    5f5c:      	b.eq	0x5f64 <_stogir.stack.validate+0x1b8>
    5f60:      	b	0x5f6c <_stogir.stack.validate+0x1c0>
    5f64:      	b	0x5f70 <_stogir.stack.validate+0x1c4>
    5f68:      	b	0x5fbc <_stogir.stack.validate+0x210>
    5f6c:      	b	0x63b0 <_stogir.stack.validate+0x604>
    5f70:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x354>
		0000000000005f70:  ARM64_RELOC_PAGE21	l_stogir.387
    5f74:      	ldr	x16, [x16]
		0000000000005f74:  ARM64_RELOC_PAGEOFF12	l_stogir.387
    5f78:      	orr	x0, x16, xzr
    5f7c:      	mov	x22, x8
    5f80:      	mov	x1, x0
    5f84:      	mov	x0, #0x1                ; =1
    5f88:      	mov	x2, #0x19               ; =25
    5f8c:      	str	x0, [x22]
    5f90:      	str	x1, [x22, #0x8]
    5f94:      	str	x2, [x22, #0x10]
    5f98:      	ldr	x19, [sp, #0x60]
    5f9c:      	ldr	x20, [sp, #0x68]
    5fa0:      	ldr	x21, [sp, #0x70]
    5fa4:      	ldr	x22, [sp, #0x78]
    5fa8:      	ldr	x23, [sp, #0x80]
    5fac:      	ldr	x29, [sp]
    5fb0:      	ldr	x30, [sp, #0x8]
    5fb4:      	add	sp, sp, #0x90
    5fb8:      	ret
    5fbc:      	cmp	x1, #0x0
    5fc0:      	cset	w9, le
    5fc4:      	uxtb	w19, w11
    5fc8:      	add	x16, sp, #0x10
    5fcc:      	str	x11, [x16]
    5fd0:      	orr	x11, x19, xzr
    5fd4:      	add	x16, sp, #0x10
    5fd8:      	str	x12, [x16, #0x8]
    5fdc:      	cmp	x11, #0x42
    5fe0:      	b.ne	0x5e94 <_stogir.stack.validate+0xe8>
    5fe4:      	uxtb	w16, w3
    5fe8:      	cmp	w16, wzr
    5fec:      	b.eq	0x60a8 <_stogir.stack.validate+0x2fc>
    5ff0:      	ldr	x4, [x0, #0x8]
    5ff4:      	cmp	x1, x4
    5ff8:      	b.ge	0x60f4 <_stogir.stack.validate+0x348>
    5ffc:      	add	x4, x0, #0x78
    6000:      	ldr	x4, [x4, #0x8]
    6004:      	cmp	x1, x4
    6008:      	b.ge	0x61e8 <_stogir.stack.validate+0x43c>
    600c:      	ldr	x1, [x0, #0x78]
    6010:      	add	x1, x2, x1
    6014:      	ldr	w1, [x1]
    6018:      	sxtw	x1, w1
    601c:      	cmp	x1, #0x0
    6020:      	cset	w1, ge
    6024:      	ubfx	x1, x1, #0, #8
    6028:      	b	0x61ec <_stogir.stack.validate+0x440>
    602c:      	movz	x9, #0x0, lsl #48
    6030:      	b	0x5ec4 <_stogir.stack.validate+0x118>
    6034:      	movz	x9, #0x0, lsl #48
    6038:      	b	0x5e90 <_stogir.stack.validate+0xe4>
    603c:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x254>
		000000000000603c:  ARM64_RELOC_PAGE21	l_stogir.388
    6040:      	ldr	x16, [x16]
		0000000000006040:  ARM64_RELOC_PAGEOFF12	l_stogir.388
    6044:      	orr	x0, x16, xzr
    6048:      	mov	x1, x0
    604c:      	mov	x0, #0x1                ; =1
    6050:      	mov	x2, #0x1e               ; =30
    6054:      	mov	x22, x8
    6058:      	b	0x5ebc <_stogir.stack.validate+0x110>
    605c:      	cmp	x11, #0x51
    6060:      	cset	w1, eq
    6064:      	cmp	x11, #0x53
    6068:      	cset	w20, eq
    606c:      	cmp	x11, #0x54
    6070:      	cset	w21, eq
    6074:      	uxtb	w16, w1
    6078:      	cmp	w16, wzr
    607c:      	b.ne	0x61f0 <_stogir.stack.validate+0x444>
    6080:      	cmp	x11, #0x52
    6084:      	b.eq	0x61f0 <_stogir.stack.validate+0x444>
    6088:      	uxtb	w16, w20
    608c:      	cmp	w16, wzr
    6090:      	b.ne	0x61f0 <_stogir.stack.validate+0x444>
    6094:      	uxtb	w16, w21
    6098:      	cmp	w16, wzr
    609c:      	b.ne	0x61f0 <_stogir.stack.validate+0x444>
    60a0:      	mov	x22, x8
    60a4:      	b	0x5ea4 <_stogir.stack.validate+0xf8>
    60a8:      	uxtb	w16, w5
    60ac:      	cmp	w16, wzr
    60b0:      	b.eq	0x60fc <_stogir.stack.validate+0x350>
    60b4:      	add	x1, x0, #0x28
    60b8:      	add	x5, x0, #0x50
    60bc:      	ldr	x1, [x1, #0x8]
    60c0:      	ldr	x5, [x5, #0x8]
    60c4:      	cmp	x1, x5
    60c8:      	b.ne	0x61e0 <_stogir.stack.validate+0x434>
    60cc:      	cmp	x4, x1
    60d0:      	b.gt	0x634c <_stogir.stack.validate+0x5a0>
    60d4:      	ldr	x1, [x0, #0x50]
    60d8:      	add	x1, x7, x1
    60dc:      	ldr	w1, [x1]
    60e0:      	sxtw	x1, w1
    60e4:      	cmp	x1, #0x0
    60e8:      	cset	w1, gt
    60ec:      	ubfx	x1, x1, #0, #8
    60f0:      	b	0x6350 <_stogir.stack.validate+0x5a4>
    60f4:      	movz	x1, #0x0, lsl #48
    60f8:      	b	0x6100 <_stogir.stack.validate+0x354>
    60fc:      	movz	x1, #0x0, lsl #48
    6100:      	cmp	x1, #0x0
    6104:      	b.eq	0x613c <_stogir.stack.validate+0x390>
    6108:      	uxtb	w16, w3
    610c:      	cmp	w16, wzr
    6110:      	b.eq	0x6124 <_stogir.stack.validate+0x378>
    6114:      	ldr	x1, [x0]
    6118:      	add	x1, x10, x1
    611c:      	ldr	x1, [x1]
    6120:      	b	0x6130 <_stogir.stack.validate+0x384>
    6124:      	ldr	x1, [x0, #0x28]
    6128:      	add	x1, x6, x1
    612c:      	ldr	x1, [x1]
    6130:      	mov	x3, x1
    6134:      	mov	x1, #0x1                ; =1
    6138:      	b	0x6144 <_stogir.stack.validate+0x398>
    613c:      	movz	x1, #0x0, lsl #48
    6140:      	movz	x3, #0x0, lsl #48
    6144:      	lsr	w1, w1, #0
    6148:      	lsr	x16, x1, #0
    614c:      	cmp	x16, #0x1
    6150:      	b.eq	0x616c <_stogir.stack.validate+0x3c0>
    6154:      	b.lo	0x615c <_stogir.stack.validate+0x3b0>
    6158:      	b	0x6170 <_stogir.stack.validate+0x3c4>
    615c:      	cmp	x16, #0x0
    6160:      	b.eq	0x6168 <_stogir.stack.validate+0x3bc>
    6164:      	b	0x6170 <_stogir.stack.validate+0x3c4>
    6168:      	b	0x6174 <_stogir.stack.validate+0x3c8>
    616c:      	b	0x6190 <_stogir.stack.validate+0x3e4>
    6170:      	b	0x63b8 <_stogir.stack.validate+0x60c>
    6174:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x254>
		0000000000006174:  ARM64_RELOC_PAGE21	l_stogir.389
    6178:      	ldr	x16, [x16]
		0000000000006178:  ARM64_RELOC_PAGEOFF12	l_stogir.389
    617c:      	orr	x0, x16, xzr
    6180:      	mov	x1, x0
    6184:      	mov	x0, #0x1                ; =1
    6188:      	mov	x2, #0x21               ; =33
    618c:      	b	0x6054 <_stogir.stack.validate+0x2a8>
    6190:      	uxtb	w16, w9
    6194:      	cmp	w16, wzr
    6198:      	b.ne	0x603c <_stogir.stack.validate+0x290>
    619c:      	uxtb	w1, w3
    61a0:      	cmp	x1, #0x42
    61a4:      	b.ne	0x603c <_stogir.stack.validate+0x290>
    61a8:      	lsr	w3, w3, #0
    61ac:      	ubfx	x1, x3, #8, #8
    61b0:      	cmp	x1, #0x6
    61b4:      	b.ne	0x603c <_stogir.stack.validate+0x290>
    61b8:      	ldr	x0, [x0, #0x78]
    61bc:      	add	x0, x2, x0
    61c0:      	ldr	w0, [x0]
    61c4:      	sxtw	x0, w0
    61c8:      	cmp	x0, #0x0
    61cc:      	b.ne	0x603c <_stogir.stack.validate+0x290>
    61d0:      	movz	x0, #0x0, lsl #48
    61d4:      	mov	x1, #0x8                ; =8
    61d8:      	movz	x2, #0x0, lsl #48
    61dc:      	b	0x6054 <_stogir.stack.validate+0x2a8>
    61e0:      	movz	x1, #0x0, lsl #48
    61e4:      	b	0x6100 <_stogir.stack.validate+0x354>
    61e8:      	movz	x1, #0x0, lsl #48
    61ec:      	b	0x60f8 <_stogir.stack.validate+0x34c>
    61f0:      	ldr	x3, [x0, #0x78]
    61f4:      	add	x2, x2, x3
    61f8:      	ldr	w2, [x2]
    61fc:      	uxtb	w16, w1
    6200:      	cmp	w16, wzr
    6204:      	b.eq	0x6270 <_stogir.stack.validate+0x4c4>
    6208:      	mov	x1, #0x3                ; =3
    620c:      	b	0x6284 <_stogir.stack.validate+0x4d8>
    6210:      	add	x16, sp, #0x10
    6214:      	ldr	w0, [x16]
    6218:      	add	x16, sp, #0x10
    621c:      	ldr	w1, [x16, #0x4]
    6220:      	add	x16, sp, #0x10
    6224:      	ldr	w2, [x16, #0x8]
    6228:      	lsr	w1, w1, #0
    622c:      	ubfx	x0, x0, #8, #8
    6230:      	lsr	w2, w2, #0
    6234:      	lsr	w0, w0, #0
    6238:      	add	x8, sp, #0x20
    623c:      	mov	w3, w1
    6240:      	mov	w1, w19
    6244:      	mov	w4, w2
    6248:      	mov	w2, w0
    624c:      	mov	x0, x23
    6250:      	bl	0x6250 <_stogir.stack.validate+0x4a4>
		0000000000006250:  ARM64_RELOC_BRANCH26	_stogir.stack.validate-scope-inputs
    6254:      	add	x16, sp, #0x20
    6258:      	ldr	x0, [x16]
    625c:      	add	x16, sp, #0x20
    6260:      	ldr	x1, [x16, #0x8]
    6264:      	add	x16, sp, #0x20
    6268:      	ldr	x2, [x16, #0x10]
    626c:      	b	0x5ebc <_stogir.stack.validate+0x110>
    6270:      	uxtb	w16, w20
    6274:      	cmp	w16, wzr
    6278:      	mov	x16, #0x1               ; =1
    627c:      	mov	x17, #0x2               ; =2
    6280:      	csel	x1, x16, x17, ne
    6284:      	sxtw	x2, w2
    6288:      	lsr	w1, w1, #0
    628c:      	sxtw	x1, w1
    6290:      	cmp	x2, x1
    6294:      	b.ne	0x63c0 <_stogir.stack.validate+0x614>
    6298:      	add	x16, sp, #0x10
    629c:      	ldr	w1, [x16]
    62a0:      	orr	x2, x1, xzr
    62a4:      	ubfx	x2, x2, #16, #16
    62a8:      	and	x3, x2, #0x8000
    62ac:      	uxth	w3, w3
    62b0:      	cmp	x3, #0x0
    62b4:      	b.ne	0x6354 <_stogir.stack.validate+0x5a8>
    62b8:      	mov	x22, x8
    62bc:      	mov	x23, x0
    62c0:      	lsr	w19, w19, #0
    62c4:      	uxtb	w16, w20
    62c8:      	cmp	w16, wzr
    62cc:      	b.ne	0x6210 <_stogir.stack.validate+0x464>
    62d0:      	uxtb	w16, w21
    62d4:      	cmp	w16, wzr
    62d8:      	b.ne	0x6210 <_stogir.stack.validate+0x464>
    62dc:      	add	x16, sp, #0x10
    62e0:      	ldr	w0, [x16]
    62e4:      	add	x16, sp, #0x10
    62e8:      	ldr	w1, [x16, #0x4]
    62ec:      	add	x16, sp, #0x10
    62f0:      	ldr	w2, [x16, #0x8]
    62f4:      	lsr	w1, w1, #0
    62f8:      	ubfx	x0, x0, #8, #8
    62fc:      	add	x16, sp, #0x10
    6300:      	ldr	w3, [x16, #0xc]
    6304:      	lsr	w2, w2, #0
    6308:      	lsr	w3, w3, #0
    630c:      	lsr	w0, w0, #0
    6310:      	add	x8, sp, #0x40
    6314:      	mov	w4, w2
    6318:      	mov	w2, w0
    631c:      	mov	x0, x23
    6320:      	mov	w5, w3
    6324:      	mov	w3, w1
    6328:      	mov	w1, w19
    632c:      	bl	0x632c <_stogir.stack.validate+0x580>
		000000000000632c:  ARM64_RELOC_BRANCH26	_stogir.stack.validate-inputs
    6330:      	add	x16, sp, #0x40
    6334:      	ldr	x0, [x16]
    6338:      	add	x16, sp, #0x40
    633c:      	ldr	x1, [x16, #0x8]
    6340:      	add	x16, sp, #0x40
    6344:      	ldr	x2, [x16, #0x10]
    6348:      	b	0x626c <_stogir.stack.validate+0x4c0>
    634c:      	movz	x1, #0x0, lsl #48
    6350:      	b	0x61e4 <_stogir.stack.validate+0x438>
    6354:      	uxtb	w1, w1
    6358:      	cmp	x1, #0x51
    635c:      	b.ne	0x63c8 <_stogir.stack.validate+0x61c>
    6360:      	cmp	x2, #0x8, lsl #12       ; =0x8000
    6364:      	b.ne	0x63d0 <_stogir.stack.validate+0x624>
    6368:      	add	x16, sp, #0x10
    636c:      	ldr	w1, [x16, #0x4]
    6370:      	add	x16, sp, #0x10
    6374:      	ldr	w2, [x16, #0x8]
    6378:      	lsr	w1, w1, #0
    637c:      	lsr	w2, w2, #0
    6380:      	mov	x22, x8
    6384:      	mov	x23, x0
    6388:      	bl	0x6388 <_stogir.stack.validate+0x5dc>
		0000000000006388:  ARM64_RELOC_BRANCH26	_stogir.stack.valid-frame-object-inputs?
    638c:      	cmp	x0, #0x0
    6390:      	b.ne	0x62c0 <_stogir.stack.validate+0x514>
    6394:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x254>
		0000000000006394:  ARM64_RELOC_PAGE21	l_stogir.390
    6398:      	ldr	x16, [x16]
		0000000000006398:  ARM64_RELOC_PAGEOFF12	l_stogir.390
    639c:      	orr	x0, x16, xzr
    63a0:      	mov	x1, x0
    63a4:      	mov	x0, #0x1                ; =1
    63a8:      	mov	x2, #0x26               ; =38
    63ac:      	b	0x626c <_stogir.stack.validate+0x4c0>
    63b0:      	brk	#0
    63b4:      	b	0x63b0 <_stogir.stack.validate+0x604>
    63b8:      	brk	#0
    63bc:      	b	0x63b8 <_stogir.stack.validate+0x60c>
    63c0:      	mov	x22, x8
    63c4:      	b	0x5ea4 <_stogir.stack.validate+0xf8>
    63c8:      	mov	x22, x8
    63cc:      	b	0x6394 <_stogir.stack.validate+0x5e8>
    63d0:      	mov	x22, x8
    63d4:      	b	0x6394 <_stogir.stack.validate+0x5e8>

00000000000063d8 <_stogir.locals.operation?>:
    63d8:      	sxtw	x0, w0
    63dc:      	cmp	x0, #0x41
    63e0:      	b.ne	0x63f4 <_stogir.locals.operation?+0x1c>
    63e4:      	mov	x0, #0x1                ; =1
    63e8:      	b	0x63f0 <_stogir.locals.operation?+0x18>
    63ec:      	movz	x0, #0x0, lsl #48
    63f0:      	ret
    63f4:      	cmp	x0, #0x48
    63f8:      	b.ne	0x6404 <_stogir.locals.operation?+0x2c>
    63fc:      	mov	x0, #0x1                ; =1
    6400:      	b	0x63f0 <_stogir.locals.operation?+0x18>
    6404:      	cmp	x0, #0x55
    6408:      	b.lt	0x63ec <_stogir.locals.operation?+0x14>
    640c:      	cmp	x0, #0x58
    6410:      	cset	w0, le
    6414:      	ubfx	x0, x0, #0, #8
    6418:      	b	0x63f0 <_stogir.locals.operation?+0x18>

000000000000641c <_stogir.locals.validate>:
    641c:      	sub	sp, sp, #0xb0
    6420:      	str	x29, [sp]
    6424:      	str	x30, [sp, #0x8]
    6428:      	mov	x29, sp
    642c:      	str	x19, [sp, #0x70]
    6430:      	str	x20, [sp, #0x78]
    6434:      	str	x21, [sp, #0x80]
    6438:      	str	x22, [sp, #0x88]
    643c:      	str	x23, [sp, #0x90]
    6440:      	str	x24, [sp, #0x98]
    6444:      	str	x25, [sp, #0xa0]
    6448:      	sxtw	x1, w1
    644c:      	lsl	x3, x1, #2
    6450:      	cmp	x1, #0x0
    6454:      	cset	w4, gt
    6458:      	movz	x16, #0x0, lsl #48
    645c:      	sub	x5, x16, x1
    6460:      	sub	x6, x5, #0x1
    6464:      	uxtb	w16, w4
    6468:      	cmp	w16, wzr
    646c:      	b.eq	0x64ac <_stogir.locals.validate+0x90>
    6470:      	ldr	x5, [x0, #0x8]
    6474:      	cmp	x1, x5
    6478:      	b.ge	0x654c <_stogir.locals.validate+0x130>
    647c:      	add	x5, x0, #0x78
    6480:      	ldr	x5, [x5, #0x8]
    6484:      	cmp	x1, x5
    6488:      	b.ge	0x6674 <_stogir.locals.validate+0x258>
    648c:      	ldr	x5, [x0, #0x78]
    6490:      	add	x5, x3, x5
    6494:      	ldr	w5, [x5]
    6498:      	sxtw	x5, w5
    649c:      	cmp	x5, #0x0
    64a0:      	cset	w5, ge
    64a4:      	ubfx	x5, x5, #0, #8
    64a8:      	b	0x6678 <_stogir.locals.validate+0x25c>
    64ac:      	cmp	x1, #0x0
    64b0:      	b.ge	0x6554 <_stogir.locals.validate+0x138>
    64b4:      	add	x7, x0, #0x28
    64b8:      	add	x9, x0, #0x50
    64bc:      	ldr	x7, [x7, #0x8]
    64c0:      	ldr	x9, [x9, #0x8]
    64c4:      	cmp	x7, x9
    64c8:      	b.ne	0x64f8 <_stogir.locals.validate+0xdc>
    64cc:      	cmp	x5, x7
    64d0:      	b.gt	0x66fc <_stogir.locals.validate+0x2e0>
    64d4:      	lsl	x5, x6, #2
    64d8:      	ldr	x7, [x0, #0x50]
    64dc:      	add	x5, x5, x7
    64e0:      	ldr	w5, [x5]
    64e4:      	sxtw	x5, w5
    64e8:      	cmp	x5, #0x0
    64ec:      	cset	w5, gt
    64f0:      	ubfx	x5, x5, #0, #8
    64f4:      	b	0x6700 <_stogir.locals.validate+0x2e4>
    64f8:      	movz	x5, #0x0, lsl #48
    64fc:      	b	0x6558 <_stogir.locals.validate+0x13c>
    6500:      	cmp	x5, #0x0
    6504:      	cset	w5, ne
    6508:      	uxtb	w16, w5
    650c:      	cmp	w16, wzr
    6510:      	mov	x16, #0x2               ; =2
    6514:      	mov	x17, #0x3               ; =3
    6518:      	csel	x5, x16, x17, ne
    651c:      	lsr	w5, w5, #0
    6520:      	sxtw	x5, w5
    6524:      	cmp	x1, #0x0
    6528:      	b.gt	0x667c <_stogir.locals.validate+0x260>
    652c:      	mov	x23, x8
    6530:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x254>
		0000000000006530:  ARM64_RELOC_PAGE21	l_stogir.391
    6534:      	ldr	x16, [x16]
		0000000000006534:  ARM64_RELOC_PAGEOFF12	l_stogir.391
    6538:      	orr	x0, x16, xzr
    653c:      	mov	x1, x0
    6540:      	mov	x0, #0x1                ; =1
    6544:      	mov	x2, #0x17               ; =23
    6548:      	b	0x6618 <_stogir.locals.validate+0x1fc>
    654c:      	movz	x5, #0x0, lsl #48
    6550:      	b	0x6558 <_stogir.locals.validate+0x13c>
    6554:      	movz	x5, #0x0, lsl #48
    6558:      	cmp	x5, #0x0
    655c:      	b.eq	0x65c0 <_stogir.locals.validate+0x1a4>
    6560:      	uxtb	w16, w4
    6564:      	cmp	w16, wzr
    6568:      	b.eq	0x6590 <_stogir.locals.validate+0x174>
    656c:      	lsl	x4, x1, #4
    6570:      	ldr	x5, [x0]
    6574:      	add	x4, x4, x5
    6578:      	ldr	x5, [x4]
    657c:      	ldr	x4, [x4, #0x8]
    6580:      	fmov	d31, x4
    6584:      	mov	x4, x5
    6588:      	fmov	x5, d31
    658c:      	b	0x65b0 <_stogir.locals.validate+0x194>
    6590:      	lsl	x4, x6, #4
    6594:      	ldr	x5, [x0, #0x28]
    6598:      	add	x4, x4, x5
    659c:      	ldr	x5, [x4]
    65a0:      	ldr	x4, [x4, #0x8]
    65a4:      	fmov	d31, x4
    65a8:      	mov	x4, x5
    65ac:      	fmov	x5, d31
    65b0:      	mov	x6, x5
    65b4:      	mov	x5, x4
    65b8:      	mov	x4, #0x1                ; =1
    65bc:      	b	0x65cc <_stogir.locals.validate+0x1b0>
    65c0:      	movz	x4, #0x0, lsl #48
    65c4:      	movz	x5, #0x0, lsl #48
    65c8:      	movz	x6, #0x0, lsl #48
    65cc:      	lsr	w4, w4, #0
    65d0:      	lsr	x16, x4, #0
    65d4:      	cmp	x16, #0x1
    65d8:      	b.eq	0x65f4 <_stogir.locals.validate+0x1d8>
    65dc:      	b.lo	0x65e4 <_stogir.locals.validate+0x1c8>
    65e0:      	b	0x65f8 <_stogir.locals.validate+0x1dc>
    65e4:      	cmp	x16, #0x0
    65e8:      	b.eq	0x65f0 <_stogir.locals.validate+0x1d4>
    65ec:      	b	0x65f8 <_stogir.locals.validate+0x1dc>
    65f0:      	b	0x65fc <_stogir.locals.validate+0x1e0>
    65f4:      	b	0x6650 <_stogir.locals.validate+0x234>
    65f8:      	b	0x6840 <_stogir.locals.validate+0x424>
    65fc:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x254>
		00000000000065fc:  ARM64_RELOC_PAGE21	l_stogir.392
    6600:      	ldr	x16, [x16]
		0000000000006600:  ARM64_RELOC_PAGEOFF12	l_stogir.392
    6604:      	orr	x0, x16, xzr
    6608:      	mov	x23, x8
    660c:      	mov	x1, x0
    6610:      	mov	x0, #0x1                ; =1
    6614:      	mov	x2, #0x17               ; =23
    6618:      	str	x0, [x23]
    661c:      	str	x1, [x23, #0x8]
    6620:      	str	x2, [x23, #0x10]
    6624:      	ldr	x19, [sp, #0x70]
    6628:      	ldr	x20, [sp, #0x78]
    662c:      	ldr	x21, [sp, #0x80]
    6630:      	ldr	x22, [sp, #0x88]
    6634:      	ldr	x23, [sp, #0x90]
    6638:      	ldr	x24, [sp, #0x98]
    663c:      	ldr	x25, [sp, #0xa0]
    6640:      	ldr	x29, [sp]
    6644:      	ldr	x30, [sp, #0x8]
    6648:      	add	sp, sp, #0xb0
    664c:      	ret
    6650:      	uxtb	w4, w5
    6654:      	add	x16, sp, #0x10
    6658:      	str	x5, [x16]
    665c:      	add	x16, sp, #0x10
    6660:      	str	x6, [x16, #0x8]
    6664:      	cmp	x4, #0x55
    6668:      	b.ne	0x66e0 <_stogir.locals.validate+0x2c4>
    666c:      	mov	x5, #0x1                ; =1
    6670:      	b	0x66ec <_stogir.locals.validate+0x2d0>
    6674:      	movz	x5, #0x0, lsl #48
    6678:      	b	0x6550 <_stogir.locals.validate+0x134>
    667c:      	cmp	x4, #0x48
    6680:      	cset	w21, eq
    6684:      	uxtb	w16, w20
    6688:      	cmp	w16, wzr
    668c:      	b.ne	0x6704 <_stogir.locals.validate+0x2e8>
    6690:      	uxtb	w16, w21
    6694:      	cmp	w16, wzr
    6698:      	b.ne	0x6704 <_stogir.locals.validate+0x2e8>
    669c:      	cmp	x4, #0x55
    66a0:      	b.lt	0x6bb4 <_stogir.locals.validate+0x798>
    66a4:      	cmp	x4, #0x58
    66a8:      	b.le	0x6704 <_stogir.locals.validate+0x2e8>
    66ac:      	mov	x23, x8
    66b0:      	b	0x6530 <_stogir.locals.validate+0x114>
    66b4:      	cmp	x4, #0x58
    66b8:      	cset	w6, eq
    66bc:      	ubfx	x6, x6, #0, #8
    66c0:      	mov	x19, x6
    66c4:      	cmp	x4, #0x41
    66c8:      	cset	w20, eq
    66cc:      	uxtb	w16, w20
    66d0:      	cmp	w16, wzr
    66d4:      	b.eq	0x6500 <_stogir.locals.validate+0xe4>
    66d8:      	mov	x5, #0x1                ; =1
    66dc:      	b	0x6524 <_stogir.locals.validate+0x108>
    66e0:      	cmp	x4, #0x56
    66e4:      	cset	w5, eq
    66e8:      	ubfx	x5, x5, #0, #8
    66ec:      	cmp	x4, #0x57
    66f0:      	b.ne	0x66b4 <_stogir.locals.validate+0x298>
    66f4:      	mov	x19, #0x1               ; =1
    66f8:      	b	0x66c4 <_stogir.locals.validate+0x2a8>
    66fc:      	movz	x5, #0x0, lsl #48
    6700:      	b	0x64fc <_stogir.locals.validate+0xe0>
    6704:      	lsr	w5, w5, #0
    6708:      	sxtw	x5, w5
    670c:      	ldr	x4, [x0, #0x78]
    6710:      	add	x3, x3, x4
    6714:      	ldr	w3, [x3]
    6718:      	sxtw	x3, w3
    671c:      	cmp	x3, x5
    6720:      	b.ne	0x6bbc <_stogir.locals.validate+0x7a0>
    6724:      	uxtb	w16, w20
    6728:      	cmp	w16, wzr
    672c:      	b.ne	0x674c <_stogir.locals.validate+0x330>
    6730:      	uxtb	w16, w21
    6734:      	cmp	w16, wzr
    6738:      	b.ne	0x674c <_stogir.locals.validate+0x330>
    673c:      	add	x16, sp, #0x10
    6740:      	ldr	w1, [x16, #0x8]
    6744:      	sxtw	x1, w1
    6748:      	b	0x6764 <_stogir.locals.validate+0x348>
    674c:      	uxtb	w16, w21
    6750:      	cmp	w16, wzr
    6754:      	b.ne	0x6764 <_stogir.locals.validate+0x348>
    6758:      	add	x16, sp, #0x10
    675c:      	ldr	w1, [x16, #0x4]
    6760:      	sxtw	x1, w1
    6764:      	add	x16, sp, #0x20
    6768:      	orr	x22, x16, xzr
    676c:      	lsr	w2, w2, #0
    6770:      	lsr	w1, w1, #0
    6774:      	mov	x23, x8
    6778:      	add	x8, sp, #0x20
    677c:      	mov	x24, x0
    6780:      	mov	w25, w2
    6784:      	bl	0x6784 <_stogir.locals.validate+0x368>
		0000000000006784:  ARM64_RELOC_BRANCH26	_stogir.locals.shape
    6788:      	add	x16, sp, #0x20
    678c:      	ldr	w0, [x16]
    6790:      	lsr	x16, x0, #0
    6794:      	cmp	x16, #0x1
    6798:      	b.eq	0x67b4 <_stogir.locals.validate+0x398>
    679c:      	b.lo	0x67a4 <_stogir.locals.validate+0x388>
    67a0:      	b	0x67b8 <_stogir.locals.validate+0x39c>
    67a4:      	cmp	x16, #0x0
    67a8:      	b.eq	0x67b0 <_stogir.locals.validate+0x394>
    67ac:      	b	0x67b8 <_stogir.locals.validate+0x39c>
    67b0:      	b	0x67d8 <_stogir.locals.validate+0x3bc>
    67b4:      	b	0x67bc <_stogir.locals.validate+0x3a0>
    67b8:      	b	0x6a38 <_stogir.locals.validate+0x61c>
    67bc:      	add	x0, x22, #0x8
    67c0:      	add	x16, sp, #0x20
    67c4:      	ldr	x1, [x16, #0x8]
    67c8:      	ldr	x0, [x0, #0x8]
    67cc:      	mov	x2, x0
    67d0:      	mov	x0, #0x1                ; =1
    67d4:      	b	0x6548 <_stogir.locals.validate+0x12c>
    67d8:      	add	x16, sp, #0x20
    67dc:      	ldr	x22, [x16, #0x8]
    67e0:      	uxtb	w16, w21
    67e4:      	cmp	w16, wzr
    67e8:      	b.eq	0x6808 <_stogir.locals.validate+0x3ec>
    67ec:      	lsr	w22, w22, #0
    67f0:      	sxtw	x22, w22
    67f4:      	and	x0, x22, #0xffffffff
    67f8:      	mov	x1, x0
    67fc:      	movz	x0, #0x0, lsl #48
    6800:      	movz	x2, #0x0, lsl #48
    6804:      	b	0x67d4 <_stogir.locals.validate+0x3b8>
    6808:      	uxtb	w16, w20
    680c:      	cmp	w16, wzr
    6810:      	b.eq	0x6864 <_stogir.locals.validate+0x448>
    6814:      	add	x16, sp, #0x10
    6818:      	ldr	w0, [x16]
    681c:      	ubfx	x0, x0, #8, #8
    6820:      	cmp	x0, #0x6
    6824:      	b.ne	0x6848 <_stogir.locals.validate+0x42c>
    6828:      	sxtw	x25, w25
    682c:      	and	x0, x25, #0xffffffff
    6830:      	mov	x1, x0
    6834:      	movz	x0, #0x0, lsl #48
    6838:      	movz	x2, #0x0, lsl #48
    683c:      	b	0x6860 <_stogir.locals.validate+0x444>
    6840:      	brk	#0
    6844:      	b	0x6840 <_stogir.locals.validate+0x424>
    6848:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x254>
		0000000000006848:  ARM64_RELOC_PAGE21	l_stogir.393
    684c:      	ldr	x16, [x16]
		000000000000684c:  ARM64_RELOC_PAGEOFF12	l_stogir.393
    6850:      	orr	x0, x16, xzr
    6854:      	mov	x1, x0
    6858:      	mov	x0, #0x1                ; =1
    685c:      	mov	x2, #0x21               ; =33
    6860:      	b	0x6804 <_stogir.locals.validate+0x3e8>
    6864:      	add	x16, sp, #0x10
    6868:      	ldr	w0, [x16, #0x4]
    686c:      	sxtw	x0, w0
    6870:      	cmp	x0, #0x0
    6874:      	cset	w1, gt
    6878:      	movz	x16, #0x0, lsl #48
    687c:      	sub	x2, x16, x0
    6880:      	sub	x3, x2, #0x1
    6884:      	uxtb	w16, w1
    6888:      	cmp	w16, wzr
    688c:      	b.eq	0x6974 <_stogir.locals.validate+0x558>
    6890:      	ldr	x2, [x24, #0x8]
    6894:      	cmp	x0, x2
    6898:      	b.ge	0x696c <_stogir.locals.validate+0x550>
    689c:      	add	x2, x24, #0x78
    68a0:      	ldr	x2, [x2, #0x8]
    68a4:      	cmp	x0, x2
    68a8:      	b.ge	0x6a28 <_stogir.locals.validate+0x60c>
    68ac:      	lsl	x2, x0, #2
    68b0:      	ldr	x4, [x24, #0x78]
    68b4:      	add	x2, x2, x4
    68b8:      	ldr	w2, [x2]
    68bc:      	sxtw	x2, w2
    68c0:      	cmp	x2, #0x0
    68c4:      	cset	w2, ge
    68c8:      	ubfx	x2, x2, #0, #8
    68cc:      	b	0x6a2c <_stogir.locals.validate+0x610>
    68d0:      	movz	x0, #0x0, lsl #48
    68d4:      	movz	x1, #0x0, lsl #48
    68d8:      	lsr	w0, w0, #0
    68dc:      	lsr	x16, x0, #0
    68e0:      	cmp	x16, #0x1
    68e4:      	b.eq	0x6900 <_stogir.locals.validate+0x4e4>
    68e8:      	b.lo	0x68f0 <_stogir.locals.validate+0x4d4>
    68ec:      	b	0x6904 <_stogir.locals.validate+0x4e8>
    68f0:      	cmp	x16, #0x0
    68f4:      	b.eq	0x68fc <_stogir.locals.validate+0x4e0>
    68f8:      	b	0x6904 <_stogir.locals.validate+0x4e8>
    68fc:      	b	0x6908 <_stogir.locals.validate+0x4ec>
    6900:      	b	0x69c0 <_stogir.locals.validate+0x5a4>
    6904:      	b	0x6b84 <_stogir.locals.validate+0x768>
    6908:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x254>
		0000000000006908:  ARM64_RELOC_PAGE21	l_stogir.394
    690c:      	ldr	x16, [x16]
		000000000000690c:  ARM64_RELOC_PAGEOFF12	l_stogir.394
    6910:      	orr	x0, x16, xzr
    6914:      	mov	x1, x0
    6918:      	mov	x0, #0x1                ; =1
    691c:      	mov	x2, #0x1c               ; =28
    6920:      	b	0x6860 <_stogir.locals.validate+0x444>
    6924:      	lsl	x0, x3, #4
    6928:      	ldr	x1, [x24, #0x28]
    692c:      	add	x0, x0, x1
    6930:      	ldr	x0, [x0]
    6934:      	mov	x1, x0
    6938:      	mov	x0, #0x1                ; =1
    693c:      	b	0x68d8 <_stogir.locals.validate+0x4bc>
    6940:      	movz	x2, #0x0, lsl #48
    6944:      	cmp	x2, #0x0
    6948:      	b.eq	0x68d0 <_stogir.locals.validate+0x4b4>
    694c:      	uxtb	w16, w1
    6950:      	cmp	w16, wzr
    6954:      	b.eq	0x6924 <_stogir.locals.validate+0x508>
    6958:      	lsl	x0, x0, #4
    695c:      	ldr	x1, [x24]
    6960:      	add	x0, x0, x1
    6964:      	ldr	x0, [x0]
    6968:      	b	0x6934 <_stogir.locals.validate+0x518>
    696c:      	movz	x2, #0x0, lsl #48
    6970:      	b	0x6944 <_stogir.locals.validate+0x528>
    6974:      	cmp	x0, #0x0
    6978:      	b.ge	0x6940 <_stogir.locals.validate+0x524>
    697c:      	add	x4, x24, #0x28
    6980:      	add	x5, x24, #0x50
    6984:      	ldr	x4, [x4, #0x8]
    6988:      	ldr	x5, [x5, #0x8]
    698c:      	cmp	x4, x5
    6990:      	b.ne	0x6a20 <_stogir.locals.validate+0x604>
    6994:      	cmp	x2, x4
    6998:      	b.gt	0x6a30 <_stogir.locals.validate+0x614>
    699c:      	lsl	x2, x3, #2
    69a0:      	ldr	x4, [x24, #0x50]
    69a4:      	add	x2, x2, x4
    69a8:      	ldr	w2, [x2]
    69ac:      	sxtw	x2, w2
    69b0:      	cmp	x2, #0x0
    69b4:      	cset	w2, gt
    69b8:      	ubfx	x2, x2, #0, #8
    69bc:      	b	0x6a34 <_stogir.locals.validate+0x618>
    69c0:      	add	x16, sp, #0x10
    69c4:      	ldr	w0, [x16, #0x4]
    69c8:      	sxtw	x0, w0
    69cc:      	cmp	x0, #0x0
    69d0:      	b.le	0x6a04 <_stogir.locals.validate+0x5e8>
    69d4:      	uxtb	w1, w1
    69d8:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x254>
		00000000000069d8:  ARM64_RELOC_PAGE21	l_stogir.395
    69dc:      	ldr	x16, [x16]
		00000000000069dc:  ARM64_RELOC_PAGEOFF12	l_stogir.395
    69e0:      	orr	x0, x16, xzr
    69e4:      	cmp	x1, #0x83
    69e8:      	cset	w2, lt
    69ec:      	add	x0, x1, x0
    69f0:      	uxtb	w16, w2
    69f4:      	cmp	w16, wzr
    69f8:      	b.eq	0x6a40 <_stogir.locals.validate+0x624>
    69fc:      	ldrb	w1, [x0]
    6a00:      	b	0x6a44 <_stogir.locals.validate+0x628>
    6a04:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x254>
		0000000000006a04:  ARM64_RELOC_PAGE21	l_stogir.396
    6a08:      	ldr	x16, [x16]
		0000000000006a08:  ARM64_RELOC_PAGEOFF12	l_stogir.396
    6a0c:      	orr	x0, x16, xzr
    6a10:      	mov	x1, x0
    6a14:      	mov	x0, #0x1                ; =1
    6a18:      	mov	x2, #0x1c               ; =28
    6a1c:      	b	0x6920 <_stogir.locals.validate+0x504>
    6a20:      	movz	x2, #0x0, lsl #48
    6a24:      	b	0x6944 <_stogir.locals.validate+0x528>
    6a28:      	movz	x2, #0x0, lsl #48
    6a2c:      	b	0x6970 <_stogir.locals.validate+0x554>
    6a30:      	movz	x2, #0x0, lsl #48
    6a34:      	b	0x6a24 <_stogir.locals.validate+0x608>
    6a38:      	brk	#0
    6a3c:      	b	0x6a38 <_stogir.locals.validate+0x61c>
    6a40:      	movz	x1, #0x0, lsl #48
    6a44:      	uxtb	w1, w1
    6a48:      	and	x1, x1, #0x1
    6a4c:      	uxtb	w1, w1
    6a50:      	cmp	x1, #0x0
    6a54:      	b.eq	0x6a04 <_stogir.locals.validate+0x5e8>
    6a58:      	uxtb	w16, w2
    6a5c:      	cmp	w16, wzr
    6a60:      	b.eq	0x6a6c <_stogir.locals.validate+0x650>
    6a64:      	ldrb	w0, [x0]
    6a68:      	b	0x6a70 <_stogir.locals.validate+0x654>
    6a6c:      	movz	x0, #0x0, lsl #48
    6a70:      	uxtb	w0, w0
    6a74:      	and	x0, x0, #0x4
    6a78:      	uxtb	w0, w0
    6a7c:      	cmp	x0, #0x0
    6a80:      	b.ne	0x6a04 <_stogir.locals.validate+0x5e8>
    6a84:      	cmp	x19, #0x0
    6a88:      	b.eq	0x6b28 <_stogir.locals.validate+0x70c>
    6a8c:      	add	x16, sp, #0x10
    6a90:      	ldr	w0, [x16, #0xc]
    6a94:      	lsr	w0, w0, #0
    6a98:      	add	x8, sp, #0x40
    6a9c:      	mov	w1, w0
    6aa0:      	mov	x0, x24
    6aa4:      	bl	0x6aa4 <_stogir.locals.validate+0x688>
		0000000000006aa4:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    6aa8:      	add	x16, sp, #0x40
    6aac:      	ldr	x0, [x16]
    6ab0:      	add	x16, sp, #0x40
    6ab4:      	ldr	x1, [x16, #0x8]
    6ab8:      	mov	x20, x1
    6abc:      	b	0x6b38 <_stogir.locals.validate+0x71c>
    6ac0:      	lsr	w25, w25, #0
    6ac4:      	lsr	w0, w20, #0
    6ac8:      	ubfx	x0, x0, #8, #8
    6acc:      	lsr	w0, w0, #0
    6ad0:      	mov	w1, w25
    6ad4:      	bl	0x6ad4 <_stogir.locals.validate+0x6b8>
		0000000000006ad4:  ARM64_RELOC_BRANCH26	_stogir.types.size
    6ad8:      	lsr	w0, w0, #0
    6adc:      	sxtw	x0, w0
    6ae0:      	cmp	x0, #0x0
    6ae4:      	b.le	0x6b0c <_stogir.locals.validate+0x6f0>
    6ae8:      	cmp	x0, x22
    6aec:      	b.gt	0x6b0c <_stogir.locals.validate+0x6f0>
    6af0:      	cmp	x19, #0x0
    6af4:      	b.eq	0x6b8c <_stogir.locals.validate+0x770>
    6af8:      	add	x16, sp, #0x10
    6afc:      	ldr	w1, [x16]
    6b00:      	ubfx	x1, x1, #8, #8
    6b04:      	cmp	x1, #0x0
    6b08:      	b.eq	0x6b8c <_stogir.locals.validate+0x770>
    6b0c:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x254>
		0000000000006b0c:  ARM64_RELOC_PAGE21	l_stogir.397
    6b10:      	ldr	x16, [x16]
		0000000000006b10:  ARM64_RELOC_PAGEOFF12	l_stogir.397
    6b14:      	orr	x0, x16, xzr
    6b18:      	mov	x1, x0
    6b1c:      	mov	x0, #0x1                ; =1
    6b20:      	mov	x2, #0x23               ; =35
    6b24:      	b	0x6a1c <_stogir.locals.validate+0x600>
    6b28:      	add	x16, sp, #0x10
    6b2c:      	ldr	x0, [x16]
    6b30:      	mov	x20, x0
    6b34:      	mov	x0, #0x1                ; =1
    6b38:      	lsr	w0, w0, #0
    6b3c:      	lsr	x16, x0, #0
    6b40:      	cmp	x16, #0x1
    6b44:      	b.eq	0x6b60 <_stogir.locals.validate+0x744>
    6b48:      	b.lo	0x6b50 <_stogir.locals.validate+0x734>
    6b4c:      	b	0x6b64 <_stogir.locals.validate+0x748>
    6b50:      	cmp	x16, #0x0
    6b54:      	b.eq	0x6b5c <_stogir.locals.validate+0x740>
    6b58:      	b	0x6b64 <_stogir.locals.validate+0x748>
    6b5c:      	b	0x6b68 <_stogir.locals.validate+0x74c>
    6b60:      	b	0x6ac0 <_stogir.locals.validate+0x6a4>
    6b64:      	b	0x6bac <_stogir.locals.validate+0x790>
    6b68:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x254>
		0000000000006b68:  ARM64_RELOC_PAGE21	l_stogir.398
    6b6c:      	ldr	x16, [x16]
		0000000000006b6c:  ARM64_RELOC_PAGEOFF12	l_stogir.398
    6b70:      	orr	x0, x16, xzr
    6b74:      	mov	x1, x0
    6b78:      	mov	x0, #0x1                ; =1
    6b7c:      	mov	x2, #0x19               ; =25
    6b80:      	b	0x6b24 <_stogir.locals.validate+0x708>
    6b84:      	brk	#0
    6b88:      	b	0x6b84 <_stogir.locals.validate+0x768>
    6b8c:      	uxtb	w20, w20
    6b90:      	cmp	x20, #0x48
    6b94:      	b.eq	0x6b0c <_stogir.locals.validate+0x6f0>
    6b98:      	and	x0, x0, #0xffffffff
    6b9c:      	mov	x1, x0
    6ba0:      	movz	x0, #0x0, lsl #48
    6ba4:      	movz	x2, #0x0, lsl #48
    6ba8:      	b	0x6b24 <_stogir.locals.validate+0x708>
    6bac:      	brk	#0
    6bb0:      	b	0x6bac <_stogir.locals.validate+0x790>
    6bb4:      	mov	x23, x8
    6bb8:      	b	0x6530 <_stogir.locals.validate+0x114>
    6bbc:      	mov	x23, x8
    6bc0:      	b	0x6530 <_stogir.locals.validate+0x114>

0000000000006bc4 <_stogir.conversion.operation?>:
    6bc4:      	sxtw	x0, w0
    6bc8:      	cmp	x0, #0x21
    6bcc:      	b.lt	0x6be0 <_stogir.conversion.operation?+0x1c>
    6bd0:      	cmp	x0, #0x27
    6bd4:      	cset	w0, le
    6bd8:      	ubfx	x0, x0, #0, #8
    6bdc:      	b	0x6be4 <_stogir.conversion.operation?+0x20>
    6be0:      	movz	x0, #0x0, lsl #48
    6be4:      	ret

0000000000006be8 <_stogir.conversion.validate>:
    6be8:      	sub	sp, sp, #0x40
    6bec:      	str	x29, [sp]
    6bf0:      	str	x30, [sp, #0x8]
    6bf4:      	mov	x29, sp
    6bf8:      	str	x19, [sp, #0x30]
    6bfc:      	sxtw	x1, w1
    6c00:      	lsl	x3, x1, #2
    6c04:      	cmp	x1, #0x0
    6c08:      	cset	w4, gt
    6c0c:      	movz	x16, #0x0, lsl #48
    6c10:      	sub	x5, x16, x1
    6c14:      	sub	x6, x5, #0x1
    6c18:      	uxtb	w16, w4
    6c1c:      	cmp	w16, wzr
    6c20:      	b.eq	0x6c60 <_stogir.conversion.validate+0x78>
    6c24:      	ldr	x5, [x0, #0x8]
    6c28:      	cmp	x1, x5
    6c2c:      	b.ge	0x6cb4 <_stogir.conversion.validate+0xcc>
    6c30:      	add	x5, x0, #0x78
    6c34:      	ldr	x5, [x5, #0x8]
    6c38:      	cmp	x1, x5
    6c3c:      	b.ge	0x6da0 <_stogir.conversion.validate+0x1b8>
    6c40:      	ldr	x5, [x0, #0x78]
    6c44:      	add	x5, x3, x5
    6c48:      	ldr	w5, [x5]
    6c4c:      	sxtw	x5, w5
    6c50:      	cmp	x5, #0x0
    6c54:      	cset	w5, ge
    6c58:      	ubfx	x5, x5, #0, #8
    6c5c:      	b	0x6da4 <_stogir.conversion.validate+0x1bc>
    6c60:      	cmp	x1, #0x0
    6c64:      	b.ge	0x6cbc <_stogir.conversion.validate+0xd4>
    6c68:      	add	x7, x0, #0x28
    6c6c:      	add	x9, x0, #0x50
    6c70:      	ldr	x7, [x7, #0x8]
    6c74:      	ldr	x9, [x9, #0x8]
    6c78:      	cmp	x7, x9
    6c7c:      	b.ne	0x6cac <_stogir.conversion.validate+0xc4>
    6c80:      	cmp	x5, x7
    6c84:      	b.gt	0x6e38 <_stogir.conversion.validate+0x250>
    6c88:      	lsl	x5, x6, #2
    6c8c:      	ldr	x7, [x0, #0x50]
    6c90:      	add	x5, x5, x7
    6c94:      	ldr	w5, [x5]
    6c98:      	sxtw	x5, w5
    6c9c:      	cmp	x5, #0x0
    6ca0:      	cset	w5, gt
    6ca4:      	ubfx	x5, x5, #0, #8
    6ca8:      	b	0x6e3c <_stogir.conversion.validate+0x254>
    6cac:      	movz	x5, #0x0, lsl #48
    6cb0:      	b	0x6cc0 <_stogir.conversion.validate+0xd8>
    6cb4:      	movz	x5, #0x0, lsl #48
    6cb8:      	b	0x6cc0 <_stogir.conversion.validate+0xd8>
    6cbc:      	movz	x5, #0x0, lsl #48
    6cc0:      	cmp	x5, #0x0
    6cc4:      	b.eq	0x6d04 <_stogir.conversion.validate+0x11c>
    6cc8:      	uxtb	w16, w4
    6ccc:      	cmp	w16, wzr
    6cd0:      	b.eq	0x6ce8 <_stogir.conversion.validate+0x100>
    6cd4:      	lsl	x4, x1, #4
    6cd8:      	ldr	x5, [x0]
    6cdc:      	add	x4, x4, x5
    6ce0:      	ldr	x4, [x4]
    6ce4:      	b	0x6cf8 <_stogir.conversion.validate+0x110>
    6ce8:      	lsl	x4, x6, #4
    6cec:      	ldr	x5, [x0, #0x28]
    6cf0:      	add	x4, x4, x5
    6cf4:      	ldr	x4, [x4]
    6cf8:      	mov	x5, x4
    6cfc:      	mov	x4, #0x1                ; =1
    6d00:      	b	0x6d0c <_stogir.conversion.validate+0x124>
    6d04:      	movz	x4, #0x0, lsl #48
    6d08:      	movz	x5, #0x0, lsl #48
    6d0c:      	lsr	w4, w4, #0
    6d10:      	lsr	x16, x4, #0
    6d14:      	cmp	x16, #0x1
    6d18:      	b.eq	0x6d34 <_stogir.conversion.validate+0x14c>
    6d1c:      	b.lo	0x6d24 <_stogir.conversion.validate+0x13c>
    6d20:      	b	0x6d38 <_stogir.conversion.validate+0x150>
    6d24:      	cmp	x16, #0x0
    6d28:      	b.eq	0x6d30 <_stogir.conversion.validate+0x148>
    6d2c:      	b	0x6d38 <_stogir.conversion.validate+0x150>
    6d30:      	b	0x6d3c <_stogir.conversion.validate+0x154>
    6d34:      	b	0x6d78 <_stogir.conversion.validate+0x190>
    6d38:      	b	0x6eb8 <_stogir.conversion.validate+0x2d0>
    6d3c:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x254>
		0000000000006d3c:  ARM64_RELOC_PAGE21	l_stogir.399
    6d40:      	ldr	x16, [x16]
		0000000000006d40:  ARM64_RELOC_PAGEOFF12	l_stogir.399
    6d44:      	orr	x0, x16, xzr
    6d48:      	mov	x19, x8
    6d4c:      	mov	x1, x0
    6d50:      	mov	x0, #0x1                ; =1
    6d54:      	mov	x2, #0x12               ; =18
    6d58:      	str	x0, [x19]
    6d5c:      	str	x1, [x19, #0x8]
    6d60:      	str	x2, [x19, #0x10]
    6d64:      	ldr	x19, [sp, #0x30]
    6d68:      	ldr	x29, [sp]
    6d6c:      	ldr	x30, [sp, #0x8]
    6d70:      	add	sp, sp, #0x40
    6d74:      	ret
    6d78:      	cmp	x1, #0x0
    6d7c:      	b.gt	0x6da8 <_stogir.conversion.validate+0x1c0>
    6d80:      	mov	x19, x8
    6d84:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x254>
		0000000000006d84:  ARM64_RELOC_PAGE21	l_stogir.400
    6d88:      	ldr	x16, [x16]
		0000000000006d88:  ARM64_RELOC_PAGEOFF12	l_stogir.400
    6d8c:      	orr	x0, x16, xzr
    6d90:      	mov	x1, x0
    6d94:      	mov	x0, #0x1                ; =1
    6d98:      	mov	x2, #0x1e               ; =30
    6d9c:      	b	0x6d58 <_stogir.conversion.validate+0x170>
    6da0:      	movz	x5, #0x0, lsl #48
    6da4:      	b	0x6cb8 <_stogir.conversion.validate+0xd0>
    6da8:      	uxtb	w1, w5
    6dac:      	orr	x4, x1, xzr
    6db0:      	cmp	x4, #0x21
    6db4:      	b.lt	0x6fec <_stogir.conversion.validate+0x404>
    6db8:      	cmp	x4, #0x27
    6dbc:      	b.gt	0x6ff4 <_stogir.conversion.validate+0x40c>
    6dc0:      	ldr	x4, [x0, #0x78]
    6dc4:      	add	x3, x3, x4
    6dc8:      	ldr	w3, [x3]
    6dcc:      	sxtw	x3, w3
    6dd0:      	cmp	x3, #0x1
    6dd4:      	b.ne	0x6ffc <_stogir.conversion.validate+0x414>
    6dd8:      	asr	x3, x5, #32
    6ddc:      	cmp	x3, #0x0
    6de0:      	cset	w6, gt
    6de4:      	movz	x16, #0x0, lsl #48
    6de8:      	sub	x7, x16, x3
    6dec:      	sub	x9, x7, #0x1
    6df0:      	uxtb	w16, w6
    6df4:      	cmp	w16, wzr
    6df8:      	b.eq	0x6e6c <_stogir.conversion.validate+0x284>
    6dfc:      	ldr	x7, [x0, #0x8]
    6e00:      	cmp	x3, x7
    6e04:      	b.ge	0x6ec0 <_stogir.conversion.validate+0x2d8>
    6e08:      	add	x7, x0, #0x78
    6e0c:      	ldr	x7, [x7, #0x8]
    6e10:      	cmp	x3, x7
    6e14:      	b.ge	0x6f70 <_stogir.conversion.validate+0x388>
    6e18:      	lsl	x7, x3, #2
    6e1c:      	add	x4, x7, x4
    6e20:      	ldr	w4, [x4]
    6e24:      	sxtw	x4, w4
    6e28:      	cmp	x4, #0x0
    6e2c:      	cset	w4, ge
    6e30:      	ubfx	x4, x4, #0, #8
    6e34:      	b	0x6f74 <_stogir.conversion.validate+0x38c>
    6e38:      	movz	x5, #0x0, lsl #48
    6e3c:      	b	0x6cb0 <_stogir.conversion.validate+0xc8>
    6e40:      	uxtb	w0, w3
    6e44:      	cmp	x0, #0x48
    6e48:      	b.ne	0x6f78 <_stogir.conversion.validate+0x390>
    6e4c:      	mov	x19, x8
    6e50:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x254>
		0000000000006e50:  ARM64_RELOC_PAGE21	l_stogir.401
    6e54:      	ldr	x16, [x16]
		0000000000006e54:  ARM64_RELOC_PAGEOFF12	l_stogir.401
    6e58:      	orr	x0, x16, xzr
    6e5c:      	mov	x1, x0
    6e60:      	mov	x0, #0x1                ; =1
    6e64:      	mov	x2, #0x25               ; =37
    6e68:      	b	0x6d9c <_stogir.conversion.validate+0x1b4>
    6e6c:      	cmp	x3, #0x0
    6e70:      	b.ge	0x6ec8 <_stogir.conversion.validate+0x2e0>
    6e74:      	add	x4, x0, #0x28
    6e78:      	add	x10, x0, #0x50
    6e7c:      	ldr	x4, [x4, #0x8]
    6e80:      	ldr	x10, [x10, #0x8]
    6e84:      	cmp	x4, x10
    6e88:      	b.ne	0x6f68 <_stogir.conversion.validate+0x380>
    6e8c:      	cmp	x7, x4
    6e90:      	b.gt	0x6fdc <_stogir.conversion.validate+0x3f4>
    6e94:      	lsl	x4, x9, #2
    6e98:      	ldr	x7, [x0, #0x50]
    6e9c:      	add	x4, x4, x7
    6ea0:      	ldr	w4, [x4]
    6ea4:      	sxtw	x4, w4
    6ea8:      	cmp	x4, #0x0
    6eac:      	cset	w4, gt
    6eb0:      	ubfx	x4, x4, #0, #8
    6eb4:      	b	0x6fe0 <_stogir.conversion.validate+0x3f8>
    6eb8:      	brk	#0
    6ebc:      	b	0x6eb8 <_stogir.conversion.validate+0x2d0>
    6ec0:      	movz	x4, #0x0, lsl #48
    6ec4:      	b	0x6ecc <_stogir.conversion.validate+0x2e4>
    6ec8:      	movz	x4, #0x0, lsl #48
    6ecc:      	cmp	x4, #0x0
    6ed0:      	b.eq	0x6f10 <_stogir.conversion.validate+0x328>
    6ed4:      	uxtb	w16, w6
    6ed8:      	cmp	w16, wzr
    6edc:      	b.eq	0x6ef4 <_stogir.conversion.validate+0x30c>
    6ee0:      	lsl	x3, x3, #4
    6ee4:      	ldr	x0, [x0]
    6ee8:      	add	x0, x3, x0
    6eec:      	ldr	x0, [x0]
    6ef0:      	b	0x6f04 <_stogir.conversion.validate+0x31c>
    6ef4:      	lsl	x3, x9, #4
    6ef8:      	ldr	x0, [x0, #0x28]
    6efc:      	add	x0, x3, x0
    6f00:      	ldr	x0, [x0]
    6f04:      	mov	x3, x0
    6f08:      	mov	x0, #0x1                ; =1
    6f0c:      	b	0x6f18 <_stogir.conversion.validate+0x330>
    6f10:      	movz	x0, #0x0, lsl #48
    6f14:      	movz	x3, #0x0, lsl #48
    6f18:      	lsr	w0, w0, #0
    6f1c:      	lsr	x16, x0, #0
    6f20:      	cmp	x16, #0x1
    6f24:      	b.eq	0x6f40 <_stogir.conversion.validate+0x358>
    6f28:      	b.lo	0x6f30 <_stogir.conversion.validate+0x348>
    6f2c:      	b	0x6f44 <_stogir.conversion.validate+0x35c>
    6f30:      	cmp	x16, #0x0
    6f34:      	b.eq	0x6f3c <_stogir.conversion.validate+0x354>
    6f38:      	b	0x6f44 <_stogir.conversion.validate+0x35c>
    6f3c:      	b	0x6f48 <_stogir.conversion.validate+0x360>
    6f40:      	b	0x6e40 <_stogir.conversion.validate+0x258>
    6f44:      	b	0x6fe4 <_stogir.conversion.validate+0x3fc>
    6f48:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x254>
		0000000000006f48:  ARM64_RELOC_PAGE21	l_stogir.402
    6f4c:      	ldr	x16, [x16]
		0000000000006f4c:  ARM64_RELOC_PAGEOFF12	l_stogir.402
    6f50:      	orr	x0, x16, xzr
    6f54:      	mov	x19, x8
    6f58:      	mov	x1, x0
    6f5c:      	mov	x0, #0x1                ; =1
    6f60:      	mov	x2, #0x19               ; =25
    6f64:      	b	0x6e68 <_stogir.conversion.validate+0x280>
    6f68:      	movz	x4, #0x0, lsl #48
    6f6c:      	b	0x6ecc <_stogir.conversion.validate+0x2e4>
    6f70:      	movz	x4, #0x0, lsl #48
    6f74:      	b	0x6ec4 <_stogir.conversion.validate+0x2dc>
    6f78:      	cmp	x0, #0x46
    6f7c:      	b.eq	0x7004 <_stogir.conversion.validate+0x41c>
    6f80:      	lsr	w2, w2, #0
    6f84:      	lsr	w5, w5, #0
    6f88:      	lsr	w3, w3, #0
    6f8c:      	lsr	w1, w1, #0
    6f90:      	ubfx	x0, x5, #8, #8
    6f94:      	ubfx	x3, x3, #8, #8
    6f98:      	lsr	w0, w0, #0
    6f9c:      	lsr	w3, w3, #0
    6fa0:      	mov	x19, x8
    6fa4:      	add	x8, sp, #0x10
    6fa8:      	fmov	s31, w0
    6fac:      	mov	w0, w1
    6fb0:      	mov	w1, w3
    6fb4:      	mov	w3, w2
    6fb8:      	fmov	w2, s31
    6fbc:      	bl	0x6fbc <_stogir.conversion.validate+0x3d4>
		0000000000006fbc:  ARM64_RELOC_BRANCH26	_stogir.conversion.policy
    6fc0:      	add	x16, sp, #0x10
    6fc4:      	ldr	x0, [x16]
    6fc8:      	add	x16, sp, #0x10
    6fcc:      	ldr	x1, [x16, #0x8]
    6fd0:      	add	x16, sp, #0x10
    6fd4:      	ldr	x2, [x16, #0x10]
    6fd8:      	b	0x6e68 <_stogir.conversion.validate+0x280>
    6fdc:      	movz	x4, #0x0, lsl #48
    6fe0:      	b	0x6f6c <_stogir.conversion.validate+0x384>
    6fe4:      	brk	#0
    6fe8:      	b	0x6fe4 <_stogir.conversion.validate+0x3fc>
    6fec:      	mov	x19, x8
    6ff0:      	b	0x6d84 <_stogir.conversion.validate+0x19c>
    6ff4:      	mov	x19, x8
    6ff8:      	b	0x6d84 <_stogir.conversion.validate+0x19c>
    6ffc:      	mov	x19, x8
    7000:      	b	0x6d84 <_stogir.conversion.validate+0x19c>
    7004:      	mov	x19, x8
    7008:      	b	0x6e50 <_stogir.conversion.validate+0x268>

000000000000700c <_stogir.conditional.validate>:
    700c:      	sub	sp, sp, #0x40
    7010:      	str	x29, [sp]
    7014:      	str	x30, [sp, #0x8]
    7018:      	mov	x29, sp
    701c:      	str	x19, [sp, #0x30]
    7020:      	sxtw	x1, w1
    7024:      	lsl	x2, x1, #2
    7028:      	cmp	x1, #0x0
    702c:      	cset	w3, gt
    7030:      	movz	x16, #0x0, lsl #48
    7034:      	sub	x4, x16, x1
    7038:      	sub	x5, x4, #0x1
    703c:      	uxtb	w16, w3
    7040:      	cmp	w16, wzr
    7044:      	b.eq	0x7084 <_stogir.conditional.validate+0x78>
    7048:      	ldr	x4, [x0, #0x8]
    704c:      	cmp	x1, x4
    7050:      	b.ge	0x70d8 <_stogir.conditional.validate+0xcc>
    7054:      	add	x4, x0, #0x78
    7058:      	ldr	x4, [x4, #0x8]
    705c:      	cmp	x1, x4
    7060:      	b.ge	0x71ec <_stogir.conditional.validate+0x1e0>
    7064:      	ldr	x4, [x0, #0x78]
    7068:      	add	x4, x2, x4
    706c:      	ldr	w4, [x4]
    7070:      	sxtw	x4, w4
    7074:      	cmp	x4, #0x0
    7078:      	cset	w4, ge
    707c:      	ubfx	x4, x4, #0, #8
    7080:      	b	0x71f0 <_stogir.conditional.validate+0x1e4>
    7084:      	cmp	x1, #0x0
    7088:      	b.ge	0x70e0 <_stogir.conditional.validate+0xd4>
    708c:      	add	x6, x0, #0x28
    7090:      	add	x7, x0, #0x50
    7094:      	ldr	x6, [x6, #0x8]
    7098:      	ldr	x7, [x7, #0x8]
    709c:      	cmp	x6, x7
    70a0:      	b.ne	0x70d0 <_stogir.conditional.validate+0xc4>
    70a4:      	cmp	x4, x6
    70a8:      	b.gt	0x7274 <_stogir.conditional.validate+0x268>
    70ac:      	lsl	x4, x5, #2
    70b0:      	ldr	x6, [x0, #0x50]
    70b4:      	add	x4, x4, x6
    70b8:      	ldr	w4, [x4]
    70bc:      	sxtw	x4, w4
    70c0:      	cmp	x4, #0x0
    70c4:      	cset	w4, gt
    70c8:      	ubfx	x4, x4, #0, #8
    70cc:      	b	0x7278 <_stogir.conditional.validate+0x26c>
    70d0:      	movz	x4, #0x0, lsl #48
    70d4:      	b	0x70e4 <_stogir.conditional.validate+0xd8>
    70d8:      	movz	x4, #0x0, lsl #48
    70dc:      	b	0x70e4 <_stogir.conditional.validate+0xd8>
    70e0:      	movz	x4, #0x0, lsl #48
    70e4:      	cmp	x4, #0x0
    70e8:      	b.eq	0x714c <_stogir.conditional.validate+0x140>
    70ec:      	uxtb	w16, w3
    70f0:      	cmp	w16, wzr
    70f4:      	b.eq	0x711c <_stogir.conditional.validate+0x110>
    70f8:      	lsl	x3, x1, #4
    70fc:      	ldr	x4, [x0]
    7100:      	add	x3, x3, x4
    7104:      	ldr	x4, [x3]
    7108:      	ldr	x3, [x3, #0x8]
    710c:      	fmov	d31, x3
    7110:      	mov	x3, x4
    7114:      	fmov	x4, d31
    7118:      	b	0x713c <_stogir.conditional.validate+0x130>
    711c:      	lsl	x3, x5, #4
    7120:      	ldr	x4, [x0, #0x28]
    7124:      	add	x3, x3, x4
    7128:      	ldr	x4, [x3]
    712c:      	ldr	x3, [x3, #0x8]
    7130:      	fmov	d31, x3
    7134:      	mov	x3, x4
    7138:      	fmov	x4, d31
    713c:      	mov	x5, x4
    7140:      	mov	x4, x3
    7144:      	mov	x3, #0x1                ; =1
    7148:      	b	0x7158 <_stogir.conditional.validate+0x14c>
    714c:      	movz	x3, #0x0, lsl #48
    7150:      	movz	x4, #0x0, lsl #48
    7154:      	movz	x5, #0x0, lsl #48
    7158:      	lsr	w3, w3, #0
    715c:      	lsr	x16, x3, #0
    7160:      	cmp	x16, #0x1
    7164:      	b.eq	0x7180 <_stogir.conditional.validate+0x174>
    7168:      	b.lo	0x7170 <_stogir.conditional.validate+0x164>
    716c:      	b	0x7184 <_stogir.conditional.validate+0x178>
    7170:      	cmp	x16, #0x0
    7174:      	b.eq	0x717c <_stogir.conditional.validate+0x170>
    7178:      	b	0x7184 <_stogir.conditional.validate+0x178>
    717c:      	b	0x7188 <_stogir.conditional.validate+0x17c>
    7180:      	b	0x71a8 <_stogir.conditional.validate+0x19c>
    7184:      	b	0x727c <_stogir.conditional.validate+0x270>
    7188:      	adrp	x16, 0x7000 <_stogir.conversion.validate+0x418>
		0000000000007188:  ARM64_RELOC_PAGE21	l_stogir.403
    718c:      	ldr	x16, [x16]
		000000000000718c:  ARM64_RELOC_PAGEOFF12	l_stogir.403
    7190:      	orr	x0, x16, xzr
    7194:      	mov	x19, x8
    7198:      	mov	x1, x0
    719c:      	mov	x0, #0x1                ; =1
    71a0:      	mov	x2, #0x18               ; =24
    71a4:      	b	0x71cc <_stogir.conditional.validate+0x1c0>
    71a8:      	cmp	x1, #0x0
    71ac:      	b.gt	0x71f4 <_stogir.conditional.validate+0x1e8>
    71b0:      	mov	x19, x8
    71b4:      	adrp	x16, 0x7000 <_stogir.conversion.validate+0x418>
		00000000000071b4:  ARM64_RELOC_PAGE21	l_stogir.404
    71b8:      	ldr	x16, [x16]
		00000000000071b8:  ARM64_RELOC_PAGEOFF12	l_stogir.404
    71bc:      	orr	x0, x16, xzr
    71c0:      	mov	x1, x0
    71c4:      	mov	x0, #0x1                ; =1
    71c8:      	mov	x2, #0x18               ; =24
    71cc:      	str	x0, [x19]
    71d0:      	str	x1, [x19, #0x8]
    71d4:      	str	x2, [x19, #0x10]
    71d8:      	ldr	x19, [sp, #0x30]
    71dc:      	ldr	x29, [sp]
    71e0:      	ldr	x30, [sp, #0x8]
    71e4:      	add	sp, sp, #0x40
    71e8:      	ret
    71ec:      	movz	x4, #0x0, lsl #48
    71f0:      	b	0x70dc <_stogir.conditional.validate+0xd0>
    71f4:      	uxtb	w1, w4
    71f8:      	cmp	x1, #0x3c
    71fc:      	b.ne	0x7284 <_stogir.conditional.validate+0x278>
    7200:      	ldr	x1, [x0, #0x78]
    7204:      	add	x1, x2, x1
    7208:      	ldr	w1, [x1]
    720c:      	sxtw	x1, w1
    7210:      	cmp	x1, #0x3
    7214:      	b.ne	0x728c <_stogir.conditional.validate+0x280>
    7218:      	lsr	w1, w5, #0
    721c:      	lsr	w2, w4, #0
    7220:      	lsr	x3, x4, #32
    7224:      	lsr	w1, w1, #0
    7228:      	lsr	x4, x5, #32
    722c:      	lsr	w3, w3, #0
    7230:      	lsr	w4, w4, #0
    7234:      	ubfx	x2, x2, #8, #8
    7238:      	lsr	w2, w2, #0
    723c:      	mov	x19, x8
    7240:      	add	x8, sp, #0x10
    7244:      	fmov	s31, w1
    7248:      	mov	w1, w2
    724c:      	mov	w2, w3
    7250:      	fmov	w3, s31
    7254:      	bl	0x7254 <_stogir.conditional.validate+0x248>
		0000000000007254:  ARM64_RELOC_BRANCH26	_stogir.conditional.operands
    7258:      	add	x16, sp, #0x10
    725c:      	ldr	x0, [x16]
    7260:      	add	x16, sp, #0x10
    7264:      	ldr	x1, [x16, #0x8]
    7268:      	add	x16, sp, #0x10
    726c:      	ldr	x2, [x16, #0x10]
    7270:      	b	0x71cc <_stogir.conditional.validate+0x1c0>
    7274:      	movz	x4, #0x0, lsl #48
    7278:      	b	0x70d4 <_stogir.conditional.validate+0xc8>
    727c:      	brk	#0
    7280:      	b	0x727c <_stogir.conditional.validate+0x270>
    7284:      	mov	x19, x8
    7288:      	b	0x71b4 <_stogir.conditional.validate+0x1a8>
    728c:      	mov	x19, x8
    7290:      	b	0x71b4 <_stogir.conditional.validate+0x1a8>

0000000000007294 <_stogir.floating.validate>:
    7294:      	sub	sp, sp, #0x50
    7298:      	str	x29, [sp]
    729c:      	str	x30, [sp, #0x8]
    72a0:      	mov	x29, sp
    72a4:      	str	x19, [sp, #0x40]
    72a8:      	sxtw	x1, w1
    72ac:      	lsl	x2, x1, #2
    72b0:      	cmp	x1, #0x0
    72b4:      	cset	w3, gt
    72b8:      	movz	x16, #0x0, lsl #48
    72bc:      	sub	x4, x16, x1
    72c0:      	sub	x5, x4, #0x1
    72c4:      	uxtb	w16, w3
    72c8:      	cmp	w16, wzr
    72cc:      	b.eq	0x730c <_stogir.floating.validate+0x78>
    72d0:      	ldr	x4, [x0, #0x8]
    72d4:      	cmp	x1, x4
    72d8:      	b.ge	0x7360 <_stogir.floating.validate+0xcc>
    72dc:      	add	x4, x0, #0x78
    72e0:      	ldr	x4, [x4, #0x8]
    72e4:      	cmp	x1, x4
    72e8:      	b.ge	0x7484 <_stogir.floating.validate+0x1f0>
    72ec:      	ldr	x4, [x0, #0x78]
    72f0:      	add	x4, x2, x4
    72f4:      	ldr	w4, [x4]
    72f8:      	sxtw	x4, w4
    72fc:      	cmp	x4, #0x0
    7300:      	cset	w4, ge
    7304:      	ubfx	x4, x4, #0, #8
    7308:      	b	0x7488 <_stogir.floating.validate+0x1f4>
    730c:      	cmp	x1, #0x0
    7310:      	b.ge	0x7368 <_stogir.floating.validate+0xd4>
    7314:      	add	x6, x0, #0x28
    7318:      	add	x7, x0, #0x50
    731c:      	ldr	x6, [x6, #0x8]
    7320:      	ldr	x7, [x7, #0x8]
    7324:      	cmp	x6, x7
    7328:      	b.ne	0x7358 <_stogir.floating.validate+0xc4>
    732c:      	cmp	x4, x6
    7330:      	b.gt	0x7510 <_stogir.floating.validate+0x27c>
    7334:      	lsl	x4, x5, #2
    7338:      	ldr	x6, [x0, #0x50]
    733c:      	add	x4, x4, x6
    7340:      	ldr	w4, [x4]
    7344:      	sxtw	x4, w4
    7348:      	cmp	x4, #0x0
    734c:      	cset	w4, gt
    7350:      	ubfx	x4, x4, #0, #8
    7354:      	b	0x7514 <_stogir.floating.validate+0x280>
    7358:      	movz	x4, #0x0, lsl #48
    735c:      	b	0x736c <_stogir.floating.validate+0xd8>
    7360:      	movz	x4, #0x0, lsl #48
    7364:      	b	0x736c <_stogir.floating.validate+0xd8>
    7368:      	movz	x4, #0x0, lsl #48
    736c:      	cmp	x4, #0x0
    7370:      	b.eq	0x73d4 <_stogir.floating.validate+0x140>
    7374:      	uxtb	w16, w3
    7378:      	cmp	w16, wzr
    737c:      	b.eq	0x73a4 <_stogir.floating.validate+0x110>
    7380:      	lsl	x3, x1, #4
    7384:      	ldr	x4, [x0]
    7388:      	add	x3, x3, x4
    738c:      	ldr	x4, [x3]
    7390:      	ldr	x3, [x3, #0x8]
    7394:      	fmov	d31, x3
    7398:      	mov	x3, x4
    739c:      	fmov	x4, d31
    73a0:      	b	0x73c4 <_stogir.floating.validate+0x130>
    73a4:      	lsl	x3, x5, #4
    73a8:      	ldr	x4, [x0, #0x28]
    73ac:      	add	x3, x3, x4
    73b0:      	ldr	x4, [x3]
    73b4:      	ldr	x3, [x3, #0x8]
    73b8:      	fmov	d31, x3
    73bc:      	mov	x3, x4
    73c0:      	fmov	x4, d31
    73c4:      	mov	x5, x4
    73c8:      	mov	x4, x3
    73cc:      	mov	x3, #0x1                ; =1
    73d0:      	b	0x73e0 <_stogir.floating.validate+0x14c>
    73d4:      	movz	x3, #0x0, lsl #48
    73d8:      	movz	x4, #0x0, lsl #48
    73dc:      	movz	x5, #0x0, lsl #48
    73e0:      	lsr	w3, w3, #0
    73e4:      	lsr	x16, x3, #0
    73e8:      	cmp	x16, #0x1
    73ec:      	b.eq	0x7408 <_stogir.floating.validate+0x174>
    73f0:      	b.lo	0x73f8 <_stogir.floating.validate+0x164>
    73f4:      	b	0x740c <_stogir.floating.validate+0x178>
    73f8:      	cmp	x16, #0x0
    73fc:      	b.eq	0x7404 <_stogir.floating.validate+0x170>
    7400:      	b	0x740c <_stogir.floating.validate+0x178>
    7404:      	b	0x7410 <_stogir.floating.validate+0x17c>
    7408:      	b	0x744c <_stogir.floating.validate+0x1b8>
    740c:      	b	0x77cc <_stogir.floating.validate+0x538>
    7410:      	adrp	x16, 0x7000 <_stogir.conversion.validate+0x418>
		0000000000007410:  ARM64_RELOC_PAGE21	l_stogir.405
    7414:      	ldr	x16, [x16]
		0000000000007414:  ARM64_RELOC_PAGEOFF12	l_stogir.405
    7418:      	orr	x0, x16, xzr
    741c:      	mov	x19, x8
    7420:      	mov	x1, x0
    7424:      	mov	x0, #0x1                ; =1
    7428:      	mov	x2, #0x1c               ; =28
    742c:      	str	x0, [x19]
    7430:      	str	x1, [x19, #0x8]
    7434:      	str	x2, [x19, #0x10]
    7438:      	ldr	x19, [sp, #0x40]
    743c:      	ldr	x29, [sp]
    7440:      	ldr	x30, [sp, #0x8]
    7444:      	add	sp, sp, #0x50
    7448:      	ret
    744c:      	add	x16, sp, #0x10
    7450:      	str	x4, [x16]
    7454:      	add	x16, sp, #0x10
    7458:      	str	x5, [x16, #0x8]
    745c:      	cmp	x1, #0x0
    7460:      	b.gt	0x748c <_stogir.floating.validate+0x1f8>
    7464:      	mov	x19, x8
    7468:      	adrp	x16, 0x7000 <_stogir.conversion.validate+0x418>
		0000000000007468:  ARM64_RELOC_PAGE21	l_stogir.406
    746c:      	ldr	x16, [x16]
		000000000000746c:  ARM64_RELOC_PAGEOFF12	l_stogir.406
    7470:      	orr	x0, x16, xzr
    7474:      	mov	x1, x0
    7478:      	mov	x0, #0x1                ; =1
    747c:      	mov	x2, #0x1c               ; =28
    7480:      	b	0x742c <_stogir.floating.validate+0x198>
    7484:      	movz	x4, #0x0, lsl #48
    7488:      	b	0x7364 <_stogir.floating.validate+0xd0>
    748c:      	uxtb	w4, w4
    7490:      	orr	x1, x4, xzr
    7494:      	cmp	x1, #0xe
    7498:      	cset	w3, ge
    749c:      	cmp	x1, #0x19
    74a0:      	cset	w5, le
    74a4:      	cmp	x1, #0x1f
    74a8:      	cset	w6, eq
    74ac:      	cmp	x1, #0x20
    74b0:      	cset	w7, eq
    74b4:      	uxtb	w16, w3
    74b8:      	cmp	w16, wzr
    74bc:      	b.eq	0x7518 <_stogir.floating.validate+0x284>
    74c0:      	uxtb	w16, w5
    74c4:      	cmp	w16, wzr
    74c8:      	b.eq	0x7518 <_stogir.floating.validate+0x284>
    74cc:      	cmp	x1, #0x1d
    74d0:      	cset	w1, eq
    74d4:      	ldr	x9, [x0, #0x78]
    74d8:      	add	x2, x2, x9
    74dc:      	ldr	w2, [x2]
    74e0:      	uxtb	w16, w6
    74e4:      	cmp	w16, wzr
    74e8:      	b.ne	0x7558 <_stogir.floating.validate+0x2c4>
    74ec:      	uxtb	w16, w7
    74f0:      	cmp	w16, wzr
    74f4:      	b.ne	0x7558 <_stogir.floating.validate+0x2c4>
    74f8:      	uxtb	w16, w1
    74fc:      	cmp	w16, wzr
    7500:      	mov	x16, #0x3               ; =3
    7504:      	mov	x17, #0x2               ; =2
    7508:      	csel	x6, x16, x17, ne
    750c:      	b	0x755c <_stogir.floating.validate+0x2c8>
    7510:      	movz	x4, #0x0, lsl #48
    7514:      	b	0x735c <_stogir.floating.validate+0xc8>
    7518:      	uxtb	w16, w6
    751c:      	cmp	w16, wzr
    7520:      	b.ne	0x74cc <_stogir.floating.validate+0x238>
    7524:      	uxtb	w16, w7
    7528:      	cmp	w16, wzr
    752c:      	b.ne	0x74cc <_stogir.floating.validate+0x238>
    7530:      	cmp	x1, #0x1a
    7534:      	b.lt	0x7540 <_stogir.floating.validate+0x2ac>
    7538:      	cmp	x1, #0x1d
    753c:      	b.le	0x74cc <_stogir.floating.validate+0x238>
    7540:      	cmp	x1, #0x3a
    7544:      	b.eq	0x74cc <_stogir.floating.validate+0x238>
    7548:      	cmp	x1, #0x3b
    754c:      	b.eq	0x74cc <_stogir.floating.validate+0x238>
    7550:      	mov	x19, x8
    7554:      	b	0x7468 <_stogir.floating.validate+0x1d4>
    7558:      	mov	x6, #0x1                ; =1
    755c:      	sxtw	x2, w2
    7560:      	lsr	w6, w6, #0
    7564:      	sxtw	x6, w6
    7568:      	cmp	x2, x6
    756c:      	b.ne	0x77dc <_stogir.floating.validate+0x548>
    7570:      	add	x16, sp, #0x10
    7574:      	ldr	w2, [x16, #0x4]
    7578:      	sxtw	x2, w2
    757c:      	cmp	x2, #0x0
    7580:      	cset	w6, gt
    7584:      	movz	x16, #0x0, lsl #48
    7588:      	sub	x7, x16, x2
    758c:      	sub	x9, x7, #0x1
    7590:      	uxtb	w16, w6
    7594:      	cmp	w16, wzr
    7598:      	b.eq	0x75f8 <_stogir.floating.validate+0x364>
    759c:      	ldr	x7, [x0, #0x8]
    75a0:      	cmp	x2, x7
    75a4:      	b.ge	0x7644 <_stogir.floating.validate+0x3b0>
    75a8:      	add	x7, x0, #0x78
    75ac:      	ldr	x7, [x7, #0x8]
    75b0:      	cmp	x2, x7
    75b4:      	b.ge	0x7724 <_stogir.floating.validate+0x490>
    75b8:      	lsl	x7, x2, #2
    75bc:      	ldr	x10, [x0, #0x78]
    75c0:      	add	x7, x7, x10
    75c4:      	ldr	w7, [x7]
    75c8:      	sxtw	x7, w7
    75cc:      	cmp	x7, #0x0
    75d0:      	cset	w7, ge
    75d4:      	ubfx	x7, x7, #0, #8
    75d8:      	b	0x7728 <_stogir.floating.validate+0x494>
    75dc:      	adrp	x16, 0x7000 <_stogir.conversion.validate+0x418>
		00000000000075dc:  ARM64_RELOC_PAGE21	l_stogir.407
    75e0:      	ldr	x16, [x16]
		00000000000075e0:  ARM64_RELOC_PAGEOFF12	l_stogir.407
    75e4:      	orr	x0, x16, xzr
    75e8:      	mov	x1, x0
    75ec:      	mov	x0, #0x1                ; =1
    75f0:      	mov	x2, #0x1d               ; =29
    75f4:      	b	0x7480 <_stogir.floating.validate+0x1ec>
    75f8:      	cmp	x2, #0x0
    75fc:      	b.ge	0x764c <_stogir.floating.validate+0x3b8>
    7600:      	add	x10, x0, #0x28
    7604:      	add	x11, x0, #0x50
    7608:      	ldr	x10, [x10, #0x8]
    760c:      	ldr	x11, [x11, #0x8]
    7610:      	cmp	x10, x11
    7614:      	b.ne	0x771c <_stogir.floating.validate+0x488>
    7618:      	cmp	x7, x10
    761c:      	b.gt	0x77c4 <_stogir.floating.validate+0x530>
    7620:      	lsl	x7, x9, #2
    7624:      	ldr	x10, [x0, #0x50]
    7628:      	add	x7, x7, x10
    762c:      	ldr	w7, [x7]
    7630:      	sxtw	x7, w7
    7634:      	cmp	x7, #0x0
    7638:      	cset	w7, gt
    763c:      	ubfx	x7, x7, #0, #8
    7640:      	b	0x77c8 <_stogir.floating.validate+0x534>
    7644:      	movz	x7, #0x0, lsl #48
    7648:      	b	0x7650 <_stogir.floating.validate+0x3bc>
    764c:      	movz	x7, #0x0, lsl #48
    7650:      	cmp	x7, #0x0
    7654:      	b.eq	0x7694 <_stogir.floating.validate+0x400>
    7658:      	uxtb	w16, w6
    765c:      	cmp	w16, wzr
    7660:      	b.eq	0x7678 <_stogir.floating.validate+0x3e4>
    7664:      	lsl	x2, x2, #4
    7668:      	ldr	x6, [x0]
    766c:      	add	x2, x2, x6
    7670:      	ldr	x2, [x2]
    7674:      	b	0x7688 <_stogir.floating.validate+0x3f4>
    7678:      	lsl	x2, x9, #4
    767c:      	ldr	x6, [x0, #0x28]
    7680:      	add	x2, x2, x6
    7684:      	ldr	x2, [x2]
    7688:      	mov	x6, x2
    768c:      	mov	x2, #0x1                ; =1
    7690:      	b	0x769c <_stogir.floating.validate+0x408>
    7694:      	movz	x2, #0x0, lsl #48
    7698:      	movz	x6, #0x0, lsl #48
    769c:      	lsr	w2, w2, #0
    76a0:      	lsr	x16, x2, #0
    76a4:      	cmp	x16, #0x1
    76a8:      	b.eq	0x76c4 <_stogir.floating.validate+0x430>
    76ac:      	b.lo	0x76b4 <_stogir.floating.validate+0x420>
    76b0:      	b	0x76c8 <_stogir.floating.validate+0x434>
    76b4:      	cmp	x16, #0x0
    76b8:      	b.eq	0x76c0 <_stogir.floating.validate+0x42c>
    76bc:      	b	0x76c8 <_stogir.floating.validate+0x434>
    76c0:      	b	0x76cc <_stogir.floating.validate+0x438>
    76c4:      	b	0x76ec <_stogir.floating.validate+0x458>
    76c8:      	b	0x77d4 <_stogir.floating.validate+0x540>
    76cc:      	adrp	x16, 0x7000 <_stogir.conversion.validate+0x418>
		00000000000076cc:  ARM64_RELOC_PAGE21	l_stogir.408
    76d0:      	ldr	x16, [x16]
		00000000000076d0:  ARM64_RELOC_PAGEOFF12	l_stogir.408
    76d4:      	orr	x0, x16, xzr
    76d8:      	mov	x19, x8
    76dc:      	mov	x1, x0
    76e0:      	mov	x0, #0x1                ; =1
    76e4:      	mov	x2, #0x18               ; =24
    76e8:      	b	0x75f4 <_stogir.floating.validate+0x360>
    76ec:      	lsr	w6, w6, #0
    76f0:      	add	x16, sp, #0x10
    76f4:      	ldr	w2, [x16]
    76f8:      	ubfx	x6, x6, #8, #8
    76fc:      	uxtb	w16, w3
    7700:      	cmp	w16, wzr
    7704:      	b.eq	0x7780 <_stogir.floating.validate+0x4ec>
    7708:      	uxtb	w16, w5
    770c:      	cmp	w16, wzr
    7710:      	b.eq	0x7780 <_stogir.floating.validate+0x4ec>
    7714:      	mov	x3, #0x1                ; =1
    7718:      	b	0x7784 <_stogir.floating.validate+0x4f0>
    771c:      	movz	x7, #0x0, lsl #48
    7720:      	b	0x7650 <_stogir.floating.validate+0x3bc>
    7724:      	movz	x7, #0x0, lsl #48
    7728:      	b	0x7648 <_stogir.floating.validate+0x3b4>
    772c:      	movz	x1, #0x0, lsl #48
    7730:      	lsr	w2, w2, #0
    7734:      	lsr	w3, w3, #0
    7738:      	lsr	w4, w4, #0
    773c:      	lsr	w6, w6, #0
    7740:      	lsr	w1, w1, #0
    7744:      	mov	w5, w1
    7748:      	mov	w1, w4
    774c:      	mov	w4, w3
    7750:      	mov	w3, w2
    7754:      	mov	w2, w6
    7758:      	mov	x19, x8
    775c:      	add	x8, sp, #0x20
    7760:      	bl	0x7760 <_stogir.floating.validate+0x4cc>
		0000000000007760:  ARM64_RELOC_BRANCH26	_stogir.floating.operands
    7764:      	add	x16, sp, #0x20
    7768:      	ldr	x0, [x16]
    776c:      	add	x16, sp, #0x20
    7770:      	ldr	x1, [x16, #0x8]
    7774:      	add	x16, sp, #0x20
    7778:      	ldr	x2, [x16, #0x10]
    777c:      	b	0x75f4 <_stogir.floating.validate+0x360>
    7780:      	orr	x3, x6, xzr
    7784:      	lsr	w3, w3, #0
    7788:      	ubfx	x2, x2, #8, #8
    778c:      	sxtw	x3, w3
    7790:      	cmp	x2, x3
    7794:      	b.ne	0x77e4 <_stogir.floating.validate+0x550>
    7798:      	add	x16, sp, #0x10
    779c:      	ldr	w2, [x16, #0x4]
    77a0:      	add	x16, sp, #0x10
    77a4:      	ldr	w3, [x16, #0x8]
    77a8:      	uxtb	w16, w1
    77ac:      	cmp	w16, wzr
    77b0:      	b.eq	0x772c <_stogir.floating.validate+0x498>
    77b4:      	add	x16, sp, #0x10
    77b8:      	ldr	w1, [x16, #0xc]
    77bc:      	sxtw	x1, w1
    77c0:      	b	0x7730 <_stogir.floating.validate+0x49c>
    77c4:      	movz	x7, #0x0, lsl #48
    77c8:      	b	0x7720 <_stogir.floating.validate+0x48c>
    77cc:      	brk	#0
    77d0:      	b	0x77cc <_stogir.floating.validate+0x538>
    77d4:      	brk	#0
    77d8:      	b	0x77d4 <_stogir.floating.validate+0x540>
    77dc:      	mov	x19, x8
    77e0:      	b	0x7468 <_stogir.floating.validate+0x1d4>
    77e4:      	mov	x19, x8
    77e8:      	b	0x75dc <_stogir.floating.validate+0x348>

00000000000077ec <_stogir.types.integer?>:
    77ec:      	sxtw	x0, w0
    77f0:      	cmp	x0, #0x1
    77f4:      	b.lt	0x7808 <_stogir.types.integer?+0x1c>
    77f8:      	cmp	x0, #0xb
    77fc:      	cset	w0, le
    7800:      	ubfx	x0, x0, #0, #8
    7804:      	b	0x780c <_stogir.types.integer?+0x20>
    7808:      	movz	x0, #0x0, lsl #48
    780c:      	ret

0000000000007810 <_stogir.integer-unary.valid-type?>:
    7810:      	sxtw	x0, w0
    7814:      	cmp	x0, #0x2d
    7818:      	cset	w2, eq
    781c:      	cmp	x0, #0x1f
    7820:      	cset	w3, eq
    7824:      	cmp	x0, #0x20
    7828:      	cset	w4, eq
    782c:      	cmp	x0, #0x36
    7830:      	cset	w5, eq
    7834:      	uxtb	w16, w3
    7838:      	cmp	w16, wzr
    783c:      	b.ne	0x7884 <_stogir.integer-unary.valid-type?+0x74>
    7840:      	uxtb	w16, w4
    7844:      	cmp	w16, wzr
    7848:      	b.ne	0x7884 <_stogir.integer-unary.valid-type?+0x74>
    784c:      	uxtb	w16, w2
    7850:      	cmp	w16, wzr
    7854:      	b.ne	0x7884 <_stogir.integer-unary.valid-type?+0x74>
    7858:      	uxtb	w16, w5
    785c:      	cmp	w16, wzr
    7860:      	b.ne	0x7884 <_stogir.integer-unary.valid-type?+0x74>
    7864:      	cmp	x0, #0x37
    7868:      	b.eq	0x7884 <_stogir.integer-unary.valid-type?+0x74>
    786c:      	cmp	x0, #0x38
    7870:      	b.eq	0x7884 <_stogir.integer-unary.valid-type?+0x74>
    7874:      	cmp	x0, #0x39
    7878:      	b.eq	0x7884 <_stogir.integer-unary.valid-type?+0x74>
    787c:      	movz	x0, #0x0, lsl #48
    7880:      	b	0x78bc <_stogir.integer-unary.valid-type?+0xac>
    7884:      	sxtw	x1, w1
    7888:      	cmp	x1, #0x1
    788c:      	b.lt	0x78b8 <_stogir.integer-unary.valid-type?+0xa8>
    7890:      	cmp	x1, #0xb
    7894:      	cset	w0, le
    7898:      	uxtb	w16, w0
    789c:      	cmp	w16, wzr
    78a0:      	b.eq	0x78b8 <_stogir.integer-unary.valid-type?+0xa8>
    78a4:      	uxtb	w16, w2
    78a8:      	cmp	w16, wzr
    78ac:      	b.eq	0x78c8 <_stogir.integer-unary.valid-type?+0xb8>
    78b0:      	mov	x0, #0x1                ; =1
    78b4:      	b	0x78c4 <_stogir.integer-unary.valid-type?+0xb4>
    78b8:      	movz	x0, #0x0, lsl #48
    78bc:      	ret
    78c0:      	mov	x0, #0x1                ; =1
    78c4:      	b	0x78bc <_stogir.integer-unary.valid-type?+0xac>
    78c8:      	cmp	x1, #0x1
    78cc:      	b.ne	0x78d8 <_stogir.integer-unary.valid-type?+0xc8>
    78d0:      	movz	x0, #0x0, lsl #48
    78d4:      	b	0x78c4 <_stogir.integer-unary.valid-type?+0xb4>
    78d8:      	cmp	x1, #0x6
    78dc:      	cset	w2, eq
    78e0:      	uxtb	w16, w3
    78e4:      	cmp	w16, wzr
    78e8:      	b.eq	0x78fc <_stogir.integer-unary.valid-type?+0xec>
    78ec:      	uxtb	w16, w2
    78f0:      	cmp	w16, wzr
    78f4:      	cset	x0, eq
    78f8:      	b	0x78c4 <_stogir.integer-unary.valid-type?+0xb4>
    78fc:      	uxtb	w16, w4
    7900:      	cmp	w16, wzr
    7904:      	b.eq	0x7920 <_stogir.integer-unary.valid-type?+0x110>
    7908:      	cmp	x1, #0x7
    790c:      	b.lt	0x7918 <_stogir.integer-unary.valid-type?+0x108>
    7910:      	ubfx	x0, x0, #0, #8
    7914:      	b	0x791c <_stogir.integer-unary.valid-type?+0x10c>
    7918:      	movz	x0, #0x0, lsl #48
    791c:      	b	0x78c4 <_stogir.integer-unary.valid-type?+0xb4>
    7920:      	uxtb	w16, w5
    7924:      	cmp	w16, wzr
    7928:      	b.eq	0x78c0 <_stogir.integer-unary.valid-type?+0xb0>
    792c:      	cmp	x1, #0x3
    7930:      	b.ne	0x794c <_stogir.integer-unary.valid-type?+0x13c>
    7934:      	mov	x0, #0x1                ; =1
    7938:      	b	0x7948 <_stogir.integer-unary.valid-type?+0x138>
    793c:      	cmp	x1, #0xb
    7940:      	cset	w0, eq
    7944:      	ubfx	x0, x0, #0, #8
    7948:      	b	0x78c4 <_stogir.integer-unary.valid-type?+0xb4>
    794c:      	cmp	x1, #0x4
    7950:      	b.ne	0x795c <_stogir.integer-unary.valid-type?+0x14c>
    7954:      	mov	x0, #0x1                ; =1
    7958:      	b	0x7948 <_stogir.integer-unary.valid-type?+0x138>
    795c:      	cmp	x1, #0x5
    7960:      	b.ne	0x796c <_stogir.integer-unary.valid-type?+0x15c>
    7964:      	mov	x0, #0x1                ; =1
    7968:      	b	0x7948 <_stogir.integer-unary.valid-type?+0x138>
    796c:      	uxtb	w16, w2
    7970:      	cmp	w16, wzr
    7974:      	b.eq	0x7980 <_stogir.integer-unary.valid-type?+0x170>
    7978:      	mov	x0, #0x1                ; =1
    797c:      	b	0x7948 <_stogir.integer-unary.valid-type?+0x138>
    7980:      	cmp	x1, #0x9
    7984:      	b.ne	0x7990 <_stogir.integer-unary.valid-type?+0x180>
    7988:      	mov	x0, #0x1                ; =1
    798c:      	b	0x7948 <_stogir.integer-unary.valid-type?+0x138>
    7990:      	cmp	x1, #0xa
    7994:      	b.ne	0x793c <_stogir.integer-unary.valid-type?+0x12c>
    7998:      	mov	x0, #0x1                ; =1
    799c:      	b	0x7948 <_stogir.integer-unary.valid-type?+0x138>

00000000000079a0 <_stogir.integer-binary.valid-type?>:
    79a0:      	sxtw	x0, w0
    79a4:      	cmp	x0, #0x3a
    79a8:      	cset	w2, eq
    79ac:      	cmp	x0, #0x3b
    79b0:      	cset	w3, eq
    79b4:      	cmp	x0, #0x1a
    79b8:      	b.lt	0x7a0c <_stogir.integer-binary.valid-type?+0x6c>
    79bc:      	cmp	x0, #0x1e
    79c0:      	b.gt	0x7a0c <_stogir.integer-binary.valid-type?+0x6c>
    79c4:      	sxtw	x1, w1
    79c8:      	cmp	x1, #0x1
    79cc:      	b.lt	0x7a3c <_stogir.integer-binary.valid-type?+0x9c>
    79d0:      	cmp	x1, #0xb
    79d4:      	b.gt	0x7a3c <_stogir.integer-binary.valid-type?+0x9c>
    79d8:      	cmp	x1, #0x1
    79dc:      	b.ne	0x7a44 <_stogir.integer-binary.valid-type?+0xa4>
    79e0:      	cmp	x0, #0x2e
    79e4:      	b.eq	0x7a4c <_stogir.integer-binary.valid-type?+0xac>
    79e8:      	cmp	x0, #0x2f
    79ec:      	b.eq	0x7a4c <_stogir.integer-binary.valid-type?+0xac>
    79f0:      	cmp	x0, #0x30
    79f4:      	b.eq	0x7a4c <_stogir.integer-binary.valid-type?+0xac>
    79f8:      	uxtb	w16, w2
    79fc:      	cmp	w16, wzr
    7a00:      	b.eq	0x7a54 <_stogir.integer-binary.valid-type?+0xb4>
    7a04:      	mov	x0, #0x1                ; =1
    7a08:      	b	0x7a5c <_stogir.integer-binary.valid-type?+0xbc>
    7a0c:      	cmp	x0, #0x2e
    7a10:      	b.lt	0x7a1c <_stogir.integer-binary.valid-type?+0x7c>
    7a14:      	cmp	x0, #0x35
    7a18:      	b.le	0x79c4 <_stogir.integer-binary.valid-type?+0x24>
    7a1c:      	uxtb	w16, w2
    7a20:      	cmp	w16, wzr
    7a24:      	b.ne	0x79c4 <_stogir.integer-binary.valid-type?+0x24>
    7a28:      	uxtb	w16, w3
    7a2c:      	cmp	w16, wzr
    7a30:      	b.ne	0x79c4 <_stogir.integer-binary.valid-type?+0x24>
    7a34:      	movz	x0, #0x0, lsl #48
    7a38:      	b	0x7a40 <_stogir.integer-binary.valid-type?+0xa0>
    7a3c:      	movz	x0, #0x0, lsl #48
    7a40:      	ret
    7a44:      	mov	x0, #0x1                ; =1
    7a48:      	b	0x7a40 <_stogir.integer-binary.valid-type?+0xa0>
    7a4c:      	mov	x0, #0x1                ; =1
    7a50:      	b	0x7a48 <_stogir.integer-binary.valid-type?+0xa8>
    7a54:      	ubfx	x3, x3, #0, #8
    7a58:      	mov	x0, x3
    7a5c:      	b	0x7a50 <_stogir.integer-binary.valid-type?+0xb0>

0000000000007a60 <_coil.core.Len$slice$len__u8>:
    7a60:      	mov	x0, x1
    7a64:      	ret

0000000000007a68 <_inherent$slice$data__u8>:
    7a68:      	ret

0000000000007a6c <_coil.mem.eql__u8>:
    7a6c:      	sub	sp, sp, #0x10
    7a70:      	str	x29, [sp]
    7a74:      	str	x30, [sp, #0x8]
    7a78:      	mov	x29, sp
    7a7c:      	cmp	x2, #0x0
    7a80:      	b.ne	0x7a8c <_coil.mem.eql__u8+0x20>
    7a84:      	mov	x0, #0x1                ; =1
    7a88:      	b	0x7aa8 <_coil.mem.eql__u8+0x3c>
    7a8c:      	lsr	x2, x2, #0
    7a90:      	bl	0x7a90 <_coil.mem.eql__u8+0x24>
		0000000000007a90:  ARM64_RELOC_BRANCH26	_memcmp
    7a94:      	lsr	w0, w0, #0
    7a98:      	sxtw	x0, w0
    7a9c:      	cmp	x0, #0x0
    7aa0:      	cset	w0, eq
    7aa4:      	ubfx	x0, x0, #0, #8
    7aa8:      	ldr	x29, [sp]
    7aac:      	ldr	x30, [sp, #0x8]
    7ab0:      	add	sp, sp, #0x10
    7ab4:      	ret

0000000000007ab8 <_stogir.opcode.count>:
    7ab8:      	mov	x0, #0x83               ; =131
    7abc:      	ret

0000000000007ac0 <_stogir.types.valid-scalar?>:
    7ac0:      	sxtw	x0, w0
    7ac4:      	cmp	x0, #0x0
    7ac8:      	b.lt	0x7adc <_stogir.types.valid-scalar?+0x1c>
    7acc:      	cmp	x0, #0xd
    7ad0:      	cset	w0, le
    7ad4:      	ubfx	x0, x0, #0, #8
    7ad8:      	b	0x7ae0 <_stogir.types.valid-scalar?+0x20>
    7adc:      	movz	x0, #0x0, lsl #48
    7ae0:      	ret

0000000000007ae4 <_stogir.types.vector?>:
    7ae4:      	sxtw	x0, w0
    7ae8:      	cmp	x0, #0xf
    7aec:      	b.le	0x7b28 <_stogir.types.vector?+0x44>
    7af0:      	cmp	x0, #0x80
    7af4:      	b.ge	0x7b38 <_stogir.types.vector?+0x54>
    7af8:      	and	x1, x0, #0xf
    7afc:      	lsr	w1, w1, #0
    7b00:      	sxtw	x1, w1
    7b04:      	cmp	x1, #0x1
    7b08:      	b.lt	0x7b30 <_stogir.types.vector?+0x4c>
    7b0c:      	and	x0, x0, #0xf
    7b10:      	lsr	w0, w0, #0
    7b14:      	sxtw	x0, w0
    7b18:      	cmp	x0, #0xd
    7b1c:      	cset	w0, le
    7b20:      	ubfx	x0, x0, #0, #8
    7b24:      	b	0x7b34 <_stogir.types.vector?+0x50>
    7b28:      	movz	x0, #0x0, lsl #48
    7b2c:      	b	0x7b34 <_stogir.types.vector?+0x50>
    7b30:      	movz	x0, #0x0, lsl #48
    7b34:      	ret
    7b38:      	movz	x0, #0x0, lsl #48
    7b3c:      	b	0x7b34 <_stogir.types.vector?+0x50>

0000000000007b40 <_coil.core.Get$slice$get__i8>:
    7b40:      	lsr	x1, x2, #0
    7b44:      	add	x0, x1, x0
    7b48:      	ldrsb	w0, [x0]
    7b4c:      	sxtb	x0, w0
    7b50:      	ret

0000000000007b54 <_stogir.opcode.metadata>:
    7b54:      	sub	sp, sp, #0x10
    7b58:      	mov	x0, sp
    7b5c:      	adrp	x16, 0x7000 <_stogir.conversion.validate+0x418>
		0000000000007b5c:  ARM64_RELOC_PAGE21	l_stogir.409
    7b60:      	ldr	x16, [x16]
		0000000000007b60:  ARM64_RELOC_PAGEOFF12	l_stogir.409
    7b64:      	orr	x1, x16, xzr
    7b68:      	str	x1, [x0]
    7b6c:      	mov	x17, #0x83              ; =131
    7b70:      	str	x17, [x0, #0x8]
    7b74:      	ldr	x0, [sp]
    7b78:      	ldr	x1, [sp, #0x8]
    7b7c:      	add	sp, sp, #0x10
    7b80:      	ret

0000000000007b84 <_coil.core.Get$slice$get__u32>:
    7b84:      	lsl	x1, x2, #2
    7b88:      	add	x0, x1, x0
    7b8c:      	ldr	w0, [x0]
    7b90:      	ret

0000000000007b94 <_stogir.opcode.operand-code-word>:
    7b94:      	sxtw	x1, w1
    7b98:      	cmp	x1, #0x0
    7b9c:      	b.le	0x7bb0 <_stogir.opcode.operand-code-word+0x1c>
    7ba0:      	cmp	x1, #0x4
    7ba4:      	b.le	0x7bb8 <_stogir.opcode.operand-code-word+0x24>
    7ba8:      	mov	x1, #0x4                ; =4
    7bac:      	b	0x7bc4 <_stogir.opcode.operand-code-word+0x30>
    7bb0:      	movz	x0, #0x0, lsl #48
    7bb4:      	b	0x7be4 <_stogir.opcode.operand-code-word+0x50>
    7bb8:      	sub	x1, x1, #0x1
    7bbc:      	lsr	w1, w1, #0
    7bc0:      	sxtw	x1, w1
    7bc4:      	ubfx	x0, x0, #0, #32
    7bc8:      	lsl	x1, x1, #2
    7bcc:      	lsr	w1, w1, #0
    7bd0:      	ubfx	x1, x1, #0, #32
    7bd4:      	lsr	x0, x0, x1
    7bd8:      	lsr	w0, w0, #0
    7bdc:      	and	x0, x0, #0xf
    7be0:      	lsr	w0, w0, #0
    7be4:      	ret

0000000000007be8 <_inherent$coil.arraylist.ArrayList$at__stogir.node.Node>:
    7be8:      	lsl	x1, x1, #4
    7bec:      	ldr	x0, [x0]
    7bf0:      	add	x0, x1, x0
    7bf4:      	ret

0000000000007bf8 <_coil.core.Len$coil.arraylist.ArrayList$len__stogir.strings.Entry>:
    7bf8:      	ldr	x0, [x0, #0x8]
    7bfc:      	ret

0000000000007c00 <_coil.core.Len$coil.arraylist.ArrayList$len__u8>:
    7c00:      	ldr	x0, [x0, #0x8]
    7c04:      	ret

0000000000007c08 <_inherent$coil.arraylist.ArrayList$slice__u8>:
    7c08:      	sub	sp, sp, #0x10
    7c0c:      	mov	x1, sp
    7c10:      	ldr	x2, [x0]
    7c14:      	ldr	x0, [x0, #0x8]
    7c18:      	str	x2, [x1]
    7c1c:      	str	x0, [x1, #0x8]
    7c20:      	ldr	x0, [sp]
    7c24:      	ldr	x1, [sp, #0x8]
    7c28:      	add	sp, sp, #0x10
    7c2c:      	ret

0000000000007c30 <_coil.slice.subslice__u8>:
    7c30:      	sub	sp, sp, #0x10
    7c34:      	mov	x1, sp
    7c38:      	lsr	x4, x2, #0
    7c3c:      	sub	x2, x3, x2
    7c40:      	add	x0, x4, x0
    7c44:      	str	x0, [x1]
    7c48:      	str	x2, [x1, #0x8]
    7c4c:      	ldr	x0, [sp]
    7c50:      	ldr	x1, [sp, #0x8]
    7c54:      	add	sp, sp, #0x10
    7c58:      	ret

0000000000007c5c <_stogir.floating.operation?>:
    7c5c:      	sxtw	x0, w0
    7c60:      	cmp	x0, #0xe
    7c64:      	b.lt	0x7c78 <_stogir.floating.operation?+0x1c>
    7c68:      	cmp	x0, #0x19
    7c6c:      	b.gt	0x7c78 <_stogir.floating.operation?+0x1c>
    7c70:      	mov	x0, #0x1                ; =1
    7c74:      	b	0x7ca4 <_stogir.floating.operation?+0x48>
    7c78:      	cmp	x0, #0x1f
    7c7c:      	b.eq	0x7ca0 <_stogir.floating.operation?+0x44>
    7c80:      	cmp	x0, #0x20
    7c84:      	b.eq	0x7ca0 <_stogir.floating.operation?+0x44>
    7c88:      	cmp	x0, #0x1a
    7c8c:      	b.lt	0x7cb8 <_stogir.floating.operation?+0x5c>
    7c90:      	cmp	x0, #0x1d
    7c94:      	b.gt	0x7cb8 <_stogir.floating.operation?+0x5c>
    7c98:      	mov	x0, #0x1                ; =1
    7c9c:      	b	0x7cb4 <_stogir.floating.operation?+0x58>
    7ca0:      	mov	x0, #0x1                ; =1
    7ca4:      	ret
    7ca8:      	cmp	x0, #0x3b
    7cac:      	cset	w0, eq
    7cb0:      	ubfx	x0, x0, #0, #8
    7cb4:      	b	0x7ca4 <_stogir.floating.operation?+0x48>
    7cb8:      	cmp	x0, #0x3a
    7cbc:      	b.ne	0x7ca8 <_stogir.floating.operation?+0x4c>
    7cc0:      	mov	x0, #0x1                ; =1
    7cc4:      	b	0x7cb4 <_stogir.floating.operation?+0x58>

0000000000007cc8 <_stogir.types.floating?>:
    7cc8:      	sxtw	x0, w0
    7ccc:      	cmp	x0, #0xc
    7cd0:      	b.ne	0x7cdc <_stogir.types.floating?+0x14>
    7cd4:      	mov	x0, #0x1                ; =1
    7cd8:      	b	0x7ce8 <_stogir.types.floating?+0x20>
    7cdc:      	cmp	x0, #0xd
    7ce0:      	cset	w0, eq
    7ce4:      	ubfx	x0, x0, #0, #8
    7ce8:      	ret

0000000000007cec <_stogir.vector-lanes.validate>:
    7cec:      	sub	sp, sp, #0x50
    7cf0:      	str	x29, [sp]
    7cf4:      	str	x30, [sp, #0x8]
    7cf8:      	mov	x29, sp
    7cfc:      	str	x19, [sp, #0x40]
    7d00:      	sxtw	x1, w1
    7d04:      	lsl	x3, x1, #2
    7d08:      	cmp	x1, #0x0
    7d0c:      	cset	w4, gt
    7d10:      	movz	x16, #0x0, lsl #48
    7d14:      	sub	x5, x16, x1
    7d18:      	sub	x6, x5, #0x1
    7d1c:      	uxtb	w16, w4
    7d20:      	cmp	w16, wzr
    7d24:      	b.eq	0x7d64 <_stogir.vector-lanes.validate+0x78>
    7d28:      	ldr	x5, [x0, #0x8]
    7d2c:      	cmp	x1, x5
    7d30:      	b.ge	0x7db8 <_stogir.vector-lanes.validate+0xcc>
    7d34:      	add	x5, x0, #0x78
    7d38:      	ldr	x5, [x5, #0x8]
    7d3c:      	cmp	x1, x5
    7d40:      	b.ge	0x7edc <_stogir.vector-lanes.validate+0x1f0>
    7d44:      	ldr	x5, [x0, #0x78]
    7d48:      	add	x5, x3, x5
    7d4c:      	ldr	w5, [x5]
    7d50:      	sxtw	x5, w5
    7d54:      	cmp	x5, #0x0
    7d58:      	cset	w5, ge
    7d5c:      	ubfx	x5, x5, #0, #8
    7d60:      	b	0x7ee0 <_stogir.vector-lanes.validate+0x1f4>
    7d64:      	cmp	x1, #0x0
    7d68:      	b.ge	0x7dc0 <_stogir.vector-lanes.validate+0xd4>
    7d6c:      	add	x7, x0, #0x28
    7d70:      	add	x9, x0, #0x50
    7d74:      	ldr	x7, [x7, #0x8]
    7d78:      	ldr	x9, [x9, #0x8]
    7d7c:      	cmp	x7, x9
    7d80:      	b.ne	0x7db0 <_stogir.vector-lanes.validate+0xc4>
    7d84:      	cmp	x5, x7
    7d88:      	b.gt	0x7f20 <_stogir.vector-lanes.validate+0x234>
    7d8c:      	lsl	x5, x6, #2
    7d90:      	ldr	x7, [x0, #0x50]
    7d94:      	add	x5, x5, x7
    7d98:      	ldr	w5, [x5]
    7d9c:      	sxtw	x5, w5
    7da0:      	cmp	x5, #0x0
    7da4:      	cset	w5, gt
    7da8:      	ubfx	x5, x5, #0, #8
    7dac:      	b	0x7f24 <_stogir.vector-lanes.validate+0x238>
    7db0:      	movz	x5, #0x0, lsl #48
    7db4:      	b	0x7dc4 <_stogir.vector-lanes.validate+0xd8>
    7db8:      	movz	x5, #0x0, lsl #48
    7dbc:      	b	0x7dc4 <_stogir.vector-lanes.validate+0xd8>
    7dc0:      	movz	x5, #0x0, lsl #48
    7dc4:      	cmp	x5, #0x0
    7dc8:      	b.eq	0x7e2c <_stogir.vector-lanes.validate+0x140>
    7dcc:      	uxtb	w16, w4
    7dd0:      	cmp	w16, wzr
    7dd4:      	b.eq	0x7dfc <_stogir.vector-lanes.validate+0x110>
    7dd8:      	lsl	x4, x1, #4
    7ddc:      	ldr	x5, [x0]
    7de0:      	add	x4, x4, x5
    7de4:      	ldr	x5, [x4]
    7de8:      	ldr	x4, [x4, #0x8]
    7dec:      	fmov	d31, x4
    7df0:      	mov	x4, x5
    7df4:      	fmov	x5, d31
    7df8:      	b	0x7e1c <_stogir.vector-lanes.validate+0x130>
    7dfc:      	lsl	x4, x6, #4
    7e00:      	ldr	x5, [x0, #0x28]
    7e04:      	add	x4, x4, x5
    7e08:      	ldr	x5, [x4]
    7e0c:      	ldr	x4, [x4, #0x8]
    7e10:      	fmov	d31, x4
    7e14:      	mov	x4, x5
    7e18:      	fmov	x5, d31
    7e1c:      	mov	x6, x5
    7e20:      	mov	x5, x4
    7e24:      	mov	x4, #0x1                ; =1
    7e28:      	b	0x7e38 <_stogir.vector-lanes.validate+0x14c>
    7e2c:      	movz	x4, #0x0, lsl #48
    7e30:      	movz	x5, #0x0, lsl #48
    7e34:      	movz	x6, #0x0, lsl #48
    7e38:      	lsr	w4, w4, #0
    7e3c:      	lsr	x16, x4, #0
    7e40:      	cmp	x16, #0x1
    7e44:      	b.eq	0x7e60 <_stogir.vector-lanes.validate+0x174>
    7e48:      	b.lo	0x7e50 <_stogir.vector-lanes.validate+0x164>
    7e4c:      	b	0x7e64 <_stogir.vector-lanes.validate+0x178>
    7e50:      	cmp	x16, #0x0
    7e54:      	b.eq	0x7e5c <_stogir.vector-lanes.validate+0x170>
    7e58:      	b	0x7e64 <_stogir.vector-lanes.validate+0x178>
    7e5c:      	b	0x7e68 <_stogir.vector-lanes.validate+0x17c>
    7e60:      	b	0x7e88 <_stogir.vector-lanes.validate+0x19c>
    7e64:      	b	0x8004 <_stogir.vector-lanes.validate+0x318>
    7e68:      	adrp	x16, 0x7000 <_stogir.conversion.validate+0x418>
		0000000000007e68:  ARM64_RELOC_PAGE21	l_stogir.410
    7e6c:      	ldr	x16, [x16]
		0000000000007e6c:  ARM64_RELOC_PAGEOFF12	l_stogir.410
    7e70:      	orr	x0, x16, xzr
    7e74:      	mov	x19, x8
    7e78:      	mov	x1, x0
    7e7c:      	mov	x0, #0x1                ; =1
    7e80:      	mov	x2, #0x1f               ; =31
    7e84:      	b	0x7ebc <_stogir.vector-lanes.validate+0x1d0>
    7e88:      	add	x16, sp, #0x10
    7e8c:      	str	x5, [x16]
    7e90:      	add	x16, sp, #0x10
    7e94:      	str	x6, [x16, #0x8]
    7e98:      	cmp	x1, #0x0
    7e9c:      	b.gt	0x7ee4 <_stogir.vector-lanes.validate+0x1f8>
    7ea0:      	mov	x19, x8
    7ea4:      	adrp	x16, 0x7000 <_stogir.conversion.validate+0x418>
		0000000000007ea4:  ARM64_RELOC_PAGE21	l_stogir.411
    7ea8:      	ldr	x16, [x16]
		0000000000007ea8:  ARM64_RELOC_PAGEOFF12	l_stogir.411
    7eac:      	orr	x0, x16, xzr
    7eb0:      	mov	x1, x0
    7eb4:      	mov	x0, #0x1                ; =1
    7eb8:      	mov	x2, #0x25               ; =37
    7ebc:      	str	x0, [x19]
    7ec0:      	str	x1, [x19, #0x8]
    7ec4:      	str	x2, [x19, #0x10]
    7ec8:      	ldr	x19, [sp, #0x40]
    7ecc:      	ldr	x29, [sp]
    7ed0:      	ldr	x30, [sp, #0x8]
    7ed4:      	add	sp, sp, #0x50
    7ed8:      	ret
    7edc:      	movz	x5, #0x0, lsl #48
    7ee0:      	b	0x7dbc <_stogir.vector-lanes.validate+0xd0>
    7ee4:      	uxtb	w5, w5
    7ee8:      	orr	x1, x5, xzr
    7eec:      	cmp	x1, #0x3d
    7ef0:      	b.lt	0x800c <_stogir.vector-lanes.validate+0x320>
    7ef4:      	cmp	x1, #0x3f
    7ef8:      	b.gt	0x8014 <_stogir.vector-lanes.validate+0x328>
    7efc:      	cmp	x1, #0x3e
    7f00:      	cset	w4, eq
    7f04:      	ldr	x6, [x0, #0x78]
    7f08:      	add	x3, x3, x6
    7f0c:      	ldr	w3, [x3]
    7f10:      	cmp	x1, #0x3d
    7f14:      	b.ne	0x7f94 <_stogir.vector-lanes.validate+0x2a8>
    7f18:      	mov	x6, #0x2                ; =2
    7f1c:      	b	0x7fa8 <_stogir.vector-lanes.validate+0x2bc>
    7f20:      	movz	x5, #0x0, lsl #48
    7f24:      	b	0x7db4 <_stogir.vector-lanes.validate+0xc8>
    7f28:      	movz	x4, #0x0, lsl #48
    7f2c:      	lsr	w2, w2, #0
    7f30:      	lsr	w6, w6, #0
    7f34:      	lsr	w1, w1, #0
    7f38:      	lsr	w5, w5, #0
    7f3c:      	lsr	w4, w4, #0
    7f40:      	ubfx	x3, x3, #8, #8
    7f44:      	lsr	w3, w3, #0
    7f48:      	mov	x19, x8
    7f4c:      	add	x8, sp, #0x20
    7f50:      	fmov	s31, w1
    7f54:      	mov	w1, w5
    7f58:      	fmov	w5, s31
    7f5c:      	fmov	s31, w2
    7f60:      	mov	w2, w3
    7f64:      	fmov	w3, s31
    7f68:      	fmov	s31, w4
    7f6c:      	mov	w4, w6
    7f70:      	fmov	w6, s31
    7f74:      	bl	0x7f74 <_stogir.vector-lanes.validate+0x288>
		0000000000007f74:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.operands
    7f78:      	add	x16, sp, #0x20
    7f7c:      	ldr	x0, [x16]
    7f80:      	add	x16, sp, #0x20
    7f84:      	ldr	x1, [x16, #0x8]
    7f88:      	add	x16, sp, #0x20
    7f8c:      	ldr	x2, [x16, #0x10]
    7f90:      	b	0x7ebc <_stogir.vector-lanes.validate+0x1d0>
    7f94:      	uxtb	w16, w4
    7f98:      	cmp	w16, wzr
    7f9c:      	mov	x16, #0x3               ; =3
    7fa0:      	mov	x17, #0x1               ; =1
    7fa4:      	csel	x6, x16, x17, ne
    7fa8:      	sxtw	x3, w3
    7fac:      	lsr	w6, w6, #0
    7fb0:      	sxtw	x6, w6
    7fb4:      	cmp	x3, x6
    7fb8:      	b.ne	0x801c <_stogir.vector-lanes.validate+0x330>
    7fbc:      	add	x16, sp, #0x10
    7fc0:      	ldr	w3, [x16]
    7fc4:      	add	x16, sp, #0x10
    7fc8:      	ldr	w6, [x16, #0x4]
    7fcc:      	cmp	x1, #0x3f
    7fd0:      	b.ne	0x7fdc <_stogir.vector-lanes.validate+0x2f0>
    7fd4:      	movz	x1, #0x0, lsl #48
    7fd8:      	b	0x7fe8 <_stogir.vector-lanes.validate+0x2fc>
    7fdc:      	add	x16, sp, #0x10
    7fe0:      	ldr	w1, [x16, #0x8]
    7fe4:      	sxtw	x1, w1
    7fe8:      	uxtb	w16, w4
    7fec:      	cmp	w16, wzr
    7ff0:      	b.eq	0x7f28 <_stogir.vector-lanes.validate+0x23c>
    7ff4:      	add	x16, sp, #0x10
    7ff8:      	ldr	w4, [x16, #0xc]
    7ffc:      	sxtw	x4, w4
    8000:      	b	0x7f2c <_stogir.vector-lanes.validate+0x240>
    8004:      	brk	#0
    8008:      	b	0x8004 <_stogir.vector-lanes.validate+0x318>
    800c:      	mov	x19, x8
    8010:      	b	0x7ea4 <_stogir.vector-lanes.validate+0x1b8>
    8014:      	mov	x19, x8
    8018:      	b	0x7ea4 <_stogir.vector-lanes.validate+0x1b8>
    801c:      	mov	x19, x8
    8020:      	b	0x7ea4 <_stogir.vector-lanes.validate+0x1b8>

0000000000008024 <_stogir.vector-comparison.node?>:
    8024:      	sxtw	x1, w1
    8028:      	cmp	x1, #0x0
    802c:      	cset	w2, gt
    8030:      	movz	x16, #0x0, lsl #48
    8034:      	sub	x3, x16, x1
    8038:      	sub	x4, x3, #0x1
    803c:      	uxtb	w16, w2
    8040:      	cmp	w16, wzr
    8044:      	b.eq	0x8088 <_stogir.vector-comparison.node?+0x64>
    8048:      	ldr	x3, [x0, #0x8]
    804c:      	cmp	x1, x3
    8050:      	b.ge	0x80dc <_stogir.vector-comparison.node?+0xb8>
    8054:      	add	x3, x0, #0x78
    8058:      	ldr	x3, [x3, #0x8]
    805c:      	cmp	x1, x3
    8060:      	b.ge	0x81c4 <_stogir.vector-comparison.node?+0x1a0>
    8064:      	lsl	x3, x1, #2
    8068:      	ldr	x5, [x0, #0x78]
    806c:      	add	x3, x3, x5
    8070:      	ldr	w3, [x3]
    8074:      	sxtw	x3, w3
    8078:      	cmp	x3, #0x0
    807c:      	cset	w3, ge
    8080:      	ubfx	x3, x3, #0, #8
    8084:      	b	0x81c8 <_stogir.vector-comparison.node?+0x1a4>
    8088:      	cmp	x1, #0x0
    808c:      	b.ge	0x80e4 <_stogir.vector-comparison.node?+0xc0>
    8090:      	add	x5, x0, #0x28
    8094:      	add	x6, x0, #0x50
    8098:      	ldr	x5, [x5, #0x8]
    809c:      	ldr	x6, [x6, #0x8]
    80a0:      	cmp	x5, x6
    80a4:      	b.ne	0x80d4 <_stogir.vector-comparison.node?+0xb0>
    80a8:      	cmp	x3, x5
    80ac:      	b.gt	0x81cc <_stogir.vector-comparison.node?+0x1a8>
    80b0:      	lsl	x3, x4, #2
    80b4:      	ldr	x5, [x0, #0x50]
    80b8:      	add	x3, x3, x5
    80bc:      	ldr	w3, [x3]
    80c0:      	sxtw	x3, w3
    80c4:      	cmp	x3, #0x0
    80c8:      	cset	w3, gt
    80cc:      	ubfx	x3, x3, #0, #8
    80d0:      	b	0x81d0 <_stogir.vector-comparison.node?+0x1ac>
    80d4:      	movz	x3, #0x0, lsl #48
    80d8:      	b	0x80e8 <_stogir.vector-comparison.node?+0xc4>
    80dc:      	movz	x3, #0x0, lsl #48
    80e0:      	b	0x80e8 <_stogir.vector-comparison.node?+0xc4>
    80e4:      	movz	x3, #0x0, lsl #48
    80e8:      	cmp	x3, #0x0
    80ec:      	b.eq	0x812c <_stogir.vector-comparison.node?+0x108>
    80f0:      	uxtb	w16, w2
    80f4:      	cmp	w16, wzr
    80f8:      	b.eq	0x8110 <_stogir.vector-comparison.node?+0xec>
    80fc:      	lsl	x1, x1, #4
    8100:      	ldr	x0, [x0]
    8104:      	add	x0, x1, x0
    8108:      	ldr	x0, [x0]
    810c:      	b	0x8120 <_stogir.vector-comparison.node?+0xfc>
    8110:      	lsl	x1, x4, #4
    8114:      	ldr	x0, [x0, #0x28]
    8118:      	add	x0, x1, x0
    811c:      	ldr	x0, [x0]
    8120:      	mov	x1, x0
    8124:      	mov	x0, #0x1                ; =1
    8128:      	b	0x8134 <_stogir.vector-comparison.node?+0x110>
    812c:      	movz	x0, #0x0, lsl #48
    8130:      	movz	x1, #0x0, lsl #48
    8134:      	lsr	w0, w0, #0
    8138:      	lsr	x16, x0, #0
    813c:      	cmp	x16, #0x1
    8140:      	b.eq	0x815c <_stogir.vector-comparison.node?+0x138>
    8144:      	b.lo	0x814c <_stogir.vector-comparison.node?+0x128>
    8148:      	b	0x8160 <_stogir.vector-comparison.node?+0x13c>
    814c:      	cmp	x16, #0x0
    8150:      	b.eq	0x8158 <_stogir.vector-comparison.node?+0x134>
    8154:      	b	0x8160 <_stogir.vector-comparison.node?+0x13c>
    8158:      	b	0x8164 <_stogir.vector-comparison.node?+0x140>
    815c:      	b	0x8174 <_stogir.vector-comparison.node?+0x150>
    8160:      	b	0x81ec <_stogir.vector-comparison.node?+0x1c8>
    8164:      	movz	x0, #0x0, lsl #48
    8168:      	b	0x8170 <_stogir.vector-comparison.node?+0x14c>
    816c:      	movz	x0, #0x0, lsl #48
    8170:      	ret
    8174:      	uxtb	w0, w1
    8178:      	cmp	x0, #0xe
    817c:      	b.lt	0x816c <_stogir.vector-comparison.node?+0x148>
    8180:      	cmp	x0, #0x19
    8184:      	b.gt	0x816c <_stogir.vector-comparison.node?+0x148>
    8188:      	lsr	w1, w1, #0
    818c:      	ubfx	x0, x1, #8, #8
    8190:      	cmp	x0, #0xf
    8194:      	b.le	0x81d4 <_stogir.vector-comparison.node?+0x1b0>
    8198:      	cmp	x0, #0x80
    819c:      	b.ge	0x81dc <_stogir.vector-comparison.node?+0x1b8>
    81a0:      	and	x0, x0, #0xf
    81a4:      	lsr	w0, w0, #0
    81a8:      	sxtw	x0, w0
    81ac:      	cmp	x0, #0x1
    81b0:      	b.lt	0x81e4 <_stogir.vector-comparison.node?+0x1c0>
    81b4:      	cmp	x0, #0xd
    81b8:      	cset	w0, le
    81bc:      	ubfx	x0, x0, #0, #8
    81c0:      	b	0x81e8 <_stogir.vector-comparison.node?+0x1c4>
    81c4:      	movz	x3, #0x0, lsl #48
    81c8:      	b	0x80e0 <_stogir.vector-comparison.node?+0xbc>
    81cc:      	movz	x3, #0x0, lsl #48
    81d0:      	b	0x80d8 <_stogir.vector-comparison.node?+0xb4>
    81d4:      	movz	x0, #0x0, lsl #48
    81d8:      	b	0x8170 <_stogir.vector-comparison.node?+0x14c>
    81dc:      	movz	x0, #0x0, lsl #48
    81e0:      	b	0x81d8 <_stogir.vector-comparison.node?+0x1b4>
    81e4:      	movz	x0, #0x0, lsl #48
    81e8:      	b	0x81e0 <_stogir.vector-comparison.node?+0x1bc>
    81ec:      	brk	#0
    81f0:      	b	0x81ec <_stogir.vector-comparison.node?+0x1c8>

00000000000081f4 <_stogir.vector-comparison.validate>:
    81f4:      	sub	sp, sp, #0x50
    81f8:      	str	x29, [sp]
    81fc:      	str	x30, [sp, #0x8]
    8200:      	mov	x29, sp
    8204:      	str	x19, [sp, #0x40]
    8208:      	sxtw	x1, w1
    820c:      	lsl	x3, x1, #2
    8210:      	cmp	x1, #0x0
    8214:      	cset	w4, gt
    8218:      	movz	x16, #0x0, lsl #48
    821c:      	sub	x5, x16, x1
    8220:      	sub	x6, x5, #0x1
    8224:      	uxtb	w16, w4
    8228:      	cmp	w16, wzr
    822c:      	b.eq	0x826c <_stogir.vector-comparison.validate+0x78>
    8230:      	ldr	x5, [x0, #0x8]
    8234:      	cmp	x1, x5
    8238:      	b.ge	0x82c0 <_stogir.vector-comparison.validate+0xcc>
    823c:      	add	x5, x0, #0x78
    8240:      	ldr	x5, [x5, #0x8]
    8244:      	cmp	x1, x5
    8248:      	b.ge	0x83e4 <_stogir.vector-comparison.validate+0x1f0>
    824c:      	ldr	x5, [x0, #0x78]
    8250:      	add	x5, x3, x5
    8254:      	ldr	w5, [x5]
    8258:      	sxtw	x5, w5
    825c:      	cmp	x5, #0x0
    8260:      	cset	w5, ge
    8264:      	ubfx	x5, x5, #0, #8
    8268:      	b	0x83e8 <_stogir.vector-comparison.validate+0x1f4>
    826c:      	cmp	x1, #0x0
    8270:      	b.ge	0x82c8 <_stogir.vector-comparison.validate+0xd4>
    8274:      	add	x7, x0, #0x28
    8278:      	add	x9, x0, #0x50
    827c:      	ldr	x7, [x7, #0x8]
    8280:      	ldr	x9, [x9, #0x8]
    8284:      	cmp	x7, x9
    8288:      	b.ne	0x82b8 <_stogir.vector-comparison.validate+0xc4>
    828c:      	cmp	x5, x7
    8290:      	b.gt	0x8438 <_stogir.vector-comparison.validate+0x244>
    8294:      	lsl	x5, x6, #2
    8298:      	ldr	x7, [x0, #0x50]
    829c:      	add	x5, x5, x7
    82a0:      	ldr	w5, [x5]
    82a4:      	sxtw	x5, w5
    82a8:      	cmp	x5, #0x0
    82ac:      	cset	w5, gt
    82b0:      	ubfx	x5, x5, #0, #8
    82b4:      	b	0x843c <_stogir.vector-comparison.validate+0x248>
    82b8:      	movz	x5, #0x0, lsl #48
    82bc:      	b	0x82cc <_stogir.vector-comparison.validate+0xd8>
    82c0:      	movz	x5, #0x0, lsl #48
    82c4:      	b	0x82cc <_stogir.vector-comparison.validate+0xd8>
    82c8:      	movz	x5, #0x0, lsl #48
    82cc:      	lsl	x7, x1, #4
    82d0:      	cmp	x5, #0x0
    82d4:      	b.eq	0x8334 <_stogir.vector-comparison.validate+0x140>
    82d8:      	uxtb	w16, w4
    82dc:      	cmp	w16, wzr
    82e0:      	b.eq	0x8304 <_stogir.vector-comparison.validate+0x110>
    82e4:      	ldr	x4, [x0]
    82e8:      	add	x4, x7, x4
    82ec:      	ldr	x5, [x4]
    82f0:      	ldr	x4, [x4, #0x8]
    82f4:      	fmov	d31, x4
    82f8:      	mov	x4, x5
    82fc:      	fmov	x5, d31
    8300:      	b	0x8324 <_stogir.vector-comparison.validate+0x130>
    8304:      	lsl	x4, x6, #4
    8308:      	ldr	x5, [x0, #0x28]
    830c:      	add	x4, x4, x5
    8310:      	ldr	x5, [x4]
    8314:      	ldr	x4, [x4, #0x8]
    8318:      	fmov	d31, x4
    831c:      	mov	x4, x5
    8320:      	fmov	x5, d31
    8324:      	mov	x6, x5
    8328:      	mov	x5, x4
    832c:      	mov	x4, #0x1                ; =1
    8330:      	b	0x8340 <_stogir.vector-comparison.validate+0x14c>
    8334:      	movz	x4, #0x0, lsl #48
    8338:      	movz	x5, #0x0, lsl #48
    833c:      	movz	x6, #0x0, lsl #48
    8340:      	lsr	w4, w4, #0
    8344:      	lsr	x16, x4, #0
    8348:      	cmp	x16, #0x1
    834c:      	b.eq	0x8368 <_stogir.vector-comparison.validate+0x174>
    8350:      	b.lo	0x8358 <_stogir.vector-comparison.validate+0x164>
    8354:      	b	0x836c <_stogir.vector-comparison.validate+0x178>
    8358:      	cmp	x16, #0x0
    835c:      	b.eq	0x8364 <_stogir.vector-comparison.validate+0x170>
    8360:      	b	0x836c <_stogir.vector-comparison.validate+0x178>
    8364:      	b	0x8370 <_stogir.vector-comparison.validate+0x17c>
    8368:      	b	0x83ac <_stogir.vector-comparison.validate+0x1b8>
    836c:      	b	0x854c <_stogir.vector-comparison.validate+0x358>
    8370:      	adrp	x16, 0x8000 <_stogir.vector-lanes.validate+0x314>
		0000000000008370:  ARM64_RELOC_PAGE21	l_stogir.412
    8374:      	ldr	x16, [x16]
		0000000000008374:  ARM64_RELOC_PAGEOFF12	l_stogir.412
    8378:      	orr	x0, x16, xzr
    837c:      	mov	x19, x8
    8380:      	mov	x1, x0
    8384:      	mov	x0, #0x1                ; =1
    8388:      	mov	x2, #0x25               ; =37
    838c:      	str	x0, [x19]
    8390:      	str	x1, [x19, #0x8]
    8394:      	str	x2, [x19, #0x10]
    8398:      	ldr	x19, [sp, #0x40]
    839c:      	ldr	x29, [sp]
    83a0:      	ldr	x30, [sp, #0x8]
    83a4:      	add	sp, sp, #0x50
    83a8:      	ret
    83ac:      	add	x16, sp, #0x10
    83b0:      	str	x5, [x16]
    83b4:      	add	x16, sp, #0x10
    83b8:      	str	x6, [x16, #0x8]
    83bc:      	cmp	x1, #0x0
    83c0:      	b.gt	0x83ec <_stogir.vector-comparison.validate+0x1f8>
    83c4:      	mov	x19, x8
    83c8:      	adrp	x16, 0x8000 <_stogir.vector-lanes.validate+0x314>
		00000000000083c8:  ARM64_RELOC_PAGE21	l_stogir.413
    83cc:      	ldr	x16, [x16]
		00000000000083cc:  ARM64_RELOC_PAGEOFF12	l_stogir.413
    83d0:      	orr	x0, x16, xzr
    83d4:      	mov	x1, x0
    83d8:      	mov	x0, #0x1                ; =1
    83dc:      	mov	x2, #0x2b               ; =43
    83e0:      	b	0x838c <_stogir.vector-comparison.validate+0x198>
    83e4:      	movz	x5, #0x0, lsl #48
    83e8:      	b	0x82c4 <_stogir.vector-comparison.validate+0xd0>
    83ec:      	ldr	x4, [x0, #0x8]
    83f0:      	cmp	x1, x4
    83f4:      	b.ge	0x8440 <_stogir.vector-comparison.validate+0x24c>
    83f8:      	add	x4, x0, #0x78
    83fc:      	ldr	x4, [x4, #0x8]
    8400:      	cmp	x1, x4
    8404:      	b.ge	0x8440 <_stogir.vector-comparison.validate+0x24c>
    8408:      	ldr	x1, [x0, #0x78]
    840c:      	add	x1, x3, x1
    8410:      	ldr	w1, [x1]
    8414:      	sxtw	x1, w1
    8418:      	cmp	x1, #0x0
    841c:      	b.lt	0x8440 <_stogir.vector-comparison.validate+0x24c>
    8420:      	ldr	x1, [x0]
    8424:      	add	x1, x7, x1
    8428:      	ldr	x1, [x1]
    842c:      	mov	x4, x1
    8430:      	mov	x1, #0x1                ; =1
    8434:      	b	0x8448 <_stogir.vector-comparison.validate+0x254>
    8438:      	movz	x5, #0x0, lsl #48
    843c:      	b	0x82bc <_stogir.vector-comparison.validate+0xc8>
    8440:      	movz	x1, #0x0, lsl #48
    8444:      	movz	x4, #0x0, lsl #48
    8448:      	lsr	w1, w1, #0
    844c:      	lsr	x16, x1, #0
    8450:      	cmp	x16, #0x1
    8454:      	b.eq	0x8470 <_stogir.vector-comparison.validate+0x27c>
    8458:      	b.lo	0x8460 <_stogir.vector-comparison.validate+0x26c>
    845c:      	b	0x8474 <_stogir.vector-comparison.validate+0x280>
    8460:      	cmp	x16, #0x0
    8464:      	b.eq	0x846c <_stogir.vector-comparison.validate+0x278>
    8468:      	b	0x8474 <_stogir.vector-comparison.validate+0x280>
    846c:      	b	0x8478 <_stogir.vector-comparison.validate+0x284>
    8470:      	b	0x8480 <_stogir.vector-comparison.validate+0x28c>
    8474:      	b	0x8554 <_stogir.vector-comparison.validate+0x360>
    8478:      	mov	x19, x8
    847c:      	b	0x83c8 <_stogir.vector-comparison.validate+0x1d4>
    8480:      	uxtb	w1, w4
    8484:      	cmp	x1, #0xe
    8488:      	b.lt	0x855c <_stogir.vector-comparison.validate+0x368>
    848c:      	cmp	x1, #0x19
    8490:      	b.gt	0x8564 <_stogir.vector-comparison.validate+0x370>
    8494:      	lsr	w4, w4, #0
    8498:      	ubfx	x1, x4, #8, #8
    849c:      	cmp	x1, #0xf
    84a0:      	b.le	0x856c <_stogir.vector-comparison.validate+0x378>
    84a4:      	cmp	x1, #0x80
    84a8:      	b.ge	0x8574 <_stogir.vector-comparison.validate+0x380>
    84ac:      	and	x1, x1, #0xf
    84b0:      	lsr	w1, w1, #0
    84b4:      	sxtw	x1, w1
    84b8:      	cmp	x1, #0x1
    84bc:      	b.lt	0x857c <_stogir.vector-comparison.validate+0x388>
    84c0:      	cmp	x1, #0xd
    84c4:      	b.gt	0x8584 <_stogir.vector-comparison.validate+0x390>
    84c8:      	ldr	x1, [x0, #0x78]
    84cc:      	add	x1, x3, x1
    84d0:      	ldr	w1, [x1]
    84d4:      	sxtw	x1, w1
    84d8:      	cmp	x1, #0x2
    84dc:      	b.ne	0x858c <_stogir.vector-comparison.validate+0x398>
    84e0:      	lsr	w2, w2, #0
    84e4:      	add	x16, sp, #0x10
    84e8:      	ldr	w1, [x16]
    84ec:      	uxtb	w3, w1
    84f0:      	add	x16, sp, #0x10
    84f4:      	ldr	w4, [x16, #0x4]
    84f8:      	lsr	w3, w3, #0
    84fc:      	ubfx	x1, x1, #8, #8
    8500:      	add	x16, sp, #0x10
    8504:      	ldr	w5, [x16, #0x8]
    8508:      	lsr	w4, w4, #0
    850c:      	lsr	w5, w5, #0
    8510:      	lsr	w1, w1, #0
    8514:      	mov	x19, x8
    8518:      	add	x8, sp, #0x20
    851c:      	fmov	s31, w1
    8520:      	mov	w1, w3
    8524:      	mov	w3, w2
    8528:      	fmov	w2, s31
    852c:      	bl	0x852c <_stogir.vector-comparison.validate+0x338>
		000000000000852c:  ARM64_RELOC_BRANCH26	_stogir.vector-comparison.operands
    8530:      	add	x16, sp, #0x20
    8534:      	ldr	x0, [x16]
    8538:      	add	x16, sp, #0x20
    853c:      	ldr	x1, [x16, #0x8]
    8540:      	add	x16, sp, #0x20
    8544:      	ldr	x2, [x16, #0x10]
    8548:      	b	0x83e0 <_stogir.vector-comparison.validate+0x1ec>
    854c:      	brk	#0
    8550:      	b	0x854c <_stogir.vector-comparison.validate+0x358>
    8554:      	brk	#0
    8558:      	b	0x8554 <_stogir.vector-comparison.validate+0x360>
    855c:      	mov	x19, x8
    8560:      	b	0x83c8 <_stogir.vector-comparison.validate+0x1d4>
    8564:      	mov	x19, x8
    8568:      	b	0x83c8 <_stogir.vector-comparison.validate+0x1d4>
    856c:      	mov	x19, x8
    8570:      	b	0x83c8 <_stogir.vector-comparison.validate+0x1d4>
    8574:      	mov	x19, x8
    8578:      	b	0x83c8 <_stogir.vector-comparison.validate+0x1d4>
    857c:      	mov	x19, x8
    8580:      	b	0x83c8 <_stogir.vector-comparison.validate+0x1d4>
    8584:      	mov	x19, x8
    8588:      	b	0x83c8 <_stogir.vector-comparison.validate+0x1d4>
    858c:      	mov	x19, x8
    8590:      	b	0x83c8 <_stogir.vector-comparison.validate+0x1d4>

0000000000008594 <_stogir.vector-arithmetic.node?>:
    8594:      	sxtw	x1, w1
    8598:      	cmp	x1, #0x0
    859c:      	cset	w2, gt
    85a0:      	movz	x16, #0x0, lsl #48
    85a4:      	sub	x3, x16, x1
    85a8:      	sub	x4, x3, #0x1
    85ac:      	uxtb	w16, w2
    85b0:      	cmp	w16, wzr
    85b4:      	b.eq	0x85f8 <_stogir.vector-arithmetic.node?+0x64>
    85b8:      	ldr	x3, [x0, #0x8]
    85bc:      	cmp	x1, x3
    85c0:      	b.ge	0x864c <_stogir.vector-arithmetic.node?+0xb8>
    85c4:      	add	x3, x0, #0x78
    85c8:      	ldr	x3, [x3, #0x8]
    85cc:      	cmp	x1, x3
    85d0:      	b.ge	0x877c <_stogir.vector-arithmetic.node?+0x1e8>
    85d4:      	lsl	x3, x1, #2
    85d8:      	ldr	x5, [x0, #0x78]
    85dc:      	add	x3, x3, x5
    85e0:      	ldr	w3, [x3]
    85e4:      	sxtw	x3, w3
    85e8:      	cmp	x3, #0x0
    85ec:      	cset	w3, ge
    85f0:      	ubfx	x3, x3, #0, #8
    85f4:      	b	0x8780 <_stogir.vector-arithmetic.node?+0x1ec>
    85f8:      	cmp	x1, #0x0
    85fc:      	b.ge	0x8654 <_stogir.vector-arithmetic.node?+0xc0>
    8600:      	add	x5, x0, #0x28
    8604:      	add	x6, x0, #0x50
    8608:      	ldr	x5, [x5, #0x8]
    860c:      	ldr	x6, [x6, #0x8]
    8610:      	cmp	x5, x6
    8614:      	b.ne	0x8644 <_stogir.vector-arithmetic.node?+0xb0>
    8618:      	cmp	x3, x5
    861c:      	b.gt	0x878c <_stogir.vector-arithmetic.node?+0x1f8>
    8620:      	lsl	x3, x4, #2
    8624:      	ldr	x5, [x0, #0x50]
    8628:      	add	x3, x3, x5
    862c:      	ldr	w3, [x3]
    8630:      	sxtw	x3, w3
    8634:      	cmp	x3, #0x0
    8638:      	cset	w3, gt
    863c:      	ubfx	x3, x3, #0, #8
    8640:      	b	0x8790 <_stogir.vector-arithmetic.node?+0x1fc>
    8644:      	movz	x3, #0x0, lsl #48
    8648:      	b	0x8658 <_stogir.vector-arithmetic.node?+0xc4>
    864c:      	movz	x3, #0x0, lsl #48
    8650:      	b	0x8658 <_stogir.vector-arithmetic.node?+0xc4>
    8654:      	movz	x3, #0x0, lsl #48
    8658:      	cmp	x3, #0x0
    865c:      	b.eq	0x869c <_stogir.vector-arithmetic.node?+0x108>
    8660:      	uxtb	w16, w2
    8664:      	cmp	w16, wzr
    8668:      	b.eq	0x8680 <_stogir.vector-arithmetic.node?+0xec>
    866c:      	lsl	x1, x1, #4
    8670:      	ldr	x0, [x0]
    8674:      	add	x0, x1, x0
    8678:      	ldr	x0, [x0]
    867c:      	b	0x8690 <_stogir.vector-arithmetic.node?+0xfc>
    8680:      	lsl	x1, x4, #4
    8684:      	ldr	x0, [x0, #0x28]
    8688:      	add	x0, x1, x0
    868c:      	ldr	x0, [x0]
    8690:      	mov	x1, x0
    8694:      	mov	x0, #0x1                ; =1
    8698:      	b	0x86a4 <_stogir.vector-arithmetic.node?+0x110>
    869c:      	movz	x0, #0x0, lsl #48
    86a0:      	movz	x1, #0x0, lsl #48
    86a4:      	lsr	w0, w0, #0
    86a8:      	lsr	x16, x0, #0
    86ac:      	cmp	x16, #0x1
    86b0:      	b.eq	0x86cc <_stogir.vector-arithmetic.node?+0x138>
    86b4:      	b.lo	0x86bc <_stogir.vector-arithmetic.node?+0x128>
    86b8:      	b	0x86d0 <_stogir.vector-arithmetic.node?+0x13c>
    86bc:      	cmp	x16, #0x0
    86c0:      	b.eq	0x86c8 <_stogir.vector-arithmetic.node?+0x134>
    86c4:      	b	0x86d0 <_stogir.vector-arithmetic.node?+0x13c>
    86c8:      	b	0x86d4 <_stogir.vector-arithmetic.node?+0x140>
    86cc:      	b	0x86e4 <_stogir.vector-arithmetic.node?+0x150>
    86d0:      	b	0x879c <_stogir.vector-arithmetic.node?+0x208>
    86d4:      	movz	x0, #0x0, lsl #48
    86d8:      	b	0x86e0 <_stogir.vector-arithmetic.node?+0x14c>
    86dc:      	movz	x0, #0x0, lsl #48
    86e0:      	ret
    86e4:      	uxtb	w0, w1
    86e8:      	cmp	x0, #0x1f
    86ec:      	b.eq	0x8740 <_stogir.vector-arithmetic.node?+0x1ac>
    86f0:      	cmp	x0, #0x20
    86f4:      	b.eq	0x8740 <_stogir.vector-arithmetic.node?+0x1ac>
    86f8:      	cmp	x0, #0x2d
    86fc:      	b.eq	0x8740 <_stogir.vector-arithmetic.node?+0x1ac>
    8700:      	cmp	x0, #0x36
    8704:      	b.eq	0x8740 <_stogir.vector-arithmetic.node?+0x1ac>
    8708:      	cmp	x0, #0x37
    870c:      	b.eq	0x8740 <_stogir.vector-arithmetic.node?+0x1ac>
    8710:      	cmp	x0, #0x38
    8714:      	b.eq	0x8740 <_stogir.vector-arithmetic.node?+0x1ac>
    8718:      	cmp	x0, #0x39
    871c:      	b.eq	0x8740 <_stogir.vector-arithmetic.node?+0x1ac>
    8720:      	cmp	x0, #0x3a
    8724:      	b.eq	0x8740 <_stogir.vector-arithmetic.node?+0x1ac>
    8728:      	cmp	x0, #0x3b
    872c:      	b.eq	0x8740 <_stogir.vector-arithmetic.node?+0x1ac>
    8730:      	cmp	x0, #0x31
    8734:      	b.lt	0x87a4 <_stogir.vector-arithmetic.node?+0x210>
    8738:      	cmp	x0, #0x35
    873c:      	b.gt	0x87a4 <_stogir.vector-arithmetic.node?+0x210>
    8740:      	lsr	w1, w1, #0
    8744:      	ubfx	x0, x1, #8, #8
    8748:      	cmp	x0, #0xf
    874c:      	b.le	0x86dc <_stogir.vector-arithmetic.node?+0x148>
    8750:      	cmp	x0, #0x80
    8754:      	b.ge	0x8784 <_stogir.vector-arithmetic.node?+0x1f0>
    8758:      	and	x0, x0, #0xf
    875c:      	lsr	w0, w0, #0
    8760:      	sxtw	x0, w0
    8764:      	cmp	x0, #0x1
    8768:      	b.lt	0x8794 <_stogir.vector-arithmetic.node?+0x200>
    876c:      	cmp	x0, #0xd
    8770:      	cset	w0, le
    8774:      	ubfx	x0, x0, #0, #8
    8778:      	b	0x8798 <_stogir.vector-arithmetic.node?+0x204>
    877c:      	movz	x3, #0x0, lsl #48
    8780:      	b	0x8650 <_stogir.vector-arithmetic.node?+0xbc>
    8784:      	movz	x0, #0x0, lsl #48
    8788:      	b	0x86e0 <_stogir.vector-arithmetic.node?+0x14c>
    878c:      	movz	x3, #0x0, lsl #48
    8790:      	b	0x8648 <_stogir.vector-arithmetic.node?+0xb4>
    8794:      	movz	x0, #0x0, lsl #48
    8798:      	b	0x8788 <_stogir.vector-arithmetic.node?+0x1f4>
    879c:      	brk	#0
    87a0:      	b	0x879c <_stogir.vector-arithmetic.node?+0x208>
    87a4:      	cmp	x0, #0x1a
    87a8:      	b.eq	0x8740 <_stogir.vector-arithmetic.node?+0x1ac>
    87ac:      	cmp	x0, #0x1b
    87b0:      	b.eq	0x8740 <_stogir.vector-arithmetic.node?+0x1ac>
    87b4:      	cmp	x0, #0x1c
    87b8:      	b.eq	0x8740 <_stogir.vector-arithmetic.node?+0x1ac>
    87bc:      	cmp	x0, #0x1d
    87c0:      	b.eq	0x8740 <_stogir.vector-arithmetic.node?+0x1ac>
    87c4:      	cmp	x0, #0x1e
    87c8:      	b.eq	0x8740 <_stogir.vector-arithmetic.node?+0x1ac>
    87cc:      	cmp	x0, #0x2e
    87d0:      	b.eq	0x8740 <_stogir.vector-arithmetic.node?+0x1ac>
    87d4:      	cmp	x0, #0x2f
    87d8:      	b.eq	0x8740 <_stogir.vector-arithmetic.node?+0x1ac>
    87dc:      	cmp	x0, #0x30
    87e0:      	b.eq	0x8740 <_stogir.vector-arithmetic.node?+0x1ac>
    87e4:      	movz	x0, #0x0, lsl #48
    87e8:      	b	0x86e0 <_stogir.vector-arithmetic.node?+0x14c>

00000000000087ec <_stogir.vector-arithmetic.validate>:
    87ec:      	sub	sp, sp, #0x60
    87f0:      	str	x29, [sp]
    87f4:      	str	x30, [sp, #0x8]
    87f8:      	mov	x29, sp
    87fc:      	str	x19, [sp, #0x40]
    8800:      	str	x20, [sp, #0x48]
    8804:      	str	x21, [sp, #0x50]
    8808:      	str	x22, [sp, #0x58]
    880c:      	sxtw	x2, w1
    8810:      	lsl	x19, x2, #2
    8814:      	cmp	x2, #0x0
    8818:      	cset	w3, gt
    881c:      	movz	x16, #0x0, lsl #48
    8820:      	sub	x4, x16, x2
    8824:      	sub	x5, x4, #0x1
    8828:      	uxtb	w16, w3
    882c:      	cmp	w16, wzr
    8830:      	b.eq	0x8870 <_stogir.vector-arithmetic.validate+0x84>
    8834:      	ldr	x4, [x0, #0x8]
    8838:      	cmp	x2, x4
    883c:      	b.ge	0x88c4 <_stogir.vector-arithmetic.validate+0xd8>
    8840:      	add	x4, x0, #0x78
    8844:      	ldr	x4, [x4, #0x8]
    8848:      	cmp	x2, x4
    884c:      	b.ge	0x89f0 <_stogir.vector-arithmetic.validate+0x204>
    8850:      	ldr	x4, [x0, #0x78]
    8854:      	add	x4, x19, x4
    8858:      	ldr	w4, [x4]
    885c:      	sxtw	x4, w4
    8860:      	cmp	x4, #0x0
    8864:      	cset	w4, ge
    8868:      	ubfx	x4, x4, #0, #8
    886c:      	b	0x89f4 <_stogir.vector-arithmetic.validate+0x208>
    8870:      	cmp	x2, #0x0
    8874:      	b.ge	0x88cc <_stogir.vector-arithmetic.validate+0xe0>
    8878:      	add	x6, x0, #0x28
    887c:      	add	x7, x0, #0x50
    8880:      	ldr	x6, [x6, #0x8]
    8884:      	ldr	x7, [x7, #0x8]
    8888:      	cmp	x6, x7
    888c:      	b.ne	0x88bc <_stogir.vector-arithmetic.validate+0xd0>
    8890:      	cmp	x4, x6
    8894:      	b.gt	0x8a8c <_stogir.vector-arithmetic.validate+0x2a0>
    8898:      	lsl	x4, x5, #2
    889c:      	ldr	x6, [x0, #0x50]
    88a0:      	add	x4, x4, x6
    88a4:      	ldr	w4, [x4]
    88a8:      	sxtw	x4, w4
    88ac:      	cmp	x4, #0x0
    88b0:      	cset	w4, gt
    88b4:      	ubfx	x4, x4, #0, #8
    88b8:      	b	0x8a90 <_stogir.vector-arithmetic.validate+0x2a4>
    88bc:      	movz	x4, #0x0, lsl #48
    88c0:      	b	0x88d0 <_stogir.vector-arithmetic.validate+0xe4>
    88c4:      	movz	x4, #0x0, lsl #48
    88c8:      	b	0x88d0 <_stogir.vector-arithmetic.validate+0xe4>
    88cc:      	movz	x4, #0x0, lsl #48
    88d0:      	cmp	x4, #0x0
    88d4:      	b.eq	0x8934 <_stogir.vector-arithmetic.validate+0x148>
    88d8:      	uxtb	w16, w3
    88dc:      	cmp	w16, wzr
    88e0:      	b.eq	0x8908 <_stogir.vector-arithmetic.validate+0x11c>
    88e4:      	lsl	x3, x2, #4
    88e8:      	ldr	x4, [x0]
    88ec:      	add	x3, x3, x4
    88f0:      	ldr	x4, [x3]
    88f4:      	ldr	x3, [x3, #0x8]
    88f8:      	fmov	d31, x3
    88fc:      	mov	x3, x4
    8900:      	fmov	x4, d31
    8904:      	b	0x8928 <_stogir.vector-arithmetic.validate+0x13c>
    8908:      	lsl	x3, x5, #4
    890c:      	ldr	x4, [x0, #0x28]
    8910:      	add	x3, x3, x4
    8914:      	ldr	x4, [x3]
    8918:      	ldr	x3, [x3, #0x8]
    891c:      	fmov	d31, x3
    8920:      	mov	x3, x4
    8924:      	fmov	x4, d31
    8928:      	mov	x20, x3
    892c:      	mov	x3, #0x1                ; =1
    8930:      	b	0x8940 <_stogir.vector-arithmetic.validate+0x154>
    8934:      	movz	x3, #0x0, lsl #48
    8938:      	movz	x20, #0x0, lsl #48
    893c:      	movz	x4, #0x0, lsl #48
    8940:      	lsr	w3, w3, #0
    8944:      	lsr	x16, x3, #0
    8948:      	cmp	x16, #0x1
    894c:      	b.eq	0x8968 <_stogir.vector-arithmetic.validate+0x17c>
    8950:      	b.lo	0x8958 <_stogir.vector-arithmetic.validate+0x16c>
    8954:      	b	0x896c <_stogir.vector-arithmetic.validate+0x180>
    8958:      	cmp	x16, #0x0
    895c:      	b.eq	0x8964 <_stogir.vector-arithmetic.validate+0x178>
    8960:      	b	0x896c <_stogir.vector-arithmetic.validate+0x180>
    8964:      	b	0x8970 <_stogir.vector-arithmetic.validate+0x184>
    8968:      	b	0x8990 <_stogir.vector-arithmetic.validate+0x1a4>
    896c:      	b	0x8b40 <_stogir.vector-arithmetic.validate+0x354>
    8970:      	adrp	x16, 0x8000 <_stogir.vector-lanes.validate+0x314>
		0000000000008970:  ARM64_RELOC_PAGE21	l_stogir.414
    8974:      	ldr	x16, [x16]
		0000000000008974:  ARM64_RELOC_PAGEOFF12	l_stogir.414
    8978:      	orr	x0, x16, xzr
    897c:      	mov	x21, x8
    8980:      	mov	x1, x0
    8984:      	mov	x0, #0x1                ; =1
    8988:      	mov	x2, #0x25               ; =37
    898c:      	b	0x89c4 <_stogir.vector-arithmetic.validate+0x1d8>
    8990:      	add	x16, sp, #0x10
    8994:      	str	x20, [x16]
    8998:      	add	x16, sp, #0x10
    899c:      	str	x4, [x16, #0x8]
    89a0:      	cmp	x2, #0x0
    89a4:      	b.gt	0x89f8 <_stogir.vector-arithmetic.validate+0x20c>
    89a8:      	mov	x21, x8
    89ac:      	adrp	x16, 0x8000 <_stogir.vector-lanes.validate+0x314>
		00000000000089ac:  ARM64_RELOC_PAGE21	l_stogir.415
    89b0:      	ldr	x16, [x16]
		00000000000089b0:  ARM64_RELOC_PAGEOFF12	l_stogir.415
    89b4:      	orr	x0, x16, xzr
    89b8:      	mov	x1, x0
    89bc:      	mov	x0, #0x1                ; =1
    89c0:      	mov	x2, #0x2b               ; =43
    89c4:      	str	x0, [x21]
    89c8:      	str	x1, [x21, #0x8]
    89cc:      	str	x2, [x21, #0x10]
    89d0:      	ldr	x19, [sp, #0x40]
    89d4:      	ldr	x20, [sp, #0x48]
    89d8:      	ldr	x21, [sp, #0x50]
    89dc:      	ldr	x22, [sp, #0x58]
    89e0:      	ldr	x29, [sp]
    89e4:      	ldr	x30, [sp, #0x8]
    89e8:      	add	sp, sp, #0x60
    89ec:      	ret
    89f0:      	movz	x4, #0x0, lsl #48
    89f4:      	b	0x88c8 <_stogir.vector-arithmetic.validate+0xdc>
    89f8:      	lsr	w1, w1, #0
    89fc:      	mov	x21, x8
    8a00:      	mov	x22, x0
    8a04:      	bl	0x8a04 <_stogir.vector-arithmetic.validate+0x218>
		0000000000008a04:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.node?
    8a08:      	cmp	x0, #0x0
    8a0c:      	b.eq	0x89ac <_stogir.vector-arithmetic.validate+0x1c0>
    8a10:      	uxtb	w20, w20
    8a14:      	orr	x0, x20, xzr
    8a18:      	ldr	x1, [x22, #0x78]
    8a1c:      	cmp	x0, #0x1d
    8a20:      	cset	w2, eq
    8a24:      	cmp	x0, #0x1e
    8a28:      	cset	w3, eq
    8a2c:      	add	x1, x19, x1
    8a30:      	ldr	w1, [x1]
    8a34:      	cmp	x0, #0x1f
    8a38:      	b.eq	0x8af0 <_stogir.vector-arithmetic.validate+0x304>
    8a3c:      	cmp	x0, #0x20
    8a40:      	b.eq	0x8af0 <_stogir.vector-arithmetic.validate+0x304>
    8a44:      	cmp	x0, #0x2d
    8a48:      	b.eq	0x8af0 <_stogir.vector-arithmetic.validate+0x304>
    8a4c:      	cmp	x0, #0x36
    8a50:      	b.eq	0x8af0 <_stogir.vector-arithmetic.validate+0x304>
    8a54:      	cmp	x0, #0x37
    8a58:      	b.eq	0x8af0 <_stogir.vector-arithmetic.validate+0x304>
    8a5c:      	cmp	x0, #0x38
    8a60:      	b.eq	0x8af0 <_stogir.vector-arithmetic.validate+0x304>
    8a64:      	cmp	x0, #0x39
    8a68:      	b.eq	0x8af0 <_stogir.vector-arithmetic.validate+0x304>
    8a6c:      	uxtb	w16, w2
    8a70:      	cmp	w16, wzr
    8a74:      	b.ne	0x8b48 <_stogir.vector-arithmetic.validate+0x35c>
    8a78:      	uxtb	w16, w3
    8a7c:      	cmp	w16, wzr
    8a80:      	b.ne	0x8b48 <_stogir.vector-arithmetic.validate+0x35c>
    8a84:      	mov	x0, #0x2                ; =2
    8a88:      	b	0x8b4c <_stogir.vector-arithmetic.validate+0x360>
    8a8c:      	movz	x4, #0x0, lsl #48
    8a90:      	b	0x88c0 <_stogir.vector-arithmetic.validate+0xd4>
    8a94:      	add	x16, sp, #0x10
    8a98:      	ldr	w2, [x16, #0xc]
    8a9c:      	sxtw	x2, w2
    8aa0:      	lsr	w1, w1, #0
    8aa4:      	lsr	w4, w4, #0
    8aa8:      	lsr	w20, w20, #0
    8aac:      	lsr	w2, w2, #0
    8ab0:      	ubfx	x0, x0, #8, #8
    8ab4:      	lsr	w0, w0, #0
    8ab8:      	add	x8, sp, #0x20
    8abc:      	mov	w3, w1
    8ac0:      	mov	w1, w20
    8ac4:      	mov	w5, w2
    8ac8:      	mov	w2, w0
    8acc:      	mov	x0, x22
    8ad0:      	bl	0x8ad0 <_stogir.vector-arithmetic.validate+0x2e4>
		0000000000008ad0:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.operands
    8ad4:      	add	x16, sp, #0x20
    8ad8:      	ldr	x0, [x16]
    8adc:      	add	x16, sp, #0x20
    8ae0:      	ldr	x1, [x16, #0x8]
    8ae4:      	add	x16, sp, #0x20
    8ae8:      	ldr	x2, [x16, #0x10]
    8aec:      	b	0x89c4 <_stogir.vector-arithmetic.validate+0x1d8>
    8af0:      	mov	x0, #0x1                ; =1
    8af4:      	sxtw	x1, w1
    8af8:      	lsr	w0, w0, #0
    8afc:      	sxtw	x0, w0
    8b00:      	cmp	x1, x0
    8b04:      	b.ne	0x89ac <_stogir.vector-arithmetic.validate+0x1c0>
    8b08:      	add	x16, sp, #0x10
    8b0c:      	ldr	w0, [x16]
    8b10:      	add	x16, sp, #0x10
    8b14:      	ldr	w1, [x16, #0x4]
    8b18:      	add	x16, sp, #0x10
    8b1c:      	ldr	w4, [x16, #0x8]
    8b20:      	uxtb	w16, w2
    8b24:      	cmp	w16, wzr
    8b28:      	b.ne	0x8a94 <_stogir.vector-arithmetic.validate+0x2a8>
    8b2c:      	uxtb	w16, w3
    8b30:      	cmp	w16, wzr
    8b34:      	b.ne	0x8a94 <_stogir.vector-arithmetic.validate+0x2a8>
    8b38:      	movz	x2, #0x0, lsl #48
    8b3c:      	b	0x8aa0 <_stogir.vector-arithmetic.validate+0x2b4>
    8b40:      	brk	#0
    8b44:      	b	0x8b40 <_stogir.vector-arithmetic.validate+0x354>
    8b48:      	mov	x0, #0x3                ; =3
    8b4c:      	b	0x8af4 <_stogir.vector-arithmetic.validate+0x308>

0000000000008b50 <_stogir.vector.memory-inputs>:
    8b50:      	sub	sp, sp, #0x40
    8b54:      	str	x29, [sp]
    8b58:      	str	x30, [sp, #0x8]
    8b5c:      	mov	x29, sp
    8b60:      	str	x19, [sp, #0x10]
    8b64:      	str	x20, [sp, #0x18]
    8b68:      	str	x21, [sp, #0x20]
    8b6c:      	str	x22, [sp, #0x28]
    8b70:      	str	x23, [sp, #0x30]
    8b74:      	str	x24, [sp, #0x38]
    8b78:      	sxtw	x5, w1
    8b7c:      	cmp	x5, #0xf
    8b80:      	b.le	0x903c <_stogir.vector.memory-inputs+0x4ec>
    8b84:      	cmp	x5, #0x80
    8b88:      	b.ge	0x9044 <_stogir.vector.memory-inputs+0x4f4>
    8b8c:      	and	x6, x5, #0xf
    8b90:      	lsr	w6, w6, #0
    8b94:      	sxtw	x6, w6
    8b98:      	cmp	x6, #0x1
    8b9c:      	b.lt	0x904c <_stogir.vector.memory-inputs+0x4fc>
    8ba0:      	and	x5, x5, #0xf
    8ba4:      	lsr	w5, w5, #0
    8ba8:      	sxtw	x5, w5
    8bac:      	cmp	x5, #0xd
    8bb0:      	b.gt	0x9054 <_stogir.vector.memory-inputs+0x504>
    8bb4:      	lsr	w1, w1, #0
    8bb8:      	lsr	w2, w2, #0
    8bbc:      	mov	x19, x8
    8bc0:      	mov	x20, x0
    8bc4:      	mov	w0, w1
    8bc8:      	mov	w21, w1
    8bcc:      	mov	w1, w2
    8bd0:      	mov	w22, w2
    8bd4:      	mov	w23, w3
    8bd8:      	mov	w24, w4
    8bdc:      	bl	0x8bdc <_stogir.vector.memory-inputs+0x8c>
		0000000000008bdc:  ARM64_RELOC_BRANCH26	_stogir.types.size
    8be0:      	lsr	w0, w0, #0
    8be4:      	sxtw	x0, w0
    8be8:      	cmp	x0, #0x0
    8bec:      	b.le	0x8c54 <_stogir.vector.memory-inputs+0x104>
    8bf0:      	sxtw	x23, w23
    8bf4:      	cmp	x23, #0x0
    8bf8:      	cset	w0, gt
    8bfc:      	movz	x16, #0x0, lsl #48
    8c00:      	sub	x1, x16, x23
    8c04:      	sub	x2, x1, #0x1
    8c08:      	uxtb	w16, w0
    8c0c:      	cmp	w16, wzr
    8c10:      	b.eq	0x8d44 <_stogir.vector.memory-inputs+0x1f4>
    8c14:      	ldr	x1, [x20, #0x8]
    8c18:      	cmp	x23, x1
    8c1c:      	b.ge	0x8d3c <_stogir.vector.memory-inputs+0x1ec>
    8c20:      	add	x1, x20, #0x78
    8c24:      	ldr	x1, [x1, #0x8]
    8c28:      	cmp	x23, x1
    8c2c:      	b.ge	0x8dec <_stogir.vector.memory-inputs+0x29c>
    8c30:      	lsl	x1, x23, #2
    8c34:      	ldr	x3, [x20, #0x78]
    8c38:      	add	x1, x1, x3
    8c3c:      	ldr	w1, [x1]
    8c40:      	sxtw	x1, w1
    8c44:      	cmp	x1, #0x0
    8c48:      	cset	w1, ge
    8c4c:      	ubfx	x1, x1, #0, #8
    8c50:      	b	0x8df0 <_stogir.vector.memory-inputs+0x2a0>
    8c54:      	adrp	x16, 0x8000 <_stogir.vector-lanes.validate+0x314>
		0000000000008c54:  ARM64_RELOC_PAGE21	l_stogir.416
    8c58:      	ldr	x16, [x16]
		0000000000008c58:  ARM64_RELOC_PAGEOFF12	l_stogir.416
    8c5c:      	orr	x0, x16, xzr
    8c60:      	mov	x1, x0
    8c64:      	mov	x0, #0x1                ; =1
    8c68:      	mov	x2, #0x32               ; =50
    8c6c:      	str	x0, [x19]
    8c70:      	str	x1, [x19, #0x8]
    8c74:      	str	x2, [x19, #0x10]
    8c78:      	ldr	x19, [sp, #0x10]
    8c7c:      	ldr	x20, [sp, #0x18]
    8c80:      	ldr	x21, [sp, #0x20]
    8c84:      	ldr	x22, [sp, #0x28]
    8c88:      	ldr	x23, [sp, #0x30]
    8c8c:      	ldr	x24, [sp, #0x38]
    8c90:      	ldr	x29, [sp]
    8c94:      	ldr	x30, [sp, #0x8]
    8c98:      	add	sp, sp, #0x40
    8c9c:      	ret
    8ca0:      	movz	x0, #0x0, lsl #48
    8ca4:      	movz	x1, #0x0, lsl #48
    8ca8:      	lsr	w0, w0, #0
    8cac:      	lsr	x16, x0, #0
    8cb0:      	cmp	x16, #0x1
    8cb4:      	b.eq	0x8cd0 <_stogir.vector.memory-inputs+0x180>
    8cb8:      	b.lo	0x8cc0 <_stogir.vector.memory-inputs+0x170>
    8cbc:      	b	0x8cd4 <_stogir.vector.memory-inputs+0x184>
    8cc0:      	cmp	x16, #0x0
    8cc4:      	b.eq	0x8ccc <_stogir.vector.memory-inputs+0x17c>
    8cc8:      	b	0x8cd4 <_stogir.vector.memory-inputs+0x184>
    8ccc:      	b	0x8cd8 <_stogir.vector.memory-inputs+0x188>
    8cd0:      	b	0x8d90 <_stogir.vector.memory-inputs+0x240>
    8cd4:      	b	0x9024 <_stogir.vector.memory-inputs+0x4d4>
    8cd8:      	adrp	x16, 0x8000 <_stogir.vector-lanes.validate+0x314>
		0000000000008cd8:  ARM64_RELOC_PAGE21	l_stogir.417
    8cdc:      	ldr	x16, [x16]
		0000000000008cdc:  ARM64_RELOC_PAGEOFF12	l_stogir.417
    8ce0:      	orr	x0, x16, xzr
    8ce4:      	mov	x1, x0
    8ce8:      	mov	x0, #0x1                ; =1
    8cec:      	mov	x2, #0x1d               ; =29
    8cf0:      	b	0x8c6c <_stogir.vector.memory-inputs+0x11c>
    8cf4:      	lsl	x0, x2, #4
    8cf8:      	ldr	x1, [x20, #0x28]
    8cfc:      	add	x0, x0, x1
    8d00:      	ldr	x0, [x0]
    8d04:      	mov	x1, x0
    8d08:      	mov	x0, #0x1                ; =1
    8d0c:      	b	0x8ca8 <_stogir.vector.memory-inputs+0x158>
    8d10:      	movz	x1, #0x0, lsl #48
    8d14:      	cmp	x1, #0x0
    8d18:      	b.eq	0x8ca0 <_stogir.vector.memory-inputs+0x150>
    8d1c:      	uxtb	w16, w0
    8d20:      	cmp	w16, wzr
    8d24:      	b.eq	0x8cf4 <_stogir.vector.memory-inputs+0x1a4>
    8d28:      	lsl	x0, x23, #4
    8d2c:      	ldr	x1, [x20]
    8d30:      	add	x0, x0, x1
    8d34:      	ldr	x0, [x0]
    8d38:      	b	0x8d04 <_stogir.vector.memory-inputs+0x1b4>
    8d3c:      	movz	x1, #0x0, lsl #48
    8d40:      	b	0x8d14 <_stogir.vector.memory-inputs+0x1c4>
    8d44:      	cmp	x23, #0x0
    8d48:      	b.ge	0x8d10 <_stogir.vector.memory-inputs+0x1c0>
    8d4c:      	add	x3, x20, #0x28
    8d50:      	add	x4, x20, #0x50
    8d54:      	ldr	x3, [x3, #0x8]
    8d58:      	ldr	x4, [x4, #0x8]
    8d5c:      	cmp	x3, x4
    8d60:      	b.ne	0x8de4 <_stogir.vector.memory-inputs+0x294>
    8d64:      	cmp	x1, x3
    8d68:      	b.gt	0x8df4 <_stogir.vector.memory-inputs+0x2a4>
    8d6c:      	lsl	x1, x2, #2
    8d70:      	ldr	x3, [x20, #0x50]
    8d74:      	add	x1, x1, x3
    8d78:      	ldr	w1, [x1]
    8d7c:      	sxtw	x1, w1
    8d80:      	cmp	x1, #0x0
    8d84:      	cset	w1, gt
    8d88:      	ubfx	x1, x1, #0, #8
    8d8c:      	b	0x8df8 <_stogir.vector.memory-inputs+0x2a8>
    8d90:      	cmp	x23, #0x0
    8d94:      	b.le	0x8dc8 <_stogir.vector.memory-inputs+0x278>
    8d98:      	uxtb	w1, w1
    8d9c:      	cmp	x1, #0x83
    8da0:      	cset	w0, lt
    8da4:      	uxtb	w16, w0
    8da8:      	cmp	w16, wzr
    8dac:      	b.eq	0x8dfc <_stogir.vector.memory-inputs+0x2ac>
    8db0:      	adrp	x16, 0x8000 <_stogir.vector-lanes.validate+0x314>
		0000000000008db0:  ARM64_RELOC_PAGE21	l_stogir.418
    8db4:      	ldr	x16, [x16]
		0000000000008db4:  ARM64_RELOC_PAGEOFF12	l_stogir.418
    8db8:      	orr	x2, x16, xzr
    8dbc:      	add	x2, x1, x2
    8dc0:      	ldrb	w2, [x2]
    8dc4:      	b	0x8e00 <_stogir.vector.memory-inputs+0x2b0>
    8dc8:      	adrp	x16, 0x8000 <_stogir.vector-lanes.validate+0x314>
		0000000000008dc8:  ARM64_RELOC_PAGE21	l_stogir.419
    8dcc:      	ldr	x16, [x16]
		0000000000008dcc:  ARM64_RELOC_PAGEOFF12	l_stogir.419
    8dd0:      	orr	x0, x16, xzr
    8dd4:      	mov	x1, x0
    8dd8:      	mov	x0, #0x1                ; =1
    8ddc:      	mov	x2, #0x2c               ; =44
    8de0:      	b	0x8cf0 <_stogir.vector.memory-inputs+0x1a0>
    8de4:      	movz	x1, #0x0, lsl #48
    8de8:      	b	0x8d14 <_stogir.vector.memory-inputs+0x1c4>
    8dec:      	movz	x1, #0x0, lsl #48
    8df0:      	b	0x8d40 <_stogir.vector.memory-inputs+0x1f0>
    8df4:      	movz	x1, #0x0, lsl #48
    8df8:      	b	0x8de8 <_stogir.vector.memory-inputs+0x298>
    8dfc:      	movz	x2, #0x0, lsl #48
    8e00:      	uxtb	w2, w2
    8e04:      	and	x2, x2, #0x1
    8e08:      	uxtb	w2, w2
    8e0c:      	cmp	x2, #0x0
    8e10:      	b.eq	0x8dc8 <_stogir.vector.memory-inputs+0x278>
    8e14:      	uxtb	w16, w0
    8e18:      	cmp	w16, wzr
    8e1c:      	b.eq	0x8e38 <_stogir.vector.memory-inputs+0x2e8>
    8e20:      	adrp	x16, 0x8000 <_stogir.vector-lanes.validate+0x314>
		0000000000008e20:  ARM64_RELOC_PAGE21	l_stogir.418
    8e24:      	ldr	x16, [x16]
		0000000000008e24:  ARM64_RELOC_PAGEOFF12	l_stogir.418
    8e28:      	orr	x0, x16, xzr
    8e2c:      	add	x0, x1, x0
    8e30:      	ldrb	w0, [x0]
    8e34:      	b	0x8e3c <_stogir.vector.memory-inputs+0x2ec>
    8e38:      	movz	x0, #0x0, lsl #48
    8e3c:      	uxtb	w0, w0
    8e40:      	and	x0, x0, #0x4
    8e44:      	uxtb	w0, w0
    8e48:      	cmp	x0, #0x0
    8e4c:      	b.ne	0x8dc8 <_stogir.vector.memory-inputs+0x278>
    8e50:      	sxtw	x24, w24
    8e54:      	cmp	x24, #0x0
    8e58:      	cset	w0, gt
    8e5c:      	movz	x16, #0x0, lsl #48
    8e60:      	sub	x1, x16, x24
    8e64:      	sub	x2, x1, #0x1
    8e68:      	uxtb	w16, w0
    8e6c:      	cmp	w16, wzr
    8e70:      	b.eq	0x8ed0 <_stogir.vector.memory-inputs+0x380>
    8e74:      	ldr	x1, [x20, #0x8]
    8e78:      	cmp	x24, x1
    8e7c:      	b.ge	0x8f1c <_stogir.vector.memory-inputs+0x3cc>
    8e80:      	add	x1, x20, #0x78
    8e84:      	ldr	x1, [x1, #0x8]
    8e88:      	cmp	x24, x1
    8e8c:      	b.ge	0x901c <_stogir.vector.memory-inputs+0x4cc>
    8e90:      	lsl	x1, x24, #2
    8e94:      	ldr	x3, [x20, #0x78]
    8e98:      	add	x1, x1, x3
    8e9c:      	ldr	w1, [x1]
    8ea0:      	sxtw	x1, w1
    8ea4:      	cmp	x1, #0x0
    8ea8:      	cset	w1, ge
    8eac:      	ubfx	x1, x1, #0, #8
    8eb0:      	b	0x9020 <_stogir.vector.memory-inputs+0x4d0>
    8eb4:      	adrp	x16, 0x8000 <_stogir.vector-lanes.validate+0x314>
		0000000000008eb4:  ARM64_RELOC_PAGE21	l_stogir.420
    8eb8:      	ldr	x16, [x16]
		0000000000008eb8:  ARM64_RELOC_PAGEOFF12	l_stogir.420
    8ebc:      	orr	x0, x16, xzr
    8ec0:      	mov	x1, x0
    8ec4:      	mov	x0, #0x1                ; =1
    8ec8:      	mov	x2, #0x2b               ; =43
    8ecc:      	b	0x8de0 <_stogir.vector.memory-inputs+0x290>
    8ed0:      	cmp	x24, #0x0
    8ed4:      	b.ge	0x8f24 <_stogir.vector.memory-inputs+0x3d4>
    8ed8:      	add	x3, x20, #0x28
    8edc:      	add	x4, x20, #0x50
    8ee0:      	ldr	x3, [x3, #0x8]
    8ee4:      	ldr	x4, [x4, #0x8]
    8ee8:      	cmp	x3, x4
    8eec:      	b.ne	0x9014 <_stogir.vector.memory-inputs+0x4c4>
    8ef0:      	cmp	x1, x3
    8ef4:      	b.gt	0x902c <_stogir.vector.memory-inputs+0x4dc>
    8ef8:      	lsl	x1, x2, #2
    8efc:      	ldr	x3, [x20, #0x50]
    8f00:      	add	x1, x1, x3
    8f04:      	ldr	w1, [x1]
    8f08:      	sxtw	x1, w1
    8f0c:      	cmp	x1, #0x0
    8f10:      	cset	w1, gt
    8f14:      	ubfx	x1, x1, #0, #8
    8f18:      	b	0x9030 <_stogir.vector.memory-inputs+0x4e0>
    8f1c:      	movz	x1, #0x0, lsl #48
    8f20:      	b	0x8f28 <_stogir.vector.memory-inputs+0x3d8>
    8f24:      	movz	x1, #0x0, lsl #48
    8f28:      	cmp	x1, #0x0
    8f2c:      	b.eq	0x8f6c <_stogir.vector.memory-inputs+0x41c>
    8f30:      	uxtb	w16, w0
    8f34:      	cmp	w16, wzr
    8f38:      	b.eq	0x8f50 <_stogir.vector.memory-inputs+0x400>
    8f3c:      	lsl	x0, x24, #4
    8f40:      	ldr	x1, [x20]
    8f44:      	add	x0, x0, x1
    8f48:      	ldr	x0, [x0]
    8f4c:      	b	0x8f60 <_stogir.vector.memory-inputs+0x410>
    8f50:      	lsl	x0, x2, #4
    8f54:      	ldr	x1, [x20, #0x28]
    8f58:      	add	x0, x0, x1
    8f5c:      	ldr	x0, [x0]
    8f60:      	mov	x1, x0
    8f64:      	mov	x0, #0x1                ; =1
    8f68:      	b	0x8f74 <_stogir.vector.memory-inputs+0x424>
    8f6c:      	movz	x0, #0x0, lsl #48
    8f70:      	movz	x1, #0x0, lsl #48
    8f74:      	lsr	w0, w0, #0
    8f78:      	lsr	x16, x0, #0
    8f7c:      	cmp	x16, #0x1
    8f80:      	b.eq	0x8f9c <_stogir.vector.memory-inputs+0x44c>
    8f84:      	b.lo	0x8f8c <_stogir.vector.memory-inputs+0x43c>
    8f88:      	b	0x8fa0 <_stogir.vector.memory-inputs+0x450>
    8f8c:      	cmp	x16, #0x0
    8f90:      	b.eq	0x8f98 <_stogir.vector.memory-inputs+0x448>
    8f94:      	b	0x8fa0 <_stogir.vector.memory-inputs+0x450>
    8f98:      	b	0x8fa4 <_stogir.vector.memory-inputs+0x454>
    8f9c:      	b	0x8fc0 <_stogir.vector.memory-inputs+0x470>
    8fa0:      	b	0x9034 <_stogir.vector.memory-inputs+0x4e4>
    8fa4:      	adrp	x16, 0x8000 <_stogir.vector-lanes.validate+0x314>
		0000000000008fa4:  ARM64_RELOC_PAGE21	l_stogir.421
    8fa8:      	ldr	x16, [x16]
		0000000000008fa8:  ARM64_RELOC_PAGEOFF12	l_stogir.421
    8fac:      	orr	x0, x16, xzr
    8fb0:      	mov	x1, x0
    8fb4:      	mov	x0, #0x1                ; =1
    8fb8:      	mov	x2, #0x1d               ; =29
    8fbc:      	b	0x8ecc <_stogir.vector.memory-inputs+0x37c>
    8fc0:      	lsr	w0, w1, #0
    8fc4:      	ubfx	x0, x0, #8, #8
    8fc8:      	cmp	x0, #0x6
    8fcc:      	b.ne	0x8eb4 <_stogir.vector.memory-inputs+0x364>
    8fd0:      	uxtb	w1, w1
    8fd4:      	cmp	x1, #0x48
    8fd8:      	b.eq	0x8eb4 <_stogir.vector.memory-inputs+0x364>
    8fdc:      	cmp	x1, #0x46
    8fe0:      	b.eq	0x8eb4 <_stogir.vector.memory-inputs+0x364>
    8fe4:      	lsr	w21, w21, #0
    8fe8:      	lsr	w22, w22, #0
    8fec:      	mov	w0, w21
    8ff0:      	mov	w1, w22
    8ff4:      	bl	0x8ff4 <_stogir.vector.memory-inputs+0x4a4>
		0000000000008ff4:  ARM64_RELOC_BRANCH26	_stogir.types.size
    8ff8:      	lsr	w0, w0, #0
    8ffc:      	sxtw	x0, w0
    9000:      	and	x0, x0, #0xffffffff
    9004:      	mov	x1, x0
    9008:      	movz	x0, #0x0, lsl #48
    900c:      	movz	x2, #0x0, lsl #48
    9010:      	b	0x8ecc <_stogir.vector.memory-inputs+0x37c>
    9014:      	movz	x1, #0x0, lsl #48
    9018:      	b	0x8f28 <_stogir.vector.memory-inputs+0x3d8>
    901c:      	movz	x1, #0x0, lsl #48
    9020:      	b	0x8f20 <_stogir.vector.memory-inputs+0x3d0>
    9024:      	brk	#0
    9028:      	b	0x9024 <_stogir.vector.memory-inputs+0x4d4>
    902c:      	movz	x1, #0x0, lsl #48
    9030:      	b	0x9018 <_stogir.vector.memory-inputs+0x4c8>
    9034:      	brk	#0
    9038:      	b	0x9034 <_stogir.vector.memory-inputs+0x4e4>
    903c:      	mov	x19, x8
    9040:      	b	0x8c54 <_stogir.vector.memory-inputs+0x104>
    9044:      	mov	x19, x8
    9048:      	b	0x8c54 <_stogir.vector.memory-inputs+0x104>
    904c:      	mov	x19, x8
    9050:      	b	0x8c54 <_stogir.vector.memory-inputs+0x104>
    9054:      	mov	x19, x8
    9058:      	b	0x8c54 <_stogir.vector.memory-inputs+0x104>

000000000000905c <_stogir.vector.store-inputs>:
    905c:      	sub	sp, sp, #0x40
    9060:      	str	x29, [sp]
    9064:      	str	x30, [sp, #0x8]
    9068:      	mov	x29, sp
    906c:      	str	x19, [sp, #0x30]
    9070:      	sxtw	x4, w4
    9074:      	cmp	x4, #0x0
    9078:      	cset	w5, gt
    907c:      	movz	x16, #0x0, lsl #48
    9080:      	sub	x6, x16, x4
    9084:      	sub	x7, x6, #0x1
    9088:      	uxtb	w16, w5
    908c:      	cmp	w16, wzr
    9090:      	b.eq	0x90d4 <_stogir.vector.store-inputs+0x78>
    9094:      	ldr	x6, [x0, #0x8]
    9098:      	cmp	x4, x6
    909c:      	b.ge	0x9128 <_stogir.vector.store-inputs+0xcc>
    90a0:      	add	x6, x0, #0x78
    90a4:      	ldr	x6, [x6, #0x8]
    90a8:      	cmp	x4, x6
    90ac:      	b.ge	0x9240 <_stogir.vector.store-inputs+0x1e4>
    90b0:      	lsl	x6, x4, #2
    90b4:      	ldr	x9, [x0, #0x78]
    90b8:      	add	x6, x6, x9
    90bc:      	ldr	w6, [x6]
    90c0:      	sxtw	x6, w6
    90c4:      	cmp	x6, #0x0
    90c8:      	cset	w6, ge
    90cc:      	ubfx	x6, x6, #0, #8
    90d0:      	b	0x9244 <_stogir.vector.store-inputs+0x1e8>
    90d4:      	cmp	x4, #0x0
    90d8:      	b.ge	0x9130 <_stogir.vector.store-inputs+0xd4>
    90dc:      	add	x9, x0, #0x28
    90e0:      	add	x10, x0, #0x50
    90e4:      	ldr	x9, [x9, #0x8]
    90e8:      	ldr	x10, [x10, #0x8]
    90ec:      	cmp	x9, x10
    90f0:      	b.ne	0x9120 <_stogir.vector.store-inputs+0xc4>
    90f4:      	cmp	x6, x9
    90f8:      	b.gt	0x9248 <_stogir.vector.store-inputs+0x1ec>
    90fc:      	lsl	x6, x7, #2
    9100:      	ldr	x9, [x0, #0x50]
    9104:      	add	x6, x6, x9
    9108:      	ldr	w6, [x6]
    910c:      	sxtw	x6, w6
    9110:      	cmp	x6, #0x0
    9114:      	cset	w6, gt
    9118:      	ubfx	x6, x6, #0, #8
    911c:      	b	0x924c <_stogir.vector.store-inputs+0x1f0>
    9120:      	movz	x6, #0x0, lsl #48
    9124:      	b	0x9134 <_stogir.vector.store-inputs+0xd8>
    9128:      	movz	x6, #0x0, lsl #48
    912c:      	b	0x9134 <_stogir.vector.store-inputs+0xd8>
    9130:      	movz	x6, #0x0, lsl #48
    9134:      	cmp	x6, #0x0
    9138:      	b.eq	0x9178 <_stogir.vector.store-inputs+0x11c>
    913c:      	uxtb	w16, w5
    9140:      	cmp	w16, wzr
    9144:      	b.eq	0x915c <_stogir.vector.store-inputs+0x100>
    9148:      	lsl	x4, x4, #4
    914c:      	ldr	x5, [x0]
    9150:      	add	x4, x4, x5
    9154:      	ldr	x4, [x4]
    9158:      	b	0x916c <_stogir.vector.store-inputs+0x110>
    915c:      	lsl	x4, x7, #4
    9160:      	ldr	x5, [x0, #0x28]
    9164:      	add	x4, x4, x5
    9168:      	ldr	x4, [x4]
    916c:      	mov	x5, x4
    9170:      	mov	x4, #0x1                ; =1
    9174:      	b	0x9180 <_stogir.vector.store-inputs+0x124>
    9178:      	movz	x4, #0x0, lsl #48
    917c:      	movz	x5, #0x0, lsl #48
    9180:      	lsr	w4, w4, #0
    9184:      	lsr	x16, x4, #0
    9188:      	cmp	x16, #0x1
    918c:      	b.eq	0x91a8 <_stogir.vector.store-inputs+0x14c>
    9190:      	b.lo	0x9198 <_stogir.vector.store-inputs+0x13c>
    9194:      	b	0x91ac <_stogir.vector.store-inputs+0x150>
    9198:      	cmp	x16, #0x0
    919c:      	b.eq	0x91a4 <_stogir.vector.store-inputs+0x148>
    91a0:      	b	0x91ac <_stogir.vector.store-inputs+0x150>
    91a4:      	b	0x91b0 <_stogir.vector.store-inputs+0x154>
    91a8:      	b	0x91d0 <_stogir.vector.store-inputs+0x174>
    91ac:      	b	0x9250 <_stogir.vector.store-inputs+0x1f4>
    91b0:      	adrp	x16, 0x9000 <_stogir.vector.memory-inputs+0x4b0>
		00000000000091b0:  ARM64_RELOC_PAGE21	l_stogir.422
    91b4:      	ldr	x16, [x16]
		00000000000091b4:  ARM64_RELOC_PAGEOFF12	l_stogir.422
    91b8:      	orr	x0, x16, xzr
    91bc:      	mov	x19, x8
    91c0:      	mov	x1, x0
    91c4:      	mov	x0, #0x1                ; =1
    91c8:      	mov	x2, #0x1a               ; =26
    91cc:      	b	0x9220 <_stogir.vector.store-inputs+0x1c4>
    91d0:      	lsr	w1, w1, #0
    91d4:      	lsr	w2, w2, #0
    91d8:      	lsr	w3, w3, #0
    91dc:      	lsr	w5, w5, #0
    91e0:      	ubfx	x4, x5, #8, #8
    91e4:      	lsr	w4, w4, #0
    91e8:      	mov	x19, x8
    91ec:      	add	x8, sp, #0x10
    91f0:      	fmov	s31, w1
    91f4:      	mov	w1, w4
    91f8:      	mov	w4, w3
    91fc:      	mov	w3, w2
    9200:      	fmov	w2, s31
    9204:      	bl	0x9204 <_stogir.vector.store-inputs+0x1a8>
		0000000000009204:  ARM64_RELOC_BRANCH26	_stogir.vector.memory-inputs
    9208:      	add	x16, sp, #0x10
    920c:      	ldr	x0, [x16]
    9210:      	add	x16, sp, #0x10
    9214:      	ldr	x1, [x16, #0x8]
    9218:      	add	x16, sp, #0x10
    921c:      	ldr	x2, [x16, #0x10]
    9220:      	str	x0, [x19]
    9224:      	str	x1, [x19, #0x8]
    9228:      	str	x2, [x19, #0x10]
    922c:      	ldr	x19, [sp, #0x30]
    9230:      	ldr	x29, [sp]
    9234:      	ldr	x30, [sp, #0x8]
    9238:      	add	sp, sp, #0x40
    923c:      	ret
    9240:      	movz	x6, #0x0, lsl #48
    9244:      	b	0x912c <_stogir.vector.store-inputs+0xd0>
    9248:      	movz	x6, #0x0, lsl #48
    924c:      	b	0x9124 <_stogir.vector.store-inputs+0xc8>
    9250:      	brk	#0
    9254:      	b	0x9250 <_stogir.vector.store-inputs+0x1f4>

0000000000009258 <_stogir.types.size>:
    9258:      	sub	sp, sp, #0x60
    925c:      	str	x29, [sp]
    9260:      	str	x30, [sp, #0x8]
    9264:      	mov	x29, sp
    9268:      	str	x19, [sp, #0x10]
    926c:      	str	x20, [sp, #0x18]
    9270:      	str	x21, [sp, #0x20]
    9274:      	str	x22, [sp, #0x28]
    9278:      	str	x23, [sp, #0x30]
    927c:      	str	x24, [sp, #0x38]
    9280:      	str	x25, [sp, #0x40]
    9284:      	str	x26, [sp, #0x48]
    9288:      	str	x27, [sp, #0x50]
    928c:      	str	x28, [sp, #0x58]
    9290:      	sxtw	x19, w0
    9294:      	sxtw	x20, w1
    9298:      	cmp	x19, #0xf
    929c:      	cset	w21, gt
    92a0:      	cmp	x19, #0x0
    92a4:      	cset	w22, eq
    92a8:      	cmp	x20, #0x4
    92ac:      	cset	w23, eq
    92b0:      	cmp	x20, #0x8
    92b4:      	cset	w24, eq
    92b8:      	uxtb	w16, w21
    92bc:      	cmp	w16, wzr
    92c0:      	b.eq	0x9324 <_stogir.types.size+0xcc>
    92c4:      	cmp	x19, #0x80
    92c8:      	cset	w25, lt
    92cc:      	uxtb	w16, w25
    92d0:      	cmp	w16, wzr
    92d4:      	b.eq	0x9324 <_stogir.types.size+0xcc>
    92d8:      	and	x1, x19, #0xf
    92dc:      	lsr	w1, w1, #0
    92e0:      	sxtw	x26, w1
    92e4:      	cmp	x26, #0x1
    92e8:      	cset	w27, ge
    92ec:      	uxtb	w16, w27
    92f0:      	cmp	w16, wzr
    92f4:      	b.eq	0x9324 <_stogir.types.size+0xcc>
    92f8:      	cmp	x26, #0xd
    92fc:      	cset	w28, le
    9300:      	uxtb	w16, w28
    9304:      	cmp	w16, wzr
    9308:      	b.eq	0x9324 <_stogir.types.size+0xcc>
    930c:      	lsr	w0, w0, #0
    9310:      	bl	0x9310 <_stogir.types.size+0xb8>
		0000000000009310:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
    9314:      	cmp	x0, #0x0
    9318:      	b.eq	0x9404 <_stogir.types.size+0x1ac>
    931c:      	mov	x0, x26
    9320:      	b	0x9408 <_stogir.types.size+0x1b0>
    9324:      	uxtb	w16, w23
    9328:      	cmp	w16, wzr
    932c:      	b.ne	0x9344 <_stogir.types.size+0xec>
    9330:      	uxtb	w16, w24
    9334:      	cmp	w16, wzr
    9338:      	b.ne	0x9344 <_stogir.types.size+0xec>
    933c:      	movn	x0, #0x0, lsl #48
    9340:      	b	0x935c <_stogir.types.size+0x104>
    9344:      	uxtb	w16, w22
    9348:      	cmp	w16, wzr
    934c:      	b.eq	0x9394 <_stogir.types.size+0x13c>
    9350:      	movz	x0, #0x0, lsl #48
    9354:      	b	0x935c <_stogir.types.size+0x104>
    9358:      	mov	x0, #0x1                ; =1
    935c:      	ldr	x19, [sp, #0x10]
    9360:      	ldr	x20, [sp, #0x18]
    9364:      	ldr	x21, [sp, #0x20]
    9368:      	ldr	x22, [sp, #0x28]
    936c:      	ldr	x23, [sp, #0x30]
    9370:      	ldr	x24, [sp, #0x38]
    9374:      	ldr	x25, [sp, #0x40]
    9378:      	ldr	x26, [sp, #0x48]
    937c:      	ldr	x27, [sp, #0x50]
    9380:      	ldr	x28, [sp, #0x58]
    9384:      	ldr	x29, [sp]
    9388:      	ldr	x30, [sp, #0x8]
    938c:      	add	sp, sp, #0x60
    9390:      	ret
    9394:      	cmp	x19, #0x1
    9398:      	b.eq	0x9358 <_stogir.types.size+0x100>
    939c:      	cmp	x19, #0x2
    93a0:      	b.eq	0x9358 <_stogir.types.size+0x100>
    93a4:      	cmp	x19, #0x7
    93a8:      	b.eq	0x9358 <_stogir.types.size+0x100>
    93ac:      	cmp	x19, #0x8
    93b0:      	b.eq	0x9358 <_stogir.types.size+0x100>
    93b4:      	cmp	x19, #0x3
    93b8:      	b.eq	0x9574 <_stogir.types.size+0x31c>
    93bc:      	cmp	x19, #0x9
    93c0:      	b.eq	0x9574 <_stogir.types.size+0x31c>
    93c4:      	cmp	x19, #0x4
    93c8:      	b.eq	0x959c <_stogir.types.size+0x344>
    93cc:      	cmp	x19, #0xa
    93d0:      	b.eq	0x959c <_stogir.types.size+0x344>
    93d4:      	cmp	x19, #0xd
    93d8:      	b.eq	0x959c <_stogir.types.size+0x344>
    93dc:      	cmp	x19, #0x5
    93e0:      	b.eq	0x95ac <_stogir.types.size+0x354>
    93e4:      	cmp	x19, #0xb
    93e8:      	b.eq	0x95ac <_stogir.types.size+0x354>
    93ec:      	cmp	x19, #0xc
    93f0:      	b.eq	0x95ac <_stogir.types.size+0x354>
    93f4:      	cmp	x19, #0x6
    93f8:      	b.ne	0x95bc <_stogir.types.size+0x364>
    93fc:      	mov	x0, x20
    9400:      	b	0x95c0 <_stogir.types.size+0x368>
    9404:      	movn	x0, #0x0, lsl #48
    9408:      	uxtb	w16, w23
    940c:      	cmp	w16, wzr
    9410:      	b.ne	0x9428 <_stogir.types.size+0x1d0>
    9414:      	uxtb	w16, w24
    9418:      	cmp	w16, wzr
    941c:      	b.ne	0x9428 <_stogir.types.size+0x1d0>
    9420:      	movn	x0, #0x0, lsl #48
    9424:      	b	0x9444 <_stogir.types.size+0x1ec>
    9428:      	lsr	w0, w0, #0
    942c:      	sxtw	x0, w0
    9430:      	cmp	x0, #0x0
    9434:      	b.ne	0x9504 <_stogir.types.size+0x2ac>
    9438:      	movz	x0, #0x0, lsl #48
    943c:      	b	0x9444 <_stogir.types.size+0x1ec>
    9440:      	mov	x0, #0x1                ; =1
    9444:      	lsr	w0, w0, #0
    9448:      	sxtw	x0, w0
    944c:      	cmp	x0, #0x0
    9450:      	b.ge	0x94ac <_stogir.types.size+0x254>
    9454:      	movn	x0, #0x0, lsl #48
    9458:      	b	0x9474 <_stogir.types.size+0x21c>
    945c:      	movn	x1, #0x0, lsl #48
    9460:      	lsr	w1, w1, #0
    9464:      	sxtw	x1, w1
    9468:      	mul	x0, x1, x0
    946c:      	lsr	w0, w0, #0
    9470:      	sxtw	x0, w0
    9474:      	ldr	x19, [sp, #0x10]
    9478:      	ldr	x20, [sp, #0x18]
    947c:      	ldr	x21, [sp, #0x20]
    9480:      	ldr	x22, [sp, #0x28]
    9484:      	ldr	x23, [sp, #0x30]
    9488:      	ldr	x24, [sp, #0x38]
    948c:      	ldr	x25, [sp, #0x40]
    9490:      	ldr	x26, [sp, #0x48]
    9494:      	ldr	x27, [sp, #0x50]
    9498:      	ldr	x28, [sp, #0x58]
    949c:      	ldr	x29, [sp]
    94a0:      	ldr	x30, [sp, #0x8]
    94a4:      	add	sp, sp, #0x60
    94a8:      	ret
    94ac:      	uxtb	w16, w21
    94b0:      	cmp	w16, wzr
    94b4:      	b.eq	0x957c <_stogir.types.size+0x324>
    94b8:      	uxtb	w16, w25
    94bc:      	cmp	w16, wzr
    94c0:      	b.eq	0x957c <_stogir.types.size+0x324>
    94c4:      	uxtb	w16, w27
    94c8:      	cmp	w16, wzr
    94cc:      	b.eq	0x957c <_stogir.types.size+0x324>
    94d0:      	uxtb	w16, w28
    94d4:      	cmp	w16, wzr
    94d8:      	b.eq	0x957c <_stogir.types.size+0x324>
    94dc:      	ubfx	x1, x19, #4, #32
    94e0:      	sxtw	x1, w1
    94e4:      	sub	x1, x1, #0x1
    94e8:      	lsr	w1, w1, #0
    94ec:      	sxtw	x1, w1
    94f0:      	mov	x16, #0x1               ; =1
    94f4:      	lsl	x1, x16, x1
    94f8:      	lsr	w1, w1, #0
    94fc:      	sxtw	x1, w1
    9500:      	b	0x9460 <_stogir.types.size+0x208>
    9504:      	cmp	x0, #0x1
    9508:      	b.eq	0x9440 <_stogir.types.size+0x1e8>
    950c:      	cmp	x0, #0x2
    9510:      	b.eq	0x9440 <_stogir.types.size+0x1e8>
    9514:      	cmp	x0, #0x7
    9518:      	b.eq	0x9440 <_stogir.types.size+0x1e8>
    951c:      	cmp	x0, #0x8
    9520:      	b.eq	0x9440 <_stogir.types.size+0x1e8>
    9524:      	cmp	x0, #0x3
    9528:      	b.eq	0x95a4 <_stogir.types.size+0x34c>
    952c:      	cmp	x0, #0x9
    9530:      	b.eq	0x95a4 <_stogir.types.size+0x34c>
    9534:      	cmp	x0, #0x4
    9538:      	b.eq	0x95b4 <_stogir.types.size+0x35c>
    953c:      	cmp	x0, #0xa
    9540:      	b.eq	0x95b4 <_stogir.types.size+0x35c>
    9544:      	cmp	x0, #0xd
    9548:      	b.eq	0x95b4 <_stogir.types.size+0x35c>
    954c:      	cmp	x0, #0x5
    9550:      	b.eq	0x95c4 <_stogir.types.size+0x36c>
    9554:      	cmp	x0, #0xb
    9558:      	b.eq	0x95c4 <_stogir.types.size+0x36c>
    955c:      	cmp	x0, #0xc
    9560:      	b.eq	0x95c4 <_stogir.types.size+0x36c>
    9564:      	cmp	x0, #0x6
    9568:      	b.ne	0x95cc <_stogir.types.size+0x374>
    956c:      	mov	x0, x20
    9570:      	b	0x95d0 <_stogir.types.size+0x378>
    9574:      	mov	x0, #0x2                ; =2
    9578:      	b	0x935c <_stogir.types.size+0x104>
    957c:      	cmp	x19, #0x0
    9580:      	b.lt	0x945c <_stogir.types.size+0x204>
    9584:      	cmp	x19, #0xd
    9588:      	b.gt	0x945c <_stogir.types.size+0x204>
    958c:      	uxtb	w16, w22
    9590:      	cmp	w16, wzr
    9594:      	cset	x1, eq
    9598:      	b	0x9460 <_stogir.types.size+0x208>
    959c:      	mov	x0, #0x4                ; =4
    95a0:      	b	0x9578 <_stogir.types.size+0x320>
    95a4:      	mov	x0, #0x2                ; =2
    95a8:      	b	0x9444 <_stogir.types.size+0x1ec>
    95ac:      	mov	x0, #0x8                ; =8
    95b0:      	b	0x95a0 <_stogir.types.size+0x348>
    95b4:      	mov	x0, #0x4                ; =4
    95b8:      	b	0x95a8 <_stogir.types.size+0x350>
    95bc:      	movn	x0, #0x0, lsl #48
    95c0:      	b	0x95b0 <_stogir.types.size+0x358>
    95c4:      	mov	x0, #0x8                ; =8
    95c8:      	b	0x95b8 <_stogir.types.size+0x360>
    95cc:      	movn	x0, #0x0, lsl #48
    95d0:      	b	0x95c8 <_stogir.types.size+0x370>

00000000000095d4 <_stogir.opcode.properties>:
    95d4:      	sxtw	x0, w0
    95d8:      	cmp	x0, #0x0
    95dc:      	b.lt	0x9604 <_stogir.opcode.properties+0x30>
    95e0:      	cmp	x0, #0x83
    95e4:      	b.ge	0x9604 <_stogir.opcode.properties+0x30>
    95e8:      	adrp	x16, 0x9000 <_stogir.vector.memory-inputs+0x4b0>
		00000000000095e8:  ARM64_RELOC_PAGE21	l_stogir.423
    95ec:      	ldr	x16, [x16]
		00000000000095ec:  ARM64_RELOC_PAGEOFF12	l_stogir.423
    95f0:      	orr	x1, x16, xzr
    95f4:      	lsr	x0, x0, #0
    95f8:      	add	x0, x0, x1
    95fc:      	ldrb	w0, [x0]
    9600:      	b	0x9608 <_stogir.opcode.properties+0x34>
    9604:      	movz	x0, #0x0, lsl #48
    9608:      	ret

000000000000960c <_stogir.checked.projection>:
    960c:      	sub	sp, sp, #0x40
    9610:      	str	x29, [sp]
    9614:      	str	x30, [sp, #0x8]
    9618:      	mov	x29, sp
    961c:      	str	x19, [sp, #0x30]
    9620:      	sxtw	x2, w1
    9624:      	cmp	x2, #0x0
    9628:      	cset	w3, gt
    962c:      	movz	x16, #0x0, lsl #48
    9630:      	sub	x4, x16, x2
    9634:      	sub	x5, x4, #0x1
    9638:      	uxtb	w16, w3
    963c:      	cmp	w16, wzr
    9640:      	b.eq	0x9684 <_stogir.checked.projection+0x78>
    9644:      	ldr	x4, [x0, #0x8]
    9648:      	cmp	x2, x4
    964c:      	b.ge	0x96d8 <_stogir.checked.projection+0xcc>
    9650:      	add	x4, x0, #0x78
    9654:      	ldr	x4, [x4, #0x8]
    9658:      	cmp	x2, x4
    965c:      	b.ge	0x97f8 <_stogir.checked.projection+0x1ec>
    9660:      	lsl	x4, x2, #2
    9664:      	ldr	x6, [x0, #0x78]
    9668:      	add	x4, x4, x6
    966c:      	ldr	w4, [x4]
    9670:      	sxtw	x4, w4
    9674:      	cmp	x4, #0x0
    9678:      	cset	w4, ge
    967c:      	ubfx	x4, x4, #0, #8
    9680:      	b	0x97fc <_stogir.checked.projection+0x1f0>
    9684:      	cmp	x2, #0x0
    9688:      	b.ge	0x96e0 <_stogir.checked.projection+0xd4>
    968c:      	add	x6, x0, #0x28
    9690:      	add	x7, x0, #0x50
    9694:      	ldr	x6, [x6, #0x8]
    9698:      	ldr	x7, [x7, #0x8]
    969c:      	cmp	x6, x7
    96a0:      	b.ne	0x96d0 <_stogir.checked.projection+0xc4>
    96a4:      	cmp	x4, x6
    96a8:      	b.gt	0x9828 <_stogir.checked.projection+0x21c>
    96ac:      	lsl	x4, x5, #2
    96b0:      	ldr	x6, [x0, #0x50]
    96b4:      	add	x4, x4, x6
    96b8:      	ldr	w4, [x4]
    96bc:      	sxtw	x4, w4
    96c0:      	cmp	x4, #0x0
    96c4:      	cset	w4, gt
    96c8:      	ubfx	x4, x4, #0, #8
    96cc:      	b	0x982c <_stogir.checked.projection+0x220>
    96d0:      	movz	x4, #0x0, lsl #48
    96d4:      	b	0x96e4 <_stogir.checked.projection+0xd8>
    96d8:      	movz	x4, #0x0, lsl #48
    96dc:      	b	0x96e4 <_stogir.checked.projection+0xd8>
    96e0:      	movz	x4, #0x0, lsl #48
    96e4:      	cmp	x4, #0x0
    96e8:      	b.eq	0x9728 <_stogir.checked.projection+0x11c>
    96ec:      	uxtb	w16, w3
    96f0:      	cmp	w16, wzr
    96f4:      	b.eq	0x970c <_stogir.checked.projection+0x100>
    96f8:      	lsl	x2, x2, #4
    96fc:      	ldr	x3, [x0]
    9700:      	add	x2, x2, x3
    9704:      	ldr	x2, [x2]
    9708:      	b	0x971c <_stogir.checked.projection+0x110>
    970c:      	lsl	x2, x5, #4
    9710:      	ldr	x3, [x0, #0x28]
    9714:      	add	x2, x2, x3
    9718:      	ldr	x2, [x2]
    971c:      	mov	x3, x2
    9720:      	mov	x2, #0x1                ; =1
    9724:      	b	0x9730 <_stogir.checked.projection+0x124>
    9728:      	movz	x2, #0x0, lsl #48
    972c:      	movz	x3, #0x0, lsl #48
    9730:      	lsr	w2, w2, #0
    9734:      	lsr	x16, x2, #0
    9738:      	cmp	x16, #0x1
    973c:      	b.eq	0x9758 <_stogir.checked.projection+0x14c>
    9740:      	b.lo	0x9748 <_stogir.checked.projection+0x13c>
    9744:      	b	0x975c <_stogir.checked.projection+0x150>
    9748:      	cmp	x16, #0x0
    974c:      	b.eq	0x9754 <_stogir.checked.projection+0x148>
    9750:      	b	0x975c <_stogir.checked.projection+0x150>
    9754:      	b	0x9760 <_stogir.checked.projection+0x154>
    9758:      	b	0x97b8 <_stogir.checked.projection+0x1ac>
    975c:      	b	0x9830 <_stogir.checked.projection+0x224>
    9760:      	adrp	x16, 0x9000 <_stogir.vector.memory-inputs+0x4b0>
		0000000000009760:  ARM64_RELOC_PAGE21	l_stogir.424
    9764:      	ldr	x16, [x16]
		0000000000009764:  ARM64_RELOC_PAGEOFF12	l_stogir.424
    9768:      	orr	x0, x16, xzr
    976c:      	mov	x19, x8
    9770:      	mov	x1, x0
    9774:      	mov	x0, #0x1                ; =1
    9778:      	mov	x2, #0x17               ; =23
    977c:      	b	0x9798 <_stogir.checked.projection+0x18c>
    9780:      	adrp	x16, 0x9000 <_stogir.vector.memory-inputs+0x4b0>
		0000000000009780:  ARM64_RELOC_PAGE21	l_stogir.425
    9784:      	ldr	x16, [x16]
		0000000000009784:  ARM64_RELOC_PAGEOFF12	l_stogir.425
    9788:      	orr	x0, x16, xzr
    978c:      	mov	x1, x0
    9790:      	mov	x0, #0x1                ; =1
    9794:      	mov	x2, #0x20               ; =32
    9798:      	str	x0, [x19]
    979c:      	str	x1, [x19, #0x8]
    97a0:      	str	x2, [x19, #0x10]
    97a4:      	ldr	x19, [sp, #0x30]
    97a8:      	ldr	x29, [sp]
    97ac:      	ldr	x30, [sp, #0x8]
    97b0:      	add	sp, sp, #0x40
    97b4:      	ret
    97b8:      	uxtb	w2, w3
    97bc:      	cmp	x2, #0x29
    97c0:      	b.lt	0x9838 <_stogir.checked.projection+0x22c>
    97c4:      	cmp	x2, #0x2b
    97c8:      	b.gt	0x9840 <_stogir.checked.projection+0x234>
    97cc:      	lsr	w1, w1, #0
    97d0:      	mov	x19, x8
    97d4:      	add	x8, sp, #0x10
    97d8:      	bl	0x97d8 <_stogir.checked.projection+0x1cc>
		00000000000097d8:  ARM64_RELOC_BRANCH26	_stogir.checked.validate
    97dc:      	add	x16, sp, #0x10
    97e0:      	ldr	x0, [x16]
    97e4:      	add	x16, sp, #0x10
    97e8:      	ldr	x1, [x16, #0x8]
    97ec:      	add	x16, sp, #0x10
    97f0:      	ldr	x2, [x16, #0x10]
    97f4:      	b	0x9798 <_stogir.checked.projection+0x18c>
    97f8:      	movz	x4, #0x0, lsl #48
    97fc:      	b	0x96dc <_stogir.checked.projection+0xd0>
    9800:      	lsr	w3, w3, #0
    9804:      	ubfx	x0, x3, #8, #8
    9808:      	cmp	x0, #0x0
    980c:      	b.eq	0x9780 <_stogir.checked.projection+0x174>
    9810:      	cmp	x0, #0xd
    9814:      	b.gt	0x9780 <_stogir.checked.projection+0x174>
    9818:      	movz	x0, #0x0, lsl #48
    981c:      	movz	x1, #0x0, lsl #48
    9820:      	movz	x2, #0x0, lsl #48
    9824:      	b	0x9798 <_stogir.checked.projection+0x18c>
    9828:      	movz	x4, #0x0, lsl #48
    982c:      	b	0x96d4 <_stogir.checked.projection+0xc8>
    9830:      	brk	#0
    9834:      	b	0x9830 <_stogir.checked.projection+0x224>
    9838:      	mov	x19, x8
    983c:      	b	0x9800 <_stogir.checked.projection+0x1f4>
    9840:      	mov	x19, x8
    9844:      	b	0x9800 <_stogir.checked.projection+0x1f4>

0000000000009848 <_stogir.checked.operands>:
    9848:      	sub	sp, sp, #0x30
    984c:      	str	x19, [sp, #0x20]
    9850:      	str	x20, [sp, #0x28]
    9854:      	sxtw	x1, w1
    9858:      	sxtw	x2, w2
    985c:      	cmp	x1, #0x29
    9860:      	b.lt	0x98a8 <_stogir.checked.operands+0x60>
    9864:      	cmp	x1, #0x2b
    9868:      	b.gt	0x98a8 <_stogir.checked.operands+0x60>
    986c:      	cmp	x2, #0x1
    9870:      	b.lt	0x98a8 <_stogir.checked.operands+0x60>
    9874:      	cmp	x2, #0xb
    9878:      	b.gt	0x98a8 <_stogir.checked.operands+0x60>
    987c:      	cmp	x2, #0x1
    9880:      	b.eq	0x98a8 <_stogir.checked.operands+0x60>
    9884:      	adrp	x16, 0x9000 <_stogir.vector.memory-inputs+0x4b0>
		0000000000009884:  ARM64_RELOC_PAGE21	l_stogir.426
    9888:      	ldr	x16, [x16]
		0000000000009888:  ARM64_RELOC_PAGEOFF12	l_stogir.426
    988c:      	orr	x1, x16, xzr
    9890:      	movz	x5, #0x0, lsl #48
    9894:      	b	0x98b8 <_stogir.checked.operands+0x70>
    9898:      	movz	x14, #0x0, lsl #48
    989c:      	b	0x991c <_stogir.checked.operands+0xd4>
    98a0:      	movz	x14, #0x0, lsl #48
    98a4:      	b	0x9930 <_stogir.checked.operands+0xe8>
    98a8:      	adrp	x16, 0x9000 <_stogir.vector.memory-inputs+0x4b0>
		00000000000098a8:  ARM64_RELOC_PAGE21	l_stogir.427
    98ac:      	ldr	x16, [x16]
		00000000000098ac:  ARM64_RELOC_PAGEOFF12	l_stogir.427
    98b0:      	orr	x1, x16, xzr
    98b4:      	mov	x5, #0x36               ; =54
    98b8:      	add	x16, sp, #0x10
    98bc:      	orr	x6, x16, xzr
    98c0:      	adrp	x16, 0x9000 <_stogir.vector.memory-inputs+0x4b0>
		00000000000098c0:  ARM64_RELOC_PAGE21	l_stogir.428
    98c4:      	ldr	x16, [x16]
		00000000000098c4:  ARM64_RELOC_PAGEOFF12	l_stogir.428
    98c8:      	orr	x7, x16, xzr
    98cc:      	adrp	x16, 0x9000 <_stogir.vector.memory-inputs+0x4b0>
		00000000000098cc:  ARM64_RELOC_PAGE21	l_stogir.429
    98d0:      	ldr	x16, [x16]
		00000000000098d0:  ARM64_RELOC_PAGEOFF12	l_stogir.429
    98d4:      	orr	x9, x16, xzr
    98d8:      	lsr	w3, w3, #0
    98dc:      	lsr	w4, w4, #0
    98e0:      	add	x10, x0, #0x78
    98e4:      	add	x11, x0, #0x28
    98e8:      	add	x12, x0, #0x50
    98ec:      	mov	x16, sp
    98f0:      	str	w3, [x16]
    98f4:      	mov	x16, sp
    98f8:      	str	w4, [x16, #0x4]
    98fc:      	mov	x16, sp
    9900:      	ldr	x3, [x16]
    9904:      	add	x16, sp, #0x10
    9908:      	str	x3, [x16]
    990c:      	mov	x3, x5
    9910:      	movz	x4, #0x0, lsl #48
    9914:      	b	0x99e0 <_stogir.checked.operands+0x198>
    9918:      	movz	x14, #0x0, lsl #48
    991c:      	fmov	d31, x13
    9920:      	mov	x13, x14
    9924:      	fmov	x14, d31
    9928:      	b	0x993c <_stogir.checked.operands+0xf4>
    992c:      	movz	x14, #0x0, lsl #48
    9930:      	fmov	d31, x13
    9934:      	mov	x13, x14
    9938:      	fmov	x14, d31
    993c:      	cmp	x13, #0x0
    9940:      	b.eq	0x9980 <_stogir.checked.operands+0x138>
    9944:      	uxtb	w16, w4
    9948:      	cmp	w16, wzr
    994c:      	b.eq	0x9964 <_stogir.checked.operands+0x11c>
    9950:      	lsl	x4, x5, #4
    9954:      	ldr	x5, [x0]
    9958:      	add	x4, x4, x5
    995c:      	ldr	x4, [x4]
    9960:      	b	0x9974 <_stogir.checked.operands+0x12c>
    9964:      	lsl	x4, x15, #4
    9968:      	ldr	x5, [x0, #0x28]
    996c:      	add	x4, x4, x5
    9970:      	ldr	x4, [x4]
    9974:      	mov	x5, x4
    9978:      	mov	x4, #0x1                ; =1
    997c:      	b	0x9988 <_stogir.checked.operands+0x140>
    9980:      	movz	x4, #0x0, lsl #48
    9984:      	movz	x5, #0x0, lsl #48
    9988:      	lsr	w4, w4, #0
    998c:      	lsr	x16, x4, #0
    9990:      	cmp	x16, #0x1
    9994:      	b.eq	0x99b0 <_stogir.checked.operands+0x168>
    9998:      	b.lo	0x99a0 <_stogir.checked.operands+0x158>
    999c:      	b	0x99b4 <_stogir.checked.operands+0x16c>
    99a0:      	cmp	x16, #0x0
    99a4:      	b.eq	0x99ac <_stogir.checked.operands+0x164>
    99a8:      	b	0x99b4 <_stogir.checked.operands+0x16c>
    99ac:      	b	0x99b8 <_stogir.checked.operands+0x170>
    99b0:      	b	0x99c4 <_stogir.checked.operands+0x17c>
    99b4:      	b	0x9b44 <_stogir.checked.operands+0x2fc>
    99b8:      	mov	x1, x7
    99bc:      	mov	x3, #0x22               ; =34
    99c0:      	b	0x99dc <_stogir.checked.operands+0x194>
    99c4:      	lsr	w5, w5, #0
    99c8:      	ubfx	x4, x5, #8, #8
    99cc:      	cmp	x4, x2
    99d0:      	b.eq	0x99dc <_stogir.checked.operands+0x194>
    99d4:      	mov	x1, x9
    99d8:      	mov	x3, #0x28               ; =40
    99dc:      	mov	x4, x14
    99e0:      	cmp	x4, #0x2
    99e4:      	b.ge	0x9a10 <_stogir.checked.operands+0x1c8>
    99e8:      	add	x5, x4, #0x1
    99ec:      	lsl	x4, x4, #2
    99f0:      	add	x4, x4, x6
    99f4:      	ldr	w4, [x4]
    99f8:      	sxtw	x4, w4
    99fc:      	and	x4, x4, #0xffffffff
    9a00:      	mov	x13, x5
    9a04:      	mov	x5, x4
    9a08:      	mov	x4, #0x1                ; =1
    9a0c:      	b	0x9a1c <_stogir.checked.operands+0x1d4>
    9a10:      	mov	x13, x4
    9a14:      	movz	x4, #0x0, lsl #48
    9a18:      	movz	x5, #0x0, lsl #48
    9a1c:      	lsr	w4, w4, #0
    9a20:      	lsr	x16, x4, #0
    9a24:      	cmp	x16, #0x1
    9a28:      	b.eq	0x9a44 <_stogir.checked.operands+0x1fc>
    9a2c:      	b.lo	0x9a34 <_stogir.checked.operands+0x1ec>
    9a30:      	b	0x9a48 <_stogir.checked.operands+0x200>
    9a34:      	cmp	x16, #0x0
    9a38:      	b.eq	0x9a40 <_stogir.checked.operands+0x1f8>
    9a3c:      	b	0x9a48 <_stogir.checked.operands+0x200>
    9a40:      	b	0x9ab0 <_stogir.checked.operands+0x268>
    9a44:      	b	0x9a4c <_stogir.checked.operands+0x204>
    9a48:      	b	0x9b3c <_stogir.checked.operands+0x2f4>
    9a4c:      	lsr	w5, w5, #0
    9a50:      	sxtw	x5, w5
    9a54:      	cmp	x5, #0x0
    9a58:      	cset	w4, gt
    9a5c:      	movz	x16, #0x0, lsl #48
    9a60:      	sub	x14, x16, x5
    9a64:      	sub	x15, x14, #0x1
    9a68:      	uxtb	w16, w4
    9a6c:      	cmp	w16, wzr
    9a70:      	b.eq	0x9af0 <_stogir.checked.operands+0x2a8>
    9a74:      	ldr	x14, [x0, #0x8]
    9a78:      	cmp	x5, x14
    9a7c:      	b.ge	0x9918 <_stogir.checked.operands+0xd0>
    9a80:      	ldr	x14, [x10, #0x8]
    9a84:      	cmp	x5, x14
    9a88:      	b.ge	0x9898 <_stogir.checked.operands+0x50>
    9a8c:      	lsl	x14, x5, #2
    9a90:      	ldr	x19, [x0, #0x78]
    9a94:      	add	x14, x14, x19
    9a98:      	ldr	w14, [x14]
    9a9c:      	sxtw	x14, w14
    9aa0:      	cmp	x14, #0x0
    9aa4:      	cset	w14, ge
    9aa8:      	ubfx	x14, x14, #0, #8
    9aac:      	b	0x989c <_stogir.checked.operands+0x54>
    9ab0:      	cmp	x3, #0x0
    9ab4:      	b.ne	0x9acc <_stogir.checked.operands+0x284>
    9ab8:      	and	x0, x2, #0xffffffff
    9abc:      	mov	x1, x0
    9ac0:      	movz	x0, #0x0, lsl #48
    9ac4:      	movz	x2, #0x0, lsl #48
    9ac8:      	b	0x9ad4 <_stogir.checked.operands+0x28c>
    9acc:      	mov	x2, x3
    9ad0:      	mov	x0, #0x1                ; =1
    9ad4:      	str	x0, [x8]
    9ad8:      	str	x1, [x8, #0x8]
    9adc:      	str	x2, [x8, #0x10]
    9ae0:      	ldr	x19, [sp, #0x20]
    9ae4:      	ldr	x20, [sp, #0x28]
    9ae8:      	add	sp, sp, #0x30
    9aec:      	ret
    9af0:      	cmp	x5, #0x0
    9af4:      	b.ge	0x992c <_stogir.checked.operands+0xe4>
    9af8:      	ldr	x19, [x11, #0x8]
    9afc:      	ldr	x20, [x12, #0x8]
    9b00:      	cmp	x19, x20
    9b04:      	b.ne	0x98a0 <_stogir.checked.operands+0x58>
    9b08:      	cmp	x14, x19
    9b0c:      	b.gt	0x9b34 <_stogir.checked.operands+0x2ec>
    9b10:      	lsl	x14, x15, #2
    9b14:      	ldr	x19, [x0, #0x50]
    9b18:      	add	x14, x14, x19
    9b1c:      	ldr	w14, [x14]
    9b20:      	sxtw	x14, w14
    9b24:      	cmp	x14, #0x0
    9b28:      	cset	w14, gt
    9b2c:      	ubfx	x14, x14, #0, #8
    9b30:      	b	0x9b38 <_stogir.checked.operands+0x2f0>
    9b34:      	movz	x14, #0x0, lsl #48
    9b38:      	b	0x98a4 <_stogir.checked.operands+0x5c>
    9b3c:      	brk	#0
    9b40:      	b	0x9b3c <_stogir.checked.operands+0x2f4>
    9b44:      	brk	#0
    9b48:      	b	0x9b44 <_stogir.checked.operands+0x2fc>

0000000000009b4c <_stogir.opcode.control?>:
    9b4c:      	sxtw	x0, w0
    9b50:      	cmp	x0, #0x0
    9b54:      	b.lt	0x9b7c <_stogir.opcode.control?+0x30>
    9b58:      	cmp	x0, #0x83
    9b5c:      	b.ge	0x9b7c <_stogir.opcode.control?+0x30>
    9b60:      	adrp	x16, 0x9000 <_stogir.vector.memory-inputs+0x4b0>
		0000000000009b60:  ARM64_RELOC_PAGE21	l_stogir.430
    9b64:      	ldr	x16, [x16]
		0000000000009b64:  ARM64_RELOC_PAGEOFF12	l_stogir.430
    9b68:      	orr	x1, x16, xzr
    9b6c:      	lsr	x0, x0, #0
    9b70:      	add	x0, x0, x1
    9b74:      	ldrb	w0, [x0]
    9b78:      	b	0x9b80 <_stogir.opcode.control?+0x34>
    9b7c:      	movz	x0, #0x0, lsl #48
    9b80:      	uxtb	w0, w0
    9b84:      	and	x0, x0, #0x1
    9b88:      	uxtb	w0, w0
    9b8c:      	ret

0000000000009b90 <_stogir.opcode.block-end?>:
    9b90:      	sxtw	x0, w0
    9b94:      	cmp	x0, #0x0
    9b98:      	b.lt	0x9bc0 <_stogir.opcode.block-end?+0x30>
    9b9c:      	cmp	x0, #0x83
    9ba0:      	b.ge	0x9bc0 <_stogir.opcode.block-end?+0x30>
    9ba4:      	adrp	x16, 0x9000 <_stogir.vector.memory-inputs+0x4b0>
		0000000000009ba4:  ARM64_RELOC_PAGE21	l_stogir.431
    9ba8:      	ldr	x16, [x16]
		0000000000009ba8:  ARM64_RELOC_PAGEOFF12	l_stogir.431
    9bac:      	orr	x1, x16, xzr
    9bb0:      	lsr	x0, x0, #0
    9bb4:      	add	x0, x0, x1
    9bb8:      	ldrb	w0, [x0]
    9bbc:      	b	0x9bc4 <_stogir.opcode.block-end?+0x34>
    9bc0:      	movz	x0, #0x0, lsl #48
    9bc4:      	uxtb	w0, w0
    9bc8:      	and	x0, x0, #0x4
    9bcc:      	uxtb	w0, w0
    9bd0:      	cmp	x0, #0x0
    9bd4:      	cset	w0, eq
    9bd8:      	uxtb	w16, w0
    9bdc:      	cmp	w16, wzr
    9be0:      	cset	x0, eq
    9be4:      	ret

0000000000009be8 <_stogir.atomic.ordinary?>:
    9be8:      	sxtw	x1, w1
    9bec:      	cmp	x1, #0x0
    9bf0:      	cset	w3, gt
    9bf4:      	movz	x16, #0x0, lsl #48
    9bf8:      	sub	x4, x16, x1
    9bfc:      	sub	x5, x4, #0x1
    9c00:      	uxtb	w16, w3
    9c04:      	cmp	w16, wzr
    9c08:      	b.eq	0x9c4c <_stogir.atomic.ordinary?+0x64>
    9c0c:      	ldr	x4, [x0, #0x8]
    9c10:      	cmp	x1, x4
    9c14:      	b.ge	0x9ca0 <_stogir.atomic.ordinary?+0xb8>
    9c18:      	add	x4, x0, #0x78
    9c1c:      	ldr	x4, [x4, #0x8]
    9c20:      	cmp	x1, x4
    9c24:      	b.ge	0x9d60 <_stogir.atomic.ordinary?+0x178>
    9c28:      	lsl	x4, x1, #2
    9c2c:      	ldr	x6, [x0, #0x78]
    9c30:      	add	x4, x4, x6
    9c34:      	ldr	w4, [x4]
    9c38:      	sxtw	x4, w4
    9c3c:      	cmp	x4, #0x0
    9c40:      	cset	w4, ge
    9c44:      	ubfx	x4, x4, #0, #8
    9c48:      	b	0x9d64 <_stogir.atomic.ordinary?+0x17c>
    9c4c:      	cmp	x1, #0x0
    9c50:      	b.ge	0x9ca8 <_stogir.atomic.ordinary?+0xc0>
    9c54:      	add	x6, x0, #0x28
    9c58:      	add	x7, x0, #0x50
    9c5c:      	ldr	x6, [x6, #0x8]
    9c60:      	ldr	x7, [x7, #0x8]
    9c64:      	cmp	x6, x7
    9c68:      	b.ne	0x9c98 <_stogir.atomic.ordinary?+0xb0>
    9c6c:      	cmp	x4, x6
    9c70:      	b.gt	0x9d80 <_stogir.atomic.ordinary?+0x198>
    9c74:      	lsl	x4, x5, #2
    9c78:      	ldr	x6, [x0, #0x50]
    9c7c:      	add	x4, x4, x6
    9c80:      	ldr	w4, [x4]
    9c84:      	sxtw	x4, w4
    9c88:      	cmp	x4, #0x0
    9c8c:      	cset	w4, gt
    9c90:      	ubfx	x4, x4, #0, #8
    9c94:      	b	0x9d84 <_stogir.atomic.ordinary?+0x19c>
    9c98:      	movz	x4, #0x0, lsl #48
    9c9c:      	b	0x9cac <_stogir.atomic.ordinary?+0xc4>
    9ca0:      	movz	x4, #0x0, lsl #48
    9ca4:      	b	0x9cac <_stogir.atomic.ordinary?+0xc4>
    9ca8:      	movz	x4, #0x0, lsl #48
    9cac:      	cmp	x4, #0x0
    9cb0:      	b.eq	0x9cf0 <_stogir.atomic.ordinary?+0x108>
    9cb4:      	uxtb	w16, w3
    9cb8:      	cmp	w16, wzr
    9cbc:      	b.eq	0x9cd4 <_stogir.atomic.ordinary?+0xec>
    9cc0:      	lsl	x1, x1, #4
    9cc4:      	ldr	x0, [x0]
    9cc8:      	add	x0, x1, x0
    9ccc:      	ldr	x0, [x0]
    9cd0:      	b	0x9ce4 <_stogir.atomic.ordinary?+0xfc>
    9cd4:      	lsl	x1, x5, #4
    9cd8:      	ldr	x0, [x0, #0x28]
    9cdc:      	add	x0, x1, x0
    9ce0:      	ldr	x0, [x0]
    9ce4:      	mov	x1, x0
    9ce8:      	mov	x0, #0x1                ; =1
    9cec:      	b	0x9cf8 <_stogir.atomic.ordinary?+0x110>
    9cf0:      	movz	x0, #0x0, lsl #48
    9cf4:      	movz	x1, #0x0, lsl #48
    9cf8:      	lsr	w0, w0, #0
    9cfc:      	lsr	x16, x0, #0
    9d00:      	cmp	x16, #0x1
    9d04:      	b.eq	0x9d20 <_stogir.atomic.ordinary?+0x138>
    9d08:      	b.lo	0x9d10 <_stogir.atomic.ordinary?+0x128>
    9d0c:      	b	0x9d24 <_stogir.atomic.ordinary?+0x13c>
    9d10:      	cmp	x16, #0x0
    9d14:      	b.eq	0x9d1c <_stogir.atomic.ordinary?+0x134>
    9d18:      	b	0x9d24 <_stogir.atomic.ordinary?+0x13c>
    9d1c:      	b	0x9d28 <_stogir.atomic.ordinary?+0x140>
    9d20:      	b	0x9d38 <_stogir.atomic.ordinary?+0x150>
    9d24:      	b	0x9d88 <_stogir.atomic.ordinary?+0x1a0>
    9d28:      	movz	x0, #0x0, lsl #48
    9d2c:      	b	0x9d34 <_stogir.atomic.ordinary?+0x14c>
    9d30:      	movz	x0, #0x0, lsl #48
    9d34:      	ret
    9d38:      	sxtw	x2, w2
    9d3c:      	lsr	w0, w1, #0
    9d40:      	ubfx	x0, x0, #8, #8
    9d44:      	cmp	x0, x2
    9d48:      	b.ne	0x9d30 <_stogir.atomic.ordinary?+0x148>
    9d4c:      	uxtb	w1, w1
    9d50:      	cmp	x1, #0x46
    9d54:      	b.ne	0x9d68 <_stogir.atomic.ordinary?+0x180>
    9d58:      	movz	x0, #0x0, lsl #48
    9d5c:      	b	0x9d7c <_stogir.atomic.ordinary?+0x194>
    9d60:      	movz	x4, #0x0, lsl #48
    9d64:      	b	0x9ca4 <_stogir.atomic.ordinary?+0xbc>
    9d68:      	cmp	x1, #0x48
    9d6c:      	cset	w0, eq
    9d70:      	uxtb	w16, w0
    9d74:      	cmp	w16, wzr
    9d78:      	cset	x0, eq
    9d7c:      	b	0x9d34 <_stogir.atomic.ordinary?+0x14c>
    9d80:      	movz	x4, #0x0, lsl #48
    9d84:      	b	0x9c9c <_stogir.atomic.ordinary?+0xb4>
    9d88:      	brk	#0
    9d8c:      	b	0x9d88 <_stogir.atomic.ordinary?+0x1a0>

0000000000009d90 <_stogir.types.scalar-size>:
    9d90:      	sxtw	x1, w1
    9d94:      	cmp	x1, #0x4
    9d98:      	b.eq	0x9dac <_stogir.types.scalar-size+0x1c>
    9d9c:      	cmp	x1, #0x8
    9da0:      	b.eq	0x9dac <_stogir.types.scalar-size+0x1c>
    9da4:      	movn	x0, #0x0, lsl #48
    9da8:      	b	0x9dc4 <_stogir.types.scalar-size+0x34>
    9dac:      	sxtw	x0, w0
    9db0:      	cmp	x0, #0x0
    9db4:      	b.ne	0x9dc8 <_stogir.types.scalar-size+0x38>
    9db8:      	movz	x0, #0x0, lsl #48
    9dbc:      	b	0x9dc4 <_stogir.types.scalar-size+0x34>
    9dc0:      	mov	x0, #0x1                ; =1
    9dc4:      	ret
    9dc8:      	cmp	x0, #0x1
    9dcc:      	b.eq	0x9dc0 <_stogir.types.scalar-size+0x30>
    9dd0:      	cmp	x0, #0x2
    9dd4:      	b.eq	0x9dc0 <_stogir.types.scalar-size+0x30>
    9dd8:      	cmp	x0, #0x7
    9ddc:      	b.eq	0x9dc0 <_stogir.types.scalar-size+0x30>
    9de0:      	cmp	x0, #0x8
    9de4:      	b.eq	0x9dc0 <_stogir.types.scalar-size+0x30>
    9de8:      	cmp	x0, #0x3
    9dec:      	b.eq	0x9e38 <_stogir.types.scalar-size+0xa8>
    9df0:      	cmp	x0, #0x9
    9df4:      	b.eq	0x9e38 <_stogir.types.scalar-size+0xa8>
    9df8:      	cmp	x0, #0x4
    9dfc:      	b.eq	0x9e40 <_stogir.types.scalar-size+0xb0>
    9e00:      	cmp	x0, #0xa
    9e04:      	b.eq	0x9e40 <_stogir.types.scalar-size+0xb0>
    9e08:      	cmp	x0, #0xd
    9e0c:      	b.eq	0x9e40 <_stogir.types.scalar-size+0xb0>
    9e10:      	cmp	x0, #0x5
    9e14:      	b.eq	0x9e48 <_stogir.types.scalar-size+0xb8>
    9e18:      	cmp	x0, #0xb
    9e1c:      	b.eq	0x9e48 <_stogir.types.scalar-size+0xb8>
    9e20:      	cmp	x0, #0xc
    9e24:      	b.eq	0x9e48 <_stogir.types.scalar-size+0xb8>
    9e28:      	cmp	x0, #0x6
    9e2c:      	b.ne	0x9e50 <_stogir.types.scalar-size+0xc0>
    9e30:      	mov	x0, x1
    9e34:      	b	0x9e54 <_stogir.types.scalar-size+0xc4>
    9e38:      	mov	x0, #0x2                ; =2
    9e3c:      	b	0x9dc4 <_stogir.types.scalar-size+0x34>
    9e40:      	mov	x0, #0x4                ; =4
    9e44:      	b	0x9e3c <_stogir.types.scalar-size+0xac>
    9e48:      	mov	x0, #0x8                ; =8
    9e4c:      	b	0x9e44 <_stogir.types.scalar-size+0xb4>
    9e50:      	movn	x0, #0x0, lsl #48
    9e54:      	b	0x9e4c <_stogir.types.scalar-size+0xbc>

0000000000009e58 <_stogir.terminal.inputs>:
    9e58:      	sxtw	x1, w1
    9e5c:      	cmp	x1, #0x60
    9e60:      	cset	w4, eq
    9e64:      	uxtb	w16, w4
    9e68:      	cmp	w16, wzr
    9e6c:      	b.ne	0x9ea0 <_stogir.terminal.inputs+0x48>
    9e70:      	cmp	x1, #0x79
    9e74:      	b.eq	0x9ea0 <_stogir.terminal.inputs+0x48>
    9e78:      	adrp	x16, 0x9000 <_stogir.vector.memory-inputs+0x4b0>
		0000000000009e78:  ARM64_RELOC_PAGE21	l_stogir.432
    9e7c:      	ldr	x16, [x16]
		0000000000009e7c:  ARM64_RELOC_PAGEOFF12	l_stogir.432
    9e80:      	orr	x0, x16, xzr
    9e84:      	mov	x1, x0
    9e88:      	mov	x0, #0x1                ; =1
    9e8c:      	mov	x2, #0x25               ; =37
    9e90:      	str	x0, [x8]
    9e94:      	str	x1, [x8, #0x8]
    9e98:      	str	x2, [x8, #0x10]
    9e9c:      	ret
    9ea0:      	sxtw	x3, w3
    9ea4:      	uxtb	w16, w4
    9ea8:      	cmp	w16, wzr
    9eac:      	b.eq	0x9eb8 <_stogir.terminal.inputs+0x60>
    9eb0:      	cmp	x3, #0x0
    9eb4:      	b.ne	0x9e78 <_stogir.terminal.inputs+0x20>
    9eb8:      	sxtw	x2, w2
    9ebc:      	cmp	x2, #0x0
    9ec0:      	cset	w1, gt
    9ec4:      	movz	x16, #0x0, lsl #48
    9ec8:      	sub	x4, x16, x2
    9ecc:      	sub	x5, x4, #0x1
    9ed0:      	uxtb	w16, w1
    9ed4:      	cmp	w16, wzr
    9ed8:      	b.eq	0x9fc0 <_stogir.terminal.inputs+0x168>
    9edc:      	ldr	x4, [x0, #0x8]
    9ee0:      	cmp	x2, x4
    9ee4:      	b.ge	0x9fb8 <_stogir.terminal.inputs+0x160>
    9ee8:      	add	x4, x0, #0x78
    9eec:      	ldr	x4, [x4, #0x8]
    9ef0:      	cmp	x2, x4
    9ef4:      	b.ge	0xa068 <_stogir.terminal.inputs+0x210>
    9ef8:      	lsl	x4, x2, #2
    9efc:      	ldr	x6, [x0, #0x78]
    9f00:      	add	x4, x4, x6
    9f04:      	ldr	w4, [x4]
    9f08:      	sxtw	x4, w4
    9f0c:      	cmp	x4, #0x0
    9f10:      	cset	w4, ge
    9f14:      	ubfx	x4, x4, #0, #8
    9f18:      	b	0xa06c <_stogir.terminal.inputs+0x214>
    9f1c:      	movz	x1, #0x0, lsl #48
    9f20:      	movz	x4, #0x0, lsl #48
    9f24:      	lsr	w1, w1, #0
    9f28:      	lsr	x16, x1, #0
    9f2c:      	cmp	x16, #0x1
    9f30:      	b.eq	0x9f4c <_stogir.terminal.inputs+0xf4>
    9f34:      	b.lo	0x9f3c <_stogir.terminal.inputs+0xe4>
    9f38:      	b	0x9f50 <_stogir.terminal.inputs+0xf8>
    9f3c:      	cmp	x16, #0x0
    9f40:      	b.eq	0x9f48 <_stogir.terminal.inputs+0xf0>
    9f44:      	b	0x9f50 <_stogir.terminal.inputs+0xf8>
    9f48:      	b	0x9f54 <_stogir.terminal.inputs+0xfc>
    9f4c:      	b	0xa00c <_stogir.terminal.inputs+0x1b4>
    9f50:      	b	0xa1c0 <_stogir.terminal.inputs+0x368>
    9f54:      	adrp	x16, 0x9000 <_stogir.vector.memory-inputs+0x4b0>
		0000000000009f54:  ARM64_RELOC_PAGE21	l_stogir.433
    9f58:      	ldr	x16, [x16]
		0000000000009f58:  ARM64_RELOC_PAGEOFF12	l_stogir.433
    9f5c:      	orr	x0, x16, xzr
    9f60:      	mov	x1, x0
    9f64:      	mov	x0, #0x1                ; =1
    9f68:      	mov	x2, #0x1d               ; =29
    9f6c:      	b	0x9e90 <_stogir.terminal.inputs+0x38>
    9f70:      	lsl	x1, x5, #4
    9f74:      	ldr	x4, [x0, #0x28]
    9f78:      	add	x1, x1, x4
    9f7c:      	ldr	x1, [x1]
    9f80:      	mov	x4, x1
    9f84:      	mov	x1, #0x1                ; =1
    9f88:      	b	0x9f24 <_stogir.terminal.inputs+0xcc>
    9f8c:      	movz	x4, #0x0, lsl #48
    9f90:      	cmp	x4, #0x0
    9f94:      	b.eq	0x9f1c <_stogir.terminal.inputs+0xc4>
    9f98:      	uxtb	w16, w1
    9f9c:      	cmp	w16, wzr
    9fa0:      	b.eq	0x9f70 <_stogir.terminal.inputs+0x118>
    9fa4:      	lsl	x1, x2, #4
    9fa8:      	ldr	x4, [x0]
    9fac:      	add	x1, x1, x4
    9fb0:      	ldr	x1, [x1]
    9fb4:      	b	0x9f80 <_stogir.terminal.inputs+0x128>
    9fb8:      	movz	x4, #0x0, lsl #48
    9fbc:      	b	0x9f90 <_stogir.terminal.inputs+0x138>
    9fc0:      	cmp	x2, #0x0
    9fc4:      	b.ge	0x9f8c <_stogir.terminal.inputs+0x134>
    9fc8:      	add	x6, x0, #0x28
    9fcc:      	add	x7, x0, #0x50
    9fd0:      	ldr	x6, [x6, #0x8]
    9fd4:      	ldr	x7, [x7, #0x8]
    9fd8:      	cmp	x6, x7
    9fdc:      	b.ne	0xa060 <_stogir.terminal.inputs+0x208>
    9fe0:      	cmp	x4, x6
    9fe4:      	b.gt	0xa070 <_stogir.terminal.inputs+0x218>
    9fe8:      	lsl	x4, x5, #2
    9fec:      	ldr	x6, [x0, #0x50]
    9ff0:      	add	x4, x4, x6
    9ff4:      	ldr	w4, [x4]
    9ff8:      	sxtw	x4, w4
    9ffc:      	cmp	x4, #0x0
    a000:      	cset	w4, gt
    a004:      	ubfx	x4, x4, #0, #8
    a008:      	b	0xa074 <_stogir.terminal.inputs+0x21c>
    a00c:      	cmp	x2, #0x0
    a010:      	b.le	0xa044 <_stogir.terminal.inputs+0x1ec>
    a014:      	uxtb	w4, w4
    a018:      	cmp	x4, #0x83
    a01c:      	cset	w1, lt
    a020:      	uxtb	w16, w1
    a024:      	cmp	w16, wzr
    a028:      	b.eq	0xa078 <_stogir.terminal.inputs+0x220>
    a02c:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0x1a8>
		000000000000a02c:  ARM64_RELOC_PAGE21	l_stogir.434
    a030:      	ldr	x16, [x16]
		000000000000a030:  ARM64_RELOC_PAGEOFF12	l_stogir.434
    a034:      	orr	x2, x16, xzr
    a038:      	add	x2, x4, x2
    a03c:      	ldrb	w2, [x2]
    a040:      	b	0xa07c <_stogir.terminal.inputs+0x224>
    a044:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0x1a8>
		000000000000a044:  ARM64_RELOC_PAGE21	l_stogir.435
    a048:      	ldr	x16, [x16]
		000000000000a048:  ARM64_RELOC_PAGEOFF12	l_stogir.435
    a04c:      	orr	x0, x16, xzr
    a050:      	mov	x1, x0
    a054:      	mov	x0, #0x1                ; =1
    a058:      	mov	x2, #0x2c               ; =44
    a05c:      	b	0x9f6c <_stogir.terminal.inputs+0x114>
    a060:      	movz	x4, #0x0, lsl #48
    a064:      	b	0x9f90 <_stogir.terminal.inputs+0x138>
    a068:      	movz	x4, #0x0, lsl #48
    a06c:      	b	0x9fbc <_stogir.terminal.inputs+0x164>
    a070:      	movz	x4, #0x0, lsl #48
    a074:      	b	0xa064 <_stogir.terminal.inputs+0x20c>
    a078:      	movz	x2, #0x0, lsl #48
    a07c:      	uxtb	w2, w2
    a080:      	and	x2, x2, #0x1
    a084:      	uxtb	w2, w2
    a088:      	cmp	x2, #0x0
    a08c:      	b.eq	0xa044 <_stogir.terminal.inputs+0x1ec>
    a090:      	uxtb	w16, w1
    a094:      	cmp	w16, wzr
    a098:      	b.eq	0xa0b4 <_stogir.terminal.inputs+0x25c>
    a09c:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0x1a8>
		000000000000a09c:  ARM64_RELOC_PAGE21	l_stogir.434
    a0a0:      	ldr	x16, [x16]
		000000000000a0a0:  ARM64_RELOC_PAGEOFF12	l_stogir.434
    a0a4:      	orr	x1, x16, xzr
    a0a8:      	add	x1, x4, x1
    a0ac:      	ldrb	w1, [x1]
    a0b0:      	b	0xa0b8 <_stogir.terminal.inputs+0x260>
    a0b4:      	movz	x1, #0x0, lsl #48
    a0b8:      	uxtb	w1, w1
    a0bc:      	and	x1, x1, #0x4
    a0c0:      	uxtb	w1, w1
    a0c4:      	cmp	x1, #0x0
    a0c8:      	cset	w1, eq
    a0cc:      	uxtb	w16, w1
    a0d0:      	cmp	w16, wzr
    a0d4:      	cset	x1, eq
    a0d8:      	cmp	x1, #0x0
    a0dc:      	b.ne	0xa044 <_stogir.terminal.inputs+0x1ec>
    a0e0:      	cmp	x3, #0x0
    a0e4:      	b.ne	0xa0f8 <_stogir.terminal.inputs+0x2a0>
    a0e8:      	movz	x0, #0x0, lsl #48
    a0ec:      	movz	x1, #0x0, lsl #48
    a0f0:      	movz	x2, #0x0, lsl #48
    a0f4:      	b	0xa05c <_stogir.terminal.inputs+0x204>
    a0f8:      	cmp	x3, #0x0
    a0fc:      	cset	w1, gt
    a100:      	movz	x16, #0x0, lsl #48
    a104:      	sub	x2, x16, x3
    a108:      	sub	x4, x2, #0x1
    a10c:      	uxtb	w16, w1
    a110:      	cmp	w16, wzr
    a114:      	b.eq	0xa174 <_stogir.terminal.inputs+0x31c>
    a118:      	ldr	x2, [x0, #0x8]
    a11c:      	cmp	x3, x2
    a120:      	b.ge	0xa1c8 <_stogir.terminal.inputs+0x370>
    a124:      	add	x2, x0, #0x78
    a128:      	ldr	x2, [x2, #0x8]
    a12c:      	cmp	x3, x2
    a130:      	b.ge	0xa2a0 <_stogir.terminal.inputs+0x448>
    a134:      	lsl	x2, x3, #2
    a138:      	ldr	x5, [x0, #0x78]
    a13c:      	add	x2, x2, x5
    a140:      	ldr	w2, [x2]
    a144:      	sxtw	x2, w2
    a148:      	cmp	x2, #0x0
    a14c:      	cset	w2, ge
    a150:      	ubfx	x2, x2, #0, #8
    a154:      	b	0xa2a4 <_stogir.terminal.inputs+0x44c>
    a158:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0x1a8>
		000000000000a158:  ARM64_RELOC_PAGE21	l_stogir.436
    a15c:      	ldr	x16, [x16]
		000000000000a15c:  ARM64_RELOC_PAGEOFF12	l_stogir.436
    a160:      	orr	x0, x16, xzr
    a164:      	mov	x1, x0
    a168:      	mov	x0, #0x1                ; =1
    a16c:      	mov	x2, #0x2e               ; =46
    a170:      	b	0xa0f4 <_stogir.terminal.inputs+0x29c>
    a174:      	cmp	x3, #0x0
    a178:      	b.ge	0xa1d0 <_stogir.terminal.inputs+0x378>
    a17c:      	add	x5, x0, #0x28
    a180:      	add	x6, x0, #0x50
    a184:      	ldr	x5, [x5, #0x8]
    a188:      	ldr	x6, [x6, #0x8]
    a18c:      	cmp	x5, x6
    a190:      	b.ne	0xa298 <_stogir.terminal.inputs+0x440>
    a194:      	cmp	x2, x5
    a198:      	b.gt	0xa2a8 <_stogir.terminal.inputs+0x450>
    a19c:      	lsl	x2, x4, #2
    a1a0:      	ldr	x5, [x0, #0x50]
    a1a4:      	add	x2, x2, x5
    a1a8:      	ldr	w2, [x2]
    a1ac:      	sxtw	x2, w2
    a1b0:      	cmp	x2, #0x0
    a1b4:      	cset	w2, gt
    a1b8:      	ubfx	x2, x2, #0, #8
    a1bc:      	b	0xa2ac <_stogir.terminal.inputs+0x454>
    a1c0:      	brk	#0
    a1c4:      	b	0xa1c0 <_stogir.terminal.inputs+0x368>
    a1c8:      	movz	x2, #0x0, lsl #48
    a1cc:      	b	0xa1d4 <_stogir.terminal.inputs+0x37c>
    a1d0:      	movz	x2, #0x0, lsl #48
    a1d4:      	cmp	x2, #0x0
    a1d8:      	b.eq	0xa218 <_stogir.terminal.inputs+0x3c0>
    a1dc:      	uxtb	w16, w1
    a1e0:      	cmp	w16, wzr
    a1e4:      	b.eq	0xa1fc <_stogir.terminal.inputs+0x3a4>
    a1e8:      	lsl	x1, x3, #4
    a1ec:      	ldr	x0, [x0]
    a1f0:      	add	x0, x1, x0
    a1f4:      	ldr	x0, [x0]
    a1f8:      	b	0xa20c <_stogir.terminal.inputs+0x3b4>
    a1fc:      	lsl	x1, x4, #4
    a200:      	ldr	x0, [x0, #0x28]
    a204:      	add	x0, x1, x0
    a208:      	ldr	x0, [x0]
    a20c:      	mov	x1, x0
    a210:      	mov	x0, #0x1                ; =1
    a214:      	b	0xa220 <_stogir.terminal.inputs+0x3c8>
    a218:      	movz	x0, #0x0, lsl #48
    a21c:      	movz	x1, #0x0, lsl #48
    a220:      	lsr	w0, w0, #0
    a224:      	lsr	x16, x0, #0
    a228:      	cmp	x16, #0x1
    a22c:      	b.eq	0xa248 <_stogir.terminal.inputs+0x3f0>
    a230:      	b.lo	0xa238 <_stogir.terminal.inputs+0x3e0>
    a234:      	b	0xa24c <_stogir.terminal.inputs+0x3f4>
    a238:      	cmp	x16, #0x0
    a23c:      	b.eq	0xa244 <_stogir.terminal.inputs+0x3ec>
    a240:      	b	0xa24c <_stogir.terminal.inputs+0x3f4>
    a244:      	b	0xa250 <_stogir.terminal.inputs+0x3f8>
    a248:      	b	0xa26c <_stogir.terminal.inputs+0x414>
    a24c:      	b	0xa2f0 <_stogir.terminal.inputs+0x498>
    a250:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0x1a8>
		000000000000a250:  ARM64_RELOC_PAGE21	l_stogir.437
    a254:      	ldr	x16, [x16]
		000000000000a254:  ARM64_RELOC_PAGEOFF12	l_stogir.437
    a258:      	orr	x0, x16, xzr
    a25c:      	mov	x1, x0
    a260:      	mov	x0, #0x1                ; =1
    a264:      	mov	x2, #0x1d               ; =29
    a268:      	b	0xa170 <_stogir.terminal.inputs+0x318>
    a26c:      	cmp	x3, #0x0
    a270:      	b.le	0xa158 <_stogir.terminal.inputs+0x300>
    a274:      	uxtb	w1, w1
    a278:      	cmp	x1, #0x83
    a27c:      	b.ge	0xa2b0 <_stogir.terminal.inputs+0x458>
    a280:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0x1a8>
		000000000000a280:  ARM64_RELOC_PAGE21	l_stogir.434
    a284:      	ldr	x16, [x16]
		000000000000a284:  ARM64_RELOC_PAGEOFF12	l_stogir.434
    a288:      	orr	x0, x16, xzr
    a28c:      	add	x0, x1, x0
    a290:      	ldrb	w0, [x0]
    a294:      	b	0xa2b4 <_stogir.terminal.inputs+0x45c>
    a298:      	movz	x2, #0x0, lsl #48
    a29c:      	b	0xa1d4 <_stogir.terminal.inputs+0x37c>
    a2a0:      	movz	x2, #0x0, lsl #48
    a2a4:      	b	0xa1cc <_stogir.terminal.inputs+0x374>
    a2a8:      	movz	x2, #0x0, lsl #48
    a2ac:      	b	0xa29c <_stogir.terminal.inputs+0x444>
    a2b0:      	movz	x0, #0x0, lsl #48
    a2b4:      	uxtb	w0, w0
    a2b8:      	and	x0, x0, #0x8
    a2bc:      	uxtb	w0, w0
    a2c0:      	cmp	x0, #0x0
    a2c4:      	cset	w0, eq
    a2c8:      	uxtb	w16, w0
    a2cc:      	cmp	w16, wzr
    a2d0:      	cset	x0, eq
    a2d4:      	cmp	x0, #0x0
    a2d8:      	b.eq	0xa158 <_stogir.terminal.inputs+0x300>
    a2dc:      	and	x0, x3, #0xffffffff
    a2e0:      	mov	x1, x0
    a2e4:      	movz	x0, #0x0, lsl #48
    a2e8:      	movz	x2, #0x0, lsl #48
    a2ec:      	b	0xa170 <_stogir.terminal.inputs+0x318>
    a2f0:      	brk	#0
    a2f4:      	b	0xa2f0 <_stogir.terminal.inputs+0x498>

000000000000a2f8 <_stogir.switch.switch-inputs>:
    a2f8:      	sxtw	x1, w1
    a2fc:      	cmp	x1, #0x0
    a300:      	cset	w3, gt
    a304:      	movz	x16, #0x0, lsl #48
    a308:      	sub	x4, x16, x1
    a30c:      	sub	x5, x4, #0x1
    a310:      	uxtb	w16, w3
    a314:      	cmp	w16, wzr
    a318:      	b.eq	0xa35c <_stogir.switch.switch-inputs+0x64>
    a31c:      	ldr	x4, [x0, #0x8]
    a320:      	cmp	x1, x4
    a324:      	b.ge	0xa3cc <_stogir.switch.switch-inputs+0xd4>
    a328:      	add	x4, x0, #0x78
    a32c:      	ldr	x4, [x4, #0x8]
    a330:      	cmp	x1, x4
    a334:      	b.ge	0xa4b4 <_stogir.switch.switch-inputs+0x1bc>
    a338:      	lsl	x4, x1, #2
    a33c:      	ldr	x6, [x0, #0x78]
    a340:      	add	x4, x4, x6
    a344:      	ldr	w4, [x4]
    a348:      	sxtw	x4, w4
    a34c:      	cmp	x4, #0x0
    a350:      	cset	w4, ge
    a354:      	ubfx	x4, x4, #0, #8
    a358:      	b	0xa4b8 <_stogir.switch.switch-inputs+0x1c0>
    a35c:      	cmp	x1, #0x0
    a360:      	b.ge	0xa3d4 <_stogir.switch.switch-inputs+0xdc>
    a364:      	add	x6, x0, #0x28
    a368:      	add	x7, x0, #0x50
    a36c:      	ldr	x6, [x6, #0x8]
    a370:      	ldr	x7, [x7, #0x8]
    a374:      	cmp	x6, x7
    a378:      	b.ne	0xa3a8 <_stogir.switch.switch-inputs+0xb0>
    a37c:      	cmp	x4, x6
    a380:      	b.gt	0xa4bc <_stogir.switch.switch-inputs+0x1c4>
    a384:      	lsl	x4, x5, #2
    a388:      	ldr	x6, [x0, #0x50]
    a38c:      	add	x4, x4, x6
    a390:      	ldr	w4, [x4]
    a394:      	sxtw	x4, w4
    a398:      	cmp	x4, #0x0
    a39c:      	cset	w4, gt
    a3a0:      	ubfx	x4, x4, #0, #8
    a3a4:      	b	0xa4c0 <_stogir.switch.switch-inputs+0x1c8>
    a3a8:      	movz	x4, #0x0, lsl #48
    a3ac:      	b	0xa3d8 <_stogir.switch.switch-inputs+0xe0>
    a3b0:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0x1a8>
		000000000000a3b0:  ARM64_RELOC_PAGE21	l_stogir.438
    a3b4:      	ldr	x16, [x16]
		000000000000a3b4:  ARM64_RELOC_PAGEOFF12	l_stogir.438
    a3b8:      	orr	x0, x16, xzr
    a3bc:      	mov	x1, x0
    a3c0:      	mov	x0, #0x1                ; =1
    a3c4:      	mov	x2, #0x16               ; =22
    a3c8:      	b	0xa46c <_stogir.switch.switch-inputs+0x174>
    a3cc:      	movz	x4, #0x0, lsl #48
    a3d0:      	b	0xa3d8 <_stogir.switch.switch-inputs+0xe0>
    a3d4:      	movz	x4, #0x0, lsl #48
    a3d8:      	cmp	x4, #0x0
    a3dc:      	b.eq	0xa41c <_stogir.switch.switch-inputs+0x124>
    a3e0:      	uxtb	w16, w3
    a3e4:      	cmp	w16, wzr
    a3e8:      	b.eq	0xa400 <_stogir.switch.switch-inputs+0x108>
    a3ec:      	lsl	x3, x1, #4
    a3f0:      	ldr	x4, [x0]
    a3f4:      	add	x3, x3, x4
    a3f8:      	ldr	x3, [x3]
    a3fc:      	b	0xa410 <_stogir.switch.switch-inputs+0x118>
    a400:      	lsl	x3, x5, #4
    a404:      	ldr	x4, [x0, #0x28]
    a408:      	add	x3, x3, x4
    a40c:      	ldr	x3, [x3]
    a410:      	mov	x4, x3
    a414:      	mov	x3, #0x1                ; =1
    a418:      	b	0xa424 <_stogir.switch.switch-inputs+0x12c>
    a41c:      	movz	x3, #0x0, lsl #48
    a420:      	movz	x4, #0x0, lsl #48
    a424:      	lsr	w3, w3, #0
    a428:      	lsr	x16, x3, #0
    a42c:      	cmp	x16, #0x1
    a430:      	b.eq	0xa44c <_stogir.switch.switch-inputs+0x154>
    a434:      	b.lo	0xa43c <_stogir.switch.switch-inputs+0x144>
    a438:      	b	0xa450 <_stogir.switch.switch-inputs+0x158>
    a43c:      	cmp	x16, #0x0
    a440:      	b.eq	0xa448 <_stogir.switch.switch-inputs+0x150>
    a444:      	b	0xa450 <_stogir.switch.switch-inputs+0x158>
    a448:      	b	0xa454 <_stogir.switch.switch-inputs+0x15c>
    a44c:      	b	0xa47c <_stogir.switch.switch-inputs+0x184>
    a450:      	b	0xa6e4 <_stogir.switch.switch-inputs+0x3ec>
    a454:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0x1a8>
		000000000000a454:  ARM64_RELOC_PAGE21	l_stogir.439
    a458:      	ldr	x16, [x16]
		000000000000a458:  ARM64_RELOC_PAGEOFF12	l_stogir.439
    a45c:      	orr	x0, x16, xzr
    a460:      	mov	x1, x0
    a464:      	mov	x0, #0x1                ; =1
    a468:      	mov	x2, #0x16               ; =22
    a46c:      	str	x0, [x8]
    a470:      	str	x1, [x8, #0x8]
    a474:      	str	x2, [x8, #0x10]
    a478:      	ret
    a47c:      	cmp	x1, #0x0
    a480:      	b.le	0xa3b0 <_stogir.switch.switch-inputs+0xb8>
    a484:      	uxtb	w4, w4
    a488:      	cmp	x4, #0x83
    a48c:      	cset	w1, lt
    a490:      	uxtb	w16, w1
    a494:      	cmp	w16, wzr
    a498:      	b.eq	0xa4c4 <_stogir.switch.switch-inputs+0x1cc>
    a49c:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0x1a8>
		000000000000a49c:  ARM64_RELOC_PAGE21	l_stogir.440
    a4a0:      	ldr	x16, [x16]
		000000000000a4a0:  ARM64_RELOC_PAGEOFF12	l_stogir.440
    a4a4:      	orr	x3, x16, xzr
    a4a8:      	add	x3, x4, x3
    a4ac:      	ldrb	w3, [x3]
    a4b0:      	b	0xa4c8 <_stogir.switch.switch-inputs+0x1d0>
    a4b4:      	movz	x4, #0x0, lsl #48
    a4b8:      	b	0xa3d0 <_stogir.switch.switch-inputs+0xd8>
    a4bc:      	movz	x4, #0x0, lsl #48
    a4c0:      	b	0xa3ac <_stogir.switch.switch-inputs+0xb4>
    a4c4:      	movz	x3, #0x0, lsl #48
    a4c8:      	uxtb	w3, w3
    a4cc:      	and	x3, x3, #0x1
    a4d0:      	uxtb	w3, w3
    a4d4:      	cmp	x3, #0x0
    a4d8:      	b.eq	0xa3b0 <_stogir.switch.switch-inputs+0xb8>
    a4dc:      	uxtb	w16, w1
    a4e0:      	cmp	w16, wzr
    a4e4:      	b.eq	0xa500 <_stogir.switch.switch-inputs+0x208>
    a4e8:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0x1a8>
		000000000000a4e8:  ARM64_RELOC_PAGE21	l_stogir.440
    a4ec:      	ldr	x16, [x16]
		000000000000a4ec:  ARM64_RELOC_PAGEOFF12	l_stogir.440
    a4f0:      	orr	x1, x16, xzr
    a4f4:      	add	x1, x4, x1
    a4f8:      	ldrb	w1, [x1]
    a4fc:      	b	0xa504 <_stogir.switch.switch-inputs+0x20c>
    a500:      	movz	x1, #0x0, lsl #48
    a504:      	uxtb	w1, w1
    a508:      	and	x1, x1, #0x4
    a50c:      	uxtb	w1, w1
    a510:      	cmp	x1, #0x0
    a514:      	cset	w1, eq
    a518:      	uxtb	w16, w1
    a51c:      	cmp	w16, wzr
    a520:      	cset	x1, eq
    a524:      	cmp	x1, #0x0
    a528:      	b.ne	0xa3b0 <_stogir.switch.switch-inputs+0xb8>
    a52c:      	sxtw	x2, w2
    a530:      	cmp	x2, #0x0
    a534:      	cset	w1, gt
    a538:      	movz	x16, #0x0, lsl #48
    a53c:      	sub	x3, x16, x2
    a540:      	sub	x4, x3, #0x1
    a544:      	uxtb	w16, w1
    a548:      	cmp	w16, wzr
    a54c:      	b.eq	0xa5ac <_stogir.switch.switch-inputs+0x2b4>
    a550:      	ldr	x3, [x0, #0x8]
    a554:      	cmp	x2, x3
    a558:      	b.ge	0xa5f8 <_stogir.switch.switch-inputs+0x300>
    a55c:      	add	x3, x0, #0x78
    a560:      	ldr	x3, [x3, #0x8]
    a564:      	cmp	x2, x3
    a568:      	b.ge	0xa6dc <_stogir.switch.switch-inputs+0x3e4>
    a56c:      	lsl	x3, x2, #2
    a570:      	ldr	x5, [x0, #0x78]
    a574:      	add	x3, x3, x5
    a578:      	ldr	w3, [x3]
    a57c:      	sxtw	x3, w3
    a580:      	cmp	x3, #0x0
    a584:      	cset	w3, ge
    a588:      	ubfx	x3, x3, #0, #8
    a58c:      	b	0xa6e0 <_stogir.switch.switch-inputs+0x3e8>
    a590:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0x1a8>
		000000000000a590:  ARM64_RELOC_PAGE21	l_stogir.441
    a594:      	ldr	x16, [x16]
		000000000000a594:  ARM64_RELOC_PAGEOFF12	l_stogir.441
    a598:      	orr	x0, x16, xzr
    a59c:      	mov	x1, x0
    a5a0:      	mov	x0, #0x1                ; =1
    a5a4:      	mov	x2, #0x20               ; =32
    a5a8:      	b	0xa3c8 <_stogir.switch.switch-inputs+0xd0>
    a5ac:      	cmp	x2, #0x0
    a5b0:      	b.ge	0xa600 <_stogir.switch.switch-inputs+0x308>
    a5b4:      	add	x5, x0, #0x28
    a5b8:      	add	x6, x0, #0x50
    a5bc:      	ldr	x5, [x5, #0x8]
    a5c0:      	ldr	x6, [x6, #0x8]
    a5c4:      	cmp	x5, x6
    a5c8:      	b.ne	0xa6d4 <_stogir.switch.switch-inputs+0x3dc>
    a5cc:      	cmp	x3, x5
    a5d0:      	b.gt	0xa6ec <_stogir.switch.switch-inputs+0x3f4>
    a5d4:      	lsl	x3, x4, #2
    a5d8:      	ldr	x5, [x0, #0x50]
    a5dc:      	add	x3, x3, x5
    a5e0:      	ldr	w3, [x3]
    a5e4:      	sxtw	x3, w3
    a5e8:      	cmp	x3, #0x0
    a5ec:      	cset	w3, gt
    a5f0:      	ubfx	x3, x3, #0, #8
    a5f4:      	b	0xa6f0 <_stogir.switch.switch-inputs+0x3f8>
    a5f8:      	movz	x3, #0x0, lsl #48
    a5fc:      	b	0xa604 <_stogir.switch.switch-inputs+0x30c>
    a600:      	movz	x3, #0x0, lsl #48
    a604:      	cmp	x3, #0x0
    a608:      	b.eq	0xa648 <_stogir.switch.switch-inputs+0x350>
    a60c:      	uxtb	w16, w1
    a610:      	cmp	w16, wzr
    a614:      	b.eq	0xa62c <_stogir.switch.switch-inputs+0x334>
    a618:      	lsl	x1, x2, #4
    a61c:      	ldr	x0, [x0]
    a620:      	add	x0, x1, x0
    a624:      	ldr	x0, [x0]
    a628:      	b	0xa63c <_stogir.switch.switch-inputs+0x344>
    a62c:      	lsl	x1, x4, #4
    a630:      	ldr	x0, [x0, #0x28]
    a634:      	add	x0, x1, x0
    a638:      	ldr	x0, [x0]
    a63c:      	mov	x1, x0
    a640:      	mov	x0, #0x1                ; =1
    a644:      	b	0xa650 <_stogir.switch.switch-inputs+0x358>
    a648:      	movz	x0, #0x0, lsl #48
    a64c:      	movz	x1, #0x0, lsl #48
    a650:      	lsr	w0, w0, #0
    a654:      	lsr	x16, x0, #0
    a658:      	cmp	x16, #0x1
    a65c:      	b.eq	0xa678 <_stogir.switch.switch-inputs+0x380>
    a660:      	b.lo	0xa668 <_stogir.switch.switch-inputs+0x370>
    a664:      	b	0xa67c <_stogir.switch.switch-inputs+0x384>
    a668:      	cmp	x16, #0x0
    a66c:      	b.eq	0xa674 <_stogir.switch.switch-inputs+0x37c>
    a670:      	b	0xa67c <_stogir.switch.switch-inputs+0x384>
    a674:      	b	0xa680 <_stogir.switch.switch-inputs+0x388>
    a678:      	b	0xa69c <_stogir.switch.switch-inputs+0x3a4>
    a67c:      	b	0xa6f4 <_stogir.switch.switch-inputs+0x3fc>
    a680:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0x1a8>
		000000000000a680:  ARM64_RELOC_PAGE21	l_stogir.442
    a684:      	ldr	x16, [x16]
		000000000000a684:  ARM64_RELOC_PAGEOFF12	l_stogir.442
    a688:      	orr	x0, x16, xzr
    a68c:      	mov	x1, x0
    a690:      	mov	x0, #0x1                ; =1
    a694:      	mov	x2, #0x17               ; =23
    a698:      	b	0xa5a8 <_stogir.switch.switch-inputs+0x2b0>
    a69c:      	lsr	w0, w1, #0
    a6a0:      	ubfx	x0, x0, #8, #8
    a6a4:      	cmp	x0, #0x1
    a6a8:      	b.lt	0xa590 <_stogir.switch.switch-inputs+0x298>
    a6ac:      	cmp	x0, #0xb
    a6b0:      	b.gt	0xa590 <_stogir.switch.switch-inputs+0x298>
    a6b4:      	uxtb	w1, w1
    a6b8:      	cmp	x1, #0x48
    a6bc:      	b.eq	0xa590 <_stogir.switch.switch-inputs+0x298>
    a6c0:      	and	x0, x0, #0xffffffff
    a6c4:      	mov	x1, x0
    a6c8:      	movz	x0, #0x0, lsl #48
    a6cc:      	movz	x2, #0x0, lsl #48
    a6d0:      	b	0xa5a8 <_stogir.switch.switch-inputs+0x2b0>
    a6d4:      	movz	x3, #0x0, lsl #48
    a6d8:      	b	0xa604 <_stogir.switch.switch-inputs+0x30c>
    a6dc:      	movz	x3, #0x0, lsl #48
    a6e0:      	b	0xa5fc <_stogir.switch.switch-inputs+0x304>
    a6e4:      	brk	#0
    a6e8:      	b	0xa6e4 <_stogir.switch.switch-inputs+0x3ec>
    a6ec:      	movz	x3, #0x0, lsl #48
    a6f0:      	b	0xa6d8 <_stogir.switch.switch-inputs+0x3e0>
    a6f4:      	brk	#0
    a6f8:      	b	0xa6f4 <_stogir.switch.switch-inputs+0x3fc>

000000000000a6fc <_stogir.switch.case-inputs>:
    a6fc:      	sub	sp, sp, #0xc0
    a700:      	str	x29, [sp]
    a704:      	str	x30, [sp, #0x8]
    a708:      	mov	x29, sp
    a70c:      	str	x19, [sp, #0x80]
    a710:      	str	x20, [sp, #0x88]
    a714:      	str	x21, [sp, #0x90]
    a718:      	str	x22, [sp, #0x98]
    a71c:      	str	x23, [sp, #0xa0]
    a720:      	str	x24, [sp, #0xa8]
    a724:      	str	x25, [sp, #0xb0]
    a728:      	str	x26, [sp, #0xb8]
    a72c:      	sxtw	x2, w2
    a730:      	lsl	x5, x2, #2
    a734:      	cmp	x2, #0x0
    a738:      	cset	w6, gt
    a73c:      	movz	x16, #0x0, lsl #48
    a740:      	sub	x7, x16, x2
    a744:      	sub	x9, x7, #0x1
    a748:      	uxtb	w16, w6
    a74c:      	cmp	w16, wzr
    a750:      	b.eq	0xa790 <_stogir.switch.case-inputs+0x94>
    a754:      	ldr	x7, [x0, #0x8]
    a758:      	cmp	x2, x7
    a75c:      	b.ge	0xa7e4 <_stogir.switch.case-inputs+0xe8>
    a760:      	add	x7, x0, #0x78
    a764:      	ldr	x7, [x7, #0x8]
    a768:      	cmp	x2, x7
    a76c:      	b.ge	0xa924 <_stogir.switch.case-inputs+0x228>
    a770:      	ldr	x7, [x0, #0x78]
    a774:      	add	x7, x5, x7
    a778:      	ldr	w7, [x7]
    a77c:      	sxtw	x7, w7
    a780:      	cmp	x7, #0x0
    a784:      	cset	w7, ge
    a788:      	ubfx	x7, x7, #0, #8
    a78c:      	b	0xa928 <_stogir.switch.case-inputs+0x22c>
    a790:      	cmp	x2, #0x0
    a794:      	b.ge	0xa7ec <_stogir.switch.case-inputs+0xf0>
    a798:      	add	x10, x0, #0x28
    a79c:      	add	x11, x0, #0x50
    a7a0:      	ldr	x10, [x10, #0x8]
    a7a4:      	ldr	x11, [x11, #0x8]
    a7a8:      	cmp	x10, x11
    a7ac:      	b.ne	0xa7dc <_stogir.switch.case-inputs+0xe0>
    a7b0:      	cmp	x7, x10
    a7b4:      	b.gt	0xaa00 <_stogir.switch.case-inputs+0x304>
    a7b8:      	lsl	x7, x9, #2
    a7bc:      	ldr	x10, [x0, #0x50]
    a7c0:      	add	x7, x7, x10
    a7c4:      	ldr	w7, [x7]
    a7c8:      	sxtw	x7, w7
    a7cc:      	cmp	x7, #0x0
    a7d0:      	cset	w7, gt
    a7d4:      	ubfx	x7, x7, #0, #8
    a7d8:      	b	0xaa04 <_stogir.switch.case-inputs+0x308>
    a7dc:      	movz	x7, #0x0, lsl #48
    a7e0:      	b	0xa7f0 <_stogir.switch.case-inputs+0xf4>
    a7e4:      	movz	x7, #0x0, lsl #48
    a7e8:      	b	0xa7f0 <_stogir.switch.case-inputs+0xf4>
    a7ec:      	movz	x7, #0x0, lsl #48
    a7f0:      	cmp	x7, #0x0
    a7f4:      	b.eq	0xa858 <_stogir.switch.case-inputs+0x15c>
    a7f8:      	uxtb	w16, w6
    a7fc:      	cmp	w16, wzr
    a800:      	b.eq	0xa828 <_stogir.switch.case-inputs+0x12c>
    a804:      	lsl	x6, x2, #4
    a808:      	ldr	x7, [x0]
    a80c:      	add	x6, x6, x7
    a810:      	ldr	x7, [x6]
    a814:      	ldr	x6, [x6, #0x8]
    a818:      	fmov	d31, x6
    a81c:      	mov	x6, x7
    a820:      	fmov	x7, d31
    a824:      	b	0xa848 <_stogir.switch.case-inputs+0x14c>
    a828:      	lsl	x6, x9, #4
    a82c:      	ldr	x7, [x0, #0x28]
    a830:      	add	x6, x6, x7
    a834:      	ldr	x7, [x6]
    a838:      	ldr	x6, [x6, #0x8]
    a83c:      	fmov	d31, x6
    a840:      	mov	x6, x7
    a844:      	fmov	x7, d31
    a848:      	mov	x9, x7
    a84c:      	mov	x7, x6
    a850:      	mov	x6, #0x1                ; =1
    a854:      	b	0xa864 <_stogir.switch.case-inputs+0x168>
    a858:      	movz	x6, #0x0, lsl #48
    a85c:      	movz	x7, #0x0, lsl #48
    a860:      	movz	x9, #0x0, lsl #48
    a864:      	lsr	w6, w6, #0
    a868:      	lsr	x16, x6, #0
    a86c:      	cmp	x16, #0x1
    a870:      	b.eq	0xa88c <_stogir.switch.case-inputs+0x190>
    a874:      	b.lo	0xa87c <_stogir.switch.case-inputs+0x180>
    a878:      	b	0xa890 <_stogir.switch.case-inputs+0x194>
    a87c:      	cmp	x16, #0x0
    a880:      	b.eq	0xa888 <_stogir.switch.case-inputs+0x18c>
    a884:      	b	0xa890 <_stogir.switch.case-inputs+0x194>
    a888:      	b	0xa894 <_stogir.switch.case-inputs+0x198>
    a88c:      	b	0xa8ec <_stogir.switch.case-inputs+0x1f0>
    a890:      	b	0xaa08 <_stogir.switch.case-inputs+0x30c>
    a894:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0x1a8>
		000000000000a894:  ARM64_RELOC_PAGE21	l_stogir.443
    a898:      	ldr	x16, [x16]
		000000000000a898:  ARM64_RELOC_PAGEOFF12	l_stogir.443
    a89c:      	orr	x0, x16, xzr
    a8a0:      	mov	x21, x8
    a8a4:      	mov	x1, x0
    a8a8:      	mov	x0, #0x1                ; =1
    a8ac:      	mov	x2, #0x1a               ; =26
    a8b0:      	str	x0, [x21]
    a8b4:      	str	x1, [x21, #0x8]
    a8b8:      	str	x2, [x21, #0x10]
    a8bc:      	ldr	x19, [sp, #0x80]
    a8c0:      	ldr	x20, [sp, #0x88]
    a8c4:      	ldr	x21, [sp, #0x90]
    a8c8:      	ldr	x22, [sp, #0x98]
    a8cc:      	ldr	x23, [sp, #0xa0]
    a8d0:      	ldr	x24, [sp, #0xa8]
    a8d4:      	ldr	x25, [sp, #0xb0]
    a8d8:      	ldr	x26, [sp, #0xb8]
    a8dc:      	ldr	x29, [sp]
    a8e0:      	ldr	x30, [sp, #0x8]
    a8e4:      	add	sp, sp, #0xc0
    a8e8:      	ret
    a8ec:      	add	x16, sp, #0x10
    a8f0:      	str	x7, [x16]
    a8f4:      	add	x16, sp, #0x10
    a8f8:      	str	x9, [x16, #0x8]
    a8fc:      	cmp	x2, #0x0
    a900:      	b.gt	0xa92c <_stogir.switch.case-inputs+0x230>
    a904:      	mov	x21, x8
    a908:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0x1a8>
		000000000000a908:  ARM64_RELOC_PAGE21	l_stogir.444
    a90c:      	ldr	x16, [x16]
		000000000000a90c:  ARM64_RELOC_PAGEOFF12	l_stogir.444
    a910:      	orr	x0, x16, xzr
    a914:      	mov	x1, x0
    a918:      	mov	x0, #0x1                ; =1
    a91c:      	mov	x2, #0x1f               ; =31
    a920:      	b	0xa8b0 <_stogir.switch.case-inputs+0x1b4>
    a924:      	movz	x7, #0x0, lsl #48
    a928:      	b	0xa7e8 <_stogir.switch.case-inputs+0xec>
    a92c:      	add	x16, sp, #0x10
    a930:      	ldr	w2, [x16]
    a934:      	uxtb	w6, w2
    a938:      	cmp	x6, #0x75
    a93c:      	b.ne	0xab98 <_stogir.switch.case-inputs+0x49c>
    a940:      	ubfx	x2, x2, #8, #8
    a944:      	cmp	x2, #0x0
    a948:      	b.ne	0xaba0 <_stogir.switch.case-inputs+0x4a4>
    a94c:      	ldr	x2, [x0, #0x78]
    a950:      	add	x2, x5, x2
    a954:      	ldr	w2, [x2]
    a958:      	sxtw	x2, w2
    a95c:      	cmp	x2, #0x2
    a960:      	b.ne	0xaba8 <_stogir.switch.case-inputs+0x4ac>
    a964:      	sxtw	x19, w1
    a968:      	cmp	x19, #0x6d
    a96c:      	b.lt	0xabb0 <_stogir.switch.case-inputs+0x4b4>
    a970:      	cmp	x19, #0x6f
    a974:      	b.gt	0xabb8 <_stogir.switch.case-inputs+0x4bc>
    a978:      	add	x16, sp, #0x20
    a97c:      	orr	x20, x16, xzr
    a980:      	add	x16, sp, #0x10
    a984:      	ldr	w1, [x16, #0x4]
    a988:      	add	x16, sp, #0x10
    a98c:      	ldr	w2, [x16, #0x8]
    a990:      	lsr	w1, w1, #0
    a994:      	lsr	w2, w2, #0
    a998:      	mov	x21, x8
    a99c:      	add	x8, sp, #0x20
    a9a0:      	mov	x22, x0
    a9a4:      	mov	w23, w3
    a9a8:      	mov	w24, w4
    a9ac:      	bl	0xa9ac <_stogir.switch.case-inputs+0x2b0>
		000000000000a9ac:  ARM64_RELOC_BRANCH26	_stogir.switch.switch-inputs
    a9b0:      	add	x16, sp, #0x20
    a9b4:      	ldr	w0, [x16]
    a9b8:      	lsr	x16, x0, #0
    a9bc:      	cmp	x16, #0x1
    a9c0:      	b.eq	0xa9dc <_stogir.switch.case-inputs+0x2e0>
    a9c4:      	b.lo	0xa9cc <_stogir.switch.case-inputs+0x2d0>
    a9c8:      	b	0xa9e0 <_stogir.switch.case-inputs+0x2e4>
    a9cc:      	cmp	x16, #0x0
    a9d0:      	b.eq	0xa9d8 <_stogir.switch.case-inputs+0x2dc>
    a9d4:      	b	0xa9e0 <_stogir.switch.case-inputs+0x2e4>
    a9d8:      	b	0xaa10 <_stogir.switch.case-inputs+0x314>
    a9dc:      	b	0xa9e4 <_stogir.switch.case-inputs+0x2e8>
    a9e0:      	b	0xab80 <_stogir.switch.case-inputs+0x484>
    a9e4:      	add	x0, x20, #0x8
    a9e8:      	add	x16, sp, #0x20
    a9ec:      	ldr	x1, [x16, #0x8]
    a9f0:      	ldr	x0, [x0, #0x8]
    a9f4:      	mov	x2, x0
    a9f8:      	mov	x0, #0x1                ; =1
    a9fc:      	b	0xa920 <_stogir.switch.case-inputs+0x224>
    aa00:      	movz	x7, #0x0, lsl #48
    aa04:      	b	0xa7e0 <_stogir.switch.case-inputs+0xe4>
    aa08:      	brk	#0
    aa0c:      	b	0xaa08 <_stogir.switch.case-inputs+0x30c>
    aa10:      	add	x16, sp, #0x20
    aa14:      	ldr	w20, [x16, #0x8]
    aa18:      	sxtw	x0, w20
    aa1c:      	and	x25, x0, #0xffffffff
    aa20:      	cmp	x19, #0x6f
    aa24:      	b.ne	0xaa38 <_stogir.switch.case-inputs+0x33c>
    aa28:      	mov	x1, x25
    aa2c:      	movz	x0, #0x0, lsl #48
    aa30:      	movz	x2, #0x0, lsl #48
    aa34:      	b	0xa9fc <_stogir.switch.case-inputs+0x300>
    aa38:      	add	x16, sp, #0x40
    aa3c:      	orr	x26, x16, xzr
    aa40:      	lsr	w23, w23, #0
    aa44:      	lsr	w20, w20, #0
    aa48:      	add	x8, sp, #0x40
    aa4c:      	mov	x0, x22
    aa50:      	mov	w1, w23
    aa54:      	mov	w2, w20
    aa58:      	bl	0xaa58 <_stogir.switch.case-inputs+0x35c>
		000000000000aa58:  ARM64_RELOC_BRANCH26	_stogir.switch.key
    aa5c:      	add	x16, sp, #0x40
    aa60:      	ldr	w0, [x16]
    aa64:      	lsr	x16, x0, #0
    aa68:      	cmp	x16, #0x1
    aa6c:      	b.eq	0xaa88 <_stogir.switch.case-inputs+0x38c>
    aa70:      	b.lo	0xaa78 <_stogir.switch.case-inputs+0x37c>
    aa74:      	b	0xaa8c <_stogir.switch.case-inputs+0x390>
    aa78:      	cmp	x16, #0x0
    aa7c:      	b.eq	0xaa84 <_stogir.switch.case-inputs+0x388>
    aa80:      	b	0xaa8c <_stogir.switch.case-inputs+0x390>
    aa84:      	b	0xaaac <_stogir.switch.case-inputs+0x3b0>
    aa88:      	b	0xaa90 <_stogir.switch.case-inputs+0x394>
    aa8c:      	b	0xab88 <_stogir.switch.case-inputs+0x48c>
    aa90:      	add	x0, x26, #0x8
    aa94:      	add	x16, sp, #0x40
    aa98:      	ldr	x1, [x16, #0x8]
    aa9c:      	ldr	x0, [x0, #0x8]
    aaa0:      	mov	x2, x0
    aaa4:      	mov	x0, #0x1                ; =1
    aaa8:      	b	0xaa34 <_stogir.switch.case-inputs+0x338>
    aaac:      	add	x16, sp, #0x40
    aab0:      	ldr	x26, [x16, #0x8]
    aab4:      	cmp	x19, #0x6d
    aab8:      	b.ne	0xaad8 <_stogir.switch.case-inputs+0x3dc>
    aabc:      	sxtw	x23, w23
    aac0:      	mov	x0, x23
    aac4:      	b	0xaae0 <_stogir.switch.case-inputs+0x3e4>
    aac8:      	mov	x1, x25
    aacc:      	movz	x0, #0x0, lsl #48
    aad0:      	movz	x2, #0x0, lsl #48
    aad4:      	b	0xaaa8 <_stogir.switch.case-inputs+0x3ac>
    aad8:      	sxtw	x24, w24
    aadc:      	mov	x0, x24
    aae0:      	add	x16, sp, #0x60
    aae4:      	orr	x19, x16, xzr
    aae8:      	lsr	w20, w20, #0
    aaec:      	lsr	w0, w0, #0
    aaf0:      	add	x8, sp, #0x60
    aaf4:      	mov	w1, w0
    aaf8:      	mov	x0, x22
    aafc:      	mov	w2, w20
    ab00:      	bl	0xab00 <_stogir.switch.case-inputs+0x404>
		000000000000ab00:  ARM64_RELOC_BRANCH26	_stogir.switch.key
    ab04:      	add	x16, sp, #0x60
    ab08:      	ldr	w0, [x16]
    ab0c:      	lsr	x16, x0, #0
    ab10:      	cmp	x16, #0x1
    ab14:      	b.eq	0xab30 <_stogir.switch.case-inputs+0x434>
    ab18:      	b.lo	0xab20 <_stogir.switch.case-inputs+0x424>
    ab1c:      	b	0xab34 <_stogir.switch.case-inputs+0x438>
    ab20:      	cmp	x16, #0x0
    ab24:      	b.eq	0xab2c <_stogir.switch.case-inputs+0x430>
    ab28:      	b	0xab34 <_stogir.switch.case-inputs+0x438>
    ab2c:      	b	0xab54 <_stogir.switch.case-inputs+0x458>
    ab30:      	b	0xab38 <_stogir.switch.case-inputs+0x43c>
    ab34:      	b	0xab90 <_stogir.switch.case-inputs+0x494>
    ab38:      	add	x0, x19, #0x8
    ab3c:      	add	x16, sp, #0x60
    ab40:      	ldr	x1, [x16, #0x8]
    ab44:      	ldr	x0, [x0, #0x8]
    ab48:      	mov	x2, x0
    ab4c:      	mov	x0, #0x1                ; =1
    ab50:      	b	0xaad4 <_stogir.switch.case-inputs+0x3d8>
    ab54:      	add	x16, sp, #0x60
    ab58:      	ldr	x0, [x16, #0x8]
    ab5c:      	cmp	x26, x0
    ab60:      	b.ls	0xaac8 <_stogir.switch.case-inputs+0x3cc>
    ab64:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0x1a8>
		000000000000ab64:  ARM64_RELOC_PAGE21	l_stogir.445
    ab68:      	ldr	x16, [x16]
		000000000000ab68:  ARM64_RELOC_PAGEOFF12	l_stogir.445
    ab6c:      	orr	x0, x16, xzr
    ab70:      	mov	x1, x0
    ab74:      	mov	x0, #0x1                ; =1
    ab78:      	mov	x2, #0x1a               ; =26
    ab7c:      	b	0xaad4 <_stogir.switch.case-inputs+0x3d8>
    ab80:      	brk	#0
    ab84:      	b	0xab80 <_stogir.switch.case-inputs+0x484>
    ab88:      	brk	#0
    ab8c:      	b	0xab88 <_stogir.switch.case-inputs+0x48c>
    ab90:      	brk	#0
    ab94:      	b	0xab90 <_stogir.switch.case-inputs+0x494>
    ab98:      	mov	x21, x8
    ab9c:      	b	0xa908 <_stogir.switch.case-inputs+0x20c>
    aba0:      	mov	x21, x8
    aba4:      	b	0xa908 <_stogir.switch.case-inputs+0x20c>
    aba8:      	mov	x21, x8
    abac:      	b	0xa908 <_stogir.switch.case-inputs+0x20c>
    abb0:      	mov	x21, x8
    abb4:      	b	0xa908 <_stogir.switch.case-inputs+0x20c>
    abb8:      	mov	x21, x8
    abbc:      	b	0xa908 <_stogir.switch.case-inputs+0x20c>

000000000000abc0 <_stogir.stack.validate-frame-address>:
    abc0:      	sxtw	x1, w1
    abc4:      	lsl	x2, x1, #2
    abc8:      	cmp	x1, #0x0
    abcc:      	cset	w3, gt
    abd0:      	movz	x16, #0x0, lsl #48
    abd4:      	sub	x4, x16, x1
    abd8:      	sub	x5, x4, #0x1
    abdc:      	uxtb	w16, w3
    abe0:      	cmp	w16, wzr
    abe4:      	b.eq	0xac24 <_stogir.stack.validate-frame-address+0x64>
    abe8:      	ldr	x4, [x0, #0x8]
    abec:      	cmp	x1, x4
    abf0:      	b.ge	0xac78 <_stogir.stack.validate-frame-address+0xb8>
    abf4:      	add	x4, x0, #0x78
    abf8:      	ldr	x4, [x4, #0x8]
    abfc:      	cmp	x1, x4
    ac00:      	b.ge	0xad90 <_stogir.stack.validate-frame-address+0x1d0>
    ac04:      	ldr	x4, [x0, #0x78]
    ac08:      	add	x4, x2, x4
    ac0c:      	ldr	w4, [x4]
    ac10:      	sxtw	x4, w4
    ac14:      	cmp	x4, #0x0
    ac18:      	cset	w4, ge
    ac1c:      	ubfx	x4, x4, #0, #8
    ac20:      	b	0xad94 <_stogir.stack.validate-frame-address+0x1d4>
    ac24:      	cmp	x1, #0x0
    ac28:      	b.ge	0xac80 <_stogir.stack.validate-frame-address+0xc0>
    ac2c:      	add	x6, x0, #0x28
    ac30:      	add	x7, x0, #0x50
    ac34:      	ldr	x6, [x6, #0x8]
    ac38:      	ldr	x7, [x7, #0x8]
    ac3c:      	cmp	x6, x7
    ac40:      	b.ne	0xac70 <_stogir.stack.validate-frame-address+0xb0>
    ac44:      	cmp	x4, x6
    ac48:      	b.gt	0xad98 <_stogir.stack.validate-frame-address+0x1d8>
    ac4c:      	lsl	x4, x5, #2
    ac50:      	ldr	x6, [x0, #0x50]
    ac54:      	add	x4, x4, x6
    ac58:      	ldr	w4, [x4]
    ac5c:      	sxtw	x4, w4
    ac60:      	cmp	x4, #0x0
    ac64:      	cset	w4, gt
    ac68:      	ubfx	x4, x4, #0, #8
    ac6c:      	b	0xad9c <_stogir.stack.validate-frame-address+0x1dc>
    ac70:      	movz	x4, #0x0, lsl #48
    ac74:      	b	0xac84 <_stogir.stack.validate-frame-address+0xc4>
    ac78:      	movz	x4, #0x0, lsl #48
    ac7c:      	b	0xac84 <_stogir.stack.validate-frame-address+0xc4>
    ac80:      	movz	x4, #0x0, lsl #48
    ac84:      	cmp	x4, #0x0
    ac88:      	b.eq	0xacc8 <_stogir.stack.validate-frame-address+0x108>
    ac8c:      	uxtb	w16, w3
    ac90:      	cmp	w16, wzr
    ac94:      	b.eq	0xacac <_stogir.stack.validate-frame-address+0xec>
    ac98:      	lsl	x3, x1, #4
    ac9c:      	ldr	x4, [x0]
    aca0:      	add	x3, x3, x4
    aca4:      	ldr	x3, [x3]
    aca8:      	b	0xacbc <_stogir.stack.validate-frame-address+0xfc>
    acac:      	lsl	x3, x5, #4
    acb0:      	ldr	x4, [x0, #0x28]
    acb4:      	add	x3, x3, x4
    acb8:      	ldr	x3, [x3]
    acbc:      	mov	x4, x3
    acc0:      	mov	x3, #0x1                ; =1
    acc4:      	b	0xacd0 <_stogir.stack.validate-frame-address+0x110>
    acc8:      	movz	x3, #0x0, lsl #48
    accc:      	movz	x4, #0x0, lsl #48
    acd0:      	lsr	w3, w3, #0
    acd4:      	lsr	x16, x3, #0
    acd8:      	cmp	x16, #0x1
    acdc:      	b.eq	0xacf8 <_stogir.stack.validate-frame-address+0x138>
    ace0:      	b.lo	0xace8 <_stogir.stack.validate-frame-address+0x128>
    ace4:      	b	0xacfc <_stogir.stack.validate-frame-address+0x13c>
    ace8:      	cmp	x16, #0x0
    acec:      	b.eq	0xacf4 <_stogir.stack.validate-frame-address+0x134>
    acf0:      	b	0xacfc <_stogir.stack.validate-frame-address+0x13c>
    acf4:      	b	0xad00 <_stogir.stack.validate-frame-address+0x140>
    acf8:      	b	0xad44 <_stogir.stack.validate-frame-address+0x184>
    acfc:      	b	0xada0 <_stogir.stack.validate-frame-address+0x1e0>
    ad00:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0x1a8>
		000000000000ad00:  ARM64_RELOC_PAGE21	l_stogir.446
    ad04:      	ldr	x16, [x16]
		000000000000ad04:  ARM64_RELOC_PAGEOFF12	l_stogir.446
    ad08:      	orr	x0, x16, xzr
    ad0c:      	mov	x1, x0
    ad10:      	mov	x0, #0x1                ; =1
    ad14:      	mov	x2, #0x21               ; =33
    ad18:      	b	0xad34 <_stogir.stack.validate-frame-address+0x174>
    ad1c:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0x1a8>
		000000000000ad1c:  ARM64_RELOC_PAGE21	l_stogir.447
    ad20:      	ldr	x16, [x16]
		000000000000ad20:  ARM64_RELOC_PAGEOFF12	l_stogir.447
    ad24:      	orr	x0, x16, xzr
    ad28:      	mov	x1, x0
    ad2c:      	mov	x0, #0x1                ; =1
    ad30:      	mov	x2, #0x1e               ; =30
    ad34:      	str	x0, [x8]
    ad38:      	str	x1, [x8, #0x8]
    ad3c:      	str	x2, [x8, #0x10]
    ad40:      	ret
    ad44:      	cmp	x1, #0x0
    ad48:      	b.le	0xad1c <_stogir.stack.validate-frame-address+0x15c>
    ad4c:      	uxtb	w1, w4
    ad50:      	cmp	x1, #0x42
    ad54:      	b.ne	0xad1c <_stogir.stack.validate-frame-address+0x15c>
    ad58:      	lsr	w4, w4, #0
    ad5c:      	ubfx	x1, x4, #8, #8
    ad60:      	cmp	x1, #0x6
    ad64:      	b.ne	0xad1c <_stogir.stack.validate-frame-address+0x15c>
    ad68:      	ldr	x0, [x0, #0x78]
    ad6c:      	add	x0, x2, x0
    ad70:      	ldr	w0, [x0]
    ad74:      	sxtw	x0, w0
    ad78:      	cmp	x0, #0x0
    ad7c:      	b.ne	0xad1c <_stogir.stack.validate-frame-address+0x15c>
    ad80:      	movz	x0, #0x0, lsl #48
    ad84:      	mov	x1, #0x8                ; =8
    ad88:      	movz	x2, #0x0, lsl #48
    ad8c:      	b	0xad34 <_stogir.stack.validate-frame-address+0x174>
    ad90:      	movz	x4, #0x0, lsl #48
    ad94:      	b	0xac7c <_stogir.stack.validate-frame-address+0xbc>
    ad98:      	movz	x4, #0x0, lsl #48
    ad9c:      	b	0xac74 <_stogir.stack.validate-frame-address+0xb4>
    ada0:      	brk	#0
    ada4:      	b	0xada0 <_stogir.stack.validate-frame-address+0x1e0>

000000000000ada8 <_stogir.stack.frame-object?>:
    ada8:      	ldr	w0, [x0]
    adac:      	uxtb	w1, w0
    adb0:      	cmp	x1, #0x51
    adb4:      	b.ne	0xadcc <_stogir.stack.frame-object?+0x24>
    adb8:      	ubfx	x0, x0, #16, #16
    adbc:      	cmp	x0, #0x8, lsl #12       ; =0x8000
    adc0:      	cset	w0, eq
    adc4:      	ubfx	x0, x0, #0, #8
    adc8:      	b	0xadd0 <_stogir.stack.frame-object?+0x28>
    adcc:      	movz	x0, #0x0, lsl #48
    add0:      	ret

000000000000add4 <_stogir.stack.valid-frame-object-inputs?>:
    add4:      	sub	sp, sp, #0x50
    add8:      	str	x29, [sp]
    addc:      	str	x30, [sp, #0x8]
    ade0:      	mov	x29, sp
    ade4:      	str	x19, [sp, #0x30]
    ade8:      	str	x20, [sp, #0x38]
    adec:      	str	x21, [sp, #0x40]
    adf0:      	add	x3, x0, #0x78
    adf4:      	add	x4, x0, #0x28
    adf8:      	add	x5, x0, #0x50
    adfc:      	add	x6, x0, #0x78
    ae00:      	add	x7, x0, #0x28
    ae04:      	add	x8, x0, #0x50
    ae08:      	sxtw	x1, w1
    ae0c:      	mov	x9, sp
    ae10:      	sub	sp, sp, #0x10
    ae14:      	mov	x10, sp
    ae18:      	mov	x12, x1
    ae1c:      	mov	x1, #0x1                ; =1
    ae20:      	movz	x11, #0x0, lsl #48
    ae24:      	b	0xaf74 <_stogir.stack.valid-frame-object-inputs?+0x1a0>
    ae28:      	movz	x15, #0x0, lsl #48
    ae2c:      	b	0xaea4 <_stogir.stack.valid-frame-object-inputs?+0xd0>
    ae30:      	movz	x13, #0x0, lsl #48
    ae34:      	movz	x14, #0x0, lsl #48
    ae38:      	lsr	w13, w13, #0
    ae3c:      	lsr	x16, x13, #0
    ae40:      	cmp	x16, #0x1
    ae44:      	b.eq	0xae60 <_stogir.stack.valid-frame-object-inputs?+0x8c>
    ae48:      	b.lo	0xae50 <_stogir.stack.valid-frame-object-inputs?+0x7c>
    ae4c:      	b	0xae64 <_stogir.stack.valid-frame-object-inputs?+0x90>
    ae50:      	cmp	x16, #0x0
    ae54:      	b.eq	0xae5c <_stogir.stack.valid-frame-object-inputs?+0x88>
    ae58:      	b	0xae64 <_stogir.stack.valid-frame-object-inputs?+0x90>
    ae5c:      	b	0xae84 <_stogir.stack.valid-frame-object-inputs?+0xb0>
    ae60:      	b	0xae68 <_stogir.stack.valid-frame-object-inputs?+0x94>
    ae64:      	b	0xb25c <_stogir.stack.valid-frame-object-inputs?+0x488>
    ae68:      	uxtb	w13, w14
    ae6c:      	lsr	w14, w14, #0
    ae70:      	ubfx	x14, x14, #8, #8
    ae74:      	cmp	x13, x14
    ae78:      	b.eq	0xb248 <_stogir.stack.valid-frame-object-inputs?+0x474>
    ae7c:      	cmp	x13, #0x49
    ae80:      	b.eq	0xb248 <_stogir.stack.valid-frame-object-inputs?+0x474>
    ae84:      	movz	x1, #0x0, lsl #48
    ae88:      	fmov	d31, x11
    ae8c:      	mov	x11, x12
    ae90:      	fmov	x12, d31
    ae94:      	b	0xb058 <_stogir.stack.valid-frame-object-inputs?+0x284>
    ae98:      	movz	x15, #0x0, lsl #48
    ae9c:      	b	0xaeac <_stogir.stack.valid-frame-object-inputs?+0xd8>
    aea0:      	movz	x15, #0x0, lsl #48
    aea4:      	b	0xaeb4 <_stogir.stack.valid-frame-object-inputs?+0xe0>
    aea8:      	movz	x15, #0x0, lsl #48
    aeac:      	b	0xaeb4 <_stogir.stack.valid-frame-object-inputs?+0xe0>
    aeb0:      	movz	x15, #0x0, lsl #48
    aeb4:      	cmp	x15, #0x0
    aeb8:      	b.eq	0xaf1c <_stogir.stack.valid-frame-object-inputs?+0x148>
    aebc:      	uxtb	w16, w14
    aec0:      	cmp	w16, wzr
    aec4:      	b.eq	0xaeec <_stogir.stack.valid-frame-object-inputs?+0x118>
    aec8:      	lsl	x13, x13, #4
    aecc:      	ldr	x14, [x0]
    aed0:      	add	x13, x13, x14
    aed4:      	ldr	x14, [x13]
    aed8:      	ldr	x13, [x13, #0x8]
    aedc:      	fmov	d31, x13
    aee0:      	mov	x13, x14
    aee4:      	fmov	x14, d31
    aee8:      	b	0xaf0c <_stogir.stack.valid-frame-object-inputs?+0x138>
    aeec:      	lsl	x13, x19, #4
    aef0:      	ldr	x14, [x0, #0x28]
    aef4:      	add	x13, x13, x14
    aef8:      	ldr	x14, [x13]
    aefc:      	ldr	x13, [x13, #0x8]
    af00:      	fmov	d31, x13
    af04:      	mov	x13, x14
    af08:      	fmov	x14, d31
    af0c:      	mov	x15, x14
    af10:      	mov	x14, x13
    af14:      	mov	x13, #0x1               ; =1
    af18:      	b	0xaf28 <_stogir.stack.valid-frame-object-inputs?+0x154>
    af1c:      	movz	x13, #0x0, lsl #48
    af20:      	movz	x14, #0x0, lsl #48
    af24:      	movz	x15, #0x0, lsl #48
    af28:      	lsr	w13, w13, #0
    af2c:      	lsr	x16, x13, #0
    af30:      	cmp	x16, #0x1
    af34:      	b.eq	0xaf50 <_stogir.stack.valid-frame-object-inputs?+0x17c>
    af38:      	b.lo	0xaf40 <_stogir.stack.valid-frame-object-inputs?+0x16c>
    af3c:      	b	0xaf54 <_stogir.stack.valid-frame-object-inputs?+0x180>
    af40:      	cmp	x16, #0x0
    af44:      	b.eq	0xaf4c <_stogir.stack.valid-frame-object-inputs?+0x178>
    af48:      	b	0xaf54 <_stogir.stack.valid-frame-object-inputs?+0x180>
    af4c:      	b	0xaf58 <_stogir.stack.valid-frame-object-inputs?+0x184>
    af50:      	b	0xb02c <_stogir.stack.valid-frame-object-inputs?+0x258>
    af54:      	b	0xb1a4 <_stogir.stack.valid-frame-object-inputs?+0x3d0>
    af58:      	fmov	d31, x11
    af5c:      	mov	x11, x12
    af60:      	fmov	x12, d31
    af64:      	movz	x1, #0x0, lsl #48
    af68:      	fmov	d31, x11
    af6c:      	mov	x11, x12
    af70:      	fmov	x12, d31
    af74:      	cmp	x1, #0x0
    af78:      	b.eq	0xb0e8 <_stogir.stack.valid-frame-object-inputs?+0x314>
    af7c:      	cmp	x11, #0x0
    af80:      	b.ne	0xb0e8 <_stogir.stack.valid-frame-object-inputs?+0x314>
    af84:      	lsr	w13, w12, #0
    af88:      	sxtw	x13, w13
    af8c:      	cmp	x13, #0x0
    af90:      	cset	w14, gt
    af94:      	movz	x16, #0x0, lsl #48
    af98:      	sub	x15, x16, x13
    af9c:      	sub	x19, x15, #0x1
    afa0:      	uxtb	w16, w14
    afa4:      	cmp	w16, wzr
    afa8:      	b.eq	0xafe8 <_stogir.stack.valid-frame-object-inputs?+0x214>
    afac:      	ldr	x15, [x0, #0x8]
    afb0:      	cmp	x13, x15
    afb4:      	b.ge	0xaea8 <_stogir.stack.valid-frame-object-inputs?+0xd4>
    afb8:      	ldr	x15, [x3, #0x8]
    afbc:      	cmp	x13, x15
    afc0:      	b.ge	0xae98 <_stogir.stack.valid-frame-object-inputs?+0xc4>
    afc4:      	lsl	x15, x13, #2
    afc8:      	ldr	x20, [x0, #0x78]
    afcc:      	add	x15, x15, x20
    afd0:      	ldr	w15, [x15]
    afd4:      	sxtw	x15, w15
    afd8:      	cmp	x15, #0x0
    afdc:      	cset	w15, ge
    afe0:      	ubfx	x15, x15, #0, #8
    afe4:      	b	0xae9c <_stogir.stack.valid-frame-object-inputs?+0xc8>
    afe8:      	cmp	x13, #0x0
    afec:      	b.ge	0xaeb0 <_stogir.stack.valid-frame-object-inputs?+0xdc>
    aff0:      	ldr	x20, [x4, #0x8]
    aff4:      	ldr	x21, [x5, #0x8]
    aff8:      	cmp	x20, x21
    affc:      	b.ne	0xaea0 <_stogir.stack.valid-frame-object-inputs?+0xcc>
    b000:      	cmp	x15, x20
    b004:      	b.gt	0xae28 <_stogir.stack.valid-frame-object-inputs?+0x54>
    b008:      	lsl	x15, x19, #2
    b00c:      	ldr	x20, [x0, #0x50]
    b010:      	add	x15, x15, x20
    b014:      	ldr	w15, [x15]
    b018:      	sxtw	x15, w15
    b01c:      	cmp	x15, #0x0
    b020:      	cset	w15, gt
    b024:      	ubfx	x15, x15, #0, #8
    b028:      	b	0xae2c <_stogir.stack.valid-frame-object-inputs?+0x58>
    b02c:      	uxtb	w13, w14
    b030:      	asr	x19, x14, #32
    b034:      	str	x14, [x10]
    b038:      	str	x15, [x10, #0x8]
    b03c:      	cmp	x13, #0x68
    b040:      	b.ne	0xb05c <_stogir.stack.valid-frame-object-inputs?+0x288>
    b044:      	cmp	x19, #0x0
    b048:      	cset	w1, eq
    b04c:      	ubfx	x1, x1, #0, #8
    b050:      	mov	x11, x12
    b054:      	mov	x12, #0x1               ; =1
    b058:      	b	0xaf68 <_stogir.stack.valid-frame-object-inputs?+0x194>
    b05c:      	cmp	x12, #0x0
    b060:      	b.le	0xae84 <_stogir.stack.valid-frame-object-inputs?+0xb0>
    b064:      	cmp	x13, #0x51
    b068:      	b.ne	0xae84 <_stogir.stack.valid-frame-object-inputs?+0xb0>
    b06c:      	cmp	x19, #0x0
    b070:      	b.le	0xae84 <_stogir.stack.valid-frame-object-inputs?+0xb0>
    b074:      	cmp	x19, x12
    b078:      	b.ge	0xae84 <_stogir.stack.valid-frame-object-inputs?+0xb0>
    b07c:      	lsr	w15, w15, #0
    b080:      	sxtw	x15, w15
    b084:      	cmp	x15, #0x0
    b088:      	b.ge	0xae84 <_stogir.stack.valid-frame-object-inputs?+0xb0>
    b08c:      	cmp	x15, #0x0
    b090:      	cset	w13, gt
    b094:      	movz	x16, #0x0, lsl #48
    b098:      	sub	x14, x16, x15
    b09c:      	sub	x19, x14, #0x1
    b0a0:      	uxtb	w16, w13
    b0a4:      	cmp	w16, wzr
    b0a8:      	b.eq	0xb1fc <_stogir.stack.valid-frame-object-inputs?+0x428>
    b0ac:      	ldr	x14, [x0, #0x8]
    b0b0:      	cmp	x15, x14
    b0b4:      	b.ge	0xb1f4 <_stogir.stack.valid-frame-object-inputs?+0x420>
    b0b8:      	ldr	x14, [x6, #0x8]
    b0bc:      	cmp	x15, x14
    b0c0:      	b.ge	0xb240 <_stogir.stack.valid-frame-object-inputs?+0x46c>
    b0c4:      	lsl	x14, x15, #2
    b0c8:      	ldr	x20, [x0, #0x78]
    b0cc:      	add	x14, x14, x20
    b0d0:      	ldr	w14, [x14]
    b0d4:      	sxtw	x14, w14
    b0d8:      	cmp	x14, #0x0
    b0dc:      	cset	w14, ge
    b0e0:      	ubfx	x14, x14, #0, #8
    b0e4:      	b	0xb244 <_stogir.stack.valid-frame-object-inputs?+0x470>
    b0e8:      	cmp	x1, #0x0
    b0ec:      	b.eq	0xb0f8 <_stogir.stack.valid-frame-object-inputs?+0x324>
    b0f0:      	mov	x1, x11
    b0f4:      	b	0xb0fc <_stogir.stack.valid-frame-object-inputs?+0x328>
    b0f8:      	movz	x1, #0x0, lsl #48
    b0fc:      	mov	sp, x9
    b100:      	cmp	x1, #0x0
    b104:      	b.eq	0xb160 <_stogir.stack.valid-frame-object-inputs?+0x38c>
    b108:      	sxtw	x1, w2
    b10c:      	cmp	x1, #0x0
    b110:      	b.ge	0xb184 <_stogir.stack.valid-frame-object-inputs?+0x3b0>
    b114:      	lsr	w2, w2, #0
    b118:      	add	x8, x29, #0x10
    b11c:      	mov	w1, w2
    b120:      	bl	0xb120 <_stogir.stack.valid-frame-object-inputs?+0x34c>
		000000000000b120:  ARM64_RELOC_BRANCH26	_stogir.stack.constant-size
    b124:      	add	x16, x29, #0x10
    b128:      	ldr	w0, [x16]
    b12c:      	lsr	x16, x0, #0
    b130:      	cmp	x16, #0x1
    b134:      	b.eq	0xb150 <_stogir.stack.valid-frame-object-inputs?+0x37c>
    b138:      	b.lo	0xb140 <_stogir.stack.valid-frame-object-inputs?+0x36c>
    b13c:      	b	0xb154 <_stogir.stack.valid-frame-object-inputs?+0x380>
    b140:      	cmp	x16, #0x0
    b144:      	b.eq	0xb14c <_stogir.stack.valid-frame-object-inputs?+0x378>
    b148:      	b	0xb154 <_stogir.stack.valid-frame-object-inputs?+0x380>
    b14c:      	b	0xb18c <_stogir.stack.valid-frame-object-inputs?+0x3b8>
    b150:      	b	0xb158 <_stogir.stack.valid-frame-object-inputs?+0x384>
    b154:      	b	0xb254 <_stogir.stack.valid-frame-object-inputs?+0x480>
    b158:      	movz	x0, #0x0, lsl #48
    b15c:      	b	0xb1a0 <_stogir.stack.valid-frame-object-inputs?+0x3cc>
    b160:      	movz	x0, #0x0, lsl #48
    b164:      	sub	sp, x29, #0x0
    b168:      	ldr	x19, [sp, #0x30]
    b16c:      	ldr	x20, [sp, #0x38]
    b170:      	ldr	x21, [sp, #0x40]
    b174:      	ldr	x29, [sp]
    b178:      	ldr	x30, [sp, #0x8]
    b17c:      	add	sp, sp, #0x50
    b180:      	ret
    b184:      	movz	x0, #0x0, lsl #48
    b188:      	b	0xb164 <_stogir.stack.valid-frame-object-inputs?+0x390>
    b18c:      	add	x16, x29, #0x10
    b190:      	ldr	x0, [x16, #0x8]
    b194:      	cmp	x0, #0x0
    b198:      	cset	w0, gt
    b19c:      	ubfx	x0, x0, #0, #8
    b1a0:      	b	0xb188 <_stogir.stack.valid-frame-object-inputs?+0x3b4>
    b1a4:      	brk	#0
    b1a8:      	b	0xb1a4 <_stogir.stack.valid-frame-object-inputs?+0x3d0>
    b1ac:      	lsl	x13, x19, #4
    b1b0:      	ldr	x14, [x0, #0x28]
    b1b4:      	add	x13, x13, x14
    b1b8:      	ldr	x13, [x13]
    b1bc:      	mov	x14, x13
    b1c0:      	mov	x13, #0x1               ; =1
    b1c4:      	b	0xae38 <_stogir.stack.valid-frame-object-inputs?+0x64>
    b1c8:      	movz	x14, #0x0, lsl #48
    b1cc:      	cmp	x14, #0x0
    b1d0:      	b.eq	0xae30 <_stogir.stack.valid-frame-object-inputs?+0x5c>
    b1d4:      	uxtb	w16, w13
    b1d8:      	cmp	w16, wzr
    b1dc:      	b.eq	0xb1ac <_stogir.stack.valid-frame-object-inputs?+0x3d8>
    b1e0:      	lsl	x13, x15, #4
    b1e4:      	ldr	x14, [x0]
    b1e8:      	add	x13, x13, x14
    b1ec:      	ldr	x13, [x13]
    b1f0:      	b	0xb1bc <_stogir.stack.valid-frame-object-inputs?+0x3e8>
    b1f4:      	movz	x14, #0x0, lsl #48
    b1f8:      	b	0xb1cc <_stogir.stack.valid-frame-object-inputs?+0x3f8>
    b1fc:      	ldr	x20, [x7, #0x8]
    b200:      	ldr	x21, [x8, #0x8]
    b204:      	cmp	x20, x21
    b208:      	b.ne	0xb1c8 <_stogir.stack.valid-frame-object-inputs?+0x3f4>
    b20c:      	cmp	x14, x20
    b210:      	b.gt	0xb238 <_stogir.stack.valid-frame-object-inputs?+0x464>
    b214:      	lsl	x14, x19, #2
    b218:      	ldr	x20, [x0, #0x50]
    b21c:      	add	x14, x14, x20
    b220:      	ldr	w14, [x14]
    b224:      	sxtw	x14, w14
    b228:      	cmp	x14, #0x0
    b22c:      	cset	w14, gt
    b230:      	ubfx	x14, x14, #0, #8
    b234:      	b	0xb23c <_stogir.stack.valid-frame-object-inputs?+0x468>
    b238:      	movz	x14, #0x0, lsl #48
    b23c:      	b	0xb1cc <_stogir.stack.valid-frame-object-inputs?+0x3f8>
    b240:      	movz	x14, #0x0, lsl #48
    b244:      	b	0xb1f8 <_stogir.stack.valid-frame-object-inputs?+0x424>
    b248:      	ldr	w12, [x10, #0x4]
    b24c:      	sxtw	x12, w12
    b250:      	b	0xae88 <_stogir.stack.valid-frame-object-inputs?+0xb4>
    b254:      	brk	#0
    b258:      	b	0xb254 <_stogir.stack.valid-frame-object-inputs?+0x480>
    b25c:      	brk	#0
    b260:      	b	0xb25c <_stogir.stack.valid-frame-object-inputs?+0x488>

000000000000b264 <_stogir.stack.validate-scope-inputs>:
    b264:      	sxtw	x1, w1
    b268:      	cmp	x1, #0x53
    b26c:      	cset	w5, eq
    b270:      	uxtb	w16, w5
    b274:      	cmp	w16, wzr
    b278:      	b.ne	0xb2ac <_stogir.stack.validate-scope-inputs+0x48>
    b27c:      	cmp	x1, #0x54
    b280:      	b.eq	0xb2ac <_stogir.stack.validate-scope-inputs+0x48>
    b284:      	adrp	x16, 0xb000 <_stogir.stack.valid-frame-object-inputs?+0x22c>
		000000000000b284:  ARM64_RELOC_PAGE21	l_stogir.448
    b288:      	ldr	x16, [x16]
		000000000000b288:  ARM64_RELOC_PAGEOFF12	l_stogir.448
    b28c:      	orr	x0, x16, xzr
    b290:      	mov	x1, x0
    b294:      	mov	x0, #0x1                ; =1
    b298:      	mov	x2, #0x22               ; =34
    b29c:      	str	x0, [x8]
    b2a0:      	str	x1, [x8, #0x8]
    b2a4:      	str	x2, [x8, #0x10]
    b2a8:      	ret
    b2ac:      	uxtb	w16, w5
    b2b0:      	cmp	w16, wzr
    b2b4:      	mov	x16, #0x6               ; =6
    b2b8:      	movz	x17, #0x0, lsl #48
    b2bc:      	csel	x1, x16, x17, ne
    b2c0:      	sxtw	x2, w2
    b2c4:      	lsr	w1, w1, #0
    b2c8:      	sxtw	x1, w1
    b2cc:      	cmp	x2, x1
    b2d0:      	b.ne	0xb284 <_stogir.stack.validate-scope-inputs+0x20>
    b2d4:      	sxtw	x3, w3
    b2d8:      	cmp	x3, #0x0
    b2dc:      	cset	w1, gt
    b2e0:      	movz	x16, #0x0, lsl #48
    b2e4:      	sub	x2, x16, x3
    b2e8:      	sub	x6, x2, #0x1
    b2ec:      	uxtb	w16, w1
    b2f0:      	cmp	w16, wzr
    b2f4:      	b.eq	0xb3dc <_stogir.stack.validate-scope-inputs+0x178>
    b2f8:      	ldr	x2, [x0, #0x8]
    b2fc:      	cmp	x3, x2
    b300:      	b.ge	0xb3d4 <_stogir.stack.validate-scope-inputs+0x170>
    b304:      	add	x2, x0, #0x78
    b308:      	ldr	x2, [x2, #0x8]
    b30c:      	cmp	x3, x2
    b310:      	b.ge	0xb484 <_stogir.stack.validate-scope-inputs+0x220>
    b314:      	lsl	x2, x3, #2
    b318:      	ldr	x7, [x0, #0x78]
    b31c:      	add	x2, x2, x7
    b320:      	ldr	w2, [x2]
    b324:      	sxtw	x2, w2
    b328:      	cmp	x2, #0x0
    b32c:      	cset	w2, ge
    b330:      	ubfx	x2, x2, #0, #8
    b334:      	b	0xb488 <_stogir.stack.validate-scope-inputs+0x224>
    b338:      	movz	x1, #0x0, lsl #48
    b33c:      	movz	x2, #0x0, lsl #48
    b340:      	lsr	w1, w1, #0
    b344:      	lsr	x16, x1, #0
    b348:      	cmp	x16, #0x1
    b34c:      	b.eq	0xb368 <_stogir.stack.validate-scope-inputs+0x104>
    b350:      	b.lo	0xb358 <_stogir.stack.validate-scope-inputs+0xf4>
    b354:      	b	0xb36c <_stogir.stack.validate-scope-inputs+0x108>
    b358:      	cmp	x16, #0x0
    b35c:      	b.eq	0xb364 <_stogir.stack.validate-scope-inputs+0x100>
    b360:      	b	0xb36c <_stogir.stack.validate-scope-inputs+0x108>
    b364:      	b	0xb370 <_stogir.stack.validate-scope-inputs+0x10c>
    b368:      	b	0xb428 <_stogir.stack.validate-scope-inputs+0x1c4>
    b36c:      	b	0xb658 <_stogir.stack.validate-scope-inputs+0x3f4>
    b370:      	adrp	x16, 0xb000 <_stogir.stack.valid-frame-object-inputs?+0x22c>
		000000000000b370:  ARM64_RELOC_PAGE21	l_stogir.449
    b374:      	ldr	x16, [x16]
		000000000000b374:  ARM64_RELOC_PAGEOFF12	l_stogir.449
    b378:      	orr	x0, x16, xzr
    b37c:      	mov	x1, x0
    b380:      	mov	x0, #0x1                ; =1
    b384:      	mov	x2, #0x1b               ; =27
    b388:      	b	0xb29c <_stogir.stack.validate-scope-inputs+0x38>
    b38c:      	lsl	x1, x6, #4
    b390:      	ldr	x2, [x0, #0x28]
    b394:      	add	x1, x1, x2
    b398:      	ldr	x1, [x1]
    b39c:      	mov	x2, x1
    b3a0:      	mov	x1, #0x1                ; =1
    b3a4:      	b	0xb340 <_stogir.stack.validate-scope-inputs+0xdc>
    b3a8:      	movz	x2, #0x0, lsl #48
    b3ac:      	cmp	x2, #0x0
    b3b0:      	b.eq	0xb338 <_stogir.stack.validate-scope-inputs+0xd4>
    b3b4:      	uxtb	w16, w1
    b3b8:      	cmp	w16, wzr
    b3bc:      	b.eq	0xb38c <_stogir.stack.validate-scope-inputs+0x128>
    b3c0:      	lsl	x1, x3, #4
    b3c4:      	ldr	x2, [x0]
    b3c8:      	add	x1, x1, x2
    b3cc:      	ldr	x1, [x1]
    b3d0:      	b	0xb39c <_stogir.stack.validate-scope-inputs+0x138>
    b3d4:      	movz	x2, #0x0, lsl #48
    b3d8:      	b	0xb3ac <_stogir.stack.validate-scope-inputs+0x148>
    b3dc:      	cmp	x3, #0x0
    b3e0:      	b.ge	0xb3a8 <_stogir.stack.validate-scope-inputs+0x144>
    b3e4:      	add	x7, x0, #0x28
    b3e8:      	add	x9, x0, #0x50
    b3ec:      	ldr	x7, [x7, #0x8]
    b3f0:      	ldr	x9, [x9, #0x8]
    b3f4:      	cmp	x7, x9
    b3f8:      	b.ne	0xb47c <_stogir.stack.validate-scope-inputs+0x218>
    b3fc:      	cmp	x2, x7
    b400:      	b.gt	0xb48c <_stogir.stack.validate-scope-inputs+0x228>
    b404:      	lsl	x2, x6, #2
    b408:      	ldr	x7, [x0, #0x50]
    b40c:      	add	x2, x2, x7
    b410:      	ldr	w2, [x2]
    b414:      	sxtw	x2, w2
    b418:      	cmp	x2, #0x0
    b41c:      	cset	w2, gt
    b420:      	ubfx	x2, x2, #0, #8
    b424:      	b	0xb490 <_stogir.stack.validate-scope-inputs+0x22c>
    b428:      	cmp	x3, #0x0
    b42c:      	b.le	0xb460 <_stogir.stack.validate-scope-inputs+0x1fc>
    b430:      	uxtb	w2, w2
    b434:      	cmp	x2, #0x83
    b438:      	cset	w1, lt
    b43c:      	uxtb	w16, w1
    b440:      	cmp	w16, wzr
    b444:      	b.eq	0xb494 <_stogir.stack.validate-scope-inputs+0x230>
    b448:      	adrp	x16, 0xb000 <_stogir.stack.valid-frame-object-inputs?+0x22c>
		000000000000b448:  ARM64_RELOC_PAGE21	l_stogir.450
    b44c:      	ldr	x16, [x16]
		000000000000b44c:  ARM64_RELOC_PAGEOFF12	l_stogir.450
    b450:      	orr	x3, x16, xzr
    b454:      	add	x3, x2, x3
    b458:      	ldrb	w3, [x3]
    b45c:      	b	0xb498 <_stogir.stack.validate-scope-inputs+0x234>
    b460:      	adrp	x16, 0xb000 <_stogir.stack.valid-frame-object-inputs?+0x22c>
		000000000000b460:  ARM64_RELOC_PAGE21	l_stogir.451
    b464:      	ldr	x16, [x16]
		000000000000b464:  ARM64_RELOC_PAGEOFF12	l_stogir.451
    b468:      	orr	x0, x16, xzr
    b46c:      	mov	x1, x0
    b470:      	mov	x0, #0x1                ; =1
    b474:      	mov	x2, #0x1b               ; =27
    b478:      	b	0xb388 <_stogir.stack.validate-scope-inputs+0x124>
    b47c:      	movz	x2, #0x0, lsl #48
    b480:      	b	0xb3ac <_stogir.stack.validate-scope-inputs+0x148>
    b484:      	movz	x2, #0x0, lsl #48
    b488:      	b	0xb3d8 <_stogir.stack.validate-scope-inputs+0x174>
    b48c:      	movz	x2, #0x0, lsl #48
    b490:      	b	0xb480 <_stogir.stack.validate-scope-inputs+0x21c>
    b494:      	movz	x3, #0x0, lsl #48
    b498:      	uxtb	w3, w3
    b49c:      	and	x3, x3, #0x1
    b4a0:      	uxtb	w3, w3
    b4a4:      	cmp	x3, #0x0
    b4a8:      	b.eq	0xb460 <_stogir.stack.validate-scope-inputs+0x1fc>
    b4ac:      	uxtb	w16, w1
    b4b0:      	cmp	w16, wzr
    b4b4:      	b.eq	0xb4d0 <_stogir.stack.validate-scope-inputs+0x26c>
    b4b8:      	adrp	x16, 0xb000 <_stogir.stack.valid-frame-object-inputs?+0x22c>
		000000000000b4b8:  ARM64_RELOC_PAGE21	l_stogir.450
    b4bc:      	ldr	x16, [x16]
		000000000000b4bc:  ARM64_RELOC_PAGEOFF12	l_stogir.450
    b4c0:      	orr	x1, x16, xzr
    b4c4:      	add	x1, x2, x1
    b4c8:      	ldrb	w1, [x1]
    b4cc:      	b	0xb4d4 <_stogir.stack.validate-scope-inputs+0x270>
    b4d0:      	movz	x1, #0x0, lsl #48
    b4d4:      	uxtb	w1, w1
    b4d8:      	and	x1, x1, #0x4
    b4dc:      	uxtb	w1, w1
    b4e0:      	cmp	x1, #0x0
    b4e4:      	b.ne	0xb460 <_stogir.stack.validate-scope-inputs+0x1fc>
    b4e8:      	uxtb	w16, w5
    b4ec:      	cmp	w16, wzr
    b4f0:      	b.eq	0xb504 <_stogir.stack.validate-scope-inputs+0x2a0>
    b4f4:      	movz	x0, #0x0, lsl #48
    b4f8:      	mov	x1, #0x8                ; =8
    b4fc:      	movz	x2, #0x0, lsl #48
    b500:      	b	0xb478 <_stogir.stack.validate-scope-inputs+0x214>
    b504:      	sxtw	x4, w4
    b508:      	cmp	x4, #0x0
    b50c:      	cset	w1, gt
    b510:      	movz	x16, #0x0, lsl #48
    b514:      	sub	x2, x16, x4
    b518:      	sub	x3, x2, #0x1
    b51c:      	uxtb	w16, w1
    b520:      	cmp	w16, wzr
    b524:      	b.eq	0xb60c <_stogir.stack.validate-scope-inputs+0x3a8>
    b528:      	ldr	x2, [x0, #0x8]
    b52c:      	cmp	x4, x2
    b530:      	b.ge	0xb604 <_stogir.stack.validate-scope-inputs+0x3a0>
    b534:      	add	x2, x0, #0x78
    b538:      	ldr	x2, [x2, #0x8]
    b53c:      	cmp	x4, x2
    b540:      	b.ge	0xb6b0 <_stogir.stack.validate-scope-inputs+0x44c>
    b544:      	lsl	x2, x4, #2
    b548:      	ldr	x5, [x0, #0x78]
    b54c:      	add	x2, x2, x5
    b550:      	ldr	w2, [x2]
    b554:      	sxtw	x2, w2
    b558:      	cmp	x2, #0x0
    b55c:      	cset	w2, ge
    b560:      	ubfx	x2, x2, #0, #8
    b564:      	b	0xb6b4 <_stogir.stack.validate-scope-inputs+0x450>
    b568:      	movz	x0, #0x0, lsl #48
    b56c:      	movz	x1, #0x0, lsl #48
    b570:      	lsr	w0, w0, #0
    b574:      	lsr	x16, x0, #0
    b578:      	cmp	x16, #0x1
    b57c:      	b.eq	0xb598 <_stogir.stack.validate-scope-inputs+0x334>
    b580:      	b.lo	0xb588 <_stogir.stack.validate-scope-inputs+0x324>
    b584:      	b	0xb59c <_stogir.stack.validate-scope-inputs+0x338>
    b588:      	cmp	x16, #0x0
    b58c:      	b.eq	0xb594 <_stogir.stack.validate-scope-inputs+0x330>
    b590:      	b	0xb59c <_stogir.stack.validate-scope-inputs+0x338>
    b594:      	b	0xb5a0 <_stogir.stack.validate-scope-inputs+0x33c>
    b598:      	b	0xb660 <_stogir.stack.validate-scope-inputs+0x3fc>
    b59c:      	b	0xb6c0 <_stogir.stack.validate-scope-inputs+0x45c>
    b5a0:      	adrp	x16, 0xb000 <_stogir.stack.valid-frame-object-inputs?+0x22c>
		000000000000b5a0:  ARM64_RELOC_PAGE21	l_stogir.452
    b5a4:      	ldr	x16, [x16]
		000000000000b5a4:  ARM64_RELOC_PAGEOFF12	l_stogir.452
    b5a8:      	orr	x0, x16, xzr
    b5ac:      	mov	x1, x0
    b5b0:      	mov	x0, #0x1                ; =1
    b5b4:      	mov	x2, #0x1b               ; =27
    b5b8:      	b	0xb500 <_stogir.stack.validate-scope-inputs+0x29c>
    b5bc:      	lsl	x1, x3, #4
    b5c0:      	ldr	x0, [x0, #0x28]
    b5c4:      	add	x0, x1, x0
    b5c8:      	ldr	x0, [x0]
    b5cc:      	mov	x1, x0
    b5d0:      	mov	x0, #0x1                ; =1
    b5d4:      	b	0xb570 <_stogir.stack.validate-scope-inputs+0x30c>
    b5d8:      	movz	x2, #0x0, lsl #48
    b5dc:      	cmp	x2, #0x0
    b5e0:      	b.eq	0xb568 <_stogir.stack.validate-scope-inputs+0x304>
    b5e4:      	uxtb	w16, w1
    b5e8:      	cmp	w16, wzr
    b5ec:      	b.eq	0xb5bc <_stogir.stack.validate-scope-inputs+0x358>
    b5f0:      	lsl	x1, x4, #4
    b5f4:      	ldr	x0, [x0]
    b5f8:      	add	x0, x1, x0
    b5fc:      	ldr	x0, [x0]
    b600:      	b	0xb5cc <_stogir.stack.validate-scope-inputs+0x368>
    b604:      	movz	x2, #0x0, lsl #48
    b608:      	b	0xb5dc <_stogir.stack.validate-scope-inputs+0x378>
    b60c:      	cmp	x4, #0x0
    b610:      	b.ge	0xb5d8 <_stogir.stack.validate-scope-inputs+0x374>
    b614:      	add	x5, x0, #0x28
    b618:      	add	x6, x0, #0x50
    b61c:      	ldr	x5, [x5, #0x8]
    b620:      	ldr	x6, [x6, #0x8]
    b624:      	cmp	x5, x6
    b628:      	b.ne	0xb6a8 <_stogir.stack.validate-scope-inputs+0x444>
    b62c:      	cmp	x2, x5
    b630:      	b.gt	0xb6b8 <_stogir.stack.validate-scope-inputs+0x454>
    b634:      	lsl	x2, x3, #2
    b638:      	ldr	x5, [x0, #0x50]
    b63c:      	add	x2, x2, x5
    b640:      	ldr	w2, [x2]
    b644:      	sxtw	x2, w2
    b648:      	cmp	x2, #0x0
    b64c:      	cset	w2, gt
    b650:      	ubfx	x2, x2, #0, #8
    b654:      	b	0xb6bc <_stogir.stack.validate-scope-inputs+0x458>
    b658:      	brk	#0
    b65c:      	b	0xb658 <_stogir.stack.validate-scope-inputs+0x3f4>
    b660:      	lsr	w0, w1, #0
    b664:      	ubfx	x0, x0, #8, #8
    b668:      	cmp	x0, #0x6
    b66c:      	b.ne	0xb68c <_stogir.stack.validate-scope-inputs+0x428>
    b670:      	uxtb	w1, w1
    b674:      	cmp	x1, #0x48
    b678:      	b.eq	0xb68c <_stogir.stack.validate-scope-inputs+0x428>
    b67c:      	movz	x0, #0x0, lsl #48
    b680:      	mov	x1, #0x8                ; =8
    b684:      	movz	x2, #0x0, lsl #48
    b688:      	b	0xb6a4 <_stogir.stack.validate-scope-inputs+0x440>
    b68c:      	adrp	x16, 0xb000 <_stogir.stack.valid-frame-object-inputs?+0x22c>
		000000000000b68c:  ARM64_RELOC_PAGE21	l_stogir.453
    b690:      	ldr	x16, [x16]
		000000000000b690:  ARM64_RELOC_PAGEOFF12	l_stogir.453
    b694:      	orr	x0, x16, xzr
    b698:      	mov	x1, x0
    b69c:      	mov	x0, #0x1                ; =1
    b6a0:      	mov	x2, #0x29               ; =41
    b6a4:      	b	0xb5b8 <_stogir.stack.validate-scope-inputs+0x354>
    b6a8:      	movz	x2, #0x0, lsl #48
    b6ac:      	b	0xb5dc <_stogir.stack.validate-scope-inputs+0x378>
    b6b0:      	movz	x2, #0x0, lsl #48
    b6b4:      	b	0xb608 <_stogir.stack.validate-scope-inputs+0x3a4>
    b6b8:      	movz	x2, #0x0, lsl #48
    b6bc:      	b	0xb6ac <_stogir.stack.validate-scope-inputs+0x448>
    b6c0:      	brk	#0
    b6c4:      	b	0xb6c0 <_stogir.stack.validate-scope-inputs+0x45c>

000000000000b6c8 <_stogir.stack.validate-inputs>:
    b6c8:      	sub	sp, sp, #0x110
    b6cc:      	str	x29, [sp]
    b6d0:      	str	x30, [sp, #0x8]
    b6d4:      	mov	x29, sp
    b6d8:      	str	x19, [sp, #0xb8]
    b6dc:      	str	x20, [sp, #0xc0]
    b6e0:      	str	x21, [sp, #0xc8]
    b6e4:      	str	x22, [sp, #0xd0]
    b6e8:      	str	x23, [sp, #0xd8]
    b6ec:      	str	x24, [sp, #0xe0]
    b6f0:      	str	x25, [sp, #0xe8]
    b6f4:      	str	x26, [sp, #0xf0]
    b6f8:      	str	x27, [sp, #0xf8]
    b6fc:      	str	x28, [sp, #0x100]
    b700:      	sxtw	x1, w1
    b704:      	cmp	x1, #0x51
    b708:      	cset	w19, eq
    b70c:      	uxtb	w16, w19
    b710:      	cmp	w16, wzr
    b714:      	b.ne	0xb784 <_stogir.stack.validate-inputs+0xbc>
    b718:      	cmp	x1, #0x52
    b71c:      	b.eq	0xb784 <_stogir.stack.validate-inputs+0xbc>
    b720:      	str	x8, [sp, #0x90]
    b724:      	adrp	x16, 0xb000 <_stogir.stack.valid-frame-object-inputs?+0x22c>
		000000000000b724:  ARM64_RELOC_PAGE21	l_stogir.454
    b728:      	ldr	x16, [x16]
		000000000000b728:  ARM64_RELOC_PAGEOFF12	l_stogir.454
    b72c:      	orr	x0, x16, xzr
    b730:      	mov	x1, x0
    b734:      	mov	x0, #0x1                ; =1
    b738:      	mov	x2, #0x29               ; =41
    b73c:      	ldr	x3, [sp, #0x90]
    b740:      	str	x0, [x3]
    b744:      	str	x1, [x3, #0x8]
    b748:      	str	x2, [x3, #0x10]
    b74c:      	ldr	x19, [sp, #0xb8]
    b750:      	ldr	x20, [sp, #0xc0]
    b754:      	ldr	x21, [sp, #0xc8]
    b758:      	ldr	x22, [sp, #0xd0]
    b75c:      	ldr	x23, [sp, #0xd8]
    b760:      	ldr	x24, [sp, #0xe0]
    b764:      	ldr	x25, [sp, #0xe8]
    b768:      	ldr	x26, [sp, #0xf0]
    b76c:      	ldr	x27, [sp, #0xf8]
    b770:      	ldr	x28, [sp, #0x100]
    b774:      	ldr	x29, [sp]
    b778:      	ldr	x30, [sp, #0x8]
    b77c:      	add	sp, sp, #0x110
    b780:      	ret
    b784:      	uxtb	w16, w19
    b788:      	cmp	w16, wzr
    b78c:      	mov	x16, #0x6               ; =6
    b790:      	movz	x17, #0x0, lsl #48
    b794:      	csel	x1, x16, x17, ne
    b798:      	sxtw	x2, w2
    b79c:      	lsr	w1, w1, #0
    b7a0:      	sxtw	x1, w1
    b7a4:      	cmp	x2, x1
    b7a8:      	b.ne	0xbd08 <_stogir.stack.validate-inputs+0x640>
    b7ac:      	sxtw	x20, w5
    b7b0:      	uxtb	w16, w19
    b7b4:      	cmp	w16, wzr
    b7b8:      	b.eq	0xb7e4 <_stogir.stack.validate-inputs+0x11c>
    b7bc:      	cmp	x20, #0x0
    b7c0:      	b.eq	0xb7e4 <_stogir.stack.validate-inputs+0x11c>
    b7c4:      	cmp	x20, #0x0
    b7c8:      	b.le	0xb8bc <_stogir.stack.validate-inputs+0x1f4>
    b7cc:      	sub	x1, x20, #0x1
    b7d0:      	and	x1, x1, x20
    b7d4:      	cmp	x1, #0x0
    b7d8:      	cset	w1, eq
    b7dc:      	ubfx	x1, x1, #0, #8
    b7e0:      	b	0xb8c0 <_stogir.stack.validate-inputs+0x1f8>
    b7e4:      	lsr	w3, w3, #0
    b7e8:      	mov	w1, w3
    b7ec:      	mov	x21, x8
    b7f0:      	add	x8, sp, #0x10
    b7f4:      	mov	x22, x0
    b7f8:      	mov	w23, w3
    b7fc:      	mov	w24, w4
    b800:      	bl	0xb800 <_stogir.stack.validate-inputs+0x138>
		000000000000b800:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    b804:      	add	x16, sp, #0x10
    b808:      	ldr	w0, [x16]
    b80c:      	lsr	x16, x0, #0
    b810:      	cmp	x16, #0x1
    b814:      	b.eq	0xb830 <_stogir.stack.validate-inputs+0x168>
    b818:      	b.lo	0xb820 <_stogir.stack.validate-inputs+0x158>
    b81c:      	b	0xb834 <_stogir.stack.validate-inputs+0x16c>
    b820:      	cmp	x16, #0x0
    b824:      	b.eq	0xb82c <_stogir.stack.validate-inputs+0x164>
    b828:      	b	0xb834 <_stogir.stack.validate-inputs+0x16c>
    b82c:      	b	0xb838 <_stogir.stack.validate-inputs+0x170>
    b830:      	b	0xb858 <_stogir.stack.validate-inputs+0x190>
    b834:      	b	0xba80 <_stogir.stack.validate-inputs+0x3b8>
    b838:      	adrp	x16, 0xb000 <_stogir.stack.valid-frame-object-inputs?+0x22c>
		000000000000b838:  ARM64_RELOC_PAGE21	l_stogir.455
    b83c:      	ldr	x16, [x16]
		000000000000b83c:  ARM64_RELOC_PAGEOFF12	l_stogir.455
    b840:      	orr	x0, x16, xzr
    b844:      	str	x21, [sp, #0x90]
    b848:      	mov	x1, x0
    b84c:      	mov	x0, #0x1                ; =1
    b850:      	mov	x2, #0x1f               ; =31
    b854:      	b	0xb73c <_stogir.stack.validate-inputs+0x74>
    b858:      	sxtw	x23, w23
    b85c:      	add	x16, sp, #0x10
    b860:      	ldr	x0, [x16, #0x8]
    b864:      	cmp	x23, #0x0
    b868:      	b.gt	0xb88c <_stogir.stack.validate-inputs+0x1c4>
    b86c:      	str	x21, [sp, #0x90]
    b870:      	adrp	x16, 0xb000 <_stogir.stack.valid-frame-object-inputs?+0x22c>
		000000000000b870:  ARM64_RELOC_PAGE21	l_stogir.456
    b874:      	ldr	x16, [x16]
		000000000000b874:  ARM64_RELOC_PAGEOFF12	l_stogir.456
    b878:      	orr	x0, x16, xzr
    b87c:      	mov	x1, x0
    b880:      	mov	x0, #0x1                ; =1
    b884:      	mov	x2, #0x1f               ; =31
    b888:      	b	0xb854 <_stogir.stack.validate-inputs+0x18c>
    b88c:      	uxtb	w0, w0
    b890:      	cmp	x0, #0x83
    b894:      	cset	w1, lt
    b898:      	uxtb	w16, w1
    b89c:      	cmp	w16, wzr
    b8a0:      	b.eq	0xb8d0 <_stogir.stack.validate-inputs+0x208>
    b8a4:      	adrp	x16, 0xb000 <_stogir.stack.valid-frame-object-inputs?+0x22c>
		000000000000b8a4:  ARM64_RELOC_PAGE21	l_stogir.457
    b8a8:      	ldr	x16, [x16]
		000000000000b8a8:  ARM64_RELOC_PAGEOFF12	l_stogir.457
    b8ac:      	orr	x2, x16, xzr
    b8b0:      	add	x2, x0, x2
    b8b4:      	ldrb	w2, [x2]
    b8b8:      	b	0xb8d4 <_stogir.stack.validate-inputs+0x20c>
    b8bc:      	movz	x1, #0x0, lsl #48
    b8c0:      	cmp	x1, #0x0
    b8c4:      	b.ne	0xb7e4 <_stogir.stack.validate-inputs+0x11c>
    b8c8:      	str	x8, [sp, #0x90]
    b8cc:      	b	0xb724 <_stogir.stack.validate-inputs+0x5c>
    b8d0:      	movz	x2, #0x0, lsl #48
    b8d4:      	uxtb	w2, w2
    b8d8:      	and	x2, x2, #0x1
    b8dc:      	uxtb	w2, w2
    b8e0:      	cmp	x2, #0x0
    b8e4:      	b.eq	0xbd10 <_stogir.stack.validate-inputs+0x648>
    b8e8:      	uxtb	w16, w1
    b8ec:      	cmp	w16, wzr
    b8f0:      	b.eq	0xb90c <_stogir.stack.validate-inputs+0x244>
    b8f4:      	adrp	x16, 0xb000 <_stogir.stack.valid-frame-object-inputs?+0x22c>
		000000000000b8f4:  ARM64_RELOC_PAGE21	l_stogir.457
    b8f8:      	ldr	x16, [x16]
		000000000000b8f8:  ARM64_RELOC_PAGEOFF12	l_stogir.457
    b8fc:      	orr	x1, x16, xzr
    b900:      	add	x0, x0, x1
    b904:      	ldrb	w0, [x0]
    b908:      	b	0xb910 <_stogir.stack.validate-inputs+0x248>
    b90c:      	movz	x0, #0x0, lsl #48
    b910:      	uxtb	w0, w0
    b914:      	and	x0, x0, #0x4
    b918:      	uxtb	w0, w0
    b91c:      	cmp	x0, #0x0
    b920:      	b.ne	0xbd18 <_stogir.stack.validate-inputs+0x650>
    b924:      	lsr	w24, w24, #0
    b928:      	add	x8, sp, #0x40
    b92c:      	mov	x0, x22
    b930:      	mov	w1, w24
    b934:      	bl	0xb934 <_stogir.stack.validate-inputs+0x26c>
		000000000000b934:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    b938:      	add	x16, sp, #0x40
    b93c:      	ldr	w0, [x16]
    b940:      	lsr	x16, x0, #0
    b944:      	cmp	x16, #0x1
    b948:      	b.eq	0xb964 <_stogir.stack.validate-inputs+0x29c>
    b94c:      	b.lo	0xb954 <_stogir.stack.validate-inputs+0x28c>
    b950:      	b	0xb968 <_stogir.stack.validate-inputs+0x2a0>
    b954:      	cmp	x16, #0x0
    b958:      	b.eq	0xb960 <_stogir.stack.validate-inputs+0x298>
    b95c:      	b	0xb968 <_stogir.stack.validate-inputs+0x2a0>
    b960:      	b	0xb96c <_stogir.stack.validate-inputs+0x2a4>
    b964:      	b	0xb98c <_stogir.stack.validate-inputs+0x2c4>
    b968:      	b	0xbc10 <_stogir.stack.validate-inputs+0x548>
    b96c:      	adrp	x16, 0xb000 <_stogir.stack.valid-frame-object-inputs?+0x22c>
		000000000000b96c:  ARM64_RELOC_PAGE21	l_stogir.458
    b970:      	ldr	x16, [x16]
		000000000000b970:  ARM64_RELOC_PAGEOFF12	l_stogir.458
    b974:      	orr	x0, x16, xzr
    b978:      	str	x21, [sp, #0x90]
    b97c:      	mov	x1, x0
    b980:      	mov	x0, #0x1                ; =1
    b984:      	mov	x2, #0x18               ; =24
    b988:      	b	0xb888 <_stogir.stack.validate-inputs+0x1c0>
    b98c:      	add	x16, sp, #0x40
    b990:      	ldr	x0, [x16, #0x8]
    b994:      	lsr	w1, w0, #0
    b998:      	ubfx	x1, x1, #8, #8
    b99c:      	cmp	x1, #0x1
    b9a0:      	b.lt	0xbd20 <_stogir.stack.validate-inputs+0x658>
    b9a4:      	cmp	x1, #0xb
    b9a8:      	b.gt	0xbd28 <_stogir.stack.validate-inputs+0x660>
    b9ac:      	uxtb	w0, w0
    b9b0:      	cmp	x0, #0x48
    b9b4:      	b.eq	0xbd30 <_stogir.stack.validate-inputs+0x668>
    b9b8:      	sxtw	x0, w24
    b9bc:      	cmp	x1, #0x0
    b9c0:      	cset	w23, eq
    b9c4:      	cmp	x1, #0x1
    b9c8:      	cset	w25, eq
    b9cc:      	cmp	x1, #0x2
    b9d0:      	cset	w26, eq
    b9d4:      	cmp	x1, #0x7
    b9d8:      	cset	w27, eq
    b9dc:      	cmp	x1, #0x8
    b9e0:      	cset	w28, eq
    b9e4:      	cmp	x1, #0x3
    b9e8:      	cset	w2, eq
    b9ec:      	cmp	x1, #0x9
    b9f0:      	cset	w3, eq
    b9f4:      	cmp	x1, #0x4
    b9f8:      	cset	w4, eq
    b9fc:      	cmp	x1, #0xa
    ba00:      	cset	w5, eq
    ba04:      	cmp	x1, #0xd
    ba08:      	cset	w6, eq
    ba0c:      	cmp	x1, #0x5
    ba10:      	cset	w7, eq
    ba14:      	cmp	x1, #0xb
    ba18:      	cset	w8, eq
    ba1c:      	cmp	x1, #0xc
    ba20:      	cset	w9, eq
    ba24:      	cmp	x1, #0x6
    ba28:      	cset	w1, eq
    ba2c:      	uxtb	w16, w1
    ba30:      	cmp	w16, wzr
    ba34:      	mov	x16, #0x8               ; =8
    ba38:      	movn	x17, #0x0, lsl #48
    ba3c:      	csel	x1, x16, x17, ne
    ba40:      	cmp	x0, #0x0
    ba44:      	b.ge	0xbd38 <_stogir.stack.validate-inputs+0x670>
    ba48:      	uxtb	w16, w19
    ba4c:      	cmp	w16, wzr
    ba50:      	b.eq	0xbb74 <_stogir.stack.validate-inputs+0x4ac>
    ba54:      	cmp	x20, #0x10
    ba58:      	b.le	0xbb74 <_stogir.stack.validate-inputs+0x4ac>
    ba5c:      	mov	x0, x20
    ba60:      	b	0xbb78 <_stogir.stack.validate-inputs+0x4b0>
    ba64:      	adrp	x16, 0xb000 <_stogir.stack.valid-frame-object-inputs?+0x22c>
		000000000000ba64:  ARM64_RELOC_PAGE21	l_stogir.459
    ba68:      	ldr	x16, [x16]
		000000000000ba68:  ARM64_RELOC_PAGEOFF12	l_stogir.459
    ba6c:      	orr	x0, x16, xzr
    ba70:      	mov	x1, x0
    ba74:      	mov	x0, #0x1                ; =1
    ba78:      	mov	x2, #0x29               ; =41
    ba7c:      	b	0xb988 <_stogir.stack.validate-inputs+0x2c0>
    ba80:      	brk	#0
    ba84:      	b	0xba80 <_stogir.stack.validate-inputs+0x3b8>
    ba88:      	mov	x0, #0x1                ; =1
    ba8c:      	lsr	w0, w0, #0
    ba90:      	sxtw	x0, w0
    ba94:      	and	x0, x0, #0xffffffff
    ba98:      	mov	x1, x0
    ba9c:      	movz	x0, #0x0, lsl #48
    baa0:      	movz	x2, #0x0, lsl #48
    baa4:      	b	0xba7c <_stogir.stack.validate-inputs+0x3b4>
    baa8:      	uxtb	w16, w23
    baac:      	cmp	w16, wzr
    bab0:      	b.eq	0xbadc <_stogir.stack.validate-inputs+0x414>
    bab4:      	movz	x0, #0x0, lsl #48
    bab8:      	b	0xba8c <_stogir.stack.validate-inputs+0x3c4>
    babc:      	mov	x0, #0x1                ; =1
    bac0:      	lsr	w0, w0, #0
    bac4:      	sxtw	x0, w0
    bac8:      	and	x0, x0, #0xffffffff
    bacc:      	mov	x1, x0
    bad0:      	movz	x0, #0x0, lsl #48
    bad4:      	movz	x2, #0x0, lsl #48
    bad8:      	b	0xbaa4 <_stogir.stack.validate-inputs+0x3dc>
    badc:      	uxtb	w16, w25
    bae0:      	cmp	w16, wzr
    bae4:      	b.ne	0xba88 <_stogir.stack.validate-inputs+0x3c0>
    bae8:      	uxtb	w16, w26
    baec:      	cmp	w16, wzr
    baf0:      	b.ne	0xba88 <_stogir.stack.validate-inputs+0x3c0>
    baf4:      	uxtb	w16, w27
    baf8:      	cmp	w16, wzr
    bafc:      	b.ne	0xba88 <_stogir.stack.validate-inputs+0x3c0>
    bb00:      	uxtb	w16, w28
    bb04:      	cmp	w16, wzr
    bb08:      	b.ne	0xba88 <_stogir.stack.validate-inputs+0x3c0>
    bb0c:      	uxtb	w16, w19
    bb10:      	cmp	w16, wzr
    bb14:      	b.ne	0xbcd0 <_stogir.stack.validate-inputs+0x608>
    bb18:      	uxtb	w16, w20
    bb1c:      	cmp	w16, wzr
    bb20:      	b.ne	0xbcd0 <_stogir.stack.validate-inputs+0x608>
    bb24:      	uxtb	w16, w22
    bb28:      	cmp	w16, wzr
    bb2c:      	b.ne	0xbce8 <_stogir.stack.validate-inputs+0x620>
    bb30:      	uxtb	w16, w24
    bb34:      	cmp	w16, wzr
    bb38:      	b.ne	0xbce8 <_stogir.stack.validate-inputs+0x620>
    bb3c:      	uxtb	w16, w21
    bb40:      	cmp	w16, wzr
    bb44:      	b.ne	0xbce8 <_stogir.stack.validate-inputs+0x620>
    bb48:      	uxtb	w16, w0
    bb4c:      	cmp	w16, wzr
    bb50:      	b.ne	0xbcf8 <_stogir.stack.validate-inputs+0x630>
    bb54:      	uxtb	w16, w1
    bb58:      	cmp	w16, wzr
    bb5c:      	b.ne	0xbcf8 <_stogir.stack.validate-inputs+0x630>
    bb60:      	uxtb	w16, w2
    bb64:      	cmp	w16, wzr
    bb68:      	b.ne	0xbcf8 <_stogir.stack.validate-inputs+0x630>
    bb6c:      	ldr	x0, [sp, #0xb0]
    bb70:      	b	0xbcfc <_stogir.stack.validate-inputs+0x634>
    bb74:      	mov	x0, #0x10               ; =16
    bb78:      	lsr	w24, w24, #0
    bb7c:      	mov	w19, w2
    bb80:      	mov	x2, x0
    bb84:      	mov	x0, x22
    bb88:      	mov	w20, w3
    bb8c:      	mov	w22, w4
    bb90:      	str	w7, [sp, #0x98]
    bb94:      	str	w8, [sp, #0xa0]
    bb98:      	add	x8, sp, #0x70
    bb9c:      	str	w9, [sp, #0xa8]
    bba0:      	str	x1, [sp, #0xb0]
    bba4:      	mov	w1, w24
    bba8:      	mov	w24, w5
    bbac:      	str	x21, [sp, #0x90]
    bbb0:      	mov	w21, w6
    bbb4:      	bl	0xbbb4 <_stogir.stack.validate-inputs+0x4ec>
		000000000000bbb4:  ARM64_RELOC_BRANCH26	_stogir.stack.constant-size-aligned
    bbb8:      	add	x16, sp, #0x70
    bbbc:      	ldr	w0, [x16]
    bbc0:      	lsr	x16, x0, #0
    bbc4:      	cmp	x16, #0x1
    bbc8:      	b.eq	0xbbe4 <_stogir.stack.validate-inputs+0x51c>
    bbcc:      	b.lo	0xbbd4 <_stogir.stack.validate-inputs+0x50c>
    bbd0:      	b	0xbbe8 <_stogir.stack.validate-inputs+0x520>
    bbd4:      	cmp	x16, #0x0
    bbd8:      	b.eq	0xbbe0 <_stogir.stack.validate-inputs+0x518>
    bbdc:      	b	0xbbe8 <_stogir.stack.validate-inputs+0x520>
    bbe0:      	b	0xbc18 <_stogir.stack.validate-inputs+0x550>
    bbe4:      	b	0xbbec <_stogir.stack.validate-inputs+0x524>
    bbe8:      	b	0xbce0 <_stogir.stack.validate-inputs+0x618>
    bbec:      	add	x16, sp, #0x70
    bbf0:      	orr	x0, x16, xzr
    bbf4:      	add	x0, x0, #0x8
    bbf8:      	add	x16, sp, #0x70
    bbfc:      	ldr	x1, [x16, #0x8]
    bc00:      	ldr	x0, [x0, #0x8]
    bc04:      	mov	x2, x0
    bc08:      	mov	x0, #0x1                ; =1
    bc0c:      	b	0xbad8 <_stogir.stack.validate-inputs+0x410>
    bc10:      	brk	#0
    bc14:      	b	0xbc10 <_stogir.stack.validate-inputs+0x548>
    bc18:      	uxtb	w16, w23
    bc1c:      	cmp	w16, wzr
    bc20:      	b.eq	0xbc2c <_stogir.stack.validate-inputs+0x564>
    bc24:      	movz	x0, #0x0, lsl #48
    bc28:      	b	0xbac0 <_stogir.stack.validate-inputs+0x3f8>
    bc2c:      	uxtb	w16, w25
    bc30:      	cmp	w16, wzr
    bc34:      	b.ne	0xbabc <_stogir.stack.validate-inputs+0x3f4>
    bc38:      	uxtb	w16, w26
    bc3c:      	cmp	w16, wzr
    bc40:      	b.ne	0xbabc <_stogir.stack.validate-inputs+0x3f4>
    bc44:      	uxtb	w16, w27
    bc48:      	cmp	w16, wzr
    bc4c:      	b.ne	0xbabc <_stogir.stack.validate-inputs+0x3f4>
    bc50:      	uxtb	w16, w28
    bc54:      	cmp	w16, wzr
    bc58:      	b.ne	0xbabc <_stogir.stack.validate-inputs+0x3f4>
    bc5c:      	uxtb	w16, w19
    bc60:      	cmp	w16, wzr
    bc64:      	b.ne	0xbcd8 <_stogir.stack.validate-inputs+0x610>
    bc68:      	uxtb	w16, w20
    bc6c:      	cmp	w16, wzr
    bc70:      	b.ne	0xbcd8 <_stogir.stack.validate-inputs+0x610>
    bc74:      	uxtb	w16, w22
    bc78:      	cmp	w16, wzr
    bc7c:      	b.ne	0xbcf0 <_stogir.stack.validate-inputs+0x628>
    bc80:      	uxtb	w16, w24
    bc84:      	cmp	w16, wzr
    bc88:      	b.ne	0xbcf0 <_stogir.stack.validate-inputs+0x628>
    bc8c:      	uxtb	w16, w21
    bc90:      	cmp	w16, wzr
    bc94:      	b.ne	0xbcf0 <_stogir.stack.validate-inputs+0x628>
    bc98:      	ldr	w0, [sp, #0x98]
    bc9c:      	uxtb	w16, w0
    bca0:      	cmp	w16, wzr
    bca4:      	b.ne	0xbd00 <_stogir.stack.validate-inputs+0x638>
    bca8:      	ldr	w1, [sp, #0xa0]
    bcac:      	uxtb	w16, w1
    bcb0:      	cmp	w16, wzr
    bcb4:      	b.ne	0xbd00 <_stogir.stack.validate-inputs+0x638>
    bcb8:      	ldr	w2, [sp, #0xa8]
    bcbc:      	uxtb	w16, w2
    bcc0:      	cmp	w16, wzr
    bcc4:      	b.ne	0xbd00 <_stogir.stack.validate-inputs+0x638>
    bcc8:      	ldr	x0, [sp, #0xb0]
    bccc:      	b	0xbd04 <_stogir.stack.validate-inputs+0x63c>
    bcd0:      	mov	x0, #0x2                ; =2
    bcd4:      	b	0xba8c <_stogir.stack.validate-inputs+0x3c4>
    bcd8:      	mov	x0, #0x2                ; =2
    bcdc:      	b	0xbac0 <_stogir.stack.validate-inputs+0x3f8>
    bce0:      	brk	#0
    bce4:      	b	0xbce0 <_stogir.stack.validate-inputs+0x618>
    bce8:      	mov	x0, #0x4                ; =4
    bcec:      	b	0xbcd4 <_stogir.stack.validate-inputs+0x60c>
    bcf0:      	mov	x0, #0x4                ; =4
    bcf4:      	b	0xbcdc <_stogir.stack.validate-inputs+0x614>
    bcf8:      	mov	x0, #0x8                ; =8
    bcfc:      	b	0xbcec <_stogir.stack.validate-inputs+0x624>
    bd00:      	mov	x0, #0x8                ; =8
    bd04:      	b	0xbcf4 <_stogir.stack.validate-inputs+0x62c>
    bd08:      	str	x8, [sp, #0x90]
    bd0c:      	b	0xb724 <_stogir.stack.validate-inputs+0x5c>
    bd10:      	str	x21, [sp, #0x90]
    bd14:      	b	0xb870 <_stogir.stack.validate-inputs+0x1a8>
    bd18:      	str	x21, [sp, #0x90]
    bd1c:      	b	0xb870 <_stogir.stack.validate-inputs+0x1a8>
    bd20:      	str	x21, [sp, #0x90]
    bd24:      	b	0xba64 <_stogir.stack.validate-inputs+0x39c>
    bd28:      	str	x21, [sp, #0x90]
    bd2c:      	b	0xba64 <_stogir.stack.validate-inputs+0x39c>
    bd30:      	str	x21, [sp, #0x90]
    bd34:      	b	0xba64 <_stogir.stack.validate-inputs+0x39c>
    bd38:      	str	x21, [sp, #0x90]
    bd3c:      	str	x1, [sp, #0xb0]
    bd40:      	mov	w19, w2
    bd44:      	mov	w20, w3
    bd48:      	mov	w22, w4
    bd4c:      	mov	w24, w5
    bd50:      	mov	w21, w6
    bd54:      	mov	w0, w7
    bd58:      	mov	w1, w8
    bd5c:      	mov	w2, w9
    bd60:      	b	0xbaa8 <_stogir.stack.validate-inputs+0x3e0>

000000000000bd64 <_stogir.locals.shape>:
    bd64:      	sub	sp, sp, #0x40
    bd68:      	str	x29, [sp]
    bd6c:      	str	x30, [sp, #0x8]
    bd70:      	mov	x29, sp
    bd74:      	str	x19, [sp, #0x20]
    bd78:      	str	x20, [sp, #0x28]
    bd7c:      	str	x21, [sp, #0x30]
    bd80:      	str	x22, [sp, #0x38]
    bd84:      	sxtw	x19, w1
    bd88:      	lsl	x20, x19, #2
    bd8c:      	cmp	x19, #0x0
    bd90:      	cset	w1, gt
    bd94:      	movz	x16, #0x0, lsl #48
    bd98:      	sub	x3, x16, x19
    bd9c:      	sub	x4, x3, #0x1
    bda0:      	uxtb	w16, w1
    bda4:      	cmp	w16, wzr
    bda8:      	b.eq	0xbde8 <_stogir.locals.shape+0x84>
    bdac:      	ldr	x3, [x0, #0x8]
    bdb0:      	cmp	x19, x3
    bdb4:      	b.ge	0xbe58 <_stogir.locals.shape+0xf4>
    bdb8:      	add	x3, x0, #0x78
    bdbc:      	ldr	x3, [x3, #0x8]
    bdc0:      	cmp	x19, x3
    bdc4:      	b.ge	0xc02c <_stogir.locals.shape+0x2c8>
    bdc8:      	ldr	x3, [x0, #0x78]
    bdcc:      	add	x3, x20, x3
    bdd0:      	ldr	w3, [x3]
    bdd4:      	sxtw	x3, w3
    bdd8:      	cmp	x3, #0x0
    bddc:      	cset	w3, ge
    bde0:      	ubfx	x3, x3, #0, #8
    bde4:      	b	0xc030 <_stogir.locals.shape+0x2cc>
    bde8:      	cmp	x19, #0x0
    bdec:      	b.ge	0xbe60 <_stogir.locals.shape+0xfc>
    bdf0:      	add	x5, x0, #0x28
    bdf4:      	add	x6, x0, #0x50
    bdf8:      	ldr	x5, [x5, #0x8]
    bdfc:      	ldr	x6, [x6, #0x8]
    be00:      	cmp	x5, x6
    be04:      	b.ne	0xbe34 <_stogir.locals.shape+0xd0>
    be08:      	cmp	x3, x5
    be0c:      	b.gt	0xc09c <_stogir.locals.shape+0x338>
    be10:      	lsl	x3, x4, #2
    be14:      	ldr	x5, [x0, #0x50]
    be18:      	add	x3, x3, x5
    be1c:      	ldr	w3, [x3]
    be20:      	sxtw	x3, w3
    be24:      	cmp	x3, #0x0
    be28:      	cset	w3, gt
    be2c:      	ubfx	x3, x3, #0, #8
    be30:      	b	0xc0a0 <_stogir.locals.shape+0x33c>
    be34:      	movz	x3, #0x0, lsl #48
    be38:      	b	0xbe64 <_stogir.locals.shape+0x100>
    be3c:      	adrp	x16, 0xb000 <_stogir.stack.valid-frame-object-inputs?+0x22c>
		000000000000be3c:  ARM64_RELOC_PAGE21	l_stogir.460
    be40:      	ldr	x16, [x16]
		000000000000be40:  ARM64_RELOC_PAGEOFF12	l_stogir.460
    be44:      	orr	x0, x16, xzr
    be48:      	mov	x1, x0
    be4c:      	mov	x0, #0x1                ; =1
    be50:      	mov	x2, #0x1c               ; =28
    be54:      	b	0xbf24 <_stogir.locals.shape+0x1c0>
    be58:      	movz	x3, #0x0, lsl #48
    be5c:      	b	0xbe64 <_stogir.locals.shape+0x100>
    be60:      	movz	x3, #0x0, lsl #48
    be64:      	cmp	x3, #0x0
    be68:      	b.eq	0xbecc <_stogir.locals.shape+0x168>
    be6c:      	uxtb	w16, w1
    be70:      	cmp	w16, wzr
    be74:      	b.eq	0xbe9c <_stogir.locals.shape+0x138>
    be78:      	lsl	x1, x19, #4
    be7c:      	ldr	x3, [x0]
    be80:      	add	x1, x1, x3
    be84:      	ldr	x3, [x1]
    be88:      	ldr	x1, [x1, #0x8]
    be8c:      	fmov	d31, x1
    be90:      	mov	x1, x3
    be94:      	fmov	x3, d31
    be98:      	b	0xbebc <_stogir.locals.shape+0x158>
    be9c:      	lsl	x1, x4, #4
    bea0:      	ldr	x3, [x0, #0x28]
    bea4:      	add	x1, x1, x3
    bea8:      	ldr	x3, [x1]
    beac:      	ldr	x1, [x1, #0x8]
    beb0:      	fmov	d31, x1
    beb4:      	mov	x1, x3
    beb8:      	fmov	x3, d31
    bebc:      	mov	x4, x3
    bec0:      	mov	x3, x1
    bec4:      	mov	x1, #0x1                ; =1
    bec8:      	b	0xbed8 <_stogir.locals.shape+0x174>
    becc:      	movz	x1, #0x0, lsl #48
    bed0:      	movz	x3, #0x0, lsl #48
    bed4:      	movz	x4, #0x0, lsl #48
    bed8:      	lsr	w1, w1, #0
    bedc:      	lsr	x16, x1, #0
    bee0:      	cmp	x16, #0x1
    bee4:      	b.eq	0xbf00 <_stogir.locals.shape+0x19c>
    bee8:      	b.lo	0xbef0 <_stogir.locals.shape+0x18c>
    beec:      	b	0xbf04 <_stogir.locals.shape+0x1a0>
    bef0:      	cmp	x16, #0x0
    bef4:      	b.eq	0xbefc <_stogir.locals.shape+0x198>
    bef8:      	b	0xbf04 <_stogir.locals.shape+0x1a0>
    befc:      	b	0xbf08 <_stogir.locals.shape+0x1a4>
    bf00:      	b	0xbf50 <_stogir.locals.shape+0x1ec>
    bf04:      	b	0xc0f0 <_stogir.locals.shape+0x38c>
    bf08:      	adrp	x16, 0xb000 <_stogir.stack.valid-frame-object-inputs?+0x22c>
		000000000000bf08:  ARM64_RELOC_PAGE21	l_stogir.461
    bf0c:      	ldr	x16, [x16]
		000000000000bf0c:  ARM64_RELOC_PAGEOFF12	l_stogir.461
    bf10:      	orr	x0, x16, xzr
    bf14:      	mov	x21, x8
    bf18:      	mov	x1, x0
    bf1c:      	mov	x0, #0x1                ; =1
    bf20:      	mov	x2, #0x16               ; =22
    bf24:      	str	x0, [x21]
    bf28:      	str	x1, [x21, #0x8]
    bf2c:      	str	x2, [x21, #0x10]
    bf30:      	ldr	x19, [sp, #0x20]
    bf34:      	ldr	x20, [sp, #0x28]
    bf38:      	ldr	x21, [sp, #0x30]
    bf3c:      	ldr	x22, [sp, #0x38]
    bf40:      	ldr	x29, [sp]
    bf44:      	ldr	x30, [sp, #0x8]
    bf48:      	add	sp, sp, #0x40
    bf4c:      	ret
    bf50:      	lsr	w2, w2, #0
    bf54:      	lsr	w1, w3, #0
    bf58:      	add	x16, sp, #0x10
    bf5c:      	str	x3, [x16]
    bf60:      	add	x16, sp, #0x10
    bf64:      	str	x4, [x16, #0x8]
    bf68:      	ubfx	x1, x1, #8, #8
    bf6c:      	lsr	w1, w1, #0
    bf70:      	mov	x21, x8
    bf74:      	mov	x22, x0
    bf78:      	mov	w0, w1
    bf7c:      	mov	w1, w2
    bf80:      	bl	0xbf80 <_stogir.locals.shape+0x21c>
		000000000000bf80:  ARM64_RELOC_BRANCH26	_stogir.types.size
    bf84:      	lsr	w0, w0, #0
    bf88:      	add	x16, sp, #0x10
    bf8c:      	ldr	w1, [x16, #0xc]
    bf90:      	sxtw	x0, w0
    bf94:      	sxtw	x1, w1
    bf98:      	cmp	x1, #0x0
    bf9c:      	b.ne	0xbfa4 <_stogir.locals.shape+0x240>
    bfa0:      	mov	x1, x0
    bfa4:      	add	x16, sp, #0x10
    bfa8:      	ldr	w2, [x16, #0x8]
    bfac:      	sxtw	x2, w2
    bfb0:      	cmp	x2, #0x0
    bfb4:      	cset	w3, eq
    bfb8:      	ubfx	x3, x3, #0, #8
    bfbc:      	cmp	x2, #0x0
    bfc0:      	b.le	0xc034 <_stogir.locals.shape+0x2d0>
    bfc4:      	cmp	x2, #0x0
    bfc8:      	b.le	0xc0ac <_stogir.locals.shape+0x348>
    bfcc:      	add	x4, x22, #0x110
    bfd0:      	add	x5, x4, #0x28
    bfd4:      	ldr	x5, [x5, #0x8]
    bfd8:      	cmp	x2, x5
    bfdc:      	b.gt	0xc0ac <_stogir.locals.shape+0x348>
    bfe0:      	sub	x2, x2, #0x1
    bfe4:      	mov	x17, #0x18              ; =24
    bfe8:      	mul	x2, x2, x17
    bfec:      	ldr	x5, [x4, #0x28]
    bff0:      	add	x2, x2, x5
    bff4:      	ldr	x5, [x2]
    bff8:      	ldr	x2, [x2, #0x8]
    bffc:      	ldr	x4, [x4, #0x8]
    c000:      	cmp	x5, #0x0
    c004:      	b.lt	0xc0e8 <_stogir.locals.shape+0x384>
    c008:      	cmp	x5, x4
    c00c:      	b.gt	0xc0e8 <_stogir.locals.shape+0x384>
    c010:      	cmp	x2, #0x0
    c014:      	b.lt	0xc0e8 <_stogir.locals.shape+0x384>
    c018:      	sub	x4, x4, x5
    c01c:      	cmp	x2, x4
    c020:      	b.gt	0xc0e8 <_stogir.locals.shape+0x384>
    c024:      	mov	x2, #0x1                ; =1
    c028:      	b	0xc0ec <_stogir.locals.shape+0x388>
    c02c:      	movz	x3, #0x0, lsl #48
    c030:      	b	0xbe5c <_stogir.locals.shape+0xf8>
    c034:      	mov	x2, x3
    c038:      	cmp	x19, #0x0
    c03c:      	b.le	0xbe3c <_stogir.locals.shape+0xd8>
    c040:      	add	x16, sp, #0x10
    c044:      	ldr	w3, [x16]
    c048:      	uxtb	w3, w3
    c04c:      	cmp	x3, #0x48
    c050:      	b.ne	0xbe3c <_stogir.locals.shape+0xd8>
    c054:      	ldr	x3, [x22, #0x78]
    c058:      	add	x3, x20, x3
    c05c:      	ldr	w3, [x3]
    c060:      	sxtw	x3, w3
    c064:      	cmp	x3, #0x3
    c068:      	b.ne	0xbe3c <_stogir.locals.shape+0xd8>
    c06c:      	cmp	x0, #0x0
    c070:      	b.le	0xbe3c <_stogir.locals.shape+0xd8>
    c074:      	cmp	x2, #0x0
    c078:      	b.eq	0xbe3c <_stogir.locals.shape+0xd8>
    c07c:      	cmp	x1, #0x0
    c080:      	b.le	0xc0f8 <_stogir.locals.shape+0x394>
    c084:      	sub	x2, x1, #0x1
    c088:      	and	x2, x2, x1
    c08c:      	cmp	x2, #0x0
    c090:      	cset	w2, eq
    c094:      	ubfx	x2, x2, #0, #8
    c098:      	b	0xc0fc <_stogir.locals.shape+0x398>
    c09c:      	movz	x3, #0x0, lsl #48
    c0a0:      	b	0xbe38 <_stogir.locals.shape+0xd4>
    c0a4:      	mov	x2, #0x1                ; =1
    c0a8:      	b	0xc038 <_stogir.locals.shape+0x2d4>
    c0ac:      	movz	x2, #0x0, lsl #48
    c0b0:      	lsr	w2, w2, #0
    c0b4:      	lsr	x16, x2, #0
    c0b8:      	cmp	x16, #0x1
    c0bc:      	b.eq	0xc0d8 <_stogir.locals.shape+0x374>
    c0c0:      	b.lo	0xc0c8 <_stogir.locals.shape+0x364>
    c0c4:      	b	0xc0dc <_stogir.locals.shape+0x378>
    c0c8:      	cmp	x16, #0x0
    c0cc:      	b.eq	0xc0d4 <_stogir.locals.shape+0x370>
    c0d0:      	b	0xc0dc <_stogir.locals.shape+0x378>
    c0d4:      	b	0xc0e0 <_stogir.locals.shape+0x37c>
    c0d8:      	b	0xc0a4 <_stogir.locals.shape+0x340>
    c0dc:      	b	0xc1d8 <_stogir.locals.shape+0x474>
    c0e0:      	mov	x2, x3
    c0e4:      	b	0xc0a8 <_stogir.locals.shape+0x344>
    c0e8:      	movz	x2, #0x0, lsl #48
    c0ec:      	b	0xc0b0 <_stogir.locals.shape+0x34c>
    c0f0:      	brk	#0
    c0f4:      	b	0xc0f0 <_stogir.locals.shape+0x38c>
    c0f8:      	movz	x2, #0x0, lsl #48
    c0fc:      	cmp	x2, #0x0
    c100:      	b.eq	0xbe3c <_stogir.locals.shape+0xd8>
    c104:      	add	x16, sp, #0x10
    c108:      	ldr	w2, [x16, #0x4]
    c10c:      	sxtw	x2, w2
    c110:      	cmp	x2, #0x0
    c114:      	cset	w3, gt
    c118:      	movz	x16, #0x0, lsl #48
    c11c:      	sub	x4, x16, x2
    c120:      	sub	x5, x4, #0x1
    c124:      	uxtb	w16, w3
    c128:      	cmp	w16, wzr
    c12c:      	b.eq	0xc18c <_stogir.locals.shape+0x428>
    c130:      	ldr	x4, [x22, #0x8]
    c134:      	cmp	x2, x4
    c138:      	b.ge	0xc1e0 <_stogir.locals.shape+0x47c>
    c13c:      	add	x4, x22, #0x78
    c140:      	ldr	x4, [x4, #0x8]
    c144:      	cmp	x2, x4
    c148:      	b.ge	0xc2c4 <_stogir.locals.shape+0x560>
    c14c:      	lsl	x4, x2, #2
    c150:      	ldr	x6, [x22, #0x78]
    c154:      	add	x4, x4, x6
    c158:      	ldr	w4, [x4]
    c15c:      	sxtw	x4, w4
    c160:      	cmp	x4, #0x0
    c164:      	cset	w4, ge
    c168:      	ubfx	x4, x4, #0, #8
    c16c:      	b	0xc2c8 <_stogir.locals.shape+0x564>
    c170:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x29c>
		000000000000c170:  ARM64_RELOC_PAGE21	l_stogir.462
    c174:      	ldr	x16, [x16]
		000000000000c174:  ARM64_RELOC_PAGEOFF12	l_stogir.462
    c178:      	orr	x0, x16, xzr
    c17c:      	mov	x1, x0
    c180:      	mov	x0, #0x1                ; =1
    c184:      	mov	x2, #0x2c               ; =44
    c188:      	b	0xbe54 <_stogir.locals.shape+0xf0>
    c18c:      	cmp	x2, #0x0
    c190:      	b.ge	0xc1e8 <_stogir.locals.shape+0x484>
    c194:      	add	x6, x22, #0x28
    c198:      	add	x7, x22, #0x50
    c19c:      	ldr	x6, [x6, #0x8]
    c1a0:      	ldr	x7, [x7, #0x8]
    c1a4:      	cmp	x6, x7
    c1a8:      	b.ne	0xc2bc <_stogir.locals.shape+0x558>
    c1ac:      	cmp	x4, x6
    c1b0:      	b.gt	0xc2cc <_stogir.locals.shape+0x568>
    c1b4:      	lsl	x4, x5, #2
    c1b8:      	ldr	x6, [x22, #0x50]
    c1bc:      	add	x4, x4, x6
    c1c0:      	ldr	w4, [x4]
    c1c4:      	sxtw	x4, w4
    c1c8:      	cmp	x4, #0x0
    c1cc:      	cset	w4, gt
    c1d0:      	ubfx	x4, x4, #0, #8
    c1d4:      	b	0xc2d0 <_stogir.locals.shape+0x56c>
    c1d8:      	brk	#0
    c1dc:      	b	0xc1d8 <_stogir.locals.shape+0x474>
    c1e0:      	movz	x4, #0x0, lsl #48
    c1e4:      	b	0xc1ec <_stogir.locals.shape+0x488>
    c1e8:      	movz	x4, #0x0, lsl #48
    c1ec:      	cmp	x4, #0x0
    c1f0:      	b.eq	0xc230 <_stogir.locals.shape+0x4cc>
    c1f4:      	uxtb	w16, w3
    c1f8:      	cmp	w16, wzr
    c1fc:      	b.eq	0xc214 <_stogir.locals.shape+0x4b0>
    c200:      	lsl	x2, x2, #4
    c204:      	ldr	x3, [x22]
    c208:      	add	x2, x2, x3
    c20c:      	ldr	x2, [x2]
    c210:      	b	0xc224 <_stogir.locals.shape+0x4c0>
    c214:      	lsl	x2, x5, #4
    c218:      	ldr	x3, [x22, #0x28]
    c21c:      	add	x2, x2, x3
    c220:      	ldr	x2, [x2]
    c224:      	mov	x3, x2
    c228:      	mov	x2, #0x1                ; =1
    c22c:      	b	0xc238 <_stogir.locals.shape+0x4d4>
    c230:      	movz	x2, #0x0, lsl #48
    c234:      	movz	x3, #0x0, lsl #48
    c238:      	lsr	w2, w2, #0
    c23c:      	lsr	x16, x2, #0
    c240:      	cmp	x16, #0x1
    c244:      	b.eq	0xc260 <_stogir.locals.shape+0x4fc>
    c248:      	b.lo	0xc250 <_stogir.locals.shape+0x4ec>
    c24c:      	b	0xc264 <_stogir.locals.shape+0x500>
    c250:      	cmp	x16, #0x0
    c254:      	b.eq	0xc25c <_stogir.locals.shape+0x4f8>
    c258:      	b	0xc264 <_stogir.locals.shape+0x500>
    c25c:      	b	0xc268 <_stogir.locals.shape+0x504>
    c260:      	b	0xc284 <_stogir.locals.shape+0x520>
    c264:      	b	0xc2fc <_stogir.locals.shape+0x598>
    c268:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x29c>
		000000000000c268:  ARM64_RELOC_PAGE21	l_stogir.463
    c26c:      	ldr	x16, [x16]
		000000000000c26c:  ARM64_RELOC_PAGEOFF12	l_stogir.463
    c270:      	orr	x0, x16, xzr
    c274:      	mov	x1, x0
    c278:      	mov	x0, #0x1                ; =1
    c27c:      	mov	x2, #0x1d               ; =29
    c280:      	b	0xc188 <_stogir.locals.shape+0x424>
    c284:      	add	x16, sp, #0x10
    c288:      	ldr	w2, [x16, #0x4]
    c28c:      	sxtw	x2, w2
    c290:      	cmp	x2, #0x0
    c294:      	b.le	0xc170 <_stogir.locals.shape+0x40c>
    c298:      	uxtb	w3, w3
    c29c:      	cmp	x3, #0x83
    c2a0:      	b.ge	0xc2d4 <_stogir.locals.shape+0x570>
    c2a4:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x29c>
		000000000000c2a4:  ARM64_RELOC_PAGE21	l_stogir.464
    c2a8:      	ldr	x16, [x16]
		000000000000c2a8:  ARM64_RELOC_PAGEOFF12	l_stogir.464
    c2ac:      	orr	x2, x16, xzr
    c2b0:      	add	x2, x3, x2
    c2b4:      	ldrb	w2, [x2]
    c2b8:      	b	0xc2d8 <_stogir.locals.shape+0x574>
    c2bc:      	movz	x4, #0x0, lsl #48
    c2c0:      	b	0xc1ec <_stogir.locals.shape+0x488>
    c2c4:      	movz	x4, #0x0, lsl #48
    c2c8:      	b	0xc1e4 <_stogir.locals.shape+0x480>
    c2cc:      	movz	x4, #0x0, lsl #48
    c2d0:      	b	0xc2c0 <_stogir.locals.shape+0x55c>
    c2d4:      	movz	x2, #0x0, lsl #48
    c2d8:      	uxtb	w2, w2
    c2dc:      	and	x2, x2, #0x2
    c2e0:      	uxtb	w2, w2
    c2e4:      	cmp	x2, #0x0
    c2e8:      	b.eq	0xc170 <_stogir.locals.shape+0x40c>
    c2ec:      	mov	x2, x1
    c2f0:      	mov	x1, x0
    c2f4:      	movz	x0, #0x0, lsl #48
    c2f8:      	b	0xc188 <_stogir.locals.shape+0x424>
    c2fc:      	brk	#0
    c300:      	b	0xc2fc <_stogir.locals.shape+0x598>

000000000000c304 <_stogir.conversion.policy>:
    c304:      	sub	sp, sp, #0x70
    c308:      	str	x29, [sp]
    c30c:      	str	x30, [sp, #0x8]
    c310:      	mov	x29, sp
    c314:      	str	x19, [sp, #0x20]
    c318:      	str	x20, [sp, #0x28]
    c31c:      	str	x21, [sp, #0x30]
    c320:      	str	x22, [sp, #0x38]
    c324:      	str	x23, [sp, #0x40]
    c328:      	str	x24, [sp, #0x48]
    c32c:      	str	x25, [sp, #0x50]
    c330:      	str	x26, [sp, #0x58]
    c334:      	str	x27, [sp, #0x60]
    c338:      	str	x28, [sp, #0x68]
    c33c:      	sxtw	x19, w0
    c340:      	sxtw	x20, w1
    c344:      	sxtw	x21, w2
    c348:      	cmp	x19, #0x24
    c34c:      	b.ne	0xc39c <_stogir.conversion.policy+0x98>
    c350:      	cmp	x20, #0xf
    c354:      	b.le	0xc5b8 <_stogir.conversion.policy+0x2b4>
    c358:      	cmp	x20, #0x80
    c35c:      	b.ge	0xc5b8 <_stogir.conversion.policy+0x2b4>
    c360:      	and	x0, x20, #0xf
    c364:      	lsr	w0, w0, #0
    c368:      	sxtw	x0, w0
    c36c:      	cmp	x0, #0x1
    c370:      	b.lt	0xc5b8 <_stogir.conversion.policy+0x2b4>
    c374:      	and	x0, x20, #0xf
    c378:      	lsr	w0, w0, #0
    c37c:      	sxtw	x0, w0
    c380:      	cmp	x0, #0xd
    c384:      	b.gt	0xc5b8 <_stogir.conversion.policy+0x2b4>
    c388:      	mov	x0, #0x1                ; =1
    c38c:      	b	0xc394 <_stogir.conversion.policy+0x90>
    c390:      	movz	x0, #0x0, lsl #48
    c394:      	mov	x22, x0
    c398:      	b	0xc3a0 <_stogir.conversion.policy+0x9c>
    c39c:      	movz	x22, #0x0, lsl #48
    c3a0:      	sxtw	x23, w3
    c3a4:      	cmp	x20, #0xd
    c3a8:      	cset	w24, eq
    c3ac:      	cmp	x20, #0xc
    c3b0:      	cset	w25, eq
    c3b4:      	cmp	x23, #0x4
    c3b8:      	cset	w26, eq
    c3bc:      	cmp	x23, #0x8
    c3c0:      	cset	w27, eq
    c3c4:      	cmp	x22, #0x0
    c3c8:      	b.eq	0xc8ac <_stogir.conversion.policy+0x5a8>
    c3cc:      	lsr	w1, w1, #0
    c3d0:      	lsr	w3, w3, #0
    c3d4:      	mov	w0, w1
    c3d8:      	mov	w1, w3
    c3dc:      	str	x8, [sp, #0x18]
    c3e0:      	mov	w28, w3
    c3e4:      	str	x23, [sp, #0x10]
    c3e8:      	mov	w23, w2
    c3ec:      	bl	0xc3ec <_stogir.conversion.policy+0xe8>
		000000000000c3ec:  ARM64_RELOC_BRANCH26	_stogir.types.size
    c3f0:      	lsr	w0, w0, #0
    c3f4:      	sxtw	x0, w0
    c3f8:      	b	0xc408 <_stogir.conversion.policy+0x104>
    c3fc:      	mov	x0, #0x1                ; =1
    c400:      	lsr	w0, w0, #0
    c404:      	sxtw	x0, w0
    c408:      	cmp	x21, #0xd
    c40c:      	cset	w1, eq
    c410:      	cmp	x21, #0xc
    c414:      	cset	w2, eq
    c418:      	cmp	x22, #0x0
    c41c:      	b.eq	0xc8c0 <_stogir.conversion.policy+0x5bc>
    c420:      	lsr	w23, w23, #0
    c424:      	lsr	w28, w28, #0
    c428:      	mov	x22, x0
    c42c:      	mov	w0, w23
    c430:      	mov	w23, w1
    c434:      	mov	w1, w28
    c438:      	mov	w28, w2
    c43c:      	bl	0xc43c <_stogir.conversion.policy+0x138>
		000000000000c43c:  ARM64_RELOC_BRANCH26	_stogir.types.size
    c440:      	lsr	w0, w0, #0
    c444:      	sxtw	x0, w0
    c448:      	b	0xc458 <_stogir.conversion.policy+0x154>
    c44c:      	mov	x0, #0x1                ; =1
    c450:      	lsr	w0, w0, #0
    c454:      	sxtw	x0, w0
    c458:      	cmp	x19, #0x21
    c45c:      	b.lt	0xc538 <_stogir.conversion.policy+0x234>
    c460:      	cmp	x19, #0x27
    c464:      	b.gt	0xc538 <_stogir.conversion.policy+0x234>
    c468:      	lsl	x1, x22, #3
    c46c:      	lsr	w1, w1, #0
    c470:      	sxtw	x1, w1
    c474:      	cmp	x1, #0x0
    c478:      	b.le	0xc538 <_stogir.conversion.policy+0x234>
    c47c:      	lsl	x0, x0, #3
    c480:      	lsr	w0, w0, #0
    c484:      	sxtw	x0, w0
    c488:      	cmp	x0, #0x0
    c48c:      	b.le	0xc538 <_stogir.conversion.policy+0x234>
    c490:      	cmp	x19, #0x26
    c494:      	cset	w2, eq
    c498:      	cmp	x20, #0x1
    c49c:      	cset	w3, ge
    c4a0:      	cmp	x20, #0xb
    c4a4:      	cset	w4, le
    c4a8:      	cmp	x21, #0x1
    c4ac:      	cset	w5, ge
    c4b0:      	cmp	x21, #0xb
    c4b4:      	cset	w6, le
    c4b8:      	cmp	x19, #0x25
    c4bc:      	b.lt	0xc74c <_stogir.conversion.policy+0x448>
    c4c0:      	ubfx	x23, x23, #0, #8
    c4c4:      	cmp	x19, #0x25
    c4c8:      	b.ne	0xc7bc <_stogir.conversion.policy+0x4b8>
    c4cc:      	uxtb	w16, w3
    c4d0:      	cmp	w16, wzr
    c4d4:      	b.eq	0xc7b4 <_stogir.conversion.policy+0x4b0>
    c4d8:      	uxtb	w16, w4
    c4dc:      	cmp	w16, wzr
    c4e0:      	b.eq	0xc7b4 <_stogir.conversion.policy+0x4b0>
    c4e4:      	uxtb	w16, w28
    c4e8:      	cmp	w16, wzr
    c4ec:      	b.eq	0xc830 <_stogir.conversion.policy+0x52c>
    c4f0:      	mov	x3, #0x1                ; =1
    c4f4:      	b	0xc834 <_stogir.conversion.policy+0x530>
    c4f8:      	uxtb	w16, w26
    c4fc:      	cmp	w16, wzr
    c500:      	b.ne	0xc598 <_stogir.conversion.policy+0x294>
    c504:      	uxtb	w16, w27
    c508:      	cmp	w16, wzr
    c50c:      	b.ne	0xc598 <_stogir.conversion.policy+0x294>
    c510:      	movn	x0, #0x0, lsl #48
    c514:      	b	0xc450 <_stogir.conversion.policy+0x14c>
    c518:      	uxtb	w16, w26
    c51c:      	cmp	w16, wzr
    c520:      	b.ne	0xc5a8 <_stogir.conversion.policy+0x2a4>
    c524:      	uxtb	w16, w27
    c528:      	cmp	w16, wzr
    c52c:      	b.ne	0xc5a8 <_stogir.conversion.policy+0x2a4>
    c530:      	movn	x0, #0x0, lsl #48
    c534:      	b	0xc400 <_stogir.conversion.policy+0xfc>
    c538:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x29c>
		000000000000c538:  ARM64_RELOC_PAGE21	l_stogir.465
    c53c:      	ldr	x16, [x16]
		000000000000c53c:  ARM64_RELOC_PAGEOFF12	l_stogir.465
    c540:      	orr	x0, x16, xzr
    c544:      	mov	x1, x0
    c548:      	mov	x0, #0x1                ; =1
    c54c:      	mov	x2, #0x22               ; =34
    c550:      	ldr	x3, [sp, #0x18]
    c554:      	str	x0, [x3]
    c558:      	str	x1, [x3, #0x8]
    c55c:      	str	x2, [x3, #0x10]
    c560:      	ldr	x19, [sp, #0x20]
    c564:      	ldr	x20, [sp, #0x28]
    c568:      	ldr	x21, [sp, #0x30]
    c56c:      	ldr	x22, [sp, #0x38]
    c570:      	ldr	x23, [sp, #0x40]
    c574:      	ldr	x24, [sp, #0x48]
    c578:      	ldr	x25, [sp, #0x50]
    c57c:      	ldr	x26, [sp, #0x58]
    c580:      	ldr	x27, [sp, #0x60]
    c584:      	ldr	x28, [sp, #0x68]
    c588:      	ldr	x29, [sp]
    c58c:      	ldr	x30, [sp, #0x8]
    c590:      	add	sp, sp, #0x70
    c594:      	ret
    c598:      	cmp	x21, #0x0
    c59c:      	b.ne	0xc600 <_stogir.conversion.policy+0x2fc>
    c5a0:      	movz	x0, #0x0, lsl #48
    c5a4:      	b	0xc450 <_stogir.conversion.policy+0x14c>
    c5a8:      	cmp	x20, #0x0
    c5ac:      	b.ne	0xc678 <_stogir.conversion.policy+0x374>
    c5b0:      	movz	x0, #0x0, lsl #48
    c5b4:      	b	0xc400 <_stogir.conversion.policy+0xfc>
    c5b8:      	cmp	x21, #0xf
    c5bc:      	b.le	0xc390 <_stogir.conversion.policy+0x8c>
    c5c0:      	cmp	x21, #0x80
    c5c4:      	b.ge	0xc5f8 <_stogir.conversion.policy+0x2f4>
    c5c8:      	and	x0, x21, #0xf
    c5cc:      	lsr	w0, w0, #0
    c5d0:      	sxtw	x0, w0
    c5d4:      	cmp	x0, #0x1
    c5d8:      	b.lt	0xc6f0 <_stogir.conversion.policy+0x3ec>
    c5dc:      	and	x0, x21, #0xf
    c5e0:      	lsr	w0, w0, #0
    c5e4:      	sxtw	x0, w0
    c5e8:      	cmp	x0, #0xd
    c5ec:      	cset	w0, le
    c5f0:      	ubfx	x0, x0, #0, #8
    c5f4:      	b	0xc6f4 <_stogir.conversion.policy+0x3f0>
    c5f8:      	movz	x0, #0x0, lsl #48
    c5fc:      	b	0xc394 <_stogir.conversion.policy+0x90>
    c600:      	cmp	x21, #0x1
    c604:      	b.eq	0xc44c <_stogir.conversion.policy+0x148>
    c608:      	cmp	x21, #0x2
    c60c:      	b.eq	0xc44c <_stogir.conversion.policy+0x148>
    c610:      	cmp	x21, #0x7
    c614:      	b.eq	0xc44c <_stogir.conversion.policy+0x148>
    c618:      	cmp	x21, #0x8
    c61c:      	b.eq	0xc44c <_stogir.conversion.policy+0x148>
    c620:      	cmp	x21, #0x3
    c624:      	b.eq	0xc7e8 <_stogir.conversion.policy+0x4e4>
    c628:      	cmp	x21, #0x9
    c62c:      	b.eq	0xc7e8 <_stogir.conversion.policy+0x4e4>
    c630:      	cmp	x21, #0x4
    c634:      	b.eq	0xc858 <_stogir.conversion.policy+0x554>
    c638:      	cmp	x21, #0xa
    c63c:      	b.eq	0xc858 <_stogir.conversion.policy+0x554>
    c640:      	uxtb	w16, w23
    c644:      	cmp	w16, wzr
    c648:      	b.ne	0xc858 <_stogir.conversion.policy+0x554>
    c64c:      	cmp	x21, #0x5
    c650:      	b.eq	0xc88c <_stogir.conversion.policy+0x588>
    c654:      	cmp	x21, #0xb
    c658:      	b.eq	0xc88c <_stogir.conversion.policy+0x588>
    c65c:      	uxtb	w16, w28
    c660:      	cmp	w16, wzr
    c664:      	b.ne	0xc88c <_stogir.conversion.policy+0x588>
    c668:      	cmp	x21, #0x6
    c66c:      	b.ne	0xc89c <_stogir.conversion.policy+0x598>
    c670:      	ldr	x0, [sp, #0x10]
    c674:      	b	0xc8a0 <_stogir.conversion.policy+0x59c>
    c678:      	cmp	x20, #0x1
    c67c:      	b.eq	0xc3fc <_stogir.conversion.policy+0xf8>
    c680:      	cmp	x20, #0x2
    c684:      	b.eq	0xc3fc <_stogir.conversion.policy+0xf8>
    c688:      	cmp	x20, #0x7
    c68c:      	b.eq	0xc3fc <_stogir.conversion.policy+0xf8>
    c690:      	cmp	x20, #0x8
    c694:      	b.eq	0xc3fc <_stogir.conversion.policy+0xf8>
    c698:      	cmp	x20, #0x3
    c69c:      	b.eq	0xc7f0 <_stogir.conversion.policy+0x4ec>
    c6a0:      	cmp	x20, #0x9
    c6a4:      	b.eq	0xc7f0 <_stogir.conversion.policy+0x4ec>
    c6a8:      	cmp	x20, #0x4
    c6ac:      	b.eq	0xc860 <_stogir.conversion.policy+0x55c>
    c6b0:      	cmp	x20, #0xa
    c6b4:      	b.eq	0xc860 <_stogir.conversion.policy+0x55c>
    c6b8:      	uxtb	w16, w24
    c6bc:      	cmp	w16, wzr
    c6c0:      	b.ne	0xc860 <_stogir.conversion.policy+0x55c>
    c6c4:      	cmp	x20, #0x5
    c6c8:      	b.eq	0xc894 <_stogir.conversion.policy+0x590>
    c6cc:      	cmp	x20, #0xb
    c6d0:      	b.eq	0xc894 <_stogir.conversion.policy+0x590>
    c6d4:      	uxtb	w16, w25
    c6d8:      	cmp	w16, wzr
    c6dc:      	b.ne	0xc894 <_stogir.conversion.policy+0x590>
    c6e0:      	cmp	x20, #0x6
    c6e4:      	b.ne	0xc8a4 <_stogir.conversion.policy+0x5a0>
    c6e8:      	ldr	x0, [sp, #0x10]
    c6ec:      	b	0xc8a8 <_stogir.conversion.policy+0x5a4>
    c6f0:      	movz	x0, #0x0, lsl #48
    c6f4:      	b	0xc5fc <_stogir.conversion.policy+0x2f8>
    c6f8:      	mov	x3, #0x1                ; =1
    c6fc:      	cmp	x3, #0x0
    c700:      	b.ne	0xc538 <_stogir.conversion.policy+0x234>
    c704:      	cmp	x19, #0x23
    c708:      	b.eq	0xc71c <_stogir.conversion.policy+0x418>
    c70c:      	uxtb	w16, w2
    c710:      	cmp	w16, wzr
    c714:      	b.ne	0xc71c <_stogir.conversion.policy+0x418>
    c718:      	mov	x0, x1
    c71c:      	and	x0, x0, #0xffffffff
    c720:      	mov	x1, x0
    c724:      	movz	x0, #0x0, lsl #48
    c728:      	movz	x2, #0x0, lsl #48
    c72c:      	b	0xc550 <_stogir.conversion.policy+0x24c>
    c730:      	movz	x3, #0x0, lsl #48
    c734:      	cmp	x3, #0x0
    c738:      	cset	w3, ne
    c73c:      	uxtb	w16, w3
    c740:      	cmp	w16, wzr
    c744:      	cset	x3, eq
    c748:      	b	0xc6fc <_stogir.conversion.policy+0x3f8>
    c74c:      	cmp	x19, #0x24
    c750:      	b.ne	0xc76c <_stogir.conversion.policy+0x468>
    c754:      	cmp	x1, x0
    c758:      	cset	w3, eq
    c75c:      	uxtb	w16, w3
    c760:      	cmp	w16, wzr
    c764:      	cset	x3, eq
    c768:      	b	0xc6fc <_stogir.conversion.policy+0x3f8>
    c76c:      	uxtb	w16, w3
    c770:      	cmp	w16, wzr
    c774:      	b.eq	0xc6f8 <_stogir.conversion.policy+0x3f4>
    c778:      	uxtb	w16, w4
    c77c:      	cmp	w16, wzr
    c780:      	b.eq	0xc6f8 <_stogir.conversion.policy+0x3f4>
    c784:      	uxtb	w16, w5
    c788:      	cmp	w16, wzr
    c78c:      	b.eq	0xc828 <_stogir.conversion.policy+0x524>
    c790:      	uxtb	w16, w6
    c794:      	cmp	w16, wzr
    c798:      	b.eq	0xc828 <_stogir.conversion.policy+0x524>
    c79c:      	cmp	x19, #0x23
    c7a0:      	b.ne	0xc87c <_stogir.conversion.policy+0x578>
    c7a4:      	cmp	x0, x1
    c7a8:      	cset	w3, ge
    c7ac:      	ubfx	x3, x3, #0, #8
    c7b0:      	b	0xc888 <_stogir.conversion.policy+0x584>
    c7b4:      	movz	x3, #0x0, lsl #48
    c7b8:      	b	0xc734 <_stogir.conversion.policy+0x430>
    c7bc:      	uxtb	w16, w2
    c7c0:      	cmp	w16, wzr
    c7c4:      	b.eq	0xc800 <_stogir.conversion.policy+0x4fc>
    c7c8:      	uxtb	w16, w25
    c7cc:      	cmp	w16, wzr
    c7d0:      	b.ne	0xc840 <_stogir.conversion.policy+0x53c>
    c7d4:      	uxtb	w16, w24
    c7d8:      	cmp	w16, wzr
    c7dc:      	b.ne	0xc840 <_stogir.conversion.policy+0x53c>
    c7e0:      	movz	x3, #0x0, lsl #48
    c7e4:      	b	0xc7fc <_stogir.conversion.policy+0x4f8>
    c7e8:      	mov	x0, #0x2                ; =2
    c7ec:      	b	0xc450 <_stogir.conversion.policy+0x14c>
    c7f0:      	mov	x0, #0x2                ; =2
    c7f4:      	b	0xc400 <_stogir.conversion.policy+0xfc>
    c7f8:      	movz	x3, #0x0, lsl #48
    c7fc:      	b	0xc734 <_stogir.conversion.policy+0x430>
    c800:      	cmp	x19, #0x27
    c804:      	b.ne	0xc730 <_stogir.conversion.policy+0x42c>
    c808:      	uxtb	w16, w25
    c80c:      	cmp	w16, wzr
    c810:      	b.ne	0xc868 <_stogir.conversion.policy+0x564>
    c814:      	uxtb	w16, w24
    c818:      	cmp	w16, wzr
    c81c:      	b.ne	0xc868 <_stogir.conversion.policy+0x564>
    c820:      	movz	x3, #0x0, lsl #48
    c824:      	b	0xc83c <_stogir.conversion.policy+0x538>
    c828:      	mov	x3, #0x1                ; =1
    c82c:      	b	0xc6fc <_stogir.conversion.policy+0x3f8>
    c830:      	mov	x3, x23
    c834:      	b	0xc7b8 <_stogir.conversion.policy+0x4b4>
    c838:      	mov	x3, x23
    c83c:      	b	0xc734 <_stogir.conversion.policy+0x430>
    c840:      	uxtb	w16, w5
    c844:      	cmp	w16, wzr
    c848:      	b.eq	0xc7f8 <_stogir.conversion.policy+0x4f4>
    c84c:      	ubfx	x6, x6, #0, #8
    c850:      	mov	x3, x6
    c854:      	b	0xc7fc <_stogir.conversion.policy+0x4f8>
    c858:      	mov	x0, #0x4                ; =4
    c85c:      	b	0xc7ec <_stogir.conversion.policy+0x4e8>
    c860:      	mov	x0, #0x4                ; =4
    c864:      	b	0xc7f4 <_stogir.conversion.policy+0x4f0>
    c868:      	uxtb	w16, w28
    c86c:      	cmp	w16, wzr
    c870:      	b.eq	0xc838 <_stogir.conversion.policy+0x534>
    c874:      	mov	x3, #0x1                ; =1
    c878:      	b	0xc83c <_stogir.conversion.policy+0x538>
    c87c:      	cmp	x0, x1
    c880:      	cset	w3, le
    c884:      	ubfx	x3, x3, #0, #8
    c888:      	b	0xc82c <_stogir.conversion.policy+0x528>
    c88c:      	mov	x0, #0x8                ; =8
    c890:      	b	0xc85c <_stogir.conversion.policy+0x558>
    c894:      	mov	x0, #0x8                ; =8
    c898:      	b	0xc864 <_stogir.conversion.policy+0x560>
    c89c:      	movn	x0, #0x0, lsl #48
    c8a0:      	b	0xc890 <_stogir.conversion.policy+0x58c>
    c8a4:      	movn	x0, #0x0, lsl #48
    c8a8:      	b	0xc898 <_stogir.conversion.policy+0x594>
    c8ac:      	str	x8, [sp, #0x18]
    c8b0:      	mov	w28, w3
    c8b4:      	str	x23, [sp, #0x10]
    c8b8:      	mov	w23, w2
    c8bc:      	b	0xc518 <_stogir.conversion.policy+0x214>
    c8c0:      	mov	x22, x0
    c8c4:      	mov	w23, w1
    c8c8:      	mov	w28, w2
    c8cc:      	b	0xc4f8 <_stogir.conversion.policy+0x1f4>

000000000000c8d0 <_stogir.conditional.operands>:
    c8d0:      	sub	sp, sp, #0x70
    c8d4:      	str	x29, [sp]
    c8d8:      	str	x30, [sp, #0x8]
    c8dc:      	mov	x29, sp
    c8e0:      	str	x19, [sp, #0x30]
    c8e4:      	str	x20, [sp, #0x38]
    c8e8:      	str	x21, [sp, #0x40]
    c8ec:      	str	x22, [sp, #0x48]
    c8f0:      	str	x23, [sp, #0x50]
    c8f4:      	str	x24, [sp, #0x58]
    c8f8:      	str	x25, [sp, #0x60]
    c8fc:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x29c>
		000000000000c8fc:  ARM64_RELOC_PAGE21	l_stogir.466
    c900:      	ldr	x16, [x16]
		000000000000c900:  ARM64_RELOC_PAGEOFF12	l_stogir.466
    c904:      	orr	x19, x16, xzr
    c908:      	sxtw	x20, w1
    c90c:      	cmp	x20, #0x0
    c910:      	b.ne	0xc9f4 <_stogir.conditional.operands+0x124>
    c914:      	mov	x21, x8
    c918:      	mov	x22, x0
    c91c:      	mov	w23, w2
    c920:      	mov	w24, w3
    c924:      	mov	w25, w4
    c928:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x29c>
		000000000000c928:  ARM64_RELOC_PAGE21	l_stogir.467
    c92c:      	ldr	x16, [x16]
		000000000000c92c:  ARM64_RELOC_PAGEOFF12	l_stogir.467
    c930:      	orr	x0, x16, xzr
    c934:      	mov	x1, #0x2b               ; =43
    c938:      	sxtw	x23, w23
    c93c:      	cmp	x23, #0x0
    c940:      	cset	w2, gt
    c944:      	movz	x16, #0x0, lsl #48
    c948:      	sub	x3, x16, x23
    c94c:      	sub	x4, x3, #0x1
    c950:      	uxtb	w16, w2
    c954:      	cmp	w16, wzr
    c958:      	b.eq	0xc9a8 <_stogir.conditional.operands+0xd8>
    c95c:      	ldr	x3, [x22, #0x8]
    c960:      	cmp	x23, x3
    c964:      	b.ge	0xca38 <_stogir.conditional.operands+0x168>
    c968:      	add	x3, x22, #0x78
    c96c:      	ldr	x3, [x3, #0x8]
    c970:      	cmp	x23, x3
    c974:      	b.ge	0xce40 <_stogir.conditional.operands+0x570>
    c978:      	lsl	x3, x23, #2
    c97c:      	ldr	x5, [x22, #0x78]
    c980:      	add	x3, x3, x5
    c984:      	ldr	w3, [x3]
    c988:      	sxtw	x3, w3
    c98c:      	cmp	x3, #0x0
    c990:      	cset	w3, ge
    c994:      	ubfx	x3, x3, #0, #8
    c998:      	fmov	d31, x0
    c99c:      	mov	x0, x3
    c9a0:      	fmov	x3, d31
    c9a4:      	b	0xce48 <_stogir.conditional.operands+0x578>
    c9a8:      	cmp	x23, #0x0
    c9ac:      	b.ge	0xca48 <_stogir.conditional.operands+0x178>
    c9b0:      	add	x5, x22, #0x28
    c9b4:      	add	x6, x22, #0x50
    c9b8:      	ldr	x5, [x5, #0x8]
    c9bc:      	ldr	x6, [x6, #0x8]
    c9c0:      	cmp	x5, x6
    c9c4:      	b.ne	0xca28 <_stogir.conditional.operands+0x158>
    c9c8:      	cmp	x3, x5
    c9cc:      	b.gt	0xcea0 <_stogir.conditional.operands+0x5d0>
    c9d0:      	lsl	x3, x4, #2
    c9d4:      	ldr	x5, [x22, #0x50]
    c9d8:      	add	x3, x3, x5
    c9dc:      	ldr	w3, [x3]
    c9e0:      	sxtw	x3, w3
    c9e4:      	cmp	x3, #0x0
    c9e8:      	cset	w3, gt
    c9ec:      	ubfx	x3, x3, #0, #8
    c9f0:      	b	0xcea4 <_stogir.conditional.operands+0x5d4>
    c9f4:      	lsr	w1, w1, #0
    c9f8:      	mov	x21, x8
    c9fc:      	mov	x22, x0
    ca00:      	mov	w0, w1
    ca04:      	mov	w23, w2
    ca08:      	mov	w24, w3
    ca0c:      	mov	w25, w4
    ca10:      	bl	0xca10 <_stogir.conditional.operands+0x140>
		000000000000ca10:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
    ca14:      	cmp	x0, #0x0
    ca18:      	b.eq	0xc928 <_stogir.conditional.operands+0x58>
    ca1c:      	mov	x0, x19
    ca20:      	movz	x1, #0x0, lsl #48
    ca24:      	b	0xc938 <_stogir.conditional.operands+0x68>
    ca28:      	movz	x3, #0x0, lsl #48
    ca2c:      	b	0xca4c <_stogir.conditional.operands+0x17c>
    ca30:      	movz	x9, #0x0, lsl #48
    ca34:      	b	0xcb0c <_stogir.conditional.operands+0x23c>
    ca38:      	mov	x3, x1
    ca3c:      	mov	x1, x0
    ca40:      	movz	x0, #0x0, lsl #48
    ca44:      	b	0xca5c <_stogir.conditional.operands+0x18c>
    ca48:      	movz	x3, #0x0, lsl #48
    ca4c:      	fmov	d31, x0
    ca50:      	mov	x0, x3
    ca54:      	mov	x3, x1
    ca58:      	fmov	x1, d31
    ca5c:      	cmp	x0, #0x0
    ca60:      	b.eq	0xcaa4 <_stogir.conditional.operands+0x1d4>
    ca64:      	uxtb	w16, w2
    ca68:      	cmp	w16, wzr
    ca6c:      	b.eq	0xca84 <_stogir.conditional.operands+0x1b4>
    ca70:      	lsl	x0, x23, #4
    ca74:      	ldr	x2, [x22]
    ca78:      	add	x0, x0, x2
    ca7c:      	ldr	x0, [x0]
    ca80:      	b	0xca94 <_stogir.conditional.operands+0x1c4>
    ca84:      	lsl	x0, x4, #4
    ca88:      	ldr	x2, [x22, #0x28]
    ca8c:      	add	x0, x0, x2
    ca90:      	ldr	x0, [x0]
    ca94:      	mov	x2, x1
    ca98:      	mov	x1, x0
    ca9c:      	mov	x0, #0x1                ; =1
    caa0:      	b	0xcab0 <_stogir.conditional.operands+0x1e0>
    caa4:      	mov	x2, x1
    caa8:      	movz	x0, #0x0, lsl #48
    caac:      	movz	x1, #0x0, lsl #48
    cab0:      	lsr	w0, w0, #0
    cab4:      	lsr	x16, x0, #0
    cab8:      	cmp	x16, #0x1
    cabc:      	b.eq	0xcad8 <_stogir.conditional.operands+0x208>
    cac0:      	b.lo	0xcac8 <_stogir.conditional.operands+0x1f8>
    cac4:      	b	0xcadc <_stogir.conditional.operands+0x20c>
    cac8:      	cmp	x16, #0x0
    cacc:      	b.eq	0xcad4 <_stogir.conditional.operands+0x204>
    cad0:      	b	0xcadc <_stogir.conditional.operands+0x20c>
    cad4:      	b	0xcae0 <_stogir.conditional.operands+0x210>
    cad8:      	b	0xce24 <_stogir.conditional.operands+0x554>
    cadc:      	b	0xced0 <_stogir.conditional.operands+0x600>
    cae0:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x29c>
		000000000000cae0:  ARM64_RELOC_PAGE21	l_stogir.468
    cae4:      	ldr	x16, [x16]
		000000000000cae4:  ARM64_RELOC_PAGEOFF12	l_stogir.468
    cae8:      	orr	x0, x16, xzr
    caec:      	mov	x1, #0x16               ; =22
    caf0:      	b	0xcb18 <_stogir.conditional.operands+0x248>
    caf4:      	movz	x9, #0x0, lsl #48
    caf8:      	fmov	d31, x8
    cafc:      	mov	x8, x9
    cb00:      	fmov	x9, d31
    cb04:      	b	0xcb84 <_stogir.conditional.operands+0x2b4>
    cb08:      	movz	x9, #0x0, lsl #48
    cb0c:      	b	0xcb8c <_stogir.conditional.operands+0x2bc>
    cb10:      	mov	x0, x1
    cb14:      	mov	x1, x2
    cb18:      	add	x16, sp, #0x20
    cb1c:      	orr	x2, x16, xzr
    cb20:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x29c>
		000000000000cb20:  ARM64_RELOC_PAGE21	l_stogir.469
    cb24:      	ldr	x16, [x16]
		000000000000cb24:  ARM64_RELOC_PAGEOFF12	l_stogir.469
    cb28:      	orr	x3, x16, xzr
    cb2c:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x29c>
		000000000000cb2c:  ARM64_RELOC_PAGE21	l_stogir.470
    cb30:      	ldr	x16, [x16]
		000000000000cb30:  ARM64_RELOC_PAGEOFF12	l_stogir.470
    cb34:      	orr	x4, x16, xzr
    cb38:      	lsr	w24, w24, #0
    cb3c:      	lsr	w25, w25, #0
    cb40:      	add	x5, x22, #0x78
    cb44:      	add	x6, x22, #0x28
    cb48:      	add	x7, x22, #0x50
    cb4c:      	add	x16, sp, #0x10
    cb50:      	str	w24, [x16]
    cb54:      	add	x16, sp, #0x10
    cb58:      	str	w25, [x16, #0x4]
    cb5c:      	add	x16, sp, #0x10
    cb60:      	ldr	x8, [x16]
    cb64:      	add	x16, sp, #0x20
    cb68:      	str	x8, [x16]
    cb6c:      	mov	x8, x1
    cb70:      	mov	x1, x0
    cb74:      	movz	x0, #0x0, lsl #48
    cb78:      	b	0xcc58 <_stogir.conditional.operands+0x388>
    cb7c:      	mov	x9, x8
    cb80:      	movz	x8, #0x0, lsl #48
    cb84:      	b	0xcb98 <_stogir.conditional.operands+0x2c8>
    cb88:      	movz	x9, #0x0, lsl #48
    cb8c:      	fmov	d31, x8
    cb90:      	mov	x8, x9
    cb94:      	fmov	x9, d31
    cb98:      	cmp	x8, #0x0
    cb9c:      	b.eq	0xcbe0 <_stogir.conditional.operands+0x310>
    cba0:      	uxtb	w16, w0
    cba4:      	cmp	w16, wzr
    cba8:      	b.eq	0xcbc0 <_stogir.conditional.operands+0x2f0>
    cbac:      	lsl	x0, x1, #4
    cbb0:      	ldr	x1, [x22]
    cbb4:      	add	x0, x0, x1
    cbb8:      	ldr	x0, [x0]
    cbbc:      	b	0xcbd0 <_stogir.conditional.operands+0x300>
    cbc0:      	lsl	x0, x10, #4
    cbc4:      	ldr	x1, [x22, #0x28]
    cbc8:      	add	x0, x0, x1
    cbcc:      	ldr	x0, [x0]
    cbd0:      	mov	x1, x0
    cbd4:      	mov	x8, x9
    cbd8:      	mov	x0, #0x1                ; =1
    cbdc:      	b	0xcbec <_stogir.conditional.operands+0x31c>
    cbe0:      	mov	x8, x9
    cbe4:      	movz	x0, #0x0, lsl #48
    cbe8:      	movz	x1, #0x0, lsl #48
    cbec:      	lsr	w0, w0, #0
    cbf0:      	lsr	x16, x0, #0
    cbf4:      	cmp	x16, #0x1
    cbf8:      	b.eq	0xcc14 <_stogir.conditional.operands+0x344>
    cbfc:      	b.lo	0xcc04 <_stogir.conditional.operands+0x334>
    cc00:      	b	0xcc18 <_stogir.conditional.operands+0x348>
    cc04:      	cmp	x16, #0x0
    cc08:      	b.eq	0xcc10 <_stogir.conditional.operands+0x340>
    cc0c:      	b	0xcc18 <_stogir.conditional.operands+0x348>
    cc10:      	b	0xcc1c <_stogir.conditional.operands+0x34c>
    cc14:      	b	0xcdf4 <_stogir.conditional.operands+0x524>
    cc18:      	b	0xcec8 <_stogir.conditional.operands+0x5f8>
    cc1c:      	mov	x0, x8
    cc20:      	mov	x1, x3
    cc24:      	mov	x8, #0x10               ; =16
    cc28:      	b	0xcc58 <_stogir.conditional.operands+0x388>
    cc2c:      	and	x0, x20, #0xffffffff
    cc30:      	mov	x1, x0
    cc34:      	movz	x0, #0x0, lsl #48
    cc38:      	movz	x2, #0x0, lsl #48
    cc3c:      	b	0xcd78 <_stogir.conditional.operands+0x4a8>
    cc40:      	mov	x0, x4
    cc44:      	mov	x1, #0x21               ; =33
    cc48:      	fmov	d31, x0
    cc4c:      	mov	x0, x8
    cc50:      	mov	x8, x1
    cc54:      	fmov	x1, d31
    cc58:      	cmp	x0, #0x2
    cc5c:      	b.ge	0xcc90 <_stogir.conditional.operands+0x3c0>
    cc60:      	add	x9, x0, #0x1
    cc64:      	lsl	x0, x0, #2
    cc68:      	add	x0, x0, x2
    cc6c:      	ldr	w0, [x0]
    cc70:      	sxtw	x0, w0
    cc74:      	and	x0, x0, #0xffffffff
    cc78:      	mov	x23, x1
    cc7c:      	mov	x1, x0
    cc80:      	mov	x24, x8
    cc84:      	mov	x8, x9
    cc88:      	mov	x0, #0x1                ; =1
    cc8c:      	b	0xcca4 <_stogir.conditional.operands+0x3d4>
    cc90:      	mov	x23, x1
    cc94:      	mov	x24, x8
    cc98:      	mov	x8, x0
    cc9c:      	movz	x0, #0x0, lsl #48
    cca0:      	movz	x1, #0x0, lsl #48
    cca4:      	lsr	w0, w0, #0
    cca8:      	lsr	x16, x0, #0
    ccac:      	cmp	x16, #0x1
    ccb0:      	b.eq	0xcccc <_stogir.conditional.operands+0x3fc>
    ccb4:      	b.lo	0xccbc <_stogir.conditional.operands+0x3ec>
    ccb8:      	b	0xccd0 <_stogir.conditional.operands+0x400>
    ccbc:      	cmp	x16, #0x0
    ccc0:      	b.eq	0xccc8 <_stogir.conditional.operands+0x3f8>
    ccc4:      	b	0xccd0 <_stogir.conditional.operands+0x400>
    ccc8:      	b	0xcd38 <_stogir.conditional.operands+0x468>
    cccc:      	b	0xccd4 <_stogir.conditional.operands+0x404>
    ccd0:      	b	0xcec0 <_stogir.conditional.operands+0x5f0>
    ccd4:      	lsr	w1, w1, #0
    ccd8:      	sxtw	x1, w1
    ccdc:      	cmp	x1, #0x0
    cce0:      	cset	w0, gt
    cce4:      	movz	x16, #0x0, lsl #48
    cce8:      	sub	x9, x16, x1
    ccec:      	sub	x10, x9, #0x1
    ccf0:      	uxtb	w16, w0
    ccf4:      	cmp	w16, wzr
    ccf8:      	b.eq	0xcdb0 <_stogir.conditional.operands+0x4e0>
    ccfc:      	ldr	x9, [x22, #0x8]
    cd00:      	cmp	x1, x9
    cd04:      	b.ge	0xcb7c <_stogir.conditional.operands+0x2ac>
    cd08:      	ldr	x9, [x5, #0x8]
    cd0c:      	cmp	x1, x9
    cd10:      	b.ge	0xcaf4 <_stogir.conditional.operands+0x224>
    cd14:      	lsl	x9, x1, #2
    cd18:      	ldr	x11, [x22, #0x78]
    cd1c:      	add	x9, x9, x11
    cd20:      	ldr	w9, [x9]
    cd24:      	sxtw	x9, w9
    cd28:      	cmp	x9, #0x0
    cd2c:      	cset	w9, ge
    cd30:      	ubfx	x9, x9, #0, #8
    cd34:      	b	0xcaf8 <_stogir.conditional.operands+0x228>
    cd38:      	cmp	x24, #0x0
    cd3c:      	b.ne	0xcd6c <_stogir.conditional.operands+0x49c>
    cd40:      	cmp	x24, #0x0
    cd44:      	b.eq	0xcc2c <_stogir.conditional.operands+0x35c>
    cd48:      	lsr	x0, x24, #0
    cd4c:      	mov	x1, x19
    cd50:      	mov	x2, x0
    cd54:      	mov	x0, x23
    cd58:      	bl	0xcd58 <_stogir.conditional.operands+0x488>
		000000000000cd58:  ARM64_RELOC_BRANCH26	_memcmp
    cd5c:      	lsr	w0, w0, #0
    cd60:      	sxtw	x0, w0
    cd64:      	cmp	x0, #0x0
    cd68:      	b.eq	0xcc2c <_stogir.conditional.operands+0x35c>
    cd6c:      	mov	x1, x23
    cd70:      	mov	x2, x24
    cd74:      	mov	x0, #0x1                ; =1
    cd78:      	str	x0, [x21]
    cd7c:      	str	x1, [x21, #0x8]
    cd80:      	str	x2, [x21, #0x10]
    cd84:      	ldr	x19, [sp, #0x30]
    cd88:      	ldr	x20, [sp, #0x38]
    cd8c:      	ldr	x21, [sp, #0x40]
    cd90:      	ldr	x22, [sp, #0x48]
    cd94:      	ldr	x23, [sp, #0x50]
    cd98:      	ldr	x24, [sp, #0x58]
    cd9c:      	ldr	x25, [sp, #0x60]
    cda0:      	ldr	x29, [sp]
    cda4:      	ldr	x30, [sp, #0x8]
    cda8:      	add	sp, sp, #0x70
    cdac:      	ret
    cdb0:      	cmp	x1, #0x0
    cdb4:      	b.ge	0xcb88 <_stogir.conditional.operands+0x2b8>
    cdb8:      	ldr	x11, [x6, #0x8]
    cdbc:      	ldr	x12, [x7, #0x8]
    cdc0:      	cmp	x11, x12
    cdc4:      	b.ne	0xcb08 <_stogir.conditional.operands+0x238>
    cdc8:      	cmp	x9, x11
    cdcc:      	b.gt	0xca30 <_stogir.conditional.operands+0x160>
    cdd0:      	lsl	x9, x10, #2
    cdd4:      	ldr	x11, [x22, #0x50]
    cdd8:      	add	x9, x9, x11
    cddc:      	ldr	w9, [x9]
    cde0:      	sxtw	x9, w9
    cde4:      	cmp	x9, #0x0
    cde8:      	cset	w9, gt
    cdec:      	ubfx	x9, x9, #0, #8
    cdf0:      	b	0xca34 <_stogir.conditional.operands+0x164>
    cdf4:      	uxtb	w0, w1
    cdf8:      	cmp	x0, #0x48
    cdfc:      	b.eq	0xcc40 <_stogir.conditional.operands+0x370>
    ce00:      	cmp	x0, #0x46
    ce04:      	b.eq	0xcc40 <_stogir.conditional.operands+0x370>
    ce08:      	lsr	w1, w1, #0
    ce0c:      	ubfx	x0, x1, #8, #8
    ce10:      	cmp	x0, x20
    ce14:      	b.ne	0xcc40 <_stogir.conditional.operands+0x370>
    ce18:      	mov	x0, x23
    ce1c:      	mov	x1, x24
    ce20:      	b	0xcc48 <_stogir.conditional.operands+0x378>
    ce24:      	uxtb	w0, w1
    ce28:      	cmp	x0, #0x48
    ce2c:      	b.ne	0xce90 <_stogir.conditional.operands+0x5c0>
    ce30:      	mov	x1, x2
    ce34:      	mov	x2, x3
    ce38:      	mov	x0, #0x1                ; =1
    ce3c:      	b	0xce74 <_stogir.conditional.operands+0x5a4>
    ce40:      	mov	x3, x0
    ce44:      	movz	x0, #0x0, lsl #48
    ce48:      	fmov	d31, x1
    ce4c:      	mov	x1, x3
    ce50:      	fmov	x3, d31
    ce54:      	b	0xca44 <_stogir.conditional.operands+0x174>
    ce58:      	cmp	x0, #0xd
    ce5c:      	cset	w0, le
    ce60:      	uxtb	w16, w0
    ce64:      	cmp	w16, wzr
    ce68:      	cset	x0, eq
    ce6c:      	mov	x1, x2
    ce70:      	mov	x2, x3
    ce74:      	cmp	x0, #0x0
    ce78:      	b.eq	0xcb10 <_stogir.conditional.operands+0x240>
    ce7c:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x29c>
		000000000000ce7c:  ARM64_RELOC_PAGE21	l_stogir.471
    ce80:      	ldr	x16, [x16]
		000000000000ce80:  ARM64_RELOC_PAGEOFF12	l_stogir.471
    ce84:      	orr	x0, x16, xzr
    ce88:      	mov	x1, #0x2a               ; =42
    ce8c:      	b	0xcb18 <_stogir.conditional.operands+0x248>
    ce90:      	cmp	x0, #0x46
    ce94:      	b.ne	0xcea8 <_stogir.conditional.operands+0x5d8>
    ce98:      	mov	x0, #0x1                ; =1
    ce9c:      	b	0xce6c <_stogir.conditional.operands+0x59c>
    cea0:      	movz	x3, #0x0, lsl #48
    cea4:      	b	0xca2c <_stogir.conditional.operands+0x15c>
    cea8:      	lsr	w1, w1, #0
    ceac:      	ubfx	x0, x1, #8, #8
    ceb0:      	cmp	x0, #0x0
    ceb4:      	b.ne	0xce58 <_stogir.conditional.operands+0x588>
    ceb8:      	mov	x0, #0x1                ; =1
    cebc:      	b	0xce6c <_stogir.conditional.operands+0x59c>
    cec0:      	brk	#0
    cec4:      	b	0xcec0 <_stogir.conditional.operands+0x5f0>
    cec8:      	brk	#0
    cecc:      	b	0xcec8 <_stogir.conditional.operands+0x5f8>
    ced0:      	brk	#0
    ced4:      	b	0xced0 <_stogir.conditional.operands+0x600>

000000000000ced8 <_stogir.floating.unary?>:
    ced8:      	sxtw	x0, w0
    cedc:      	cmp	x0, #0x1f
    cee0:      	b.ne	0xceec <_stogir.floating.unary?+0x14>
    cee4:      	mov	x0, #0x1                ; =1
    cee8:      	b	0xcef8 <_stogir.floating.unary?+0x20>
    ceec:      	cmp	x0, #0x20
    cef0:      	cset	w0, eq
    cef4:      	ubfx	x0, x0, #0, #8
    cef8:      	ret

000000000000cefc <_stogir.floating.comparison?>:
    cefc:      	sxtw	x0, w0
    cf00:      	cmp	x0, #0xe
    cf04:      	b.lt	0xcf18 <_stogir.floating.comparison?+0x1c>
    cf08:      	cmp	x0, #0x19
    cf0c:      	cset	w0, le
    cf10:      	ubfx	x0, x0, #0, #8
    cf14:      	b	0xcf1c <_stogir.floating.comparison?+0x20>
    cf18:      	movz	x0, #0x0, lsl #48
    cf1c:      	ret

000000000000cf20 <_stogir.floating.operands>:
    cf20:      	sub	sp, sp, #0x90
    cf24:      	str	x29, [sp]
    cf28:      	str	x30, [sp, #0x8]
    cf2c:      	mov	x29, sp
    cf30:      	str	x19, [sp, #0x60]
    cf34:      	str	x20, [sp, #0x68]
    cf38:      	str	x21, [sp, #0x70]
    cf3c:      	str	x22, [sp, #0x78]
    cf40:      	str	x23, [sp, #0x80]
    cf44:      	str	x24, [sp, #0x88]
    cf48:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x29c>
		000000000000cf48:  ARM64_RELOC_PAGE21	l_stogir.472
    cf4c:      	ldr	x16, [x16]
		000000000000cf4c:  ARM64_RELOC_PAGEOFF12	l_stogir.472
    cf50:      	orr	x19, x16, xzr
    cf54:      	sxtw	x1, w1
    cf58:      	sxtw	x20, w2
    cf5c:      	cmp	x1, #0x1f
    cf60:      	cset	w2, eq
    cf64:      	cmp	x1, #0x20
    cf68:      	cset	w6, eq
    cf6c:      	cmp	x1, #0xe
    cf70:      	b.lt	0xcfac <_stogir.floating.operands+0x8c>
    cf74:      	cmp	x1, #0x19
    cf78:      	b.gt	0xcfac <_stogir.floating.operands+0x8c>
    cf7c:      	cmp	x20, #0xc
    cf80:      	b.ne	0xcf8c <_stogir.floating.operands+0x6c>
    cf84:      	mov	x7, #0x1                ; =1
    cf88:      	b	0xcf98 <_stogir.floating.operands+0x78>
    cf8c:      	cmp	x20, #0xd
    cf90:      	cset	w7, eq
    cf94:      	ubfx	x7, x7, #0, #8
    cf98:      	cmp	x7, #0x0
    cf9c:      	b.eq	0xcfe4 <_stogir.floating.operands+0xc4>
    cfa0:      	mov	x7, x19
    cfa4:      	movz	x9, #0x0, lsl #48
    cfa8:      	b	0xcff4 <_stogir.floating.operands+0xd4>
    cfac:      	uxtb	w16, w2
    cfb0:      	cmp	w16, wzr
    cfb4:      	b.ne	0xcf7c <_stogir.floating.operands+0x5c>
    cfb8:      	uxtb	w16, w6
    cfbc:      	cmp	w16, wzr
    cfc0:      	b.ne	0xcf7c <_stogir.floating.operands+0x5c>
    cfc4:      	cmp	x1, #0x1a
    cfc8:      	b.lt	0xcfd4 <_stogir.floating.operands+0xb4>
    cfcc:      	cmp	x1, #0x1d
    cfd0:      	b.le	0xcf7c <_stogir.floating.operands+0x5c>
    cfd4:      	cmp	x1, #0x3a
    cfd8:      	b.eq	0xcf7c <_stogir.floating.operands+0x5c>
    cfdc:      	cmp	x1, #0x3b
    cfe0:      	b.eq	0xcf7c <_stogir.floating.operands+0x5c>
    cfe4:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x29c>
		000000000000cfe4:  ARM64_RELOC_PAGE21	l_stogir.473
    cfe8:      	ldr	x16, [x16]
		000000000000cfe8:  ARM64_RELOC_PAGEOFF12	l_stogir.473
    cfec:      	orr	x7, x16, xzr
    cff0:      	mov	x9, #0x22               ; =34
    cff4:      	lsr	w3, w3, #0
    cff8:      	add	x16, sp, #0x10
    cffc:      	str	w3, [x16]
    d000:      	uxtb	w16, w2
    d004:      	cmp	w16, wzr
    d008:      	b.eq	0xd018 <_stogir.floating.operands+0xf8>
    d00c:      	mov	x6, x7
    d010:      	mov	x2, #0x1                ; =1
    d014:      	b	0xd024 <_stogir.floating.operands+0x104>
    d018:      	ubfx	x6, x6, #0, #8
    d01c:      	mov	x2, x6
    d020:      	mov	x6, x7
    d024:      	cmp	x2, #0x0
    d028:      	b.eq	0xd064 <_stogir.floating.operands+0x144>
    d02c:      	sxtw	x3, w3
    d030:      	mov	x2, x3
    d034:      	mov	x3, x6
    d038:      	b	0xd070 <_stogir.floating.operands+0x150>
    d03c:      	mov	x0, x1
    d040:      	mov	x1, x2
    d044:      	b	0xd1ac <_stogir.floating.operands+0x28c>
    d048:      	movz	x15, #0x0, lsl #48
    d04c:      	fmov	d31, x9
    d050:      	mov	x9, x15
    d054:      	fmov	x15, d31
    d058:      	b	0xd0c8 <_stogir.floating.operands+0x1a8>
    d05c:      	movz	x15, #0x0, lsl #48
    d060:      	b	0xd0d0 <_stogir.floating.operands+0x1b0>
    d064:      	sxtw	x4, w4
    d068:      	mov	x2, x4
    d06c:      	mov	x3, x6
    d070:      	add	x16, sp, #0x20
    d074:      	orr	x4, x16, xzr
    d078:      	adrp	x16, 0xd000 <_stogir.floating.operands+0xe0>
		000000000000d078:  ARM64_RELOC_PAGE21	l_stogir.474
    d07c:      	ldr	x16, [x16]
		000000000000d07c:  ARM64_RELOC_PAGEOFF12	l_stogir.474
    d080:      	orr	x6, x16, xzr
    d084:      	adrp	x16, 0xd000 <_stogir.floating.operands+0xe0>
		000000000000d084:  ARM64_RELOC_PAGE21	l_stogir.475
    d088:      	ldr	x16, [x16]
		000000000000d088:  ARM64_RELOC_PAGEOFF12	l_stogir.475
    d08c:      	orr	x7, x16, xzr
    d090:      	add	x10, x0, #0x78
    d094:      	add	x11, x0, #0x28
    d098:      	add	x12, x0, #0x50
    d09c:      	lsr	w2, w2, #0
    d0a0:      	add	x16, sp, #0x10
    d0a4:      	str	w2, [x16, #0x4]
    d0a8:      	add	x16, sp, #0x10
    d0ac:      	ldr	x2, [x16]
    d0b0:      	add	x16, sp, #0x20
    d0b4:      	str	x2, [x16]
    d0b8:      	movz	x2, #0x0, lsl #48
    d0bc:      	b	0xd1d0 <_stogir.floating.operands+0x2b0>
    d0c0:      	mov	x15, x9
    d0c4:      	movz	x9, #0x0, lsl #48
    d0c8:      	b	0xd0dc <_stogir.floating.operands+0x1bc>
    d0cc:      	movz	x15, #0x0, lsl #48
    d0d0:      	fmov	d31, x9
    d0d4:      	mov	x9, x15
    d0d8:      	fmov	x15, d31
    d0dc:      	cmp	x9, #0x0
    d0e0:      	b.eq	0xd124 <_stogir.floating.operands+0x204>
    d0e4:      	uxtb	w16, w2
    d0e8:      	cmp	w16, wzr
    d0ec:      	b.eq	0xd104 <_stogir.floating.operands+0x1e4>
    d0f0:      	lsl	x2, x3, #4
    d0f4:      	ldr	x3, [x0]
    d0f8:      	add	x2, x2, x3
    d0fc:      	ldr	x2, [x2]
    d100:      	b	0xd114 <_stogir.floating.operands+0x1f4>
    d104:      	lsl	x2, x21, #4
    d108:      	ldr	x3, [x0, #0x28]
    d10c:      	add	x2, x2, x3
    d110:      	ldr	x2, [x2]
    d114:      	mov	x3, x2
    d118:      	mov	x9, x15
    d11c:      	mov	x2, #0x1                ; =1
    d120:      	b	0xd130 <_stogir.floating.operands+0x210>
    d124:      	mov	x9, x15
    d128:      	movz	x2, #0x0, lsl #48
    d12c:      	movz	x3, #0x0, lsl #48
    d130:      	lsr	w2, w2, #0
    d134:      	lsr	x16, x2, #0
    d138:      	cmp	x16, #0x1
    d13c:      	b.eq	0xd158 <_stogir.floating.operands+0x238>
    d140:      	b.lo	0xd148 <_stogir.floating.operands+0x228>
    d144:      	b	0xd15c <_stogir.floating.operands+0x23c>
    d148:      	cmp	x16, #0x0
    d14c:      	b.eq	0xd154 <_stogir.floating.operands+0x234>
    d150:      	b	0xd15c <_stogir.floating.operands+0x23c>
    d154:      	b	0xd160 <_stogir.floating.operands+0x240>
    d158:      	b	0xd3b8 <_stogir.floating.operands+0x498>
    d15c:      	b	0xd4f0 <_stogir.floating.operands+0x5d0>
    d160:      	mov	x2, x9
    d164:      	mov	x3, x6
    d168:      	mov	x9, #0x18               ; =24
    d16c:      	b	0xd1d0 <_stogir.floating.operands+0x2b0>
    d170:      	and	x0, x20, #0xffffffff
    d174:      	mov	x1, x0
    d178:      	movz	x0, #0x0, lsl #48
    d17c:      	movz	x2, #0x0, lsl #48
    d180:      	b	0xd340 <_stogir.floating.operands+0x420>
    d184:      	mov	x22, x3
    d188:      	mov	x23, x4
    d18c:      	mov	x1, #0x1                ; =1
    d190:      	cmp	x1, #0x0
    d194:      	b.eq	0xd3d4 <_stogir.floating.operands+0x4b4>
    d198:      	adrp	x16, 0xd000 <_stogir.floating.operands+0xe0>
		000000000000d198:  ARM64_RELOC_PAGE21	l_stogir.476
    d19c:      	ldr	x16, [x16]
		000000000000d19c:  ARM64_RELOC_PAGEOFF12	l_stogir.476
    d1a0:      	orr	x0, x16, xzr
    d1a4:      	mov	x24, x8
    d1a8:      	mov	x1, #0x21               ; =33
    d1ac:      	mov	x21, x0
    d1b0:      	mov	x22, x1
    d1b4:      	b	0xd300 <_stogir.floating.operands+0x3e0>
    d1b8:      	mov	x2, x7
    d1bc:      	mov	x3, #0x1e               ; =30
    d1c0:      	fmov	d31, x2
    d1c4:      	mov	x2, x9
    d1c8:      	mov	x9, x3
    d1cc:      	fmov	x3, d31
    d1d0:      	cmp	x2, #0x2
    d1d4:      	b.ge	0xd208 <_stogir.floating.operands+0x2e8>
    d1d8:      	add	x13, x2, #0x1
    d1dc:      	lsl	x2, x2, #2
    d1e0:      	add	x2, x2, x4
    d1e4:      	ldr	w2, [x2]
    d1e8:      	sxtw	x2, w2
    d1ec:      	and	x2, x2, #0xffffffff
    d1f0:      	mov	x14, x9
    d1f4:      	mov	x9, x13
    d1f8:      	mov	x13, x3
    d1fc:      	mov	x3, x2
    d200:      	mov	x2, #0x1                ; =1
    d204:      	b	0xd21c <_stogir.floating.operands+0x2fc>
    d208:      	mov	x13, x3
    d20c:      	mov	x14, x9
    d210:      	mov	x9, x2
    d214:      	movz	x2, #0x0, lsl #48
    d218:      	movz	x3, #0x0, lsl #48
    d21c:      	lsr	w2, w2, #0
    d220:      	lsr	x16, x2, #0
    d224:      	cmp	x16, #0x1
    d228:      	b.eq	0xd244 <_stogir.floating.operands+0x324>
    d22c:      	b.lo	0xd234 <_stogir.floating.operands+0x314>
    d230:      	b	0xd248 <_stogir.floating.operands+0x328>
    d234:      	cmp	x16, #0x0
    d238:      	b.eq	0xd240 <_stogir.floating.operands+0x320>
    d23c:      	b	0xd248 <_stogir.floating.operands+0x328>
    d240:      	b	0xd2b0 <_stogir.floating.operands+0x390>
    d244:      	b	0xd24c <_stogir.floating.operands+0x32c>
    d248:      	b	0xd4a4 <_stogir.floating.operands+0x584>
    d24c:      	lsr	w3, w3, #0
    d250:      	sxtw	x3, w3
    d254:      	cmp	x3, #0x0
    d258:      	cset	w2, gt
    d25c:      	movz	x16, #0x0, lsl #48
    d260:      	sub	x15, x16, x3
    d264:      	sub	x21, x15, #0x1
    d268:      	uxtb	w16, w2
    d26c:      	cmp	w16, wzr
    d270:      	b.eq	0xd374 <_stogir.floating.operands+0x454>
    d274:      	ldr	x15, [x0, #0x8]
    d278:      	cmp	x3, x15
    d27c:      	b.ge	0xd0c0 <_stogir.floating.operands+0x1a0>
    d280:      	ldr	x15, [x10, #0x8]
    d284:      	cmp	x3, x15
    d288:      	b.ge	0xd048 <_stogir.floating.operands+0x128>
    d28c:      	lsl	x15, x3, #2
    d290:      	ldr	x22, [x0, #0x78]
    d294:      	add	x15, x15, x22
    d298:      	ldr	w15, [x15]
    d29c:      	sxtw	x15, w15
    d2a0:      	cmp	x15, #0x0
    d2a4:      	cset	w15, ge
    d2a8:      	ubfx	x15, x15, #0, #8
    d2ac:      	b	0xd04c <_stogir.floating.operands+0x12c>
    d2b0:      	sxtw	x21, w5
    d2b4:      	cmp	x21, #0x0
    d2b8:      	b.ne	0xd2cc <_stogir.floating.operands+0x3ac>
    d2bc:      	mov	x3, x13
    d2c0:      	mov	x4, x14
    d2c4:      	movz	x2, #0x0, lsl #48
    d2c8:      	b	0xd2d8 <_stogir.floating.operands+0x3b8>
    d2cc:      	mov	x3, x13
    d2d0:      	mov	x4, x14
    d2d4:      	mov	x2, #0x1                ; =1
    d2d8:      	cmp	x2, #0x0
    d2dc:      	b.eq	0xd500 <_stogir.floating.operands+0x5e0>
    d2e0:      	cmp	x1, #0x1d
    d2e4:      	b.ne	0xd184 <_stogir.floating.operands+0x264>
    d2e8:      	mov	x22, x3
    d2ec:      	mov	x23, x4
    d2f0:      	movz	x1, #0x0, lsl #48
    d2f4:      	b	0xd190 <_stogir.floating.operands+0x270>
    d2f8:      	mov	x21, x3
    d2fc:      	mov	x22, x4
    d300:      	cmp	x22, #0x0
    d304:      	b.ne	0xd334 <_stogir.floating.operands+0x414>
    d308:      	cmp	x22, #0x0
    d30c:      	b.eq	0xd170 <_stogir.floating.operands+0x250>
    d310:      	lsr	x0, x22, #0
    d314:      	mov	x1, x19
    d318:      	mov	x2, x0
    d31c:      	mov	x0, x21
    d320:      	bl	0xd320 <_stogir.floating.operands+0x400>
		000000000000d320:  ARM64_RELOC_BRANCH26	_memcmp
    d324:      	lsr	w0, w0, #0
    d328:      	sxtw	x0, w0
    d32c:      	cmp	x0, #0x0
    d330:      	b.eq	0xd170 <_stogir.floating.operands+0x250>
    d334:      	mov	x1, x21
    d338:      	mov	x2, x22
    d33c:      	mov	x0, #0x1                ; =1
    d340:      	str	x0, [x24]
    d344:      	str	x1, [x24, #0x8]
    d348:      	str	x2, [x24, #0x10]
    d34c:      	ldr	x19, [sp, #0x60]
    d350:      	ldr	x20, [sp, #0x68]
    d354:      	ldr	x21, [sp, #0x70]
    d358:      	ldr	x22, [sp, #0x78]
    d35c:      	ldr	x23, [sp, #0x80]
    d360:      	ldr	x24, [sp, #0x88]
    d364:      	ldr	x29, [sp]
    d368:      	ldr	x30, [sp, #0x8]
    d36c:      	add	sp, sp, #0x90
    d370:      	ret
    d374:      	cmp	x3, #0x0
    d378:      	b.ge	0xd0cc <_stogir.floating.operands+0x1ac>
    d37c:      	ldr	x22, [x11, #0x8]
    d380:      	ldr	x23, [x12, #0x8]
    d384:      	cmp	x22, x23
    d388:      	b.ne	0xd05c <_stogir.floating.operands+0x13c>
    d38c:      	cmp	x15, x22
    d390:      	b.gt	0xd430 <_stogir.floating.operands+0x510>
    d394:      	lsl	x15, x21, #2
    d398:      	ldr	x22, [x0, #0x50]
    d39c:      	add	x15, x15, x22
    d3a0:      	ldr	w15, [x15]
    d3a4:      	sxtw	x15, w15
    d3a8:      	cmp	x15, #0x0
    d3ac:      	cset	w15, gt
    d3b0:      	ubfx	x15, x15, #0, #8
    d3b4:      	b	0xd434 <_stogir.floating.operands+0x514>
    d3b8:      	lsr	w3, w3, #0
    d3bc:      	ubfx	x2, x3, #8, #8
    d3c0:      	cmp	x2, x20
    d3c4:      	b.ne	0xd1b8 <_stogir.floating.operands+0x298>
    d3c8:      	mov	x2, x13
    d3cc:      	mov	x3, x14
    d3d0:      	b	0xd1c0 <_stogir.floating.operands+0x2a0>
    d3d4:      	lsr	w5, w5, #0
    d3d8:      	mov	w1, w5
    d3dc:      	mov	x24, x8
    d3e0:      	add	x8, sp, #0x30
    d3e4:      	bl	0xd3e4 <_stogir.floating.operands+0x4c4>
		000000000000d3e4:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    d3e8:      	add	x16, sp, #0x30
    d3ec:      	ldr	w0, [x16]
    d3f0:      	lsr	x16, x0, #0
    d3f4:      	cmp	x16, #0x1
    d3f8:      	b.eq	0xd414 <_stogir.floating.operands+0x4f4>
    d3fc:      	b.lo	0xd404 <_stogir.floating.operands+0x4e4>
    d400:      	b	0xd418 <_stogir.floating.operands+0x4f8>
    d404:      	cmp	x16, #0x0
    d408:      	b.eq	0xd410 <_stogir.floating.operands+0x4f0>
    d40c:      	b	0xd418 <_stogir.floating.operands+0x4f8>
    d410:      	b	0xd41c <_stogir.floating.operands+0x4fc>
    d414:      	b	0xd438 <_stogir.floating.operands+0x518>
    d418:      	b	0xd4f8 <_stogir.floating.operands+0x5d8>
    d41c:      	adrp	x16, 0xd000 <_stogir.floating.operands+0xe0>
		000000000000d41c:  ARM64_RELOC_PAGE21	l_stogir.477
    d420:      	ldr	x16, [x16]
		000000000000d420:  ARM64_RELOC_PAGEOFF12	l_stogir.477
    d424:      	orr	x0, x16, xzr
    d428:      	mov	x1, #0x16               ; =22
    d42c:      	b	0xd044 <_stogir.floating.operands+0x124>
    d430:      	movz	x15, #0x0, lsl #48
    d434:      	b	0xd060 <_stogir.floating.operands+0x140>
    d438:      	add	x16, sp, #0x30
    d43c:      	ldr	x0, [x16, #0x8]
    d440:      	cmp	x21, #0x0
    d444:      	b.ge	0xd480 <_stogir.floating.operands+0x560>
    d448:      	mov	x1, x22
    d44c:      	mov	x2, x23
    d450:      	mov	x0, #0x1                ; =1
    d454:      	b	0xd464 <_stogir.floating.operands+0x544>
    d458:      	movz	x0, #0x0, lsl #48
    d45c:      	mov	x1, x22
    d460:      	mov	x2, x23
    d464:      	cmp	x0, #0x0
    d468:      	b.eq	0xd03c <_stogir.floating.operands+0x11c>
    d46c:      	adrp	x16, 0xd000 <_stogir.floating.operands+0xe0>
		000000000000d46c:  ARM64_RELOC_PAGE21	l_stogir.478
    d470:      	ldr	x16, [x16]
		000000000000d470:  ARM64_RELOC_PAGEOFF12	l_stogir.478
    d474:      	orr	x0, x16, xzr
    d478:      	mov	x1, #0x2d               ; =45
    d47c:      	b	0xd044 <_stogir.floating.operands+0x124>
    d480:      	uxtb	w0, w0
    d484:      	cmp	x0, #0x83
    d488:      	b.ge	0xd4ac <_stogir.floating.operands+0x58c>
    d48c:      	adrp	x16, 0xd000 <_stogir.floating.operands+0xe0>
		000000000000d48c:  ARM64_RELOC_PAGE21	l_stogir.479
    d490:      	ldr	x16, [x16]
		000000000000d490:  ARM64_RELOC_PAGEOFF12	l_stogir.479
    d494:      	orr	x1, x16, xzr
    d498:      	add	x1, x0, x1
    d49c:      	ldrb	w1, [x1]
    d4a0:      	b	0xd4b0 <_stogir.floating.operands+0x590>
    d4a4:      	brk	#0
    d4a8:      	b	0xd4a4 <_stogir.floating.operands+0x584>
    d4ac:      	movz	x1, #0x0, lsl #48
    d4b0:      	uxtb	w1, w1
    d4b4:      	and	x1, x1, #0x2
    d4b8:      	uxtb	w1, w1
    d4bc:      	cmp	x1, #0x0
    d4c0:      	cset	w1, eq
    d4c4:      	uxtb	w16, w1
    d4c8:      	cmp	w16, wzr
    d4cc:      	cset	x1, eq
    d4d0:      	cmp	x1, #0x0
    d4d4:      	b.ne	0xd458 <_stogir.floating.operands+0x538>
    d4d8:      	cmp	x0, #0x65
    d4dc:      	b.eq	0xd458 <_stogir.floating.operands+0x538>
    d4e0:      	cmp	x0, #0x66
    d4e4:      	b.eq	0xd458 <_stogir.floating.operands+0x538>
    d4e8:      	mov	x0, #0x1                ; =1
    d4ec:      	b	0xd45c <_stogir.floating.operands+0x53c>
    d4f0:      	brk	#0
    d4f4:      	b	0xd4f0 <_stogir.floating.operands+0x5d0>
    d4f8:      	brk	#0
    d4fc:      	b	0xd4f8 <_stogir.floating.operands+0x5d8>
    d500:      	mov	x24, x8
    d504:      	b	0xd2f8 <_stogir.floating.operands+0x3d8>

000000000000d508 <_stogir.types.signed?>:
    d508:      	sxtw	x0, w0
    d50c:      	cmp	x0, #0x7
    d510:      	b.lt	0xd524 <_stogir.types.signed?+0x1c>
    d514:      	cmp	x0, #0xb
    d518:      	cset	w0, le
    d51c:      	ubfx	x0, x0, #0, #8
    d520:      	b	0xd528 <_stogir.types.signed?+0x20>
    d524:      	movz	x0, #0x0, lsl #48
    d528:      	ret

000000000000d52c <_stogir.integer-binary.logical?>:
    d52c:      	sxtw	x0, w0
    d530:      	cmp	x0, #0x2e
    d534:      	b.ne	0xd550 <_stogir.integer-binary.logical?+0x24>
    d538:      	mov	x0, #0x1                ; =1
    d53c:      	b	0xd54c <_stogir.integer-binary.logical?+0x20>
    d540:      	cmp	x0, #0x30
    d544:      	cset	w0, eq
    d548:      	ubfx	x0, x0, #0, #8
    d54c:      	ret
    d550:      	cmp	x0, #0x2f
    d554:      	b.ne	0xd540 <_stogir.integer-binary.logical?+0x14>
    d558:      	mov	x0, #0x1                ; =1
    d55c:      	b	0xd54c <_stogir.integer-binary.logical?+0x20>

000000000000d560 <_inherent$slice$data__i8>:
    d560:      	ret

000000000000d564 <_inherent$slice$data__u32>:
    d564:      	ret

000000000000d568 <_inherent$coil.arraylist.ArrayList$slice__stogir.node.Node>:
    d568:      	sub	sp, sp, #0x10
    d56c:      	mov	x1, sp
    d570:      	ldr	x2, [x0]
    d574:      	ldr	x0, [x0, #0x8]
    d578:      	str	x2, [x1]
    d57c:      	str	x0, [x1, #0x8]
    d580:      	ldr	x0, [sp]
    d584:      	ldr	x1, [sp, #0x8]
    d588:      	add	sp, sp, #0x10
    d58c:      	ret

000000000000d590 <_inherent$slice$at__stogir.node.Node>:
    d590:      	lsl	x1, x2, #4
    d594:      	add	x0, x1, x0
    d598:      	ret

000000000000d59c <_inherent$slice$new__u8>:
    d59c:      	sub	sp, sp, #0x10
    d5a0:      	mov	x2, sp
    d5a4:      	str	x0, [x2]
    d5a8:      	str	x1, [x2, #0x8]
    d5ac:      	ldr	x0, [sp]
    d5b0:      	ldr	x1, [sp, #0x8]
    d5b4:      	add	sp, sp, #0x10
    d5b8:      	ret

000000000000d5bc <_stogir.vector-lanes.operands>:
    d5bc:      	sub	sp, sp, #0x120
    d5c0:      	str	x29, [sp]
    d5c4:      	str	x30, [sp, #0x8]
    d5c8:      	mov	x29, sp
    d5cc:      	str	x19, [sp, #0xc8]
    d5d0:      	str	x20, [sp, #0xd0]
    d5d4:      	str	x21, [sp, #0xd8]
    d5d8:      	str	x22, [sp, #0xe0]
    d5dc:      	str	x23, [sp, #0xe8]
    d5e0:      	str	x24, [sp, #0xf0]
    d5e4:      	str	x25, [sp, #0xf8]
    d5e8:      	str	x26, [sp, #0x100]
    d5ec:      	str	x27, [sp, #0x108]
    d5f0:      	str	x28, [sp, #0x110]
    d5f4:      	sxtw	x4, w4
    d5f8:      	cmp	x4, #0x0
    d5fc:      	cset	w7, gt
    d600:      	movz	x16, #0x0, lsl #48
    d604:      	sub	x9, x16, x4
    d608:      	sub	x10, x9, #0x1
    d60c:      	uxtb	w16, w7
    d610:      	cmp	w16, wzr
    d614:      	b.eq	0xd658 <_stogir.vector-lanes.operands+0x9c>
    d618:      	ldr	x9, [x0, #0x8]
    d61c:      	cmp	x4, x9
    d620:      	b.ge	0xd70c <_stogir.vector-lanes.operands+0x150>
    d624:      	add	x9, x0, #0x78
    d628:      	ldr	x9, [x9, #0x8]
    d62c:      	cmp	x4, x9
    d630:      	b.ge	0xd81c <_stogir.vector-lanes.operands+0x260>
    d634:      	lsl	x9, x4, #2
    d638:      	ldr	x11, [x0, #0x78]
    d63c:      	add	x9, x9, x11
    d640:      	ldr	w9, [x9]
    d644:      	sxtw	x9, w9
    d648:      	cmp	x9, #0x0
    d64c:      	cset	w9, ge
    d650:      	ubfx	x9, x9, #0, #8
    d654:      	b	0xd820 <_stogir.vector-lanes.operands+0x264>
    d658:      	cmp	x4, #0x0
    d65c:      	b.ge	0xd714 <_stogir.vector-lanes.operands+0x158>
    d660:      	add	x11, x0, #0x28
    d664:      	add	x12, x0, #0x50
    d668:      	ldr	x11, [x11, #0x8]
    d66c:      	ldr	x12, [x12, #0x8]
    d670:      	cmp	x11, x12
    d674:      	b.ne	0xd6a4 <_stogir.vector-lanes.operands+0xe8>
    d678:      	cmp	x9, x11
    d67c:      	b.gt	0xd998 <_stogir.vector-lanes.operands+0x3dc>
    d680:      	lsl	x9, x10, #2
    d684:      	ldr	x11, [x0, #0x50]
    d688:      	add	x9, x9, x11
    d68c:      	ldr	w9, [x9]
    d690:      	sxtw	x9, w9
    d694:      	cmp	x9, #0x0
    d698:      	cset	w9, gt
    d69c:      	ubfx	x9, x9, #0, #8
    d6a0:      	b	0xd99c <_stogir.vector-lanes.operands+0x3e0>
    d6a4:      	movz	x9, #0x0, lsl #48
    d6a8:      	b	0xd718 <_stogir.vector-lanes.operands+0x15c>
    d6ac:      	mov	x0, x1
    d6b0:      	mov	x1, x23
    d6b4:      	str	x21, [sp, #0x98]
    d6b8:      	str	x19, [sp, #0xa0]
    d6bc:      	str	x22, [sp, #0x88]
    d6c0:      	mov	x19, x0
    d6c4:      	mov	x20, x1
    d6c8:      	cmp	x20, #0x0
    d6cc:      	b.ne	0xd6fc <_stogir.vector-lanes.operands+0x140>
    d6d0:      	cmp	x20, #0x0
    d6d4:      	b.eq	0xd9a0 <_stogir.vector-lanes.operands+0x3e4>
    d6d8:      	lsr	x0, x20, #0
    d6dc:      	ldr	x1, [sp, #0x88]
    d6e0:      	mov	x2, x0
    d6e4:      	mov	x0, x19
    d6e8:      	bl	0xd6e8 <_stogir.vector-lanes.operands+0x12c>
		000000000000d6e8:  ARM64_RELOC_BRANCH26	_memcmp
    d6ec:      	lsr	w0, w0, #0
    d6f0:      	sxtw	x0, w0
    d6f4:      	cmp	x0, #0x0
    d6f8:      	b.eq	0xd9a0 <_stogir.vector-lanes.operands+0x3e4>
    d6fc:      	mov	x1, x19
    d700:      	mov	x2, x20
    d704:      	mov	x0, #0x1                ; =1
    d708:      	b	0xd7b0 <_stogir.vector-lanes.operands+0x1f4>
    d70c:      	movz	x9, #0x0, lsl #48
    d710:      	b	0xd718 <_stogir.vector-lanes.operands+0x15c>
    d714:      	movz	x9, #0x0, lsl #48
    d718:      	cmp	x9, #0x0
    d71c:      	b.eq	0xd75c <_stogir.vector-lanes.operands+0x1a0>
    d720:      	uxtb	w16, w7
    d724:      	cmp	w16, wzr
    d728:      	b.eq	0xd740 <_stogir.vector-lanes.operands+0x184>
    d72c:      	lsl	x4, x4, #4
    d730:      	ldr	x7, [x0]
    d734:      	add	x4, x4, x7
    d738:      	ldr	x4, [x4]
    d73c:      	b	0xd750 <_stogir.vector-lanes.operands+0x194>
    d740:      	lsl	x4, x10, #4
    d744:      	ldr	x7, [x0, #0x28]
    d748:      	add	x4, x4, x7
    d74c:      	ldr	x4, [x4]
    d750:      	mov	x7, x4
    d754:      	mov	x4, #0x1                ; =1
    d758:      	b	0xd764 <_stogir.vector-lanes.operands+0x1a8>
    d75c:      	movz	x4, #0x0, lsl #48
    d760:      	movz	x7, #0x0, lsl #48
    d764:      	lsr	w4, w4, #0
    d768:      	lsr	x16, x4, #0
    d76c:      	cmp	x16, #0x1
    d770:      	b.eq	0xd78c <_stogir.vector-lanes.operands+0x1d0>
    d774:      	b.lo	0xd77c <_stogir.vector-lanes.operands+0x1c0>
    d778:      	b	0xd790 <_stogir.vector-lanes.operands+0x1d4>
    d77c:      	cmp	x16, #0x0
    d780:      	b.eq	0xd788 <_stogir.vector-lanes.operands+0x1cc>
    d784:      	b	0xd790 <_stogir.vector-lanes.operands+0x1d4>
    d788:      	b	0xd794 <_stogir.vector-lanes.operands+0x1d8>
    d78c:      	b	0xd7f8 <_stogir.vector-lanes.operands+0x23c>
    d790:      	b	0xddc4 <_stogir.vector-lanes.operands+0x808>
    d794:      	adrp	x16, 0xd000 <_stogir.floating.operands+0xe0>
		000000000000d794:  ARM64_RELOC_PAGE21	l_stogir.480
    d798:      	ldr	x16, [x16]
		000000000000d798:  ARM64_RELOC_PAGEOFF12	l_stogir.480
    d79c:      	orr	x0, x16, xzr
    d7a0:      	str	x8, [sp, #0xa0]
    d7a4:      	mov	x1, x0
    d7a8:      	mov	x0, #0x1                ; =1
    d7ac:      	mov	x2, #0x1b               ; =27
    d7b0:      	ldr	x3, [sp, #0xa0]
    d7b4:      	str	x0, [x3]
    d7b8:      	str	x1, [x3, #0x8]
    d7bc:      	str	x2, [x3, #0x10]
    d7c0:      	ldr	x19, [sp, #0xc8]
    d7c4:      	ldr	x20, [sp, #0xd0]
    d7c8:      	ldr	x21, [sp, #0xd8]
    d7cc:      	ldr	x22, [sp, #0xe0]
    d7d0:      	ldr	x23, [sp, #0xe8]
    d7d4:      	ldr	x24, [sp, #0xf0]
    d7d8:      	ldr	x25, [sp, #0xf8]
    d7dc:      	ldr	x26, [sp, #0x100]
    d7e0:      	ldr	x27, [sp, #0x108]
    d7e4:      	ldr	x28, [sp, #0x110]
    d7e8:      	ldr	x29, [sp]
    d7ec:      	ldr	x30, [sp, #0x8]
    d7f0:      	add	sp, sp, #0x120
    d7f4:      	ret
    d7f8:      	sxtw	x19, w1
    d7fc:      	sxtw	x1, w2
    d800:      	lsr	w4, w7, #0
    d804:      	ubfx	x4, x4, #8, #8
    d808:      	orr	x20, x4, xzr
    d80c:      	cmp	x19, #0x3d
    d810:      	b.ne	0xd824 <_stogir.vector-lanes.operands+0x268>
    d814:      	mov	x21, x20
    d818:      	b	0xd828 <_stogir.vector-lanes.operands+0x26c>
    d81c:      	movz	x9, #0x0, lsl #48
    d820:      	b	0xd710 <_stogir.vector-lanes.operands+0x154>
    d824:      	mov	x21, x1
    d828:      	cmp	x19, #0x3d
    d82c:      	b.eq	0xd834 <_stogir.vector-lanes.operands+0x278>
    d830:      	mov	x1, x20
    d834:      	adrp	x16, 0xd000 <_stogir.floating.operands+0xe0>
		000000000000d834:  ARM64_RELOC_PAGE21	l_stogir.481
    d838:      	ldr	x16, [x16]
		000000000000d838:  ARM64_RELOC_PAGEOFF12	l_stogir.481
    d83c:      	orr	x22, x16, xzr
    d840:      	lsr	w23, w21, #0
    d844:      	sxtw	x24, w23
    d848:      	cmp	x24, #0xf
    d84c:      	cset	w25, gt
    d850:      	cmp	x24, #0x80
    d854:      	cset	w26, lt
    d858:      	and	x4, x24, #0xf
    d85c:      	lsr	w4, w4, #0
    d860:      	sxtw	x4, w4
    d864:      	cmp	x4, #0x1
    d868:      	cset	w27, ge
    d86c:      	cmp	x4, #0xd
    d870:      	cset	w28, le
    d874:      	cmp	x19, #0x3d
    d878:      	b.lt	0xd8c8 <_stogir.vector-lanes.operands+0x30c>
    d87c:      	cmp	x19, #0x3f
    d880:      	b.gt	0xd8c8 <_stogir.vector-lanes.operands+0x30c>
    d884:      	uxtb	w16, w25
    d888:      	cmp	w16, wzr
    d88c:      	b.eq	0xd8c8 <_stogir.vector-lanes.operands+0x30c>
    d890:      	uxtb	w16, w26
    d894:      	cmp	w16, wzr
    d898:      	b.eq	0xd8c8 <_stogir.vector-lanes.operands+0x30c>
    d89c:      	uxtb	w16, w27
    d8a0:      	cmp	w16, wzr
    d8a4:      	b.eq	0xd8c8 <_stogir.vector-lanes.operands+0x30c>
    d8a8:      	uxtb	w16, w28
    d8ac:      	cmp	w16, wzr
    d8b0:      	b.eq	0xd8c8 <_stogir.vector-lanes.operands+0x30c>
    d8b4:      	sxtw	x4, w3
    d8b8:      	cmp	x4, #0x4
    d8bc:      	b.eq	0xdec4 <_stogir.vector-lanes.operands+0x908>
    d8c0:      	cmp	x4, #0x8
    d8c4:      	b.eq	0xdec4 <_stogir.vector-lanes.operands+0x908>
    d8c8:      	adrp	x16, 0xd000 <_stogir.floating.operands+0xe0>
		000000000000d8c8:  ARM64_RELOC_PAGE21	l_stogir.482
    d8cc:      	ldr	x16, [x16]
		000000000000d8cc:  ARM64_RELOC_PAGEOFF12	l_stogir.482
    d8d0:      	orr	x4, x16, xzr
    d8d4:      	mov	x7, #0x36               ; =54
    d8d8:      	sxtw	x9, w5
    d8dc:      	sxtw	x10, w6
    d8e0:      	cmp	x10, #0x0
    d8e4:      	cset	w10, eq
    d8e8:      	cmp	x19, #0x3f
    d8ec:      	b.ne	0xdf10 <_stogir.vector-lanes.operands+0x954>
    d8f0:      	lsr	w1, w1, #0
    d8f4:      	lsr	w3, w3, #0
    d8f8:      	mov	w0, w23
    d8fc:      	mov	w2, w3
    d900:      	mov	x19, x8
    d904:      	mov	x20, x4
    d908:      	mov	x23, x7
    d90c:      	mov	x24, x9
    d910:      	mov	w25, w10
    d914:      	bl	0xd914 <_stogir.vector-lanes.operands+0x358>
		000000000000d914:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.compatible?
    d918:      	cmp	x0, #0x0
    d91c:      	b.eq	0xda0c <_stogir.vector-lanes.operands+0x450>
    d920:      	mov	x1, x20
    d924:      	movz	x0, #0x0, lsl #48
    d928:      	b	0xda14 <_stogir.vector-lanes.operands+0x458>
    d92c:      	cmp	x19, #0x3d
    d930:      	b.ne	0xdf20 <_stogir.vector-lanes.operands+0x964>
    d934:      	lsr	w2, w2, #0
    d938:      	lsr	w3, w3, #0
    d93c:      	str	x0, [sp, #0x80]
    d940:      	mov	w0, w23
    d944:      	str	w3, [sp, #0xb8]
    d948:      	str	x1, [sp, #0xa0]
    d94c:      	mov	w1, w2
    d950:      	mov	w2, w3
    d954:      	str	x4, [sp, #0xa8]
    d958:      	str	x7, [sp, #0xb0]
    d95c:      	str	w9, [sp, #0xc0]
    d960:      	str	x22, [sp, #0x88]
    d964:      	mov	x22, x8
    d968:      	str	w23, [sp, #0x90]
    d96c:      	mov	w23, w5
    d970:      	str	x21, [sp, #0x98]
    d974:      	mov	w21, w6
    d978:      	bl	0xd978 <_stogir.vector-lanes.operands+0x3bc>
		000000000000d978:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.compatible?
    d97c:      	cmp	x0, #0x0
    d980:      	b.ne	0xda24 <_stogir.vector-lanes.operands+0x468>
    d984:      	adrp	x16, 0xd000 <_stogir.floating.operands+0xe0>
		000000000000d984:  ARM64_RELOC_PAGE21	l_stogir.483
    d988:      	ldr	x16, [x16]
		000000000000d988:  ARM64_RELOC_PAGEOFF12	l_stogir.483
    d98c:      	orr	x0, x16, xzr
    d990:      	mov	x1, #0x26               ; =38
    d994:      	b	0xda2c <_stogir.vector-lanes.operands+0x470>
    d998:      	movz	x9, #0x0, lsl #48
    d99c:      	b	0xd6a8 <_stogir.vector-lanes.operands+0xec>
    d9a0:      	ldr	x0, [sp, #0x98]
    d9a4:      	and	x0, x0, #0xffffffff
    d9a8:      	mov	x1, x0
    d9ac:      	movz	x0, #0x0, lsl #48
    d9b0:      	movz	x2, #0x0, lsl #48
    d9b4:      	b	0xd708 <_stogir.vector-lanes.operands+0x14c>
    d9b8:      	ldr	w0, [sp, #0xc0]
    d9bc:      	uxtb	w16, w0
    d9c0:      	cmp	w16, wzr
    d9c4:      	b.eq	0xdcc8 <_stogir.vector-lanes.operands+0x70c>
    d9c8:      	mov	x0, x20
    d9cc:      	mov	x1, x22
    d9d0:      	mov	x19, x0
    d9d4:      	mov	x20, x1
    d9d8:      	b	0xd6c8 <_stogir.vector-lanes.operands+0x10c>
    d9dc:      	cmp	x24, #0x0
    d9e0:      	b.ne	0xdbb8 <_stogir.vector-lanes.operands+0x5fc>
    d9e4:      	uxtb	w16, w25
    d9e8:      	cmp	w16, wzr
    d9ec:      	cset	x0, eq
    d9f0:      	cmp	x0, #0x0
    d9f4:      	b.eq	0xd6ac <_stogir.vector-lanes.operands+0xf0>
    d9f8:      	adrp	x16, 0xd000 <_stogir.floating.operands+0xe0>
		000000000000d9f8:  ARM64_RELOC_PAGE21	l_stogir.484
    d9fc:      	ldr	x16, [x16]
		000000000000d9fc:  ARM64_RELOC_PAGEOFF12	l_stogir.484
    da00:      	orr	x0, x16, xzr
    da04:      	mov	x1, #0x24               ; =36
    da08:      	b	0xd6b4 <_stogir.vector-lanes.operands+0xf8>
    da0c:      	mov	x1, x20
    da10:      	mov	x0, #0x1                ; =1
    da14:      	cmp	x0, #0x0
    da18:      	b.eq	0xd9dc <_stogir.vector-lanes.operands+0x420>
    da1c:      	mov	x0, #0x1                ; =1
    da20:      	b	0xd9f0 <_stogir.vector-lanes.operands+0x434>
    da24:      	ldr	x0, [sp, #0xa8]
    da28:      	ldr	x1, [sp, #0xb0]
    da2c:      	cmp	x19, #0x3e
    da30:      	b.ne	0xda60 <_stogir.vector-lanes.operands+0x4a4>
    da34:      	cmp	x20, x24
    da38:      	b.ne	0xda48 <_stogir.vector-lanes.operands+0x48c>
    da3c:      	mov	x2, x0
    da40:      	movz	x0, #0x0, lsl #48
    da44:      	b	0xda50 <_stogir.vector-lanes.operands+0x494>
    da48:      	mov	x2, x0
    da4c:      	mov	x0, #0x1                ; =1
    da50:      	fmov	d31, x1
    da54:      	mov	x1, x2
    da58:      	fmov	x2, d31
    da5c:      	b	0xda6c <_stogir.vector-lanes.operands+0x4b0>
    da60:      	mov	x2, x1
    da64:      	mov	x1, x0
    da68:      	movz	x0, #0x0, lsl #48
    da6c:      	cmp	x0, #0x0
    da70:      	b.eq	0xda8c <_stogir.vector-lanes.operands+0x4d0>
    da74:      	adrp	x16, 0xd000 <_stogir.floating.operands+0xe0>
		000000000000da74:  ARM64_RELOC_PAGE21	l_stogir.485
    da78:      	ldr	x16, [x16]
		000000000000da78:  ARM64_RELOC_PAGEOFF12	l_stogir.485
    da7c:      	orr	x0, x16, xzr
    da80:      	mov	x20, x0
    da84:      	mov	x0, #0x27               ; =39
    da88:      	b	0xda94 <_stogir.vector-lanes.operands+0x4d8>
    da8c:      	mov	x20, x1
    da90:      	mov	x0, x2
    da94:      	lsr	w23, w23, #0
    da98:      	add	x8, sp, #0x10
    da9c:      	mov	w1, w23
    daa0:      	mov	x23, x0
    daa4:      	ldr	x0, [sp, #0x80]
    daa8:      	bl	0xdaa8 <_stogir.vector-lanes.operands+0x4ec>
		000000000000daa8:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    daac:      	add	x16, sp, #0x10
    dab0:      	ldr	w0, [x16]
    dab4:      	lsr	x16, x0, #0
    dab8:      	cmp	x16, #0x1
    dabc:      	b.eq	0xdad8 <_stogir.vector-lanes.operands+0x51c>
    dac0:      	b.lo	0xdac8 <_stogir.vector-lanes.operands+0x50c>
    dac4:      	b	0xdadc <_stogir.vector-lanes.operands+0x520>
    dac8:      	cmp	x16, #0x0
    dacc:      	b.eq	0xdad4 <_stogir.vector-lanes.operands+0x518>
    dad0:      	b	0xdadc <_stogir.vector-lanes.operands+0x520>
    dad4:      	b	0xdae0 <_stogir.vector-lanes.operands+0x524>
    dad8:      	b	0xdb58 <_stogir.vector-lanes.operands+0x59c>
    dadc:      	b	0xdf00 <_stogir.vector-lanes.operands+0x944>
    dae0:      	adrp	x16, 0xd000 <_stogir.floating.operands+0xe0>
		000000000000dae0:  ARM64_RELOC_PAGE21	l_stogir.486
    dae4:      	ldr	x16, [x16]
		000000000000dae4:  ARM64_RELOC_PAGEOFF12	l_stogir.486
    dae8:      	orr	x0, x16, xzr
    daec:      	mov	x20, x0
    daf0:      	mov	x22, #0x19              ; =25
    daf4:      	cmp	x19, #0x3e
    daf8:      	b.ne	0xd9b8 <_stogir.vector-lanes.operands+0x3fc>
    dafc:      	lsr	w21, w21, #0
    db00:      	add	x8, sp, #0x50
    db04:      	ldr	x0, [sp, #0x80]
    db08:      	mov	w1, w21
    db0c:      	bl	0xdb0c <_stogir.vector-lanes.operands+0x550>
		000000000000db0c:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    db10:      	add	x16, sp, #0x50
    db14:      	ldr	w0, [x16]
    db18:      	lsr	x16, x0, #0
    db1c:      	cmp	x16, #0x1
    db20:      	b.eq	0xdb3c <_stogir.vector-lanes.operands+0x580>
    db24:      	b.lo	0xdb2c <_stogir.vector-lanes.operands+0x570>
    db28:      	b	0xdb40 <_stogir.vector-lanes.operands+0x584>
    db2c:      	cmp	x16, #0x0
    db30:      	b.eq	0xdb38 <_stogir.vector-lanes.operands+0x57c>
    db34:      	b	0xdb40 <_stogir.vector-lanes.operands+0x584>
    db38:      	b	0xdb44 <_stogir.vector-lanes.operands+0x588>
    db3c:      	b	0xdcdc <_stogir.vector-lanes.operands+0x720>
    db40:      	b	0xdf08 <_stogir.vector-lanes.operands+0x94c>
    db44:      	adrp	x16, 0xd000 <_stogir.floating.operands+0xe0>
		000000000000db44:  ARM64_RELOC_PAGE21	l_stogir.487
    db48:      	ldr	x16, [x16]
		000000000000db48:  ARM64_RELOC_PAGEOFF12	l_stogir.487
    db4c:      	orr	x0, x16, xzr
    db50:      	mov	x1, #0x20               ; =32
    db54:      	b	0xdbc8 <_stogir.vector-lanes.operands+0x60c>
    db58:      	add	x16, sp, #0x10
    db5c:      	orr	x0, x16, xzr
    db60:      	add	x0, x0, #0x8
    db64:      	add	x16, sp, #0x10
    db68:      	ldr	x1, [x16, #0x8]
    db6c:      	add	x16, sp, #0x40
    db70:      	str	x1, [x16]
    db74:      	lsr	w1, w1, #0
    db78:      	ldr	x0, [x0, #0x8]
    db7c:      	add	x16, sp, #0x40
    db80:      	str	x0, [x16, #0x8]
    db84:      	ubfx	x0, x1, #8, #8
    db88:      	cmp	x0, #0x1
    db8c:      	b.lt	0xdbcc <_stogir.vector-lanes.operands+0x610>
    db90:      	cmp	x0, #0xb
    db94:      	cset	w0, le
    db98:      	ubfx	x0, x0, #0, #8
    db9c:      	mov	x1, x20
    dba0:      	b	0xdbd4 <_stogir.vector-lanes.operands+0x618>
    dba4:      	mov	x0, x1
    dba8:      	mov	x1, x2
    dbac:      	mov	x20, x0
    dbb0:      	mov	x22, x1
    dbb4:      	b	0xdaf4 <_stogir.vector-lanes.operands+0x538>
    dbb8:      	mov	x0, #0x1                ; =1
    dbbc:      	b	0xd9f0 <_stogir.vector-lanes.operands+0x434>
    dbc0:      	mov	x0, x1
    dbc4:      	mov	x1, x22
    dbc8:      	b	0xd9d0 <_stogir.vector-lanes.operands+0x414>
    dbcc:      	mov	x1, x20
    dbd0:      	movz	x0, #0x0, lsl #48
    dbd4:      	cmp	x0, #0x0
    dbd8:      	b.eq	0xdbe4 <_stogir.vector-lanes.operands+0x628>
    dbdc:      	movz	x0, #0x0, lsl #48
    dbe0:      	b	0xdbe8 <_stogir.vector-lanes.operands+0x62c>
    dbe4:      	mov	x0, #0x1                ; =1
    dbe8:      	cmp	x0, #0x0
    dbec:      	b.eq	0xdc98 <_stogir.vector-lanes.operands+0x6dc>
    dbf0:      	mov	x0, #0x1                ; =1
    dbf4:      	b	0xdc20 <_stogir.vector-lanes.operands+0x664>
    dbf8:      	cmp	x0, #0x46
    dbfc:      	cset	w0, eq
    dc00:      	uxtb	w16, w0
    dc04:      	cmp	w16, wzr
    dc08:      	cset	x0, eq
    dc0c:      	cmp	x0, #0x0
    dc10:      	cset	w0, ne
    dc14:      	uxtb	w16, w0
    dc18:      	cmp	w16, wzr
    dc1c:      	cset	x0, eq
    dc20:      	cmp	x0, #0x0
    dc24:      	b.eq	0xdc3c <_stogir.vector-lanes.operands+0x680>
    dc28:      	adrp	x16, 0xd000 <_stogir.floating.operands+0xe0>
		000000000000dc28:  ARM64_RELOC_PAGE21	l_stogir.488
    dc2c:      	ldr	x16, [x16]
		000000000000dc2c:  ARM64_RELOC_PAGEOFF12	l_stogir.488
    dc30:      	orr	x0, x16, xzr
    dc34:      	mov	x1, #0x2b               ; =43
    dc38:      	b	0xdc44 <_stogir.vector-lanes.operands+0x688>
    dc3c:      	mov	x0, x1
    dc40:      	mov	x1, x23
    dc44:      	cmp	x22, #0x0
    dc48:      	b.ge	0xdc70 <_stogir.vector-lanes.operands+0x6b4>
    dc4c:      	add	x16, sp, #0x40
    dc50:      	ldr	w2, [x16]
    dc54:      	uxtb	w3, w2
    dc58:      	ubfx	x2, x2, #8, #8
    dc5c:      	cmp	x3, x2
    dc60:      	b.ne	0xdcfc <_stogir.vector-lanes.operands+0x740>
    dc64:      	mov	x2, x0
    dc68:      	mov	x0, #0x1                ; =1
    dc6c:      	b	0xdd14 <_stogir.vector-lanes.operands+0x758>
    dc70:      	mov	x2, x1
    dc74:      	mov	x1, x0
    dc78:      	movz	x0, #0x0, lsl #48
    dc7c:      	cmp	x0, #0x0
    dc80:      	b.eq	0xdba4 <_stogir.vector-lanes.operands+0x5e8>
    dc84:      	adrp	x16, 0xd000 <_stogir.floating.operands+0xe0>
		000000000000dc84:  ARM64_RELOC_PAGE21	l_stogir.489
    dc88:      	ldr	x16, [x16]
		000000000000dc88:  ARM64_RELOC_PAGEOFF12	l_stogir.489
    dc8c:      	orr	x0, x16, xzr
    dc90:      	mov	x1, #0x28               ; =40
    dc94:      	b	0xdbac <_stogir.vector-lanes.operands+0x5f0>
    dc98:      	add	x16, sp, #0x40
    dc9c:      	ldr	w0, [x16]
    dca0:      	uxtb	w0, w0
    dca4:      	cmp	x0, #0x48
    dca8:      	b.ne	0xdbf8 <_stogir.vector-lanes.operands+0x63c>
    dcac:      	movz	x0, #0x0, lsl #48
    dcb0:      	b	0xdc0c <_stogir.vector-lanes.operands+0x650>
    dcb4:      	fmov	d31, x1
    dcb8:      	mov	x1, x2
    dcbc:      	fmov	x2, d31
    dcc0:      	movz	x0, #0x0, lsl #48
    dcc4:      	b	0xdc7c <_stogir.vector-lanes.operands+0x6c0>
    dcc8:      	adrp	x16, 0xd000 <_stogir.floating.operands+0xe0>
		000000000000dcc8:  ARM64_RELOC_PAGE21	l_stogir.490
    dccc:      	ldr	x16, [x16]
		000000000000dccc:  ARM64_RELOC_PAGEOFF12	l_stogir.490
    dcd0:      	orr	x0, x16, xzr
    dcd4:      	mov	x1, #0x20               ; =32
    dcd8:      	b	0xd9d0 <_stogir.vector-lanes.operands+0x414>
    dcdc:      	add	x16, sp, #0x50
    dce0:      	ldr	x0, [x16, #0x8]
    dce4:      	uxtb	w1, w0
    dce8:      	cmp	x1, #0x48
    dcec:      	b.ne	0xde40 <_stogir.vector-lanes.operands+0x884>
    dcf0:      	mov	x2, x20
    dcf4:      	movz	x1, #0x0, lsl #48
    dcf8:      	b	0xde58 <_stogir.vector-lanes.operands+0x89c>
    dcfc:      	cmp	x3, #0x49
    dd00:      	cset	w2, eq
    dd04:      	ubfx	x2, x2, #0, #8
    dd08:      	fmov	d31, x0
    dd0c:      	mov	x0, x2
    dd10:      	fmov	x2, d31
    dd14:      	cmp	x0, #0x0
    dd18:      	b.eq	0xdcb4 <_stogir.vector-lanes.operands+0x6f8>
    dd1c:      	add	x16, sp, #0x40
    dd20:      	ldr	w0, [x16, #0x8]
    dd24:      	add	x16, sp, #0x40
    dd28:      	ldr	w3, [x16, #0xc]
    dd2c:      	uxtb	w16, w25
    dd30:      	cmp	w16, wzr
    dd34:      	b.eq	0xdd60 <_stogir.vector-lanes.operands+0x7a4>
    dd38:      	uxtb	w16, w26
    dd3c:      	cmp	w16, wzr
    dd40:      	b.eq	0xde94 <_stogir.vector-lanes.operands+0x8d8>
    dd44:      	uxtb	w16, w27
    dd48:      	cmp	w16, wzr
    dd4c:      	b.eq	0xdea8 <_stogir.vector-lanes.operands+0x8ec>
    dd50:      	ubfx	x28, x28, #0, #8
    dd54:      	mov	x4, x2
    dd58:      	mov	x2, x28
    dd5c:      	b	0xdeb0 <_stogir.vector-lanes.operands+0x8f4>
    dd60:      	mov	x4, x1
    dd64:      	movz	x1, #0x0, lsl #48
    dd68:      	cmp	x1, #0x0
    dd6c:      	b.eq	0xde6c <_stogir.vector-lanes.operands+0x8b0>
    dd70:      	ubfx	x1, x24, #4, #32
    dd74:      	sxtw	x1, w1
    dd78:      	sub	x1, x1, #0x1
    dd7c:      	lsr	w1, w1, #0
    dd80:      	sxtw	x1, w1
    dd84:      	mov	x16, #0x1               ; =1
    dd88:      	lsl	x1, x16, x1
    dd8c:      	lsr	w1, w1, #0
    dd90:      	sxtw	x1, w1
    dd94:      	ubfx	x0, x0, #0, #32
    dd98:      	ubfx	x3, x3, #0, #32
    dd9c:      	lsl	x3, x3, #32
    dda0:      	orr	x0, x3, x0
    dda4:      	lsr	w1, w1, #0
    dda8:      	sxtw	x1, w1
    ddac:      	cmp	x0, x1
    ddb0:      	cset	w0, hs
    ddb4:      	ubfx	x0, x0, #0, #8
    ddb8:      	mov	x1, x2
    ddbc:      	mov	x2, x4
    ddc0:      	b	0xdcc4 <_stogir.vector-lanes.operands+0x708>
    ddc4:      	brk	#0
    ddc8:      	b	0xddc4 <_stogir.vector-lanes.operands+0x808>
    ddcc:      	ldr	w1, [sp, #0xb8]
    ddd0:      	lsr	w1, w1, #0
    ddd4:      	lsr	w0, w0, #0
    ddd8:      	ubfx	x0, x0, #8, #8
    dddc:      	lsr	w0, w0, #0
    dde0:      	mov	w2, w1
    dde4:      	mov	w1, w0
    dde8:      	ldr	w0, [sp, #0x90]
    ddec:      	bl	0xddec <_stogir.vector-lanes.operands+0x830>
		000000000000ddec:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.compatible?
    ddf0:      	cmp	x0, #0x0
    ddf4:      	cset	w0, ne
    ddf8:      	uxtb	w16, w0
    ddfc:      	cmp	w16, wzr
    de00:      	cset	x0, eq
    de04:      	mov	x1, x19
    de08:      	cmp	x0, #0x0
    de0c:      	b.eq	0xdbc0 <_stogir.vector-lanes.operands+0x604>
    de10:      	adrp	x16, 0xd000 <_stogir.floating.operands+0xe0>
		000000000000de10:  ARM64_RELOC_PAGE21	l_stogir.491
    de14:      	ldr	x16, [x16]
		000000000000de14:  ARM64_RELOC_PAGEOFF12	l_stogir.491
    de18:      	orr	x0, x16, xzr
    de1c:      	mov	x1, #0x27               ; =39
    de20:      	b	0xdbc8 <_stogir.vector-lanes.operands+0x60c>
    de24:      	mov	x19, x2
    de28:      	mov	x1, #0x1                ; =1
    de2c:      	cmp	x1, #0x0
    de30:      	b.eq	0xddcc <_stogir.vector-lanes.operands+0x810>
    de34:      	mov	x1, x19
    de38:      	mov	x0, #0x1                ; =1
    de3c:      	b	0xde08 <_stogir.vector-lanes.operands+0x84c>
    de40:      	cmp	x1, #0x46
    de44:      	cset	w1, eq
    de48:      	uxtb	w16, w1
    de4c:      	cmp	w16, wzr
    de50:      	cset	x1, eq
    de54:      	mov	x2, x20
    de58:      	cmp	x1, #0x0
    de5c:      	b.eq	0xde24 <_stogir.vector-lanes.operands+0x868>
    de60:      	mov	x19, x2
    de64:      	movz	x1, #0x0, lsl #48
    de68:      	b	0xde2c <_stogir.vector-lanes.operands+0x870>
    de6c:      	cmp	x24, #0x0
    de70:      	b.lt	0xdea0 <_stogir.vector-lanes.operands+0x8e4>
    de74:      	cmp	x24, #0xd
    de78:      	b.gt	0xdea0 <_stogir.vector-lanes.operands+0x8e4>
    de7c:      	cmp	x24, #0x0
    de80:      	cset	w1, eq
    de84:      	uxtb	w16, w1
    de88:      	cmp	w16, wzr
    de8c:      	cset	x1, eq
    de90:      	b	0xdea4 <_stogir.vector-lanes.operands+0x8e8>
    de94:      	mov	x4, x1
    de98:      	movz	x1, #0x0, lsl #48
    de9c:      	b	0xdd68 <_stogir.vector-lanes.operands+0x7ac>
    dea0:      	movn	x1, #0x0, lsl #48
    dea4:      	b	0xdd94 <_stogir.vector-lanes.operands+0x7d8>
    dea8:      	mov	x4, x2
    deac:      	movz	x2, #0x0, lsl #48
    deb0:      	fmov	d31, x1
    deb4:      	mov	x1, x2
    deb8:      	mov	x2, x4
    debc:      	fmov	x4, d31
    dec0:      	b	0xde9c <_stogir.vector-lanes.operands+0x8e0>
    dec4:      	uxtb	w7, w7
    dec8:      	cmp	x7, #0x48
    decc:      	b.ne	0xded8 <_stogir.vector-lanes.operands+0x91c>
    ded0:      	movz	x4, #0x0, lsl #48
    ded4:      	b	0xdeec <_stogir.vector-lanes.operands+0x930>
    ded8:      	cmp	x7, #0x46
    dedc:      	cset	w4, eq
    dee0:      	uxtb	w16, w4
    dee4:      	cmp	w16, wzr
    dee8:      	cset	x4, eq
    deec:      	cmp	x4, #0x0
    def0:      	b.eq	0xd8c8 <_stogir.vector-lanes.operands+0x30c>
    def4:      	mov	x4, x22
    def8:      	movz	x7, #0x0, lsl #48
    defc:      	b	0xd8d8 <_stogir.vector-lanes.operands+0x31c>
    df00:      	brk	#0
    df04:      	b	0xdf00 <_stogir.vector-lanes.operands+0x944>
    df08:      	brk	#0
    df0c:      	b	0xdf08 <_stogir.vector-lanes.operands+0x94c>
    df10:      	mov	x1, x8
    df14:      	mov	x8, x9
    df18:      	mov	w9, w10
    df1c:      	b	0xd92c <_stogir.vector-lanes.operands+0x370>
    df20:      	str	x21, [sp, #0x98]
    df24:      	str	x1, [sp, #0xa0]
    df28:      	str	x0, [sp, #0x80]
    df2c:      	str	w3, [sp, #0xb8]
    df30:      	mov	w21, w6
    df34:      	str	x22, [sp, #0x88]
    df38:      	mov	x22, x8
    df3c:      	str	w23, [sp, #0x90]
    df40:      	mov	w23, w5
    df44:      	str	w9, [sp, #0xc0]
    df48:      	str	x4, [sp, #0xa8]
    df4c:      	str	x7, [sp, #0xb0]
    df50:      	b	0xda24 <_stogir.vector-lanes.operands+0x468>

000000000000df54 <_stogir.vector-comparison.operation?>:
    df54:      	sxtw	x0, w0
    df58:      	cmp	x0, #0xe
    df5c:      	b.lt	0xdf70 <_stogir.vector-comparison.operation?+0x1c>
    df60:      	cmp	x0, #0x19
    df64:      	cset	w0, le
    df68:      	ubfx	x0, x0, #0, #8
    df6c:      	b	0xdf74 <_stogir.vector-comparison.operation?+0x20>
    df70:      	movz	x0, #0x0, lsl #48
    df74:      	ret

000000000000df78 <_stogir.vector-comparison.operands>:
    df78:      	sub	sp, sp, #0xe0
    df7c:      	str	x29, [sp]
    df80:      	str	x30, [sp, #0x8]
    df84:      	mov	x29, sp
    df88:      	str	x19, [sp, #0x90]
    df8c:      	str	x20, [sp, #0x98]
    df90:      	str	x21, [sp, #0xa0]
    df94:      	str	x22, [sp, #0xa8]
    df98:      	str	x23, [sp, #0xb0]
    df9c:      	str	x24, [sp, #0xb8]
    dfa0:      	str	x25, [sp, #0xc0]
    dfa4:      	str	x26, [sp, #0xc8]
    dfa8:      	str	x27, [sp, #0xd0]
    dfac:      	str	x28, [sp, #0xd8]
    dfb0:      	adrp	x16, 0xd000 <_stogir.floating.operands+0xe0>
		000000000000dfb0:  ARM64_RELOC_PAGE21	l_stogir.492
    dfb4:      	ldr	x16, [x16]
		000000000000dfb4:  ARM64_RELOC_PAGEOFF12	l_stogir.492
    dfb8:      	orr	x19, x16, xzr
    dfbc:      	lsr	w4, w4, #0
    dfc0:      	mov	x20, x8
    dfc4:      	add	x8, sp, #0x10
    dfc8:      	mov	x21, x0
    dfcc:      	mov	w22, w1
    dfd0:      	mov	w1, w4
    dfd4:      	mov	w23, w2
    dfd8:      	mov	w24, w3
    dfdc:      	mov	w25, w5
    dfe0:      	bl	0xdfe0 <_stogir.vector-comparison.operands+0x68>
		000000000000dfe0:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    dfe4:      	add	x16, sp, #0x10
    dfe8:      	ldr	w0, [x16]
    dfec:      	lsr	x16, x0, #0
    dff0:      	cmp	x16, #0x1
    dff4:      	b.eq	0xe010 <_stogir.vector-comparison.operands+0x98>
    dff8:      	b.lo	0xe000 <_stogir.vector-comparison.operands+0x88>
    dffc:      	b	0xe014 <_stogir.vector-comparison.operands+0x9c>
    e000:      	cmp	x16, #0x0
    e004:      	b.eq	0xe00c <_stogir.vector-comparison.operands+0x94>
    e008:      	b	0xe014 <_stogir.vector-comparison.operands+0x9c>
    e00c:      	b	0xe018 <_stogir.vector-comparison.operands+0xa0>
    e010:      	b	0xe068 <_stogir.vector-comparison.operands+0xf0>
    e014:      	b	0xe218 <_stogir.vector-comparison.operands+0x2a0>
    e018:      	mov	x1, x19
    e01c:      	mov	x0, #0x1                ; =1
    e020:      	mov	x2, #0x21               ; =33
    e024:      	str	x0, [x20]
    e028:      	str	x1, [x20, #0x8]
    e02c:      	str	x2, [x20, #0x10]
    e030:      	ldr	x19, [sp, #0x90]
    e034:      	ldr	x20, [sp, #0x98]
    e038:      	ldr	x21, [sp, #0xa0]
    e03c:      	ldr	x22, [sp, #0xa8]
    e040:      	ldr	x23, [sp, #0xb0]
    e044:      	ldr	x24, [sp, #0xb8]
    e048:      	ldr	x25, [sp, #0xc0]
    e04c:      	ldr	x26, [sp, #0xc8]
    e050:      	ldr	x27, [sp, #0xd0]
    e054:      	ldr	x28, [sp, #0xd8]
    e058:      	ldr	x29, [sp]
    e05c:      	ldr	x30, [sp, #0x8]
    e060:      	add	sp, sp, #0xe0
    e064:      	ret
    e068:      	lsr	w25, w25, #0
    e06c:      	add	x16, sp, #0x10
    e070:      	ldr	x26, [x16, #0x8]
    e074:      	add	x8, sp, #0x40
    e078:      	mov	x0, x21
    e07c:      	mov	w1, w25
    e080:      	bl	0xe080 <_stogir.vector-comparison.operands+0x108>
		000000000000e080:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    e084:      	add	x16, sp, #0x40
    e088:      	ldr	w0, [x16]
    e08c:      	lsr	x16, x0, #0
    e090:      	cmp	x16, #0x1
    e094:      	b.eq	0xe0b0 <_stogir.vector-comparison.operands+0x138>
    e098:      	b.lo	0xe0a0 <_stogir.vector-comparison.operands+0x128>
    e09c:      	b	0xe0b4 <_stogir.vector-comparison.operands+0x13c>
    e0a0:      	cmp	x16, #0x0
    e0a4:      	b.eq	0xe0ac <_stogir.vector-comparison.operands+0x134>
    e0a8:      	b	0xe0b4 <_stogir.vector-comparison.operands+0x13c>
    e0ac:      	b	0xe0b8 <_stogir.vector-comparison.operands+0x140>
    e0b0:      	b	0xe0c8 <_stogir.vector-comparison.operands+0x150>
    e0b4:      	b	0xe220 <_stogir.vector-comparison.operands+0x2a8>
    e0b8:      	mov	x1, x19
    e0bc:      	mov	x0, #0x1                ; =1
    e0c0:      	mov	x2, #0x21               ; =33
    e0c4:      	b	0xe024 <_stogir.vector-comparison.operands+0xac>
    e0c8:      	sxtw	x19, w24
    e0cc:      	cmp	x19, #0x4
    e0d0:      	cset	w21, eq
    e0d4:      	cmp	x19, #0x8
    e0d8:      	cset	w25, eq
    e0dc:      	add	x16, sp, #0x40
    e0e0:      	ldr	x27, [x16, #0x8]
    e0e4:      	uxtb	w16, w21
    e0e8:      	cmp	w16, wzr
    e0ec:      	b.ne	0xe118 <_stogir.vector-comparison.operands+0x1a0>
    e0f0:      	uxtb	w16, w25
    e0f4:      	cmp	w16, wzr
    e0f8:      	b.ne	0xe118 <_stogir.vector-comparison.operands+0x1a0>
    e0fc:      	adrp	x16, 0xe000 <_stogir.vector-comparison.operands+0x88>
		000000000000e0fc:  ARM64_RELOC_PAGE21	l_stogir.493
    e100:      	ldr	x16, [x16]
		000000000000e100:  ARM64_RELOC_PAGEOFF12	l_stogir.493
    e104:      	orr	x0, x16, xzr
    e108:      	mov	x1, x0
    e10c:      	mov	x0, #0x1                ; =1
    e110:      	mov	x2, #0x33               ; =51
    e114:      	b	0xe0c4 <_stogir.vector-comparison.operands+0x14c>
    e118:      	lsr	w22, w22, #0
    e11c:      	lsr	w0, w26, #0
    e120:      	ubfx	x28, x0, #8, #8
    e124:      	orr	x0, x28, xzr
    e128:      	lsr	w0, w0, #0
    e12c:      	mov	w1, w0
    e130:      	fmov	s31, w0
    e134:      	mov	w0, w22
    e138:      	fmov	w22, s31
    e13c:      	bl	0xe13c <_stogir.vector-comparison.operands+0x1c4>
		000000000000e13c:  ARM64_RELOC_BRANCH26	_stogir.vector-comparison.valid-type?
    e140:      	cmp	x0, #0x0
    e144:      	b.eq	0xe0fc <_stogir.vector-comparison.operands+0x184>
    e148:      	lsr	w0, w27, #0
    e14c:      	ubfx	x0, x0, #8, #8
    e150:      	cmp	x28, x0
    e154:      	b.ne	0xe0fc <_stogir.vector-comparison.operands+0x184>
    e158:      	uxtb	w26, w26
    e15c:      	cmp	x26, #0x48
    e160:      	b.eq	0xe0fc <_stogir.vector-comparison.operands+0x184>
    e164:      	cmp	x26, #0x46
    e168:      	b.eq	0xe0fc <_stogir.vector-comparison.operands+0x184>
    e16c:      	uxtb	w27, w27
    e170:      	cmp	x27, #0x48
    e174:      	b.eq	0xe0fc <_stogir.vector-comparison.operands+0x184>
    e178:      	cmp	x27, #0x46
    e17c:      	b.eq	0xe0fc <_stogir.vector-comparison.operands+0x184>
    e180:      	sxtw	x26, w23
    e184:      	cmp	x26, #0xf
    e188:      	cset	w27, gt
    e18c:      	uxtb	w16, w27
    e190:      	cmp	w16, wzr
    e194:      	b.eq	0xe0fc <_stogir.vector-comparison.operands+0x184>
    e198:      	cmp	x26, #0x80
    e19c:      	cset	w0, lt
    e1a0:      	uxtb	w16, w0
    e1a4:      	cmp	w16, wzr
    e1a8:      	b.eq	0xe0fc <_stogir.vector-comparison.operands+0x184>
    e1ac:      	and	x1, x26, #0xf
    e1b0:      	lsr	w1, w1, #0
    e1b4:      	sxtw	x1, w1
    e1b8:      	cmp	x1, #0x1
    e1bc:      	cset	w2, ge
    e1c0:      	uxtb	w16, w2
    e1c4:      	cmp	w16, wzr
    e1c8:      	b.eq	0xe0fc <_stogir.vector-comparison.operands+0x184>
    e1cc:      	cmp	x1, #0xd
    e1d0:      	cset	w3, le
    e1d4:      	uxtb	w16, w3
    e1d8:      	cmp	w16, wzr
    e1dc:      	b.eq	0xe0fc <_stogir.vector-comparison.operands+0x184>
    e1e0:      	lsr	w23, w23, #0
    e1e4:      	str	x1, [sp, #0x78]
    e1e8:      	str	x19, [sp, #0x70]
    e1ec:      	mov	w19, w0
    e1f0:      	mov	w0, w23
    e1f4:      	str	w22, [sp, #0x80]
    e1f8:      	mov	w22, w2
    e1fc:      	str	w23, [sp, #0x88]
    e200:      	mov	w23, w3
    e204:      	bl	0xe204 <_stogir.vector-comparison.operands+0x28c>
		000000000000e204:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
    e208:      	cmp	x0, #0x0
    e20c:      	b.eq	0xe228 <_stogir.vector-comparison.operands+0x2b0>
    e210:      	ldr	x0, [sp, #0x78]
    e214:      	b	0xe22c <_stogir.vector-comparison.operands+0x2b4>
    e218:      	brk	#0
    e21c:      	b	0xe218 <_stogir.vector-comparison.operands+0x2a0>
    e220:      	brk	#0
    e224:      	b	0xe220 <_stogir.vector-comparison.operands+0x2a8>
    e228:      	movn	x0, #0x0, lsl #48
    e22c:      	lsr	w0, w0, #0
    e230:      	sxtw	x0, w0
    e234:      	cmp	x0, #0x1
    e238:      	b.lt	0xe0fc <_stogir.vector-comparison.operands+0x184>
    e23c:      	cmp	x0, #0xb
    e240:      	b.gt	0xe0fc <_stogir.vector-comparison.operands+0x184>
    e244:      	uxtb	w16, w27
    e248:      	cmp	w16, wzr
    e24c:      	b.eq	0xe2d0 <_stogir.vector-comparison.operands+0x358>
    e250:      	uxtb	w16, w19
    e254:      	cmp	w16, wzr
    e258:      	b.eq	0xe2d0 <_stogir.vector-comparison.operands+0x358>
    e25c:      	uxtb	w16, w22
    e260:      	cmp	w16, wzr
    e264:      	b.eq	0xe2d0 <_stogir.vector-comparison.operands+0x358>
    e268:      	uxtb	w16, w23
    e26c:      	cmp	w16, wzr
    e270:      	b.eq	0xe2d0 <_stogir.vector-comparison.operands+0x358>
    e274:      	ubfx	x0, x26, #4, #32
    e278:      	sxtw	x0, w0
    e27c:      	sub	x0, x0, #0x1
    e280:      	lsr	w0, w0, #0
    e284:      	sxtw	x0, w0
    e288:      	mov	x16, #0x1               ; =1
    e28c:      	lsl	x0, x16, x0
    e290:      	lsr	w0, w0, #0
    e294:      	sxtw	x0, w0
    e298:      	b	0xe2fc <_stogir.vector-comparison.operands+0x384>
    e29c:      	movn	x1, #0x0, lsl #48
    e2a0:      	lsr	w0, w0, #0
    e2a4:      	sxtw	x0, w0
    e2a8:      	lsr	w1, w1, #0
    e2ac:      	sxtw	x1, w1
    e2b0:      	cmp	x0, x1
    e2b4:      	b.ne	0xe0fc <_stogir.vector-comparison.operands+0x184>
    e2b8:      	ldr	w0, [sp, #0x88]
    e2bc:      	bl	0xe2bc <_stogir.vector-comparison.operands+0x344>
		000000000000e2bc:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
    e2c0:      	cmp	x0, #0x0
    e2c4:      	b.eq	0xe3b4 <_stogir.vector-comparison.operands+0x43c>
    e2c8:      	ldr	x0, [sp, #0x78]
    e2cc:      	b	0xe3b8 <_stogir.vector-comparison.operands+0x440>
    e2d0:      	cmp	x26, #0x0
    e2d4:      	b.lt	0xe2f8 <_stogir.vector-comparison.operands+0x380>
    e2d8:      	cmp	x26, #0xd
    e2dc:      	b.gt	0xe2f8 <_stogir.vector-comparison.operands+0x380>
    e2e0:      	cmp	x26, #0x0
    e2e4:      	cset	w0, eq
    e2e8:      	uxtb	w16, w0
    e2ec:      	cmp	w16, wzr
    e2f0:      	cset	x0, eq
    e2f4:      	b	0xe2fc <_stogir.vector-comparison.operands+0x384>
    e2f8:      	movn	x0, #0x0, lsl #48
    e2fc:      	and	x1, x28, #0xf
    e300:      	lsr	w1, w1, #0
    e304:      	sxtw	x19, w1
    e308:      	cmp	x28, #0xf
    e30c:      	b.le	0xe350 <_stogir.vector-comparison.operands+0x3d8>
    e310:      	cmp	x28, #0x80
    e314:      	b.ge	0xe350 <_stogir.vector-comparison.operands+0x3d8>
    e318:      	cmp	x19, #0x1
    e31c:      	b.lt	0xe350 <_stogir.vector-comparison.operands+0x3d8>
    e320:      	cmp	x19, #0xd
    e324:      	b.gt	0xe350 <_stogir.vector-comparison.operands+0x3d8>
    e328:      	ubfx	x1, x28, #4, #32
    e32c:      	sxtw	x1, w1
    e330:      	sub	x1, x1, #0x1
    e334:      	lsr	w1, w1, #0
    e338:      	sxtw	x1, w1
    e33c:      	mov	x16, #0x1               ; =1
    e340:      	lsl	x1, x16, x1
    e344:      	lsr	w1, w1, #0
    e348:      	sxtw	x1, w1
    e34c:      	b	0xe2a0 <_stogir.vector-comparison.operands+0x328>
    e350:      	cmp	x28, #0xd
    e354:      	b.gt	0xe29c <_stogir.vector-comparison.operands+0x324>
    e358:      	cmp	x28, #0x0
    e35c:      	cset	w1, eq
    e360:      	uxtb	w16, w1
    e364:      	cmp	w16, wzr
    e368:      	cset	x1, eq
    e36c:      	b	0xe2a0 <_stogir.vector-comparison.operands+0x328>
    e370:      	movn	x0, #0x0, lsl #48
    e374:      	lsr	w24, w24, #0
    e378:      	lsr	w21, w21, #0
    e37c:      	sxtw	x21, w21
    e380:      	lsr	w0, w0, #0
    e384:      	lsr	w0, w0, #0
    e388:      	mov	w1, w24
    e38c:      	bl	0xe38c <_stogir.vector-comparison.operands+0x414>
		000000000000e38c:  ARM64_RELOC_BRANCH26	_stogir.types.scalar-size
    e390:      	lsr	w0, w0, #0
    e394:      	sxtw	x0, w0
    e398:      	cmp	x21, x0
    e39c:      	b.ne	0xe0fc <_stogir.vector-comparison.operands+0x184>
    e3a0:      	and	x0, x28, #0xffffffff
    e3a4:      	mov	x1, x0
    e3a8:      	movz	x0, #0x0, lsl #48
    e3ac:      	movz	x2, #0x0, lsl #48
    e3b0:      	b	0xe114 <_stogir.vector-comparison.operands+0x19c>
    e3b4:      	movn	x0, #0x0, lsl #48
    e3b8:      	uxtb	w16, w21
    e3bc:      	cmp	w16, wzr
    e3c0:      	b.ne	0xe3f8 <_stogir.vector-comparison.operands+0x480>
    e3c4:      	uxtb	w16, w25
    e3c8:      	cmp	w16, wzr
    e3cc:      	b.ne	0xe3f8 <_stogir.vector-comparison.operands+0x480>
    e3d0:      	movn	x21, #0x0, lsl #48
    e3d4:      	b	0xe3e0 <_stogir.vector-comparison.operands+0x468>
    e3d8:      	mov	x0, #0x1                ; =1
    e3dc:      	mov	x21, x0
    e3e0:      	ldr	w0, [sp, #0x80]
    e3e4:      	bl	0xe3e4 <_stogir.vector-comparison.operands+0x46c>
		000000000000e3e4:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
    e3e8:      	cmp	x0, #0x0
    e3ec:      	b.eq	0xe370 <_stogir.vector-comparison.operands+0x3f8>
    e3f0:      	mov	x0, x19
    e3f4:      	b	0xe374 <_stogir.vector-comparison.operands+0x3fc>
    e3f8:      	lsr	w0, w0, #0
    e3fc:      	sxtw	x0, w0
    e400:      	cmp	x0, #0x0
    e404:      	b.ne	0xe410 <_stogir.vector-comparison.operands+0x498>
    e408:      	movz	x0, #0x0, lsl #48
    e40c:      	b	0xe3dc <_stogir.vector-comparison.operands+0x464>
    e410:      	cmp	x0, #0x1
    e414:      	b.eq	0xe3d8 <_stogir.vector-comparison.operands+0x460>
    e418:      	cmp	x0, #0x2
    e41c:      	b.eq	0xe3d8 <_stogir.vector-comparison.operands+0x460>
    e420:      	cmp	x0, #0x7
    e424:      	b.eq	0xe3d8 <_stogir.vector-comparison.operands+0x460>
    e428:      	cmp	x0, #0x8
    e42c:      	b.eq	0xe3d8 <_stogir.vector-comparison.operands+0x460>
    e430:      	cmp	x0, #0x3
    e434:      	b.eq	0xe480 <_stogir.vector-comparison.operands+0x508>
    e438:      	cmp	x0, #0x9
    e43c:      	b.eq	0xe480 <_stogir.vector-comparison.operands+0x508>
    e440:      	cmp	x0, #0x4
    e444:      	b.eq	0xe488 <_stogir.vector-comparison.operands+0x510>
    e448:      	cmp	x0, #0xa
    e44c:      	b.eq	0xe488 <_stogir.vector-comparison.operands+0x510>
    e450:      	cmp	x0, #0xd
    e454:      	b.eq	0xe488 <_stogir.vector-comparison.operands+0x510>
    e458:      	cmp	x0, #0x5
    e45c:      	b.eq	0xe490 <_stogir.vector-comparison.operands+0x518>
    e460:      	cmp	x0, #0xb
    e464:      	b.eq	0xe490 <_stogir.vector-comparison.operands+0x518>
    e468:      	cmp	x0, #0xc
    e46c:      	b.eq	0xe490 <_stogir.vector-comparison.operands+0x518>
    e470:      	cmp	x0, #0x6
    e474:      	b.ne	0xe498 <_stogir.vector-comparison.operands+0x520>
    e478:      	ldr	x0, [sp, #0x70]
    e47c:      	b	0xe49c <_stogir.vector-comparison.operands+0x524>
    e480:      	mov	x0, #0x2                ; =2
    e484:      	b	0xe3dc <_stogir.vector-comparison.operands+0x464>
    e488:      	mov	x0, #0x4                ; =4
    e48c:      	b	0xe484 <_stogir.vector-comparison.operands+0x50c>
    e490:      	mov	x0, #0x8                ; =8
    e494:      	b	0xe48c <_stogir.vector-comparison.operands+0x514>
    e498:      	movn	x0, #0x0, lsl #48
    e49c:      	b	0xe494 <_stogir.vector-comparison.operands+0x51c>

000000000000e4a0 <_stogir.vector-arithmetic.operation?>:
    e4a0:      	sxtw	x0, w0
    e4a4:      	cmp	x0, #0x1f
    e4a8:      	b.eq	0xe504 <_stogir.vector-arithmetic.operation?+0x64>
    e4ac:      	cmp	x0, #0x20
    e4b0:      	b.eq	0xe504 <_stogir.vector-arithmetic.operation?+0x64>
    e4b4:      	cmp	x0, #0x2d
    e4b8:      	b.eq	0xe504 <_stogir.vector-arithmetic.operation?+0x64>
    e4bc:      	cmp	x0, #0x36
    e4c0:      	b.eq	0xe504 <_stogir.vector-arithmetic.operation?+0x64>
    e4c4:      	cmp	x0, #0x37
    e4c8:      	b.eq	0xe504 <_stogir.vector-arithmetic.operation?+0x64>
    e4cc:      	cmp	x0, #0x38
    e4d0:      	b.eq	0xe504 <_stogir.vector-arithmetic.operation?+0x64>
    e4d4:      	cmp	x0, #0x39
    e4d8:      	b.eq	0xe504 <_stogir.vector-arithmetic.operation?+0x64>
    e4dc:      	cmp	x0, #0x3a
    e4e0:      	b.eq	0xe50c <_stogir.vector-arithmetic.operation?+0x6c>
    e4e4:      	cmp	x0, #0x3b
    e4e8:      	b.eq	0xe50c <_stogir.vector-arithmetic.operation?+0x6c>
    e4ec:      	cmp	x0, #0x31
    e4f0:      	b.lt	0xe524 <_stogir.vector-arithmetic.operation?+0x84>
    e4f4:      	cmp	x0, #0x35
    e4f8:      	b.gt	0xe524 <_stogir.vector-arithmetic.operation?+0x84>
    e4fc:      	mov	x0, #0x1                ; =1
    e500:      	b	0xe520 <_stogir.vector-arithmetic.operation?+0x80>
    e504:      	mov	x0, #0x1                ; =1
    e508:      	ret
    e50c:      	mov	x0, #0x1                ; =1
    e510:      	b	0xe508 <_stogir.vector-arithmetic.operation?+0x68>
    e514:      	cmp	x0, #0x30
    e518:      	cset	w0, eq
    e51c:      	ubfx	x0, x0, #0, #8
    e520:      	b	0xe510 <_stogir.vector-arithmetic.operation?+0x70>
    e524:      	cmp	x0, #0x1a
    e528:      	b.ne	0xe534 <_stogir.vector-arithmetic.operation?+0x94>
    e52c:      	mov	x0, #0x1                ; =1
    e530:      	b	0xe520 <_stogir.vector-arithmetic.operation?+0x80>
    e534:      	cmp	x0, #0x1b
    e538:      	b.ne	0xe544 <_stogir.vector-arithmetic.operation?+0xa4>
    e53c:      	mov	x0, #0x1                ; =1
    e540:      	b	0xe520 <_stogir.vector-arithmetic.operation?+0x80>
    e544:      	cmp	x0, #0x1c
    e548:      	b.ne	0xe554 <_stogir.vector-arithmetic.operation?+0xb4>
    e54c:      	mov	x0, #0x1                ; =1
    e550:      	b	0xe520 <_stogir.vector-arithmetic.operation?+0x80>
    e554:      	cmp	x0, #0x1d
    e558:      	b.ne	0xe564 <_stogir.vector-arithmetic.operation?+0xc4>
    e55c:      	mov	x0, #0x1                ; =1
    e560:      	b	0xe520 <_stogir.vector-arithmetic.operation?+0x80>
    e564:      	cmp	x0, #0x1e
    e568:      	b.ne	0xe574 <_stogir.vector-arithmetic.operation?+0xd4>
    e56c:      	mov	x0, #0x1                ; =1
    e570:      	b	0xe520 <_stogir.vector-arithmetic.operation?+0x80>
    e574:      	cmp	x0, #0x2e
    e578:      	b.ne	0xe584 <_stogir.vector-arithmetic.operation?+0xe4>
    e57c:      	mov	x0, #0x1                ; =1
    e580:      	b	0xe520 <_stogir.vector-arithmetic.operation?+0x80>
    e584:      	cmp	x0, #0x2f
    e588:      	b.ne	0xe514 <_stogir.vector-arithmetic.operation?+0x74>
    e58c:      	mov	x0, #0x1                ; =1
    e590:      	b	0xe520 <_stogir.vector-arithmetic.operation?+0x80>

000000000000e594 <_stogir.vector-arithmetic.unary?>:
    e594:      	sxtw	x0, w0
    e598:      	cmp	x0, #0x1f
    e59c:      	b.ne	0xe5b8 <_stogir.vector-arithmetic.unary?+0x24>
    e5a0:      	mov	x0, #0x1                ; =1
    e5a4:      	b	0xe5b4 <_stogir.vector-arithmetic.unary?+0x20>
    e5a8:      	cmp	x0, #0x39
    e5ac:      	cset	w0, eq
    e5b0:      	ubfx	x0, x0, #0, #8
    e5b4:      	ret
    e5b8:      	cmp	x0, #0x20
    e5bc:      	b.ne	0xe5c8 <_stogir.vector-arithmetic.unary?+0x34>
    e5c0:      	mov	x0, #0x1                ; =1
    e5c4:      	b	0xe5b4 <_stogir.vector-arithmetic.unary?+0x20>
    e5c8:      	cmp	x0, #0x2d
    e5cc:      	b.ne	0xe5d8 <_stogir.vector-arithmetic.unary?+0x44>
    e5d0:      	mov	x0, #0x1                ; =1
    e5d4:      	b	0xe5b4 <_stogir.vector-arithmetic.unary?+0x20>
    e5d8:      	cmp	x0, #0x36
    e5dc:      	b.ne	0xe5e8 <_stogir.vector-arithmetic.unary?+0x54>
    e5e0:      	mov	x0, #0x1                ; =1
    e5e4:      	b	0xe5b4 <_stogir.vector-arithmetic.unary?+0x20>
    e5e8:      	cmp	x0, #0x37
    e5ec:      	b.ne	0xe5f8 <_stogir.vector-arithmetic.unary?+0x64>
    e5f0:      	mov	x0, #0x1                ; =1
    e5f4:      	b	0xe5b4 <_stogir.vector-arithmetic.unary?+0x20>
    e5f8:      	cmp	x0, #0x38
    e5fc:      	b.ne	0xe5a8 <_stogir.vector-arithmetic.unary?+0x14>
    e600:      	mov	x0, #0x1                ; =1
    e604:      	b	0xe5b4 <_stogir.vector-arithmetic.unary?+0x20>

000000000000e608 <_stogir.vector-arithmetic.operands>:
    e608:      	sub	sp, sp, #0xc0
    e60c:      	str	x29, [sp]
    e610:      	str	x30, [sp, #0x8]
    e614:      	mov	x29, sp
    e618:      	str	x19, [sp, #0x68]
    e61c:      	str	x20, [sp, #0x70]
    e620:      	str	x21, [sp, #0x78]
    e624:      	str	x22, [sp, #0x80]
    e628:      	str	x23, [sp, #0x88]
    e62c:      	str	x24, [sp, #0x90]
    e630:      	str	x25, [sp, #0x98]
    e634:      	str	x26, [sp, #0xa0]
    e638:      	str	x27, [sp, #0xa8]
    e63c:      	str	x28, [sp, #0xb0]
    e640:      	adrp	x16, 0xe000 <_stogir.vector-comparison.operands+0x88>
		000000000000e640:  ARM64_RELOC_PAGE21	l_stogir.494
    e644:      	ldr	x16, [x16]
		000000000000e644:  ARM64_RELOC_PAGEOFF12	l_stogir.494
    e648:      	orr	x19, x16, xzr
    e64c:      	lsr	w1, w1, #0
    e650:      	lsr	w2, w2, #0
    e654:      	mov	x20, x8
    e658:      	mov	x21, x0
    e65c:      	mov	w0, w1
    e660:      	mov	w22, w1
    e664:      	mov	w1, w2
    e668:      	mov	w23, w2
    e66c:      	mov	w24, w3
    e670:      	mov	w25, w4
    e674:      	mov	w26, w5
    e678:      	bl	0xe678 <_stogir.vector-arithmetic.operands+0x70>
		000000000000e678:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.valid-type?
    e67c:      	cmp	x0, #0x0
    e680:      	b.eq	0xe690 <_stogir.vector-arithmetic.operands+0x88>
    e684:      	mov	x0, x19
    e688:      	movz	x1, #0x0, lsl #48
    e68c:      	b	0xe6a0 <_stogir.vector-arithmetic.operands+0x98>
    e690:      	adrp	x16, 0xe000 <_stogir.vector-comparison.operands+0x88>
		000000000000e690:  ARM64_RELOC_PAGE21	l_stogir.495
    e694:      	ldr	x16, [x16]
		000000000000e694:  ARM64_RELOC_PAGEOFF12	l_stogir.495
    e698:      	orr	x0, x16, xzr
    e69c:      	mov	x1, #0x37               ; =55
    e6a0:      	sxtw	x22, w22
    e6a4:      	sxtw	x23, w23
    e6a8:      	sxtw	x24, w24
    e6ac:      	sxtw	x25, w25
    e6b0:      	adrp	x16, 0xe000 <_stogir.vector-comparison.operands+0x88>
		000000000000e6b0:  ARM64_RELOC_PAGE21	l_stogir.496
    e6b4:      	ldr	x16, [x16]
		000000000000e6b4:  ARM64_RELOC_PAGEOFF12	l_stogir.496
    e6b8:      	orr	x2, x16, xzr
    e6bc:      	adrp	x16, 0xe000 <_stogir.vector-comparison.operands+0x88>
		000000000000e6bc:  ARM64_RELOC_PAGE21	l_stogir.497
    e6c0:      	ldr	x16, [x16]
		000000000000e6c0:  ARM64_RELOC_PAGEOFF12	l_stogir.497
    e6c4:      	orr	x3, x16, xzr
    e6c8:      	add	x4, x21, #0x78
    e6cc:      	add	x5, x21, #0x28
    e6d0:      	add	x6, x21, #0x50
    e6d4:      	cmp	x22, #0x31
    e6d8:      	cset	w7, ge
    e6dc:      	cmp	x22, #0x35
    e6e0:      	cset	w8, le
    e6e4:      	cmp	x22, #0x1f
    e6e8:      	cset	w9, eq
    e6ec:      	cmp	x22, #0x20
    e6f0:      	cset	w10, eq
    e6f4:      	cmp	x22, #0x2d
    e6f8:      	cset	w11, eq
    e6fc:      	cmp	x22, #0x36
    e700:      	cset	w12, eq
    e704:      	cmp	x22, #0x37
    e708:      	cset	w13, eq
    e70c:      	cmp	x22, #0x38
    e710:      	cset	w14, eq
    e714:      	cmp	x22, #0x39
    e718:      	cset	w15, eq
    e71c:      	ubfx	x15, x15, #0, #8
    e720:      	mov	x27, x1
    e724:      	mov	x1, x0
    e728:      	movz	x0, #0x0, lsl #48
    e72c:      	b	0xe80c <_stogir.vector-arithmetic.operands+0x204>
    e730:      	movz	x3, #0x0, lsl #48
    e734:      	b	0xe744 <_stogir.vector-arithmetic.operands+0x13c>
    e738:      	movz	x3, #0x0, lsl #48
    e73c:      	b	0xe74c <_stogir.vector-arithmetic.operands+0x144>
    e740:      	movz	x3, #0x0, lsl #48
    e744:      	b	0xe758 <_stogir.vector-arithmetic.operands+0x150>
    e748:      	movz	x3, #0x0, lsl #48
    e74c:      	str	x5, [sp, #0x60]
    e750:      	b	0xe758 <_stogir.vector-arithmetic.operands+0x150>
    e754:      	movz	x3, #0x0, lsl #48
    e758:      	cmp	x3, #0x0
    e75c:      	b.eq	0xe79c <_stogir.vector-arithmetic.operands+0x194>
    e760:      	uxtb	w16, w2
    e764:      	cmp	w16, wzr
    e768:      	b.eq	0xe780 <_stogir.vector-arithmetic.operands+0x178>
    e76c:      	lsl	x1, x1, #4
    e770:      	ldr	x2, [x21]
    e774:      	add	x1, x1, x2
    e778:      	ldr	x1, [x1]
    e77c:      	b	0xe790 <_stogir.vector-arithmetic.operands+0x188>
    e780:      	lsl	x1, x9, #4
    e784:      	ldr	x2, [x21, #0x28]
    e788:      	add	x1, x1, x2
    e78c:      	ldr	x1, [x1]
    e790:      	mov	x2, x1
    e794:      	mov	x1, #0x1                ; =1
    e798:      	b	0xe7a4 <_stogir.vector-arithmetic.operands+0x19c>
    e79c:      	movz	x1, #0x0, lsl #48
    e7a0:      	movz	x2, #0x0, lsl #48
    e7a4:      	lsr	w1, w1, #0
    e7a8:      	lsr	x16, x1, #0
    e7ac:      	cmp	x16, #0x1
    e7b0:      	b.eq	0xe7cc <_stogir.vector-arithmetic.operands+0x1c4>
    e7b4:      	b.lo	0xe7bc <_stogir.vector-arithmetic.operands+0x1b4>
    e7b8:      	b	0xe7d0 <_stogir.vector-arithmetic.operands+0x1c8>
    e7bc:      	cmp	x16, #0x0
    e7c0:      	b.eq	0xe7c8 <_stogir.vector-arithmetic.operands+0x1c0>
    e7c4:      	b	0xe7d0 <_stogir.vector-arithmetic.operands+0x1c8>
    e7c8:      	b	0xe7d4 <_stogir.vector-arithmetic.operands+0x1cc>
    e7cc:      	b	0xe93c <_stogir.vector-arithmetic.operands+0x334>
    e7d0:      	b	0xeb88 <_stogir.vector-arithmetic.operands+0x580>
    e7d4:      	ldr	x1, [sp, #0x40]
    e7d8:      	mov	x2, #0x21               ; =33
    e7dc:      	b	0xe7e8 <_stogir.vector-arithmetic.operands+0x1e0>
    e7e0:      	ldr	x1, [sp, #0x48]
    e7e4:      	mov	x2, #0x32               ; =50
    e7e8:      	add	x0, x0, #0x1
    e7ec:      	lsr	w0, w0, #0
    e7f0:      	sxtw	x0, w0
    e7f4:      	ldr	x3, [sp, #0x48]
    e7f8:      	ldr	w9, [sp, #0x50]
    e7fc:      	ldr	x4, [sp, #0x58]
    e800:      	ldr	x5, [sp, #0x60]
    e804:      	mov	x27, x2
    e808:      	ldr	x2, [sp, #0x40]
    e80c:      	uxtb	w16, w9
    e810:      	cmp	w16, wzr
    e814:      	b.eq	0xe868 <_stogir.vector-arithmetic.operands+0x260>
    e818:      	mov	x28, x27
    e81c:      	mov	x27, x1
    e820:      	mov	x1, #0x1                ; =1
    e824:      	b	0xe83c <_stogir.vector-arithmetic.operands+0x234>
    e828:      	mov	x28, x15
    e82c:      	fmov	d31, x1
    e830:      	mov	x1, x28
    e834:      	mov	x28, x27
    e838:      	fmov	x27, d31
    e83c:      	cmp	x1, #0x0
    e840:      	b.eq	0xe84c <_stogir.vector-arithmetic.operands+0x244>
    e844:      	mov	x1, #0x1                ; =1
    e848:      	b	0xe850 <_stogir.vector-arithmetic.operands+0x248>
    e84c:      	mov	x1, #0x2                ; =2
    e850:      	cmp	x0, x1
    e854:      	b.ge	0xe9c4 <_stogir.vector-arithmetic.operands+0x3bc>
    e858:      	cmp	x0, #0x0
    e85c:      	b.ne	0xe87c <_stogir.vector-arithmetic.operands+0x274>
    e860:      	mov	x1, x24
    e864:      	b	0xe880 <_stogir.vector-arithmetic.operands+0x278>
    e868:      	uxtb	w16, w10
    e86c:      	cmp	w16, wzr
    e870:      	b.eq	0xe99c <_stogir.vector-arithmetic.operands+0x394>
    e874:      	mov	x28, #0x1               ; =1
    e878:      	b	0xe82c <_stogir.vector-arithmetic.operands+0x224>
    e87c:      	mov	x1, x25
    e880:      	lsr	w1, w1, #0
    e884:      	sxtw	x1, w1
    e888:      	str	x2, [sp, #0x40]
    e88c:      	cmp	x1, #0x0
    e890:      	cset	w2, gt
    e894:      	str	x3, [sp, #0x48]
    e898:      	movz	x16, #0x0, lsl #48
    e89c:      	sub	x3, x16, x1
    e8a0:      	str	w9, [sp, #0x50]
    e8a4:      	sub	x9, x3, #0x1
    e8a8:      	uxtb	w16, w2
    e8ac:      	cmp	w16, wzr
    e8b0:      	b.eq	0xec48 <_stogir.vector-arithmetic.operands+0x640>
    e8b4:      	ldr	x3, [x21, #0x8]
    e8b8:      	cmp	x1, x3
    e8bc:      	b.ge	0xec50 <_stogir.vector-arithmetic.operands+0x648>
    e8c0:      	ldr	x3, [x4, #0x8]
    e8c4:      	cmp	x1, x3
    e8c8:      	b.ge	0xec58 <_stogir.vector-arithmetic.operands+0x650>
    e8cc:      	lsl	x3, x1, #2
    e8d0:      	str	x4, [sp, #0x58]
    e8d4:      	ldr	x4, [x21, #0x78]
    e8d8:      	add	x3, x3, x4
    e8dc:      	ldr	w3, [x3]
    e8e0:      	sxtw	x3, w3
    e8e4:      	cmp	x3, #0x0
    e8e8:      	cset	w3, ge
    e8ec:      	ubfx	x3, x3, #0, #8
    e8f0:      	b	0xe73c <_stogir.vector-arithmetic.operands+0x134>
    e8f4:      	cmp	x1, #0x0
    e8f8:      	b.ge	0xec60 <_stogir.vector-arithmetic.operands+0x658>
    e8fc:      	ldr	x4, [x5, #0x8]
    e900:      	str	x5, [sp, #0x60]
    e904:      	ldr	x5, [x6, #0x8]
    e908:      	cmp	x4, x5
    e90c:      	b.ne	0xe740 <_stogir.vector-arithmetic.operands+0x138>
    e910:      	cmp	x3, x4
    e914:      	b.gt	0xe730 <_stogir.vector-arithmetic.operands+0x128>
    e918:      	lsl	x3, x9, #2
    e91c:      	ldr	x4, [x21, #0x50]
    e920:      	add	x3, x3, x4
    e924:      	ldr	w3, [x3]
    e928:      	sxtw	x3, w3
    e92c:      	cmp	x3, #0x0
    e930:      	cset	w3, gt
    e934:      	ubfx	x3, x3, #0, #8
    e938:      	b	0xe734 <_stogir.vector-arithmetic.operands+0x12c>
    e93c:      	lsr	w1, w2, #0
    e940:      	ubfx	x1, x1, #8, #8
    e944:      	cmp	x1, x23
    e948:      	b.eq	0xe97c <_stogir.vector-arithmetic.operands+0x374>
    e94c:      	cmp	x0, #0x1
    e950:      	b.ne	0xe7e0 <_stogir.vector-arithmetic.operands+0x1d8>
    e954:      	uxtb	w16, w7
    e958:      	cmp	w16, wzr
    e95c:      	b.eq	0xe7e0 <_stogir.vector-arithmetic.operands+0x1d8>
    e960:      	uxtb	w16, w8
    e964:      	cmp	w16, wzr
    e968:      	b.eq	0xe7e0 <_stogir.vector-arithmetic.operands+0x1d8>
    e96c:      	cmp	x1, #0x1
    e970:      	b.lt	0xe7e0 <_stogir.vector-arithmetic.operands+0x1d8>
    e974:      	cmp	x1, #0xb
    e978:      	b.gt	0xe7e0 <_stogir.vector-arithmetic.operands+0x1d8>
    e97c:      	uxtb	w2, w2
    e980:      	cmp	x2, #0x48
    e984:      	b.eq	0xe7e0 <_stogir.vector-arithmetic.operands+0x1d8>
    e988:      	cmp	x2, #0x46
    e98c:      	b.eq	0xe7e0 <_stogir.vector-arithmetic.operands+0x1d8>
    e990:      	mov	x1, x27
    e994:      	mov	x2, x28
    e998:      	b	0xe7e8 <_stogir.vector-arithmetic.operands+0x1e0>
    e99c:      	uxtb	w16, w11
    e9a0:      	cmp	w16, wzr
    e9a4:      	b.eq	0xe9b0 <_stogir.vector-arithmetic.operands+0x3a8>
    e9a8:      	mov	x28, #0x1               ; =1
    e9ac:      	b	0xe82c <_stogir.vector-arithmetic.operands+0x224>
    e9b0:      	uxtb	w16, w12
    e9b4:      	cmp	w16, wzr
    e9b8:      	b.eq	0xe9e0 <_stogir.vector-arithmetic.operands+0x3d8>
    e9bc:      	mov	x28, #0x1               ; =1
    e9c0:      	b	0xe82c <_stogir.vector-arithmetic.operands+0x224>
    e9c4:      	sxtw	x24, w26
    e9c8:      	cmp	x24, #0x0
    e9cc:      	b.ne	0xe9f4 <_stogir.vector-arithmetic.operands+0x3ec>
    e9d0:      	mov	x1, x27
    e9d4:      	mov	x2, x28
    e9d8:      	movz	x0, #0x0, lsl #48
    e9dc:      	b	0xea00 <_stogir.vector-arithmetic.operands+0x3f8>
    e9e0:      	uxtb	w16, w13
    e9e4:      	cmp	w16, wzr
    e9e8:      	b.eq	0xeae8 <_stogir.vector-arithmetic.operands+0x4e0>
    e9ec:      	mov	x28, #0x1               ; =1
    e9f0:      	b	0xe82c <_stogir.vector-arithmetic.operands+0x224>
    e9f4:      	mov	x1, x27
    e9f8:      	mov	x2, x28
    e9fc:      	mov	x0, #0x1                ; =1
    ea00:      	cmp	x0, #0x0
    ea04:      	b.eq	0xea18 <_stogir.vector-arithmetic.operands+0x410>
    ea08:      	cmp	x22, #0x1d
    ea0c:      	b.ne	0xeb58 <_stogir.vector-arithmetic.operands+0x550>
    ea10:      	mov	x0, #0x1                ; =1
    ea14:      	b	0xeb64 <_stogir.vector-arithmetic.operands+0x55c>
    ea18:      	mov	x21, x1
    ea1c:      	mov	x22, x2
    ea20:      	cmp	x22, #0x0
    ea24:      	b.ne	0xea54 <_stogir.vector-arithmetic.operands+0x44c>
    ea28:      	cmp	x22, #0x0
    ea2c:      	b.eq	0xead4 <_stogir.vector-arithmetic.operands+0x4cc>
    ea30:      	lsr	x0, x22, #0
    ea34:      	mov	x1, x19
    ea38:      	mov	x2, x0
    ea3c:      	mov	x0, x21
    ea40:      	bl	0xea40 <_stogir.vector-arithmetic.operands+0x438>
		000000000000ea40:  ARM64_RELOC_BRANCH26	_memcmp
    ea44:      	lsr	w0, w0, #0
    ea48:      	sxtw	x0, w0
    ea4c:      	cmp	x0, #0x0
    ea50:      	b.eq	0xead4 <_stogir.vector-arithmetic.operands+0x4cc>
    ea54:      	mov	x1, x21
    ea58:      	mov	x2, x22
    ea5c:      	mov	x0, #0x1                ; =1
    ea60:      	str	x0, [x20]
    ea64:      	str	x1, [x20, #0x8]
    ea68:      	str	x2, [x20, #0x10]
    ea6c:      	ldr	x19, [sp, #0x68]
    ea70:      	ldr	x20, [sp, #0x70]
    ea74:      	ldr	x21, [sp, #0x78]
    ea78:      	ldr	x22, [sp, #0x80]
    ea7c:      	ldr	x23, [sp, #0x88]
    ea80:      	ldr	x24, [sp, #0x90]
    ea84:      	ldr	x25, [sp, #0x98]
    ea88:      	ldr	x26, [sp, #0xa0]
    ea8c:      	ldr	x27, [sp, #0xa8]
    ea90:      	ldr	x28, [sp, #0xb0]
    ea94:      	ldr	x29, [sp]
    ea98:      	ldr	x30, [sp, #0x8]
    ea9c:      	add	sp, sp, #0xc0
    eaa0:      	ret
    eaa4:      	mov	x22, x1
    eaa8:      	mov	x25, x2
    eaac:      	mov	x0, #0x1                ; =1
    eab0:      	cmp	x0, #0x0
    eab4:      	b.eq	0xeafc <_stogir.vector-arithmetic.operands+0x4f4>
    eab8:      	adrp	x16, 0xe000 <_stogir.vector-comparison.operands+0x88>
		000000000000eab8:  ARM64_RELOC_PAGE21	l_stogir.498
    eabc:      	ldr	x16, [x16]
		000000000000eabc:  ARM64_RELOC_PAGEOFF12	l_stogir.498
    eac0:      	orr	x0, x16, xzr
    eac4:      	mov	x1, #0x23               ; =35
    eac8:      	mov	x21, x0
    eacc:      	mov	x22, x1
    ead0:      	b	0xea20 <_stogir.vector-arithmetic.operands+0x418>
    ead4:      	and	x0, x23, #0xffffffff
    ead8:      	mov	x1, x0
    eadc:      	movz	x0, #0x0, lsl #48
    eae0:      	movz	x2, #0x0, lsl #48
    eae4:      	b	0xea60 <_stogir.vector-arithmetic.operands+0x458>
    eae8:      	uxtb	w16, w14
    eaec:      	cmp	w16, wzr
    eaf0:      	b.eq	0xe828 <_stogir.vector-arithmetic.operands+0x220>
    eaf4:      	mov	x28, #0x1               ; =1
    eaf8:      	b	0xe82c <_stogir.vector-arithmetic.operands+0x224>
    eafc:      	lsr	w26, w26, #0
    eb00:      	add	x8, sp, #0x10
    eb04:      	mov	x0, x21
    eb08:      	mov	w1, w26
    eb0c:      	bl	0xeb0c <_stogir.vector-arithmetic.operands+0x504>
		000000000000eb0c:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    eb10:      	add	x16, sp, #0x10
    eb14:      	ldr	w0, [x16]
    eb18:      	lsr	x16, x0, #0
    eb1c:      	cmp	x16, #0x1
    eb20:      	b.eq	0xeb3c <_stogir.vector-arithmetic.operands+0x534>
    eb24:      	b.lo	0xeb2c <_stogir.vector-arithmetic.operands+0x524>
    eb28:      	b	0xeb40 <_stogir.vector-arithmetic.operands+0x538>
    eb2c:      	cmp	x16, #0x0
    eb30:      	b.eq	0xeb38 <_stogir.vector-arithmetic.operands+0x530>
    eb34:      	b	0xeb40 <_stogir.vector-arithmetic.operands+0x538>
    eb38:      	b	0xeb44 <_stogir.vector-arithmetic.operands+0x53c>
    eb3c:      	b	0xeb90 <_stogir.vector-arithmetic.operands+0x588>
    eb40:      	b	0xec40 <_stogir.vector-arithmetic.operands+0x638>
    eb44:      	adrp	x16, 0xe000 <_stogir.vector-comparison.operands+0x88>
		000000000000eb44:  ARM64_RELOC_PAGE21	l_stogir.499
    eb48:      	ldr	x16, [x16]
		000000000000eb48:  ARM64_RELOC_PAGEOFF12	l_stogir.499
    eb4c:      	orr	x0, x16, xzr
    eb50:      	mov	x1, #0x1d               ; =29
    eb54:      	b	0xeb84 <_stogir.vector-arithmetic.operands+0x57c>
    eb58:      	cmp	x22, #0x1e
    eb5c:      	cset	w0, eq
    eb60:      	ubfx	x0, x0, #0, #8
    eb64:      	cmp	x0, #0x0
    eb68:      	b.eq	0xeaa4 <_stogir.vector-arithmetic.operands+0x49c>
    eb6c:      	mov	x22, x1
    eb70:      	mov	x25, x2
    eb74:      	movz	x0, #0x0, lsl #48
    eb78:      	b	0xeab0 <_stogir.vector-arithmetic.operands+0x4a8>
    eb7c:      	mov	x0, x1
    eb80:      	mov	x1, x2
    eb84:      	b	0xeac8 <_stogir.vector-arithmetic.operands+0x4c0>
    eb88:      	brk	#0
    eb8c:      	b	0xeb88 <_stogir.vector-arithmetic.operands+0x580>
    eb90:      	add	x16, sp, #0x10
    eb94:      	ldr	x0, [x16, #0x8]
    eb98:      	cmp	x24, #0x0
    eb9c:      	b.gt	0xebd8 <_stogir.vector-arithmetic.operands+0x5d0>
    eba0:      	mov	x1, x22
    eba4:      	mov	x2, x25
    eba8:      	mov	x0, #0x1                ; =1
    ebac:      	b	0xebbc <_stogir.vector-arithmetic.operands+0x5b4>
    ebb0:      	movz	x0, #0x0, lsl #48
    ebb4:      	mov	x1, x22
    ebb8:      	mov	x2, x25
    ebbc:      	cmp	x0, #0x0
    ebc0:      	b.eq	0xeb7c <_stogir.vector-arithmetic.operands+0x574>
    ebc4:      	adrp	x16, 0xe000 <_stogir.vector-comparison.operands+0x88>
		000000000000ebc4:  ARM64_RELOC_PAGE21	l_stogir.500
    ebc8:      	ldr	x16, [x16]
		000000000000ebc8:  ARM64_RELOC_PAGEOFF12	l_stogir.500
    ebcc:      	orr	x0, x16, xzr
    ebd0:      	mov	x1, #0x34               ; =52
    ebd4:      	b	0xeb84 <_stogir.vector-arithmetic.operands+0x57c>
    ebd8:      	uxtb	w0, w0
    ebdc:      	cmp	x0, #0x83
    ebe0:      	b.ge	0xebfc <_stogir.vector-arithmetic.operands+0x5f4>
    ebe4:      	adrp	x16, 0xe000 <_stogir.vector-comparison.operands+0x88>
		000000000000ebe4:  ARM64_RELOC_PAGE21	l_stogir.501
    ebe8:      	ldr	x16, [x16]
		000000000000ebe8:  ARM64_RELOC_PAGEOFF12	l_stogir.501
    ebec:      	orr	x1, x16, xzr
    ebf0:      	add	x1, x0, x1
    ebf4:      	ldrb	w1, [x1]
    ebf8:      	b	0xec00 <_stogir.vector-arithmetic.operands+0x5f8>
    ebfc:      	movz	x1, #0x0, lsl #48
    ec00:      	uxtb	w1, w1
    ec04:      	and	x1, x1, #0x2
    ec08:      	uxtb	w1, w1
    ec0c:      	cmp	x1, #0x0
    ec10:      	cset	w1, eq
    ec14:      	uxtb	w16, w1
    ec18:      	cmp	w16, wzr
    ec1c:      	cset	x1, eq
    ec20:      	cmp	x1, #0x0
    ec24:      	b.ne	0xebb0 <_stogir.vector-arithmetic.operands+0x5a8>
    ec28:      	cmp	x0, #0x65
    ec2c:      	b.eq	0xebb0 <_stogir.vector-arithmetic.operands+0x5a8>
    ec30:      	cmp	x0, #0x66
    ec34:      	b.eq	0xebb0 <_stogir.vector-arithmetic.operands+0x5a8>
    ec38:      	mov	x0, #0x1                ; =1
    ec3c:      	b	0xebb4 <_stogir.vector-arithmetic.operands+0x5ac>
    ec40:      	brk	#0
    ec44:      	b	0xec40 <_stogir.vector-arithmetic.operands+0x638>
    ec48:      	str	x4, [sp, #0x58]
    ec4c:      	b	0xe8f4 <_stogir.vector-arithmetic.operands+0x2ec>
    ec50:      	str	x4, [sp, #0x58]
    ec54:      	b	0xe748 <_stogir.vector-arithmetic.operands+0x140>
    ec58:      	str	x4, [sp, #0x58]
    ec5c:      	b	0xe738 <_stogir.vector-arithmetic.operands+0x130>
    ec60:      	str	x5, [sp, #0x60]
    ec64:      	b	0xe754 <_stogir.vector-arithmetic.operands+0x14c>

000000000000ec68 <_stogir.types.base-type>:
    ec68:      	sub	sp, sp, #0x20
    ec6c:      	str	x29, [sp]
    ec70:      	str	x30, [sp, #0x8]
    ec74:      	mov	x29, sp
    ec78:      	str	x19, [sp, #0x10]
    ec7c:      	lsr	w0, w0, #0
    ec80:      	mov	w19, w0
    ec84:      	bl	0xec84 <_stogir.types.base-type+0x1c>
		000000000000ec84:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
    ec88:      	cmp	x0, #0x0
    ec8c:      	b.eq	0xeca4 <_stogir.types.base-type+0x3c>
    ec90:      	sxtw	x19, w19
    ec94:      	and	x0, x19, #0xf
    ec98:      	lsr	w0, w0, #0
    ec9c:      	sxtw	x0, w0
    eca0:      	b	0xeca8 <_stogir.types.base-type+0x40>
    eca4:      	movn	x0, #0x0, lsl #48
    eca8:      	ldr	x19, [sp, #0x10]
    ecac:      	ldr	x29, [sp]
    ecb0:      	ldr	x30, [sp, #0x8]
    ecb4:      	add	sp, sp, #0x20
    ecb8:      	ret

000000000000ecbc <_stogir.types.lanes>:
    ecbc:      	sxtw	x0, w0
    ecc0:      	cmp	x0, #0xf
    ecc4:      	b.le	0xed14 <_stogir.types.lanes+0x58>
    ecc8:      	cmp	x0, #0x80
    eccc:      	b.ge	0xed14 <_stogir.types.lanes+0x58>
    ecd0:      	and	x1, x0, #0xf
    ecd4:      	lsr	w1, w1, #0
    ecd8:      	sxtw	x1, w1
    ecdc:      	cmp	x1, #0x1
    ece0:      	b.lt	0xed14 <_stogir.types.lanes+0x58>
    ece4:      	cmp	x1, #0xd
    ece8:      	b.gt	0xed14 <_stogir.types.lanes+0x58>
    ecec:      	ubfx	x0, x0, #4, #32
    ecf0:      	sxtw	x0, w0
    ecf4:      	sub	x0, x0, #0x1
    ecf8:      	lsr	w0, w0, #0
    ecfc:      	sxtw	x0, w0
    ed00:      	mov	x16, #0x1               ; =1
    ed04:      	lsl	x0, x16, x0
    ed08:      	lsr	w0, w0, #0
    ed0c:      	sxtw	x0, w0
    ed10:      	b	0xed40 <_stogir.types.lanes+0x84>
    ed14:      	cmp	x0, #0x0
    ed18:      	b.lt	0xed3c <_stogir.types.lanes+0x80>
    ed1c:      	cmp	x0, #0xd
    ed20:      	b.gt	0xed3c <_stogir.types.lanes+0x80>
    ed24:      	cmp	x0, #0x0
    ed28:      	cset	w0, eq
    ed2c:      	uxtb	w16, w0
    ed30:      	cmp	w16, wzr
    ed34:      	cset	x0, eq
    ed38:      	b	0xed40 <_stogir.types.lanes+0x84>
    ed3c:      	movn	x0, #0x0, lsl #48
    ed40:      	ret

000000000000ed44 <_coil.core.Get$slice$get__u8>:
    ed44:      	lsr	x1, x2, #0
    ed48:      	add	x0, x1, x0
    ed4c:      	ldrb	w0, [x0]
    ed50:      	ret

000000000000ed54 <_stogir.checked.valid-type?>:
    ed54:      	sxtw	x0, w0
    ed58:      	cmp	x0, #0x1
    ed5c:      	b.lt	0xed80 <_stogir.checked.valid-type?+0x2c>
    ed60:      	cmp	x0, #0xb
    ed64:      	b.gt	0xed80 <_stogir.checked.valid-type?+0x2c>
    ed68:      	cmp	x0, #0x1
    ed6c:      	cset	w0, eq
    ed70:      	uxtb	w16, w0
    ed74:      	cmp	w16, wzr
    ed78:      	cset	x0, eq
    ed7c:      	b	0xed84 <_stogir.checked.valid-type?+0x30>
    ed80:      	movz	x0, #0x0, lsl #48
    ed84:      	ret

000000000000ed88 <_coil.core.Iterable$slice$iter__i32>:
    ed88:      	str	x0, [x8]
    ed8c:      	str	x1, [x8, #0x8]
    ed90:      	movz	x17, #0x0, lsl #48
    ed94:      	str	x17, [x8, #0x10]
    ed98:      	ret

000000000000ed9c <_coil.core.Iterator$coil.slice.SliceIter$next__i32>:
    ed9c:      	sub	sp, sp, #0x10
    eda0:      	mov	x1, sp
    eda4:      	ldr	x2, [x0, #0x10]
    eda8:      	ldr	x3, [x0]
    edac:      	ldr	x4, [x0, #0x8]
    edb0:      	cmp	x2, x4
    edb4:      	b.ge	0xede0 <_coil.core.Iterator$coil.slice.SliceIter$next__i32+0x44>
    edb8:      	add	x4, x2, #0x1
    edbc:      	lsl	x2, x2, #2
    edc0:      	add	x2, x2, x3
    edc4:      	str	x4, [x0, #0x10]
    edc8:      	ldr	w0, [x2]
    edcc:      	sxtw	x0, w0
    edd0:      	and	x0, x0, #0xffffffff
    edd4:      	mov	x2, x0
    edd8:      	mov	x0, #0x1                ; =1
    eddc:      	b	0xede8 <_coil.core.Iterator$coil.slice.SliceIter$next__i32+0x4c>
    ede0:      	movz	x0, #0x0, lsl #48
    ede4:      	movz	x2, #0x0, lsl #48
    ede8:      	str	x0, [x1]
    edec:      	str	x2, [x1, #0x8]
    edf0:      	ldr	x0, [sp]
    edf4:      	ldr	x1, [sp, #0x8]
    edf8:      	add	sp, sp, #0x10
    edfc:      	ret

000000000000ee00 <_stogir.terminal.previous-input>:
    ee00:      	sxtw	x1, w1
    ee04:      	cmp	x1, #0x0
    ee08:      	b.ne	0xee28 <_stogir.terminal.previous-input+0x28>
    ee0c:      	movz	x0, #0x0, lsl #48
    ee10:      	movz	x1, #0x0, lsl #48
    ee14:      	movz	x2, #0x0, lsl #48
    ee18:      	str	x0, [x8]
    ee1c:      	str	x1, [x8, #0x8]
    ee20:      	str	x2, [x8, #0x10]
    ee24:      	ret
    ee28:      	cmp	x1, #0x0
    ee2c:      	cset	w2, gt
    ee30:      	movz	x16, #0x0, lsl #48
    ee34:      	sub	x3, x16, x1
    ee38:      	sub	x4, x3, #0x1
    ee3c:      	uxtb	w16, w2
    ee40:      	cmp	w16, wzr
    ee44:      	b.eq	0xeea4 <_stogir.terminal.previous-input+0xa4>
    ee48:      	ldr	x3, [x0, #0x8]
    ee4c:      	cmp	x1, x3
    ee50:      	b.ge	0xeef0 <_stogir.terminal.previous-input+0xf0>
    ee54:      	add	x3, x0, #0x78
    ee58:      	ldr	x3, [x3, #0x8]
    ee5c:      	cmp	x1, x3
    ee60:      	b.ge	0xefc8 <_stogir.terminal.previous-input+0x1c8>
    ee64:      	lsl	x3, x1, #2
    ee68:      	ldr	x5, [x0, #0x78]
    ee6c:      	add	x3, x3, x5
    ee70:      	ldr	w3, [x3]
    ee74:      	sxtw	x3, w3
    ee78:      	cmp	x3, #0x0
    ee7c:      	cset	w3, ge
    ee80:      	ubfx	x3, x3, #0, #8
    ee84:      	b	0xefcc <_stogir.terminal.previous-input+0x1cc>
    ee88:      	adrp	x16, 0xe000 <_stogir.vector-comparison.operands+0x88>
		000000000000ee88:  ARM64_RELOC_PAGE21	l_stogir.502
    ee8c:      	ldr	x16, [x16]
		000000000000ee8c:  ARM64_RELOC_PAGEOFF12	l_stogir.502
    ee90:      	orr	x0, x16, xzr
    ee94:      	mov	x1, x0
    ee98:      	mov	x0, #0x1                ; =1
    ee9c:      	mov	x2, #0x2e               ; =46
    eea0:      	b	0xee18 <_stogir.terminal.previous-input+0x18>
    eea4:      	cmp	x1, #0x0
    eea8:      	b.ge	0xeef8 <_stogir.terminal.previous-input+0xf8>
    eeac:      	add	x5, x0, #0x28
    eeb0:      	add	x6, x0, #0x50
    eeb4:      	ldr	x5, [x5, #0x8]
    eeb8:      	ldr	x6, [x6, #0x8]
    eebc:      	cmp	x5, x6
    eec0:      	b.ne	0xefc0 <_stogir.terminal.previous-input+0x1c0>
    eec4:      	cmp	x3, x5
    eec8:      	b.gt	0xefd0 <_stogir.terminal.previous-input+0x1d0>
    eecc:      	lsl	x3, x4, #2
    eed0:      	ldr	x5, [x0, #0x50]
    eed4:      	add	x3, x3, x5
    eed8:      	ldr	w3, [x3]
    eedc:      	sxtw	x3, w3
    eee0:      	cmp	x3, #0x0
    eee4:      	cset	w3, gt
    eee8:      	ubfx	x3, x3, #0, #8
    eeec:      	b	0xefd4 <_stogir.terminal.previous-input+0x1d4>
    eef0:      	movz	x3, #0x0, lsl #48
    eef4:      	b	0xeefc <_stogir.terminal.previous-input+0xfc>
    eef8:      	movz	x3, #0x0, lsl #48
    eefc:      	cmp	x3, #0x0
    ef00:      	b.eq	0xef40 <_stogir.terminal.previous-input+0x140>
    ef04:      	uxtb	w16, w2
    ef08:      	cmp	w16, wzr
    ef0c:      	b.eq	0xef24 <_stogir.terminal.previous-input+0x124>
    ef10:      	lsl	x2, x1, #4
    ef14:      	ldr	x0, [x0]
    ef18:      	add	x0, x2, x0
    ef1c:      	ldr	x0, [x0]
    ef20:      	b	0xef34 <_stogir.terminal.previous-input+0x134>
    ef24:      	lsl	x2, x4, #4
    ef28:      	ldr	x0, [x0, #0x28]
    ef2c:      	add	x0, x2, x0
    ef30:      	ldr	x0, [x0]
    ef34:      	mov	x2, x0
    ef38:      	mov	x0, #0x1                ; =1
    ef3c:      	b	0xef48 <_stogir.terminal.previous-input+0x148>
    ef40:      	movz	x0, #0x0, lsl #48
    ef44:      	movz	x2, #0x0, lsl #48
    ef48:      	lsr	w0, w0, #0
    ef4c:      	lsr	x16, x0, #0
    ef50:      	cmp	x16, #0x1
    ef54:      	b.eq	0xef70 <_stogir.terminal.previous-input+0x170>
    ef58:      	b.lo	0xef60 <_stogir.terminal.previous-input+0x160>
    ef5c:      	b	0xef74 <_stogir.terminal.previous-input+0x174>
    ef60:      	cmp	x16, #0x0
    ef64:      	b.eq	0xef6c <_stogir.terminal.previous-input+0x16c>
    ef68:      	b	0xef74 <_stogir.terminal.previous-input+0x174>
    ef6c:      	b	0xef78 <_stogir.terminal.previous-input+0x178>
    ef70:      	b	0xef94 <_stogir.terminal.previous-input+0x194>
    ef74:      	b	0xf018 <_stogir.terminal.previous-input+0x218>
    ef78:      	adrp	x16, 0xe000 <_stogir.vector-comparison.operands+0x88>
		000000000000ef78:  ARM64_RELOC_PAGE21	l_stogir.503
    ef7c:      	ldr	x16, [x16]
		000000000000ef7c:  ARM64_RELOC_PAGEOFF12	l_stogir.503
    ef80:      	orr	x0, x16, xzr
    ef84:      	mov	x1, x0
    ef88:      	mov	x0, #0x1                ; =1
    ef8c:      	mov	x2, #0x1d               ; =29
    ef90:      	b	0xeea0 <_stogir.terminal.previous-input+0xa0>
    ef94:      	cmp	x1, #0x0
    ef98:      	b.le	0xee88 <_stogir.terminal.previous-input+0x88>
    ef9c:      	uxtb	w2, w2
    efa0:      	cmp	x2, #0x83
    efa4:      	b.ge	0xefd8 <_stogir.terminal.previous-input+0x1d8>
    efa8:      	adrp	x16, 0xe000 <_stogir.vector-comparison.operands+0x88>
		000000000000efa8:  ARM64_RELOC_PAGE21	l_stogir.504
    efac:      	ldr	x16, [x16]
		000000000000efac:  ARM64_RELOC_PAGEOFF12	l_stogir.504
    efb0:      	orr	x0, x16, xzr
    efb4:      	add	x0, x2, x0
    efb8:      	ldrb	w0, [x0]
    efbc:      	b	0xefdc <_stogir.terminal.previous-input+0x1dc>
    efc0:      	movz	x3, #0x0, lsl #48
    efc4:      	b	0xeefc <_stogir.terminal.previous-input+0xfc>
    efc8:      	movz	x3, #0x0, lsl #48
    efcc:      	b	0xeef4 <_stogir.terminal.previous-input+0xf4>
    efd0:      	movz	x3, #0x0, lsl #48
    efd4:      	b	0xefc4 <_stogir.terminal.previous-input+0x1c4>
    efd8:      	movz	x0, #0x0, lsl #48
    efdc:      	uxtb	w0, w0
    efe0:      	and	x0, x0, #0x8
    efe4:      	uxtb	w0, w0
    efe8:      	cmp	x0, #0x0
    efec:      	cset	w0, eq
    eff0:      	uxtb	w16, w0
    eff4:      	cmp	w16, wzr
    eff8:      	cset	x0, eq
    effc:      	cmp	x0, #0x0
    f000:      	b.eq	0xee88 <_stogir.terminal.previous-input+0x88>
    f004:      	and	x0, x1, #0xffffffff
    f008:      	mov	x1, x0
    f00c:      	movz	x0, #0x0, lsl #48
    f010:      	movz	x2, #0x0, lsl #48
    f014:      	b	0xeea0 <_stogir.terminal.previous-input+0xa0>
    f018:      	brk	#0
    f01c:      	b	0xf018 <_stogir.terminal.previous-input+0x218>

000000000000f020 <_stogir.switch.selector-type>:
    f020:      	sxtw	x1, w1
    f024:      	cmp	x1, #0x0
    f028:      	cset	w2, gt
    f02c:      	movz	x16, #0x0, lsl #48
    f030:      	sub	x3, x16, x1
    f034:      	sub	x4, x3, #0x1
    f038:      	uxtb	w16, w2
    f03c:      	cmp	w16, wzr
    f040:      	b.eq	0xf084 <_stogir.switch.selector-type+0x64>
    f044:      	ldr	x3, [x0, #0x8]
    f048:      	cmp	x1, x3
    f04c:      	b.ge	0xf0d8 <_stogir.switch.selector-type+0xb8>
    f050:      	add	x3, x0, #0x78
    f054:      	ldr	x3, [x3, #0x8]
    f058:      	cmp	x1, x3
    f05c:      	b.ge	0xf1dc <_stogir.switch.selector-type+0x1bc>
    f060:      	lsl	x3, x1, #2
    f064:      	ldr	x5, [x0, #0x78]
    f068:      	add	x3, x3, x5
    f06c:      	ldr	w3, [x3]
    f070:      	sxtw	x3, w3
    f074:      	cmp	x3, #0x0
    f078:      	cset	w3, ge
    f07c:      	ubfx	x3, x3, #0, #8
    f080:      	b	0xf1e0 <_stogir.switch.selector-type+0x1c0>
    f084:      	cmp	x1, #0x0
    f088:      	b.ge	0xf0e0 <_stogir.switch.selector-type+0xc0>
    f08c:      	add	x5, x0, #0x28
    f090:      	add	x6, x0, #0x50
    f094:      	ldr	x5, [x5, #0x8]
    f098:      	ldr	x6, [x6, #0x8]
    f09c:      	cmp	x5, x6
    f0a0:      	b.ne	0xf0d0 <_stogir.switch.selector-type+0xb0>
    f0a4:      	cmp	x3, x5
    f0a8:      	b.gt	0xf1e4 <_stogir.switch.selector-type+0x1c4>
    f0ac:      	lsl	x3, x4, #2
    f0b0:      	ldr	x5, [x0, #0x50]
    f0b4:      	add	x3, x3, x5
    f0b8:      	ldr	w3, [x3]
    f0bc:      	sxtw	x3, w3
    f0c0:      	cmp	x3, #0x0
    f0c4:      	cset	w3, gt
    f0c8:      	ubfx	x3, x3, #0, #8
    f0cc:      	b	0xf1e8 <_stogir.switch.selector-type+0x1c8>
    f0d0:      	movz	x3, #0x0, lsl #48
    f0d4:      	b	0xf0e4 <_stogir.switch.selector-type+0xc4>
    f0d8:      	movz	x3, #0x0, lsl #48
    f0dc:      	b	0xf0e4 <_stogir.switch.selector-type+0xc4>
    f0e0:      	movz	x3, #0x0, lsl #48
    f0e4:      	cmp	x3, #0x0
    f0e8:      	b.eq	0xf128 <_stogir.switch.selector-type+0x108>
    f0ec:      	uxtb	w16, w2
    f0f0:      	cmp	w16, wzr
    f0f4:      	b.eq	0xf10c <_stogir.switch.selector-type+0xec>
    f0f8:      	lsl	x1, x1, #4
    f0fc:      	ldr	x0, [x0]
    f100:      	add	x0, x1, x0
    f104:      	ldr	x0, [x0]
    f108:      	b	0xf11c <_stogir.switch.selector-type+0xfc>
    f10c:      	lsl	x1, x4, #4
    f110:      	ldr	x0, [x0, #0x28]
    f114:      	add	x0, x1, x0
    f118:      	ldr	x0, [x0]
    f11c:      	mov	x1, x0
    f120:      	mov	x0, #0x1                ; =1
    f124:      	b	0xf130 <_stogir.switch.selector-type+0x110>
    f128:      	movz	x0, #0x0, lsl #48
    f12c:      	movz	x1, #0x0, lsl #48
    f130:      	lsr	w0, w0, #0
    f134:      	lsr	x16, x0, #0
    f138:      	cmp	x16, #0x1
    f13c:      	b.eq	0xf158 <_stogir.switch.selector-type+0x138>
    f140:      	b.lo	0xf148 <_stogir.switch.selector-type+0x128>
    f144:      	b	0xf15c <_stogir.switch.selector-type+0x13c>
    f148:      	cmp	x16, #0x0
    f14c:      	b.eq	0xf154 <_stogir.switch.selector-type+0x134>
    f150:      	b	0xf15c <_stogir.switch.selector-type+0x13c>
    f154:      	b	0xf160 <_stogir.switch.selector-type+0x140>
    f158:      	b	0xf1a4 <_stogir.switch.selector-type+0x184>
    f15c:      	b	0xf1ec <_stogir.switch.selector-type+0x1cc>
    f160:      	adrp	x16, 0xf000 <_stogir.terminal.previous-input+0x200>
		000000000000f160:  ARM64_RELOC_PAGE21	l_stogir.505
    f164:      	ldr	x16, [x16]
		000000000000f164:  ARM64_RELOC_PAGEOFF12	l_stogir.505
    f168:      	orr	x0, x16, xzr
    f16c:      	mov	x1, x0
    f170:      	mov	x0, #0x1                ; =1
    f174:      	mov	x2, #0x17               ; =23
    f178:      	b	0xf194 <_stogir.switch.selector-type+0x174>
    f17c:      	adrp	x16, 0xf000 <_stogir.terminal.previous-input+0x200>
		000000000000f17c:  ARM64_RELOC_PAGE21	l_stogir.506
    f180:      	ldr	x16, [x16]
		000000000000f180:  ARM64_RELOC_PAGEOFF12	l_stogir.506
    f184:      	orr	x0, x16, xzr
    f188:      	mov	x1, x0
    f18c:      	mov	x0, #0x1                ; =1
    f190:      	mov	x2, #0x20               ; =32
    f194:      	str	x0, [x8]
    f198:      	str	x1, [x8, #0x8]
    f19c:      	str	x2, [x8, #0x10]
    f1a0:      	ret
    f1a4:      	lsr	w0, w1, #0
    f1a8:      	ubfx	x0, x0, #8, #8
    f1ac:      	cmp	x0, #0x1
    f1b0:      	b.lt	0xf17c <_stogir.switch.selector-type+0x15c>
    f1b4:      	cmp	x0, #0xb
    f1b8:      	b.gt	0xf17c <_stogir.switch.selector-type+0x15c>
    f1bc:      	uxtb	w1, w1
    f1c0:      	cmp	x1, #0x48
    f1c4:      	b.eq	0xf17c <_stogir.switch.selector-type+0x15c>
    f1c8:      	and	x0, x0, #0xffffffff
    f1cc:      	mov	x1, x0
    f1d0:      	movz	x0, #0x0, lsl #48
    f1d4:      	movz	x2, #0x0, lsl #48
    f1d8:      	b	0xf194 <_stogir.switch.selector-type+0x174>
    f1dc:      	movz	x3, #0x0, lsl #48
    f1e0:      	b	0xf0dc <_stogir.switch.selector-type+0xbc>
    f1e4:      	movz	x3, #0x0, lsl #48
    f1e8:      	b	0xf0d4 <_stogir.switch.selector-type+0xb4>
    f1ec:      	brk	#0
    f1f0:      	b	0xf1ec <_stogir.switch.selector-type+0x1cc>

000000000000f1f4 <_stogir.switch.key>:
    f1f4:      	sub	sp, sp, #0x30
    f1f8:      	str	x19, [sp]
    f1fc:      	str	x20, [sp, #0x8]
    f200:      	str	x21, [sp, #0x10]
    f204:      	str	x22, [sp, #0x18]
    f208:      	str	x23, [sp, #0x20]
    f20c:      	sxtw	x2, w2
    f210:      	cmp	x2, #0x1
    f214:      	b.lt	0xf290 <_stogir.switch.key+0x9c>
    f218:      	cmp	x2, #0xb
    f21c:      	cset	w3, le
    f220:      	uxtb	w16, w3
    f224:      	cmp	w16, wzr
    f228:      	b.eq	0xf290 <_stogir.switch.key+0x9c>
    f22c:      	sxtw	x1, w1
    f230:      	cmp	x1, #0x0
    f234:      	cset	w4, gt
    f238:      	movz	x16, #0x0, lsl #48
    f23c:      	sub	x5, x16, x1
    f240:      	sub	x6, x5, #0x1
    f244:      	uxtb	w16, w4
    f248:      	cmp	w16, wzr
    f24c:      	b.eq	0xf314 <_stogir.switch.key+0x120>
    f250:      	ldr	x5, [x0, #0x8]
    f254:      	cmp	x1, x5
    f258:      	b.ge	0xf360 <_stogir.switch.key+0x16c>
    f25c:      	add	x5, x0, #0x78
    f260:      	ldr	x5, [x5, #0x8]
    f264:      	cmp	x1, x5
    f268:      	b.ge	0xf4cc <_stogir.switch.key+0x2d8>
    f26c:      	lsl	x5, x1, #2
    f270:      	ldr	x7, [x0, #0x78]
    f274:      	add	x5, x5, x7
    f278:      	ldr	w5, [x5]
    f27c:      	sxtw	x5, w5
    f280:      	cmp	x5, #0x0
    f284:      	cset	w5, ge
    f288:      	ubfx	x5, x5, #0, #8
    f28c:      	b	0xf4d0 <_stogir.switch.key+0x2dc>
    f290:      	adrp	x16, 0xf000 <_stogir.terminal.previous-input+0x200>
		000000000000f290:  ARM64_RELOC_PAGE21	l_stogir.507
    f294:      	ldr	x16, [x16]
		000000000000f294:  ARM64_RELOC_PAGEOFF12	l_stogir.507
    f298:      	orr	x0, x16, xzr
    f29c:      	mov	x1, x0
    f2a0:      	mov	x0, #0x1                ; =1
    f2a4:      	mov	x2, #0x24               ; =36
    f2a8:      	str	x0, [x8]
    f2ac:      	str	x1, [x8, #0x8]
    f2b0:      	str	x2, [x8, #0x10]
    f2b4:      	ldr	x19, [sp]
    f2b8:      	ldr	x20, [sp, #0x8]
    f2bc:      	ldr	x21, [sp, #0x10]
    f2c0:      	ldr	x22, [sp, #0x18]
    f2c4:      	ldr	x23, [sp, #0x20]
    f2c8:      	add	sp, sp, #0x30
    f2cc:      	ret
    f2d0:      	mov	x23, #0x1               ; =1
    f2d4:      	cmp	x1, #0x0
    f2d8:      	b.ge	0xf2f8 <_stogir.switch.key+0x104>
    f2dc:      	lsr	w1, w4, #0
    f2e0:      	uxtb	w4, w4
    f2e4:      	ubfx	x1, x1, #8, #8
    f2e8:      	cmp	x4, x1
    f2ec:      	b.eq	0xf574 <_stogir.switch.key+0x380>
    f2f0:      	cmp	x4, #0x49
    f2f4:      	b.eq	0xf574 <_stogir.switch.key+0x380>
    f2f8:      	adrp	x16, 0xf000 <_stogir.terminal.previous-input+0x200>
		000000000000f2f8:  ARM64_RELOC_PAGE21	l_stogir.508
    f2fc:      	ldr	x16, [x16]
		000000000000f2fc:  ARM64_RELOC_PAGEOFF12	l_stogir.508
    f300:      	orr	x0, x16, xzr
    f304:      	mov	x1, x0
    f308:      	mov	x0, #0x1                ; =1
    f30c:      	mov	x2, #0x30               ; =48
    f310:      	b	0xf2a8 <_stogir.switch.key+0xb4>
    f314:      	cmp	x1, #0x0
    f318:      	b.ge	0xf368 <_stogir.switch.key+0x174>
    f31c:      	add	x7, x0, #0x28
    f320:      	add	x9, x0, #0x50
    f324:      	ldr	x7, [x7, #0x8]
    f328:      	ldr	x9, [x9, #0x8]
    f32c:      	cmp	x7, x9
    f330:      	b.ne	0xf4c4 <_stogir.switch.key+0x2d0>
    f334:      	cmp	x5, x7
    f338:      	b.gt	0xf56c <_stogir.switch.key+0x378>
    f33c:      	lsl	x5, x6, #2
    f340:      	ldr	x7, [x0, #0x50]
    f344:      	add	x5, x5, x7
    f348:      	ldr	w5, [x5]
    f34c:      	sxtw	x5, w5
    f350:      	cmp	x5, #0x0
    f354:      	cset	w5, gt
    f358:      	ubfx	x5, x5, #0, #8
    f35c:      	b	0xf570 <_stogir.switch.key+0x37c>
    f360:      	movz	x5, #0x0, lsl #48
    f364:      	b	0xf36c <_stogir.switch.key+0x178>
    f368:      	movz	x5, #0x0, lsl #48
    f36c:      	cmp	x5, #0x0
    f370:      	b.eq	0xf3d4 <_stogir.switch.key+0x1e0>
    f374:      	uxtb	w16, w4
    f378:      	cmp	w16, wzr
    f37c:      	b.eq	0xf3a4 <_stogir.switch.key+0x1b0>
    f380:      	lsl	x4, x1, #4
    f384:      	ldr	x0, [x0]
    f388:      	add	x0, x4, x0
    f38c:      	ldr	x4, [x0]
    f390:      	ldr	x0, [x0, #0x8]
    f394:      	fmov	d31, x0
    f398:      	mov	x0, x4
    f39c:      	fmov	x4, d31
    f3a0:      	b	0xf3c4 <_stogir.switch.key+0x1d0>
    f3a4:      	lsl	x4, x6, #4
    f3a8:      	ldr	x0, [x0, #0x28]
    f3ac:      	add	x0, x4, x0
    f3b0:      	ldr	x4, [x0]
    f3b4:      	ldr	x0, [x0, #0x8]
    f3b8:      	fmov	d31, x0
    f3bc:      	mov	x0, x4
    f3c0:      	fmov	x4, d31
    f3c4:      	mov	x5, x4
    f3c8:      	mov	x4, x0
    f3cc:      	mov	x0, #0x1                ; =1
    f3d0:      	b	0xf3e0 <_stogir.switch.key+0x1ec>
    f3d4:      	movz	x0, #0x0, lsl #48
    f3d8:      	movz	x4, #0x0, lsl #48
    f3dc:      	movz	x5, #0x0, lsl #48
    f3e0:      	lsr	w0, w0, #0
    f3e4:      	lsr	x16, x0, #0
    f3e8:      	cmp	x16, #0x1
    f3ec:      	b.eq	0xf408 <_stogir.switch.key+0x214>
    f3f0:      	b.lo	0xf3f8 <_stogir.switch.key+0x204>
    f3f4:      	b	0xf40c <_stogir.switch.key+0x218>
    f3f8:      	cmp	x16, #0x0
    f3fc:      	b.eq	0xf404 <_stogir.switch.key+0x210>
    f400:      	b	0xf40c <_stogir.switch.key+0x218>
    f404:      	b	0xf410 <_stogir.switch.key+0x21c>
    f408:      	b	0xf42c <_stogir.switch.key+0x238>
    f40c:      	b	0xf618 <_stogir.switch.key+0x424>
    f410:      	adrp	x16, 0xf000 <_stogir.terminal.previous-input+0x200>
		000000000000f410:  ARM64_RELOC_PAGE21	l_stogir.509
    f414:      	ldr	x16, [x16]
		000000000000f414:  ARM64_RELOC_PAGEOFF12	l_stogir.509
    f418:      	orr	x0, x16, xzr
    f41c:      	mov	x1, x0
    f420:      	mov	x0, #0x1                ; =1
    f424:      	mov	x2, #0x1c               ; =28
    f428:      	b	0xf310 <_stogir.switch.key+0x11c>
    f42c:      	cmp	x2, #0x1
    f430:      	cset	w0, eq
    f434:      	cmp	x2, #0x0
    f438:      	cset	w6, eq
    f43c:      	cmp	x2, #0x2
    f440:      	cset	w7, eq
    f444:      	cmp	x2, #0x7
    f448:      	cset	w9, eq
    f44c:      	cmp	x2, #0x8
    f450:      	cset	w10, eq
    f454:      	cmp	x2, #0x3
    f458:      	cset	w11, eq
    f45c:      	cmp	x2, #0x9
    f460:      	cset	w12, eq
    f464:      	cmp	x2, #0x4
    f468:      	cset	w13, eq
    f46c:      	cmp	x2, #0xa
    f470:      	cset	w14, eq
    f474:      	cmp	x2, #0xd
    f478:      	cset	w15, eq
    f47c:      	cmp	x2, #0x5
    f480:      	cset	w19, eq
    f484:      	cmp	x2, #0xb
    f488:      	cset	w20, eq
    f48c:      	cmp	x2, #0xc
    f490:      	cset	w21, eq
    f494:      	cmp	x2, #0x6
    f498:      	cset	w22, eq
    f49c:      	uxtb	w16, w22
    f4a0:      	cmp	w16, wzr
    f4a4:      	mov	x16, #0x8               ; =8
    f4a8:      	movn	x17, #0x0, lsl #48
    f4ac:      	csel	x22, x16, x17, ne
    f4b0:      	uxtb	w16, w6
    f4b4:      	cmp	w16, wzr
    f4b8:      	b.eq	0xf4d4 <_stogir.switch.key+0x2e0>
    f4bc:      	movz	x23, #0x0, lsl #48
    f4c0:      	b	0xf2d4 <_stogir.switch.key+0xe0>
    f4c4:      	movz	x5, #0x0, lsl #48
    f4c8:      	b	0xf36c <_stogir.switch.key+0x178>
    f4cc:      	movz	x5, #0x0, lsl #48
    f4d0:      	b	0xf364 <_stogir.switch.key+0x170>
    f4d4:      	uxtb	w16, w0
    f4d8:      	cmp	w16, wzr
    f4dc:      	b.ne	0xf2d0 <_stogir.switch.key+0xdc>
    f4e0:      	uxtb	w16, w7
    f4e4:      	cmp	w16, wzr
    f4e8:      	b.ne	0xf2d0 <_stogir.switch.key+0xdc>
    f4ec:      	uxtb	w16, w9
    f4f0:      	cmp	w16, wzr
    f4f4:      	b.ne	0xf2d0 <_stogir.switch.key+0xdc>
    f4f8:      	uxtb	w16, w10
    f4fc:      	cmp	w16, wzr
    f500:      	b.ne	0xf2d0 <_stogir.switch.key+0xdc>
    f504:      	uxtb	w16, w11
    f508:      	cmp	w16, wzr
    f50c:      	b.ne	0xf610 <_stogir.switch.key+0x41c>
    f510:      	uxtb	w16, w12
    f514:      	cmp	w16, wzr
    f518:      	b.ne	0xf610 <_stogir.switch.key+0x41c>
    f51c:      	uxtb	w16, w13
    f520:      	cmp	w16, wzr
    f524:      	b.ne	0xf6e8 <_stogir.switch.key+0x4f4>
    f528:      	uxtb	w16, w14
    f52c:      	cmp	w16, wzr
    f530:      	b.ne	0xf6e8 <_stogir.switch.key+0x4f4>
    f534:      	uxtb	w16, w15
    f538:      	cmp	w16, wzr
    f53c:      	b.ne	0xf6e8 <_stogir.switch.key+0x4f4>
    f540:      	uxtb	w16, w19
    f544:      	cmp	w16, wzr
    f548:      	b.ne	0xf6f0 <_stogir.switch.key+0x4fc>
    f54c:      	uxtb	w16, w20
    f550:      	cmp	w16, wzr
    f554:      	b.ne	0xf6f0 <_stogir.switch.key+0x4fc>
    f558:      	uxtb	w16, w21
    f55c:      	cmp	w16, wzr
    f560:      	b.ne	0xf6f0 <_stogir.switch.key+0x4fc>
    f564:      	mov	x23, x22
    f568:      	b	0xf6f4 <_stogir.switch.key+0x500>
    f56c:      	movz	x5, #0x0, lsl #48
    f570:      	b	0xf4c8 <_stogir.switch.key+0x2d4>
    f574:      	cmp	x1, x2
    f578:      	b.ne	0xf2f8 <_stogir.switch.key+0x104>
    f57c:      	lsr	w23, w23, #0
    f580:      	lsr	w1, w5, #0
    f584:      	sxtw	x23, w23
    f588:      	ubfx	x1, x1, #0, #32
    f58c:      	lsr	x4, x5, #32
    f590:      	lsl	x5, x23, #3
    f594:      	ubfx	x4, x4, #0, #32
    f598:      	lsr	w5, w5, #0
    f59c:      	lsl	x4, x4, #32
    f5a0:      	sxtw	x5, w5
    f5a4:      	orr	x1, x4, x1
    f5a8:      	cmp	x5, #0x40
    f5ac:      	b.ge	0xf5bc <_stogir.switch.key+0x3c8>
    f5b0:      	lsr	x4, x1, x5
    f5b4:      	cmp	x4, #0x0
    f5b8:      	b.ne	0xf2f8 <_stogir.switch.key+0x104>
    f5bc:      	uxtb	w16, w0
    f5c0:      	cmp	w16, wzr
    f5c4:      	b.eq	0xf5d0 <_stogir.switch.key+0x3dc>
    f5c8:      	cmp	x1, #0x1
    f5cc:      	b.hi	0xf2f8 <_stogir.switch.key+0x104>
    f5d0:      	cmp	x2, #0x7
    f5d4:      	b.lt	0xf5f8 <_stogir.switch.key+0x404>
    f5d8:      	uxtb	w16, w3
    f5dc:      	cmp	w16, wzr
    f5e0:      	b.eq	0xf5f8 <_stogir.switch.key+0x404>
    f5e4:      	uxtb	w16, w6
    f5e8:      	cmp	w16, wzr
    f5ec:      	b.eq	0xf650 <_stogir.switch.key+0x45c>
    f5f0:      	movz	x0, #0x0, lsl #48
    f5f4:      	b	0xf624 <_stogir.switch.key+0x430>
    f5f8:      	movz	x0, #0x0, lsl #48
    f5fc:      	eor	x0, x0, x1
    f600:      	mov	x1, x0
    f604:      	movz	x0, #0x0, lsl #48
    f608:      	movz	x2, #0x0, lsl #48
    f60c:      	b	0xf310 <_stogir.switch.key+0x11c>
    f610:      	mov	x23, #0x2               ; =2
    f614:      	b	0xf2d4 <_stogir.switch.key+0xe0>
    f618:      	brk	#0
    f61c:      	b	0xf618 <_stogir.switch.key+0x424>
    f620:      	mov	x0, #0x1                ; =1
    f624:      	lsr	w0, w0, #0
    f628:      	sxtw	x0, w0
    f62c:      	lsl	x0, x0, #3
    f630:      	lsr	w0, w0, #0
    f634:      	sxtw	x0, w0
    f638:      	sub	x0, x0, #0x1
    f63c:      	lsr	w0, w0, #0
    f640:      	sxtw	x0, w0
    f644:      	mov	x16, #0x1               ; =1
    f648:      	lsl	x0, x16, x0
    f64c:      	b	0xf5fc <_stogir.switch.key+0x408>
    f650:      	uxtb	w16, w0
    f654:      	cmp	w16, wzr
    f658:      	b.ne	0xf620 <_stogir.switch.key+0x42c>
    f65c:      	uxtb	w16, w7
    f660:      	cmp	w16, wzr
    f664:      	b.ne	0xf620 <_stogir.switch.key+0x42c>
    f668:      	uxtb	w16, w9
    f66c:      	cmp	w16, wzr
    f670:      	b.ne	0xf620 <_stogir.switch.key+0x42c>
    f674:      	uxtb	w16, w10
    f678:      	cmp	w16, wzr
    f67c:      	b.ne	0xf620 <_stogir.switch.key+0x42c>
    f680:      	uxtb	w16, w11
    f684:      	cmp	w16, wzr
    f688:      	b.ne	0xf6f8 <_stogir.switch.key+0x504>
    f68c:      	uxtb	w16, w12
    f690:      	cmp	w16, wzr
    f694:      	b.ne	0xf6f8 <_stogir.switch.key+0x504>
    f698:      	uxtb	w16, w13
    f69c:      	cmp	w16, wzr
    f6a0:      	b.ne	0xf700 <_stogir.switch.key+0x50c>
    f6a4:      	uxtb	w16, w14
    f6a8:      	cmp	w16, wzr
    f6ac:      	b.ne	0xf700 <_stogir.switch.key+0x50c>
    f6b0:      	uxtb	w16, w15
    f6b4:      	cmp	w16, wzr
    f6b8:      	b.ne	0xf700 <_stogir.switch.key+0x50c>
    f6bc:      	uxtb	w16, w19
    f6c0:      	cmp	w16, wzr
    f6c4:      	b.ne	0xf708 <_stogir.switch.key+0x514>
    f6c8:      	uxtb	w16, w20
    f6cc:      	cmp	w16, wzr
    f6d0:      	b.ne	0xf708 <_stogir.switch.key+0x514>
    f6d4:      	uxtb	w16, w21
    f6d8:      	cmp	w16, wzr
    f6dc:      	b.ne	0xf708 <_stogir.switch.key+0x514>
    f6e0:      	mov	x0, x22
    f6e4:      	b	0xf70c <_stogir.switch.key+0x518>
    f6e8:      	mov	x23, #0x4               ; =4
    f6ec:      	b	0xf614 <_stogir.switch.key+0x420>
    f6f0:      	mov	x23, #0x8               ; =8
    f6f4:      	b	0xf6ec <_stogir.switch.key+0x4f8>
    f6f8:      	mov	x0, #0x2                ; =2
    f6fc:      	b	0xf624 <_stogir.switch.key+0x430>
    f700:      	mov	x0, #0x4                ; =4
    f704:      	b	0xf6fc <_stogir.switch.key+0x508>
    f708:      	mov	x0, #0x8                ; =8
    f70c:      	b	0xf704 <_stogir.switch.key+0x510>

000000000000f710 <_stogir.stack.entry-allocation?>:
    f710:      	sub	sp, sp, #0x10
    f714:      	add	x2, x0, #0x78
    f718:      	add	x3, x0, #0x28
    f71c:      	add	x4, x0, #0x50
    f720:      	add	x5, x0, #0x78
    f724:      	add	x6, x0, #0x28
    f728:      	add	x7, x0, #0x50
    f72c:      	sxtw	x1, w1
    f730:      	mov	x9, x1
    f734:      	mov	x1, #0x1                ; =1
    f738:      	movz	x8, #0x0, lsl #48
    f73c:      	b	0xf88c <_stogir.stack.entry-allocation?+0x17c>
    f740:      	movz	x12, #0x0, lsl #48
    f744:      	b	0xf7bc <_stogir.stack.entry-allocation?+0xac>
    f748:      	movz	x10, #0x0, lsl #48
    f74c:      	movz	x11, #0x0, lsl #48
    f750:      	lsr	w10, w10, #0
    f754:      	lsr	x16, x10, #0
    f758:      	cmp	x16, #0x1
    f75c:      	b.eq	0xf778 <_stogir.stack.entry-allocation?+0x68>
    f760:      	b.lo	0xf768 <_stogir.stack.entry-allocation?+0x58>
    f764:      	b	0xf77c <_stogir.stack.entry-allocation?+0x6c>
    f768:      	cmp	x16, #0x0
    f76c:      	b.eq	0xf774 <_stogir.stack.entry-allocation?+0x64>
    f770:      	b	0xf77c <_stogir.stack.entry-allocation?+0x6c>
    f774:      	b	0xf79c <_stogir.stack.entry-allocation?+0x8c>
    f778:      	b	0xf780 <_stogir.stack.entry-allocation?+0x70>
    f77c:      	b	0xfad8 <_stogir.stack.entry-allocation?+0x3c8>
    f780:      	uxtb	w10, w11
    f784:      	lsr	w11, w11, #0
    f788:      	ubfx	x11, x11, #8, #8
    f78c:      	cmp	x10, x11
    f790:      	b.eq	0xfac8 <_stogir.stack.entry-allocation?+0x3b8>
    f794:      	cmp	x10, #0x49
    f798:      	b.eq	0xfac8 <_stogir.stack.entry-allocation?+0x3b8>
    f79c:      	movz	x1, #0x0, lsl #48
    f7a0:      	fmov	d31, x8
    f7a4:      	mov	x8, x9
    f7a8:      	fmov	x9, d31
    f7ac:      	b	0xf978 <_stogir.stack.entry-allocation?+0x268>
    f7b0:      	movz	x12, #0x0, lsl #48
    f7b4:      	b	0xf7c4 <_stogir.stack.entry-allocation?+0xb4>
    f7b8:      	movz	x12, #0x0, lsl #48
    f7bc:      	b	0xf7cc <_stogir.stack.entry-allocation?+0xbc>
    f7c0:      	movz	x12, #0x0, lsl #48
    f7c4:      	b	0xf7cc <_stogir.stack.entry-allocation?+0xbc>
    f7c8:      	movz	x12, #0x0, lsl #48
    f7cc:      	cmp	x12, #0x0
    f7d0:      	b.eq	0xf834 <_stogir.stack.entry-allocation?+0x124>
    f7d4:      	uxtb	w16, w11
    f7d8:      	cmp	w16, wzr
    f7dc:      	b.eq	0xf804 <_stogir.stack.entry-allocation?+0xf4>
    f7e0:      	lsl	x10, x10, #4
    f7e4:      	ldr	x11, [x0]
    f7e8:      	add	x10, x10, x11
    f7ec:      	ldr	x11, [x10]
    f7f0:      	ldr	x10, [x10, #0x8]
    f7f4:      	fmov	d31, x10
    f7f8:      	mov	x10, x11
    f7fc:      	fmov	x11, d31
    f800:      	b	0xf824 <_stogir.stack.entry-allocation?+0x114>
    f804:      	lsl	x10, x13, #4
    f808:      	ldr	x11, [x0, #0x28]
    f80c:      	add	x10, x10, x11
    f810:      	ldr	x11, [x10]
    f814:      	ldr	x10, [x10, #0x8]
    f818:      	fmov	d31, x10
    f81c:      	mov	x10, x11
    f820:      	fmov	x11, d31
    f824:      	mov	x12, x11
    f828:      	mov	x11, x10
    f82c:      	mov	x10, #0x1               ; =1
    f830:      	b	0xf840 <_stogir.stack.entry-allocation?+0x130>
    f834:      	movz	x10, #0x0, lsl #48
    f838:      	movz	x11, #0x0, lsl #48
    f83c:      	movz	x12, #0x0, lsl #48
    f840:      	lsr	w10, w10, #0
    f844:      	lsr	x16, x10, #0
    f848:      	cmp	x16, #0x1
    f84c:      	b.eq	0xf868 <_stogir.stack.entry-allocation?+0x158>
    f850:      	b.lo	0xf858 <_stogir.stack.entry-allocation?+0x148>
    f854:      	b	0xf86c <_stogir.stack.entry-allocation?+0x15c>
    f858:      	cmp	x16, #0x0
    f85c:      	b.eq	0xf864 <_stogir.stack.entry-allocation?+0x154>
    f860:      	b	0xf86c <_stogir.stack.entry-allocation?+0x15c>
    f864:      	b	0xf870 <_stogir.stack.entry-allocation?+0x160>
    f868:      	b	0xf944 <_stogir.stack.entry-allocation?+0x234>
    f86c:      	b	0xfa24 <_stogir.stack.entry-allocation?+0x314>
    f870:      	fmov	d31, x8
    f874:      	mov	x8, x9
    f878:      	fmov	x9, d31
    f87c:      	movz	x1, #0x0, lsl #48
    f880:      	fmov	d31, x8
    f884:      	mov	x8, x9
    f888:      	fmov	x9, d31
    f88c:      	cmp	x1, #0x0
    f890:      	b.eq	0xfa08 <_stogir.stack.entry-allocation?+0x2f8>
    f894:      	cmp	x8, #0x0
    f898:      	b.ne	0xfa08 <_stogir.stack.entry-allocation?+0x2f8>
    f89c:      	lsr	w10, w9, #0
    f8a0:      	sxtw	x10, w10
    f8a4:      	cmp	x10, #0x0
    f8a8:      	cset	w11, gt
    f8ac:      	movz	x16, #0x0, lsl #48
    f8b0:      	sub	x12, x16, x10
    f8b4:      	sub	x13, x12, #0x1
    f8b8:      	uxtb	w16, w11
    f8bc:      	cmp	w16, wzr
    f8c0:      	b.eq	0xf900 <_stogir.stack.entry-allocation?+0x1f0>
    f8c4:      	ldr	x12, [x0, #0x8]
    f8c8:      	cmp	x10, x12
    f8cc:      	b.ge	0xf7c0 <_stogir.stack.entry-allocation?+0xb0>
    f8d0:      	ldr	x12, [x2, #0x8]
    f8d4:      	cmp	x10, x12
    f8d8:      	b.ge	0xf7b0 <_stogir.stack.entry-allocation?+0xa0>
    f8dc:      	lsl	x12, x10, #2
    f8e0:      	ldr	x14, [x0, #0x78]
    f8e4:      	add	x12, x12, x14
    f8e8:      	ldr	w12, [x12]
    f8ec:      	sxtw	x12, w12
    f8f0:      	cmp	x12, #0x0
    f8f4:      	cset	w12, ge
    f8f8:      	ubfx	x12, x12, #0, #8
    f8fc:      	b	0xf7b4 <_stogir.stack.entry-allocation?+0xa4>
    f900:      	cmp	x10, #0x0
    f904:      	b.ge	0xf7c8 <_stogir.stack.entry-allocation?+0xb8>
    f908:      	ldr	x14, [x3, #0x8]
    f90c:      	ldr	x15, [x4, #0x8]
    f910:      	cmp	x14, x15
    f914:      	b.ne	0xf7b8 <_stogir.stack.entry-allocation?+0xa8>
    f918:      	cmp	x12, x14
    f91c:      	b.gt	0xf740 <_stogir.stack.entry-allocation?+0x30>
    f920:      	lsl	x12, x13, #2
    f924:      	ldr	x14, [x0, #0x50]
    f928:      	add	x12, x12, x14
    f92c:      	ldr	w12, [x12]
    f930:      	sxtw	x12, w12
    f934:      	cmp	x12, #0x0
    f938:      	cset	w12, gt
    f93c:      	ubfx	x12, x12, #0, #8
    f940:      	b	0xf744 <_stogir.stack.entry-allocation?+0x34>
    f944:      	uxtb	w10, w11
    f948:      	asr	x13, x11, #32
    f94c:      	mov	x16, sp
    f950:      	str	x11, [x16]
    f954:      	mov	x16, sp
    f958:      	str	x12, [x16, #0x8]
    f95c:      	cmp	x10, #0x68
    f960:      	b.ne	0xf97c <_stogir.stack.entry-allocation?+0x26c>
    f964:      	cmp	x13, #0x0
    f968:      	cset	w1, eq
    f96c:      	ubfx	x1, x1, #0, #8
    f970:      	mov	x8, x9
    f974:      	mov	x9, #0x1                ; =1
    f978:      	b	0xf880 <_stogir.stack.entry-allocation?+0x170>
    f97c:      	cmp	x9, #0x0
    f980:      	b.le	0xf79c <_stogir.stack.entry-allocation?+0x8c>
    f984:      	cmp	x10, #0x51
    f988:      	b.ne	0xf79c <_stogir.stack.entry-allocation?+0x8c>
    f98c:      	cmp	x13, #0x0
    f990:      	b.le	0xf79c <_stogir.stack.entry-allocation?+0x8c>
    f994:      	cmp	x13, x9
    f998:      	b.ge	0xf79c <_stogir.stack.entry-allocation?+0x8c>
    f99c:      	lsr	w12, w12, #0
    f9a0:      	sxtw	x12, w12
    f9a4:      	cmp	x12, #0x0
    f9a8:      	b.ge	0xf79c <_stogir.stack.entry-allocation?+0x8c>
    f9ac:      	cmp	x12, #0x0
    f9b0:      	cset	w10, gt
    f9b4:      	movz	x16, #0x0, lsl #48
    f9b8:      	sub	x11, x16, x12
    f9bc:      	sub	x13, x11, #0x1
    f9c0:      	uxtb	w16, w10
    f9c4:      	cmp	w16, wzr
    f9c8:      	b.eq	0xfa7c <_stogir.stack.entry-allocation?+0x36c>
    f9cc:      	ldr	x11, [x0, #0x8]
    f9d0:      	cmp	x12, x11
    f9d4:      	b.ge	0xfa74 <_stogir.stack.entry-allocation?+0x364>
    f9d8:      	ldr	x11, [x5, #0x8]
    f9dc:      	cmp	x12, x11
    f9e0:      	b.ge	0xfac0 <_stogir.stack.entry-allocation?+0x3b0>
    f9e4:      	lsl	x11, x12, #2
    f9e8:      	ldr	x14, [x0, #0x78]
    f9ec:      	add	x11, x11, x14
    f9f0:      	ldr	w11, [x11]
    f9f4:      	sxtw	x11, w11
    f9f8:      	cmp	x11, #0x0
    f9fc:      	cset	w11, ge
    fa00:      	ubfx	x11, x11, #0, #8
    fa04:      	b	0xfac4 <_stogir.stack.entry-allocation?+0x3b4>
    fa08:      	cmp	x1, #0x0
    fa0c:      	b.eq	0xfa18 <_stogir.stack.entry-allocation?+0x308>
    fa10:      	mov	x0, x8
    fa14:      	b	0xfa1c <_stogir.stack.entry-allocation?+0x30c>
    fa18:      	movz	x0, #0x0, lsl #48
    fa1c:      	add	sp, sp, #0x10
    fa20:      	ret
    fa24:      	brk	#0
    fa28:      	b	0xfa24 <_stogir.stack.entry-allocation?+0x314>
    fa2c:      	lsl	x10, x13, #4
    fa30:      	ldr	x11, [x0, #0x28]
    fa34:      	add	x10, x10, x11
    fa38:      	ldr	x10, [x10]
    fa3c:      	mov	x11, x10
    fa40:      	mov	x10, #0x1               ; =1
    fa44:      	b	0xf750 <_stogir.stack.entry-allocation?+0x40>
    fa48:      	movz	x11, #0x0, lsl #48
    fa4c:      	cmp	x11, #0x0
    fa50:      	b.eq	0xf748 <_stogir.stack.entry-allocation?+0x38>
    fa54:      	uxtb	w16, w10
    fa58:      	cmp	w16, wzr
    fa5c:      	b.eq	0xfa2c <_stogir.stack.entry-allocation?+0x31c>
    fa60:      	lsl	x10, x12, #4
    fa64:      	ldr	x11, [x0]
    fa68:      	add	x10, x10, x11
    fa6c:      	ldr	x10, [x10]
    fa70:      	b	0xfa3c <_stogir.stack.entry-allocation?+0x32c>
    fa74:      	movz	x11, #0x0, lsl #48
    fa78:      	b	0xfa4c <_stogir.stack.entry-allocation?+0x33c>
    fa7c:      	ldr	x14, [x6, #0x8]
    fa80:      	ldr	x15, [x7, #0x8]
    fa84:      	cmp	x14, x15
    fa88:      	b.ne	0xfa48 <_stogir.stack.entry-allocation?+0x338>
    fa8c:      	cmp	x11, x14
    fa90:      	b.gt	0xfab8 <_stogir.stack.entry-allocation?+0x3a8>
    fa94:      	lsl	x11, x13, #2
    fa98:      	ldr	x14, [x0, #0x50]
    fa9c:      	add	x11, x11, x14
    faa0:      	ldr	w11, [x11]
    faa4:      	sxtw	x11, w11
    faa8:      	cmp	x11, #0x0
    faac:      	cset	w11, gt
    fab0:      	ubfx	x11, x11, #0, #8
    fab4:      	b	0xfabc <_stogir.stack.entry-allocation?+0x3ac>
    fab8:      	movz	x11, #0x0, lsl #48
    fabc:      	b	0xfa4c <_stogir.stack.entry-allocation?+0x33c>
    fac0:      	movz	x11, #0x0, lsl #48
    fac4:      	b	0xfa78 <_stogir.stack.entry-allocation?+0x368>
    fac8:      	mov	x16, sp
    facc:      	ldr	w9, [x16, #0x4]
    fad0:      	sxtw	x9, w9
    fad4:      	b	0xf7a0 <_stogir.stack.entry-allocation?+0x90>
    fad8:      	brk	#0
    fadc:      	b	0xfad8 <_stogir.stack.entry-allocation?+0x3c8>

000000000000fae0 <_stogir.stack.constant-size>:
    fae0:      	sub	sp, sp, #0x10
    fae4:      	str	x29, [sp]
    fae8:      	str	x30, [sp, #0x8]
    faec:      	mov	x29, sp
    faf0:      	mov	x2, sp
    faf4:      	sxtw	x1, w1
    faf8:      	sub	sp, sp, #0x10
    fafc:      	mov	x3, sp
    fb00:      	cmp	x1, #0x0
    fb04:      	cset	w4, gt
    fb08:      	movz	x16, #0x0, lsl #48
    fb0c:      	sub	x5, x16, x1
    fb10:      	sub	x6, x5, #0x1
    fb14:      	uxtb	w16, w4
    fb18:      	cmp	w16, wzr
    fb1c:      	b.eq	0xfb60 <_stogir.stack.constant-size+0x80>
    fb20:      	ldr	x5, [x0, #0x8]
    fb24:      	cmp	x1, x5
    fb28:      	b.ge	0xfbb4 <_stogir.stack.constant-size+0xd4>
    fb2c:      	add	x5, x0, #0x78
    fb30:      	ldr	x5, [x5, #0x8]
    fb34:      	cmp	x1, x5
    fb38:      	b.ge	0xfd28 <_stogir.stack.constant-size+0x248>
    fb3c:      	lsl	x5, x1, #2
    fb40:      	ldr	x7, [x0, #0x78]
    fb44:      	add	x5, x5, x7
    fb48:      	ldr	w5, [x5]
    fb4c:      	sxtw	x5, w5
    fb50:      	cmp	x5, #0x0
    fb54:      	cset	w5, ge
    fb58:      	ubfx	x5, x5, #0, #8
    fb5c:      	b	0xfd2c <_stogir.stack.constant-size+0x24c>
    fb60:      	cmp	x1, #0x0
    fb64:      	b.ge	0xfbbc <_stogir.stack.constant-size+0xdc>
    fb68:      	add	x7, x0, #0x28
    fb6c:      	add	x9, x0, #0x50
    fb70:      	ldr	x7, [x7, #0x8]
    fb74:      	ldr	x9, [x9, #0x8]
    fb78:      	cmp	x7, x9
    fb7c:      	b.ne	0xfbac <_stogir.stack.constant-size+0xcc>
    fb80:      	cmp	x5, x7
    fb84:      	b.gt	0xfdb0 <_stogir.stack.constant-size+0x2d0>
    fb88:      	lsl	x5, x6, #2
    fb8c:      	ldr	x7, [x0, #0x50]
    fb90:      	add	x5, x5, x7
    fb94:      	ldr	w5, [x5]
    fb98:      	sxtw	x5, w5
    fb9c:      	cmp	x5, #0x0
    fba0:      	cset	w5, gt
    fba4:      	ubfx	x5, x5, #0, #8
    fba8:      	b	0xfdb4 <_stogir.stack.constant-size+0x2d4>
    fbac:      	movz	x5, #0x0, lsl #48
    fbb0:      	b	0xfbc0 <_stogir.stack.constant-size+0xe0>
    fbb4:      	movz	x5, #0x0, lsl #48
    fbb8:      	b	0xfbc0 <_stogir.stack.constant-size+0xe0>
    fbbc:      	movz	x5, #0x0, lsl #48
    fbc0:      	cmp	x5, #0x0
    fbc4:      	b.eq	0xfc28 <_stogir.stack.constant-size+0x148>
    fbc8:      	uxtb	w16, w4
    fbcc:      	cmp	w16, wzr
    fbd0:      	b.eq	0xfbf8 <_stogir.stack.constant-size+0x118>
    fbd4:      	lsl	x4, x1, #4
    fbd8:      	ldr	x0, [x0]
    fbdc:      	add	x0, x4, x0
    fbe0:      	ldr	x4, [x0]
    fbe4:      	ldr	x0, [x0, #0x8]
    fbe8:      	fmov	d31, x0
    fbec:      	mov	x0, x4
    fbf0:      	fmov	x4, d31
    fbf4:      	b	0xfc18 <_stogir.stack.constant-size+0x138>
    fbf8:      	lsl	x4, x6, #4
    fbfc:      	ldr	x0, [x0, #0x28]
    fc00:      	add	x0, x4, x0
    fc04:      	ldr	x4, [x0]
    fc08:      	ldr	x0, [x0, #0x8]
    fc0c:      	fmov	d31, x0
    fc10:      	mov	x0, x4
    fc14:      	fmov	x4, d31
    fc18:      	mov	x5, x4
    fc1c:      	mov	x4, x0
    fc20:      	mov	x0, #0x1                ; =1
    fc24:      	b	0xfc34 <_stogir.stack.constant-size+0x154>
    fc28:      	movz	x0, #0x0, lsl #48
    fc2c:      	movz	x4, #0x0, lsl #48
    fc30:      	movz	x5, #0x0, lsl #48
    fc34:      	lsr	w0, w0, #0
    fc38:      	lsr	x16, x0, #0
    fc3c:      	cmp	x16, #0x1
    fc40:      	b.eq	0xfc5c <_stogir.stack.constant-size+0x17c>
    fc44:      	b.lo	0xfc4c <_stogir.stack.constant-size+0x16c>
    fc48:      	b	0xfc60 <_stogir.stack.constant-size+0x180>
    fc4c:      	cmp	x16, #0x0
    fc50:      	b.eq	0xfc58 <_stogir.stack.constant-size+0x178>
    fc54:      	b	0xfc60 <_stogir.stack.constant-size+0x180>
    fc58:      	b	0xfc64 <_stogir.stack.constant-size+0x184>
    fc5c:      	b	0xfd08 <_stogir.stack.constant-size+0x228>
    fc60:      	b	0xfe68 <_stogir.stack.constant-size+0x388>
    fc64:      	adrp	x16, 0xf000 <_stogir.terminal.previous-input+0x200>
		000000000000fc64:  ARM64_RELOC_PAGE21	l_stogir.510
    fc68:      	ldr	x16, [x16]
		000000000000fc68:  ARM64_RELOC_PAGEOFF12	l_stogir.510
    fc6c:      	orr	x0, x16, xzr
    fc70:      	mov	x1, x0
    fc74:      	mov	x0, #0x1                ; =1
    fc78:      	mov	x3, #0x18               ; =24
    fc7c:      	b	0xfce4 <_stogir.stack.constant-size+0x204>
    fc80:      	mov	x4, #0x1                ; =1
    fc84:      	ldr	w5, [x3, #0x8]
    fc88:      	ldr	w6, [x3, #0xc]
    fc8c:      	cmp	x1, #0x0
    fc90:      	b.ge	0xfccc <_stogir.stack.constant-size+0x1ec>
    fc94:      	cmp	x0, #0x1
    fc98:      	b.lt	0xfccc <_stogir.stack.constant-size+0x1ec>
    fc9c:      	cmp	x0, #0xb
    fca0:      	cset	w1, le
    fca4:      	uxtb	w16, w1
    fca8:      	cmp	w16, wzr
    fcac:      	b.eq	0xfccc <_stogir.stack.constant-size+0x1ec>
    fcb0:      	ldr	w3, [x3]
    fcb4:      	uxtb	w7, w3
    fcb8:      	ubfx	x3, x3, #8, #8
    fcbc:      	cmp	x7, x3
    fcc0:      	b.eq	0xfdb8 <_stogir.stack.constant-size+0x2d8>
    fcc4:      	cmp	x7, #0x49
    fcc8:      	b.eq	0xfdb8 <_stogir.stack.constant-size+0x2d8>
    fccc:      	adrp	x16, 0xf000 <_stogir.terminal.previous-input+0x200>
		000000000000fccc:  ARM64_RELOC_PAGE21	l_stogir.511
    fcd0:      	ldr	x16, [x16]
		000000000000fcd0:  ARM64_RELOC_PAGEOFF12	l_stogir.511
    fcd4:      	orr	x0, x16, xzr
    fcd8:      	mov	x1, x0
    fcdc:      	mov	x0, #0x1                ; =1
    fce0:      	mov	x3, #0x30               ; =48
    fce4:      	mov	sp, x2
    fce8:      	str	x0, [x8]
    fcec:      	str	x1, [x8, #0x8]
    fcf0:      	str	x3, [x8, #0x10]
    fcf4:      	sub	sp, x29, #0x0
    fcf8:      	ldr	x29, [sp]
    fcfc:      	ldr	x30, [sp, #0x8]
    fd00:      	add	sp, sp, #0x10
    fd04:      	ret
    fd08:      	lsr	w0, w4, #0
    fd0c:      	str	x4, [x3]
    fd10:      	str	x5, [x3, #0x8]
    fd14:      	ubfx	x0, x0, #8, #8
    fd18:      	cmp	x0, #0x0
    fd1c:      	b.ne	0xfd30 <_stogir.stack.constant-size+0x250>
    fd20:      	movz	x4, #0x0, lsl #48
    fd24:      	b	0xfc84 <_stogir.stack.constant-size+0x1a4>
    fd28:      	movz	x5, #0x0, lsl #48
    fd2c:      	b	0xfbb8 <_stogir.stack.constant-size+0xd8>
    fd30:      	cmp	x0, #0x1
    fd34:      	b.eq	0xfc80 <_stogir.stack.constant-size+0x1a0>
    fd38:      	cmp	x0, #0x2
    fd3c:      	b.eq	0xfc80 <_stogir.stack.constant-size+0x1a0>
    fd40:      	cmp	x0, #0x7
    fd44:      	b.eq	0xfc80 <_stogir.stack.constant-size+0x1a0>
    fd48:      	cmp	x0, #0x8
    fd4c:      	b.eq	0xfc80 <_stogir.stack.constant-size+0x1a0>
    fd50:      	cmp	x0, #0x3
    fd54:      	b.eq	0xfe60 <_stogir.stack.constant-size+0x380>
    fd58:      	cmp	x0, #0x9
    fd5c:      	b.eq	0xfe60 <_stogir.stack.constant-size+0x380>
    fd60:      	cmp	x0, #0x4
    fd64:      	b.eq	0xfe70 <_stogir.stack.constant-size+0x390>
    fd68:      	cmp	x0, #0xa
    fd6c:      	b.eq	0xfe70 <_stogir.stack.constant-size+0x390>
    fd70:      	cmp	x0, #0xd
    fd74:      	b.eq	0xfe70 <_stogir.stack.constant-size+0x390>
    fd78:      	cmp	x0, #0x5
    fd7c:      	b.eq	0xfe78 <_stogir.stack.constant-size+0x398>
    fd80:      	cmp	x0, #0xb
    fd84:      	b.eq	0xfe78 <_stogir.stack.constant-size+0x398>
    fd88:      	cmp	x0, #0xc
    fd8c:      	b.eq	0xfe78 <_stogir.stack.constant-size+0x398>
    fd90:      	cmp	x0, #0x6
    fd94:      	cset	w4, eq
    fd98:      	uxtb	w16, w4
    fd9c:      	cmp	w16, wzr
    fda0:      	mov	x16, #0x8               ; =8
    fda4:      	movn	x17, #0x0, lsl #48
    fda8:      	csel	x4, x16, x17, ne
    fdac:      	b	0xfe7c <_stogir.stack.constant-size+0x39c>
    fdb0:      	movz	x5, #0x0, lsl #48
    fdb4:      	b	0xfbb0 <_stogir.stack.constant-size+0xd0>
    fdb8:      	lsr	w4, w4, #0
    fdbc:      	sxtw	x4, w4
    fdc0:      	cmp	x4, #0x0
    fdc4:      	b.le	0xfccc <_stogir.stack.constant-size+0x1ec>
    fdc8:      	ubfx	x5, x5, #0, #32
    fdcc:      	ubfx	x6, x6, #0, #32
    fdd0:      	lsl	x3, x6, #32
    fdd4:      	orr	x3, x3, x5
    fdd8:      	cmp	x4, #0x8
    fddc:      	b.ge	0xfdf8 <_stogir.stack.constant-size+0x318>
    fde0:      	lsl	x5, x4, #3
    fde4:      	lsr	w5, w5, #0
    fde8:      	sxtw	x5, w5
    fdec:      	lsr	x5, x3, x5
    fdf0:      	cmp	x5, #0x0
    fdf4:      	b.ne	0xfccc <_stogir.stack.constant-size+0x1ec>
    fdf8:      	cmp	x0, #0x7
    fdfc:      	b.lt	0xfe38 <_stogir.stack.constant-size+0x358>
    fe00:      	uxtb	w16, w1
    fe04:      	cmp	w16, wzr
    fe08:      	b.eq	0xfe38 <_stogir.stack.constant-size+0x358>
    fe0c:      	lsl	x0, x4, #3
    fe10:      	lsr	w0, w0, #0
    fe14:      	sxtw	x0, w0
    fe18:      	sub	x0, x0, #0x1
    fe1c:      	lsr	w0, w0, #0
    fe20:      	sxtw	x0, w0
    fe24:      	mov	x16, #0x1               ; =1
    fe28:      	lsl	x0, x16, x0
    fe2c:      	and	x0, x0, x3
    fe30:      	cmp	x0, #0x0
    fe34:      	b.ne	0xfccc <_stogir.stack.constant-size+0x1ec>
    fe38:      	mov	x17, #-0x10             ; =-16
    fe3c:      	movk	x17, #0x7fff, lsl #48
    fe40:      	cmp	x3, x17
    fe44:      	b.hi	0xfccc <_stogir.stack.constant-size+0x1ec>
    fe48:      	add	x0, x3, #0xf
    fe4c:      	and	x0, x0, #0xfffffffffffffff0
    fe50:      	mov	x1, x0
    fe54:      	movz	x0, #0x0, lsl #48
    fe58:      	movz	x3, #0x0, lsl #48
    fe5c:      	b	0xfce4 <_stogir.stack.constant-size+0x204>
    fe60:      	mov	x4, #0x2                ; =2
    fe64:      	b	0xfc84 <_stogir.stack.constant-size+0x1a4>
    fe68:      	brk	#0
    fe6c:      	b	0xfe68 <_stogir.stack.constant-size+0x388>
    fe70:      	mov	x4, #0x4                ; =4
    fe74:      	b	0xfe64 <_stogir.stack.constant-size+0x384>
    fe78:      	mov	x4, #0x8                ; =8
    fe7c:      	b	0xfe74 <_stogir.stack.constant-size+0x394>

000000000000fe80 <_stogir.frame.valid-alignment?>:
    fe80:      	cmp	x0, #0x0
    fe84:      	b.le	0xfea0 <_stogir.frame.valid-alignment?+0x20>
    fe88:      	sub	x1, x0, #0x1
    fe8c:      	and	x0, x1, x0
    fe90:      	cmp	x0, #0x0
    fe94:      	cset	w0, eq
    fe98:      	ubfx	x0, x0, #0, #8
    fe9c:      	b	0xfea4 <_stogir.frame.valid-alignment?+0x24>
    fea0:      	movz	x0, #0x0, lsl #48
    fea4:      	ret

000000000000fea8 <_stogir.stack.constant-size-aligned>:
    fea8:      	sub	sp, sp, #0x10
    feac:      	cmp	x2, #0x10
    feb0:      	b.lt	0xff30 <_stogir.stack.constant-size-aligned+0x88>
    feb4:      	cmp	x2, #0x0
    feb8:      	b.le	0xff30 <_stogir.stack.constant-size-aligned+0x88>
    febc:      	sub	x3, x2, #0x1
    fec0:      	and	x3, x3, x2
    fec4:      	cmp	x3, #0x0
    fec8:      	b.ne	0xff30 <_stogir.stack.constant-size-aligned+0x88>
    fecc:      	sxtw	x1, w1
    fed0:      	cmp	x1, #0x0
    fed4:      	cset	w3, gt
    fed8:      	movz	x16, #0x0, lsl #48
    fedc:      	sub	x4, x16, x1
    fee0:      	sub	x5, x4, #0x1
    fee4:      	uxtb	w16, w3
    fee8:      	cmp	w16, wzr
    feec:      	b.eq	0xffd0 <_stogir.stack.constant-size-aligned+0x128>
    fef0:      	ldr	x4, [x0, #0x8]
    fef4:      	cmp	x1, x4
    fef8:      	b.ge	0x1001c <_stogir.stack.constant-size-aligned+0x174>
    fefc:      	add	x4, x0, #0x78
    ff00:      	ldr	x4, [x4, #0x8]
    ff04:      	cmp	x1, x4
    ff08:      	b.ge	0x10118 <_stogir.stack.constant-size-aligned+0x270>
    ff0c:      	lsl	x4, x1, #2
    ff10:      	ldr	x6, [x0, #0x78]
    ff14:      	add	x4, x4, x6
    ff18:      	ldr	w4, [x4]
    ff1c:      	sxtw	x4, w4
    ff20:      	cmp	x4, #0x0
    ff24:      	cset	w4, ge
    ff28:      	ubfx	x4, x4, #0, #8
    ff2c:      	b	0x1011c <_stogir.stack.constant-size-aligned+0x274>
    ff30:      	adrp	x16, 0xf000 <_stogir.terminal.previous-input+0x200>
		000000000000ff30:  ARM64_RELOC_PAGE21	l_stogir.512
    ff34:      	ldr	x16, [x16]
		000000000000ff34:  ARM64_RELOC_PAGEOFF12	l_stogir.512
    ff38:      	orr	x0, x16, xzr
    ff3c:      	mov	x1, x0
    ff40:      	mov	x0, #0x1                ; =1
    ff44:      	mov	x2, #0x20               ; =32
    ff48:      	str	x0, [x8]
    ff4c:      	str	x1, [x8, #0x8]
    ff50:      	str	x2, [x8, #0x10]
    ff54:      	add	sp, sp, #0x10
    ff58:      	ret
    ff5c:      	mov	x3, #0x1                ; =1
    ff60:      	mov	x16, sp
    ff64:      	ldr	w4, [x16, #0x8]
    ff68:      	mov	x16, sp
    ff6c:      	ldr	w5, [x16, #0xc]
    ff70:      	cmp	x1, #0x0
    ff74:      	b.ge	0xffb4 <_stogir.stack.constant-size-aligned+0x10c>
    ff78:      	cmp	x0, #0x1
    ff7c:      	b.lt	0xffb4 <_stogir.stack.constant-size-aligned+0x10c>
    ff80:      	cmp	x0, #0xb
    ff84:      	cset	w1, le
    ff88:      	uxtb	w16, w1
    ff8c:      	cmp	w16, wzr
    ff90:      	b.eq	0xffb4 <_stogir.stack.constant-size-aligned+0x10c>
    ff94:      	mov	x16, sp
    ff98:      	ldr	w6, [x16]
    ff9c:      	uxtb	w7, w6
    ffa0:      	ubfx	x6, x6, #8, #8
    ffa4:      	cmp	x7, x6
    ffa8:      	b.eq	0x101a8 <_stogir.stack.constant-size-aligned+0x300>
    ffac:      	cmp	x7, #0x49
    ffb0:      	b.eq	0x101a8 <_stogir.stack.constant-size-aligned+0x300>
    ffb4:      	adrp	x16, 0xf000 <_stogir.terminal.previous-input+0x200>
		000000000000ffb4:  ARM64_RELOC_PAGE21	l_stogir.513
    ffb8:      	ldr	x16, [x16]
		000000000000ffb8:  ARM64_RELOC_PAGEOFF12	l_stogir.513
    ffbc:      	orr	x0, x16, xzr
    ffc0:      	mov	x1, x0
    ffc4:      	mov	x0, #0x1                ; =1
    ffc8:      	mov	x2, #0x30               ; =48
    ffcc:      	b	0xff48 <_stogir.stack.constant-size-aligned+0xa0>
    ffd0:      	cmp	x1, #0x0
    ffd4:      	b.ge	0x10024 <_stogir.stack.constant-size-aligned+0x17c>
    ffd8:      	add	x6, x0, #0x28
    ffdc:      	add	x7, x0, #0x50
    ffe0:      	ldr	x6, [x6, #0x8]
    ffe4:      	ldr	x7, [x7, #0x8]
    ffe8:      	cmp	x6, x7
    ffec:      	b.ne	0x10110 <_stogir.stack.constant-size-aligned+0x268>
    fff0:      	cmp	x4, x6
    fff4:      	b.gt	0x101a0 <_stogir.stack.constant-size-aligned+0x2f8>
    fff8:      	lsl	x4, x5, #2
    fffc:      	ldr	x6, [x0, #0x50]
   10000:      	add	x4, x4, x6
   10004:      	ldr	w4, [x4]
   10008:      	sxtw	x4, w4
   1000c:      	cmp	x4, #0x0
   10010:      	cset	w4, gt
   10014:      	ubfx	x4, x4, #0, #8
   10018:      	b	0x101a4 <_stogir.stack.constant-size-aligned+0x2fc>
   1001c:      	movz	x4, #0x0, lsl #48
   10020:      	b	0x10028 <_stogir.stack.constant-size-aligned+0x180>
   10024:      	movz	x4, #0x0, lsl #48
   10028:      	cmp	x4, #0x0
   1002c:      	b.eq	0x10090 <_stogir.stack.constant-size-aligned+0x1e8>
   10030:      	uxtb	w16, w3
   10034:      	cmp	w16, wzr
   10038:      	b.eq	0x10060 <_stogir.stack.constant-size-aligned+0x1b8>
   1003c:      	lsl	x3, x1, #4
   10040:      	ldr	x0, [x0]
   10044:      	add	x0, x3, x0
   10048:      	ldr	x3, [x0]
   1004c:      	ldr	x0, [x0, #0x8]
   10050:      	fmov	d31, x0
   10054:      	mov	x0, x3
   10058:      	fmov	x3, d31
   1005c:      	b	0x10080 <_stogir.stack.constant-size-aligned+0x1d8>
   10060:      	lsl	x3, x5, #4
   10064:      	ldr	x0, [x0, #0x28]
   10068:      	add	x0, x3, x0
   1006c:      	ldr	x3, [x0]
   10070:      	ldr	x0, [x0, #0x8]
   10074:      	fmov	d31, x0
   10078:      	mov	x0, x3
   1007c:      	fmov	x3, d31
   10080:      	mov	x4, x3
   10084:      	mov	x3, x0
   10088:      	mov	x0, #0x1                ; =1
   1008c:      	b	0x1009c <_stogir.stack.constant-size-aligned+0x1f4>
   10090:      	movz	x0, #0x0, lsl #48
   10094:      	movz	x3, #0x0, lsl #48
   10098:      	movz	x4, #0x0, lsl #48
   1009c:      	lsr	w0, w0, #0
   100a0:      	lsr	x16, x0, #0
   100a4:      	cmp	x16, #0x1
   100a8:      	b.eq	0x100c4 <_stogir.stack.constant-size-aligned+0x21c>
   100ac:      	b.lo	0x100b4 <_stogir.stack.constant-size-aligned+0x20c>
   100b0:      	b	0x100c8 <_stogir.stack.constant-size-aligned+0x220>
   100b4:      	cmp	x16, #0x0
   100b8:      	b.eq	0x100c0 <_stogir.stack.constant-size-aligned+0x218>
   100bc:      	b	0x100c8 <_stogir.stack.constant-size-aligned+0x220>
   100c0:      	b	0x100cc <_stogir.stack.constant-size-aligned+0x224>
   100c4:      	b	0x100e8 <_stogir.stack.constant-size-aligned+0x240>
   100c8:      	b	0x10268 <_stogir.stack.constant-size-aligned+0x3c0>
   100cc:      	adrp	x16, 0x10000 <_stogir.stack.constant-size-aligned+0x158>
		00000000000100cc:  ARM64_RELOC_PAGE21	l_stogir.514
   100d0:      	ldr	x16, [x16]
		00000000000100d0:  ARM64_RELOC_PAGEOFF12	l_stogir.514
   100d4:      	orr	x0, x16, xzr
   100d8:      	mov	x1, x0
   100dc:      	mov	x0, #0x1                ; =1
   100e0:      	mov	x2, #0x18               ; =24
   100e4:      	b	0xffcc <_stogir.stack.constant-size-aligned+0x124>
   100e8:      	lsr	w0, w3, #0
   100ec:      	mov	x16, sp
   100f0:      	str	x3, [x16]
   100f4:      	mov	x16, sp
   100f8:      	str	x4, [x16, #0x8]
   100fc:      	ubfx	x0, x0, #8, #8
   10100:      	cmp	x0, #0x0
   10104:      	b.ne	0x10120 <_stogir.stack.constant-size-aligned+0x278>
   10108:      	movz	x3, #0x0, lsl #48
   1010c:      	b	0xff60 <_stogir.stack.constant-size-aligned+0xb8>
   10110:      	movz	x4, #0x0, lsl #48
   10114:      	b	0x10028 <_stogir.stack.constant-size-aligned+0x180>
   10118:      	movz	x4, #0x0, lsl #48
   1011c:      	b	0x10020 <_stogir.stack.constant-size-aligned+0x178>
   10120:      	cmp	x0, #0x1
   10124:      	b.eq	0xff5c <_stogir.stack.constant-size-aligned+0xb4>
   10128:      	cmp	x0, #0x2
   1012c:      	b.eq	0xff5c <_stogir.stack.constant-size-aligned+0xb4>
   10130:      	cmp	x0, #0x7
   10134:      	b.eq	0xff5c <_stogir.stack.constant-size-aligned+0xb4>
   10138:      	cmp	x0, #0x8
   1013c:      	b.eq	0xff5c <_stogir.stack.constant-size-aligned+0xb4>
   10140:      	cmp	x0, #0x3
   10144:      	b.eq	0x10260 <_stogir.stack.constant-size-aligned+0x3b8>
   10148:      	cmp	x0, #0x9
   1014c:      	b.eq	0x10260 <_stogir.stack.constant-size-aligned+0x3b8>
   10150:      	cmp	x0, #0x4
   10154:      	b.eq	0x10270 <_stogir.stack.constant-size-aligned+0x3c8>
   10158:      	cmp	x0, #0xa
   1015c:      	b.eq	0x10270 <_stogir.stack.constant-size-aligned+0x3c8>
   10160:      	cmp	x0, #0xd
   10164:      	b.eq	0x10270 <_stogir.stack.constant-size-aligned+0x3c8>
   10168:      	cmp	x0, #0x5
   1016c:      	b.eq	0x10278 <_stogir.stack.constant-size-aligned+0x3d0>
   10170:      	cmp	x0, #0xb
   10174:      	b.eq	0x10278 <_stogir.stack.constant-size-aligned+0x3d0>
   10178:      	cmp	x0, #0xc
   1017c:      	b.eq	0x10278 <_stogir.stack.constant-size-aligned+0x3d0>
   10180:      	cmp	x0, #0x6
   10184:      	cset	w3, eq
   10188:      	uxtb	w16, w3
   1018c:      	cmp	w16, wzr
   10190:      	mov	x16, #0x8               ; =8
   10194:      	movn	x17, #0x0, lsl #48
   10198:      	csel	x3, x16, x17, ne
   1019c:      	b	0x1027c <_stogir.stack.constant-size-aligned+0x3d4>
   101a0:      	movz	x4, #0x0, lsl #48
   101a4:      	b	0x10114 <_stogir.stack.constant-size-aligned+0x26c>
   101a8:      	lsr	w3, w3, #0
   101ac:      	sxtw	x3, w3
   101b0:      	cmp	x3, #0x0
   101b4:      	b.le	0xffb4 <_stogir.stack.constant-size-aligned+0x10c>
   101b8:      	ubfx	x4, x4, #0, #32
   101bc:      	ubfx	x5, x5, #0, #32
   101c0:      	lsl	x5, x5, #32
   101c4:      	orr	x4, x5, x4
   101c8:      	cmp	x3, #0x8
   101cc:      	b.ge	0x101e8 <_stogir.stack.constant-size-aligned+0x340>
   101d0:      	lsl	x5, x3, #3
   101d4:      	lsr	w5, w5, #0
   101d8:      	sxtw	x5, w5
   101dc:      	lsr	x5, x4, x5
   101e0:      	cmp	x5, #0x0
   101e4:      	b.ne	0xffb4 <_stogir.stack.constant-size-aligned+0x10c>
   101e8:      	cmp	x0, #0x7
   101ec:      	b.lt	0x10228 <_stogir.stack.constant-size-aligned+0x380>
   101f0:      	uxtb	w16, w1
   101f4:      	cmp	w16, wzr
   101f8:      	b.eq	0x10228 <_stogir.stack.constant-size-aligned+0x380>
   101fc:      	lsl	x0, x3, #3
   10200:      	lsr	w0, w0, #0
   10204:      	sxtw	x0, w0
   10208:      	sub	x0, x0, #0x1
   1020c:      	lsr	w0, w0, #0
   10210:      	sxtw	x0, w0
   10214:      	mov	x16, #0x1               ; =1
   10218:      	lsl	x0, x16, x0
   1021c:      	and	x0, x0, x4
   10220:      	cmp	x0, #0x0
   10224:      	b.ne	0xffb4 <_stogir.stack.constant-size-aligned+0x10c>
   10228:      	sub	x0, x2, #0x1
   1022c:      	mov	x16, #0x7fffffffffffffff ; =9223372036854775807
   10230:      	sub	x0, x16, x0
   10234:      	cmp	x4, x0
   10238:      	b.hi	0xffb4 <_stogir.stack.constant-size-aligned+0x10c>
   1023c:      	sub	x0, x2, #0x1
   10240:      	movz	x16, #0x0, lsl #48
   10244:      	sub	x1, x16, x2
   10248:      	add	x0, x0, x4
   1024c:      	and	x0, x1, x0
   10250:      	mov	x1, x0
   10254:      	movz	x0, #0x0, lsl #48
   10258:      	movz	x2, #0x0, lsl #48
   1025c:      	b	0xffcc <_stogir.stack.constant-size-aligned+0x124>
   10260:      	mov	x3, #0x2                ; =2
   10264:      	b	0xff60 <_stogir.stack.constant-size-aligned+0xb8>
   10268:      	brk	#0
   1026c:      	b	0x10268 <_stogir.stack.constant-size-aligned+0x3c0>
   10270:      	mov	x3, #0x4                ; =4
   10274:      	b	0x10264 <_stogir.stack.constant-size-aligned+0x3bc>
   10278:      	mov	x3, #0x8                ; =8
   1027c:      	b	0x10274 <_stogir.stack.constant-size-aligned+0x3cc>

0000000000010280 <_stogir.numeric-conversion.operation?>:
   10280:      	sxtw	x0, w0
   10284:      	cmp	x0, #0x25
   10288:      	b.lt	0x1029c <_stogir.numeric-conversion.operation?+0x1c>
   1028c:      	cmp	x0, #0x27
   10290:      	cset	w0, le
   10294:      	ubfx	x0, x0, #0, #8
   10298:      	b	0x102a0 <_stogir.numeric-conversion.operation?+0x20>
   1029c:      	movz	x0, #0x0, lsl #48
   102a0:      	ret

00000000000102a4 <_stogir.numeric-conversion.valid-types?>:
   102a4:      	sxtw	x0, w0
   102a8:      	sxtw	x1, w1
   102ac:      	sxtw	x2, w2
   102b0:      	cmp	x2, #0xc
   102b4:      	cset	w3, eq
   102b8:      	cmp	x2, #0xd
   102bc:      	cset	w4, eq
   102c0:      	ubfx	x4, x4, #0, #8
   102c4:      	cmp	x0, #0x25
   102c8:      	b.ne	0x102f0 <_stogir.numeric-conversion.valid-types?+0x4c>
   102cc:      	cmp	x1, #0x1
   102d0:      	b.lt	0x10358 <_stogir.numeric-conversion.valid-types?+0xb4>
   102d4:      	cmp	x1, #0xb
   102d8:      	b.gt	0x10358 <_stogir.numeric-conversion.valid-types?+0xb4>
   102dc:      	uxtb	w16, w3
   102e0:      	cmp	w16, wzr
   102e4:      	b.eq	0x10368 <_stogir.numeric-conversion.valid-types?+0xc4>
   102e8:      	mov	x0, #0x1                ; =1
   102ec:      	b	0x1036c <_stogir.numeric-conversion.valid-types?+0xc8>
   102f0:      	cmp	x1, #0xc
   102f4:      	cset	w5, eq
   102f8:      	cmp	x1, #0xd
   102fc:      	cset	w1, eq
   10300:      	cmp	x0, #0x26
   10304:      	b.ne	0x10328 <_stogir.numeric-conversion.valid-types?+0x84>
   10308:      	uxtb	w16, w5
   1030c:      	cmp	w16, wzr
   10310:      	b.ne	0x10378 <_stogir.numeric-conversion.valid-types?+0xd4>
   10314:      	uxtb	w16, w1
   10318:      	cmp	w16, wzr
   1031c:      	b.ne	0x10378 <_stogir.numeric-conversion.valid-types?+0xd4>
   10320:      	movz	x0, #0x0, lsl #48
   10324:      	b	0x10354 <_stogir.numeric-conversion.valid-types?+0xb0>
   10328:      	cmp	x0, #0x27
   1032c:      	b.ne	0x10360 <_stogir.numeric-conversion.valid-types?+0xbc>
   10330:      	uxtb	w16, w5
   10334:      	cmp	w16, wzr
   10338:      	b.ne	0x10390 <_stogir.numeric-conversion.valid-types?+0xec>
   1033c:      	uxtb	w16, w1
   10340:      	cmp	w16, wzr
   10344:      	b.ne	0x10390 <_stogir.numeric-conversion.valid-types?+0xec>
   10348:      	movz	x0, #0x0, lsl #48
   1034c:      	b	0x10374 <_stogir.numeric-conversion.valid-types?+0xd0>
   10350:      	movz	x0, #0x0, lsl #48
   10354:      	b	0x10364 <_stogir.numeric-conversion.valid-types?+0xc0>
   10358:      	movz	x0, #0x0, lsl #48
   1035c:      	b	0x10364 <_stogir.numeric-conversion.valid-types?+0xc0>
   10360:      	movz	x0, #0x0, lsl #48
   10364:      	ret
   10368:      	mov	x0, x4
   1036c:      	b	0x1035c <_stogir.numeric-conversion.valid-types?+0xb8>
   10370:      	mov	x0, x4
   10374:      	b	0x10364 <_stogir.numeric-conversion.valid-types?+0xc0>
   10378:      	cmp	x2, #0x1
   1037c:      	b.lt	0x10350 <_stogir.numeric-conversion.valid-types?+0xac>
   10380:      	cmp	x2, #0xb
   10384:      	cset	w0, le
   10388:      	ubfx	x0, x0, #0, #8
   1038c:      	b	0x10354 <_stogir.numeric-conversion.valid-types?+0xb0>
   10390:      	uxtb	w16, w3
   10394:      	cmp	w16, wzr
   10398:      	b.eq	0x10370 <_stogir.numeric-conversion.valid-types?+0xcc>
   1039c:      	mov	x0, #0x1                ; =1
   103a0:      	b	0x10374 <_stogir.numeric-conversion.valid-types?+0xd0>

00000000000103a4 <_inherent$slice$new__stogir.node.Node>:
   103a4:      	sub	sp, sp, #0x10
   103a8:      	mov	x2, sp
   103ac:      	str	x0, [x2]
   103b0:      	str	x1, [x2, #0x8]
   103b4:      	ldr	x0, [sp]
   103b8:      	ldr	x1, [sp, #0x8]
   103bc:      	add	sp, sp, #0x10
   103c0:      	ret

00000000000103c4 <_inherent$slice$data__stogir.node.Node>:
   103c4:      	ret

00000000000103c8 <_coil.slice.element-ref__stogir.node.Node>:
   103c8:      	ret

00000000000103cc <_stogir.vector-lanes.ordinary?>:
   103cc:      	ldr	w0, [x0]
   103d0:      	uxtb	w0, w0
   103d4:      	cmp	x0, #0x48
   103d8:      	b.ne	0x103e4 <_stogir.vector-lanes.ordinary?+0x18>
   103dc:      	movz	x0, #0x0, lsl #48
   103e0:      	b	0x103f8 <_stogir.vector-lanes.ordinary?+0x2c>
   103e4:      	cmp	x0, #0x46
   103e8:      	cset	w0, eq
   103ec:      	uxtb	w16, w0
   103f0:      	cmp	w16, wzr
   103f4:      	cset	x0, eq
   103f8:      	ret

00000000000103fc <_stogir.vector-lanes.compatible?>:
   103fc:      	sub	sp, sp, #0x30
   10400:      	str	x29, [sp]
   10404:      	str	x30, [sp, #0x8]
   10408:      	mov	x29, sp
   1040c:      	str	x19, [sp, #0x10]
   10410:      	str	x20, [sp, #0x18]
   10414:      	str	x21, [sp, #0x20]
   10418:      	lsr	w3, w0, #0
   1041c:      	sxtw	x19, w0
   10420:      	mov	w0, w3
   10424:      	mov	w20, w1
   10428:      	mov	w21, w2
   1042c:      	bl	0x1042c <_stogir.vector-lanes.compatible?+0x30>
		000000000001042c:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
   10430:      	and	x1, x19, #0xf
   10434:      	lsr	w1, w1, #0
   10438:      	sxtw	x1, w1
   1043c:      	cmp	x0, #0x0
   10440:      	b.eq	0x1044c <_stogir.vector-lanes.compatible?+0x50>
   10444:      	mov	x0, x1
   10448:      	b	0x10450 <_stogir.vector-lanes.compatible?+0x54>
   1044c:      	movn	x0, #0x0, lsl #48
   10450:      	cmp	x19, #0xf
   10454:      	b.le	0x104a4 <_stogir.vector-lanes.compatible?+0xa8>
   10458:      	cmp	x19, #0x80
   1045c:      	b.ge	0x104a4 <_stogir.vector-lanes.compatible?+0xa8>
   10460:      	cmp	x1, #0x1
   10464:      	b.lt	0x104a4 <_stogir.vector-lanes.compatible?+0xa8>
   10468:      	cmp	x1, #0xd
   1046c:      	b.gt	0x104a4 <_stogir.vector-lanes.compatible?+0xa8>
   10470:      	sxtw	x21, w21
   10474:      	cmp	x21, #0x4
   10478:      	cset	w1, eq
   1047c:      	cmp	x21, #0x8
   10480:      	cset	w2, eq
   10484:      	uxtb	w16, w1
   10488:      	cmp	w16, wzr
   1048c:      	b.ne	0x104cc <_stogir.vector-lanes.compatible?+0xd0>
   10490:      	uxtb	w16, w2
   10494:      	cmp	w16, wzr
   10498:      	b.ne	0x104cc <_stogir.vector-lanes.compatible?+0xd0>
   1049c:      	movz	x0, #0x0, lsl #48
   104a0:      	b	0x104c8 <_stogir.vector-lanes.compatible?+0xcc>
   104a4:      	movz	x0, #0x0, lsl #48
   104a8:      	ldr	x19, [sp, #0x10]
   104ac:      	ldr	x20, [sp, #0x18]
   104b0:      	ldr	x21, [sp, #0x20]
   104b4:      	ldr	x29, [sp]
   104b8:      	ldr	x30, [sp, #0x8]
   104bc:      	add	sp, sp, #0x30
   104c0:      	ret
   104c4:      	movz	x0, #0x0, lsl #48
   104c8:      	b	0x104a8 <_stogir.vector-lanes.compatible?+0xac>
   104cc:      	sxtw	x20, w20
   104d0:      	cmp	x20, #0x0
   104d4:      	b.lt	0x104c4 <_stogir.vector-lanes.compatible?+0xc8>
   104d8:      	cmp	x20, #0xd
   104dc:      	b.gt	0x104c4 <_stogir.vector-lanes.compatible?+0xc8>
   104e0:      	cmp	x20, #0x0
   104e4:      	b.le	0x10500 <_stogir.vector-lanes.compatible?+0x104>
   104e8:      	lsr	w0, w0, #0
   104ec:      	sxtw	x0, w0
   104f0:      	cmp	x0, x20
   104f4:      	b.ne	0x10508 <_stogir.vector-lanes.compatible?+0x10c>
   104f8:      	mov	x0, #0x1                ; =1
   104fc:      	b	0x10504 <_stogir.vector-lanes.compatible?+0x108>
   10500:      	movz	x0, #0x0, lsl #48
   10504:      	b	0x104c8 <_stogir.vector-lanes.compatible?+0xcc>
   10508:      	cmp	x0, #0x1
   1050c:      	b.lt	0x10548 <_stogir.vector-lanes.compatible?+0x14c>
   10510:      	cmp	x0, #0xb
   10514:      	b.gt	0x10548 <_stogir.vector-lanes.compatible?+0x14c>
   10518:      	cmp	x20, #0x1
   1051c:      	b.lt	0x10550 <_stogir.vector-lanes.compatible?+0x154>
   10520:      	cmp	x20, #0xb
   10524:      	b.gt	0x10550 <_stogir.vector-lanes.compatible?+0x154>
   10528:      	uxtb	w16, w1
   1052c:      	cmp	w16, wzr
   10530:      	b.ne	0x1057c <_stogir.vector-lanes.compatible?+0x180>
   10534:      	uxtb	w16, w2
   10538:      	cmp	w16, wzr
   1053c:      	b.ne	0x1057c <_stogir.vector-lanes.compatible?+0x180>
   10540:      	movn	x0, #0x0, lsl #48
   10544:      	b	0x10590 <_stogir.vector-lanes.compatible?+0x194>
   10548:      	movz	x0, #0x0, lsl #48
   1054c:      	b	0x104fc <_stogir.vector-lanes.compatible?+0x100>
   10550:      	movz	x0, #0x0, lsl #48
   10554:      	b	0x1054c <_stogir.vector-lanes.compatible?+0x150>
   10558:      	mov	x1, #0x1                ; =1
   1055c:      	lsr	w0, w0, #0
   10560:      	sxtw	x0, w0
   10564:      	lsr	w1, w1, #0
   10568:      	sxtw	x1, w1
   1056c:      	cmp	x0, x1
   10570:      	cset	w0, eq
   10574:      	ubfx	x0, x0, #0, #8
   10578:      	b	0x10554 <_stogir.vector-lanes.compatible?+0x158>
   1057c:      	cmp	x0, #0x0
   10580:      	b.ne	0x10630 <_stogir.vector-lanes.compatible?+0x234>
   10584:      	movz	x0, #0x0, lsl #48
   10588:      	b	0x10590 <_stogir.vector-lanes.compatible?+0x194>
   1058c:      	mov	x0, #0x1                ; =1
   10590:      	uxtb	w16, w1
   10594:      	cmp	w16, wzr
   10598:      	b.ne	0x105b0 <_stogir.vector-lanes.compatible?+0x1b4>
   1059c:      	uxtb	w16, w2
   105a0:      	cmp	w16, wzr
   105a4:      	b.ne	0x105b0 <_stogir.vector-lanes.compatible?+0x1b4>
   105a8:      	movn	x1, #0x0, lsl #48
   105ac:      	b	0x1055c <_stogir.vector-lanes.compatible?+0x160>
   105b0:      	cmp	x20, #0x0
   105b4:      	b.ne	0x105c0 <_stogir.vector-lanes.compatible?+0x1c4>
   105b8:      	movz	x1, #0x0, lsl #48
   105bc:      	b	0x1055c <_stogir.vector-lanes.compatible?+0x160>
   105c0:      	cmp	x20, #0x1
   105c4:      	b.eq	0x10558 <_stogir.vector-lanes.compatible?+0x15c>
   105c8:      	cmp	x20, #0x2
   105cc:      	b.eq	0x10558 <_stogir.vector-lanes.compatible?+0x15c>
   105d0:      	cmp	x20, #0x7
   105d4:      	b.eq	0x10558 <_stogir.vector-lanes.compatible?+0x15c>
   105d8:      	cmp	x20, #0x8
   105dc:      	b.eq	0x10558 <_stogir.vector-lanes.compatible?+0x15c>
   105e0:      	cmp	x20, #0x3
   105e4:      	b.eq	0x106a0 <_stogir.vector-lanes.compatible?+0x2a4>
   105e8:      	cmp	x20, #0x9
   105ec:      	b.eq	0x106a0 <_stogir.vector-lanes.compatible?+0x2a4>
   105f0:      	cmp	x20, #0x4
   105f4:      	b.eq	0x106b0 <_stogir.vector-lanes.compatible?+0x2b4>
   105f8:      	cmp	x20, #0xa
   105fc:      	b.eq	0x106b0 <_stogir.vector-lanes.compatible?+0x2b4>
   10600:      	cmp	x20, #0xd
   10604:      	b.eq	0x106b0 <_stogir.vector-lanes.compatible?+0x2b4>
   10608:      	cmp	x20, #0x5
   1060c:      	b.eq	0x106c0 <_stogir.vector-lanes.compatible?+0x2c4>
   10610:      	cmp	x20, #0xb
   10614:      	b.eq	0x106c0 <_stogir.vector-lanes.compatible?+0x2c4>
   10618:      	cmp	x20, #0xc
   1061c:      	b.eq	0x106c0 <_stogir.vector-lanes.compatible?+0x2c4>
   10620:      	cmp	x20, #0x6
   10624:      	b.ne	0x106d0 <_stogir.vector-lanes.compatible?+0x2d4>
   10628:      	mov	x1, x21
   1062c:      	b	0x106d4 <_stogir.vector-lanes.compatible?+0x2d8>
   10630:      	cmp	x0, #0x1
   10634:      	b.eq	0x1058c <_stogir.vector-lanes.compatible?+0x190>
   10638:      	cmp	x0, #0x2
   1063c:      	b.eq	0x1058c <_stogir.vector-lanes.compatible?+0x190>
   10640:      	cmp	x0, #0x7
   10644:      	b.eq	0x1058c <_stogir.vector-lanes.compatible?+0x190>
   10648:      	cmp	x0, #0x8
   1064c:      	b.eq	0x1058c <_stogir.vector-lanes.compatible?+0x190>
   10650:      	cmp	x0, #0x3
   10654:      	b.eq	0x106a8 <_stogir.vector-lanes.compatible?+0x2ac>
   10658:      	cmp	x0, #0x9
   1065c:      	b.eq	0x106a8 <_stogir.vector-lanes.compatible?+0x2ac>
   10660:      	cmp	x0, #0x4
   10664:      	b.eq	0x106b8 <_stogir.vector-lanes.compatible?+0x2bc>
   10668:      	cmp	x0, #0xa
   1066c:      	b.eq	0x106b8 <_stogir.vector-lanes.compatible?+0x2bc>
   10670:      	cmp	x0, #0xd
   10674:      	b.eq	0x106b8 <_stogir.vector-lanes.compatible?+0x2bc>
   10678:      	cmp	x0, #0x5
   1067c:      	b.eq	0x106c8 <_stogir.vector-lanes.compatible?+0x2cc>
   10680:      	cmp	x0, #0xb
   10684:      	b.eq	0x106c8 <_stogir.vector-lanes.compatible?+0x2cc>
   10688:      	cmp	x0, #0xc
   1068c:      	b.eq	0x106c8 <_stogir.vector-lanes.compatible?+0x2cc>
   10690:      	cmp	x0, #0x6
   10694:      	b.ne	0x106d8 <_stogir.vector-lanes.compatible?+0x2dc>
   10698:      	mov	x0, x21
   1069c:      	b	0x106dc <_stogir.vector-lanes.compatible?+0x2e0>
   106a0:      	mov	x1, #0x2                ; =2
   106a4:      	b	0x1055c <_stogir.vector-lanes.compatible?+0x160>
   106a8:      	mov	x0, #0x2                ; =2
   106ac:      	b	0x10590 <_stogir.vector-lanes.compatible?+0x194>
   106b0:      	mov	x1, #0x4                ; =4
   106b4:      	b	0x106a4 <_stogir.vector-lanes.compatible?+0x2a8>
   106b8:      	mov	x0, #0x4                ; =4
   106bc:      	b	0x106ac <_stogir.vector-lanes.compatible?+0x2b0>
   106c0:      	mov	x1, #0x8                ; =8
   106c4:      	b	0x106b4 <_stogir.vector-lanes.compatible?+0x2b8>
   106c8:      	mov	x0, #0x8                ; =8
   106cc:      	b	0x106bc <_stogir.vector-lanes.compatible?+0x2c0>
   106d0:      	movn	x1, #0x0, lsl #48
   106d4:      	b	0x106c4 <_stogir.vector-lanes.compatible?+0x2c8>
   106d8:      	movn	x0, #0x0, lsl #48
   106dc:      	b	0x106cc <_stogir.vector-lanes.compatible?+0x2d0>

00000000000106e0 <_stogir.symbols.numeric?>:
   106e0:      	ldr	w0, [x0]
   106e4:      	uxtb	w1, w0
   106e8:      	ubfx	x0, x0, #8, #8
   106ec:      	cmp	x1, x0
   106f0:      	b.ne	0x106fc <_stogir.symbols.numeric?+0x1c>
   106f4:      	mov	x0, #0x1                ; =1
   106f8:      	b	0x10708 <_stogir.symbols.numeric?+0x28>
   106fc:      	cmp	x1, #0x49
   10700:      	cset	w0, eq
   10704:      	ubfx	x0, x0, #0, #8
   10708:      	ret

000000000001070c <_stogir.node.constant-bits>:
   1070c:      	ldr	w1, [x0, #0x8]
   10710:      	ubfx	x1, x1, #0, #32
   10714:      	ldr	w0, [x0, #0xc]
   10718:      	ubfx	x0, x0, #0, #32
   1071c:      	lsl	x0, x0, #32
   10720:      	orr	x0, x0, x1
   10724:      	ret

0000000000010728 <_stogir.vector-comparison.valid-type?>:
   10728:      	sub	sp, sp, #0x30
   1072c:      	str	x29, [sp]
   10730:      	str	x30, [sp, #0x8]
   10734:      	mov	x29, sp
   10738:      	str	x19, [sp, #0x10]
   1073c:      	str	x20, [sp, #0x18]
   10740:      	str	x21, [sp, #0x20]
   10744:      	sxtw	x19, w0
   10748:      	cmp	x19, #0xe
   1074c:      	b.lt	0x107a4 <_stogir.vector-comparison.valid-type?+0x7c>
   10750:      	cmp	x19, #0x19
   10754:      	b.gt	0x107a4 <_stogir.vector-comparison.valid-type?+0x7c>
   10758:      	sxtw	x0, w1
   1075c:      	cmp	x0, #0xf
   10760:      	b.le	0x107c4 <_stogir.vector-comparison.valid-type?+0x9c>
   10764:      	cmp	x0, #0x80
   10768:      	b.ge	0x107c4 <_stogir.vector-comparison.valid-type?+0x9c>
   1076c:      	and	x0, x0, #0xf
   10770:      	lsr	w0, w0, #0
   10774:      	sxtw	x20, w0
   10778:      	cmp	x20, #0x1
   1077c:      	b.lt	0x107c4 <_stogir.vector-comparison.valid-type?+0x9c>
   10780:      	cmp	x20, #0xd
   10784:      	b.gt	0x107c4 <_stogir.vector-comparison.valid-type?+0x9c>
   10788:      	lsr	w21, w1, #0
   1078c:      	mov	w0, w21
   10790:      	bl	0x10790 <_stogir.vector-comparison.valid-type?+0x68>
		0000000000010790:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
   10794:      	cmp	x0, #0x0
   10798:      	b.eq	0x107d4 <_stogir.vector-comparison.valid-type?+0xac>
   1079c:      	mov	x0, x20
   107a0:      	b	0x107d8 <_stogir.vector-comparison.valid-type?+0xb0>
   107a4:      	movz	x0, #0x0, lsl #48
   107a8:      	ldr	x19, [sp, #0x10]
   107ac:      	ldr	x20, [sp, #0x18]
   107b0:      	ldr	x21, [sp, #0x20]
   107b4:      	ldr	x29, [sp]
   107b8:      	ldr	x30, [sp, #0x8]
   107bc:      	add	sp, sp, #0x30
   107c0:      	ret
   107c4:      	movz	x0, #0x0, lsl #48
   107c8:      	b	0x107a8 <_stogir.vector-comparison.valid-type?+0x80>
   107cc:      	mov	x0, #0x1                ; =1
   107d0:      	b	0x107c8 <_stogir.vector-comparison.valid-type?+0xa0>
   107d4:      	movn	x0, #0x0, lsl #48
   107d8:      	lsr	w0, w0, #0
   107dc:      	sxtw	x0, w0
   107e0:      	cmp	x0, #0xc
   107e4:      	b.eq	0x107cc <_stogir.vector-comparison.valid-type?+0xa4>
   107e8:      	cmp	x0, #0xd
   107ec:      	b.eq	0x107cc <_stogir.vector-comparison.valid-type?+0xa4>
   107f0:      	mov	w0, w21
   107f4:      	bl	0x107f4 <_stogir.vector-comparison.valid-type?+0xcc>
		00000000000107f4:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
   107f8:      	cmp	x0, #0x0
   107fc:      	b.eq	0x10810 <_stogir.vector-comparison.valid-type?+0xe8>
   10800:      	mov	x0, x20
   10804:      	b	0x10814 <_stogir.vector-comparison.valid-type?+0xec>
   10808:      	movz	x0, #0x0, lsl #48
   1080c:      	b	0x107d0 <_stogir.vector-comparison.valid-type?+0xa8>
   10810:      	movn	x0, #0x0, lsl #48
   10814:      	lsr	w0, w0, #0
   10818:      	sxtw	x0, w0
   1081c:      	cmp	x0, #0x1
   10820:      	b.lt	0x10808 <_stogir.vector-comparison.valid-type?+0xe0>
   10824:      	cmp	x0, #0xb
   10828:      	b.gt	0x10808 <_stogir.vector-comparison.valid-type?+0xe0>
   1082c:      	cmp	x19, #0x17
   10830:      	cset	w0, le
   10834:      	ubfx	x0, x0, #0, #8
   10838:      	b	0x1080c <_stogir.vector-comparison.valid-type?+0xe4>

000000000001083c <_stogir.vector-arithmetic.extrema?>:
   1083c:      	sxtw	x0, w0
   10840:      	cmp	x0, #0x3a
   10844:      	b.ne	0x10850 <_stogir.vector-arithmetic.extrema?+0x14>
   10848:      	mov	x0, #0x1                ; =1
   1084c:      	b	0x1085c <_stogir.vector-arithmetic.extrema?+0x20>
   10850:      	cmp	x0, #0x3b
   10854:      	cset	w0, eq
   10858:      	ubfx	x0, x0, #0, #8
   1085c:      	ret

0000000000010860 <_stogir.vector-arithmetic.shift?>:
   10860:      	sxtw	x0, w0
   10864:      	cmp	x0, #0x31
   10868:      	b.lt	0x1087c <_stogir.vector-arithmetic.shift?+0x1c>
   1086c:      	cmp	x0, #0x35
   10870:      	cset	w0, le
   10874:      	ubfx	x0, x0, #0, #8
   10878:      	b	0x10880 <_stogir.vector-arithmetic.shift?+0x20>
   1087c:      	movz	x0, #0x0, lsl #48
   10880:      	ret

0000000000010884 <_stogir.vector-arithmetic.valid-type?>:
   10884:      	sub	sp, sp, #0x40
   10888:      	str	x29, [sp]
   1088c:      	str	x30, [sp, #0x8]
   10890:      	mov	x29, sp
   10894:      	str	x19, [sp, #0x10]
   10898:      	str	x20, [sp, #0x18]
   1089c:      	str	x21, [sp, #0x20]
   108a0:      	str	x22, [sp, #0x28]
   108a4:      	str	x23, [sp, #0x30]
   108a8:      	lsr	w2, w1, #0
   108ac:      	sxtw	x19, w1
   108b0:      	mov	w20, w0
   108b4:      	mov	w0, w2
   108b8:      	bl	0x108b8 <_stogir.vector-arithmetic.valid-type?+0x34>
		00000000000108b8:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
   108bc:      	and	x1, x19, #0xf
   108c0:      	lsr	w1, w1, #0
   108c4:      	sxtw	x1, w1
   108c8:      	cmp	x0, #0x0
   108cc:      	b.eq	0x108d8 <_stogir.vector-arithmetic.valid-type?+0x54>
   108d0:      	mov	x0, x1
   108d4:      	b	0x108dc <_stogir.vector-arithmetic.valid-type?+0x58>
   108d8:      	movn	x0, #0x0, lsl #48
   108dc:      	cmp	x19, #0xf
   108e0:      	b.le	0x10ac0 <_stogir.vector-arithmetic.valid-type?+0x23c>
   108e4:      	cmp	x19, #0x80
   108e8:      	b.ge	0x10ac0 <_stogir.vector-arithmetic.valid-type?+0x23c>
   108ec:      	cmp	x1, #0x1
   108f0:      	b.lt	0x10ac0 <_stogir.vector-arithmetic.valid-type?+0x23c>
   108f4:      	cmp	x1, #0xd
   108f8:      	b.gt	0x10ac0 <_stogir.vector-arithmetic.valid-type?+0x23c>
   108fc:      	sxtw	x1, w20
   10900:      	cmp	x1, #0x1f
   10904:      	cset	w19, eq
   10908:      	cmp	x1, #0x20
   1090c:      	cset	w21, eq
   10910:      	cmp	x1, #0x2e
   10914:      	cset	w2, eq
   10918:      	cmp	x1, #0x2f
   1091c:      	cset	w3, eq
   10920:      	cmp	x1, #0x30
   10924:      	cset	w4, eq
   10928:      	cmp	x1, #0x1e
   1092c:      	cset	w5, eq
   10930:      	cmp	x1, #0x31
   10934:      	cset	w6, ge
   10938:      	cmp	x1, #0x35
   1093c:      	cset	w7, le
   10940:      	cmp	x1, #0x3a
   10944:      	cset	w8, eq
   10948:      	cmp	x1, #0x3b
   1094c:      	cset	w9, eq
   10950:      	cmp	x1, #0x2d
   10954:      	cset	w10, eq
   10958:      	cmp	x1, #0x36
   1095c:      	cset	w11, eq
   10960:      	cmp	x1, #0x37
   10964:      	cset	w12, eq
   10968:      	cmp	x1, #0x38
   1096c:      	cset	w13, eq
   10970:      	cmp	x1, #0x39
   10974:      	cset	w14, eq
   10978:      	uxtb	w16, w19
   1097c:      	cmp	w16, wzr
   10980:      	b.ne	0x109fc <_stogir.vector-arithmetic.valid-type?+0x178>
   10984:      	uxtb	w16, w21
   10988:      	cmp	w16, wzr
   1098c:      	b.ne	0x109fc <_stogir.vector-arithmetic.valid-type?+0x178>
   10990:      	uxtb	w16, w10
   10994:      	cmp	w16, wzr
   10998:      	b.ne	0x109fc <_stogir.vector-arithmetic.valid-type?+0x178>
   1099c:      	uxtb	w16, w11
   109a0:      	cmp	w16, wzr
   109a4:      	b.ne	0x109fc <_stogir.vector-arithmetic.valid-type?+0x178>
   109a8:      	uxtb	w16, w12
   109ac:      	cmp	w16, wzr
   109b0:      	b.ne	0x109fc <_stogir.vector-arithmetic.valid-type?+0x178>
   109b4:      	uxtb	w16, w13
   109b8:      	cmp	w16, wzr
   109bc:      	b.ne	0x109fc <_stogir.vector-arithmetic.valid-type?+0x178>
   109c0:      	uxtb	w16, w14
   109c4:      	cmp	w16, wzr
   109c8:      	b.ne	0x109fc <_stogir.vector-arithmetic.valid-type?+0x178>
   109cc:      	uxtb	w16, w8
   109d0:      	cmp	w16, wzr
   109d4:      	b.ne	0x109fc <_stogir.vector-arithmetic.valid-type?+0x178>
   109d8:      	uxtb	w16, w9
   109dc:      	cmp	w16, wzr
   109e0:      	b.ne	0x109fc <_stogir.vector-arithmetic.valid-type?+0x178>
   109e4:      	uxtb	w16, w6
   109e8:      	cmp	w16, wzr
   109ec:      	b.eq	0x10be8 <_stogir.vector-arithmetic.valid-type?+0x364>
   109f0:      	uxtb	w16, w7
   109f4:      	cmp	w16, wzr
   109f8:      	b.eq	0x10be8 <_stogir.vector-arithmetic.valid-type?+0x364>
   109fc:      	lsr	w0, w0, #0
   10a00:      	sxtw	x1, w0
   10a04:      	cmp	x1, #0xc
   10a08:      	cset	w22, eq
   10a0c:      	cmp	x1, #0xd
   10a10:      	cset	w23, eq
   10a14:      	uxtb	w16, w19
   10a18:      	cmp	w16, wzr
   10a1c:      	b.ne	0x10af4 <_stogir.vector-arithmetic.valid-type?+0x270>
   10a20:      	uxtb	w16, w21
   10a24:      	cmp	w16, wzr
   10a28:      	b.ne	0x10af4 <_stogir.vector-arithmetic.valid-type?+0x270>
   10a2c:      	uxtb	w16, w10
   10a30:      	cmp	w16, wzr
   10a34:      	b.ne	0x10af4 <_stogir.vector-arithmetic.valid-type?+0x270>
   10a38:      	uxtb	w16, w11
   10a3c:      	cmp	w16, wzr
   10a40:      	b.ne	0x10af4 <_stogir.vector-arithmetic.valid-type?+0x270>
   10a44:      	uxtb	w16, w12
   10a48:      	cmp	w16, wzr
   10a4c:      	b.ne	0x10af4 <_stogir.vector-arithmetic.valid-type?+0x270>
   10a50:      	uxtb	w16, w13
   10a54:      	cmp	w16, wzr
   10a58:      	b.ne	0x10af4 <_stogir.vector-arithmetic.valid-type?+0x270>
   10a5c:      	uxtb	w16, w14
   10a60:      	cmp	w16, wzr
   10a64:      	b.ne	0x10af4 <_stogir.vector-arithmetic.valid-type?+0x270>
   10a68:      	cmp	x1, #0x1
   10a6c:      	cset	w0, eq
   10a70:      	cmp	x1, #0x1
   10a74:      	cset	w10, ge
   10a78:      	cmp	x1, #0xb
   10a7c:      	cset	w1, le
   10a80:      	uxtb	w16, w6
   10a84:      	cmp	w16, wzr
   10a88:      	b.eq	0x10b54 <_stogir.vector-arithmetic.valid-type?+0x2d0>
   10a8c:      	uxtb	w16, w7
   10a90:      	cmp	w16, wzr
   10a94:      	b.eq	0x10b54 <_stogir.vector-arithmetic.valid-type?+0x2d0>
   10a98:      	uxtb	w16, w10
   10a9c:      	cmp	w16, wzr
   10aa0:      	b.eq	0x10be0 <_stogir.vector-arithmetic.valid-type?+0x35c>
   10aa4:      	uxtb	w16, w1
   10aa8:      	cmp	w16, wzr
   10aac:      	b.eq	0x10be0 <_stogir.vector-arithmetic.valid-type?+0x35c>
   10ab0:      	uxtb	w16, w0
   10ab4:      	cmp	w16, wzr
   10ab8:      	cset	x0, eq
   10abc:      	b	0x10be4 <_stogir.vector-arithmetic.valid-type?+0x360>
   10ac0:      	movz	x0, #0x0, lsl #48
   10ac4:      	ldr	x19, [sp, #0x10]
   10ac8:      	ldr	x20, [sp, #0x18]
   10acc:      	ldr	x21, [sp, #0x20]
   10ad0:      	ldr	x22, [sp, #0x28]
   10ad4:      	ldr	x23, [sp, #0x30]
   10ad8:      	ldr	x29, [sp]
   10adc:      	ldr	x30, [sp, #0x8]
   10ae0:      	add	sp, sp, #0x40
   10ae4:      	ret
   10ae8:      	ubfx	x21, x21, #0, #8
   10aec:      	mov	x0, x21
   10af0:      	b	0x10ac4 <_stogir.vector-arithmetic.valid-type?+0x240>
   10af4:      	lsr	w20, w20, #0
   10af8:      	lsr	w0, w0, #0
   10afc:      	mov	w1, w0
   10b00:      	mov	w0, w20
   10b04:      	bl	0x10b04 <_stogir.vector-arithmetic.valid-type?+0x280>
		0000000000010b04:  ARM64_RELOC_BRANCH26	_stogir.integer-unary.valid-type?
   10b08:      	cmp	x0, #0x0
   10b0c:      	b.eq	0x10b18 <_stogir.vector-arithmetic.valid-type?+0x294>
   10b10:      	mov	x0, #0x1                ; =1
   10b14:      	b	0x10af0 <_stogir.vector-arithmetic.valid-type?+0x26c>
   10b18:      	uxtb	w16, w22
   10b1c:      	cmp	w16, wzr
   10b20:      	b.ne	0x10b38 <_stogir.vector-arithmetic.valid-type?+0x2b4>
   10b24:      	uxtb	w16, w23
   10b28:      	cmp	w16, wzr
   10b2c:      	b.ne	0x10b38 <_stogir.vector-arithmetic.valid-type?+0x2b4>
   10b30:      	movz	x0, #0x0, lsl #48
   10b34:      	b	0x10af0 <_stogir.vector-arithmetic.valid-type?+0x26c>
   10b38:      	uxtb	w16, w19
   10b3c:      	cmp	w16, wzr
   10b40:      	b.eq	0x10ae8 <_stogir.vector-arithmetic.valid-type?+0x264>
   10b44:      	mov	x0, #0x1                ; =1
   10b48:      	b	0x10af0 <_stogir.vector-arithmetic.valid-type?+0x26c>
   10b4c:      	movz	x0, #0x0, lsl #48
   10b50:      	b	0x10af0 <_stogir.vector-arithmetic.valid-type?+0x26c>
   10b54:      	uxtb	w16, w2
   10b58:      	cmp	w16, wzr
   10b5c:      	b.ne	0x10bc8 <_stogir.vector-arithmetic.valid-type?+0x344>
   10b60:      	uxtb	w16, w3
   10b64:      	cmp	w16, wzr
   10b68:      	b.ne	0x10bc8 <_stogir.vector-arithmetic.valid-type?+0x344>
   10b6c:      	uxtb	w16, w4
   10b70:      	cmp	w16, wzr
   10b74:      	b.ne	0x10bc8 <_stogir.vector-arithmetic.valid-type?+0x344>
   10b78:      	uxtb	w16, w22
   10b7c:      	cmp	w16, wzr
   10b80:      	b.ne	0x10c40 <_stogir.vector-arithmetic.valid-type?+0x3bc>
   10b84:      	uxtb	w16, w23
   10b88:      	cmp	w16, wzr
   10b8c:      	b.ne	0x10c40 <_stogir.vector-arithmetic.valid-type?+0x3bc>
   10b90:      	uxtb	w16, w10
   10b94:      	cmp	w16, wzr
   10b98:      	b.eq	0x10c50 <_stogir.vector-arithmetic.valid-type?+0x3cc>
   10b9c:      	uxtb	w16, w1
   10ba0:      	cmp	w16, wzr
   10ba4:      	b.eq	0x10c50 <_stogir.vector-arithmetic.valid-type?+0x3cc>
   10ba8:      	uxtb	w16, w0
   10bac:      	cmp	w16, wzr
   10bb0:      	b.eq	0x10c58 <_stogir.vector-arithmetic.valid-type?+0x3d4>
   10bb4:      	uxtb	w16, w8
   10bb8:      	cmp	w16, wzr
   10bbc:      	b.eq	0x10c60 <_stogir.vector-arithmetic.valid-type?+0x3dc>
   10bc0:      	mov	x0, #0x1                ; =1
   10bc4:      	b	0x10c68 <_stogir.vector-arithmetic.valid-type?+0x3e4>
   10bc8:      	uxtb	w16, w10
   10bcc:      	cmp	w16, wzr
   10bd0:      	b.eq	0x10b4c <_stogir.vector-arithmetic.valid-type?+0x2c8>
   10bd4:      	ubfx	x1, x1, #0, #8
   10bd8:      	mov	x0, x1
   10bdc:      	b	0x10b50 <_stogir.vector-arithmetic.valid-type?+0x2cc>
   10be0:      	movz	x0, #0x0, lsl #48
   10be4:      	b	0x10b50 <_stogir.vector-arithmetic.valid-type?+0x2cc>
   10be8:      	cmp	x1, #0x1a
   10bec:      	b.eq	0x109fc <_stogir.vector-arithmetic.valid-type?+0x178>
   10bf0:      	cmp	x1, #0x1b
   10bf4:      	b.eq	0x109fc <_stogir.vector-arithmetic.valid-type?+0x178>
   10bf8:      	cmp	x1, #0x1c
   10bfc:      	b.eq	0x109fc <_stogir.vector-arithmetic.valid-type?+0x178>
   10c00:      	cmp	x1, #0x1d
   10c04:      	b.eq	0x109fc <_stogir.vector-arithmetic.valid-type?+0x178>
   10c08:      	uxtb	w16, w5
   10c0c:      	cmp	w16, wzr
   10c10:      	b.ne	0x109fc <_stogir.vector-arithmetic.valid-type?+0x178>
   10c14:      	uxtb	w16, w2
   10c18:      	cmp	w16, wzr
   10c1c:      	b.ne	0x109fc <_stogir.vector-arithmetic.valid-type?+0x178>
   10c20:      	uxtb	w16, w3
   10c24:      	cmp	w16, wzr
   10c28:      	b.ne	0x109fc <_stogir.vector-arithmetic.valid-type?+0x178>
   10c2c:      	uxtb	w16, w4
   10c30:      	cmp	w16, wzr
   10c34:      	b.ne	0x109fc <_stogir.vector-arithmetic.valid-type?+0x178>
   10c38:      	movz	x0, #0x0, lsl #48
   10c3c:      	b	0x10af0 <_stogir.vector-arithmetic.valid-type?+0x26c>
   10c40:      	uxtb	w16, w5
   10c44:      	cmp	w16, wzr
   10c48:      	cset	x0, eq
   10c4c:      	b	0x10b50 <_stogir.vector-arithmetic.valid-type?+0x2cc>
   10c50:      	movz	x0, #0x0, lsl #48
   10c54:      	b	0x10c4c <_stogir.vector-arithmetic.valid-type?+0x3c8>
   10c58:      	mov	x0, #0x1                ; =1
   10c5c:      	b	0x10c54 <_stogir.vector-arithmetic.valid-type?+0x3d0>
   10c60:      	ubfx	x9, x9, #0, #8
   10c64:      	mov	x0, x9
   10c68:      	b	0x10c5c <_stogir.vector-arithmetic.valid-type?+0x3d8>

0000000000010c6c <_coil.core.Len$slice$len__i32>:
   10c6c:      	mov	x0, x1
   10c70:      	ret

0000000000010c74 <_inherent$slice$data__i32>:
   10c74:      	ret

0000000000010c78 <_stogir.opcode.terminator?>:
   10c78:      	sxtw	x0, w0
   10c7c:      	cmp	x0, #0x0
   10c80:      	b.lt	0x10ca8 <_stogir.opcode.terminator?+0x30>
   10c84:      	cmp	x0, #0x83
   10c88:      	b.ge	0x10ca8 <_stogir.opcode.terminator?+0x30>
   10c8c:      	adrp	x16, 0x10000 <_stogir.stack.constant-size-aligned+0x158>
		0000000000010c8c:  ARM64_RELOC_PAGE21	l_stogir.515
   10c90:      	ldr	x16, [x16]
		0000000000010c90:  ARM64_RELOC_PAGEOFF12	l_stogir.515
   10c94:      	orr	x1, x16, xzr
   10c98:      	lsr	x0, x0, #0
   10c9c:      	add	x0, x0, x1
   10ca0:      	ldrb	w0, [x0]
   10ca4:      	b	0x10cac <_stogir.opcode.terminator?+0x34>
   10ca8:      	movz	x0, #0x0, lsl #48
   10cac:      	uxtb	w0, w0
   10cb0:      	and	x0, x0, #0x8
   10cb4:      	uxtb	w0, w0
   10cb8:      	cmp	x0, #0x0
   10cbc:      	cset	w0, eq
   10cc0:      	uxtb	w16, w0
   10cc4:      	cmp	w16, wzr
   10cc8:      	cset	x0, eq
   10ccc:      	ret

0000000000010cd0 <_stogir.switch.sign-mask>:
   10cd0:      	sxtw	x0, w0
   10cd4:      	cmp	x0, #0x7
   10cd8:      	b.lt	0x10cf4 <_stogir.switch.sign-mask+0x24>
   10cdc:      	cmp	x0, #0xb
   10ce0:      	b.gt	0x10cf4 <_stogir.switch.sign-mask+0x24>
   10ce4:      	cmp	x0, #0x0
   10ce8:      	b.ne	0x10d2c <_stogir.switch.sign-mask+0x5c>
   10cec:      	movz	x0, #0x0, lsl #48
   10cf0:      	b	0x10d00 <_stogir.switch.sign-mask+0x30>
   10cf4:      	movz	x0, #0x0, lsl #48
   10cf8:      	ret
   10cfc:      	mov	x0, #0x1                ; =1
   10d00:      	lsr	w0, w0, #0
   10d04:      	sxtw	x0, w0
   10d08:      	lsl	x0, x0, #3
   10d0c:      	lsr	w0, w0, #0
   10d10:      	sxtw	x0, w0
   10d14:      	sub	x0, x0, #0x1
   10d18:      	lsr	w0, w0, #0
   10d1c:      	sxtw	x0, w0
   10d20:      	mov	x16, #0x1               ; =1
   10d24:      	lsl	x0, x16, x0
   10d28:      	b	0x10cf8 <_stogir.switch.sign-mask+0x28>
   10d2c:      	cmp	x0, #0x1
   10d30:      	b.eq	0x10cfc <_stogir.switch.sign-mask+0x2c>
   10d34:      	cmp	x0, #0x2
   10d38:      	b.eq	0x10cfc <_stogir.switch.sign-mask+0x2c>
   10d3c:      	cmp	x0, #0x7
   10d40:      	b.eq	0x10cfc <_stogir.switch.sign-mask+0x2c>
   10d44:      	cmp	x0, #0x8
   10d48:      	b.eq	0x10cfc <_stogir.switch.sign-mask+0x2c>
   10d4c:      	cmp	x0, #0x3
   10d50:      	b.eq	0x10dac <_stogir.switch.sign-mask+0xdc>
   10d54:      	cmp	x0, #0x9
   10d58:      	b.eq	0x10dac <_stogir.switch.sign-mask+0xdc>
   10d5c:      	cmp	x0, #0x4
   10d60:      	b.eq	0x10db4 <_stogir.switch.sign-mask+0xe4>
   10d64:      	cmp	x0, #0xa
   10d68:      	b.eq	0x10db4 <_stogir.switch.sign-mask+0xe4>
   10d6c:      	cmp	x0, #0xd
   10d70:      	b.eq	0x10db4 <_stogir.switch.sign-mask+0xe4>
   10d74:      	cmp	x0, #0x5
   10d78:      	b.eq	0x10dbc <_stogir.switch.sign-mask+0xec>
   10d7c:      	cmp	x0, #0xb
   10d80:      	b.eq	0x10dbc <_stogir.switch.sign-mask+0xec>
   10d84:      	cmp	x0, #0xc
   10d88:      	b.eq	0x10dbc <_stogir.switch.sign-mask+0xec>
   10d8c:      	cmp	x0, #0x6
   10d90:      	cset	w0, eq
   10d94:      	uxtb	w16, w0
   10d98:      	cmp	w16, wzr
   10d9c:      	mov	x16, #0x8               ; =8
   10da0:      	movn	x17, #0x0, lsl #48
   10da4:      	csel	x0, x16, x17, ne
   10da8:      	b	0x10dc0 <_stogir.switch.sign-mask+0xf0>
   10dac:      	mov	x0, #0x2                ; =2
   10db0:      	b	0x10d00 <_stogir.switch.sign-mask+0x30>
   10db4:      	mov	x0, #0x4                ; =4
   10db8:      	b	0x10db0 <_stogir.switch.sign-mask+0xe0>
   10dbc:      	mov	x0, #0x8                ; =8
   10dc0:      	b	0x10db8 <_stogir.switch.sign-mask+0xe8>
