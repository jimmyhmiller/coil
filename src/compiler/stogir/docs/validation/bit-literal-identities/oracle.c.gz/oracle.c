
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <inttypes.h>
typedef struct { union { bool b; int8_t i8; int16_t i16; int32_t i32; int64_t i64; uint64_t u64; } val; } Insn;
typedef struct { int kind, source, opcode; } Result;
#define IR_NOT 45
#define IR_UNUSED 0
#define IR_OPT_TYPE_MASK 0xff00
#define IR_FOLD_COPY(ref) return (Result){2,ref,0}
#define IR_FOLD_NEXT return (Result){3,0,0}
#define IR_FOLD_RESTART return (Result){4,op1,opt & 255}
static Result rule0(int op1, int op2, Insn *op2_insn, int opt) {

	IR_FOLD_COPY(op2_insn->val.b ? op1 : op2);

}
static Result rule1(int op1, int op2, Insn *op2_insn, int opt) {

	if (op2_insn->val.i8 == 0) {
		/* a & 0 => 0 */
		IR_FOLD_COPY(op2);
	} else if (op2_insn->val.i8 == -1) {
		IR_FOLD_COPY(op1);
	}
	IR_FOLD_NEXT;

}
static Result rule2(int op1, int op2, Insn *op2_insn, int opt) {

	if (op2_insn->val.i16 == 0) {
		/* a & 0 => 0 */
		IR_FOLD_COPY(op2);
	} else if (op2_insn->val.i16 == -1) {
		IR_FOLD_COPY(op1);
	}
	IR_FOLD_NEXT;

}
static Result rule3(int op1, int op2, Insn *op2_insn, int opt) {

	if (op2_insn->val.i32 == 0) {
		/* a & 0 => 0 */
		IR_FOLD_COPY(op2);
	} else if (op2_insn->val.i32 == -1) {
		IR_FOLD_COPY(op1);
	}
	IR_FOLD_NEXT;

}
static Result rule4(int op1, int op2, Insn *op2_insn, int opt) {

	if (op2_insn->val.i64 == 0) {
		/* a & 0 => 0 */
		IR_FOLD_COPY(op2);
	} else if (op2_insn->val.i64 == -1) {
		IR_FOLD_COPY(op1);
	}
	IR_FOLD_NEXT;

}
static Result rule5(int op1, int op2, Insn *op2_insn, int opt) {

	IR_FOLD_COPY(op2_insn->val.b ? op2 : op1);

}
static Result rule6(int op1, int op2, Insn *op2_insn, int opt) {

	if (op2_insn->val.i8 == -1) {
		/* a | 1 => 1 */
		IR_FOLD_COPY(op2);
	} else if (op2_insn->val.i8 == 0) {
		IR_FOLD_COPY(op1);
	}
	IR_FOLD_NEXT;

}
static Result rule7(int op1, int op2, Insn *op2_insn, int opt) {

	if (op2_insn->val.i16 == -1) {
		/* a | 1 => 1 */
		IR_FOLD_COPY(op2);
	} else if (op2_insn->val.i16 == 0) {
		IR_FOLD_COPY(op1);
	}
	IR_FOLD_NEXT;

}
static Result rule8(int op1, int op2, Insn *op2_insn, int opt) {

	if (op2_insn->val.i32 == -1) {
		/* a | 1 => 1 */
		IR_FOLD_COPY(op2);
	} else if (op2_insn->val.i32 == -0) {
		IR_FOLD_COPY(op1);
	}
	IR_FOLD_NEXT;

}
static Result rule9(int op1, int op2, Insn *op2_insn, int opt) {

	if (op2_insn->val.i64 == -1) {
		/* a | 1 => 1 */
		IR_FOLD_COPY(op2);
	} else if (op2_insn->val.i64 == 0) {
		IR_FOLD_COPY(op1);
	}
	IR_FOLD_NEXT;

}
static Result rule10(int op1, int op2, Insn *op2_insn, int opt) {

	if (!op2_insn->val.b) {
		/* a ^ 0 => a */
		IR_FOLD_COPY(op1);
	} else {
		/* a ^ 1 => !a */
		opt = IR_NOT | (opt & IR_OPT_TYPE_MASK);
		op2 = IR_UNUSED;
		IR_FOLD_RESTART;
	}

}
static Result rule11(int op1, int op2, Insn *op2_insn, int opt) {

	if (op2_insn->val.i8 == 0) {
		/* a ^ 0 => a */
		IR_FOLD_COPY(op1);
	} else if (op2_insn->val.i8 == -1) {
		/* a ^ 1 => ~a */
		opt = IR_NOT | (opt & IR_OPT_TYPE_MASK);
		op2 = IR_UNUSED;
		IR_FOLD_RESTART;
	}
	IR_FOLD_NEXT;

}
static Result rule12(int op1, int op2, Insn *op2_insn, int opt) {

	if (op2_insn->val.i16 == 0) {
		/* a ^ 0 => a */
		IR_FOLD_COPY(op1);
	} else if (op2_insn->val.i16 == -1) {
		/* a ^ 1 => ~a */
		opt = IR_NOT | (opt & IR_OPT_TYPE_MASK);
		op2 = IR_UNUSED;
		IR_FOLD_RESTART;
	}
	IR_FOLD_NEXT;

}
static Result rule13(int op1, int op2, Insn *op2_insn, int opt) {

	if (op2_insn->val.i32 == 0) {
		/* a ^ 0 => a */
		IR_FOLD_COPY(op1);
	} else if (op2_insn->val.i32 == -1) {
		/* a ^ 1 => ~a */
		opt = IR_NOT | (opt & IR_OPT_TYPE_MASK);
		op2 = IR_UNUSED;
		IR_FOLD_RESTART;
	}
	IR_FOLD_NEXT;

}
static Result rule14(int op1, int op2, Insn *op2_insn, int opt) {

	if (op2_insn->val.i64 == 0) {
		/* a ^ 0 => a */
		IR_FOLD_COPY(op1);
	} else if (op2_insn->val.i64 == -1) {
		/* a ^ 1 => ~a */
		opt = IR_NOT | (opt & IR_OPT_TYPE_MASK);
		op2 = IR_UNUSED;
		IR_FOLD_RESTART;
	}
	IR_FOLD_NEXT;

}
static Result decide(int opcode,int ty,uint64_t bits) {
Insn literal; literal.val.u64=bits;
if (opcode==47 && ty==1) return rule0(11,-2,&literal,(ty<<8)|opcode);
if (opcode==47 && ty==2) return rule1(11,-2,&literal,(ty<<8)|opcode);
if (opcode==47 && ty==8) return rule1(11,-2,&literal,(ty<<8)|opcode);
if (opcode==47 && ty==7) return rule1(11,-2,&literal,(ty<<8)|opcode);
if (opcode==47 && ty==3) return rule2(11,-2,&literal,(ty<<8)|opcode);
if (opcode==47 && ty==9) return rule2(11,-2,&literal,(ty<<8)|opcode);
if (opcode==47 && ty==4) return rule3(11,-2,&literal,(ty<<8)|opcode);
if (opcode==47 && ty==10) return rule3(11,-2,&literal,(ty<<8)|opcode);
if (opcode==47 && ty==5) return rule4(11,-2,&literal,(ty<<8)|opcode);
if (opcode==47 && ty==11) return rule4(11,-2,&literal,(ty<<8)|opcode);
if (opcode==46 && ty==1) return rule5(11,-2,&literal,(ty<<8)|opcode);
if (opcode==46 && ty==2) return rule6(11,-2,&literal,(ty<<8)|opcode);
if (opcode==46 && ty==8) return rule6(11,-2,&literal,(ty<<8)|opcode);
if (opcode==46 && ty==7) return rule6(11,-2,&literal,(ty<<8)|opcode);
if (opcode==46 && ty==3) return rule7(11,-2,&literal,(ty<<8)|opcode);
if (opcode==46 && ty==9) return rule7(11,-2,&literal,(ty<<8)|opcode);
if (opcode==46 && ty==4) return rule8(11,-2,&literal,(ty<<8)|opcode);
if (opcode==46 && ty==10) return rule8(11,-2,&literal,(ty<<8)|opcode);
if (opcode==46 && ty==5) return rule9(11,-2,&literal,(ty<<8)|opcode);
if (opcode==46 && ty==11) return rule9(11,-2,&literal,(ty<<8)|opcode);
if (opcode==48 && ty==1) return rule10(11,-2,&literal,(ty<<8)|opcode);
if (opcode==48 && ty==2) return rule11(11,-2,&literal,(ty<<8)|opcode);
if (opcode==48 && ty==8) return rule11(11,-2,&literal,(ty<<8)|opcode);
if (opcode==48 && ty==7) return rule11(11,-2,&literal,(ty<<8)|opcode);
if (opcode==48 && ty==3) return rule12(11,-2,&literal,(ty<<8)|opcode);
if (opcode==48 && ty==9) return rule12(11,-2,&literal,(ty<<8)|opcode);
if (opcode==48 && ty==4) return rule13(11,-2,&literal,(ty<<8)|opcode);
if (opcode==48 && ty==10) return rule13(11,-2,&literal,(ty<<8)|opcode);
if (opcode==48 && ty==5) return rule14(11,-2,&literal,(ty<<8)|opcode);
if (opcode==48 && ty==11) return rule14(11,-2,&literal,(ty<<8)|opcode);
return (Result){-1,0,0};
}
int main(void) {
int types[]={1,2,3,4,5,7,8,9,10,11};
for(int t=0;t<10;t++) {
 int ty=types[t], width=ty==1?1:((ty==2||ty==7||ty==8)?8:(ty==3||ty==9)?16:(ty==4||ty==10)?32:64);
 uint64_t mask=width==64?UINT64_MAX:(((uint64_t)1<<width)-1);
 uint64_t literals[]={0,mask,mask & 0xa5};
 for(int op=46;op<=48;op++) for(int i=0;i<3;i++) for(int reverse=0;reverse<2;reverse++) {
  Result r=decide(op,ty,literals[i]);
  printf("BIT %d %d %" PRIu64 " %s %d %d %d\n",ty,op,literals[i],reverse?"true":"false",r.kind,r.source,r.opcode);
 }
}
return 0;
}
