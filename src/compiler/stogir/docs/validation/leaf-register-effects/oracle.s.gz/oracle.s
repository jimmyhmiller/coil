.text
.globl _oracle
_oracle:
  add w0, w7, #4095
  add w0, w7, w9, lsl #31
  sub w0, w7, #4095
  sub w0, w7, w9, lsl #31
  adds w0, w7, #4095
  adds w0, w7, w9, lsl #31
  subs w0, w7, #4095
  subs w0, w7, w9, lsl #31
  and w0, w7, w9, asr #3
  orr w0, w7, w9, asr #3
  eor w0, w7, w9, asr #3
  ands w0, w7, w9, asr #3
  bic w0, w7, w9, asr #3
  orn w0, w7, w9, asr #3
  eon w0, w7, w9, asr #3
  bics w0, w7, w9, asr #3
  and w0, w7, #0xff
  orr w0, w7, #0xff
  eor w0, w7, #0xff
  ands w0, w7, #0xff
  movz w0, #0xabcd, lsl #16
  movn w0, #0xabcd, lsl #16
  movk w0, #0xabcd, lsl #16
  sbfm w0, w7, #3, #21
  bfm w0, w7, #3, #21
  ubfm w0, w7, #3, #21
  csel w0, w7, w9, ne
  csinc w0, w7, w9, ne
  csinv w0, w7, w9, ne
  csneg w0, w7, w9, ne
  madd w0, w7, w9, w11
  msub w0, w7, w9, w11
  udiv w0, w7, w9
  sdiv w0, w7, w9
  lslv w0, w7, w9
  lsrv w0, w7, w9
  asrv w0, w7, w9
  rorv w0, w7, w9
  rbit w0, w7
  rev w0, w7
  rev16 w0, w7
  clz w0, w7
  ldr w0, [x7, #16]
  ldur w0, [x7, #-16]
  ldr w0, [x7, x9, lsl #2]
  str w0, [x7, #16]
  stur w0, [x7, #-16]
  ldrsb w0, [x7, #0]
  ldrsh w0, [x7, #0]
  add w1, w7, #4095
  add w1, w7, w9, lsl #31
  sub w1, w7, #4095
  sub w1, w7, w9, lsl #31
  adds w1, w7, #4095
  adds w1, w7, w9, lsl #31
  subs w1, w7, #4095
  subs w1, w7, w9, lsl #31
  and w1, w7, w9, asr #3
  orr w1, w7, w9, asr #3
  eor w1, w7, w9, asr #3
  ands w1, w7, w9, asr #3
  bic w1, w7, w9, asr #3
  orn w1, w7, w9, asr #3
  eon w1, w7, w9, asr #3
  bics w1, w7, w9, asr #3
  and w1, w7, #0xff
  orr w1, w7, #0xff
  eor w1, w7, #0xff
  ands w1, w7, #0xff
  movz w1, #0xabcd, lsl #16
  movn w1, #0xabcd, lsl #16
  movk w1, #0xabcd, lsl #16
  sbfm w1, w7, #3, #21
  bfm w1, w7, #3, #21
  ubfm w1, w7, #3, #21
  csel w1, w7, w9, ne
  csinc w1, w7, w9, ne
  csinv w1, w7, w9, ne
  csneg w1, w7, w9, ne
  madd w1, w7, w9, w11
  msub w1, w7, w9, w11
  udiv w1, w7, w9
  sdiv w1, w7, w9
  lslv w1, w7, w9
  lsrv w1, w7, w9
  asrv w1, w7, w9
  rorv w1, w7, w9
  rbit w1, w7
  rev w1, w7
  rev16 w1, w7
  clz w1, w7
  ldr w1, [x7, #16]
  ldur w1, [x7, #-16]
  ldr w1, [x7, x9, lsl #2]
  str w1, [x7, #16]
  stur w1, [x7, #-16]
  ldrsb w1, [x7, #0]
  ldrsh w1, [x7, #0]
  add w2, w7, #4095
  add w2, w7, w9, lsl #31
  sub w2, w7, #4095
  sub w2, w7, w9, lsl #31
  adds w2, w7, #4095
  adds w2, w7, w9, lsl #31
  subs w2, w7, #4095
  subs w2, w7, w9, lsl #31
  and w2, w7, w9, asr #3
  orr w2, w7, w9, asr #3
  eor w2, w7, w9, asr #3
  ands w2, w7, w9, asr #3
  bic w2, w7, w9, asr #3
  orn w2, w7, w9, asr #3
  eon w2, w7, w9, asr #3
  bics w2, w7, w9, asr #3
  and w2, w7, #0xff
  orr w2, w7, #0xff
  eor w2, w7, #0xff
  ands w2, w7, #0xff
  movz w2, #0xabcd, lsl #16
  movn w2, #0xabcd, lsl #16
  movk w2, #0xabcd, lsl #16
  sbfm w2, w7, #3, #21
  bfm w2, w7, #3, #21
  ubfm w2, w7, #3, #21
  csel w2, w7, w9, ne
  csinc w2, w7, w9, ne
  csinv w2, w7, w9, ne
  csneg w2, w7, w9, ne
  madd w2, w7, w9, w11
  msub w2, w7, w9, w11
  udiv w2, w7, w9
  sdiv w2, w7, w9
  lslv w2, w7, w9
  lsrv w2, w7, w9
  asrv w2, w7, w9
  rorv w2, w7, w9
  rbit w2, w7
  rev w2, w7
  rev16 w2, w7
  clz w2, w7
  ldr w2, [x7, #16]
  ldur w2, [x7, #-16]
  ldr w2, [x7, x9, lsl #2]
  str w2, [x7, #16]
  stur w2, [x7, #-16]
  ldrsb w2, [x7, #0]
  ldrsh w2, [x7, #0]
  add w3, w7, #4095
  add w3, w7, w9, lsl #31
  sub w3, w7, #4095
  sub w3, w7, w9, lsl #31
  adds w3, w7, #4095
  adds w3, w7, w9, lsl #31
  subs w3, w7, #4095
  subs w3, w7, w9, lsl #31
  and w3, w7, w9, asr #3
  orr w3, w7, w9, asr #3
  eor w3, w7, w9, asr #3
  ands w3, w7, w9, asr #3
  bic w3, w7, w9, asr #3
  orn w3, w7, w9, asr #3
  eon w3, w7, w9, asr #3
  bics w3, w7, w9, asr #3
  and w3, w7, #0xff
  orr w3, w7, #0xff
  eor w3, w7, #0xff
  ands w3, w7, #0xff
  movz w3, #0xabcd, lsl #16
  movn w3, #0xabcd, lsl #16
  movk w3, #0xabcd, lsl #16
  sbfm w3, w7, #3, #21
  bfm w3, w7, #3, #21
  ubfm w3, w7, #3, #21
  csel w3, w7, w9, ne
  csinc w3, w7, w9, ne
  csinv w3, w7, w9, ne
  csneg w3, w7, w9, ne
  madd w3, w7, w9, w11
  msub w3, w7, w9, w11
  udiv w3, w7, w9
  sdiv w3, w7, w9
  lslv w3, w7, w9
  lsrv w3, w7, w9
  asrv w3, w7, w9
  rorv w3, w7, w9
  rbit w3, w7
  rev w3, w7
  rev16 w3, w7
  clz w3, w7
  ldr w3, [x7, #16]
  ldur w3, [x7, #-16]
  ldr w3, [x7, x9, lsl #2]
  str w3, [x7, #16]
  stur w3, [x7, #-16]
  ldrsb w3, [x7, #0]
  ldrsh w3, [x7, #0]
  add w4, w7, #4095
  add w4, w7, w9, lsl #31
  sub w4, w7, #4095
  sub w4, w7, w9, lsl #31
  adds w4, w7, #4095
  adds w4, w7, w9, lsl #31
  subs w4, w7, #4095
  subs w4, w7, w9, lsl #31
  and w4, w7, w9, asr #3
  orr w4, w7, w9, asr #3
  eor w4, w7, w9, asr #3
  ands w4, w7, w9, asr #3
  bic w4, w7, w9, asr #3
  orn w4, w7, w9, asr #3
  eon w4, w7, w9, asr #3
  bics w4, w7, w9, asr #3
  and w4, w7, #0xff
  orr w4, w7, #0xff
  eor w4, w7, #0xff
  ands w4, w7, #0xff
  movz w4, #0xabcd, lsl #16
  movn w4, #0xabcd, lsl #16
  movk w4, #0xabcd, lsl #16
  sbfm w4, w7, #3, #21
  bfm w4, w7, #3, #21
  ubfm w4, w7, #3, #21
  csel w4, w7, w9, ne
  csinc w4, w7, w9, ne
  csinv w4, w7, w9, ne
  csneg w4, w7, w9, ne
  madd w4, w7, w9, w11
  msub w4, w7, w9, w11
  udiv w4, w7, w9
  sdiv w4, w7, w9
  lslv w4, w7, w9
  lsrv w4, w7, w9
  asrv w4, w7, w9
  rorv w4, w7, w9
  rbit w4, w7
  rev w4, w7
  rev16 w4, w7
  clz w4, w7
  ldr w4, [x7, #16]
  ldur w4, [x7, #-16]
  ldr w4, [x7, x9, lsl #2]
  str w4, [x7, #16]
  stur w4, [x7, #-16]
  ldrsb w4, [x7, #0]
  ldrsh w4, [x7, #0]
  add w5, w7, #4095
  add w5, w7, w9, lsl #31
  sub w5, w7, #4095
  sub w5, w7, w9, lsl #31
  adds w5, w7, #4095
  adds w5, w7, w9, lsl #31
  subs w5, w7, #4095
  subs w5, w7, w9, lsl #31
  and w5, w7, w9, asr #3
  orr w5, w7, w9, asr #3
  eor w5, w7, w9, asr #3
  ands w5, w7, w9, asr #3
  bic w5, w7, w9, asr #3
  orn w5, w7, w9, asr #3
  eon w5, w7, w9, asr #3
  bics w5, w7, w9, asr #3
  and w5, w7, #0xff
  orr w5, w7, #0xff
  eor w5, w7, #0xff
  ands w5, w7, #0xff
  movz w5, #0xabcd, lsl #16
  movn w5, #0xabcd, lsl #16
  movk w5, #0xabcd, lsl #16
  sbfm w5, w7, #3, #21
  bfm w5, w7, #3, #21
  ubfm w5, w7, #3, #21
  csel w5, w7, w9, ne
  csinc w5, w7, w9, ne
  csinv w5, w7, w9, ne
  csneg w5, w7, w9, ne
  madd w5, w7, w9, w11
  msub w5, w7, w9, w11
  udiv w5, w7, w9
  sdiv w5, w7, w9
  lslv w5, w7, w9
  lsrv w5, w7, w9
  asrv w5, w7, w9
  rorv w5, w7, w9
  rbit w5, w7
  rev w5, w7
  rev16 w5, w7
  clz w5, w7
  ldr w5, [x7, #16]
  ldur w5, [x7, #-16]
  ldr w5, [x7, x9, lsl #2]
  str w5, [x7, #16]
  stur w5, [x7, #-16]
  ldrsb w5, [x7, #0]
  ldrsh w5, [x7, #0]
  add w6, w7, #4095
  add w6, w7, w9, lsl #31
  sub w6, w7, #4095
  sub w6, w7, w9, lsl #31
  adds w6, w7, #4095
  adds w6, w7, w9, lsl #31
  subs w6, w7, #4095
  subs w6, w7, w9, lsl #31
  and w6, w7, w9, asr #3
  orr w6, w7, w9, asr #3
  eor w6, w7, w9, asr #3
  ands w6, w7, w9, asr #3
  bic w6, w7, w9, asr #3
  orn w6, w7, w9, asr #3
  eon w6, w7, w9, asr #3
  bics w6, w7, w9, asr #3
  and w6, w7, #0xff
  orr w6, w7, #0xff
  eor w6, w7, #0xff
  ands w6, w7, #0xff
  movz w6, #0xabcd, lsl #16
  movn w6, #0xabcd, lsl #16
  movk w6, #0xabcd, lsl #16
  sbfm w6, w7, #3, #21
  bfm w6, w7, #3, #21
  ubfm w6, w7, #3, #21
  csel w6, w7, w9, ne
  csinc w6, w7, w9, ne
  csinv w6, w7, w9, ne
  csneg w6, w7, w9, ne
  madd w6, w7, w9, w11
  msub w6, w7, w9, w11
  udiv w6, w7, w9
  sdiv w6, w7, w9
  lslv w6, w7, w9
  lsrv w6, w7, w9
  asrv w6, w7, w9
  rorv w6, w7, w9
  rbit w6, w7
  rev w6, w7
  rev16 w6, w7
  clz w6, w7
  ldr w6, [x7, #16]
  ldur w6, [x7, #-16]
  ldr w6, [x7, x9, lsl #2]
  str w6, [x7, #16]
  stur w6, [x7, #-16]
  ldrsb w6, [x7, #0]
  ldrsh w6, [x7, #0]
  add w7, w7, #4095
  add w7, w7, w9, lsl #31
  sub w7, w7, #4095
  sub w7, w7, w9, lsl #31
  adds w7, w7, #4095
  adds w7, w7, w9, lsl #31
  subs w7, w7, #4095
  subs w7, w7, w9, lsl #31
  and w7, w7, w9, asr #3
  orr w7, w7, w9, asr #3
  eor w7, w7, w9, asr #3
  ands w7, w7, w9, asr #3
  bic w7, w7, w9, asr #3
  orn w7, w7, w9, asr #3
  eon w7, w7, w9, asr #3
  bics w7, w7, w9, asr #3
  and w7, w7, #0xff
  orr w7, w7, #0xff
  eor w7, w7, #0xff
  ands w7, w7, #0xff
  movz w7, #0xabcd, lsl #16
  movn w7, #0xabcd, lsl #16
  movk w7, #0xabcd, lsl #16
  sbfm w7, w7, #3, #21
  bfm w7, w7, #3, #21
  ubfm w7, w7, #3, #21
  csel w7, w7, w9, ne
  csinc w7, w7, w9, ne
  csinv w7, w7, w9, ne
  csneg w7, w7, w9, ne
  madd w7, w7, w9, w11
  msub w7, w7, w9, w11
  udiv w7, w7, w9
  sdiv w7, w7, w9
  lslv w7, w7, w9
  lsrv w7, w7, w9
  asrv w7, w7, w9
  rorv w7, w7, w9
  rbit w7, w7
  rev w7, w7
  rev16 w7, w7
  clz w7, w7
  ldr w7, [x7, #16]
  ldur w7, [x7, #-16]
  ldr w7, [x7, x9, lsl #2]
  str w7, [x7, #16]
  stur w7, [x7, #-16]
  ldrsb w7, [x7, #0]
  ldrsh w7, [x7, #0]
  add w8, w7, #4095
  add w8, w7, w9, lsl #31
  sub w8, w7, #4095
  sub w8, w7, w9, lsl #31
  adds w8, w7, #4095
  adds w8, w7, w9, lsl #31
  subs w8, w7, #4095
  subs w8, w7, w9, lsl #31
  and w8, w7, w9, asr #3
  orr w8, w7, w9, asr #3
  eor w8, w7, w9, asr #3
  ands w8, w7, w9, asr #3
  bic w8, w7, w9, asr #3
  orn w8, w7, w9, asr #3
  eon w8, w7, w9, asr #3
  bics w8, w7, w9, asr #3
  and w8, w7, #0xff
  orr w8, w7, #0xff
  eor w8, w7, #0xff
  ands w8, w7, #0xff
  movz w8, #0xabcd, lsl #16
  movn w8, #0xabcd, lsl #16
  movk w8, #0xabcd, lsl #16
  sbfm w8, w7, #3, #21
  bfm w8, w7, #3, #21
  ubfm w8, w7, #3, #21
  csel w8, w7, w9, ne
  csinc w8, w7, w9, ne
  csinv w8, w7, w9, ne
  csneg w8, w7, w9, ne
  madd w8, w7, w9, w11
  msub w8, w7, w9, w11
  udiv w8, w7, w9
  sdiv w8, w7, w9
  lslv w8, w7, w9
  lsrv w8, w7, w9
  asrv w8, w7, w9
  rorv w8, w7, w9
  rbit w8, w7
  rev w8, w7
  rev16 w8, w7
  clz w8, w7
  ldr w8, [x7, #16]
  ldur w8, [x7, #-16]
  ldr w8, [x7, x9, lsl #2]
  str w8, [x7, #16]
  stur w8, [x7, #-16]
  ldrsb w8, [x7, #0]
  ldrsh w8, [x7, #0]
  add w9, w7, #4095
  add w9, w7, w9, lsl #31
  sub w9, w7, #4095
  sub w9, w7, w9, lsl #31
  adds w9, w7, #4095
  adds w9, w7, w9, lsl #31
  subs w9, w7, #4095
  subs w9, w7, w9, lsl #31
  and w9, w7, w9, asr #3
  orr w9, w7, w9, asr #3
  eor w9, w7, w9, asr #3
  ands w9, w7, w9, asr #3
  bic w9, w7, w9, asr #3
  orn w9, w7, w9, asr #3
  eon w9, w7, w9, asr #3
  bics w9, w7, w9, asr #3
  and w9, w7, #0xff
  orr w9, w7, #0xff
  eor w9, w7, #0xff
  ands w9, w7, #0xff
  movz w9, #0xabcd, lsl #16
  movn w9, #0xabcd, lsl #16
  movk w9, #0xabcd, lsl #16
  sbfm w9, w7, #3, #21
  bfm w9, w7, #3, #21
  ubfm w9, w7, #3, #21
  csel w9, w7, w9, ne
  csinc w9, w7, w9, ne
  csinv w9, w7, w9, ne
  csneg w9, w7, w9, ne
  madd w9, w7, w9, w11
  msub w9, w7, w9, w11
  udiv w9, w7, w9
  sdiv w9, w7, w9
  lslv w9, w7, w9
  lsrv w9, w7, w9
  asrv w9, w7, w9
  rorv w9, w7, w9
  rbit w9, w7
  rev w9, w7
  rev16 w9, w7
  clz w9, w7
  ldr w9, [x7, #16]
  ldur w9, [x7, #-16]
  ldr w9, [x7, x9, lsl #2]
  str w9, [x7, #16]
  stur w9, [x7, #-16]
  ldrsb w9, [x7, #0]
  ldrsh w9, [x7, #0]
  add w10, w7, #4095
  add w10, w7, w9, lsl #31
  sub w10, w7, #4095
  sub w10, w7, w9, lsl #31
  adds w10, w7, #4095
  adds w10, w7, w9, lsl #31
  subs w10, w7, #4095
  subs w10, w7, w9, lsl #31
  and w10, w7, w9, asr #3
  orr w10, w7, w9, asr #3
  eor w10, w7, w9, asr #3
  ands w10, w7, w9, asr #3
  bic w10, w7, w9, asr #3
  orn w10, w7, w9, asr #3
  eon w10, w7, w9, asr #3
  bics w10, w7, w9, asr #3
  and w10, w7, #0xff
  orr w10, w7, #0xff
  eor w10, w7, #0xff
  ands w10, w7, #0xff
  movz w10, #0xabcd, lsl #16
  movn w10, #0xabcd, lsl #16
  movk w10, #0xabcd, lsl #16
  sbfm w10, w7, #3, #21
  bfm w10, w7, #3, #21
  ubfm w10, w7, #3, #21
  csel w10, w7, w9, ne
  csinc w10, w7, w9, ne
  csinv w10, w7, w9, ne
  csneg w10, w7, w9, ne
  madd w10, w7, w9, w11
  msub w10, w7, w9, w11
  udiv w10, w7, w9
  sdiv w10, w7, w9
  lslv w10, w7, w9
  lsrv w10, w7, w9
  asrv w10, w7, w9
  rorv w10, w7, w9
  rbit w10, w7
  rev w10, w7
  rev16 w10, w7
  clz w10, w7
  ldr w10, [x7, #16]
  ldur w10, [x7, #-16]
  ldr w10, [x7, x9, lsl #2]
  str w10, [x7, #16]
  stur w10, [x7, #-16]
  ldrsb w10, [x7, #0]
  ldrsh w10, [x7, #0]
  add w11, w7, #4095
  add w11, w7, w9, lsl #31
  sub w11, w7, #4095
  sub w11, w7, w9, lsl #31
  adds w11, w7, #4095
  adds w11, w7, w9, lsl #31
  subs w11, w7, #4095
  subs w11, w7, w9, lsl #31
  and w11, w7, w9, asr #3
  orr w11, w7, w9, asr #3
  eor w11, w7, w9, asr #3
  ands w11, w7, w9, asr #3
  bic w11, w7, w9, asr #3
  orn w11, w7, w9, asr #3
  eon w11, w7, w9, asr #3
  bics w11, w7, w9, asr #3
  and w11, w7, #0xff
  orr w11, w7, #0xff
  eor w11, w7, #0xff
  ands w11, w7, #0xff
  movz w11, #0xabcd, lsl #16
  movn w11, #0xabcd, lsl #16
  movk w11, #0xabcd, lsl #16
  sbfm w11, w7, #3, #21
  bfm w11, w7, #3, #21
  ubfm w11, w7, #3, #21
  csel w11, w7, w9, ne
  csinc w11, w7, w9, ne
  csinv w11, w7, w9, ne
  csneg w11, w7, w9, ne
  madd w11, w7, w9, w11
  msub w11, w7, w9, w11
  udiv w11, w7, w9
  sdiv w11, w7, w9
  lslv w11, w7, w9
  lsrv w11, w7, w9
  asrv w11, w7, w9
  rorv w11, w7, w9
  rbit w11, w7
  rev w11, w7
  rev16 w11, w7
  clz w11, w7
  ldr w11, [x7, #16]
  ldur w11, [x7, #-16]
  ldr w11, [x7, x9, lsl #2]
  str w11, [x7, #16]
  stur w11, [x7, #-16]
  ldrsb w11, [x7, #0]
  ldrsh w11, [x7, #0]
  add w12, w7, #4095
  add w12, w7, w9, lsl #31
  sub w12, w7, #4095
  sub w12, w7, w9, lsl #31
  adds w12, w7, #4095
  adds w12, w7, w9, lsl #31
  subs w12, w7, #4095
  subs w12, w7, w9, lsl #31
  and w12, w7, w9, asr #3
  orr w12, w7, w9, asr #3
  eor w12, w7, w9, asr #3
  ands w12, w7, w9, asr #3
  bic w12, w7, w9, asr #3
  orn w12, w7, w9, asr #3
  eon w12, w7, w9, asr #3
  bics w12, w7, w9, asr #3
  and w12, w7, #0xff
  orr w12, w7, #0xff
  eor w12, w7, #0xff
  ands w12, w7, #0xff
  movz w12, #0xabcd, lsl #16
  movn w12, #0xabcd, lsl #16
  movk w12, #0xabcd, lsl #16
  sbfm w12, w7, #3, #21
  bfm w12, w7, #3, #21
  ubfm w12, w7, #3, #21
  csel w12, w7, w9, ne
  csinc w12, w7, w9, ne
  csinv w12, w7, w9, ne
  csneg w12, w7, w9, ne
  madd w12, w7, w9, w11
  msub w12, w7, w9, w11
  udiv w12, w7, w9
  sdiv w12, w7, w9
  lslv w12, w7, w9
  lsrv w12, w7, w9
  asrv w12, w7, w9
  rorv w12, w7, w9
  rbit w12, w7
  rev w12, w7
  rev16 w12, w7
  clz w12, w7
  ldr w12, [x7, #16]
  ldur w12, [x7, #-16]
  ldr w12, [x7, x9, lsl #2]
  str w12, [x7, #16]
  stur w12, [x7, #-16]
  ldrsb w12, [x7, #0]
  ldrsh w12, [x7, #0]
  add w13, w7, #4095
  add w13, w7, w9, lsl #31
  sub w13, w7, #4095
  sub w13, w7, w9, lsl #31
  adds w13, w7, #4095
  adds w13, w7, w9, lsl #31
  subs w13, w7, #4095
  subs w13, w7, w9, lsl #31
  and w13, w7, w9, asr #3
  orr w13, w7, w9, asr #3
  eor w13, w7, w9, asr #3
  ands w13, w7, w9, asr #3
  bic w13, w7, w9, asr #3
  orn w13, w7, w9, asr #3
  eon w13, w7, w9, asr #3
  bics w13, w7, w9, asr #3
  and w13, w7, #0xff
  orr w13, w7, #0xff
  eor w13, w7, #0xff
  ands w13, w7, #0xff
  movz w13, #0xabcd, lsl #16
  movn w13, #0xabcd, lsl #16
  movk w13, #0xabcd, lsl #16
  sbfm w13, w7, #3, #21
  bfm w13, w7, #3, #21
  ubfm w13, w7, #3, #21
  csel w13, w7, w9, ne
  csinc w13, w7, w9, ne
  csinv w13, w7, w9, ne
  csneg w13, w7, w9, ne
  madd w13, w7, w9, w11
  msub w13, w7, w9, w11
  udiv w13, w7, w9
  sdiv w13, w7, w9
  lslv w13, w7, w9
  lsrv w13, w7, w9
  asrv w13, w7, w9
  rorv w13, w7, w9
  rbit w13, w7
  rev w13, w7
  rev16 w13, w7
  clz w13, w7
  ldr w13, [x7, #16]
  ldur w13, [x7, #-16]
  ldr w13, [x7, x9, lsl #2]
  str w13, [x7, #16]
  stur w13, [x7, #-16]
  ldrsb w13, [x7, #0]
  ldrsh w13, [x7, #0]
  add w14, w7, #4095
  add w14, w7, w9, lsl #31
  sub w14, w7, #4095
  sub w14, w7, w9, lsl #31
  adds w14, w7, #4095
  adds w14, w7, w9, lsl #31
  subs w14, w7, #4095
  subs w14, w7, w9, lsl #31
  and w14, w7, w9, asr #3
  orr w14, w7, w9, asr #3
  eor w14, w7, w9, asr #3
  ands w14, w7, w9, asr #3
  bic w14, w7, w9, asr #3
  orn w14, w7, w9, asr #3
  eon w14, w7, w9, asr #3
  bics w14, w7, w9, asr #3
  and w14, w7, #0xff
  orr w14, w7, #0xff
  eor w14, w7, #0xff
  ands w14, w7, #0xff
  movz w14, #0xabcd, lsl #16
  movn w14, #0xabcd, lsl #16
  movk w14, #0xabcd, lsl #16
  sbfm w14, w7, #3, #21
  bfm w14, w7, #3, #21
  ubfm w14, w7, #3, #21
  csel w14, w7, w9, ne
  csinc w14, w7, w9, ne
  csinv w14, w7, w9, ne
  csneg w14, w7, w9, ne
  madd w14, w7, w9, w11
  msub w14, w7, w9, w11
  udiv w14, w7, w9
  sdiv w14, w7, w9
  lslv w14, w7, w9
  lsrv w14, w7, w9
  asrv w14, w7, w9
  rorv w14, w7, w9
  rbit w14, w7
  rev w14, w7
  rev16 w14, w7
  clz w14, w7
  ldr w14, [x7, #16]
  ldur w14, [x7, #-16]
  ldr w14, [x7, x9, lsl #2]
  str w14, [x7, #16]
  stur w14, [x7, #-16]
  ldrsb w14, [x7, #0]
  ldrsh w14, [x7, #0]
  add w15, w7, #4095
  add w15, w7, w9, lsl #31
  sub w15, w7, #4095
  sub w15, w7, w9, lsl #31
  adds w15, w7, #4095
  adds w15, w7, w9, lsl #31
  subs w15, w7, #4095
  subs w15, w7, w9, lsl #31
  and w15, w7, w9, asr #3
  orr w15, w7, w9, asr #3
  eor w15, w7, w9, asr #3
  ands w15, w7, w9, asr #3
  bic w15, w7, w9, asr #3
  orn w15, w7, w9, asr #3
  eon w15, w7, w9, asr #3
  bics w15, w7, w9, asr #3
  and w15, w7, #0xff
  orr w15, w7, #0xff
  eor w15, w7, #0xff
  ands w15, w7, #0xff
  movz w15, #0xabcd, lsl #16
  movn w15, #0xabcd, lsl #16
  movk w15, #0xabcd, lsl #16
  sbfm w15, w7, #3, #21
  bfm w15, w7, #3, #21
  ubfm w15, w7, #3, #21
  csel w15, w7, w9, ne
  csinc w15, w7, w9, ne
  csinv w15, w7, w9, ne
  csneg w15, w7, w9, ne
  madd w15, w7, w9, w11
  msub w15, w7, w9, w11
  udiv w15, w7, w9
  sdiv w15, w7, w9
  lslv w15, w7, w9
  lsrv w15, w7, w9
  asrv w15, w7, w9
  rorv w15, w7, w9
  rbit w15, w7
  rev w15, w7
  rev16 w15, w7
  clz w15, w7
  ldr w15, [x7, #16]
  ldur w15, [x7, #-16]
  ldr w15, [x7, x9, lsl #2]
  str w15, [x7, #16]
  stur w15, [x7, #-16]
  ldrsb w15, [x7, #0]
  ldrsh w15, [x7, #0]
  add w16, w7, #4095
  add w16, w7, w9, lsl #31
  sub w16, w7, #4095
  sub w16, w7, w9, lsl #31
  adds w16, w7, #4095
  adds w16, w7, w9, lsl #31
  subs w16, w7, #4095
  subs w16, w7, w9, lsl #31
  and w16, w7, w9, asr #3
  orr w16, w7, w9, asr #3
  eor w16, w7, w9, asr #3
  ands w16, w7, w9, asr #3
  bic w16, w7, w9, asr #3
  orn w16, w7, w9, asr #3
  eon w16, w7, w9, asr #3
  bics w16, w7, w9, asr #3
  and w16, w7, #0xff
  orr w16, w7, #0xff
  eor w16, w7, #0xff
  ands w16, w7, #0xff
  movz w16, #0xabcd, lsl #16
  movn w16, #0xabcd, lsl #16
  movk w16, #0xabcd, lsl #16
  sbfm w16, w7, #3, #21
  bfm w16, w7, #3, #21
  ubfm w16, w7, #3, #21
  csel w16, w7, w9, ne
  csinc w16, w7, w9, ne
  csinv w16, w7, w9, ne
  csneg w16, w7, w9, ne
  madd w16, w7, w9, w11
  msub w16, w7, w9, w11
  udiv w16, w7, w9
  sdiv w16, w7, w9
  lslv w16, w7, w9
  lsrv w16, w7, w9
  asrv w16, w7, w9
  rorv w16, w7, w9
  rbit w16, w7
  rev w16, w7
  rev16 w16, w7
  clz w16, w7
  ldr w16, [x7, #16]
  ldur w16, [x7, #-16]
  ldr w16, [x7, x9, lsl #2]
  str w16, [x7, #16]
  stur w16, [x7, #-16]
  ldrsb w16, [x7, #0]
  ldrsh w16, [x7, #0]
  add w17, w7, #4095
  add w17, w7, w9, lsl #31
  sub w17, w7, #4095
  sub w17, w7, w9, lsl #31
  adds w17, w7, #4095
  adds w17, w7, w9, lsl #31
  subs w17, w7, #4095
  subs w17, w7, w9, lsl #31
  and w17, w7, w9, asr #3
  orr w17, w7, w9, asr #3
  eor w17, w7, w9, asr #3
  ands w17, w7, w9, asr #3
  bic w17, w7, w9, asr #3
  orn w17, w7, w9, asr #3
  eon w17, w7, w9, asr #3
  bics w17, w7, w9, asr #3
  and w17, w7, #0xff
  orr w17, w7, #0xff
  eor w17, w7, #0xff
  ands w17, w7, #0xff
  movz w17, #0xabcd, lsl #16
  movn w17, #0xabcd, lsl #16
  movk w17, #0xabcd, lsl #16
  sbfm w17, w7, #3, #21
  bfm w17, w7, #3, #21
  ubfm w17, w7, #3, #21
  csel w17, w7, w9, ne
  csinc w17, w7, w9, ne
  csinv w17, w7, w9, ne
  csneg w17, w7, w9, ne
  madd w17, w7, w9, w11
  msub w17, w7, w9, w11
  udiv w17, w7, w9
  sdiv w17, w7, w9
  lslv w17, w7, w9
  lsrv w17, w7, w9
  asrv w17, w7, w9
  rorv w17, w7, w9
  rbit w17, w7
  rev w17, w7
  rev16 w17, w7
  clz w17, w7
  ldr w17, [x7, #16]
  ldur w17, [x7, #-16]
  ldr w17, [x7, x9, lsl #2]
  str w17, [x7, #16]
  stur w17, [x7, #-16]
  ldrsb w17, [x7, #0]
  ldrsh w17, [x7, #0]
  add w18, w7, #4095
  add w18, w7, w9, lsl #31
  sub w18, w7, #4095
  sub w18, w7, w9, lsl #31
  adds w18, w7, #4095
  adds w18, w7, w9, lsl #31
  subs w18, w7, #4095
  subs w18, w7, w9, lsl #31
  and w18, w7, w9, asr #3
  orr w18, w7, w9, asr #3
  eor w18, w7, w9, asr #3
  ands w18, w7, w9, asr #3
  bic w18, w7, w9, asr #3
  orn w18, w7, w9, asr #3
  eon w18, w7, w9, asr #3
  bics w18, w7, w9, asr #3
  and w18, w7, #0xff
  orr w18, w7, #0xff
  eor w18, w7, #0xff
  ands w18, w7, #0xff
  movz w18, #0xabcd, lsl #16
  movn w18, #0xabcd, lsl #16
  movk w18, #0xabcd, lsl #16
  sbfm w18, w7, #3, #21
  bfm w18, w7, #3, #21
  ubfm w18, w7, #3, #21
  csel w18, w7, w9, ne
  csinc w18, w7, w9, ne
  csinv w18, w7, w9, ne
  csneg w18, w7, w9, ne
  madd w18, w7, w9, w11
  msub w18, w7, w9, w11
  udiv w18, w7, w9
  sdiv w18, w7, w9
  lslv w18, w7, w9
  lsrv w18, w7, w9
  asrv w18, w7, w9
  rorv w18, w7, w9
  rbit w18, w7
  rev w18, w7
  rev16 w18, w7
  clz w18, w7
  ldr w18, [x7, #16]
  ldur w18, [x7, #-16]
  ldr w18, [x7, x9, lsl #2]
  str w18, [x7, #16]
  stur w18, [x7, #-16]
  ldrsb w18, [x7, #0]
  ldrsh w18, [x7, #0]
  add w19, w7, #4095
  add w19, w7, w9, lsl #31
  sub w19, w7, #4095
  sub w19, w7, w9, lsl #31
  adds w19, w7, #4095
  adds w19, w7, w9, lsl #31
  subs w19, w7, #4095
  subs w19, w7, w9, lsl #31
  and w19, w7, w9, asr #3
  orr w19, w7, w9, asr #3
  eor w19, w7, w9, asr #3
  ands w19, w7, w9, asr #3
  bic w19, w7, w9, asr #3
  orn w19, w7, w9, asr #3
  eon w19, w7, w9, asr #3
  bics w19, w7, w9, asr #3
  and w19, w7, #0xff
  orr w19, w7, #0xff
  eor w19, w7, #0xff
  ands w19, w7, #0xff
  movz w19, #0xabcd, lsl #16
  movn w19, #0xabcd, lsl #16
  movk w19, #0xabcd, lsl #16
  sbfm w19, w7, #3, #21
  bfm w19, w7, #3, #21
  ubfm w19, w7, #3, #21
  csel w19, w7, w9, ne
  csinc w19, w7, w9, ne
  csinv w19, w7, w9, ne
  csneg w19, w7, w9, ne
  madd w19, w7, w9, w11
  msub w19, w7, w9, w11
  udiv w19, w7, w9
  sdiv w19, w7, w9
  lslv w19, w7, w9
  lsrv w19, w7, w9
  asrv w19, w7, w9
  rorv w19, w7, w9
  rbit w19, w7
  rev w19, w7
  rev16 w19, w7
  clz w19, w7
  ldr w19, [x7, #16]
  ldur w19, [x7, #-16]
  ldr w19, [x7, x9, lsl #2]
  str w19, [x7, #16]
  stur w19, [x7, #-16]
  ldrsb w19, [x7, #0]
  ldrsh w19, [x7, #0]
  add w20, w7, #4095
  add w20, w7, w9, lsl #31
  sub w20, w7, #4095
  sub w20, w7, w9, lsl #31
  adds w20, w7, #4095
  adds w20, w7, w9, lsl #31
  subs w20, w7, #4095
  subs w20, w7, w9, lsl #31
  and w20, w7, w9, asr #3
  orr w20, w7, w9, asr #3
  eor w20, w7, w9, asr #3
  ands w20, w7, w9, asr #3
  bic w20, w7, w9, asr #3
  orn w20, w7, w9, asr #3
  eon w20, w7, w9, asr #3
  bics w20, w7, w9, asr #3
  and w20, w7, #0xff
  orr w20, w7, #0xff
  eor w20, w7, #0xff
  ands w20, w7, #0xff
  movz w20, #0xabcd, lsl #16
  movn w20, #0xabcd, lsl #16
  movk w20, #0xabcd, lsl #16
  sbfm w20, w7, #3, #21
  bfm w20, w7, #3, #21
  ubfm w20, w7, #3, #21
  csel w20, w7, w9, ne
  csinc w20, w7, w9, ne
  csinv w20, w7, w9, ne
  csneg w20, w7, w9, ne
  madd w20, w7, w9, w11
  msub w20, w7, w9, w11
  udiv w20, w7, w9
  sdiv w20, w7, w9
  lslv w20, w7, w9
  lsrv w20, w7, w9
  asrv w20, w7, w9
  rorv w20, w7, w9
  rbit w20, w7
  rev w20, w7
  rev16 w20, w7
  clz w20, w7
  ldr w20, [x7, #16]
  ldur w20, [x7, #-16]
  ldr w20, [x7, x9, lsl #2]
  str w20, [x7, #16]
  stur w20, [x7, #-16]
  ldrsb w20, [x7, #0]
  ldrsh w20, [x7, #0]
  add w21, w7, #4095
  add w21, w7, w9, lsl #31
  sub w21, w7, #4095
  sub w21, w7, w9, lsl #31
  adds w21, w7, #4095
  adds w21, w7, w9, lsl #31
  subs w21, w7, #4095
  subs w21, w7, w9, lsl #31
  and w21, w7, w9, asr #3
  orr w21, w7, w9, asr #3
  eor w21, w7, w9, asr #3
  ands w21, w7, w9, asr #3
  bic w21, w7, w9, asr #3
  orn w21, w7, w9, asr #3
  eon w21, w7, w9, asr #3
  bics w21, w7, w9, asr #3
  and w21, w7, #0xff
  orr w21, w7, #0xff
  eor w21, w7, #0xff
  ands w21, w7, #0xff
  movz w21, #0xabcd, lsl #16
  movn w21, #0xabcd, lsl #16
  movk w21, #0xabcd, lsl #16
  sbfm w21, w7, #3, #21
  bfm w21, w7, #3, #21
  ubfm w21, w7, #3, #21
  csel w21, w7, w9, ne
  csinc w21, w7, w9, ne
  csinv w21, w7, w9, ne
  csneg w21, w7, w9, ne
  madd w21, w7, w9, w11
  msub w21, w7, w9, w11
  udiv w21, w7, w9
  sdiv w21, w7, w9
  lslv w21, w7, w9
  lsrv w21, w7, w9
  asrv w21, w7, w9
  rorv w21, w7, w9
  rbit w21, w7
  rev w21, w7
  rev16 w21, w7
  clz w21, w7
  ldr w21, [x7, #16]
  ldur w21, [x7, #-16]
  ldr w21, [x7, x9, lsl #2]
  str w21, [x7, #16]
  stur w21, [x7, #-16]
  ldrsb w21, [x7, #0]
  ldrsh w21, [x7, #0]
  add w22, w7, #4095
  add w22, w7, w9, lsl #31
  sub w22, w7, #4095
  sub w22, w7, w9, lsl #31
  adds w22, w7, #4095
  adds w22, w7, w9, lsl #31
  subs w22, w7, #4095
  subs w22, w7, w9, lsl #31
  and w22, w7, w9, asr #3
  orr w22, w7, w9, asr #3
  eor w22, w7, w9, asr #3
  ands w22, w7, w9, asr #3
  bic w22, w7, w9, asr #3
  orn w22, w7, w9, asr #3
  eon w22, w7, w9, asr #3
  bics w22, w7, w9, asr #3
  and w22, w7, #0xff
  orr w22, w7, #0xff
  eor w22, w7, #0xff
  ands w22, w7, #0xff
  movz w22, #0xabcd, lsl #16
  movn w22, #0xabcd, lsl #16
  movk w22, #0xabcd, lsl #16
  sbfm w22, w7, #3, #21
  bfm w22, w7, #3, #21
  ubfm w22, w7, #3, #21
  csel w22, w7, w9, ne
  csinc w22, w7, w9, ne
  csinv w22, w7, w9, ne
  csneg w22, w7, w9, ne
  madd w22, w7, w9, w11
  msub w22, w7, w9, w11
  udiv w22, w7, w9
  sdiv w22, w7, w9
  lslv w22, w7, w9
  lsrv w22, w7, w9
  asrv w22, w7, w9
  rorv w22, w7, w9
  rbit w22, w7
  rev w22, w7
  rev16 w22, w7
  clz w22, w7
  ldr w22, [x7, #16]
  ldur w22, [x7, #-16]
  ldr w22, [x7, x9, lsl #2]
  str w22, [x7, #16]
  stur w22, [x7, #-16]
  ldrsb w22, [x7, #0]
  ldrsh w22, [x7, #0]
  add w23, w7, #4095
  add w23, w7, w9, lsl #31
  sub w23, w7, #4095
  sub w23, w7, w9, lsl #31
  adds w23, w7, #4095
  adds w23, w7, w9, lsl #31
  subs w23, w7, #4095
  subs w23, w7, w9, lsl #31
  and w23, w7, w9, asr #3
  orr w23, w7, w9, asr #3
  eor w23, w7, w9, asr #3
  ands w23, w7, w9, asr #3
  bic w23, w7, w9, asr #3
  orn w23, w7, w9, asr #3
  eon w23, w7, w9, asr #3
  bics w23, w7, w9, asr #3
  and w23, w7, #0xff
  orr w23, w7, #0xff
  eor w23, w7, #0xff
  ands w23, w7, #0xff
  movz w23, #0xabcd, lsl #16
  movn w23, #0xabcd, lsl #16
  movk w23, #0xabcd, lsl #16
  sbfm w23, w7, #3, #21
  bfm w23, w7, #3, #21
  ubfm w23, w7, #3, #21
  csel w23, w7, w9, ne
  csinc w23, w7, w9, ne
  csinv w23, w7, w9, ne
  csneg w23, w7, w9, ne
  madd w23, w7, w9, w11
  msub w23, w7, w9, w11
  udiv w23, w7, w9
  sdiv w23, w7, w9
  lslv w23, w7, w9
  lsrv w23, w7, w9
  asrv w23, w7, w9
  rorv w23, w7, w9
  rbit w23, w7
  rev w23, w7
  rev16 w23, w7
  clz w23, w7
  ldr w23, [x7, #16]
  ldur w23, [x7, #-16]
  ldr w23, [x7, x9, lsl #2]
  str w23, [x7, #16]
  stur w23, [x7, #-16]
  ldrsb w23, [x7, #0]
  ldrsh w23, [x7, #0]
  add w24, w7, #4095
  add w24, w7, w9, lsl #31
  sub w24, w7, #4095
  sub w24, w7, w9, lsl #31
  adds w24, w7, #4095
  adds w24, w7, w9, lsl #31
  subs w24, w7, #4095
  subs w24, w7, w9, lsl #31
  and w24, w7, w9, asr #3
  orr w24, w7, w9, asr #3
  eor w24, w7, w9, asr #3
  ands w24, w7, w9, asr #3
  bic w24, w7, w9, asr #3
  orn w24, w7, w9, asr #3
  eon w24, w7, w9, asr #3
  bics w24, w7, w9, asr #3
  and w24, w7, #0xff
  orr w24, w7, #0xff
  eor w24, w7, #0xff
  ands w24, w7, #0xff
  movz w24, #0xabcd, lsl #16
  movn w24, #0xabcd, lsl #16
  movk w24, #0xabcd, lsl #16
  sbfm w24, w7, #3, #21
  bfm w24, w7, #3, #21
  ubfm w24, w7, #3, #21
  csel w24, w7, w9, ne
  csinc w24, w7, w9, ne
  csinv w24, w7, w9, ne
  csneg w24, w7, w9, ne
  madd w24, w7, w9, w11
  msub w24, w7, w9, w11
  udiv w24, w7, w9
  sdiv w24, w7, w9
  lslv w24, w7, w9
  lsrv w24, w7, w9
  asrv w24, w7, w9
  rorv w24, w7, w9
  rbit w24, w7
  rev w24, w7
  rev16 w24, w7
  clz w24, w7
  ldr w24, [x7, #16]
  ldur w24, [x7, #-16]
  ldr w24, [x7, x9, lsl #2]
  str w24, [x7, #16]
  stur w24, [x7, #-16]
  ldrsb w24, [x7, #0]
  ldrsh w24, [x7, #0]
  add w25, w7, #4095
  add w25, w7, w9, lsl #31
  sub w25, w7, #4095
  sub w25, w7, w9, lsl #31
  adds w25, w7, #4095
  adds w25, w7, w9, lsl #31
  subs w25, w7, #4095
  subs w25, w7, w9, lsl #31
  and w25, w7, w9, asr #3
  orr w25, w7, w9, asr #3
  eor w25, w7, w9, asr #3
  ands w25, w7, w9, asr #3
  bic w25, w7, w9, asr #3
  orn w25, w7, w9, asr #3
  eon w25, w7, w9, asr #3
  bics w25, w7, w9, asr #3
  and w25, w7, #0xff
  orr w25, w7, #0xff
  eor w25, w7, #0xff
  ands w25, w7, #0xff
  movz w25, #0xabcd, lsl #16
  movn w25, #0xabcd, lsl #16
  movk w25, #0xabcd, lsl #16
  sbfm w25, w7, #3, #21
  bfm w25, w7, #3, #21
  ubfm w25, w7, #3, #21
  csel w25, w7, w9, ne
  csinc w25, w7, w9, ne
  csinv w25, w7, w9, ne
  csneg w25, w7, w9, ne
  madd w25, w7, w9, w11
  msub w25, w7, w9, w11
  udiv w25, w7, w9
  sdiv w25, w7, w9
  lslv w25, w7, w9
  lsrv w25, w7, w9
  asrv w25, w7, w9
  rorv w25, w7, w9
  rbit w25, w7
  rev w25, w7
  rev16 w25, w7
  clz w25, w7
  ldr w25, [x7, #16]
  ldur w25, [x7, #-16]
  ldr w25, [x7, x9, lsl #2]
  str w25, [x7, #16]
  stur w25, [x7, #-16]
  ldrsb w25, [x7, #0]
  ldrsh w25, [x7, #0]
  add w26, w7, #4095
  add w26, w7, w9, lsl #31
  sub w26, w7, #4095
  sub w26, w7, w9, lsl #31
  adds w26, w7, #4095
  adds w26, w7, w9, lsl #31
  subs w26, w7, #4095
  subs w26, w7, w9, lsl #31
  and w26, w7, w9, asr #3
  orr w26, w7, w9, asr #3
  eor w26, w7, w9, asr #3
  ands w26, w7, w9, asr #3
  bic w26, w7, w9, asr #3
  orn w26, w7, w9, asr #3
  eon w26, w7, w9, asr #3
  bics w26, w7, w9, asr #3
  and w26, w7, #0xff
  orr w26, w7, #0xff
  eor w26, w7, #0xff
  ands w26, w7, #0xff
  movz w26, #0xabcd, lsl #16
  movn w26, #0xabcd, lsl #16
  movk w26, #0xabcd, lsl #16
  sbfm w26, w7, #3, #21
  bfm w26, w7, #3, #21
  ubfm w26, w7, #3, #21
  csel w26, w7, w9, ne
  csinc w26, w7, w9, ne
  csinv w26, w7, w9, ne
  csneg w26, w7, w9, ne
  madd w26, w7, w9, w11
  msub w26, w7, w9, w11
  udiv w26, w7, w9
  sdiv w26, w7, w9
  lslv w26, w7, w9
  lsrv w26, w7, w9
  asrv w26, w7, w9
  rorv w26, w7, w9
  rbit w26, w7
  rev w26, w7
  rev16 w26, w7
  clz w26, w7
  ldr w26, [x7, #16]
  ldur w26, [x7, #-16]
  ldr w26, [x7, x9, lsl #2]
  str w26, [x7, #16]
  stur w26, [x7, #-16]
  ldrsb w26, [x7, #0]
  ldrsh w26, [x7, #0]
  add w27, w7, #4095
  add w27, w7, w9, lsl #31
  sub w27, w7, #4095
  sub w27, w7, w9, lsl #31
  adds w27, w7, #4095
  adds w27, w7, w9, lsl #31
  subs w27, w7, #4095
  subs w27, w7, w9, lsl #31
  and w27, w7, w9, asr #3
  orr w27, w7, w9, asr #3
  eor w27, w7, w9, asr #3
  ands w27, w7, w9, asr #3
  bic w27, w7, w9, asr #3
  orn w27, w7, w9, asr #3
  eon w27, w7, w9, asr #3
  bics w27, w7, w9, asr #3
  and w27, w7, #0xff
  orr w27, w7, #0xff
  eor w27, w7, #0xff
  ands w27, w7, #0xff
  movz w27, #0xabcd, lsl #16
  movn w27, #0xabcd, lsl #16
  movk w27, #0xabcd, lsl #16
  sbfm w27, w7, #3, #21
  bfm w27, w7, #3, #21
  ubfm w27, w7, #3, #21
  csel w27, w7, w9, ne
  csinc w27, w7, w9, ne
  csinv w27, w7, w9, ne
  csneg w27, w7, w9, ne
  madd w27, w7, w9, w11
  msub w27, w7, w9, w11
  udiv w27, w7, w9
  sdiv w27, w7, w9
  lslv w27, w7, w9
  lsrv w27, w7, w9
  asrv w27, w7, w9
  rorv w27, w7, w9
  rbit w27, w7
  rev w27, w7
  rev16 w27, w7
  clz w27, w7
  ldr w27, [x7, #16]
  ldur w27, [x7, #-16]
  ldr w27, [x7, x9, lsl #2]
  str w27, [x7, #16]
  stur w27, [x7, #-16]
  ldrsb w27, [x7, #0]
  ldrsh w27, [x7, #0]
  add w28, w7, #4095
  add w28, w7, w9, lsl #31
  sub w28, w7, #4095
  sub w28, w7, w9, lsl #31
  adds w28, w7, #4095
  adds w28, w7, w9, lsl #31
  subs w28, w7, #4095
  subs w28, w7, w9, lsl #31
  and w28, w7, w9, asr #3
  orr w28, w7, w9, asr #3
  eor w28, w7, w9, asr #3
  ands w28, w7, w9, asr #3
  bic w28, w7, w9, asr #3
  orn w28, w7, w9, asr #3
  eon w28, w7, w9, asr #3
  bics w28, w7, w9, asr #3
  and w28, w7, #0xff
  orr w28, w7, #0xff
  eor w28, w7, #0xff
  ands w28, w7, #0xff
  movz w28, #0xabcd, lsl #16
  movn w28, #0xabcd, lsl #16
  movk w28, #0xabcd, lsl #16
  sbfm w28, w7, #3, #21
  bfm w28, w7, #3, #21
  ubfm w28, w7, #3, #21
  csel w28, w7, w9, ne
  csinc w28, w7, w9, ne
  csinv w28, w7, w9, ne
  csneg w28, w7, w9, ne
  madd w28, w7, w9, w11
  msub w28, w7, w9, w11
  udiv w28, w7, w9
  sdiv w28, w7, w9
  lslv w28, w7, w9
  lsrv w28, w7, w9
  asrv w28, w7, w9
  rorv w28, w7, w9
  rbit w28, w7
  rev w28, w7
  rev16 w28, w7
  clz w28, w7
  ldr w28, [x7, #16]
  ldur w28, [x7, #-16]
  ldr w28, [x7, x9, lsl #2]
  str w28, [x7, #16]
  stur w28, [x7, #-16]
  ldrsb w28, [x7, #0]
  ldrsh w28, [x7, #0]
  add w29, w7, #4095
  add w29, w7, w9, lsl #31
  sub w29, w7, #4095
  sub w29, w7, w9, lsl #31
  adds w29, w7, #4095
  adds w29, w7, w9, lsl #31
  subs w29, w7, #4095
  subs w29, w7, w9, lsl #31
  and w29, w7, w9, asr #3
  orr w29, w7, w9, asr #3
  eor w29, w7, w9, asr #3
  ands w29, w7, w9, asr #3
  bic w29, w7, w9, asr #3
  orn w29, w7, w9, asr #3
  eon w29, w7, w9, asr #3
  bics w29, w7, w9, asr #3
  and w29, w7, #0xff
  orr w29, w7, #0xff
  eor w29, w7, #0xff
  ands w29, w7, #0xff
  movz w29, #0xabcd, lsl #16
  movn w29, #0xabcd, lsl #16
  movk w29, #0xabcd, lsl #16
  sbfm w29, w7, #3, #21
  bfm w29, w7, #3, #21
  ubfm w29, w7, #3, #21
  csel w29, w7, w9, ne
  csinc w29, w7, w9, ne
  csinv w29, w7, w9, ne
  csneg w29, w7, w9, ne
  madd w29, w7, w9, w11
  msub w29, w7, w9, w11
  udiv w29, w7, w9
  sdiv w29, w7, w9
  lslv w29, w7, w9
  lsrv w29, w7, w9
  asrv w29, w7, w9
  rorv w29, w7, w9
  rbit w29, w7
  rev w29, w7
  rev16 w29, w7
  clz w29, w7
  ldr w29, [x7, #16]
  ldur w29, [x7, #-16]
  ldr w29, [x7, x9, lsl #2]
  str w29, [x7, #16]
  stur w29, [x7, #-16]
  ldrsb w29, [x7, #0]
  ldrsh w29, [x7, #0]
  add w30, w7, #4095
  add w30, w7, w9, lsl #31
  sub w30, w7, #4095
  sub w30, w7, w9, lsl #31
  adds w30, w7, #4095
  adds w30, w7, w9, lsl #31
  subs w30, w7, #4095
  subs w30, w7, w9, lsl #31
  and w30, w7, w9, asr #3
  orr w30, w7, w9, asr #3
  eor w30, w7, w9, asr #3
  ands w30, w7, w9, asr #3
  bic w30, w7, w9, asr #3
  orn w30, w7, w9, asr #3
  eon w30, w7, w9, asr #3
  bics w30, w7, w9, asr #3
  and w30, w7, #0xff
  orr w30, w7, #0xff
  eor w30, w7, #0xff
  ands w30, w7, #0xff
  movz w30, #0xabcd, lsl #16
  movn w30, #0xabcd, lsl #16
  movk w30, #0xabcd, lsl #16
  sbfm w30, w7, #3, #21
  bfm w30, w7, #3, #21
  ubfm w30, w7, #3, #21
  csel w30, w7, w9, ne
  csinc w30, w7, w9, ne
  csinv w30, w7, w9, ne
  csneg w30, w7, w9, ne
  madd w30, w7, w9, w11
  msub w30, w7, w9, w11
  udiv w30, w7, w9
  sdiv w30, w7, w9
  lslv w30, w7, w9
  lsrv w30, w7, w9
  asrv w30, w7, w9
  rorv w30, w7, w9
  rbit w30, w7
  rev w30, w7
  rev16 w30, w7
  clz w30, w7
  ldr w30, [x7, #16]
  ldur w30, [x7, #-16]
  ldr w30, [x7, x9, lsl #2]
  str w30, [x7, #16]
  stur w30, [x7, #-16]
  ldrsb w30, [x7, #0]
  ldrsh w30, [x7, #0]
  add wsp, w7, #4095
  add wzr, w7, w9, lsl #31
  sub wsp, w7, #4095
  sub wzr, w7, w9, lsl #31
  adds wzr, w7, #4095
  adds wzr, w7, w9, lsl #31
  subs wzr, w7, #4095
  subs wzr, w7, w9, lsl #31
  and wzr, w7, w9, asr #3
  orr wzr, w7, w9, asr #3
  eor wzr, w7, w9, asr #3
  ands wzr, w7, w9, asr #3
  bic wzr, w7, w9, asr #3
  orn wzr, w7, w9, asr #3
  eon wzr, w7, w9, asr #3
  bics wzr, w7, w9, asr #3
  and wsp, w7, #0xff
  orr wsp, w7, #0xff
  eor wsp, w7, #0xff
  ands wzr, w7, #0xff
  movz wzr, #0xabcd, lsl #16
  movn wzr, #0xabcd, lsl #16
  movk wzr, #0xabcd, lsl #16
  sbfm wzr, w7, #3, #21
  bfm wzr, w7, #3, #21
  ubfm wzr, w7, #3, #21
  csel wzr, w7, w9, ne
  csinc wzr, w7, w9, ne
  csinv wzr, w7, w9, ne
  csneg wzr, w7, w9, ne
  madd wzr, w7, w9, w11
  msub wzr, w7, w9, w11
  udiv wzr, w7, w9
  sdiv wzr, w7, w9
  lslv wzr, w7, w9
  lsrv wzr, w7, w9
  asrv wzr, w7, w9
  rorv wzr, w7, w9
  rbit wzr, w7
  rev wzr, w7
  rev16 wzr, w7
  clz wzr, w7
  ldr wzr, [x7, #16]
  ldur wzr, [x7, #-16]
  ldr wzr, [x7, x9, lsl #2]
  str wzr, [x7, #16]
  stur wzr, [x7, #-16]
  ldrsb wzr, [x7, #0]
  ldrsh wzr, [x7, #0]
  ldr w3, [x7], #8
  ldr w3, [x7, #8]!
  ldp w3, w5, [x7]
  ror w3, w7, #3
  add x0, x7, #4095
  add x0, x7, x9, lsl #63
  sub x0, x7, #4095
  sub x0, x7, x9, lsl #63
  adds x0, x7, #4095
  adds x0, x7, x9, lsl #63
  subs x0, x7, #4095
  subs x0, x7, x9, lsl #63
  add x0, x7, x9, uxtx
  sub x0, x7, x9, uxtx
  and x0, x7, x9, asr #3
  orr x0, x7, x9, asr #3
  eor x0, x7, x9, asr #3
  ands x0, x7, x9, asr #3
  bic x0, x7, x9, asr #3
  orn x0, x7, x9, asr #3
  eon x0, x7, x9, asr #3
  bics x0, x7, x9, asr #3
  and x0, x7, #0xff
  orr x0, x7, #0xff
  eor x0, x7, #0xff
  ands x0, x7, #0xff
  movz x0, #0xabcd, lsl #48
  movn x0, #0xabcd, lsl #48
  movk x0, #0xabcd, lsl #48
  sbfm x0, x7, #3, #21
  bfm x0, x7, #3, #21
  ubfm x0, x7, #3, #21
  csel x0, x7, x9, ne
  csinc x0, x7, x9, ne
  csinv x0, x7, x9, ne
  csneg x0, x7, x9, ne
  madd x0, x7, x9, x11
  msub x0, x7, x9, x11
  udiv x0, x7, x9
  sdiv x0, x7, x9
  lslv x0, x7, x9
  lsrv x0, x7, x9
  asrv x0, x7, x9
  rorv x0, x7, x9
  rbit x0, x7
  rev x0, x7
  rev16 x0, x7
  clz x0, x7
  ldr x0, [x7, #16]
  ldur x0, [x7, #-16]
  ldr x0, [x7, x9, lsl #3]
  str x0, [x7, #16]
  stur x0, [x7, #-16]
  ldrsb x0, [x7, #0]
  ldrsh x0, [x7, #0]
  ldrsw x0, [x7, #4]
  add x1, x7, #4095
  add x1, x7, x9, lsl #63
  sub x1, x7, #4095
  sub x1, x7, x9, lsl #63
  adds x1, x7, #4095
  adds x1, x7, x9, lsl #63
  subs x1, x7, #4095
  subs x1, x7, x9, lsl #63
  add x1, x7, x9, uxtx
  sub x1, x7, x9, uxtx
  and x1, x7, x9, asr #3
  orr x1, x7, x9, asr #3
  eor x1, x7, x9, asr #3
  ands x1, x7, x9, asr #3
  bic x1, x7, x9, asr #3
  orn x1, x7, x9, asr #3
  eon x1, x7, x9, asr #3
  bics x1, x7, x9, asr #3
  and x1, x7, #0xff
  orr x1, x7, #0xff
  eor x1, x7, #0xff
  ands x1, x7, #0xff
  movz x1, #0xabcd, lsl #48
  movn x1, #0xabcd, lsl #48
  movk x1, #0xabcd, lsl #48
  sbfm x1, x7, #3, #21
  bfm x1, x7, #3, #21
  ubfm x1, x7, #3, #21
  csel x1, x7, x9, ne
  csinc x1, x7, x9, ne
  csinv x1, x7, x9, ne
  csneg x1, x7, x9, ne
  madd x1, x7, x9, x11
  msub x1, x7, x9, x11
  udiv x1, x7, x9
  sdiv x1, x7, x9
  lslv x1, x7, x9
  lsrv x1, x7, x9
  asrv x1, x7, x9
  rorv x1, x7, x9
  rbit x1, x7
  rev x1, x7
  rev16 x1, x7
  clz x1, x7
  ldr x1, [x7, #16]
  ldur x1, [x7, #-16]
  ldr x1, [x7, x9, lsl #3]
  str x1, [x7, #16]
  stur x1, [x7, #-16]
  ldrsb x1, [x7, #0]
  ldrsh x1, [x7, #0]
  ldrsw x1, [x7, #4]
  add x2, x7, #4095
  add x2, x7, x9, lsl #63
  sub x2, x7, #4095
  sub x2, x7, x9, lsl #63
  adds x2, x7, #4095
  adds x2, x7, x9, lsl #63
  subs x2, x7, #4095
  subs x2, x7, x9, lsl #63
  add x2, x7, x9, uxtx
  sub x2, x7, x9, uxtx
  and x2, x7, x9, asr #3
  orr x2, x7, x9, asr #3
  eor x2, x7, x9, asr #3
  ands x2, x7, x9, asr #3
  bic x2, x7, x9, asr #3
  orn x2, x7, x9, asr #3
  eon x2, x7, x9, asr #3
  bics x2, x7, x9, asr #3
  and x2, x7, #0xff
  orr x2, x7, #0xff
  eor x2, x7, #0xff
  ands x2, x7, #0xff
  movz x2, #0xabcd, lsl #48
  movn x2, #0xabcd, lsl #48
  movk x2, #0xabcd, lsl #48
  sbfm x2, x7, #3, #21
  bfm x2, x7, #3, #21
  ubfm x2, x7, #3, #21
  csel x2, x7, x9, ne
  csinc x2, x7, x9, ne
  csinv x2, x7, x9, ne
  csneg x2, x7, x9, ne
  madd x2, x7, x9, x11
  msub x2, x7, x9, x11
  udiv x2, x7, x9
  sdiv x2, x7, x9
  lslv x2, x7, x9
  lsrv x2, x7, x9
  asrv x2, x7, x9
  rorv x2, x7, x9
  rbit x2, x7
  rev x2, x7
  rev16 x2, x7
  clz x2, x7
  ldr x2, [x7, #16]
  ldur x2, [x7, #-16]
  ldr x2, [x7, x9, lsl #3]
  str x2, [x7, #16]
  stur x2, [x7, #-16]
  ldrsb x2, [x7, #0]
  ldrsh x2, [x7, #0]
  ldrsw x2, [x7, #4]
  add x3, x7, #4095
  add x3, x7, x9, lsl #63
  sub x3, x7, #4095
  sub x3, x7, x9, lsl #63
  adds x3, x7, #4095
  adds x3, x7, x9, lsl #63
  subs x3, x7, #4095
  subs x3, x7, x9, lsl #63
  add x3, x7, x9, uxtx
  sub x3, x7, x9, uxtx
  and x3, x7, x9, asr #3
  orr x3, x7, x9, asr #3
  eor x3, x7, x9, asr #3
  ands x3, x7, x9, asr #3
  bic x3, x7, x9, asr #3
  orn x3, x7, x9, asr #3
  eon x3, x7, x9, asr #3
  bics x3, x7, x9, asr #3
  and x3, x7, #0xff
  orr x3, x7, #0xff
  eor x3, x7, #0xff
  ands x3, x7, #0xff
  movz x3, #0xabcd, lsl #48
  movn x3, #0xabcd, lsl #48
  movk x3, #0xabcd, lsl #48
  sbfm x3, x7, #3, #21
  bfm x3, x7, #3, #21
  ubfm x3, x7, #3, #21
  csel x3, x7, x9, ne
  csinc x3, x7, x9, ne
  csinv x3, x7, x9, ne
  csneg x3, x7, x9, ne
  madd x3, x7, x9, x11
  msub x3, x7, x9, x11
  udiv x3, x7, x9
  sdiv x3, x7, x9
  lslv x3, x7, x9
  lsrv x3, x7, x9
  asrv x3, x7, x9
  rorv x3, x7, x9
  rbit x3, x7
  rev x3, x7
  rev16 x3, x7
  clz x3, x7
  ldr x3, [x7, #16]
  ldur x3, [x7, #-16]
  ldr x3, [x7, x9, lsl #3]
  str x3, [x7, #16]
  stur x3, [x7, #-16]
  ldrsb x3, [x7, #0]
  ldrsh x3, [x7, #0]
  ldrsw x3, [x7, #4]
  add x4, x7, #4095
  add x4, x7, x9, lsl #63
  sub x4, x7, #4095
  sub x4, x7, x9, lsl #63
  adds x4, x7, #4095
  adds x4, x7, x9, lsl #63
  subs x4, x7, #4095
  subs x4, x7, x9, lsl #63
  add x4, x7, x9, uxtx
  sub x4, x7, x9, uxtx
  and x4, x7, x9, asr #3
  orr x4, x7, x9, asr #3
  eor x4, x7, x9, asr #3
  ands x4, x7, x9, asr #3
  bic x4, x7, x9, asr #3
  orn x4, x7, x9, asr #3
  eon x4, x7, x9, asr #3
  bics x4, x7, x9, asr #3
  and x4, x7, #0xff
  orr x4, x7, #0xff
  eor x4, x7, #0xff
  ands x4, x7, #0xff
  movz x4, #0xabcd, lsl #48
  movn x4, #0xabcd, lsl #48
  movk x4, #0xabcd, lsl #48
  sbfm x4, x7, #3, #21
  bfm x4, x7, #3, #21
  ubfm x4, x7, #3, #21
  csel x4, x7, x9, ne
  csinc x4, x7, x9, ne
  csinv x4, x7, x9, ne
  csneg x4, x7, x9, ne
  madd x4, x7, x9, x11
  msub x4, x7, x9, x11
  udiv x4, x7, x9
  sdiv x4, x7, x9
  lslv x4, x7, x9
  lsrv x4, x7, x9
  asrv x4, x7, x9
  rorv x4, x7, x9
  rbit x4, x7
  rev x4, x7
  rev16 x4, x7
  clz x4, x7
  ldr x4, [x7, #16]
  ldur x4, [x7, #-16]
  ldr x4, [x7, x9, lsl #3]
  str x4, [x7, #16]
  stur x4, [x7, #-16]
  ldrsb x4, [x7, #0]
  ldrsh x4, [x7, #0]
  ldrsw x4, [x7, #4]
  add x5, x7, #4095
  add x5, x7, x9, lsl #63
  sub x5, x7, #4095
  sub x5, x7, x9, lsl #63
  adds x5, x7, #4095
  adds x5, x7, x9, lsl #63
  subs x5, x7, #4095
  subs x5, x7, x9, lsl #63
  add x5, x7, x9, uxtx
  sub x5, x7, x9, uxtx
  and x5, x7, x9, asr #3
  orr x5, x7, x9, asr #3
  eor x5, x7, x9, asr #3
  ands x5, x7, x9, asr #3
  bic x5, x7, x9, asr #3
  orn x5, x7, x9, asr #3
  eon x5, x7, x9, asr #3
  bics x5, x7, x9, asr #3
  and x5, x7, #0xff
  orr x5, x7, #0xff
  eor x5, x7, #0xff
  ands x5, x7, #0xff
  movz x5, #0xabcd, lsl #48
  movn x5, #0xabcd, lsl #48
  movk x5, #0xabcd, lsl #48
  sbfm x5, x7, #3, #21
  bfm x5, x7, #3, #21
  ubfm x5, x7, #3, #21
  csel x5, x7, x9, ne
  csinc x5, x7, x9, ne
  csinv x5, x7, x9, ne
  csneg x5, x7, x9, ne
  madd x5, x7, x9, x11
  msub x5, x7, x9, x11
  udiv x5, x7, x9
  sdiv x5, x7, x9
  lslv x5, x7, x9
  lsrv x5, x7, x9
  asrv x5, x7, x9
  rorv x5, x7, x9
  rbit x5, x7
  rev x5, x7
  rev16 x5, x7
  clz x5, x7
  ldr x5, [x7, #16]
  ldur x5, [x7, #-16]
  ldr x5, [x7, x9, lsl #3]
  str x5, [x7, #16]
  stur x5, [x7, #-16]
  ldrsb x5, [x7, #0]
  ldrsh x5, [x7, #0]
  ldrsw x5, [x7, #4]
  add x6, x7, #4095
  add x6, x7, x9, lsl #63
  sub x6, x7, #4095
  sub x6, x7, x9, lsl #63
  adds x6, x7, #4095
  adds x6, x7, x9, lsl #63
  subs x6, x7, #4095
  subs x6, x7, x9, lsl #63
  add x6, x7, x9, uxtx
  sub x6, x7, x9, uxtx
  and x6, x7, x9, asr #3
  orr x6, x7, x9, asr #3
  eor x6, x7, x9, asr #3
  ands x6, x7, x9, asr #3
  bic x6, x7, x9, asr #3
  orn x6, x7, x9, asr #3
  eon x6, x7, x9, asr #3
  bics x6, x7, x9, asr #3
  and x6, x7, #0xff
  orr x6, x7, #0xff
  eor x6, x7, #0xff
  ands x6, x7, #0xff
  movz x6, #0xabcd, lsl #48
  movn x6, #0xabcd, lsl #48
  movk x6, #0xabcd, lsl #48
  sbfm x6, x7, #3, #21
  bfm x6, x7, #3, #21
  ubfm x6, x7, #3, #21
  csel x6, x7, x9, ne
  csinc x6, x7, x9, ne
  csinv x6, x7, x9, ne
  csneg x6, x7, x9, ne
  madd x6, x7, x9, x11
  msub x6, x7, x9, x11
  udiv x6, x7, x9
  sdiv x6, x7, x9
  lslv x6, x7, x9
  lsrv x6, x7, x9
  asrv x6, x7, x9
  rorv x6, x7, x9
  rbit x6, x7
  rev x6, x7
  rev16 x6, x7
  clz x6, x7
  ldr x6, [x7, #16]
  ldur x6, [x7, #-16]
  ldr x6, [x7, x9, lsl #3]
  str x6, [x7, #16]
  stur x6, [x7, #-16]
  ldrsb x6, [x7, #0]
  ldrsh x6, [x7, #0]
  ldrsw x6, [x7, #4]
  add x7, x7, #4095
  add x7, x7, x9, lsl #63
  sub x7, x7, #4095
  sub x7, x7, x9, lsl #63
  adds x7, x7, #4095
  adds x7, x7, x9, lsl #63
  subs x7, x7, #4095
  subs x7, x7, x9, lsl #63
  add x7, x7, x9, uxtx
  sub x7, x7, x9, uxtx
  and x7, x7, x9, asr #3
  orr x7, x7, x9, asr #3
  eor x7, x7, x9, asr #3
  ands x7, x7, x9, asr #3
  bic x7, x7, x9, asr #3
  orn x7, x7, x9, asr #3
  eon x7, x7, x9, asr #3
  bics x7, x7, x9, asr #3
  and x7, x7, #0xff
  orr x7, x7, #0xff
  eor x7, x7, #0xff
  ands x7, x7, #0xff
  movz x7, #0xabcd, lsl #48
  movn x7, #0xabcd, lsl #48
  movk x7, #0xabcd, lsl #48
  sbfm x7, x7, #3, #21
  bfm x7, x7, #3, #21
  ubfm x7, x7, #3, #21
  csel x7, x7, x9, ne
  csinc x7, x7, x9, ne
  csinv x7, x7, x9, ne
  csneg x7, x7, x9, ne
  madd x7, x7, x9, x11
  msub x7, x7, x9, x11
  udiv x7, x7, x9
  sdiv x7, x7, x9
  lslv x7, x7, x9
  lsrv x7, x7, x9
  asrv x7, x7, x9
  rorv x7, x7, x9
  rbit x7, x7
  rev x7, x7
  rev16 x7, x7
  clz x7, x7
  ldr x7, [x7, #16]
  ldur x7, [x7, #-16]
  ldr x7, [x7, x9, lsl #3]
  str x7, [x7, #16]
  stur x7, [x7, #-16]
  ldrsb x7, [x7, #0]
  ldrsh x7, [x7, #0]
  ldrsw x7, [x7, #4]
  add x8, x7, #4095
  add x8, x7, x9, lsl #63
  sub x8, x7, #4095
  sub x8, x7, x9, lsl #63
  adds x8, x7, #4095
  adds x8, x7, x9, lsl #63
  subs x8, x7, #4095
  subs x8, x7, x9, lsl #63
  add x8, x7, x9, uxtx
  sub x8, x7, x9, uxtx
  and x8, x7, x9, asr #3
  orr x8, x7, x9, asr #3
  eor x8, x7, x9, asr #3
  ands x8, x7, x9, asr #3
  bic x8, x7, x9, asr #3
  orn x8, x7, x9, asr #3
  eon x8, x7, x9, asr #3
  bics x8, x7, x9, asr #3
  and x8, x7, #0xff
  orr x8, x7, #0xff
  eor x8, x7, #0xff
  ands x8, x7, #0xff
  movz x8, #0xabcd, lsl #48
  movn x8, #0xabcd, lsl #48
  movk x8, #0xabcd, lsl #48
  sbfm x8, x7, #3, #21
  bfm x8, x7, #3, #21
  ubfm x8, x7, #3, #21
  csel x8, x7, x9, ne
  csinc x8, x7, x9, ne
  csinv x8, x7, x9, ne
  csneg x8, x7, x9, ne
  madd x8, x7, x9, x11
  msub x8, x7, x9, x11
  udiv x8, x7, x9
  sdiv x8, x7, x9
  lslv x8, x7, x9
  lsrv x8, x7, x9
  asrv x8, x7, x9
  rorv x8, x7, x9
  rbit x8, x7
  rev x8, x7
  rev16 x8, x7
  clz x8, x7
  ldr x8, [x7, #16]
  ldur x8, [x7, #-16]
  ldr x8, [x7, x9, lsl #3]
  str x8, [x7, #16]
  stur x8, [x7, #-16]
  ldrsb x8, [x7, #0]
  ldrsh x8, [x7, #0]
  ldrsw x8, [x7, #4]
  add x9, x7, #4095
  add x9, x7, x9, lsl #63
  sub x9, x7, #4095
  sub x9, x7, x9, lsl #63
  adds x9, x7, #4095
  adds x9, x7, x9, lsl #63
  subs x9, x7, #4095
  subs x9, x7, x9, lsl #63
  add x9, x7, x9, uxtx
  sub x9, x7, x9, uxtx
  and x9, x7, x9, asr #3
  orr x9, x7, x9, asr #3
  eor x9, x7, x9, asr #3
  ands x9, x7, x9, asr #3
  bic x9, x7, x9, asr #3
  orn x9, x7, x9, asr #3
  eon x9, x7, x9, asr #3
  bics x9, x7, x9, asr #3
  and x9, x7, #0xff
  orr x9, x7, #0xff
  eor x9, x7, #0xff
  ands x9, x7, #0xff
  movz x9, #0xabcd, lsl #48
  movn x9, #0xabcd, lsl #48
  movk x9, #0xabcd, lsl #48
  sbfm x9, x7, #3, #21
  bfm x9, x7, #3, #21
  ubfm x9, x7, #3, #21
  csel x9, x7, x9, ne
  csinc x9, x7, x9, ne
  csinv x9, x7, x9, ne
  csneg x9, x7, x9, ne
  madd x9, x7, x9, x11
  msub x9, x7, x9, x11
  udiv x9, x7, x9
  sdiv x9, x7, x9
  lslv x9, x7, x9
  lsrv x9, x7, x9
  asrv x9, x7, x9
  rorv x9, x7, x9
  rbit x9, x7
  rev x9, x7
  rev16 x9, x7
  clz x9, x7
  ldr x9, [x7, #16]
  ldur x9, [x7, #-16]
  ldr x9, [x7, x9, lsl #3]
  str x9, [x7, #16]
  stur x9, [x7, #-16]
  ldrsb x9, [x7, #0]
  ldrsh x9, [x7, #0]
  ldrsw x9, [x7, #4]
  add x10, x7, #4095
  add x10, x7, x9, lsl #63
  sub x10, x7, #4095
  sub x10, x7, x9, lsl #63
  adds x10, x7, #4095
  adds x10, x7, x9, lsl #63
  subs x10, x7, #4095
  subs x10, x7, x9, lsl #63
  add x10, x7, x9, uxtx
  sub x10, x7, x9, uxtx
  and x10, x7, x9, asr #3
  orr x10, x7, x9, asr #3
  eor x10, x7, x9, asr #3
  ands x10, x7, x9, asr #3
  bic x10, x7, x9, asr #3
  orn x10, x7, x9, asr #3
  eon x10, x7, x9, asr #3
  bics x10, x7, x9, asr #3
  and x10, x7, #0xff
  orr x10, x7, #0xff
  eor x10, x7, #0xff
  ands x10, x7, #0xff
  movz x10, #0xabcd, lsl #48
  movn x10, #0xabcd, lsl #48
  movk x10, #0xabcd, lsl #48
  sbfm x10, x7, #3, #21
  bfm x10, x7, #3, #21
  ubfm x10, x7, #3, #21
  csel x10, x7, x9, ne
  csinc x10, x7, x9, ne
  csinv x10, x7, x9, ne
  csneg x10, x7, x9, ne
  madd x10, x7, x9, x11
  msub x10, x7, x9, x11
  udiv x10, x7, x9
  sdiv x10, x7, x9
  lslv x10, x7, x9
  lsrv x10, x7, x9
  asrv x10, x7, x9
  rorv x10, x7, x9
  rbit x10, x7
  rev x10, x7
  rev16 x10, x7
  clz x10, x7
  ldr x10, [x7, #16]
  ldur x10, [x7, #-16]
  ldr x10, [x7, x9, lsl #3]
  str x10, [x7, #16]
  stur x10, [x7, #-16]
  ldrsb x10, [x7, #0]
  ldrsh x10, [x7, #0]
  ldrsw x10, [x7, #4]
  add x11, x7, #4095
  add x11, x7, x9, lsl #63
  sub x11, x7, #4095
  sub x11, x7, x9, lsl #63
  adds x11, x7, #4095
  adds x11, x7, x9, lsl #63
  subs x11, x7, #4095
  subs x11, x7, x9, lsl #63
  add x11, x7, x9, uxtx
  sub x11, x7, x9, uxtx
  and x11, x7, x9, asr #3
  orr x11, x7, x9, asr #3
  eor x11, x7, x9, asr #3
  ands x11, x7, x9, asr #3
  bic x11, x7, x9, asr #3
  orn x11, x7, x9, asr #3
  eon x11, x7, x9, asr #3
  bics x11, x7, x9, asr #3
  and x11, x7, #0xff
  orr x11, x7, #0xff
  eor x11, x7, #0xff
  ands x11, x7, #0xff
  movz x11, #0xabcd, lsl #48
  movn x11, #0xabcd, lsl #48
  movk x11, #0xabcd, lsl #48
  sbfm x11, x7, #3, #21
  bfm x11, x7, #3, #21
  ubfm x11, x7, #3, #21
  csel x11, x7, x9, ne
  csinc x11, x7, x9, ne
  csinv x11, x7, x9, ne
  csneg x11, x7, x9, ne
  madd x11, x7, x9, x11
  msub x11, x7, x9, x11
  udiv x11, x7, x9
  sdiv x11, x7, x9
  lslv x11, x7, x9
  lsrv x11, x7, x9
  asrv x11, x7, x9
  rorv x11, x7, x9
  rbit x11, x7
  rev x11, x7
  rev16 x11, x7
  clz x11, x7
  ldr x11, [x7, #16]
  ldur x11, [x7, #-16]
  ldr x11, [x7, x9, lsl #3]
  str x11, [x7, #16]
  stur x11, [x7, #-16]
  ldrsb x11, [x7, #0]
  ldrsh x11, [x7, #0]
  ldrsw x11, [x7, #4]
  add x12, x7, #4095
  add x12, x7, x9, lsl #63
  sub x12, x7, #4095
  sub x12, x7, x9, lsl #63
  adds x12, x7, #4095
  adds x12, x7, x9, lsl #63
  subs x12, x7, #4095
  subs x12, x7, x9, lsl #63
  add x12, x7, x9, uxtx
  sub x12, x7, x9, uxtx
  and x12, x7, x9, asr #3
  orr x12, x7, x9, asr #3
  eor x12, x7, x9, asr #3
  ands x12, x7, x9, asr #3
  bic x12, x7, x9, asr #3
  orn x12, x7, x9, asr #3
  eon x12, x7, x9, asr #3
  bics x12, x7, x9, asr #3
  and x12, x7, #0xff
  orr x12, x7, #0xff
  eor x12, x7, #0xff
  ands x12, x7, #0xff
  movz x12, #0xabcd, lsl #48
  movn x12, #0xabcd, lsl #48
  movk x12, #0xabcd, lsl #48
  sbfm x12, x7, #3, #21
  bfm x12, x7, #3, #21
  ubfm x12, x7, #3, #21
  csel x12, x7, x9, ne
  csinc x12, x7, x9, ne
  csinv x12, x7, x9, ne
  csneg x12, x7, x9, ne
  madd x12, x7, x9, x11
  msub x12, x7, x9, x11
  udiv x12, x7, x9
  sdiv x12, x7, x9
  lslv x12, x7, x9
  lsrv x12, x7, x9
  asrv x12, x7, x9
  rorv x12, x7, x9
  rbit x12, x7
  rev x12, x7
  rev16 x12, x7
  clz x12, x7
  ldr x12, [x7, #16]
  ldur x12, [x7, #-16]
  ldr x12, [x7, x9, lsl #3]
  str x12, [x7, #16]
  stur x12, [x7, #-16]
  ldrsb x12, [x7, #0]
  ldrsh x12, [x7, #0]
  ldrsw x12, [x7, #4]
  add x13, x7, #4095
  add x13, x7, x9, lsl #63
  sub x13, x7, #4095
  sub x13, x7, x9, lsl #63
  adds x13, x7, #4095
  adds x13, x7, x9, lsl #63
  subs x13, x7, #4095
  subs x13, x7, x9, lsl #63
  add x13, x7, x9, uxtx
  sub x13, x7, x9, uxtx
  and x13, x7, x9, asr #3
  orr x13, x7, x9, asr #3
  eor x13, x7, x9, asr #3
  ands x13, x7, x9, asr #3
  bic x13, x7, x9, asr #3
  orn x13, x7, x9, asr #3
  eon x13, x7, x9, asr #3
  bics x13, x7, x9, asr #3
  and x13, x7, #0xff
  orr x13, x7, #0xff
  eor x13, x7, #0xff
  ands x13, x7, #0xff
  movz x13, #0xabcd, lsl #48
  movn x13, #0xabcd, lsl #48
  movk x13, #0xabcd, lsl #48
  sbfm x13, x7, #3, #21
  bfm x13, x7, #3, #21
  ubfm x13, x7, #3, #21
  csel x13, x7, x9, ne
  csinc x13, x7, x9, ne
  csinv x13, x7, x9, ne
  csneg x13, x7, x9, ne
  madd x13, x7, x9, x11
  msub x13, x7, x9, x11
  udiv x13, x7, x9
  sdiv x13, x7, x9
  lslv x13, x7, x9
  lsrv x13, x7, x9
  asrv x13, x7, x9
  rorv x13, x7, x9
  rbit x13, x7
  rev x13, x7
  rev16 x13, x7
  clz x13, x7
  ldr x13, [x7, #16]
  ldur x13, [x7, #-16]
  ldr x13, [x7, x9, lsl #3]
  str x13, [x7, #16]
  stur x13, [x7, #-16]
  ldrsb x13, [x7, #0]
  ldrsh x13, [x7, #0]
  ldrsw x13, [x7, #4]
  add x14, x7, #4095
  add x14, x7, x9, lsl #63
  sub x14, x7, #4095
  sub x14, x7, x9, lsl #63
  adds x14, x7, #4095
  adds x14, x7, x9, lsl #63
  subs x14, x7, #4095
  subs x14, x7, x9, lsl #63
  add x14, x7, x9, uxtx
  sub x14, x7, x9, uxtx
  and x14, x7, x9, asr #3
  orr x14, x7, x9, asr #3
  eor x14, x7, x9, asr #3
  ands x14, x7, x9, asr #3
  bic x14, x7, x9, asr #3
  orn x14, x7, x9, asr #3
  eon x14, x7, x9, asr #3
  bics x14, x7, x9, asr #3
  and x14, x7, #0xff
  orr x14, x7, #0xff
  eor x14, x7, #0xff
  ands x14, x7, #0xff
  movz x14, #0xabcd, lsl #48
  movn x14, #0xabcd, lsl #48
  movk x14, #0xabcd, lsl #48
  sbfm x14, x7, #3, #21
  bfm x14, x7, #3, #21
  ubfm x14, x7, #3, #21
  csel x14, x7, x9, ne
  csinc x14, x7, x9, ne
  csinv x14, x7, x9, ne
  csneg x14, x7, x9, ne
  madd x14, x7, x9, x11
  msub x14, x7, x9, x11
  udiv x14, x7, x9
  sdiv x14, x7, x9
  lslv x14, x7, x9
  lsrv x14, x7, x9
  asrv x14, x7, x9
  rorv x14, x7, x9
  rbit x14, x7
  rev x14, x7
  rev16 x14, x7
  clz x14, x7
  ldr x14, [x7, #16]
  ldur x14, [x7, #-16]
  ldr x14, [x7, x9, lsl #3]
  str x14, [x7, #16]
  stur x14, [x7, #-16]
  ldrsb x14, [x7, #0]
  ldrsh x14, [x7, #0]
  ldrsw x14, [x7, #4]
  add x15, x7, #4095
  add x15, x7, x9, lsl #63
  sub x15, x7, #4095
  sub x15, x7, x9, lsl #63
  adds x15, x7, #4095
  adds x15, x7, x9, lsl #63
  subs x15, x7, #4095
  subs x15, x7, x9, lsl #63
  add x15, x7, x9, uxtx
  sub x15, x7, x9, uxtx
  and x15, x7, x9, asr #3
  orr x15, x7, x9, asr #3
  eor x15, x7, x9, asr #3
  ands x15, x7, x9, asr #3
  bic x15, x7, x9, asr #3
  orn x15, x7, x9, asr #3
  eon x15, x7, x9, asr #3
  bics x15, x7, x9, asr #3
  and x15, x7, #0xff
  orr x15, x7, #0xff
  eor x15, x7, #0xff
  ands x15, x7, #0xff
  movz x15, #0xabcd, lsl #48
  movn x15, #0xabcd, lsl #48
  movk x15, #0xabcd, lsl #48
  sbfm x15, x7, #3, #21
  bfm x15, x7, #3, #21
  ubfm x15, x7, #3, #21
  csel x15, x7, x9, ne
  csinc x15, x7, x9, ne
  csinv x15, x7, x9, ne
  csneg x15, x7, x9, ne
  madd x15, x7, x9, x11
  msub x15, x7, x9, x11
  udiv x15, x7, x9
  sdiv x15, x7, x9
  lslv x15, x7, x9
  lsrv x15, x7, x9
  asrv x15, x7, x9
  rorv x15, x7, x9
  rbit x15, x7
  rev x15, x7
  rev16 x15, x7
  clz x15, x7
  ldr x15, [x7, #16]
  ldur x15, [x7, #-16]
  ldr x15, [x7, x9, lsl #3]
  str x15, [x7, #16]
  stur x15, [x7, #-16]
  ldrsb x15, [x7, #0]
  ldrsh x15, [x7, #0]
  ldrsw x15, [x7, #4]
  add x16, x7, #4095
  add x16, x7, x9, lsl #63
  sub x16, x7, #4095
  sub x16, x7, x9, lsl #63
  adds x16, x7, #4095
  adds x16, x7, x9, lsl #63
  subs x16, x7, #4095
  subs x16, x7, x9, lsl #63
  add x16, x7, x9, uxtx
  sub x16, x7, x9, uxtx
  and x16, x7, x9, asr #3
  orr x16, x7, x9, asr #3
  eor x16, x7, x9, asr #3
  ands x16, x7, x9, asr #3
  bic x16, x7, x9, asr #3
  orn x16, x7, x9, asr #3
  eon x16, x7, x9, asr #3
  bics x16, x7, x9, asr #3
  and x16, x7, #0xff
  orr x16, x7, #0xff
  eor x16, x7, #0xff
  ands x16, x7, #0xff
  movz x16, #0xabcd, lsl #48
  movn x16, #0xabcd, lsl #48
  movk x16, #0xabcd, lsl #48
  sbfm x16, x7, #3, #21
  bfm x16, x7, #3, #21
  ubfm x16, x7, #3, #21
  csel x16, x7, x9, ne
  csinc x16, x7, x9, ne
  csinv x16, x7, x9, ne
  csneg x16, x7, x9, ne
  madd x16, x7, x9, x11
  msub x16, x7, x9, x11
  udiv x16, x7, x9
  sdiv x16, x7, x9
  lslv x16, x7, x9
  lsrv x16, x7, x9
  asrv x16, x7, x9
  rorv x16, x7, x9
  rbit x16, x7
  rev x16, x7
  rev16 x16, x7
  clz x16, x7
  ldr x16, [x7, #16]
  ldur x16, [x7, #-16]
  ldr x16, [x7, x9, lsl #3]
  str x16, [x7, #16]
  stur x16, [x7, #-16]
  ldrsb x16, [x7, #0]
  ldrsh x16, [x7, #0]
  ldrsw x16, [x7, #4]
  add x17, x7, #4095
  add x17, x7, x9, lsl #63
  sub x17, x7, #4095
  sub x17, x7, x9, lsl #63
  adds x17, x7, #4095
  adds x17, x7, x9, lsl #63
  subs x17, x7, #4095
  subs x17, x7, x9, lsl #63
  add x17, x7, x9, uxtx
  sub x17, x7, x9, uxtx
  and x17, x7, x9, asr #3
  orr x17, x7, x9, asr #3
  eor x17, x7, x9, asr #3
  ands x17, x7, x9, asr #3
  bic x17, x7, x9, asr #3
  orn x17, x7, x9, asr #3
  eon x17, x7, x9, asr #3
  bics x17, x7, x9, asr #3
  and x17, x7, #0xff
  orr x17, x7, #0xff
  eor x17, x7, #0xff
  ands x17, x7, #0xff
  movz x17, #0xabcd, lsl #48
  movn x17, #0xabcd, lsl #48
  movk x17, #0xabcd, lsl #48
  sbfm x17, x7, #3, #21
  bfm x17, x7, #3, #21
  ubfm x17, x7, #3, #21
  csel x17, x7, x9, ne
  csinc x17, x7, x9, ne
  csinv x17, x7, x9, ne
  csneg x17, x7, x9, ne
  madd x17, x7, x9, x11
  msub x17, x7, x9, x11
  udiv x17, x7, x9
  sdiv x17, x7, x9
  lslv x17, x7, x9
  lsrv x17, x7, x9
  asrv x17, x7, x9
  rorv x17, x7, x9
  rbit x17, x7
  rev x17, x7
  rev16 x17, x7
  clz x17, x7
  ldr x17, [x7, #16]
  ldur x17, [x7, #-16]
  ldr x17, [x7, x9, lsl #3]
  str x17, [x7, #16]
  stur x17, [x7, #-16]
  ldrsb x17, [x7, #0]
  ldrsh x17, [x7, #0]
  ldrsw x17, [x7, #4]
  add x18, x7, #4095
  add x18, x7, x9, lsl #63
  sub x18, x7, #4095
  sub x18, x7, x9, lsl #63
  adds x18, x7, #4095
  adds x18, x7, x9, lsl #63
  subs x18, x7, #4095
  subs x18, x7, x9, lsl #63
  add x18, x7, x9, uxtx
  sub x18, x7, x9, uxtx
  and x18, x7, x9, asr #3
  orr x18, x7, x9, asr #3
  eor x18, x7, x9, asr #3
  ands x18, x7, x9, asr #3
  bic x18, x7, x9, asr #3
  orn x18, x7, x9, asr #3
  eon x18, x7, x9, asr #3
  bics x18, x7, x9, asr #3
  and x18, x7, #0xff
  orr x18, x7, #0xff
  eor x18, x7, #0xff
  ands x18, x7, #0xff
  movz x18, #0xabcd, lsl #48
  movn x18, #0xabcd, lsl #48
  movk x18, #0xabcd, lsl #48
  sbfm x18, x7, #3, #21
  bfm x18, x7, #3, #21
  ubfm x18, x7, #3, #21
  csel x18, x7, x9, ne
  csinc x18, x7, x9, ne
  csinv x18, x7, x9, ne
  csneg x18, x7, x9, ne
  madd x18, x7, x9, x11
  msub x18, x7, x9, x11
  udiv x18, x7, x9
  sdiv x18, x7, x9
  lslv x18, x7, x9
  lsrv x18, x7, x9
  asrv x18, x7, x9
  rorv x18, x7, x9
  rbit x18, x7
  rev x18, x7
  rev16 x18, x7
  clz x18, x7
  ldr x18, [x7, #16]
  ldur x18, [x7, #-16]
  ldr x18, [x7, x9, lsl #3]
  str x18, [x7, #16]
  stur x18, [x7, #-16]
  ldrsb x18, [x7, #0]
  ldrsh x18, [x7, #0]
  ldrsw x18, [x7, #4]
  add x19, x7, #4095
  add x19, x7, x9, lsl #63
  sub x19, x7, #4095
  sub x19, x7, x9, lsl #63
  adds x19, x7, #4095
  adds x19, x7, x9, lsl #63
  subs x19, x7, #4095
  subs x19, x7, x9, lsl #63
  add x19, x7, x9, uxtx
  sub x19, x7, x9, uxtx
  and x19, x7, x9, asr #3
  orr x19, x7, x9, asr #3
  eor x19, x7, x9, asr #3
  ands x19, x7, x9, asr #3
  bic x19, x7, x9, asr #3
  orn x19, x7, x9, asr #3
  eon x19, x7, x9, asr #3
  bics x19, x7, x9, asr #3
  and x19, x7, #0xff
  orr x19, x7, #0xff
  eor x19, x7, #0xff
  ands x19, x7, #0xff
  movz x19, #0xabcd, lsl #48
  movn x19, #0xabcd, lsl #48
  movk x19, #0xabcd, lsl #48
  sbfm x19, x7, #3, #21
  bfm x19, x7, #3, #21
  ubfm x19, x7, #3, #21
  csel x19, x7, x9, ne
  csinc x19, x7, x9, ne
  csinv x19, x7, x9, ne
  csneg x19, x7, x9, ne
  madd x19, x7, x9, x11
  msub x19, x7, x9, x11
  udiv x19, x7, x9
  sdiv x19, x7, x9
  lslv x19, x7, x9
  lsrv x19, x7, x9
  asrv x19, x7, x9
  rorv x19, x7, x9
  rbit x19, x7
  rev x19, x7
  rev16 x19, x7
  clz x19, x7
  ldr x19, [x7, #16]
  ldur x19, [x7, #-16]
  ldr x19, [x7, x9, lsl #3]
  str x19, [x7, #16]
  stur x19, [x7, #-16]
  ldrsb x19, [x7, #0]
  ldrsh x19, [x7, #0]
  ldrsw x19, [x7, #4]
  add x20, x7, #4095
  add x20, x7, x9, lsl #63
  sub x20, x7, #4095
  sub x20, x7, x9, lsl #63
  adds x20, x7, #4095
  adds x20, x7, x9, lsl #63
  subs x20, x7, #4095
  subs x20, x7, x9, lsl #63
  add x20, x7, x9, uxtx
  sub x20, x7, x9, uxtx
  and x20, x7, x9, asr #3
  orr x20, x7, x9, asr #3
  eor x20, x7, x9, asr #3
  ands x20, x7, x9, asr #3
  bic x20, x7, x9, asr #3
  orn x20, x7, x9, asr #3
  eon x20, x7, x9, asr #3
  bics x20, x7, x9, asr #3
  and x20, x7, #0xff
  orr x20, x7, #0xff
  eor x20, x7, #0xff
  ands x20, x7, #0xff
  movz x20, #0xabcd, lsl #48
  movn x20, #0xabcd, lsl #48
  movk x20, #0xabcd, lsl #48
  sbfm x20, x7, #3, #21
  bfm x20, x7, #3, #21
  ubfm x20, x7, #3, #21
  csel x20, x7, x9, ne
  csinc x20, x7, x9, ne
  csinv x20, x7, x9, ne
  csneg x20, x7, x9, ne
  madd x20, x7, x9, x11
  msub x20, x7, x9, x11
  udiv x20, x7, x9
  sdiv x20, x7, x9
  lslv x20, x7, x9
  lsrv x20, x7, x9
  asrv x20, x7, x9
  rorv x20, x7, x9
  rbit x20, x7
  rev x20, x7
  rev16 x20, x7
  clz x20, x7
  ldr x20, [x7, #16]
  ldur x20, [x7, #-16]
  ldr x20, [x7, x9, lsl #3]
  str x20, [x7, #16]
  stur x20, [x7, #-16]
  ldrsb x20, [x7, #0]
  ldrsh x20, [x7, #0]
  ldrsw x20, [x7, #4]
  add x21, x7, #4095
  add x21, x7, x9, lsl #63
  sub x21, x7, #4095
  sub x21, x7, x9, lsl #63
  adds x21, x7, #4095
  adds x21, x7, x9, lsl #63
  subs x21, x7, #4095
  subs x21, x7, x9, lsl #63
  add x21, x7, x9, uxtx
  sub x21, x7, x9, uxtx
  and x21, x7, x9, asr #3
  orr x21, x7, x9, asr #3
  eor x21, x7, x9, asr #3
  ands x21, x7, x9, asr #3
  bic x21, x7, x9, asr #3
  orn x21, x7, x9, asr #3
  eon x21, x7, x9, asr #3
  bics x21, x7, x9, asr #3
  and x21, x7, #0xff
  orr x21, x7, #0xff
  eor x21, x7, #0xff
  ands x21, x7, #0xff
  movz x21, #0xabcd, lsl #48
  movn x21, #0xabcd, lsl #48
  movk x21, #0xabcd, lsl #48
  sbfm x21, x7, #3, #21
  bfm x21, x7, #3, #21
  ubfm x21, x7, #3, #21
  csel x21, x7, x9, ne
  csinc x21, x7, x9, ne
  csinv x21, x7, x9, ne
  csneg x21, x7, x9, ne
  madd x21, x7, x9, x11
  msub x21, x7, x9, x11
  udiv x21, x7, x9
  sdiv x21, x7, x9
  lslv x21, x7, x9
  lsrv x21, x7, x9
  asrv x21, x7, x9
  rorv x21, x7, x9
  rbit x21, x7
  rev x21, x7
  rev16 x21, x7
  clz x21, x7
  ldr x21, [x7, #16]
  ldur x21, [x7, #-16]
  ldr x21, [x7, x9, lsl #3]
  str x21, [x7, #16]
  stur x21, [x7, #-16]
  ldrsb x21, [x7, #0]
  ldrsh x21, [x7, #0]
  ldrsw x21, [x7, #4]
  add x22, x7, #4095
  add x22, x7, x9, lsl #63
  sub x22, x7, #4095
  sub x22, x7, x9, lsl #63
  adds x22, x7, #4095
  adds x22, x7, x9, lsl #63
  subs x22, x7, #4095
  subs x22, x7, x9, lsl #63
  add x22, x7, x9, uxtx
  sub x22, x7, x9, uxtx
  and x22, x7, x9, asr #3
  orr x22, x7, x9, asr #3
  eor x22, x7, x9, asr #3
  ands x22, x7, x9, asr #3
  bic x22, x7, x9, asr #3
  orn x22, x7, x9, asr #3
  eon x22, x7, x9, asr #3
  bics x22, x7, x9, asr #3
  and x22, x7, #0xff
  orr x22, x7, #0xff
  eor x22, x7, #0xff
  ands x22, x7, #0xff
  movz x22, #0xabcd, lsl #48
  movn x22, #0xabcd, lsl #48
  movk x22, #0xabcd, lsl #48
  sbfm x22, x7, #3, #21
  bfm x22, x7, #3, #21
  ubfm x22, x7, #3, #21
  csel x22, x7, x9, ne
  csinc x22, x7, x9, ne
  csinv x22, x7, x9, ne
  csneg x22, x7, x9, ne
  madd x22, x7, x9, x11
  msub x22, x7, x9, x11
  udiv x22, x7, x9
  sdiv x22, x7, x9
  lslv x22, x7, x9
  lsrv x22, x7, x9
  asrv x22, x7, x9
  rorv x22, x7, x9
  rbit x22, x7
  rev x22, x7
  rev16 x22, x7
  clz x22, x7
  ldr x22, [x7, #16]
  ldur x22, [x7, #-16]
  ldr x22, [x7, x9, lsl #3]
  str x22, [x7, #16]
  stur x22, [x7, #-16]
  ldrsb x22, [x7, #0]
  ldrsh x22, [x7, #0]
  ldrsw x22, [x7, #4]
  add x23, x7, #4095
  add x23, x7, x9, lsl #63
  sub x23, x7, #4095
  sub x23, x7, x9, lsl #63
  adds x23, x7, #4095
  adds x23, x7, x9, lsl #63
  subs x23, x7, #4095
  subs x23, x7, x9, lsl #63
  add x23, x7, x9, uxtx
  sub x23, x7, x9, uxtx
  and x23, x7, x9, asr #3
  orr x23, x7, x9, asr #3
  eor x23, x7, x9, asr #3
  ands x23, x7, x9, asr #3
  bic x23, x7, x9, asr #3
  orn x23, x7, x9, asr #3
  eon x23, x7, x9, asr #3
  bics x23, x7, x9, asr #3
  and x23, x7, #0xff
  orr x23, x7, #0xff
  eor x23, x7, #0xff
  ands x23, x7, #0xff
  movz x23, #0xabcd, lsl #48
  movn x23, #0xabcd, lsl #48
  movk x23, #0xabcd, lsl #48
  sbfm x23, x7, #3, #21
  bfm x23, x7, #3, #21
  ubfm x23, x7, #3, #21
  csel x23, x7, x9, ne
  csinc x23, x7, x9, ne
  csinv x23, x7, x9, ne
  csneg x23, x7, x9, ne
  madd x23, x7, x9, x11
  msub x23, x7, x9, x11
  udiv x23, x7, x9
  sdiv x23, x7, x9
  lslv x23, x7, x9
  lsrv x23, x7, x9
  asrv x23, x7, x9
  rorv x23, x7, x9
  rbit x23, x7
  rev x23, x7
  rev16 x23, x7
  clz x23, x7
  ldr x23, [x7, #16]
  ldur x23, [x7, #-16]
  ldr x23, [x7, x9, lsl #3]
  str x23, [x7, #16]
  stur x23, [x7, #-16]
  ldrsb x23, [x7, #0]
  ldrsh x23, [x7, #0]
  ldrsw x23, [x7, #4]
  add x24, x7, #4095
  add x24, x7, x9, lsl #63
  sub x24, x7, #4095
  sub x24, x7, x9, lsl #63
  adds x24, x7, #4095
  adds x24, x7, x9, lsl #63
  subs x24, x7, #4095
  subs x24, x7, x9, lsl #63
  add x24, x7, x9, uxtx
  sub x24, x7, x9, uxtx
  and x24, x7, x9, asr #3
  orr x24, x7, x9, asr #3
  eor x24, x7, x9, asr #3
  ands x24, x7, x9, asr #3
  bic x24, x7, x9, asr #3
  orn x24, x7, x9, asr #3
  eon x24, x7, x9, asr #3
  bics x24, x7, x9, asr #3
  and x24, x7, #0xff
  orr x24, x7, #0xff
  eor x24, x7, #0xff
  ands x24, x7, #0xff
  movz x24, #0xabcd, lsl #48
  movn x24, #0xabcd, lsl #48
  movk x24, #0xabcd, lsl #48
  sbfm x24, x7, #3, #21
  bfm x24, x7, #3, #21
  ubfm x24, x7, #3, #21
  csel x24, x7, x9, ne
  csinc x24, x7, x9, ne
  csinv x24, x7, x9, ne
  csneg x24, x7, x9, ne
  madd x24, x7, x9, x11
  msub x24, x7, x9, x11
  udiv x24, x7, x9
  sdiv x24, x7, x9
  lslv x24, x7, x9
  lsrv x24, x7, x9
  asrv x24, x7, x9
  rorv x24, x7, x9
  rbit x24, x7
  rev x24, x7
  rev16 x24, x7
  clz x24, x7
  ldr x24, [x7, #16]
  ldur x24, [x7, #-16]
  ldr x24, [x7, x9, lsl #3]
  str x24, [x7, #16]
  stur x24, [x7, #-16]
  ldrsb x24, [x7, #0]
  ldrsh x24, [x7, #0]
  ldrsw x24, [x7, #4]
  add x25, x7, #4095
  add x25, x7, x9, lsl #63
  sub x25, x7, #4095
  sub x25, x7, x9, lsl #63
  adds x25, x7, #4095
  adds x25, x7, x9, lsl #63
  subs x25, x7, #4095
  subs x25, x7, x9, lsl #63
  add x25, x7, x9, uxtx
  sub x25, x7, x9, uxtx
  and x25, x7, x9, asr #3
  orr x25, x7, x9, asr #3
  eor x25, x7, x9, asr #3
  ands x25, x7, x9, asr #3
  bic x25, x7, x9, asr #3
  orn x25, x7, x9, asr #3
  eon x25, x7, x9, asr #3
  bics x25, x7, x9, asr #3
  and x25, x7, #0xff
  orr x25, x7, #0xff
  eor x25, x7, #0xff
  ands x25, x7, #0xff
  movz x25, #0xabcd, lsl #48
  movn x25, #0xabcd, lsl #48
  movk x25, #0xabcd, lsl #48
  sbfm x25, x7, #3, #21
  bfm x25, x7, #3, #21
  ubfm x25, x7, #3, #21
  csel x25, x7, x9, ne
  csinc x25, x7, x9, ne
  csinv x25, x7, x9, ne
  csneg x25, x7, x9, ne
  madd x25, x7, x9, x11
  msub x25, x7, x9, x11
  udiv x25, x7, x9
  sdiv x25, x7, x9
  lslv x25, x7, x9
  lsrv x25, x7, x9
  asrv x25, x7, x9
  rorv x25, x7, x9
  rbit x25, x7
  rev x25, x7
  rev16 x25, x7
  clz x25, x7
  ldr x25, [x7, #16]
  ldur x25, [x7, #-16]
  ldr x25, [x7, x9, lsl #3]
  str x25, [x7, #16]
  stur x25, [x7, #-16]
  ldrsb x25, [x7, #0]
  ldrsh x25, [x7, #0]
  ldrsw x25, [x7, #4]
  add x26, x7, #4095
  add x26, x7, x9, lsl #63
  sub x26, x7, #4095
  sub x26, x7, x9, lsl #63
  adds x26, x7, #4095
  adds x26, x7, x9, lsl #63
  subs x26, x7, #4095
  subs x26, x7, x9, lsl #63
  add x26, x7, x9, uxtx
  sub x26, x7, x9, uxtx
  and x26, x7, x9, asr #3
  orr x26, x7, x9, asr #3
  eor x26, x7, x9, asr #3
  ands x26, x7, x9, asr #3
  bic x26, x7, x9, asr #3
  orn x26, x7, x9, asr #3
  eon x26, x7, x9, asr #3
  bics x26, x7, x9, asr #3
  and x26, x7, #0xff
  orr x26, x7, #0xff
  eor x26, x7, #0xff
  ands x26, x7, #0xff
  movz x26, #0xabcd, lsl #48
  movn x26, #0xabcd, lsl #48
  movk x26, #0xabcd, lsl #48
  sbfm x26, x7, #3, #21
  bfm x26, x7, #3, #21
  ubfm x26, x7, #3, #21
  csel x26, x7, x9, ne
  csinc x26, x7, x9, ne
  csinv x26, x7, x9, ne
  csneg x26, x7, x9, ne
  madd x26, x7, x9, x11
  msub x26, x7, x9, x11
  udiv x26, x7, x9
  sdiv x26, x7, x9
  lslv x26, x7, x9
  lsrv x26, x7, x9
  asrv x26, x7, x9
  rorv x26, x7, x9
  rbit x26, x7
  rev x26, x7
  rev16 x26, x7
  clz x26, x7
  ldr x26, [x7, #16]
  ldur x26, [x7, #-16]
  ldr x26, [x7, x9, lsl #3]
  str x26, [x7, #16]
  stur x26, [x7, #-16]
  ldrsb x26, [x7, #0]
  ldrsh x26, [x7, #0]
  ldrsw x26, [x7, #4]
  add x27, x7, #4095
  add x27, x7, x9, lsl #63
  sub x27, x7, #4095
  sub x27, x7, x9, lsl #63
  adds x27, x7, #4095
  adds x27, x7, x9, lsl #63
  subs x27, x7, #4095
  subs x27, x7, x9, lsl #63
  add x27, x7, x9, uxtx
  sub x27, x7, x9, uxtx
  and x27, x7, x9, asr #3
  orr x27, x7, x9, asr #3
  eor x27, x7, x9, asr #3
  ands x27, x7, x9, asr #3
  bic x27, x7, x9, asr #3
  orn x27, x7, x9, asr #3
  eon x27, x7, x9, asr #3
  bics x27, x7, x9, asr #3
  and x27, x7, #0xff
  orr x27, x7, #0xff
  eor x27, x7, #0xff
  ands x27, x7, #0xff
  movz x27, #0xabcd, lsl #48
  movn x27, #0xabcd, lsl #48
  movk x27, #0xabcd, lsl #48
  sbfm x27, x7, #3, #21
  bfm x27, x7, #3, #21
  ubfm x27, x7, #3, #21
  csel x27, x7, x9, ne
  csinc x27, x7, x9, ne
  csinv x27, x7, x9, ne
  csneg x27, x7, x9, ne
  madd x27, x7, x9, x11
  msub x27, x7, x9, x11
  udiv x27, x7, x9
  sdiv x27, x7, x9
  lslv x27, x7, x9
  lsrv x27, x7, x9
  asrv x27, x7, x9
  rorv x27, x7, x9
  rbit x27, x7
  rev x27, x7
  rev16 x27, x7
  clz x27, x7
  ldr x27, [x7, #16]
  ldur x27, [x7, #-16]
  ldr x27, [x7, x9, lsl #3]
  str x27, [x7, #16]
  stur x27, [x7, #-16]
  ldrsb x27, [x7, #0]
  ldrsh x27, [x7, #0]
  ldrsw x27, [x7, #4]
  add x28, x7, #4095
  add x28, x7, x9, lsl #63
  sub x28, x7, #4095
  sub x28, x7, x9, lsl #63
  adds x28, x7, #4095
  adds x28, x7, x9, lsl #63
  subs x28, x7, #4095
  subs x28, x7, x9, lsl #63
  add x28, x7, x9, uxtx
  sub x28, x7, x9, uxtx
  and x28, x7, x9, asr #3
  orr x28, x7, x9, asr #3
  eor x28, x7, x9, asr #3
  ands x28, x7, x9, asr #3
  bic x28, x7, x9, asr #3
  orn x28, x7, x9, asr #3
  eon x28, x7, x9, asr #3
  bics x28, x7, x9, asr #3
  and x28, x7, #0xff
  orr x28, x7, #0xff
  eor x28, x7, #0xff
  ands x28, x7, #0xff
  movz x28, #0xabcd, lsl #48
  movn x28, #0xabcd, lsl #48
  movk x28, #0xabcd, lsl #48
  sbfm x28, x7, #3, #21
  bfm x28, x7, #3, #21
  ubfm x28, x7, #3, #21
  csel x28, x7, x9, ne
  csinc x28, x7, x9, ne
  csinv x28, x7, x9, ne
  csneg x28, x7, x9, ne
  madd x28, x7, x9, x11
  msub x28, x7, x9, x11
  udiv x28, x7, x9
  sdiv x28, x7, x9
  lslv x28, x7, x9
  lsrv x28, x7, x9
  asrv x28, x7, x9
  rorv x28, x7, x9
  rbit x28, x7
  rev x28, x7
  rev16 x28, x7
  clz x28, x7
  ldr x28, [x7, #16]
  ldur x28, [x7, #-16]
  ldr x28, [x7, x9, lsl #3]
  str x28, [x7, #16]
  stur x28, [x7, #-16]
  ldrsb x28, [x7, #0]
  ldrsh x28, [x7, #0]
  ldrsw x28, [x7, #4]
  add x29, x7, #4095
  add x29, x7, x9, lsl #63
  sub x29, x7, #4095
  sub x29, x7, x9, lsl #63
  adds x29, x7, #4095
  adds x29, x7, x9, lsl #63
  subs x29, x7, #4095
  subs x29, x7, x9, lsl #63
  add x29, x7, x9, uxtx
  sub x29, x7, x9, uxtx
  and x29, x7, x9, asr #3
  orr x29, x7, x9, asr #3
  eor x29, x7, x9, asr #3
  ands x29, x7, x9, asr #3
  bic x29, x7, x9, asr #3
  orn x29, x7, x9, asr #3
  eon x29, x7, x9, asr #3
  bics x29, x7, x9, asr #3
  and x29, x7, #0xff
  orr x29, x7, #0xff
  eor x29, x7, #0xff
  ands x29, x7, #0xff
  movz x29, #0xabcd, lsl #48
  movn x29, #0xabcd, lsl #48
  movk x29, #0xabcd, lsl #48
  sbfm x29, x7, #3, #21
  bfm x29, x7, #3, #21
  ubfm x29, x7, #3, #21
  csel x29, x7, x9, ne
  csinc x29, x7, x9, ne
  csinv x29, x7, x9, ne
  csneg x29, x7, x9, ne
  madd x29, x7, x9, x11
  msub x29, x7, x9, x11
  udiv x29, x7, x9
  sdiv x29, x7, x9
  lslv x29, x7, x9
  lsrv x29, x7, x9
  asrv x29, x7, x9
  rorv x29, x7, x9
  rbit x29, x7
  rev x29, x7
  rev16 x29, x7
  clz x29, x7
  ldr x29, [x7, #16]
  ldur x29, [x7, #-16]
  ldr x29, [x7, x9, lsl #3]
  str x29, [x7, #16]
  stur x29, [x7, #-16]
  ldrsb x29, [x7, #0]
  ldrsh x29, [x7, #0]
  ldrsw x29, [x7, #4]
  add x30, x7, #4095
  add x30, x7, x9, lsl #63
  sub x30, x7, #4095
  sub x30, x7, x9, lsl #63
  adds x30, x7, #4095
  adds x30, x7, x9, lsl #63
  subs x30, x7, #4095
  subs x30, x7, x9, lsl #63
  add x30, x7, x9, uxtx
  sub x30, x7, x9, uxtx
  and x30, x7, x9, asr #3
  orr x30, x7, x9, asr #3
  eor x30, x7, x9, asr #3
  ands x30, x7, x9, asr #3
  bic x30, x7, x9, asr #3
  orn x30, x7, x9, asr #3
  eon x30, x7, x9, asr #3
  bics x30, x7, x9, asr #3
  and x30, x7, #0xff
  orr x30, x7, #0xff
  eor x30, x7, #0xff
  ands x30, x7, #0xff
  movz x30, #0xabcd, lsl #48
  movn x30, #0xabcd, lsl #48
  movk x30, #0xabcd, lsl #48
  sbfm x30, x7, #3, #21
  bfm x30, x7, #3, #21
  ubfm x30, x7, #3, #21
  csel x30, x7, x9, ne
  csinc x30, x7, x9, ne
  csinv x30, x7, x9, ne
  csneg x30, x7, x9, ne
  madd x30, x7, x9, x11
  msub x30, x7, x9, x11
  udiv x30, x7, x9
  sdiv x30, x7, x9
  lslv x30, x7, x9
  lsrv x30, x7, x9
  asrv x30, x7, x9
  rorv x30, x7, x9
  rbit x30, x7
  rev x30, x7
  rev16 x30, x7
  clz x30, x7
  ldr x30, [x7, #16]
  ldur x30, [x7, #-16]
  ldr x30, [x7, x9, lsl #3]
  str x30, [x7, #16]
  stur x30, [x7, #-16]
  ldrsb x30, [x7, #0]
  ldrsh x30, [x7, #0]
  ldrsw x30, [x7, #4]
  add sp, x7, #4095
  add xzr, x7, x9, lsl #63
  sub sp, x7, #4095
  sub xzr, x7, x9, lsl #63
  adds xzr, x7, #4095
  adds xzr, x7, x9, lsl #63
  subs xzr, x7, #4095
  subs xzr, x7, x9, lsl #63
  add sp, x7, x9, uxtx
  sub sp, x7, x9, uxtx
  and xzr, x7, x9, asr #3
  orr xzr, x7, x9, asr #3
  eor xzr, x7, x9, asr #3
  ands xzr, x7, x9, asr #3
  bic xzr, x7, x9, asr #3
  orn xzr, x7, x9, asr #3
  eon xzr, x7, x9, asr #3
  bics xzr, x7, x9, asr #3
  and sp, x7, #0xff
  orr sp, x7, #0xff
  eor sp, x7, #0xff
  ands xzr, x7, #0xff
  movz xzr, #0xabcd, lsl #48
  movn xzr, #0xabcd, lsl #48
  movk xzr, #0xabcd, lsl #48
  sbfm xzr, x7, #3, #21
  bfm xzr, x7, #3, #21
  ubfm xzr, x7, #3, #21
  csel xzr, x7, x9, ne
  csinc xzr, x7, x9, ne
  csinv xzr, x7, x9, ne
  csneg xzr, x7, x9, ne
  madd xzr, x7, x9, x11
  msub xzr, x7, x9, x11
  udiv xzr, x7, x9
  sdiv xzr, x7, x9
  lslv xzr, x7, x9
  lsrv xzr, x7, x9
  asrv xzr, x7, x9
  rorv xzr, x7, x9
  rbit xzr, x7
  rev xzr, x7
  rev16 xzr, x7
  clz xzr, x7
  ldr xzr, [x7, #16]
  ldur xzr, [x7, #-16]
  ldr xzr, [x7, x9, lsl #3]
  str xzr, [x7, #16]
  stur xzr, [x7, #-16]
  ldrsb xzr, [x7, #0]
  ldrsh xzr, [x7, #0]
  ldrsw xzr, [x7, #4]
  ldr x3, [x7], #8
  ldr x3, [x7, #8]!
  ldp x3, x5, [x7]
  ror x3, x7, #3
  blr x3
  br x3
  ret x3
  ret
  bl .
  b .
  nop
  mrs x3, nzcv
  fmov x3, d7
  ldr d3, [x7]
  ldr q3, [x7]
  prfm pldl1keep, [x7]
  svc #0
  brk #0
