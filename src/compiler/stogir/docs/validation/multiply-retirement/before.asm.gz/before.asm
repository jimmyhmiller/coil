
/Users/jimmyhmiller/Documents/Code/projects/coil-stogir/.worktrees/wide-record-promotion/build/multiply-retirement-verifier/before.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <_gap_verify_graph>:
       0:      	sub	sp, sp, #0x1e0
       4:      	str	x29, [sp]
       8:      	str	x30, [sp, #0x8]
       c:      	mov	x29, sp
      10:      	str	x19, [sp, #0x1d0]
      14:      	add	x8, sp, #0x10
      18:      	mov	x19, x0
      1c:      	mov	x1, #0x8                ; =8
      20:      	bl	0x20 <_gap_verify_graph+0x20>
		0000000000000020:  ARM64_RELOC_BRANCH26	_stogir.verify.integer-operations-target
      24:      	add	x16, sp, #0x10
      28:      	ldr	w0, [x16]
      2c:      	lsr	x16, x0, #0
      30:      	cmp	x16, #0x1
      34:      	b.eq	0x50 <_gap_verify_graph+0x50>
      38:      	b.lo	0x40 <_gap_verify_graph+0x40>
      3c:      	b	0x54 <_gap_verify_graph+0x54>
      40:      	cmp	x16, #0x0
      44:      	b.eq	0x4c <_gap_verify_graph+0x4c>
      48:      	b	0x54 <_gap_verify_graph+0x54>
      4c:      	b	0x60 <_gap_verify_graph+0x60>
      50:      	b	0x58 <_gap_verify_graph+0x58>
      54:      	b	0xa8 <_gap_verify_graph+0xa8>
      58:      	movn	x0, #0x0, lsl #48
      5c:      	b	0x94 <_gap_verify_graph+0x94>
      60:      	movz	x0, #0x0, lsl #48
      64:      	b	0x84 <_gap_verify_graph+0x84>
      68:      	add	x1, x0, #0x8
      6c:      	add	x16, sp, #0x30
      70:      	add	x2, x16, x0
      74:      	add	x0, x19, x0
      78:      	ldr	x0, [x0]
      7c:      	str	x0, [x2]
      80:      	mov	x0, x1
      84:      	cmp	x0, #0x1a0
      88:      	b.lo	0x68 <_gap_verify_graph+0x68>
      8c:      	add	x16, sp, #0x30
      90:      	ldr	x0, [x16, #0x8]
      94:      	ldr	x19, [sp, #0x1d0]
      98:      	ldr	x29, [sp]
      9c:      	ldr	x30, [sp, #0x8]
      a0:      	add	sp, sp, #0x1e0
      a4:      	ret
      a8:      	brk	#0
      ac:      	b	0xa8 <_gap_verify_graph+0xa8>

00000000000000b0 <_stogir.verify.integer-operations-target>:
      b0:      	sub	sp, sp, #0x70
      b4:      	str	x29, [sp]
      b8:      	str	x30, [sp, #0x8]
      bc:      	mov	x29, sp
      c0:      	str	x19, [sp, #0x50]
      c4:      	str	x20, [sp, #0x58]
      c8:      	str	x21, [sp, #0x60]
      cc:      	mov	x19, x8
      d0:      	add	x8, sp, #0x10
      d4:      	mov	x20, x0
      d8:      	mov	w21, w1
      dc:      	bl	0xdc <_stogir.verify.integer-operations-target+0x2c>
		00000000000000dc:  ARM64_RELOC_BRANCH26	_stogir.verify.structure
      e0:      	add	x16, sp, #0x10
      e4:      	ldr	w0, [x16]
      e8:      	lsr	x16, x0, #0
      ec:      	cmp	x16, #0x1
      f0:      	b.eq	0x10c <_stogir.verify.integer-operations-target+0x5c>
      f4:      	b.lo	0xfc <_stogir.verify.integer-operations-target+0x4c>
      f8:      	b	0x110 <_stogir.verify.integer-operations-target+0x60>
      fc:      	cmp	x16, #0x0
     100:      	b.eq	0x108 <_stogir.verify.integer-operations-target+0x58>
     104:      	b	0x110 <_stogir.verify.integer-operations-target+0x60>
     108:      	b	0x138 <_stogir.verify.integer-operations-target+0x88>
     10c:      	b	0x114 <_stogir.verify.integer-operations-target+0x64>
     110:      	b	0x18c <_stogir.verify.integer-operations-target+0xdc>
     114:      	add	x16, sp, #0x10
     118:      	orr	x0, x16, xzr
     11c:      	add	x0, x0, #0x8
     120:      	add	x16, sp, #0x10
     124:      	ldr	x1, [x16, #0x8]
     128:      	ldr	x0, [x0, #0x8]
     12c:      	mov	x2, x0
     130:      	mov	x0, #0x1                ; =1
     134:      	b	0x164 <_stogir.verify.integer-operations-target+0xb4>
     138:      	lsr	w21, w21, #0
     13c:      	add	x8, sp, #0x30
     140:      	mov	x0, x20
     144:      	mov	w1, w21
     148:      	bl	0x148 <_stogir.verify.integer-operations-target+0x98>
		0000000000000148:  ARM64_RELOC_BRANCH26	_stogir.verify.integer-operations-target-structured
     14c:      	add	x16, sp, #0x30
     150:      	ldr	x0, [x16]
     154:      	add	x16, sp, #0x30
     158:      	ldr	x1, [x16, #0x8]
     15c:      	add	x16, sp, #0x30
     160:      	ldr	x2, [x16, #0x10]
     164:      	str	x0, [x19]
     168:      	str	x1, [x19, #0x8]
     16c:      	str	x2, [x19, #0x10]
     170:      	ldr	x19, [sp, #0x50]
     174:      	ldr	x20, [sp, #0x58]
     178:      	ldr	x21, [sp, #0x60]
     17c:      	ldr	x29, [sp]
     180:      	ldr	x30, [sp, #0x8]
     184:      	add	sp, sp, #0x70
     188:      	ret
     18c:      	brk	#0
     190:      	b	0x18c <_stogir.verify.integer-operations-target+0xdc>

0000000000000194 <_coil.core.Len$coil.arraylist.ArrayList$len__stogir.node.Node>:
     194:      	ldr	x0, [x0, #0x8]
     198:      	ret
     19c:      	udf	#0x0

00000000000001a0 <_stogir.verify.structure>:
     1a0:      	sub	sp, sp, #0x1b0
     1a4:      	str	x29, [sp, #0x10]
     1a8:      	str	x30, [sp, #0x18]
     1ac:      	add	x29, sp, #0x10
     1b0:      	str	x19, [sp, #0x160]
     1b4:      	str	x20, [sp, #0x168]
     1b8:      	str	x21, [sp, #0x170]
     1bc:      	str	x22, [sp, #0x178]
     1c0:      	str	x23, [sp, #0x180]
     1c4:      	str	x24, [sp, #0x188]
     1c8:      	str	x25, [sp, #0x190]
     1cc:      	str	x26, [sp, #0x198]
     1d0:      	str	x27, [sp, #0x1a0]
     1d4:      	str	x28, [sp, #0x1a8]
     1d8:      	add	x1, x0, #0x78
     1dc:      	ldr	x2, [x0, #0x8]
     1e0:      	ldr	x1, [x1, #0x8]
     1e4:      	cmp	x2, x1
     1e8:      	b.ne	0x228 <_stogir.verify.structure+0x88>
     1ec:      	adrp	x16, 0x0 <_gap_verify_graph>
		00000000000001ec:  ARM64_RELOC_PAGE21	l_stogir.304
     1f0:      	ldr	x16, [x16]
		00000000000001f0:  ARM64_RELOC_PAGEOFF12	l_stogir.304
     1f4:      	orr	x1, x16, xzr
     1f8:      	movz	x2, #0x0, lsl #48
     1fc:      	b	0x238 <_stogir.verify.structure+0x98>
     200:      	ldr	x2, [sp, #0x138]
     204:      	ldr	x1, [sp, #0x140]
     208:      	add	x1, x2, x1
     20c:      	ldr	x2, [sp, #0xb0]
     210:      	add	x2, x2, #0x1
     214:      	lsr	w2, w2, #0
     218:      	sxtw	x2, w2
     21c:      	ldr	x6, [sp, #0x110]
     220:      	ldr	x8, [sp, #0x108]
     224:      	b	0x304 <_stogir.verify.structure+0x164>
     228:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000228:  ARM64_RELOC_PAGE21	l_stogir.305
     22c:      	ldr	x16, [x16]
		000000000000022c:  ARM64_RELOC_PAGEOFF12	l_stogir.305
     230:      	orr	x1, x16, xzr
     234:      	mov	x2, #0x2c               ; =44
     238:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000238:  ARM64_RELOC_PAGE21	l_stogir.306
     23c:      	ldr	x16, [x16]
		000000000000023c:  ARM64_RELOC_PAGEOFF12	l_stogir.306
     240:      	orr	x19, x16, xzr
     244:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000244:  ARM64_RELOC_PAGE21	l_stogir.307
     248:      	ldr	x16, [x16]
		0000000000000248:  ARM64_RELOC_PAGEOFF12	l_stogir.307
     24c:      	orr	x20, x16, xzr
     250:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000250:  ARM64_RELOC_PAGE21	l_stogir.308
     254:      	ldr	x16, [x16]
		0000000000000254:  ARM64_RELOC_PAGEOFF12	l_stogir.308
     258:      	orr	x21, x16, xzr
     25c:      	adrp	x16, 0x0 <_gap_verify_graph>
		000000000000025c:  ARM64_RELOC_PAGE21	l_stogir.309
     260:      	ldr	x16, [x16]
		0000000000000260:  ARM64_RELOC_PAGEOFF12	l_stogir.309
     264:      	orr	x22, x16, xzr
     268:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000268:  ARM64_RELOC_PAGE21	l_stogir.310
     26c:      	ldr	x16, [x16]
		000000000000026c:  ARM64_RELOC_PAGEOFF12	l_stogir.310
     270:      	orr	x23, x16, xzr
     274:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000274:  ARM64_RELOC_PAGE21	l_stogir.311
     278:      	ldr	x16, [x16]
		0000000000000278:  ARM64_RELOC_PAGEOFF12	l_stogir.311
     27c:      	orr	x24, x16, xzr
     280:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000280:  ARM64_RELOC_PAGE21	l_stogir.312
     284:      	ldr	x16, [x16]
		0000000000000284:  ARM64_RELOC_PAGEOFF12	l_stogir.312
     288:      	orr	x25, x16, xzr
     28c:      	adrp	x16, 0x0 <_gap_verify_graph>
		000000000000028c:  ARM64_RELOC_PAGE21	l_stogir.313
     290:      	ldr	x16, [x16]
		0000000000000290:  ARM64_RELOC_PAGEOFF12	l_stogir.313
     294:      	orr	x26, x16, xzr
     298:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000298:  ARM64_RELOC_PAGE21	l_stogir.314
     29c:      	ldr	x16, [x16]
		000000000000029c:  ARM64_RELOC_PAGEOFF12	l_stogir.314
     2a0:      	orr	x27, x16, xzr
     2a4:      	adrp	x16, 0x0 <_gap_verify_graph>
		00000000000002a4:  ARM64_RELOC_PAGE21	l_stogir.315
     2a8:      	ldr	x16, [x16]
		00000000000002a8:  ARM64_RELOC_PAGEOFF12	l_stogir.315
     2ac:      	orr	x28, x16, xzr
     2b0:      	add	x3, x0, #0x110
     2b4:      	adrp	x16, 0x0 <_gap_verify_graph>
		00000000000002b4:  ARM64_RELOC_PAGE21	l_stogir.316
     2b8:      	ldr	x16, [x16]
		00000000000002b8:  ARM64_RELOC_PAGEOFF12	l_stogir.316
     2bc:      	orr	x4, x16, xzr
     2c0:      	add	x5, x0, #0x78
     2c4:      	add	x6, x0, #0x28
     2c8:      	add	x7, x0, #0x50
     2cc:      	adrp	x16, 0x0 <_gap_verify_graph>
		00000000000002cc:  ARM64_RELOC_PAGE21	l_stogir.316
     2d0:      	ldr	x16, [x16]
		00000000000002d0:  ARM64_RELOC_PAGEOFF12	l_stogir.316
     2d4:      	orr	x9, x16, xzr
     2d8:      	adrp	x16, 0x0 <_gap_verify_graph>
		00000000000002d8:  ARM64_RELOC_PAGE21	l_stogir.317
     2dc:      	ldr	x16, [x16]
		00000000000002dc:  ARM64_RELOC_PAGEOFF12	l_stogir.317
     2e0:      	orr	x10, x16, xzr
     2e4:      	add	x11, x3, #0x28
     2e8:      	mov	x12, x1
     2ec:      	mov	x13, x2
     2f0:      	mov	x1, #0x1                ; =1
     2f4:      	movz	x2, #0x0, lsl #48
     2f8:      	b	0x3b0 <_stogir.verify.structure+0x210>
     2fc:      	ldr	x6, [sp, #0x58]
     300:      	mov	x8, #0x16               ; =22
     304:      	b	0x35c <_stogir.verify.structure+0x1bc>
     308:      	str	x8, [sp, #0xa0]
     30c:      	str	x19, [sp, #0x40]
     310:      	str	x20, [sp, #0x58]
     314:      	str	x21, [sp, #0x60]
     318:      	mov	x21, x0
     31c:      	str	x22, [sp, #0x68]
     320:      	str	x23, [sp, #0x70]
     324:      	str	x24, [sp, #0x78]
     328:      	str	x25, [sp, #0x80]
     32c:      	str	x26, [sp, #0x88]
     330:      	str	x27, [sp, #0x90]
     334:      	str	x28, [sp, #0x98]
     338:      	str	x4, [sp, #0x100]
     33c:      	mov	x0, x5
     340:      	mov	x5, x3
     344:      	mov	x3, x11
     348:      	mov	x4, x6
     34c:      	str	x9, [sp, #0x120]
     350:      	str	x10, [sp, #0x128]
     354:      	ldr	x6, [sp, #0x40]
     358:      	mov	x8, #0x23               ; =35
     35c:      	ldr	x19, [sp, #0x40]
     360:      	ldr	x20, [sp, #0x58]
     364:      	ldr	x22, [sp, #0x68]
     368:      	ldr	x23, [sp, #0x70]
     36c:      	ldr	x24, [sp, #0x78]
     370:      	ldr	x25, [sp, #0x80]
     374:      	ldr	x26, [sp, #0x88]
     378:      	ldr	x27, [sp, #0x90]
     37c:      	ldr	x28, [sp, #0x98]
     380:      	mov	x11, x3
     384:      	mov	x3, x5
     388:      	mov	x5, x0
     38c:      	mov	x0, x21
     390:      	ldr	x21, [sp, #0x60]
     394:      	ldr	x9, [sp, #0x120]
     398:      	ldr	x10, [sp, #0x128]
     39c:      	mov	x12, x6
     3a0:      	mov	x6, x4
     3a4:      	ldr	x4, [sp, #0x100]
     3a8:      	mov	x13, x8
     3ac:      	ldr	x8, [sp, #0xa0]
     3b0:      	cmp	x13, #0x0
     3b4:      	b.ne	0xc4c <_stogir.verify.structure+0xaac>
     3b8:      	ldr	x14, [x0, #0x8]
     3bc:      	cmp	x1, x14
     3c0:      	b.ge	0xc5c <_stogir.verify.structure+0xabc>
     3c4:      	lsl	x14, x1, #4
     3c8:      	lsl	x14, x1, #2
     3cc:      	ldr	x14, [x0]
     3d0:      	add	x14, x14, x1, lsl #4
     3d4:      	ldr	x14, [x14]
     3d8:      	ldr	x15, [x0, #0x78]
     3dc:      	add	x15, x15, x1, lsl #2
     3e0:      	ldr	w15, [x15]
     3e4:      	sxtw	x15, w15
     3e8:      	cmp	x15, #0x0
     3ec:      	b.lt	0x308 <_stogir.verify.structure+0x168>
     3f0:      	mov	x17, #0xffff            ; =65535
     3f4:      	cmp	x15, x17
     3f8:      	b.gt	0xc6c <_stogir.verify.structure+0xacc>
     3fc:      	str	x0, [sp, #0x30]
     400:      	uxtb	w0, w14
     404:      	str	w0, [sp, #0x38]
     408:      	str	x19, [sp, #0x40]
     40c:      	cmp	x0, #0x83
     410:      	cset	w19, lt
     414:      	uxtb	w16, w19
     418:      	cmp	w16, wzr
     41c:      	b.eq	0xcbc <_stogir.verify.structure+0xb1c>
     420:      	lsr	w14, w14, #0
     424:      	str	x0, [sp, #0x48]
     428:      	ubfx	x0, x14, #8, #8
     42c:      	str	w0, [sp, #0x50]
     430:      	lsr	w0, w0, #0
     434:      	str	x8, [sp, #0xa0]
     438:      	str	x3, [sp, #0xd8]
     43c:      	str	x5, [sp, #0xd0]
     440:      	str	x6, [sp, #0xc8]
     444:      	str	x7, [sp, #0xa8]
     448:      	str	x11, [sp, #0xe0]
     44c:      	str	x2, [sp, #0xb0]
     450:      	str	x12, [sp, #0xb8]
     454:      	str	x13, [sp, #0xc0]
     458:      	str	x20, [sp, #0x58]
     45c:      	mov	x20, x14
     460:      	str	x21, [sp, #0x60]
     464:      	ldr	x21, [sp, #0x30]
     468:      	str	x22, [sp, #0x68]
     46c:      	ldr	x22, [sp, #0x48]
     470:      	str	x23, [sp, #0x70]
     474:      	mov	x23, x4
     478:      	str	x24, [sp, #0x78]
     47c:      	ldr	w24, [sp, #0x38]
     480:      	str	x25, [sp, #0x80]
     484:      	mov	x25, x15
     488:      	str	x26, [sp, #0x88]
     48c:      	mov	x26, x1
     490:      	str	x27, [sp, #0x90]
     494:      	mov	x27, x9
     498:      	str	x28, [sp, #0x98]
     49c:      	mov	x28, x10
     4a0:      	str	w19, [sp, #0xe8]
     4a4:      	ldr	w19, [sp, #0x50]
     4a8:      	bl	0x4a8 <_stogir.verify.structure+0x308>
		00000000000004a8:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
     4ac:      	cmp	x0, #0x0
     4b0:      	b.eq	0xd08 <_stogir.verify.structure+0xb68>
     4b4:      	add	x0, x22, x28
     4b8:      	lsr	w24, w24, #0
     4bc:      	ldrsb	w0, [x0]
     4c0:      	sxtb	x0, w0
     4c4:      	cmp	x0, #0x0
     4c8:      	b.lt	0xa44 <_stogir.verify.structure+0x8a4>
     4cc:      	mov	w0, w24
     4d0:      	bl	0x4d0 <_stogir.verify.structure+0x330>
		00000000000004d0:  ARM64_RELOC_BRANCH26	_stogir.opcode.operand-slots
     4d4:      	lsr	w0, w0, #0
     4d8:      	sxtw	x0, w0
     4dc:      	cmp	x25, x0
     4e0:      	b.eq	0xa44 <_stogir.verify.structure+0x8a4>
     4e4:      	ldr	x5, [sp, #0xd8]
     4e8:      	str	x23, [sp, #0x100]
     4ec:      	ldr	x3, [sp, #0xe0]
     4f0:      	ldr	x0, [sp, #0xd0]
     4f4:      	ldr	x4, [sp, #0xc8]
     4f8:      	ldr	x7, [sp, #0xa8]
     4fc:      	str	x27, [sp, #0x120]
     500:      	str	x28, [sp, #0x128]
     504:      	mov	x1, x26
     508:      	ldr	x2, [sp, #0xb0]
     50c:      	ldr	x6, [sp, #0x60]
     510:      	mov	x8, #0x23               ; =35
     514:      	b	0x224 <_stogir.verify.structure+0x84>
     518:      	ldr	x0, [sp, #0xc0]
     51c:      	cmp	x0, #0x0
     520:      	b.ne	0x538 <_stogir.verify.structure+0x398>
     524:      	and	x0, x2, #0xffffffff
     528:      	mov	x1, x0
     52c:      	movz	x0, #0x0, lsl #48
     530:      	movz	x2, #0x0, lsl #48
     534:      	b	0x544 <_stogir.verify.structure+0x3a4>
     538:      	ldr	x1, [sp, #0xb8]
     53c:      	mov	x2, x0
     540:      	mov	x0, #0x1                ; =1
     544:      	ldr	x3, [sp, #0xa0]
     548:      	str	x0, [x3]
     54c:      	str	x1, [x3, #0x8]
     550:      	str	x2, [x3, #0x10]
     554:      	ldr	x19, [sp, #0x160]
     558:      	ldr	x20, [sp, #0x168]
     55c:      	ldr	x21, [sp, #0x170]
     560:      	ldr	x22, [sp, #0x178]
     564:      	ldr	x23, [sp, #0x180]
     568:      	ldr	x24, [sp, #0x188]
     56c:      	ldr	x25, [sp, #0x190]
     570:      	ldr	x26, [sp, #0x198]
     574:      	ldr	x27, [sp, #0x1a0]
     578:      	ldr	x28, [sp, #0x1a8]
     57c:      	ldr	x29, [sp, #0x10]
     580:      	ldr	x30, [sp, #0x18]
     584:      	add	sp, sp, #0x1b0
     588:      	ret
     58c:      	mov	x12, x9
     590:      	lsl	x12, x12, #2
     594:      	lsr	w12, w12, #0
     598:      	ubfx	x12, x12, #0, #32
     59c:      	lsr	x11, x11, x12
     5a0:      	lsr	w11, w11, #0
     5a4:      	and	x11, x11, #0xf
     5a8:      	lsr	w11, w11, #0
     5ac:      	b	0x5c8 <_stogir.verify.structure+0x428>
     5b0:      	movz	x6, #0x0, lsl #48
     5b4:      	cmp	x6, #0x0
     5b8:      	b.eq	0xa7c <_stogir.verify.structure+0x8dc>
     5bc:      	ldr	w6, [sp, #0x158]
     5c0:      	b	0x6a0 <_stogir.verify.structure+0x500>
     5c4:      	movz	x11, #0x0, lsl #48
     5c8:      	b	0x5d0 <_stogir.verify.structure+0x430>
     5cc:      	movz	x11, #0x0, lsl #48
     5d0:      	add	x16, sp, #0x20
     5d4:      	str	x16, [sp]
     5d8:      	str	w0, [sp, #0xf0]
     5dc:      	str	x4, [sp, #0x108]
     5e0:      	str	x5, [sp, #0x110]
     5e4:      	str	x9, [sp, #0x130]
     5e8:      	str	x22, [sp, #0xf8]
     5ec:      	mov	x22, x2
     5f0:      	mov	w2, w3
     5f4:      	str	x23, [sp, #0x100]
     5f8:      	mov	x23, x1
     5fc:      	mov	w1, w0
     600:      	mov	x0, x21
     604:      	str	x25, [sp, #0x118]
     608:      	mov	x25, x6
     60c:      	str	x27, [sp, #0x120]
     610:      	mov	w27, w7
     614:      	str	x28, [sp, #0x128]
     618:      	mov	w28, w8
     61c:      	str	x20, [sp, #0x138]
     620:      	mov	w20, w10
     624:      	str	x26, [sp, #0x140]
     628:      	mov	x26, x11
     62c:      	bl	0x62c <_stogir.verify.structure+0x48c>
		000000000000062c:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
     630:      	ldr	x16, [sp]
     634:      	str	x0, [x16]
     638:      	str	x1, [x16, #0x8]
     63c:      	add	x16, sp, #0x20
     640:      	ldr	x0, [x16]
     644:      	add	x16, sp, #0x20
     648:      	ldr	x1, [x16, #0x8]
     64c:      	lsr	w0, w0, #0
     650:      	lsr	x16, x0, #0
     654:      	cmp	x16, #0x1
     658:      	b.eq	0x674 <_stogir.verify.structure+0x4d4>
     65c:      	b.lo	0x664 <_stogir.verify.structure+0x4c4>
     660:      	b	0x678 <_stogir.verify.structure+0x4d8>
     664:      	cmp	x16, #0x0
     668:      	b.eq	0x670 <_stogir.verify.structure+0x4d0>
     66c:      	b	0x678 <_stogir.verify.structure+0x4d8>
     670:      	b	0x67c <_stogir.verify.structure+0x4dc>
     674:      	b	0x788 <_stogir.verify.structure+0x5e8>
     678:      	b	0xb9c <_stogir.verify.structure+0x9fc>
     67c:      	str	x23, [sp, #0x148]
     680:      	ldr	x5, [sp, #0xd8]
     684:      	ldr	x3, [sp, #0xe0]
     688:      	ldr	x0, [sp, #0xd0]
     68c:      	ldr	x4, [sp, #0xc8]
     690:      	ldr	x7, [sp, #0xa8]
     694:      	mov	w6, w19
     698:      	ldr	x1, [sp, #0x80]
     69c:      	mov	x2, #0x17               ; =23
     6a0:      	ldr	x8, [sp, #0x148]
     6a4:      	add	x8, x8, #0x1
     6a8:      	lsr	w8, w8, #0
     6ac:      	sxtw	x8, w8
     6b0:      	ldr	x26, [sp, #0x140]
     6b4:      	ldr	x25, [sp, #0x118]
     6b8:      	str	x5, [sp, #0xd8]
     6bc:      	str	w20, [sp, #0xe8]
     6c0:      	ldr	x20, [sp, #0x138]
     6c4:      	ldr	x23, [sp, #0x100]
     6c8:      	str	x3, [sp, #0xe0]
     6cc:      	str	x0, [sp, #0xd0]
     6d0:      	ldr	w0, [sp, #0xf0]
     6d4:      	str	x4, [sp, #0xc8]
     6d8:      	str	x7, [sp, #0xa8]
     6dc:      	mov	w19, w6
     6e0:      	ldr	x27, [sp, #0x120]
     6e4:      	ldr	x28, [sp, #0x128]
     6e8:      	mov	x3, x1
     6ec:      	mov	x1, x8
     6f0:      	mov	x4, x2
     6f4:      	mov	x2, x22
     6f8:      	ldr	x22, [sp, #0xf8]
     6fc:      	cmp	x4, #0x0
     700:      	b.ne	0x720 <_stogir.verify.structure+0x580>
     704:      	cmp	x1, x25
     708:      	cset	w5, le
     70c:      	ubfx	x5, x5, #0, #8
     710:      	fmov	d31, x3
     714:      	mov	x3, x5
     718:      	fmov	x5, d31
     71c:      	b	0x728 <_stogir.verify.structure+0x588>
     720:      	mov	x5, x3
     724:      	movz	x3, #0x0, lsl #48
     728:      	cmp	x3, #0x0
     72c:      	b.eq	0xd34 <_stogir.verify.structure+0xb94>
     730:      	lsr	w3, w1, #0
     734:      	sxtw	x6, w3
     738:      	cmp	x6, #0x0
     73c:      	cset	w7, gt
     740:      	cmp	x6, #0x4
     744:      	cset	w8, gt
     748:      	sub	x9, x6, #0x1
     74c:      	lsr	w9, w9, #0
     750:      	sxtw	x9, w9
     754:      	ldr	w10, [sp, #0xe8]
     758:      	uxtb	w16, w10
     75c:      	cmp	w16, wzr
     760:      	b.eq	0x5cc <_stogir.verify.structure+0x42c>
     764:      	ldr	w11, [x22]
     768:      	uxtb	w16, w7
     76c:      	cmp	w16, wzr
     770:      	b.eq	0x5c4 <_stogir.verify.structure+0x424>
     774:      	uxtb	w16, w8
     778:      	cmp	w16, wzr
     77c:      	b.eq	0x58c <_stogir.verify.structure+0x3ec>
     780:      	mov	x12, #0x4               ; =4
     784:      	b	0x590 <_stogir.verify.structure+0x3f0>
     788:      	lsr	w26, w26, #0
     78c:      	adrp	x16, 0x0 <_gap_verify_graph>
		000000000000078c:  ARM64_RELOC_PAGE21	l_stogir.318
     790:      	ldr	x16, [x16]
		0000000000000790:  ARM64_RELOC_PAGEOFF12	l_stogir.318
     794:      	ldr	w0, [x16]
     798:      	orr	x2, x26, xzr
     79c:      	cmp	x2, x0
     7a0:      	b.ne	0x7ac <_stogir.verify.structure+0x60c>
     7a4:      	mov	x0, #0x1                ; =1
     7a8:      	b	0x7c4 <_stogir.verify.structure+0x624>
     7ac:      	adrp	x16, 0x0 <_gap_verify_graph>
		00000000000007ac:  ARM64_RELOC_PAGE21	l_stogir.319
     7b0:      	ldr	x16, [x16]
		00000000000007b0:  ARM64_RELOC_PAGEOFF12	l_stogir.319
     7b4:      	ldr	w0, [x16]
     7b8:      	cmp	x2, x0
     7bc:      	cset	w0, eq
     7c0:      	ubfx	x0, x0, #0, #8
     7c4:      	lsr	w1, w1, #0
     7c8:      	cmp	x0, #0x0
     7cc:      	b.eq	0xd68 <_stogir.verify.structure+0xbc8>
     7d0:      	lsr	w1, w1, #0
     7d4:      	str	x23, [sp, #0x148]
     7d8:      	mov	x23, x2
     7dc:      	str	x25, [sp, #0x150]
     7e0:      	mov	x25, x0
     7e4:      	mov	x0, x21
     7e8:      	str	w19, [sp, #0x158]
     7ec:      	mov	w19, w1
     7f0:      	bl	0x7f0 <_stogir.verify.structure+0x650>
		00000000000007f0:  ARM64_RELOC_BRANCH26	_stogir.graph.borrow-node
     7f4:      	cmp	x0, #0x0
     7f8:      	cset	w1, eq
     7fc:      	uxtb	w16, w1
     800:      	cmp	w16, wzr
     804:      	cset	x1, eq
     808:      	cmp	x1, #0x0
     80c:      	b.eq	0x83c <_stogir.verify.structure+0x69c>
     810:      	ldr	w0, [x0]
     814:      	uxtb	w0, w0
     818:      	cmp	x0, #0x48
     81c:      	b.ne	0x83c <_stogir.verify.structure+0x69c>
     820:      	ldr	x0, [sp, #0x88]
     824:      	mov	x2, #0x25               ; =37
     828:      	b	0x844 <_stogir.verify.structure+0x6a4>
     82c:      	ldr	x1, [sp, #0x110]
     830:      	ldr	x2, [sp, #0x108]
     834:      	movz	x0, #0x0, lsl #48
     838:      	b	0x850 <_stogir.verify.structure+0x6b0>
     83c:      	ldr	x0, [sp, #0x110]
     840:      	ldr	x2, [sp, #0x108]
     844:      	fmov	d31, x0
     848:      	mov	x0, x1
     84c:      	fmov	x1, d31
     850:      	sxtw	x19, w19
     854:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000854:  ARM64_RELOC_PAGE21	l_stogir.320
     858:      	ldr	x16, [x16]
		0000000000000858:  ARM64_RELOC_PAGEOFF12	l_stogir.320
     85c:      	ldr	w3, [x16]
     860:      	cmp	x23, x3
     864:      	b.ne	0xd84 <_stogir.verify.structure+0xbe4>
     868:      	cmp	x19, #0x0
     86c:      	b.gt	0x9e4 <_stogir.verify.structure+0x844>
     870:      	ldr	x5, [sp, #0xd8]
     874:      	ldr	x3, [sp, #0xe0]
     878:      	movz	x4, #0x0, lsl #48
     87c:      	lsr	w4, w4, #0
     880:      	lsr	x16, x4, #0
     884:      	cmp	x16, #0x1
     888:      	b.eq	0x8a4 <_stogir.verify.structure+0x704>
     88c:      	b.lo	0x894 <_stogir.verify.structure+0x6f4>
     890:      	b	0x8a8 <_stogir.verify.structure+0x708>
     894:      	cmp	x16, #0x0
     898:      	b.eq	0x8a0 <_stogir.verify.structure+0x700>
     89c:      	b	0x8a8 <_stogir.verify.structure+0x708>
     8a0:      	b	0x8ac <_stogir.verify.structure+0x70c>
     8a4:      	b	0x8b4 <_stogir.verify.structure+0x714>
     8a8:      	b	0xc44 <_stogir.verify.structure+0xaa4>
     8ac:      	ldr	x1, [sp, #0x90]
     8b0:      	mov	x2, #0x21               ; =33
     8b4:      	cmp	x26, #0xf
     8b8:      	b.hs	0xd90 <_stogir.verify.structure+0xbf0>
     8bc:      	mov	x16, #0x1               ; =1
     8c0:      	lsl	x4, x16, x26
     8c4:      	lsr	w4, w4, #0
     8c8:      	mov	x17, #0x5e1c            ; =24092
     8cc:      	and	x4, x4, x17
     8d0:      	lsr	w4, w4, #0
     8d4:      	cmp	x4, #0x0
     8d8:      	b.eq	0xda4 <_stogir.verify.structure+0xc04>
     8dc:      	cmp	x25, #0x0
     8e0:      	b.eq	0xab4 <_stogir.verify.structure+0x914>
     8e4:      	ldr	x4, [sp, #0xc8]
     8e8:      	ldr	x7, [sp, #0xa8]
     8ec:      	mov	x6, x0
     8f0:      	ldr	x0, [sp, #0xd0]
     8f4:      	b	0x5b4 <_stogir.verify.structure+0x414>
     8f8:      	lsr	w0, w26, #0
     8fc:      	lsl	x2, x22, #2
     900:      	cmp	x22, #0x78
     904:      	cset	w24, eq
     908:      	lsr	w0, w0, #0
     90c:      	add	x2, x23, x22, lsl #2
     910:      	add	x4, x27, x22, lsl #2
     914:      	cmp	x19, #0x0
     918:      	cset	w19, eq
     91c:      	orr	x22, x2, xzr
     920:      	orr	x2, x4, xzr
     924:      	mov	x4, x3
     928:      	mov	x3, x1
     92c:      	mov	x1, #0x1                ; =1
     930:      	b	0x6fc <_stogir.verify.structure+0x55c>
     934:      	ldr	x1, [sp, #0x78]
     938:      	mov	x2, #0x1b               ; =27
     93c:      	add	x0, x0, #0x1
     940:      	cmp	x2, #0x0
     944:      	b.ne	0x964 <_stogir.verify.structure+0x7c4>
     948:      	cmp	x0, x20
     94c:      	cset	w3, lt
     950:      	ubfx	x3, x3, #0, #8
     954:      	fmov	d31, x2
     958:      	mov	x2, x3
     95c:      	fmov	x3, d31
     960:      	b	0x96c <_stogir.verify.structure+0x7cc>
     964:      	mov	x3, x2
     968:      	movz	x2, #0x0, lsl #48
     96c:      	cmp	x2, #0x0
     970:      	b.eq	0x8f8 <_stogir.verify.structure+0x758>
     974:      	add	x2, x0, x26
     978:      	ldr	x4, [x21, #0x78]
     97c:      	lsl	x5, x2, #2
     980:      	add	x2, x4, x2, lsl #2
     984:      	ldr	w2, [x2]
     988:      	sxtw	x2, w2
     98c:      	cmn	x2, #0x1
     990:      	b.ne	0x934 <_stogir.verify.structure+0x794>
     994:      	mov	x2, x3
     998:      	b	0x93c <_stogir.verify.structure+0x79c>
     99c:      	ldr	x0, [sp, #0xb8]
     9a0:      	ldr	x1, [sp, #0xc0]
     9a4:      	add	x2, x25, #0x4
     9a8:      	ldr	x3, [x21, #0x8]
     9ac:      	asr	x16, x2, #63
     9b0:      	lsr	x16, x16, #62
     9b4:      	add	x2, x2, x16
     9b8:      	asr	x2, x2, #2
     9bc:      	orr	x20, x2, xzr
     9c0:      	add	x2, x20, x26
     9c4:      	cmp	x2, x3
     9c8:      	b.le	0x9d4 <_stogir.verify.structure+0x834>
     9cc:      	ldr	x0, [sp, #0x70]
     9d0:      	mov	x1, #0x15               ; =21
     9d4:      	mov	x2, x1
     9d8:      	mov	x1, x0
     9dc:      	mov	x0, #0x1                ; =1
     9e0:      	b	0x940 <_stogir.verify.structure+0x7a0>
     9e4:      	ldr	x3, [sp, #0xe0]
     9e8:      	ldr	x4, [x3, #0x8]
     9ec:      	cmp	x19, x4
     9f0:      	b.gt	0xdb8 <_stogir.verify.structure+0xc18>
     9f4:      	sub	x4, x19, #0x1
     9f8:      	ldr	x5, [sp, #0xd8]
     9fc:      	ldr	x6, [x5, #0x28]
     a00:      	mov	x17, #0x18              ; =24
     a04:      	mul	x4, x4, x17
     a08:      	add	x4, x4, x6
     a0c:      	ldr	x6, [x4]
     a10:      	ldr	x4, [x4, #0x8]
     a14:      	ldr	x7, [x5, #0x8]
     a18:      	cmp	x6, #0x0
     a1c:      	b.lt	0xa74 <_stogir.verify.structure+0x8d4>
     a20:      	cmp	x6, x7
     a24:      	b.gt	0xa74 <_stogir.verify.structure+0x8d4>
     a28:      	cmp	x4, #0x0
     a2c:      	b.lt	0xa74 <_stogir.verify.structure+0x8d4>
     a30:      	sub	x6, x7, x6
     a34:      	cmp	x4, x6
     a38:      	b.gt	0xa74 <_stogir.verify.structure+0x8d4>
     a3c:      	mov	x4, #0x1                ; =1
     a40:      	b	0xa78 <_stogir.verify.structure+0x8d8>
     a44:      	mov	w0, w24
     a48:      	bl	0xa48 <_stogir.verify.structure+0x8a8>
		0000000000000a48:  ARM64_RELOC_BRANCH26	_stogir.opcode.input-count
     a4c:      	lsr	w0, w0, #0
     a50:      	sxtw	x0, w0
     a54:      	cmn	x0, #0x1
     a58:      	b.ne	0x99c <_stogir.verify.structure+0x7fc>
     a5c:      	ubfx	x0, x20, #16, #16
     a60:      	cmp	x25, x0
     a64:      	b.eq	0x99c <_stogir.verify.structure+0x7fc>
     a68:      	ldr	x0, [sp, #0x68]
     a6c:      	mov	x1, #0x24               ; =36
     a70:      	b	0x9a4 <_stogir.verify.structure+0x804>
     a74:      	movz	x4, #0x0, lsl #48
     a78:      	b	0x87c <_stogir.verify.structure+0x6dc>
     a7c:      	cmp	x19, #0x0
     a80:      	b.ne	0xdc0 <_stogir.verify.structure+0xc20>
     a84:      	uxtb	w16, w20
     a88:      	cmp	w16, wzr
     a8c:      	b.eq	0xba4 <_stogir.verify.structure+0xa04>
     a90:      	ldr	w6, [x22]
     a94:      	uxtb	w16, w27
     a98:      	cmp	w16, wzr
     a9c:      	b.eq	0xbe4 <_stogir.verify.structure+0xa44>
     aa0:      	uxtb	w16, w28
     aa4:      	cmp	w16, wzr
     aa8:      	b.eq	0xc18 <_stogir.verify.structure+0xa78>
     aac:      	mov	x8, #0x4                ; =4
     ab0:      	b	0xc1c <_stogir.verify.structure+0xa7c>
     ab4:      	cmp	x19, #0x0
     ab8:      	b.le	0xdc8 <_stogir.verify.structure+0xc28>
     abc:      	ldr	x0, [x21, #0x8]
     ac0:      	cmp	x19, x0
     ac4:      	b.ge	0xdd0 <_stogir.verify.structure+0xc30>
     ac8:      	ldr	x0, [sp, #0xd0]
     acc:      	ldr	x4, [x0, #0x8]
     ad0:      	cmp	x19, x4
     ad4:      	b.ge	0xbf4 <_stogir.verify.structure+0xa54>
     ad8:      	lsl	x4, x19, #2
     adc:      	ldr	x4, [x21, #0x78]
     ae0:      	add	x4, x4, x19, lsl #2
     ae4:      	ldr	w4, [x4]
     ae8:      	sxtw	x4, w4
     aec:      	cmp	x4, #0x0
     af0:      	cset	w4, ge
     af4:      	ubfx	x4, x4, #0, #8
     af8:      	b	0xbf8 <_stogir.verify.structure+0xa58>
     afc:      	uxtb	w16, w24
     b00:      	cmp	w16, wzr
     b04:      	b.eq	0xdd8 <_stogir.verify.structure+0xc38>
     b08:      	ldr	w6, [sp, #0x158]
     b0c:      	uxtb	w16, w6
     b10:      	cmp	w16, wzr
     b14:      	b.eq	0xb24 <_stogir.verify.structure+0x984>
     b18:      	ldr	x8, [sp, #0x150]
     b1c:      	cmp	x8, #0x2
     b20:      	b.eq	0x5c0 <_stogir.verify.structure+0x420>
     b24:      	ldr	x1, [sp, #0x98]
     b28:      	mov	x2, #0x1a               ; =26
     b2c:      	b	0x5c0 <_stogir.verify.structure+0x420>
     b30:      	movz	x4, #0x0, lsl #48
     b34:      	ldr	x7, [sp, #0xa8]
     b38:      	mov	x6, x4
     b3c:      	ldr	x4, [sp, #0xc8]
     b40:      	b	0x5b4 <_stogir.verify.structure+0x414>
     b44:      	cmp	x19, #0x0
     b48:      	b.ge	0xde0 <_stogir.verify.structure+0xc40>
     b4c:      	ldr	x4, [sp, #0xc8]
     b50:      	ldr	x6, [x4, #0x8]
     b54:      	ldr	x7, [sp, #0xa8]
     b58:      	ldr	x8, [x7, #0x8]
     b5c:      	cmp	x6, x8
     b60:      	b.ne	0xbec <_stogir.verify.structure+0xa4c>
     b64:      	movz	x16, #0x0, lsl #48
     b68:      	sub	x8, x16, x19
     b6c:      	cmp	x8, x6
     b70:      	b.gt	0xc3c <_stogir.verify.structure+0xa9c>
     b74:      	sub	x6, x8, #0x1
     b78:      	ldr	x8, [x21, #0x50]
     b7c:      	lsl	x9, x6, #2
     b80:      	add	x6, x8, x6, lsl #2
     b84:      	ldr	w6, [x6]
     b88:      	sxtw	x6, w6
     b8c:      	cmp	x6, #0x0
     b90:      	cset	w6, gt
     b94:      	ubfx	x6, x6, #0, #8
     b98:      	b	0xc40 <_stogir.verify.structure+0xaa0>
     b9c:      	brk	#0
     ba0:      	b	0xb9c <_stogir.verify.structure+0x9fc>
     ba4:      	movz	x6, #0x0, lsl #48
     ba8:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000ba8:  ARM64_RELOC_PAGE21	l_stogir.321
     bac:      	ldr	x16, [x16]
		0000000000000bac:  ARM64_RELOC_PAGEOFF12	l_stogir.321
     bb0:      	ldr	w8, [x16]
     bb4:      	lsr	w6, w6, #0
     bb8:      	cmp	x6, x8
     bbc:      	b.ne	0xbc8 <_stogir.verify.structure+0xa28>
     bc0:      	ldr	w6, [sp, #0x158]
     bc4:      	b	0x5c0 <_stogir.verify.structure+0x420>
     bc8:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000bc8:  ARM64_RELOC_PAGE21	l_stogir.322
     bcc:      	ldr	x16, [x16]
		0000000000000bcc:  ARM64_RELOC_PAGEOFF12	l_stogir.322
     bd0:      	ldr	w8, [x16]
     bd4:      	cmp	x6, x8
     bd8:      	b.ne	0xbfc <_stogir.verify.structure+0xa5c>
     bdc:      	ldr	w6, [sp, #0x158]
     be0:      	b	0x5c0 <_stogir.verify.structure+0x420>
     be4:      	movz	x6, #0x0, lsl #48
     be8:      	b	0xba8 <_stogir.verify.structure+0xa08>
     bec:      	movz	x6, #0x0, lsl #48
     bf0:      	b	0x5b4 <_stogir.verify.structure+0x414>
     bf4:      	movz	x4, #0x0, lsl #48
     bf8:      	b	0xb34 <_stogir.verify.structure+0x994>
     bfc:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000bfc:  ARM64_RELOC_PAGE21	l_stogir.323
     c00:      	ldr	x16, [x16]
		0000000000000c00:  ARM64_RELOC_PAGEOFF12	l_stogir.323
     c04:      	ldr	w8, [x16]
     c08:      	cmp	x6, x8
     c0c:      	b.ne	0xafc <_stogir.verify.structure+0x95c>
     c10:      	ldr	w6, [sp, #0x158]
     c14:      	b	0x5c0 <_stogir.verify.structure+0x420>
     c18:      	ldr	x8, [sp, #0x130]
     c1c:      	lsl	x8, x8, #2
     c20:      	lsr	w8, w8, #0
     c24:      	ubfx	x8, x8, #0, #32
     c28:      	lsr	x6, x6, x8
     c2c:      	lsr	w6, w6, #0
     c30:      	and	x6, x6, #0xf
     c34:      	lsr	w6, w6, #0
     c38:      	b	0xbe8 <_stogir.verify.structure+0xa48>
     c3c:      	movz	x6, #0x0, lsl #48
     c40:      	b	0xbf0 <_stogir.verify.structure+0xa50>
     c44:      	brk	#0
     c48:      	b	0xc44 <_stogir.verify.structure+0xaa4>
     c4c:      	str	x8, [sp, #0xa0]
     c50:      	str	x12, [sp, #0xb8]
     c54:      	str	x13, [sp, #0xc0]
     c58:      	b	0x518 <_stogir.verify.structure+0x378>
     c5c:      	str	x8, [sp, #0xa0]
     c60:      	str	x12, [sp, #0xb8]
     c64:      	str	x13, [sp, #0xc0]
     c68:      	b	0x518 <_stogir.verify.structure+0x378>
     c6c:      	str	x8, [sp, #0xa0]
     c70:      	str	x19, [sp, #0x40]
     c74:      	str	x20, [sp, #0x58]
     c78:      	str	x21, [sp, #0x60]
     c7c:      	mov	x21, x0
     c80:      	str	x22, [sp, #0x68]
     c84:      	str	x23, [sp, #0x70]
     c88:      	str	x24, [sp, #0x78]
     c8c:      	str	x25, [sp, #0x80]
     c90:      	str	x26, [sp, #0x88]
     c94:      	str	x27, [sp, #0x90]
     c98:      	str	x28, [sp, #0x98]
     c9c:      	str	x4, [sp, #0x100]
     ca0:      	mov	x0, x5
     ca4:      	mov	x5, x3
     ca8:      	mov	x3, x11
     cac:      	mov	x4, x6
     cb0:      	str	x9, [sp, #0x120]
     cb4:      	str	x10, [sp, #0x128]
     cb8:      	b	0x354 <_stogir.verify.structure+0x1b4>
     cbc:      	str	x8, [sp, #0xa0]
     cc0:      	str	x20, [sp, #0x58]
     cc4:      	str	x21, [sp, #0x60]
     cc8:      	ldr	x21, [sp, #0x30]
     ccc:      	str	x22, [sp, #0x68]
     cd0:      	str	x23, [sp, #0x70]
     cd4:      	str	x24, [sp, #0x78]
     cd8:      	str	x25, [sp, #0x80]
     cdc:      	str	x26, [sp, #0x88]
     ce0:      	str	x27, [sp, #0x90]
     ce4:      	str	x28, [sp, #0x98]
     ce8:      	str	x4, [sp, #0x100]
     cec:      	mov	x0, x5
     cf0:      	mov	x5, x3
     cf4:      	mov	x3, x11
     cf8:      	mov	x4, x6
     cfc:      	str	x9, [sp, #0x120]
     d00:      	str	x10, [sp, #0x128]
     d04:      	b	0x2fc <_stogir.verify.structure+0x15c>
     d08:      	mov	x1, x26
     d0c:      	ldr	x2, [sp, #0xb0]
     d10:      	ldr	x5, [sp, #0xd8]
     d14:      	str	x23, [sp, #0x100]
     d18:      	ldr	x3, [sp, #0xe0]
     d1c:      	ldr	x0, [sp, #0xd0]
     d20:      	ldr	x4, [sp, #0xc8]
     d24:      	ldr	x7, [sp, #0xa8]
     d28:      	str	x27, [sp, #0x120]
     d2c:      	str	x28, [sp, #0x128]
     d30:      	b	0x2fc <_stogir.verify.structure+0x15c>
     d34:      	str	x26, [sp, #0x140]
     d38:      	str	x20, [sp, #0x138]
     d3c:      	str	x5, [sp, #0x110]
     d40:      	ldr	x5, [sp, #0xd8]
     d44:      	str	x4, [sp, #0x108]
     d48:      	str	x23, [sp, #0x100]
     d4c:      	ldr	x3, [sp, #0xe0]
     d50:      	ldr	x0, [sp, #0xd0]
     d54:      	ldr	x4, [sp, #0xc8]
     d58:      	ldr	x7, [sp, #0xa8]
     d5c:      	str	x27, [sp, #0x120]
     d60:      	str	x28, [sp, #0x128]
     d64:      	b	0x200 <_stogir.verify.structure+0x60>
     d68:      	str	x23, [sp, #0x148]
     d6c:      	mov	x23, x2
     d70:      	str	x25, [sp, #0x150]
     d74:      	mov	x25, x0
     d78:      	str	w19, [sp, #0x158]
     d7c:      	mov	w19, w1
     d80:      	b	0x82c <_stogir.verify.structure+0x68c>
     d84:      	ldr	x5, [sp, #0xd8]
     d88:      	ldr	x3, [sp, #0xe0]
     d8c:      	b	0x8b4 <_stogir.verify.structure+0x714>
     d90:      	ldr	x0, [sp, #0xd0]
     d94:      	ldr	x4, [sp, #0xc8]
     d98:      	ldr	x7, [sp, #0xa8]
     d9c:      	ldr	w6, [sp, #0x158]
     da0:      	b	0x5c0 <_stogir.verify.structure+0x420>
     da4:      	ldr	x0, [sp, #0xd0]
     da8:      	ldr	x4, [sp, #0xc8]
     dac:      	ldr	x7, [sp, #0xa8]
     db0:      	ldr	w6, [sp, #0x158]
     db4:      	b	0x5c0 <_stogir.verify.structure+0x420>
     db8:      	ldr	x5, [sp, #0xd8]
     dbc:      	b	0x878 <_stogir.verify.structure+0x6d8>
     dc0:      	ldr	w6, [sp, #0x158]
     dc4:      	b	0xb24 <_stogir.verify.structure+0x984>
     dc8:      	ldr	x0, [sp, #0xd0]
     dcc:      	b	0xb44 <_stogir.verify.structure+0x9a4>
     dd0:      	ldr	x0, [sp, #0xd0]
     dd4:      	b	0xb30 <_stogir.verify.structure+0x990>
     dd8:      	ldr	w6, [sp, #0x158]
     ddc:      	b	0xb24 <_stogir.verify.structure+0x984>
     de0:      	ldr	x4, [sp, #0xc8]
     de4:      	ldr	x7, [sp, #0xa8]
     de8:      	b	0x5b0 <_stogir.verify.structure+0x410>

0000000000000dec <_stogir.verify.integer-operations-target-structured>:
     dec:      	sub	sp, sp, #0x4a0
     df0:      	str	x29, [sp, #0x10]
     df4:      	str	x30, [sp, #0x18]
     df8:      	add	x29, sp, #0x10
     dfc:      	str	x19, [sp, #0x448]
     e00:      	str	x20, [sp, #0x450]
     e04:      	str	x21, [sp, #0x458]
     e08:      	str	x22, [sp, #0x460]
     e0c:      	str	x23, [sp, #0x468]
     e10:      	str	x24, [sp, #0x470]
     e14:      	str	x25, [sp, #0x478]
     e18:      	str	x26, [sp, #0x480]
     e1c:      	str	x27, [sp, #0x488]
     e20:      	str	x28, [sp, #0x490]
     e24:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e24:  ARM64_RELOC_PAGE21	l_stogir.324
     e28:      	ldr	x16, [x16]
		0000000000000e28:  ARM64_RELOC_PAGEOFF12	l_stogir.324
     e2c:      	orr	x2, x16, xzr
     e30:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e30:  ARM64_RELOC_PAGE21	l_stogir.325
     e34:      	ldr	x16, [x16]
		0000000000000e34:  ARM64_RELOC_PAGEOFF12	l_stogir.325
     e38:      	orr	x19, x16, xzr
     e3c:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e3c:  ARM64_RELOC_PAGE21	l_stogir.326
     e40:      	ldr	x16, [x16]
		0000000000000e40:  ARM64_RELOC_PAGEOFF12	l_stogir.326
     e44:      	orr	x20, x16, xzr
     e48:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e48:  ARM64_RELOC_PAGE21	l_stogir.327
     e4c:      	ldr	x16, [x16]
		0000000000000e4c:  ARM64_RELOC_PAGEOFF12	l_stogir.327
     e50:      	orr	x21, x16, xzr
     e54:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e54:  ARM64_RELOC_PAGE21	l_stogir.328
     e58:      	ldr	x16, [x16]
		0000000000000e58:  ARM64_RELOC_PAGEOFF12	l_stogir.328
     e5c:      	orr	x22, x16, xzr
     e60:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e60:  ARM64_RELOC_PAGE21	l_stogir.329
     e64:      	ldr	x16, [x16]
		0000000000000e64:  ARM64_RELOC_PAGEOFF12	l_stogir.329
     e68:      	orr	x23, x16, xzr
     e6c:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e6c:  ARM64_RELOC_PAGE21	l_stogir.330
     e70:      	ldr	x16, [x16]
		0000000000000e70:  ARM64_RELOC_PAGEOFF12	l_stogir.330
     e74:      	orr	x24, x16, xzr
     e78:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e78:  ARM64_RELOC_PAGE21	l_stogir.331
     e7c:      	ldr	x16, [x16]
		0000000000000e7c:  ARM64_RELOC_PAGEOFF12	l_stogir.331
     e80:      	orr	x25, x16, xzr
     e84:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e84:  ARM64_RELOC_PAGE21	l_stogir.332
     e88:      	ldr	x16, [x16]
		0000000000000e88:  ARM64_RELOC_PAGEOFF12	l_stogir.332
     e8c:      	orr	x26, x16, xzr
     e90:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e90:  ARM64_RELOC_PAGE21	l_stogir.333
     e94:      	ldr	x16, [x16]
		0000000000000e94:  ARM64_RELOC_PAGEOFF12	l_stogir.333
     e98:      	orr	x27, x16, xzr
     e9c:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e9c:  ARM64_RELOC_PAGE21	l_stogir.334
     ea0:      	ldr	x16, [x16]
		0000000000000ea0:  ARM64_RELOC_PAGEOFF12	l_stogir.334
     ea4:      	orr	x28, x16, xzr
     ea8:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000ea8:  ARM64_RELOC_PAGE21	l_stogir.335
     eac:      	ldr	x16, [x16]
		0000000000000eac:  ARM64_RELOC_PAGEOFF12	l_stogir.335
     eb0:      	orr	x3, x16, xzr
     eb4:      	lsr	w4, w1, #0
     eb8:      	lsr	w5, w1, #0
     ebc:      	lsr	w1, w1, #0
     ec0:      	add	x16, sp, #0x20
     ec4:      	orr	x6, x16, xzr
     ec8:      	add	x16, sp, #0x30
     ecc:      	orr	x7, x16, xzr
     ed0:      	add	x7, x7, #0x8
     ed4:      	add	x16, sp, #0x50
     ed8:      	orr	x9, x16, xzr
     edc:      	add	x9, x9, #0x8
     ee0:      	add	x16, sp, #0xe0
     ee4:      	orr	x10, x16, xzr
     ee8:      	add	x10, x10, #0x8
     eec:      	add	x16, sp, #0x100
     ef0:      	orr	x11, x16, xzr
     ef4:      	add	x11, x11, #0x8
     ef8:      	add	x16, sp, #0x120
     efc:      	orr	x12, x16, xzr
     f00:      	add	x12, x12, #0x8
     f04:      	add	x16, sp, #0x140
     f08:      	orr	x13, x16, xzr
     f0c:      	add	x13, x13, #0x8
     f10:      	add	x16, sp, #0x160
     f14:      	orr	x14, x16, xzr
     f18:      	add	x14, x14, #0x8
     f1c:      	add	x16, sp, #0x180
     f20:      	orr	x15, x16, xzr
     f24:      	add	x15, x15, #0x8
     f28:      	str	w1, [sp, #0x230]
     f2c:      	add	x16, sp, #0x1a0
     f30:      	orr	x1, x16, xzr
     f34:      	add	x1, x1, #0x8
     f38:      	str	x1, [sp, #0x238]
     f3c:      	add	x16, sp, #0x1f0
     f40:      	orr	x1, x16, xzr
     f44:      	add	x1, x1, #0x8
     f48:      	str	x19, [sp, #0x240]
     f4c:      	str	x20, [sp, #0x250]
     f50:      	str	x2, [sp, #0x248]
     f54:      	mov	x2, #0x1                ; =1
     f58:      	movz	x19, #0x0, lsl #48
     f5c:      	movz	x20, #0x0, lsl #48
     f60:      	cmp	x20, #0x0
     f64:      	b.ne	0x2248 <_stogir.verify.integer-operations-target-structured+0x145c>
     f68:      	str	x1, [sp, #0x258]
     f6c:      	ldr	x1, [x0, #0x8]
     f70:      	cmp	x2, x1
     f74:      	b.ge	0x2254 <_stogir.verify.integer-operations-target-structured+0x1468>
     f78:      	lsl	x1, x2, #4
     f7c:      	lsl	x1, x2, #2
     f80:      	ldr	x1, [x0]
     f84:      	add	x1, x1, x2, lsl #4
     f88:      	str	x3, [sp, #0x260]
     f8c:      	ldr	x3, [x1]
     f90:      	str	x21, [sp, #0x268]
     f94:      	uxtb	w21, w3
     f98:      	ldr	x1, [x1, #0x8]
     f9c:      	str	x22, [sp, #0x270]
     fa0:      	orr	x22, x21, xzr
     fa4:      	add	x16, sp, #0x20
     fa8:      	str	x3, [x16]
     fac:      	add	x16, sp, #0x20
     fb0:      	str	x1, [x16, #0x8]
     fb4:      	ldr	x1, [x0, #0x78]
     fb8:      	add	x1, x1, x2, lsl #2
     fbc:      	ldr	w1, [x1]
     fc0:      	cmp	x22, #0xe
     fc4:      	b.lt	0x17e0 <_stogir.verify.integer-operations-target-structured+0x9f4>
     fc8:      	cmp	x22, #0x17
     fcc:      	cset	w3, le
     fd0:      	ubfx	x3, x3, #0, #8
     fd4:      	str	x23, [sp, #0x278]
     fd8:      	cmp	x22, #0x1a
     fdc:      	cset	w23, ge
     fe0:      	str	x24, [sp, #0x280]
     fe4:      	cmp	x22, #0x1e
     fe8:      	cset	w24, le
     fec:      	str	x25, [sp, #0x288]
     ff0:      	cmp	x22, #0x2e
     ff4:      	cset	w25, ge
     ff8:      	str	x26, [sp, #0x290]
     ffc:      	cmp	x22, #0x35
    1000:      	cset	w26, le
    1004:      	str	x27, [sp, #0x298]
    1008:      	cmp	x22, #0x3a
    100c:      	cset	w27, eq
    1010:      	str	x28, [sp, #0x2a0]
    1014:      	cmp	x22, #0x3b
    1018:      	cset	w28, eq
    101c:      	uxtb	w16, w23
    1020:      	cmp	w16, wzr
    1024:      	b.eq	0x17e8 <_stogir.verify.integer-operations-target-structured+0x9fc>
    1028:      	uxtb	w16, w24
    102c:      	cmp	w16, wzr
    1030:      	b.eq	0x17e8 <_stogir.verify.integer-operations-target-structured+0x9fc>
    1034:      	str	x0, [sp, #0x2a8]
    1038:      	mov	x0, #0x1                ; =1
    103c:      	cmp	x22, #0x1f
    1040:      	b.ne	0x1830 <_stogir.verify.integer-operations-target-structured+0xa44>
    1044:      	str	x0, [sp, #0x2b0]
    1048:      	mov	x0, #0x1                ; =1
    104c:      	str	x0, [sp, #0x2b8]
    1050:      	lsr	w0, w2, #0
    1054:      	lsr	w1, w1, #0
    1058:      	lsr	w0, w0, #0
    105c:      	str	x8, [sp, #0x2c0]
    1060:      	str	w4, [sp, #0x2d0]
    1064:      	str	w5, [sp, #0x2d8]
    1068:      	str	x6, [sp, #0x2e0]
    106c:      	str	x15, [sp, #0x320]
    1070:      	str	x2, [sp, #0x328]
    1074:      	mov	x2, x6
    1078:      	str	w1, [sp, #0x330]
    107c:      	str	x3, [sp, #0x338]
    1080:      	mov	w3, w1
    1084:      	mov	w1, w0
    1088:      	str	w0, [sp, #0x340]
    108c:      	ldr	x0, [sp, #0x2a8]
    1090:      	str	x20, [sp, #0x2c8]
    1094:      	ldr	x20, [sp, #0x260]
    1098:      	str	w28, [sp, #0x2e8]
    109c:      	mov	x28, x7
    10a0:      	str	w27, [sp, #0x2f0]
    10a4:      	mov	x27, x9
    10a8:      	str	w26, [sp, #0x2f8]
    10ac:      	mov	x26, x10
    10b0:      	str	w25, [sp, #0x300]
    10b4:      	mov	x25, x11
    10b8:      	str	w24, [sp, #0x308]
    10bc:      	mov	x24, x12
    10c0:      	str	w23, [sp, #0x310]
    10c4:      	mov	x23, x13
    10c8:      	str	w21, [sp, #0x318]
    10cc:      	mov	x21, x14
    10d0:      	bl	0x10d0 <_stogir.verify.integer-operations-target-structured+0x2e4>
		00000000000010d0:  ARM64_RELOC_BRANCH26	_stogir.verify.classifications
    10d4:      	uxtb	w1, w0
    10d8:      	cmp	x1, #0x0
    10dc:      	cset	w1, ne
    10e0:      	cmp	x22, #0x3d
    10e4:      	b.lt	0x18a8 <_stogir.verify.integer-operations-target-structured+0xabc>
    10e8:      	cmp	x22, #0x3f
    10ec:      	b.gt	0x18a8 <_stogir.verify.integer-operations-target-structured+0xabc>
    10f0:      	add	x8, sp, #0x30
    10f4:      	ldr	w2, [sp, #0x2d0]
    10f8:      	str	x0, [sp, #0x348]
    10fc:      	ldr	x0, [sp, #0x2a8]
    1100:      	str	x21, [sp, #0x350]
    1104:      	mov	w21, w1
    1108:      	ldr	w1, [sp, #0x340]
    110c:      	bl	0x110c <_stogir.verify.integer-operations-target-structured+0x320>
		000000000000110c:  ARM64_RELOC_BRANCH26	_stogir.vector.validate
    1110:      	add	x16, sp, #0x30
    1114:      	ldr	w0, [x16]
    1118:      	lsr	x16, x0, #0
    111c:      	cmp	x16, #0x1
    1120:      	b.eq	0x113c <_stogir.verify.integer-operations-target-structured+0x350>
    1124:      	b.lo	0x112c <_stogir.verify.integer-operations-target-structured+0x340>
    1128:      	b	0x1140 <_stogir.verify.integer-operations-target-structured+0x354>
    112c:      	cmp	x16, #0x0
    1130:      	b.eq	0x1138 <_stogir.verify.integer-operations-target-structured+0x34c>
    1134:      	b	0x1140 <_stogir.verify.integer-operations-target-structured+0x354>
    1138:      	b	0x18cc <_stogir.verify.integer-operations-target-structured+0xae0>
    113c:      	b	0x1144 <_stogir.verify.integer-operations-target-structured+0x358>
    1140:      	b	0x21cc <_stogir.verify.integer-operations-target-structured+0x13e0>
    1144:      	add	x16, sp, #0x30
    1148:      	ldr	x0, [x16, #0x8]
    114c:      	ldr	x1, [x28, #0x8]
    1150:      	mov	x2, x1
    1154:      	mov	x1, x0
    1158:      	mov	x0, x19
    115c:      	mov	x19, x0
    1160:      	mov	x0, x1
    1164:      	mov	x1, x2
    1168:      	cmp	x22, #0x44
    116c:      	b.ne	0x18f0 <_stogir.verify.integer-operations-target-structured+0xb04>
    1170:      	uxtb	w16, w21
    1174:      	cmp	w16, wzr
    1178:      	b.eq	0x18e4 <_stogir.verify.integer-operations-target-structured+0xaf8>
    117c:      	mov	x2, x0
    1180:      	movz	x0, #0x0, lsl #48
    1184:      	fmov	d31, x1
    1188:      	mov	x1, x2
    118c:      	fmov	x2, d31
    1190:      	cmp	x0, #0x0
    1194:      	b.eq	0x2260 <_stogir.verify.integer-operations-target-structured+0x1474>
    1198:      	add	x8, sp, #0x50
    119c:      	ldr	x0, [sp, #0x2a8]
    11a0:      	str	x1, [sp, #0x358]
    11a4:      	ldr	w1, [sp, #0x340]
    11a8:      	str	x2, [sp, #0x360]
    11ac:      	bl	0x11ac <_stogir.verify.integer-operations-target-structured+0x3c0>
		00000000000011ac:  ARM64_RELOC_BRANCH26	_stogir.copy.validate
    11b0:      	add	x16, sp, #0x50
    11b4:      	ldr	w0, [x16]
    11b8:      	lsr	x16, x0, #0
    11bc:      	cmp	x16, #0x1
    11c0:      	b.eq	0x11dc <_stogir.verify.integer-operations-target-structured+0x3f0>
    11c4:      	b.lo	0x11cc <_stogir.verify.integer-operations-target-structured+0x3e0>
    11c8:      	b	0x11e0 <_stogir.verify.integer-operations-target-structured+0x3f4>
    11cc:      	cmp	x16, #0x0
    11d0:      	b.eq	0x11d8 <_stogir.verify.integer-operations-target-structured+0x3ec>
    11d4:      	b	0x11e0 <_stogir.verify.integer-operations-target-structured+0x3f4>
    11d8:      	b	0x1900 <_stogir.verify.integer-operations-target-structured+0xb14>
    11dc:      	b	0x11e4 <_stogir.verify.integer-operations-target-structured+0x3f8>
    11e0:      	b	0x1918 <_stogir.verify.integer-operations-target-structured+0xb2c>
    11e4:      	add	x16, sp, #0x50
    11e8:      	ldr	x0, [x16, #0x8]
    11ec:      	ldr	x1, [x27, #0x8]
    11f0:      	mov	x2, x1
    11f4:      	mov	x1, x0
    11f8:      	mov	x0, x19
    11fc:      	mov	x19, x0
    1200:      	mov	x0, x1
    1204:      	mov	x1, x2
    1208:      	cmp	x22, #0x1d
    120c:      	b.ne	0x192c <_stogir.verify.integer-operations-target-structured+0xb40>
    1210:      	mov	x2, x1
    1214:      	mov	x1, x0
    1218:      	mov	x0, #0x1                ; =1
    121c:      	cmp	x0, #0x0
    1220:      	b.eq	0x1954 <_stogir.verify.integer-operations-target-structured+0xb68>
    1224:      	add	x16, sp, #0x20
    1228:      	ldr	w0, [x16, #0xc]
    122c:      	sxtw	x0, w0
    1230:      	cmp	x0, #0x0
    1234:      	b.ne	0x194c <_stogir.verify.integer-operations-target-structured+0xb60>
    1238:      	movz	x0, #0x0, lsl #48
    123c:      	cmp	x0, #0x0
    1240:      	b.eq	0x226c <_stogir.verify.integer-operations-target-structured+0x1480>
    1244:      	add	x16, sp, #0x20
    1248:      	ldr	w0, [x16, #0xc]
    124c:      	lsr	w0, w0, #0
    1250:      	add	x8, sp, #0x70
    1254:      	str	x1, [sp, #0x368]
    1258:      	mov	w1, w0
    125c:      	ldr	x0, [sp, #0x2a8]
    1260:      	str	x2, [sp, #0x370]
    1264:      	bl	0x1264 <_stogir.verify.integer-operations-target-structured+0x478>
		0000000000001264:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    1268:      	add	x16, sp, #0x70
    126c:      	ldr	w0, [x16]
    1270:      	lsr	x16, x0, #0
    1274:      	cmp	x16, #0x1
    1278:      	b.eq	0x1294 <_stogir.verify.integer-operations-target-structured+0x4a8>
    127c:      	b.lo	0x1284 <_stogir.verify.integer-operations-target-structured+0x498>
    1280:      	b	0x1298 <_stogir.verify.integer-operations-target-structured+0x4ac>
    1284:      	cmp	x16, #0x0
    1288:      	b.eq	0x1290 <_stogir.verify.integer-operations-target-structured+0x4a4>
    128c:      	b	0x1298 <_stogir.verify.integer-operations-target-structured+0x4ac>
    1290:      	b	0x129c <_stogir.verify.integer-operations-target-structured+0x4b0>
    1294:      	b	0x195c <_stogir.verify.integer-operations-target-structured+0xb70>
    1298:      	b	0x1a10 <_stogir.verify.integer-operations-target-structured+0xc24>
    129c:      	ldr	x0, [sp, #0x240]
    12a0:      	mov	x1, #0x16               ; =22
    12a4:      	cmp	x22, #0x2c
    12a8:      	cset	w2, eq
    12ac:      	cmp	x22, #0x29
    12b0:      	b.lt	0x1a24 <_stogir.verify.integer-operations-target-structured+0xc38>
    12b4:      	cmp	x22, #0x2b
    12b8:      	b.gt	0x1a24 <_stogir.verify.integer-operations-target-structured+0xc38>
    12bc:      	uxtb	w16, w2
    12c0:      	cmp	w16, wzr
    12c4:      	b.eq	0x2278 <_stogir.verify.integer-operations-target-structured+0x148c>
    12c8:      	add	x8, sp, #0xa0
    12cc:      	str	x0, [sp, #0x378]
    12d0:      	ldr	x0, [sp, #0x2a8]
    12d4:      	str	x1, [sp, #0x380]
    12d8:      	ldr	w1, [sp, #0x340]
    12dc:      	bl	0x12dc <_stogir.verify.integer-operations-target-structured+0x4f0>
		00000000000012dc:  ARM64_RELOC_BRANCH26	_stogir.checked.validate-projection
    12e0:      	add	x16, sp, #0xa0
    12e4:      	ldr	x0, [x16]
    12e8:      	add	x16, sp, #0xa0
    12ec:      	ldr	x1, [x16, #0x8]
    12f0:      	add	x16, sp, #0xa0
    12f4:      	ldr	x2, [x16, #0x10]
    12f8:      	lsr	w0, w0, #0
    12fc:      	lsr	x16, x0, #0
    1300:      	cmp	x16, #0x1
    1304:      	b.eq	0x1320 <_stogir.verify.integer-operations-target-structured+0x534>
    1308:      	b.lo	0x1310 <_stogir.verify.integer-operations-target-structured+0x524>
    130c:      	b	0x1324 <_stogir.verify.integer-operations-target-structured+0x538>
    1310:      	cmp	x16, #0x0
    1314:      	b.eq	0x131c <_stogir.verify.integer-operations-target-structured+0x530>
    1318:      	b	0x1324 <_stogir.verify.integer-operations-target-structured+0x538>
    131c:      	b	0x1a60 <_stogir.verify.integer-operations-target-structured+0xc74>
    1320:      	b	0x1328 <_stogir.verify.integer-operations-target-structured+0x53c>
    1324:      	b	0x21c4 <_stogir.verify.integer-operations-target-structured+0x13d8>
    1328:      	mov	x0, x19
    132c:      	mov	x19, x0
    1330:      	mov	x0, x1
    1334:      	mov	x1, x2
    1338:      	cmp	x22, #0x7e
    133c:      	b.lt	0x2284 <_stogir.verify.integer-operations-target-structured+0x1498>
    1340:      	cmp	x22, #0x82
    1344:      	b.gt	0x2290 <_stogir.verify.integer-operations-target-structured+0x14a4>
    1348:      	add	x8, sp, #0xe0
    134c:      	str	x0, [sp, #0x388]
    1350:      	ldr	x0, [sp, #0x2a8]
    1354:      	str	x1, [sp, #0x390]
    1358:      	ldr	w1, [sp, #0x340]
    135c:      	bl	0x135c <_stogir.verify.integer-operations-target-structured+0x570>
		000000000000135c:  ARM64_RELOC_BRANCH26	_stogir.atomic.validate
    1360:      	add	x16, sp, #0xe0
    1364:      	ldr	w0, [x16]
    1368:      	lsr	x16, x0, #0
    136c:      	cmp	x16, #0x1
    1370:      	b.eq	0x138c <_stogir.verify.integer-operations-target-structured+0x5a0>
    1374:      	b.lo	0x137c <_stogir.verify.integer-operations-target-structured+0x590>
    1378:      	b	0x1390 <_stogir.verify.integer-operations-target-structured+0x5a4>
    137c:      	cmp	x16, #0x0
    1380:      	b.eq	0x1388 <_stogir.verify.integer-operations-target-structured+0x59c>
    1384:      	b	0x1390 <_stogir.verify.integer-operations-target-structured+0x5a4>
    1388:      	b	0x1a78 <_stogir.verify.integer-operations-target-structured+0xc8c>
    138c:      	b	0x1394 <_stogir.verify.integer-operations-target-structured+0x5a8>
    1390:      	b	0x1a90 <_stogir.verify.integer-operations-target-structured+0xca4>
    1394:      	add	x16, sp, #0xe0
    1398:      	ldr	x0, [x16, #0x8]
    139c:      	ldr	x1, [x26, #0x8]
    13a0:      	mov	x2, x1
    13a4:      	mov	x1, x0
    13a8:      	mov	x0, x19
    13ac:      	mov	x19, x0
    13b0:      	mov	x0, x1
    13b4:      	mov	x1, x2
    13b8:      	cmp	x22, #0x60
    13bc:      	b.eq	0x1aa4 <_stogir.verify.integer-operations-target-structured+0xcb8>
    13c0:      	cmp	x22, #0x79
    13c4:      	b.eq	0x1aa4 <_stogir.verify.integer-operations-target-structured+0xcb8>
    13c8:      	cmp	x22, #0x75
    13cc:      	b.eq	0x1b30 <_stogir.verify.integer-operations-target-structured+0xd44>
    13d0:      	cmp	x22, #0x6d
    13d4:      	b.lt	0x229c <_stogir.verify.integer-operations-target-structured+0x14b0>
    13d8:      	cmp	x22, #0x6f
    13dc:      	b.le	0x1b30 <_stogir.verify.integer-operations-target-structured+0xd44>
    13e0:      	str	x0, [sp, #0x3a8]
    13e4:      	str	x1, [sp, #0x3b0]
    13e8:      	ldr	x0, [sp, #0x3a8]
    13ec:      	ldr	x1, [sp, #0x3b0]
    13f0:      	cmp	x22, #0x42
    13f4:      	b.eq	0x1bc4 <_stogir.verify.integer-operations-target-structured+0xdd8>
    13f8:      	cmp	x22, #0x51
    13fc:      	b.eq	0x1bc4 <_stogir.verify.integer-operations-target-structured+0xdd8>
    1400:      	cmp	x22, #0x52
    1404:      	b.eq	0x1bc4 <_stogir.verify.integer-operations-target-structured+0xdd8>
    1408:      	cmp	x22, #0x53
    140c:      	b.eq	0x1bc4 <_stogir.verify.integer-operations-target-structured+0xdd8>
    1410:      	cmp	x22, #0x54
    1414:      	b.eq	0x1bc4 <_stogir.verify.integer-operations-target-structured+0xdd8>
    1418:      	cmp	x22, #0x41
    141c:      	b.eq	0x1c50 <_stogir.verify.integer-operations-target-structured+0xe64>
    1420:      	cmp	x22, #0x48
    1424:      	b.eq	0x1c50 <_stogir.verify.integer-operations-target-structured+0xe64>
    1428:      	cmp	x22, #0x55
    142c:      	b.lt	0x22a8 <_stogir.verify.integer-operations-target-structured+0x14bc>
    1430:      	cmp	x22, #0x58
    1434:      	b.le	0x1c50 <_stogir.verify.integer-operations-target-structured+0xe64>
    1438:      	str	x0, [sp, #0x3c8]
    143c:      	str	x1, [sp, #0x3d0]
    1440:      	ldr	x1, [sp, #0x350]
    1444:      	ldr	x0, [sp, #0x3c8]
    1448:      	ldr	x2, [sp, #0x3d0]
    144c:      	cmp	x22, #0x21
    1450:      	b.lt	0x22b8 <_stogir.verify.integer-operations-target-structured+0x14cc>
    1454:      	cmp	x22, #0x27
    1458:      	b.gt	0x22cc <_stogir.verify.integer-operations-target-structured+0x14e0>
    145c:      	add	x8, sp, #0x180
    1460:      	str	x1, [sp, #0x350]
    1464:      	ldr	w1, [sp, #0x340]
    1468:      	str	x0, [sp, #0x3d8]
    146c:      	ldr	x0, [sp, #0x2a8]
    1470:      	str	x2, [sp, #0x3e0]
    1474:      	ldr	w2, [sp, #0x230]
    1478:      	bl	0x1478 <_stogir.verify.integer-operations-target-structured+0x68c>
		0000000000001478:  ARM64_RELOC_BRANCH26	_stogir.conversion.validate
    147c:      	add	x16, sp, #0x180
    1480:      	ldr	w0, [x16]
    1484:      	lsr	x16, x0, #0
    1488:      	cmp	x16, #0x1
    148c:      	b.eq	0x14ac <_stogir.verify.integer-operations-target-structured+0x6c0>
    1490:      	b.lo	0x1498 <_stogir.verify.integer-operations-target-structured+0x6ac>
    1494:      	b	0x14b0 <_stogir.verify.integer-operations-target-structured+0x6c4>
    1498:      	cmp	x16, #0x0
    149c:      	b.eq	0x14a4 <_stogir.verify.integer-operations-target-structured+0x6b8>
    14a0:      	b	0x14b0 <_stogir.verify.integer-operations-target-structured+0x6c4>
    14a4:      	ldr	x1, [sp, #0x320]
    14a8:      	b	0x1cf0 <_stogir.verify.integer-operations-target-structured+0xf04>
    14ac:      	b	0x14b4 <_stogir.verify.integer-operations-target-structured+0x6c8>
    14b0:      	b	0x1d08 <_stogir.verify.integer-operations-target-structured+0xf1c>
    14b4:      	add	x16, sp, #0x180
    14b8:      	ldr	x0, [x16, #0x8]
    14bc:      	ldr	x1, [sp, #0x320]
    14c0:      	ldr	x2, [x1, #0x8]
    14c4:      	mov	x3, x2
    14c8:      	mov	x2, x0
    14cc:      	mov	x0, x19
    14d0:      	mov	x19, x0
    14d4:      	mov	x0, x2
    14d8:      	mov	x2, x3
    14dc:      	cmp	x22, #0x3c
    14e0:      	b.ne	0x22e0 <_stogir.verify.integer-operations-target-structured+0x14f4>
    14e4:      	add	x8, sp, #0x1a0
    14e8:      	str	x1, [sp, #0x320]
    14ec:      	ldr	w1, [sp, #0x340]
    14f0:      	str	x0, [sp, #0x3e8]
    14f4:      	ldr	x0, [sp, #0x2a8]
    14f8:      	str	x2, [sp, #0x3f0]
    14fc:      	bl	0x14fc <_stogir.verify.integer-operations-target-structured+0x710>
		00000000000014fc:  ARM64_RELOC_BRANCH26	_stogir.conditional.validate
    1500:      	add	x16, sp, #0x1a0
    1504:      	ldr	w0, [x16]
    1508:      	lsr	x16, x0, #0
    150c:      	cmp	x16, #0x1
    1510:      	b.eq	0x1530 <_stogir.verify.integer-operations-target-structured+0x744>
    1514:      	b.lo	0x151c <_stogir.verify.integer-operations-target-structured+0x730>
    1518:      	b	0x1534 <_stogir.verify.integer-operations-target-structured+0x748>
    151c:      	cmp	x16, #0x0
    1520:      	b.eq	0x1528 <_stogir.verify.integer-operations-target-structured+0x73c>
    1524:      	b	0x1534 <_stogir.verify.integer-operations-target-structured+0x748>
    1528:      	ldr	x1, [sp, #0x238]
    152c:      	b	0x1d1c <_stogir.verify.integer-operations-target-structured+0xf30>
    1530:      	b	0x1538 <_stogir.verify.integer-operations-target-structured+0x74c>
    1534:      	b	0x1d34 <_stogir.verify.integer-operations-target-structured+0xf48>
    1538:      	add	x16, sp, #0x1a0
    153c:      	ldr	x0, [x16, #0x8]
    1540:      	ldr	x1, [sp, #0x238]
    1544:      	ldr	x2, [x1, #0x8]
    1548:      	mov	x3, x2
    154c:      	mov	x2, x0
    1550:      	mov	x0, x19
    1554:      	mov	x19, x0
    1558:      	mov	x0, x2
    155c:      	mov	x2, x3
    1560:      	cmp	x22, #0x78
    1564:      	b.ne	0x22f4 <_stogir.verify.integer-operations-target-structured+0x1508>
    1568:      	add	x16, sp, #0x20
    156c:      	ldr	w3, [x16]
    1570:      	ubfx	x3, x3, #8, #8
    1574:      	cmp	x3, #0x0
    1578:      	b.ne	0x1d48 <_stogir.verify.integer-operations-target-structured+0xf5c>
    157c:      	add	x16, sp, #0x20
    1580:      	ldr	w3, [x16, #0x8]
    1584:      	sxtw	x3, w3
    1588:      	cmp	x3, #0x0
    158c:      	b.eq	0x1598 <_stogir.verify.integer-operations-target-structured+0x7ac>
    1590:      	ldr	x0, [sp, #0x268]
    1594:      	mov	x2, #0x1f               ; =31
    1598:      	str	x1, [sp, #0x238]
    159c:      	mov	x1, x2
    15a0:      	add	x2, x19, #0x1
    15a4:      	lsr	w2, w2, #0
    15a8:      	sxtw	x2, w2
    15ac:      	mov	x19, x2
    15b0:      	ldr	x2, [sp, #0x348]
    15b4:      	uxth	w2, w2
    15b8:      	mov	w17, #0x8               ; =8
    15bc:      	uxth	w16, w2
    15c0:      	ubfx	w17, w17, #0, #4
    15c4:      	lsr	w2, w16, w17
    15c8:      	uxth	w2, w2
    15cc:      	uxtb	w2, w2
    15d0:      	cmp	x2, #0x0
    15d4:      	b.eq	0x2304 <_stogir.verify.integer-operations-target-structured+0x1518>
    15d8:      	add	x8, sp, #0x1f0
    15dc:      	str	x0, [sp, #0x408]
    15e0:      	ldr	x0, [sp, #0x2a8]
    15e4:      	str	x1, [sp, #0x410]
    15e8:      	ldr	w1, [sp, #0x340]
    15ec:      	str	x20, [sp, #0x260]
    15f0:      	mov	x20, x2
    15f4:      	bl	0x15f4 <_stogir.verify.integer-operations-target-structured+0x808>
		00000000000015f4:  ARM64_RELOC_BRANCH26	_stogir.floating.validate
    15f8:      	add	x16, sp, #0x1f0
    15fc:      	ldr	w0, [x16]
    1600:      	lsr	x16, x0, #0
    1604:      	cmp	x16, #0x1
    1608:      	b.eq	0x1628 <_stogir.verify.integer-operations-target-structured+0x83c>
    160c:      	b.lo	0x1614 <_stogir.verify.integer-operations-target-structured+0x828>
    1610:      	b	0x162c <_stogir.verify.integer-operations-target-structured+0x840>
    1614:      	cmp	x16, #0x0
    1618:      	b.eq	0x1620 <_stogir.verify.integer-operations-target-structured+0x834>
    161c:      	b	0x162c <_stogir.verify.integer-operations-target-structured+0x840>
    1620:      	ldr	x1, [sp, #0x258]
    1624:      	b	0x1e00 <_stogir.verify.integer-operations-target-structured+0x1014>
    1628:      	b	0x1630 <_stogir.verify.integer-operations-target-structured+0x844>
    162c:      	b	0x1e18 <_stogir.verify.integer-operations-target-structured+0x102c>
    1630:      	add	x16, sp, #0x1f0
    1634:      	ldr	x0, [x16, #0x8]
    1638:      	ldr	x1, [sp, #0x258]
    163c:      	ldr	x2, [x1, #0x8]
    1640:      	mov	x3, x2
    1644:      	mov	x2, x0
    1648:      	mov	x0, x19
    164c:      	mov	x19, x0
    1650:      	mov	x0, x2
    1654:      	mov	x2, x3
    1658:      	uxtb	w16, w21
    165c:      	cmp	w16, wzr
    1660:      	b.eq	0x1e2c <_stogir.verify.integer-operations-target-structured+0x1040>
    1664:      	mov	x3, x2
    1668:      	mov	x2, x0
    166c:      	movz	x0, #0x0, lsl #48
    1670:      	cmp	x0, #0x0
    1674:      	b.eq	0x231c <_stogir.verify.integer-operations-target-structured+0x1530>
    1678:      	cmp	x20, #0x0
    167c:      	b.eq	0x1e3c <_stogir.verify.integer-operations-target-structured+0x1050>
    1680:      	movz	x0, #0x0, lsl #48
    1684:      	cmp	x0, #0x0
    1688:      	b.eq	0x2328 <_stogir.verify.integer-operations-target-structured+0x153c>
    168c:      	ldr	x20, [sp, #0x338]
    1690:      	cmp	x20, #0x0
    1694:      	b.eq	0x1e44 <_stogir.verify.integer-operations-target-structured+0x1058>
    1698:      	ldr	x21, [sp, #0x2b0]
    169c:      	mov	x0, #0x1                ; =1
    16a0:      	cmp	x0, #0x0
    16a4:      	b.eq	0x2334 <_stogir.verify.integer-operations-target-structured+0x1548>
    16a8:      	add	x16, sp, #0x210
    16ac:      	str	x16, [sp]
    16b0:      	ldr	x0, [sp, #0x2a8]
    16b4:      	str	x1, [sp, #0x258]
    16b8:      	ldr	w1, [sp, #0x340]
    16bc:      	str	x2, [sp, #0x418]
    16c0:      	str	x3, [sp, #0x420]
    16c4:      	mov	x2, #0x1                ; =1
    16c8:      	bl	0x16c8 <_stogir.verify.integer-operations-target-structured+0x8dc>
		00000000000016c8:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    16cc:      	ldr	x16, [sp]
    16d0:      	str	x0, [x16]
    16d4:      	str	x1, [x16, #0x8]
    16d8:      	add	x16, sp, #0x210
    16dc:      	ldr	x0, [x16]
    16e0:      	add	x16, sp, #0x210
    16e4:      	ldr	x1, [x16, #0x8]
    16e8:      	lsr	w0, w0, #0
    16ec:      	lsr	x16, x0, #0
    16f0:      	cmp	x16, #0x1
    16f4:      	b.eq	0x1710 <_stogir.verify.integer-operations-target-structured+0x924>
    16f8:      	b.lo	0x1700 <_stogir.verify.integer-operations-target-structured+0x914>
    16fc:      	b	0x1714 <_stogir.verify.integer-operations-target-structured+0x928>
    1700:      	cmp	x16, #0x0
    1704:      	b.eq	0x170c <_stogir.verify.integer-operations-target-structured+0x920>
    1708:      	b	0x1714 <_stogir.verify.integer-operations-target-structured+0x928>
    170c:      	b	0x1718 <_stogir.verify.integer-operations-target-structured+0x92c>
    1710:      	b	0x1e70 <_stogir.verify.integer-operations-target-structured+0x1084>
    1714:      	b	0x219c <_stogir.verify.integer-operations-target-structured+0x13b0>
    1718:      	str	x26, [sp, #0x440]
    171c:      	str	x25, [sp, #0x438]
    1720:      	str	x24, [sp, #0x430]
    1724:      	str	x23, [sp, #0x428]
    1728:      	ldr	x0, [sp, #0x280]
    172c:      	mov	x1, #0x17               ; =23
    1730:      	add	x2, x19, #0x1
    1734:      	lsr	w2, w2, #0
    1738:      	sxtw	x2, w2
    173c:      	fmov	d31, x0
    1740:      	mov	x0, x2
    1744:      	mov	x2, x1
    1748:      	fmov	x1, d31
    174c:      	ldr	w3, [sp, #0x330]
    1750:      	sxtw	x3, w3
    1754:      	add	x3, x3, #0x4
    1758:      	asr	x16, x3, #63
    175c:      	lsr	x16, x16, #62
    1760:      	add	x3, x3, x16
    1764:      	asr	x3, x3, #2
    1768:      	ldr	x4, [sp, #0x328]
    176c:      	add	x3, x3, x4
    1770:      	ldr	x8, [sp, #0x2c0]
    1774:      	ldr	x6, [sp, #0x2e0]
    1778:      	ldr	x21, [sp, #0x268]
    177c:      	ldr	x22, [sp, #0x270]
    1780:      	ldr	x23, [sp, #0x278]
    1784:      	ldr	x24, [sp, #0x280]
    1788:      	ldr	x25, [sp, #0x288]
    178c:      	ldr	x26, [sp, #0x290]
    1790:      	ldr	w4, [sp, #0x2d0]
    1794:      	mov	x7, x28
    1798:      	ldr	x28, [sp, #0x2a0]
    179c:      	mov	x9, x27
    17a0:      	ldr	x27, [sp, #0x298]
    17a4:      	ldr	x10, [sp, #0x440]
    17a8:      	ldr	x11, [sp, #0x438]
    17ac:      	ldr	x12, [sp, #0x430]
    17b0:      	ldr	x13, [sp, #0x428]
    17b4:      	ldr	w5, [sp, #0x2d8]
    17b8:      	ldr	x14, [sp, #0x350]
    17bc:      	ldr	x15, [sp, #0x320]
    17c0:      	mov	x19, x0
    17c4:      	ldr	x0, [sp, #0x2a8]
    17c8:      	str	x1, [sp, #0x248]
    17cc:      	ldr	x1, [sp, #0x258]
    17d0:      	mov	x20, x2
    17d4:      	mov	x2, x3
    17d8:      	ldr	x3, [sp, #0x260]
    17dc:      	b	0xf60 <_stogir.verify.integer-operations-target-structured+0x174>
    17e0:      	movz	x3, #0x0, lsl #48
    17e4:      	b	0xfd4 <_stogir.verify.integer-operations-target-structured+0x1e8>
    17e8:      	uxtb	w16, w25
    17ec:      	cmp	w16, wzr
    17f0:      	b.eq	0x180c <_stogir.verify.integer-operations-target-structured+0xa20>
    17f4:      	uxtb	w16, w26
    17f8:      	cmp	w16, wzr
    17fc:      	b.eq	0x180c <_stogir.verify.integer-operations-target-structured+0xa20>
    1800:      	str	x0, [sp, #0x2a8]
    1804:      	mov	x0, #0x1                ; =1
    1808:      	b	0x103c <_stogir.verify.integer-operations-target-structured+0x250>
    180c:      	uxtb	w16, w27
    1810:      	cmp	w16, wzr
    1814:      	b.eq	0x1824 <_stogir.verify.integer-operations-target-structured+0xa38>
    1818:      	str	x0, [sp, #0x2a8]
    181c:      	mov	x0, #0x1                ; =1
    1820:      	b	0x1808 <_stogir.verify.integer-operations-target-structured+0xa1c>
    1824:      	str	x0, [sp, #0x2a8]
    1828:      	ubfx	x0, x28, #0, #8
    182c:      	b	0x1820 <_stogir.verify.integer-operations-target-structured+0xa34>
    1830:      	cmp	x22, #0x20
    1834:      	b.ne	0x1844 <_stogir.verify.integer-operations-target-structured+0xa58>
    1838:      	str	x0, [sp, #0x2b0]
    183c:      	mov	x0, #0x1                ; =1
    1840:      	b	0x104c <_stogir.verify.integer-operations-target-structured+0x260>
    1844:      	cmp	x22, #0x2d
    1848:      	b.ne	0x1858 <_stogir.verify.integer-operations-target-structured+0xa6c>
    184c:      	str	x0, [sp, #0x2b0]
    1850:      	mov	x0, #0x1                ; =1
    1854:      	b	0x1840 <_stogir.verify.integer-operations-target-structured+0xa54>
    1858:      	cmp	x22, #0x36
    185c:      	b.ne	0x186c <_stogir.verify.integer-operations-target-structured+0xa80>
    1860:      	str	x0, [sp, #0x2b0]
    1864:      	mov	x0, #0x1                ; =1
    1868:      	b	0x1854 <_stogir.verify.integer-operations-target-structured+0xa68>
    186c:      	cmp	x22, #0x37
    1870:      	b.ne	0x1880 <_stogir.verify.integer-operations-target-structured+0xa94>
    1874:      	str	x0, [sp, #0x2b0]
    1878:      	mov	x0, #0x1                ; =1
    187c:      	b	0x1868 <_stogir.verify.integer-operations-target-structured+0xa7c>
    1880:      	cmp	x22, #0x38
    1884:      	b.ne	0x1894 <_stogir.verify.integer-operations-target-structured+0xaa8>
    1888:      	str	x0, [sp, #0x2b0]
    188c:      	mov	x0, #0x1                ; =1
    1890:      	b	0x187c <_stogir.verify.integer-operations-target-structured+0xa90>
    1894:      	str	x0, [sp, #0x2b0]
    1898:      	cmp	x22, #0x39
    189c:      	cset	w0, eq
    18a0:      	ubfx	x0, x0, #0, #8
    18a4:      	b	0x1890 <_stogir.verify.integer-operations-target-structured+0xaa4>
    18a8:      	uxtb	w16, w1
    18ac:      	cmp	w16, wzr
    18b0:      	b.ne	0x10f0 <_stogir.verify.integer-operations-target-structured+0x304>
    18b4:      	str	x0, [sp, #0x348]
    18b8:      	str	x21, [sp, #0x350]
    18bc:      	mov	w21, w1
    18c0:      	ldr	x0, [sp, #0x248]
    18c4:      	ldr	x1, [sp, #0x2c8]
    18c8:      	b	0x1168 <_stogir.verify.integer-operations-target-structured+0x37c>
    18cc:      	add	x0, x19, #0x1
    18d0:      	lsr	w0, w0, #0
    18d4:      	sxtw	x0, w0
    18d8:      	ldr	x1, [sp, #0x248]
    18dc:      	ldr	x2, [sp, #0x2c8]
    18e0:      	b	0x115c <_stogir.verify.integer-operations-target-structured+0x370>
    18e4:      	mov	x2, x0
    18e8:      	mov	x0, #0x1                ; =1
    18ec:      	b	0x1184 <_stogir.verify.integer-operations-target-structured+0x398>
    18f0:      	mov	x2, x1
    18f4:      	mov	x1, x0
    18f8:      	movz	x0, #0x0, lsl #48
    18fc:      	b	0x1190 <_stogir.verify.integer-operations-target-structured+0x3a4>
    1900:      	add	x0, x19, #0x1
    1904:      	lsr	w0, w0, #0
    1908:      	sxtw	x0, w0
    190c:      	ldr	x1, [sp, #0x358]
    1910:      	ldr	x2, [sp, #0x360]
    1914:      	b	0x11fc <_stogir.verify.integer-operations-target-structured+0x410>
    1918:      	brk	#0
    191c:      	b	0x1918 <_stogir.verify.integer-operations-target-structured+0xb2c>
    1920:      	ldr	x0, [sp, #0x358]
    1924:      	ldr	x1, [sp, #0x360]
    1928:      	b	0x1208 <_stogir.verify.integer-operations-target-structured+0x41c>
    192c:      	cmp	x22, #0x1e
    1930:      	cset	w2, eq
    1934:      	ubfx	x2, x2, #0, #8
    1938:      	fmov	d31, x0
    193c:      	mov	x0, x2
    1940:      	mov	x2, x1
    1944:      	fmov	x1, d31
    1948:      	b	0x121c <_stogir.verify.integer-operations-target-structured+0x430>
    194c:      	mov	x0, #0x1                ; =1
    1950:      	b	0x123c <_stogir.verify.integer-operations-target-structured+0x450>
    1954:      	movz	x0, #0x0, lsl #48
    1958:      	b	0x123c <_stogir.verify.integer-operations-target-structured+0x450>
    195c:      	add	x16, sp, #0x70
    1960:      	ldr	x0, [x16, #0x8]
    1964:      	add	x16, sp, #0x20
    1968:      	ldr	w1, [x16, #0xc]
    196c:      	sxtw	x1, w1
    1970:      	cmp	x1, #0x0
    1974:      	b.ge	0x1998 <_stogir.verify.integer-operations-target-structured+0xbac>
    1978:      	ldr	x1, [sp, #0x368]
    197c:      	ldr	x2, [sp, #0x370]
    1980:      	mov	x0, #0x1                ; =1
    1984:      	cmp	x0, #0x0
    1988:      	b.eq	0x1a04 <_stogir.verify.integer-operations-target-structured+0xc18>
    198c:      	ldr	x0, [sp, #0x250]
    1990:      	mov	x1, #0x2d               ; =45
    1994:      	b	0x12a4 <_stogir.verify.integer-operations-target-structured+0x4b8>
    1998:      	uxtb	w0, w0
    199c:      	cmp	x0, #0x83
    19a0:      	b.ge	0x19f4 <_stogir.verify.integer-operations-target-structured+0xc08>
    19a4:      	add	x1, x0, x20
    19a8:      	ldrb	w1, [x1]
    19ac:      	uxtb	w1, w1
    19b0:      	and	x1, x1, #0x2
    19b4:      	uxtb	w1, w1
    19b8:      	cmp	x1, #0x0
    19bc:      	cset	w1, eq
    19c0:      	uxtb	w16, w1
    19c4:      	cmp	w16, wzr
    19c8:      	cset	x1, eq
    19cc:      	cmp	x1, #0x0
    19d0:      	b.ne	0x19fc <_stogir.verify.integer-operations-target-structured+0xc10>
    19d4:      	cmp	x0, #0x65
    19d8:      	b.eq	0x19fc <_stogir.verify.integer-operations-target-structured+0xc10>
    19dc:      	cmp	x0, #0x66
    19e0:      	b.eq	0x19fc <_stogir.verify.integer-operations-target-structured+0xc10>
    19e4:      	mov	x0, #0x1                ; =1
    19e8:      	ldr	x1, [sp, #0x368]
    19ec:      	ldr	x2, [sp, #0x370]
    19f0:      	b	0x1984 <_stogir.verify.integer-operations-target-structured+0xb98>
    19f4:      	movz	x1, #0x0, lsl #48
    19f8:      	b	0x19ac <_stogir.verify.integer-operations-target-structured+0xbc0>
    19fc:      	movz	x0, #0x0, lsl #48
    1a00:      	b	0x19e8 <_stogir.verify.integer-operations-target-structured+0xbfc>
    1a04:      	mov	x0, x1
    1a08:      	mov	x1, x2
    1a0c:      	b	0x1994 <_stogir.verify.integer-operations-target-structured+0xba8>
    1a10:      	brk	#0
    1a14:      	b	0x1a10 <_stogir.verify.integer-operations-target-structured+0xc24>
    1a18:      	ldr	x0, [sp, #0x368]
    1a1c:      	ldr	x1, [sp, #0x370]
    1a20:      	b	0x12a4 <_stogir.verify.integer-operations-target-structured+0x4b8>
    1a24:      	uxtb	w16, w2
    1a28:      	cmp	w16, wzr
    1a2c:      	b.ne	0x12bc <_stogir.verify.integer-operations-target-structured+0x4d0>
    1a30:      	b	0x1338 <_stogir.verify.integer-operations-target-structured+0x54c>
    1a34:      	add	x8, sp, #0xc0
    1a38:      	ldr	x0, [sp, #0x2a8]
    1a3c:      	ldr	w1, [sp, #0x340]
    1a40:      	bl	0x1a40 <_stogir.verify.integer-operations-target-structured+0xc54>
		0000000000001a40:  ARM64_RELOC_BRANCH26	_stogir.checked.validate
    1a44:      	add	x16, sp, #0xc0
    1a48:      	ldr	x0, [x16]
    1a4c:      	add	x16, sp, #0xc0
    1a50:      	ldr	x1, [x16, #0x8]
    1a54:      	add	x16, sp, #0xc0
    1a58:      	ldr	x2, [x16, #0x10]
    1a5c:      	b	0x12f8 <_stogir.verify.integer-operations-target-structured+0x50c>
    1a60:      	add	x0, x19, #0x1
    1a64:      	lsr	w0, w0, #0
    1a68:      	sxtw	x0, w0
    1a6c:      	ldr	x1, [sp, #0x378]
    1a70:      	ldr	x2, [sp, #0x380]
    1a74:      	b	0x132c <_stogir.verify.integer-operations-target-structured+0x540>
    1a78:      	add	x0, x19, #0x1
    1a7c:      	lsr	w0, w0, #0
    1a80:      	sxtw	x0, w0
    1a84:      	ldr	x1, [sp, #0x388]
    1a88:      	ldr	x2, [sp, #0x390]
    1a8c:      	b	0x13ac <_stogir.verify.integer-operations-target-structured+0x5c0>
    1a90:      	brk	#0
    1a94:      	b	0x1a90 <_stogir.verify.integer-operations-target-structured+0xca4>
    1a98:      	ldr	x0, [sp, #0x388]
    1a9c:      	ldr	x1, [sp, #0x390]
    1aa0:      	b	0x13b8 <_stogir.verify.integer-operations-target-structured+0x5cc>
    1aa4:      	add	x8, sp, #0x100
    1aa8:      	str	x0, [sp, #0x398]
    1aac:      	ldr	x0, [sp, #0x2a8]
    1ab0:      	str	x1, [sp, #0x3a0]
    1ab4:      	ldr	w1, [sp, #0x340]
    1ab8:      	bl	0x1ab8 <_stogir.verify.integer-operations-target-structured+0xccc>
		0000000000001ab8:  ARM64_RELOC_BRANCH26	_stogir.terminal.validate
    1abc:      	add	x16, sp, #0x100
    1ac0:      	ldr	w0, [x16]
    1ac4:      	lsr	x16, x0, #0
    1ac8:      	cmp	x16, #0x1
    1acc:      	b.eq	0x1ae8 <_stogir.verify.integer-operations-target-structured+0xcfc>
    1ad0:      	b.lo	0x1ad8 <_stogir.verify.integer-operations-target-structured+0xcec>
    1ad4:      	b	0x1aec <_stogir.verify.integer-operations-target-structured+0xd00>
    1ad8:      	cmp	x16, #0x0
    1adc:      	b.eq	0x1ae4 <_stogir.verify.integer-operations-target-structured+0xcf8>
    1ae0:      	b	0x1aec <_stogir.verify.integer-operations-target-structured+0xd00>
    1ae4:      	b	0x1b18 <_stogir.verify.integer-operations-target-structured+0xd2c>
    1ae8:      	b	0x1af0 <_stogir.verify.integer-operations-target-structured+0xd04>
    1aec:      	b	0x21bc <_stogir.verify.integer-operations-target-structured+0x13d0>
    1af0:      	add	x16, sp, #0x100
    1af4:      	ldr	x0, [x16, #0x8]
    1af8:      	ldr	x1, [x25, #0x8]
    1afc:      	mov	x2, x1
    1b00:      	mov	x1, x0
    1b04:      	mov	x0, x19
    1b08:      	mov	x19, x0
    1b0c:      	mov	x0, x1
    1b10:      	mov	x1, x2
    1b14:      	b	0x13c8 <_stogir.verify.integer-operations-target-structured+0x5dc>
    1b18:      	add	x0, x19, #0x1
    1b1c:      	lsr	w0, w0, #0
    1b20:      	sxtw	x0, w0
    1b24:      	ldr	x1, [sp, #0x398]
    1b28:      	ldr	x2, [sp, #0x3a0]
    1b2c:      	b	0x1b08 <_stogir.verify.integer-operations-target-structured+0xd1c>
    1b30:      	add	x8, sp, #0x120
    1b34:      	str	x0, [sp, #0x3a8]
    1b38:      	ldr	x0, [sp, #0x2a8]
    1b3c:      	str	x1, [sp, #0x3b0]
    1b40:      	ldr	w1, [sp, #0x340]
    1b44:      	bl	0x1b44 <_stogir.verify.integer-operations-target-structured+0xd58>
		0000000000001b44:  ARM64_RELOC_BRANCH26	_stogir.switch.validate
    1b48:      	add	x16, sp, #0x120
    1b4c:      	ldr	w0, [x16]
    1b50:      	lsr	x16, x0, #0
    1b54:      	cmp	x16, #0x1
    1b58:      	b.eq	0x1b74 <_stogir.verify.integer-operations-target-structured+0xd88>
    1b5c:      	b.lo	0x1b64 <_stogir.verify.integer-operations-target-structured+0xd78>
    1b60:      	b	0x1b78 <_stogir.verify.integer-operations-target-structured+0xd8c>
    1b64:      	cmp	x16, #0x0
    1b68:      	b.eq	0x1b70 <_stogir.verify.integer-operations-target-structured+0xd84>
    1b6c:      	b	0x1b78 <_stogir.verify.integer-operations-target-structured+0xd8c>
    1b70:      	b	0x1ba4 <_stogir.verify.integer-operations-target-structured+0xdb8>
    1b74:      	b	0x1b7c <_stogir.verify.integer-operations-target-structured+0xd90>
    1b78:      	b	0x1bbc <_stogir.verify.integer-operations-target-structured+0xdd0>
    1b7c:      	add	x16, sp, #0x120
    1b80:      	ldr	x0, [x16, #0x8]
    1b84:      	ldr	x1, [x24, #0x8]
    1b88:      	mov	x2, x1
    1b8c:      	mov	x1, x0
    1b90:      	mov	x0, x19
    1b94:      	mov	x19, x0
    1b98:      	mov	x0, x1
    1b9c:      	mov	x1, x2
    1ba0:      	b	0x13f0 <_stogir.verify.integer-operations-target-structured+0x604>
    1ba4:      	add	x0, x19, #0x1
    1ba8:      	lsr	w0, w0, #0
    1bac:      	sxtw	x0, w0
    1bb0:      	ldr	x1, [sp, #0x3a8]
    1bb4:      	ldr	x2, [sp, #0x3b0]
    1bb8:      	b	0x1b94 <_stogir.verify.integer-operations-target-structured+0xda8>
    1bbc:      	brk	#0
    1bc0:      	b	0x1bbc <_stogir.verify.integer-operations-target-structured+0xdd0>
    1bc4:      	add	x8, sp, #0x140
    1bc8:      	str	x0, [sp, #0x3b8]
    1bcc:      	ldr	x0, [sp, #0x2a8]
    1bd0:      	str	x1, [sp, #0x3c0]
    1bd4:      	ldr	w1, [sp, #0x340]
    1bd8:      	bl	0x1bd8 <_stogir.verify.integer-operations-target-structured+0xdec>
		0000000000001bd8:  ARM64_RELOC_BRANCH26	_stogir.stack.validate
    1bdc:      	add	x16, sp, #0x140
    1be0:      	ldr	w0, [x16]
    1be4:      	lsr	x16, x0, #0
    1be8:      	cmp	x16, #0x1
    1bec:      	b.eq	0x1c08 <_stogir.verify.integer-operations-target-structured+0xe1c>
    1bf0:      	b.lo	0x1bf8 <_stogir.verify.integer-operations-target-structured+0xe0c>
    1bf4:      	b	0x1c0c <_stogir.verify.integer-operations-target-structured+0xe20>
    1bf8:      	cmp	x16, #0x0
    1bfc:      	b.eq	0x1c04 <_stogir.verify.integer-operations-target-structured+0xe18>
    1c00:      	b	0x1c0c <_stogir.verify.integer-operations-target-structured+0xe20>
    1c04:      	b	0x1c38 <_stogir.verify.integer-operations-target-structured+0xe4c>
    1c08:      	b	0x1c10 <_stogir.verify.integer-operations-target-structured+0xe24>
    1c0c:      	b	0x21b4 <_stogir.verify.integer-operations-target-structured+0x13c8>
    1c10:      	add	x16, sp, #0x140
    1c14:      	ldr	x0, [x16, #0x8]
    1c18:      	ldr	x1, [x23, #0x8]
    1c1c:      	mov	x2, x1
    1c20:      	mov	x1, x0
    1c24:      	mov	x0, x19
    1c28:      	mov	x19, x0
    1c2c:      	mov	x0, x1
    1c30:      	mov	x1, x2
    1c34:      	b	0x1418 <_stogir.verify.integer-operations-target-structured+0x62c>
    1c38:      	add	x0, x19, #0x1
    1c3c:      	lsr	w0, w0, #0
    1c40:      	sxtw	x0, w0
    1c44:      	ldr	x1, [sp, #0x3b8]
    1c48:      	ldr	x2, [sp, #0x3c0]
    1c4c:      	b	0x1c28 <_stogir.verify.integer-operations-target-structured+0xe3c>
    1c50:      	add	x8, sp, #0x160
    1c54:      	ldr	w2, [sp, #0x2d8]
    1c58:      	str	x0, [sp, #0x3c8]
    1c5c:      	ldr	x0, [sp, #0x2a8]
    1c60:      	str	x1, [sp, #0x3d0]
    1c64:      	ldr	w1, [sp, #0x340]
    1c68:      	bl	0x1c68 <_stogir.verify.integer-operations-target-structured+0xe7c>
		0000000000001c68:  ARM64_RELOC_BRANCH26	_stogir.locals.validate
    1c6c:      	add	x16, sp, #0x160
    1c70:      	ldr	w0, [x16]
    1c74:      	lsr	x16, x0, #0
    1c78:      	cmp	x16, #0x1
    1c7c:      	b.eq	0x1c9c <_stogir.verify.integer-operations-target-structured+0xeb0>
    1c80:      	b.lo	0x1c88 <_stogir.verify.integer-operations-target-structured+0xe9c>
    1c84:      	b	0x1ca0 <_stogir.verify.integer-operations-target-structured+0xeb4>
    1c88:      	cmp	x16, #0x0
    1c8c:      	b.eq	0x1c94 <_stogir.verify.integer-operations-target-structured+0xea8>
    1c90:      	b	0x1ca0 <_stogir.verify.integer-operations-target-structured+0xeb4>
    1c94:      	ldr	x1, [sp, #0x350]
    1c98:      	b	0x1cd0 <_stogir.verify.integer-operations-target-structured+0xee4>
    1c9c:      	b	0x1ca4 <_stogir.verify.integer-operations-target-structured+0xeb8>
    1ca0:      	b	0x1ce8 <_stogir.verify.integer-operations-target-structured+0xefc>
    1ca4:      	add	x16, sp, #0x160
    1ca8:      	ldr	x0, [x16, #0x8]
    1cac:      	ldr	x1, [sp, #0x350]
    1cb0:      	ldr	x2, [x1, #0x8]
    1cb4:      	mov	x3, x2
    1cb8:      	mov	x2, x0
    1cbc:      	mov	x0, x19
    1cc0:      	mov	x19, x0
    1cc4:      	mov	x0, x2
    1cc8:      	mov	x2, x3
    1ccc:      	b	0x144c <_stogir.verify.integer-operations-target-structured+0x660>
    1cd0:      	add	x0, x19, #0x1
    1cd4:      	lsr	w0, w0, #0
    1cd8:      	sxtw	x0, w0
    1cdc:      	ldr	x2, [sp, #0x3c8]
    1ce0:      	ldr	x3, [sp, #0x3d0]
    1ce4:      	b	0x1cc0 <_stogir.verify.integer-operations-target-structured+0xed4>
    1ce8:      	brk	#0
    1cec:      	b	0x1ce8 <_stogir.verify.integer-operations-target-structured+0xefc>
    1cf0:      	add	x0, x19, #0x1
    1cf4:      	lsr	w0, w0, #0
    1cf8:      	sxtw	x0, w0
    1cfc:      	ldr	x2, [sp, #0x3d8]
    1d00:      	ldr	x3, [sp, #0x3e0]
    1d04:      	b	0x14d0 <_stogir.verify.integer-operations-target-structured+0x6e4>
    1d08:      	brk	#0
    1d0c:      	b	0x1d08 <_stogir.verify.integer-operations-target-structured+0xf1c>
    1d10:      	ldr	x0, [sp, #0x3d8]
    1d14:      	ldr	x2, [sp, #0x3e0]
    1d18:      	b	0x14dc <_stogir.verify.integer-operations-target-structured+0x6f0>
    1d1c:      	add	x0, x19, #0x1
    1d20:      	lsr	w0, w0, #0
    1d24:      	sxtw	x0, w0
    1d28:      	ldr	x2, [sp, #0x3e8]
    1d2c:      	ldr	x3, [sp, #0x3f0]
    1d30:      	b	0x1554 <_stogir.verify.integer-operations-target-structured+0x768>
    1d34:      	brk	#0
    1d38:      	b	0x1d34 <_stogir.verify.integer-operations-target-structured+0xf48>
    1d3c:      	ldr	x0, [sp, #0x3e8]
    1d40:      	ldr	x2, [sp, #0x3f0]
    1d44:      	b	0x1560 <_stogir.verify.integer-operations-target-structured+0x774>
    1d48:      	add	x16, sp, #0x20
    1d4c:      	ldr	w3, [x16, #0x8]
    1d50:      	lsr	w3, w3, #0
    1d54:      	add	x8, sp, #0x1c0
    1d58:      	str	x1, [sp, #0x238]
    1d5c:      	mov	w1, w3
    1d60:      	str	x0, [sp, #0x3f8]
    1d64:      	ldr	x0, [sp, #0x2a8]
    1d68:      	str	x2, [sp, #0x400]
    1d6c:      	bl	0x1d6c <_stogir.verify.integer-operations-target-structured+0xf80>
		0000000000001d6c:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    1d70:      	add	x16, sp, #0x1c0
    1d74:      	ldr	w0, [x16]
    1d78:      	lsr	x16, x0, #0
    1d7c:      	cmp	x16, #0x1
    1d80:      	b.eq	0x1d9c <_stogir.verify.integer-operations-target-structured+0xfb0>
    1d84:      	b.lo	0x1d8c <_stogir.verify.integer-operations-target-structured+0xfa0>
    1d88:      	b	0x1da0 <_stogir.verify.integer-operations-target-structured+0xfb4>
    1d8c:      	cmp	x16, #0x0
    1d90:      	b.eq	0x1d98 <_stogir.verify.integer-operations-target-structured+0xfac>
    1d94:      	b	0x1da0 <_stogir.verify.integer-operations-target-structured+0xfb4>
    1d98:      	b	0x1da4 <_stogir.verify.integer-operations-target-structured+0xfb8>
    1d9c:      	b	0x1db0 <_stogir.verify.integer-operations-target-structured+0xfc4>
    1da0:      	b	0x1dec <_stogir.verify.integer-operations-target-structured+0x1000>
    1da4:      	ldr	x0, [sp, #0x270]
    1da8:      	mov	x1, #0x14               ; =20
    1dac:      	b	0x15a0 <_stogir.verify.integer-operations-target-structured+0x7b4>
    1db0:      	add	x16, sp, #0x1c0
    1db4:      	ldr	x0, [x16, #0x8]
    1db8:      	add	x16, sp, #0x20
    1dbc:      	ldr	w1, [x16]
    1dc0:      	lsr	w0, w0, #0
    1dc4:      	ubfx	x1, x1, #8, #8
    1dc8:      	ubfx	x0, x0, #8, #8
    1dcc:      	cmp	x0, x1
    1dd0:      	b.ne	0x1de0 <_stogir.verify.integer-operations-target-structured+0xff4>
    1dd4:      	ldr	x0, [sp, #0x3f8]
    1dd8:      	ldr	x1, [sp, #0x400]
    1ddc:      	b	0x1dac <_stogir.verify.integer-operations-target-structured+0xfc0>
    1de0:      	ldr	x0, [sp, #0x278]
    1de4:      	mov	x1, #0x1a               ; =26
    1de8:      	b	0x1ddc <_stogir.verify.integer-operations-target-structured+0xff0>
    1dec:      	brk	#0
    1df0:      	b	0x1dec <_stogir.verify.integer-operations-target-structured+0x1000>
    1df4:      	ldr	x0, [sp, #0x3f8]
    1df8:      	ldr	x1, [sp, #0x400]
    1dfc:      	b	0x15b0 <_stogir.verify.integer-operations-target-structured+0x7c4>
    1e00:      	add	x0, x19, #0x1
    1e04:      	lsr	w0, w0, #0
    1e08:      	sxtw	x0, w0
    1e0c:      	ldr	x2, [sp, #0x408]
    1e10:      	ldr	x3, [sp, #0x410]
    1e14:      	b	0x164c <_stogir.verify.integer-operations-target-structured+0x860>
    1e18:      	brk	#0
    1e1c:      	b	0x1e18 <_stogir.verify.integer-operations-target-structured+0x102c>
    1e20:      	ldr	x0, [sp, #0x408]
    1e24:      	ldr	x2, [sp, #0x410]
    1e28:      	b	0x1658 <_stogir.verify.integer-operations-target-structured+0x86c>
    1e2c:      	mov	x3, x2
    1e30:      	mov	x2, x0
    1e34:      	mov	x0, #0x1                ; =1
    1e38:      	b	0x1670 <_stogir.verify.integer-operations-target-structured+0x884>
    1e3c:      	mov	x0, #0x1                ; =1
    1e40:      	b	0x1684 <_stogir.verify.integer-operations-target-structured+0x898>
    1e44:      	ldr	x21, [sp, #0x2b0]
    1e48:      	cmp	x21, #0x0
    1e4c:      	b.eq	0x1e58 <_stogir.verify.integer-operations-target-structured+0x106c>
    1e50:      	mov	x0, #0x1                ; =1
    1e54:      	b	0x16a0 <_stogir.verify.integer-operations-target-structured+0x8b4>
    1e58:      	ldr	x0, [sp, #0x2b8]
    1e5c:      	b	0x1e54 <_stogir.verify.integer-operations-target-structured+0x1068>
    1e60:      	movz	x0, #0x0, lsl #48
    1e64:      	b	0x16a0 <_stogir.verify.integer-operations-target-structured+0x8b4>
    1e68:      	movz	x0, #0x0, lsl #48
    1e6c:      	b	0x16a0 <_stogir.verify.integer-operations-target-structured+0x8b4>
    1e70:      	lsr	w1, w1, #0
    1e74:      	lsr	w1, w1, #0
    1e78:      	ldr	x0, [sp, #0x2a8]
    1e7c:      	bl	0x1e7c <_stogir.verify.integer-operations-target-structured+0x1090>
		0000000000001e7c:  ARM64_RELOC_BRANCH26	_stogir.graph.borrow-node
    1e80:      	cmp	x0, #0x0
    1e84:      	b.ne	0x1ea4 <_stogir.verify.integer-operations-target-structured+0x10b8>
    1e88:      	str	x26, [sp, #0x440]
    1e8c:      	str	x25, [sp, #0x438]
    1e90:      	str	x24, [sp, #0x430]
    1e94:      	str	x23, [sp, #0x428]
    1e98:      	ldr	x0, [sp, #0x280]
    1e9c:      	mov	x1, #0x17               ; =23
    1ea0:      	b	0x1730 <_stogir.verify.integer-operations-target-structured+0x944>
    1ea4:      	ldr	w0, [x0]
    1ea8:      	add	x16, sp, #0x20
    1eac:      	ldr	w1, [x16]
    1eb0:      	ubfx	x0, x0, #8, #8
    1eb4:      	orr	x2, x0, xzr
    1eb8:      	ubfx	x1, x1, #8, #8
    1ebc:      	cmp	x1, #0x6
    1ec0:      	b.ne	0x2028 <_stogir.verify.integer-operations-target-structured+0x123c>
    1ec4:      	cmp	x2, #0x6
    1ec8:      	b.ne	0x2020 <_stogir.verify.integer-operations-target-structured+0x1234>
    1ecc:      	cmp	x22, #0x1a
    1ed0:      	b.ne	0x2010 <_stogir.verify.integer-operations-target-structured+0x1224>
    1ed4:      	mov	x1, #0x1                ; =1
    1ed8:      	cmp	x2, #0x1
    1edc:      	cset	w3, ge
    1ee0:      	uxtb	w16, w3
    1ee4:      	cmp	w16, wzr
    1ee8:      	b.eq	0x2354 <_stogir.verify.integer-operations-target-structured+0x1568>
    1eec:      	cmp	x2, #0xb
    1ef0:      	cset	w4, le
    1ef4:      	uxtb	w16, w4
    1ef8:      	cmp	w16, wzr
    1efc:      	b.eq	0x2370 <_stogir.verify.integer-operations-target-structured+0x1584>
    1f00:      	ldr	x5, [sp, #0x2b8]
    1f04:      	cmp	x5, #0x0
    1f08:      	b.eq	0x238c <_stogir.verify.integer-operations-target-structured+0x15a0>
    1f0c:      	ldr	w5, [sp, #0x318]
    1f10:      	lsr	w5, w5, #0
    1f14:      	lsr	w0, w0, #0
    1f18:      	str	x23, [sp, #0x428]
    1f1c:      	mov	x23, x2
    1f20:      	str	x24, [sp, #0x430]
    1f24:      	mov	x24, x1
    1f28:      	mov	w1, w0
    1f2c:      	mov	w0, w5
    1f30:      	str	x25, [sp, #0x438]
    1f34:      	mov	w25, w3
    1f38:      	str	x26, [sp, #0x440]
    1f3c:      	mov	w26, w4
    1f40:      	bl	0x1f40 <_stogir.verify.integer-operations-target-structured+0x1154>
		0000000000001f40:  ARM64_RELOC_BRANCH26	_stogir.integer-unary.valid-type?
    1f44:      	cmp	x0, #0x0
    1f48:      	b.ne	0x2030 <_stogir.verify.integer-operations-target-structured+0x1244>
    1f4c:      	ldr	x0, [sp, #0x288]
    1f50:      	mov	x1, #0x1c               ; =28
    1f54:      	add	x16, sp, #0x20
    1f58:      	ldr	w2, [x16]
    1f5c:      	cmp	x20, #0x0
    1f60:      	b.eq	0x2100 <_stogir.verify.integer-operations-target-structured+0x1314>
    1f64:      	mov	x3, x0
    1f68:      	mov	x0, #0x1                ; =1
    1f6c:      	lsr	w0, w0, #0
    1f70:      	ubfx	x2, x2, #8, #8
    1f74:      	sxtw	x0, w0
    1f78:      	cmp	x2, x0
    1f7c:      	b.ne	0x210c <_stogir.verify.integer-operations-target-structured+0x1320>
    1f80:      	mov	x0, x3
    1f84:      	mov	x22, x1
    1f88:      	cmp	x20, #0x0
    1f8c:      	b.eq	0x2118 <_stogir.verify.integer-operations-target-structured+0x132c>
    1f90:      	mov	x20, x0
    1f94:      	mov	x0, #0x1                ; =1
    1f98:      	cmp	x0, #0x0
    1f9c:      	b.eq	0x2190 <_stogir.verify.integer-operations-target-structured+0x13a4>
    1fa0:      	add	x16, sp, #0x220
    1fa4:      	str	x16, [sp]
    1fa8:      	ldr	x0, [sp, #0x2a8]
    1fac:      	ldr	w1, [sp, #0x340]
    1fb0:      	mov	x2, #0x2                ; =2
    1fb4:      	bl	0x1fb4 <_stogir.verify.integer-operations-target-structured+0x11c8>
		0000000000001fb4:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    1fb8:      	ldr	x16, [sp]
    1fbc:      	str	x0, [x16]
    1fc0:      	str	x1, [x16, #0x8]
    1fc4:      	add	x16, sp, #0x220
    1fc8:      	ldr	x0, [x16]
    1fcc:      	add	x16, sp, #0x220
    1fd0:      	ldr	x1, [x16, #0x8]
    1fd4:      	lsr	w0, w0, #0
    1fd8:      	lsr	x16, x0, #0
    1fdc:      	cmp	x16, #0x1
    1fe0:      	b.eq	0x1ffc <_stogir.verify.integer-operations-target-structured+0x1210>
    1fe4:      	b.lo	0x1fec <_stogir.verify.integer-operations-target-structured+0x1200>
    1fe8:      	b	0x2000 <_stogir.verify.integer-operations-target-structured+0x1214>
    1fec:      	cmp	x16, #0x0
    1ff0:      	b.eq	0x1ff8 <_stogir.verify.integer-operations-target-structured+0x120c>
    1ff4:      	b	0x2000 <_stogir.verify.integer-operations-target-structured+0x1214>
    1ff8:      	b	0x2004 <_stogir.verify.integer-operations-target-structured+0x1218>
    1ffc:      	b	0x2124 <_stogir.verify.integer-operations-target-structured+0x1338>
    2000:      	b	0x2188 <_stogir.verify.integer-operations-target-structured+0x139c>
    2004:      	ldr	x0, [sp, #0x298]
    2008:      	mov	x1, #0x1d               ; =29
    200c:      	b	0x1ea0 <_stogir.verify.integer-operations-target-structured+0x10b4>
    2010:      	cmp	x22, #0x1b
    2014:      	cset	w1, eq
    2018:      	ubfx	x1, x1, #0, #8
    201c:      	b	0x1ed8 <_stogir.verify.integer-operations-target-structured+0x10ec>
    2020:      	movz	x1, #0x0, lsl #48
    2024:      	b	0x1ed8 <_stogir.verify.integer-operations-target-structured+0x10ec>
    2028:      	movz	x1, #0x0, lsl #48
    202c:      	b	0x1ed8 <_stogir.verify.integer-operations-target-structured+0x10ec>
    2030:      	cmp	x21, #0x0
    2034:      	b.eq	0x20a8 <_stogir.verify.integer-operations-target-structured+0x12bc>
    2038:      	ldr	w0, [sp, #0x310]
    203c:      	uxtb	w16, w0
    2040:      	cmp	w16, wzr
    2044:      	b.eq	0x20b4 <_stogir.verify.integer-operations-target-structured+0x12c8>
    2048:      	ldr	w0, [sp, #0x308]
    204c:      	uxtb	w16, w0
    2050:      	cmp	w16, wzr
    2054:      	b.eq	0x20b4 <_stogir.verify.integer-operations-target-structured+0x12c8>
    2058:      	ldr	w0, [sp, #0x2f0]
    205c:      	uxtb	w16, w25
    2060:      	cmp	w16, wzr
    2064:      	b.eq	0x1f4c <_stogir.verify.integer-operations-target-structured+0x1160>
    2068:      	uxtb	w16, w26
    206c:      	cmp	w16, wzr
    2070:      	b.eq	0x1f4c <_stogir.verify.integer-operations-target-structured+0x1160>
    2074:      	cmp	x23, #0x1
    2078:      	b.ne	0x20a8 <_stogir.verify.integer-operations-target-structured+0x12bc>
    207c:      	cmp	x22, #0x2e
    2080:      	b.eq	0x20a8 <_stogir.verify.integer-operations-target-structured+0x12bc>
    2084:      	cmp	x22, #0x2f
    2088:      	b.eq	0x20a8 <_stogir.verify.integer-operations-target-structured+0x12bc>
    208c:      	cmp	x22, #0x30
    2090:      	b.eq	0x20a8 <_stogir.verify.integer-operations-target-structured+0x12bc>
    2094:      	uxtb	w16, w0
    2098:      	cmp	w16, wzr
    209c:      	b.ne	0x20a8 <_stogir.verify.integer-operations-target-structured+0x12bc>
    20a0:      	cmp	x22, #0x3b
    20a4:      	b.ne	0x1f4c <_stogir.verify.integer-operations-target-structured+0x1160>
    20a8:      	ldr	x0, [sp, #0x418]
    20ac:      	ldr	x1, [sp, #0x420]
    20b0:      	b	0x1f54 <_stogir.verify.integer-operations-target-structured+0x1168>
    20b4:      	ldr	w0, [sp, #0x300]
    20b8:      	uxtb	w16, w0
    20bc:      	cmp	w16, wzr
    20c0:      	b.eq	0x20dc <_stogir.verify.integer-operations-target-structured+0x12f0>
    20c4:      	ldr	w0, [sp, #0x2f8]
    20c8:      	uxtb	w16, w0
    20cc:      	cmp	w16, wzr
    20d0:      	b.eq	0x20dc <_stogir.verify.integer-operations-target-structured+0x12f0>
    20d4:      	ldr	w0, [sp, #0x2f0]
    20d8:      	b	0x205c <_stogir.verify.integer-operations-target-structured+0x1270>
    20dc:      	ldr	w0, [sp, #0x2f0]
    20e0:      	uxtb	w16, w0
    20e4:      	cmp	w16, wzr
    20e8:      	b.ne	0x205c <_stogir.verify.integer-operations-target-structured+0x1270>
    20ec:      	ldr	w1, [sp, #0x2e8]
    20f0:      	uxtb	w16, w1
    20f4:      	cmp	w16, wzr
    20f8:      	b.ne	0x205c <_stogir.verify.integer-operations-target-structured+0x1270>
    20fc:      	b	0x1f4c <_stogir.verify.integer-operations-target-structured+0x1160>
    2100:      	mov	x3, x0
    2104:      	mov	x0, x23
    2108:      	b	0x1f6c <_stogir.verify.integer-operations-target-structured+0x1180>
    210c:      	ldr	x0, [sp, #0x290]
    2110:      	mov	x22, #0x26              ; =38
    2114:      	b	0x1f88 <_stogir.verify.integer-operations-target-structured+0x119c>
    2118:      	mov	x20, x0
    211c:      	mov	x0, x21
    2120:      	b	0x1f98 <_stogir.verify.integer-operations-target-structured+0x11ac>
    2124:      	lsr	w1, w1, #0
    2128:      	lsr	w1, w1, #0
    212c:      	ldr	x0, [sp, #0x2a8]
    2130:      	bl	0x2130 <_stogir.verify.integer-operations-target-structured+0x1344>
		0000000000002130:  ARM64_RELOC_BRANCH26	_stogir.graph.borrow-node
    2134:      	cmp	x0, #0x0
    2138:      	b.ne	0x2148 <_stogir.verify.integer-operations-target-structured+0x135c>
    213c:      	ldr	x0, [sp, #0x298]
    2140:      	mov	x1, #0x1d               ; =29
    2144:      	b	0x200c <_stogir.verify.integer-operations-target-structured+0x1220>
    2148:      	ldr	w0, [x0]
    214c:      	ubfx	x0, x0, #8, #8
    2150:      	cmp	x23, x0
    2154:      	b.eq	0x2170 <_stogir.verify.integer-operations-target-structured+0x1384>
    2158:      	cmp	x24, #0x0
    215c:      	b.eq	0x217c <_stogir.verify.integer-operations-target-structured+0x1390>
    2160:      	cmp	x0, #0x5
    2164:      	b.eq	0x2170 <_stogir.verify.integer-operations-target-structured+0x1384>
    2168:      	cmp	x0, #0xb
    216c:      	b.ne	0x217c <_stogir.verify.integer-operations-target-structured+0x1390>
    2170:      	mov	x0, x20
    2174:      	mov	x1, x22
    2178:      	b	0x2144 <_stogir.verify.integer-operations-target-structured+0x1358>
    217c:      	ldr	x0, [sp, #0x2a0]
    2180:      	mov	x1, #0x1d               ; =29
    2184:      	b	0x2178 <_stogir.verify.integer-operations-target-structured+0x138c>
    2188:      	brk	#0
    218c:      	b	0x2188 <_stogir.verify.integer-operations-target-structured+0x139c>
    2190:      	mov	x0, x20
    2194:      	mov	x1, x22
    2198:      	b	0x200c <_stogir.verify.integer-operations-target-structured+0x1220>
    219c:      	brk	#0
    21a0:      	b	0x219c <_stogir.verify.integer-operations-target-structured+0x13b0>
    21a4:      	mov	x0, x19
    21a8:      	ldr	x1, [sp, #0x418]
    21ac:      	ldr	x2, [sp, #0x420]
    21b0:      	b	0x174c <_stogir.verify.integer-operations-target-structured+0x960>
    21b4:      	brk	#0
    21b8:      	b	0x21b4 <_stogir.verify.integer-operations-target-structured+0x13c8>
    21bc:      	brk	#0
    21c0:      	b	0x21bc <_stogir.verify.integer-operations-target-structured+0x13d0>
    21c4:      	brk	#0
    21c8:      	b	0x21c4 <_stogir.verify.integer-operations-target-structured+0x13d8>
    21cc:      	brk	#0
    21d0:      	b	0x21cc <_stogir.verify.integer-operations-target-structured+0x13e0>
    21d4:      	ldr	x0, [sp, #0x2c8]
    21d8:      	cmp	x0, #0x0
    21dc:      	b.ne	0x2238 <_stogir.verify.integer-operations-target-structured+0x144c>
    21e0:      	and	x0, x19, #0xffffffff
    21e4:      	mov	x1, x0
    21e8:      	movz	x0, #0x0, lsl #48
    21ec:      	movz	x2, #0x0, lsl #48
    21f0:      	ldr	x3, [sp, #0x2c0]
    21f4:      	str	x0, [x3]
    21f8:      	str	x1, [x3, #0x8]
    21fc:      	str	x2, [x3, #0x10]
    2200:      	ldr	x19, [sp, #0x448]
    2204:      	ldr	x20, [sp, #0x450]
    2208:      	ldr	x21, [sp, #0x458]
    220c:      	ldr	x22, [sp, #0x460]
    2210:      	ldr	x23, [sp, #0x468]
    2214:      	ldr	x24, [sp, #0x470]
    2218:      	ldr	x25, [sp, #0x478]
    221c:      	ldr	x26, [sp, #0x480]
    2220:      	ldr	x27, [sp, #0x488]
    2224:      	ldr	x28, [sp, #0x490]
    2228:      	ldr	x29, [sp, #0x10]
    222c:      	ldr	x30, [sp, #0x18]
    2230:      	add	sp, sp, #0x4a0
    2234:      	ret
    2238:      	ldr	x1, [sp, #0x248]
    223c:      	mov	x2, x0
    2240:      	mov	x0, #0x1                ; =1
    2244:      	b	0x21f0 <_stogir.verify.integer-operations-target-structured+0x1404>
    2248:      	str	x8, [sp, #0x2c0]
    224c:      	str	x20, [sp, #0x2c8]
    2250:      	b	0x21d4 <_stogir.verify.integer-operations-target-structured+0x13e8>
    2254:      	str	x8, [sp, #0x2c0]
    2258:      	str	x20, [sp, #0x2c8]
    225c:      	b	0x21d4 <_stogir.verify.integer-operations-target-structured+0x13e8>
    2260:      	str	x1, [sp, #0x358]
    2264:      	str	x2, [sp, #0x360]
    2268:      	b	0x1920 <_stogir.verify.integer-operations-target-structured+0xb34>
    226c:      	str	x1, [sp, #0x368]
    2270:      	str	x2, [sp, #0x370]
    2274:      	b	0x1a18 <_stogir.verify.integer-operations-target-structured+0xc2c>
    2278:      	str	x0, [sp, #0x378]
    227c:      	str	x1, [sp, #0x380]
    2280:      	b	0x1a34 <_stogir.verify.integer-operations-target-structured+0xc48>
    2284:      	str	x0, [sp, #0x388]
    2288:      	str	x1, [sp, #0x390]
    228c:      	b	0x1a98 <_stogir.verify.integer-operations-target-structured+0xcac>
    2290:      	str	x0, [sp, #0x388]
    2294:      	str	x1, [sp, #0x390]
    2298:      	b	0x1a98 <_stogir.verify.integer-operations-target-structured+0xcac>
    229c:      	str	x0, [sp, #0x3a8]
    22a0:      	str	x1, [sp, #0x3b0]
    22a4:      	b	0x13e8 <_stogir.verify.integer-operations-target-structured+0x5fc>
    22a8:      	str	x0, [sp, #0x3c8]
    22ac:      	str	x1, [sp, #0x3d0]
    22b0:      	ldr	x1, [sp, #0x350]
    22b4:      	b	0x1444 <_stogir.verify.integer-operations-target-structured+0x658>
    22b8:      	str	x1, [sp, #0x350]
    22bc:      	ldr	x1, [sp, #0x320]
    22c0:      	str	x0, [sp, #0x3d8]
    22c4:      	str	x2, [sp, #0x3e0]
    22c8:      	b	0x1d10 <_stogir.verify.integer-operations-target-structured+0xf24>
    22cc:      	str	x1, [sp, #0x350]
    22d0:      	ldr	x1, [sp, #0x320]
    22d4:      	str	x0, [sp, #0x3d8]
    22d8:      	str	x2, [sp, #0x3e0]
    22dc:      	b	0x1d10 <_stogir.verify.integer-operations-target-structured+0xf24>
    22e0:      	str	x1, [sp, #0x320]
    22e4:      	ldr	x1, [sp, #0x238]
    22e8:      	str	x0, [sp, #0x3e8]
    22ec:      	str	x2, [sp, #0x3f0]
    22f0:      	b	0x1d3c <_stogir.verify.integer-operations-target-structured+0xf50>
    22f4:      	str	x1, [sp, #0x238]
    22f8:      	str	x0, [sp, #0x3f8]
    22fc:      	str	x2, [sp, #0x400]
    2300:      	b	0x1df4 <_stogir.verify.integer-operations-target-structured+0x1008>
    2304:      	str	x0, [sp, #0x408]
    2308:      	str	x1, [sp, #0x410]
    230c:      	ldr	x1, [sp, #0x258]
    2310:      	str	x20, [sp, #0x260]
    2314:      	mov	x20, x2
    2318:      	b	0x1e20 <_stogir.verify.integer-operations-target-structured+0x1034>
    231c:      	ldr	x20, [sp, #0x338]
    2320:      	ldr	x21, [sp, #0x2b0]
    2324:      	b	0x1e68 <_stogir.verify.integer-operations-target-structured+0x107c>
    2328:      	ldr	x20, [sp, #0x338]
    232c:      	ldr	x21, [sp, #0x2b0]
    2330:      	b	0x1e60 <_stogir.verify.integer-operations-target-structured+0x1074>
    2334:      	str	x26, [sp, #0x440]
    2338:      	str	x25, [sp, #0x438]
    233c:      	str	x24, [sp, #0x430]
    2340:      	str	x23, [sp, #0x428]
    2344:      	str	x1, [sp, #0x258]
    2348:      	str	x2, [sp, #0x418]
    234c:      	str	x3, [sp, #0x420]
    2350:      	b	0x21a4 <_stogir.verify.integer-operations-target-structured+0x13b8>
    2354:      	str	x26, [sp, #0x440]
    2358:      	str	x25, [sp, #0x438]
    235c:      	str	x24, [sp, #0x430]
    2360:      	mov	x24, x1
    2364:      	str	x23, [sp, #0x428]
    2368:      	mov	x23, x2
    236c:      	b	0x1f4c <_stogir.verify.integer-operations-target-structured+0x1160>
    2370:      	str	x26, [sp, #0x440]
    2374:      	str	x25, [sp, #0x438]
    2378:      	str	x24, [sp, #0x430]
    237c:      	mov	x24, x1
    2380:      	str	x23, [sp, #0x428]
    2384:      	mov	x23, x2
    2388:      	b	0x1f4c <_stogir.verify.integer-operations-target-structured+0x1160>
    238c:      	str	x26, [sp, #0x440]
    2390:      	str	x25, [sp, #0x438]
    2394:      	str	x24, [sp, #0x430]
    2398:      	mov	x24, x1
    239c:      	str	x23, [sp, #0x428]
    23a0:      	mov	x23, x2
    23a4:      	mov	w25, w3
    23a8:      	mov	w26, w4
    23ac:      	b	0x2030 <_stogir.verify.integer-operations-target-structured+0x1244>

00000000000023b0 <_coil.core.Len$coil.arraylist.ArrayList$len__i32>:
    23b0:      	ldr	x0, [x0, #0x8]
    23b4:      	ret

00000000000023b8 <_coil.core.Eq$slice<u8>$=>:
    23b8:      	sub	sp, sp, #0x10
    23bc:      	str	x29, [sp]
    23c0:      	str	x30, [sp, #0x8]
    23c4:      	mov	x29, sp
    23c8:      	cmp	x1, x3
    23cc:      	b.ne	0x240c <_coil.core.Eq$slice<u8>$=+0x54>
    23d0:      	cmp	x1, #0x0
    23d4:      	b.ne	0x23e0 <_coil.core.Eq$slice<u8>$=+0x28>
    23d8:      	mov	x0, #0x1                ; =1
    23dc:      	b	0x2408 <_coil.core.Eq$slice<u8>$=+0x50>
    23e0:      	lsr	x1, x1, #0
    23e4:      	fmov	d31, x1
    23e8:      	mov	x1, x2
    23ec:      	fmov	x2, d31
    23f0:      	bl	0x23f0 <_coil.core.Eq$slice<u8>$=+0x38>
		00000000000023f0:  ARM64_RELOC_BRANCH26	_memcmp
    23f4:      	lsr	w0, w0, #0
    23f8:      	sxtw	x0, w0
    23fc:      	cmp	x0, #0x0
    2400:      	cset	w0, eq
    2404:      	ubfx	x0, x0, #0, #8
    2408:      	b	0x2410 <_coil.core.Eq$slice<u8>$=+0x58>
    240c:      	movz	x0, #0x0, lsl #48
    2410:      	ldr	x29, [sp]
    2414:      	ldr	x30, [sp, #0x8]
    2418:      	add	sp, sp, #0x10
    241c:      	ret

0000000000002420 <_stogir.node.opcode>:
    2420:      	ldr	w0, [x0]
    2424:      	uxtb	w0, w0
    2428:      	ret

000000000000242c <_stogir.opcode.valid?>:
    242c:      	sxtw	x0, w0
    2430:      	cmp	x0, #0x0
    2434:      	b.lt	0x2448 <_stogir.opcode.valid?+0x1c>
    2438:      	cmp	x0, #0x83
    243c:      	cset	w0, lt
    2440:      	ubfx	x0, x0, #0, #8
    2444:      	b	0x244c <_stogir.opcode.valid?+0x20>
    2448:      	movz	x0, #0x0, lsl #48
    244c:      	ret

0000000000002450 <_stogir.node.type-id>:
    2450:      	ldr	w0, [x0]
    2454:      	ubfx	x0, x0, #8, #8
    2458:      	ret

000000000000245c <_stogir.types.valid?>:
    245c:      	sxtw	x0, w0
    2460:      	cmp	x0, #0x0
    2464:      	b.lt	0x2478 <_stogir.types.valid?+0x1c>
    2468:      	cmp	x0, #0xd
    246c:      	b.gt	0x2478 <_stogir.types.valid?+0x1c>
    2470:      	mov	x0, #0x1                ; =1
    2474:      	b	0x24b8 <_stogir.types.valid?+0x5c>
    2478:      	cmp	x0, #0xf
    247c:      	b.le	0x24b4 <_stogir.types.valid?+0x58>
    2480:      	cmp	x0, #0x80
    2484:      	b.ge	0x24ac <_stogir.types.valid?+0x50>
    2488:      	and	x0, x0, #0xf
    248c:      	lsr	w0, w0, #0
    2490:      	sxtw	x0, w0
    2494:      	cmp	x0, #0x1
    2498:      	b.lt	0x24bc <_stogir.types.valid?+0x60>
    249c:      	cmp	x0, #0xd
    24a0:      	cset	w0, le
    24a4:      	ubfx	x0, x0, #0, #8
    24a8:      	b	0x24c0 <_stogir.types.valid?+0x64>
    24ac:      	movz	x0, #0x0, lsl #48
    24b0:      	b	0x24b8 <_stogir.types.valid?+0x5c>
    24b4:      	movz	x0, #0x0, lsl #48
    24b8:      	ret
    24bc:      	movz	x0, #0x0, lsl #48
    24c0:      	b	0x24b0 <_stogir.types.valid?+0x54>

00000000000024c4 <_stogir.opcode.operand-slots>:
    24c4:      	sxtw	x0, w0
    24c8:      	cmp	x0, #0x0
    24cc:      	b.lt	0x24f8 <_stogir.opcode.operand-slots+0x34>
    24d0:      	cmp	x0, #0x83
    24d4:      	b.ge	0x24f8 <_stogir.opcode.operand-slots+0x34>
    24d8:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x1214>
		00000000000024d8:  ARM64_RELOC_PAGE21	l_stogir.336
    24dc:      	ldr	x16, [x16]
		00000000000024dc:  ARM64_RELOC_PAGEOFF12	l_stogir.336
    24e0:      	orr	x1, x16, xzr
    24e4:      	lsr	x2, x0, #0
    24e8:      	add	x0, x1, x0
    24ec:      	ldrsb	w0, [x0]
    24f0:      	sxtb	x0, w0
    24f4:      	b	0x24fc <_stogir.opcode.operand-slots+0x38>
    24f8:      	mov	x0, #-0x2               ; =-2
    24fc:      	ret

0000000000002500 <_stogir.opcode.input-count>:
    2500:      	sxtw	x0, w0
    2504:      	cmp	x0, #0x0
    2508:      	b.lt	0x2534 <_stogir.opcode.input-count+0x34>
    250c:      	cmp	x0, #0x83
    2510:      	b.ge	0x2534 <_stogir.opcode.input-count+0x34>
    2514:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x1214>
		0000000000002514:  ARM64_RELOC_PAGE21	l_stogir.337
    2518:      	ldr	x16, [x16]
		0000000000002518:  ARM64_RELOC_PAGEOFF12	l_stogir.337
    251c:      	orr	x1, x16, xzr
    2520:      	lsr	x2, x0, #0
    2524:      	add	x0, x1, x0
    2528:      	ldrsb	w0, [x0]
    252c:      	sxtb	x0, w0
    2530:      	b	0x2538 <_stogir.opcode.input-count+0x38>
    2534:      	mov	x0, #-0x2               ; =-2
    2538:      	ret

000000000000253c <_stogir.node.auxiliary>:
    253c:      	ldr	w0, [x0]
    2540:      	ubfx	x0, x0, #16, #16
    2544:      	ret

0000000000002548 <_stogir.opcode.operand-code>:
    2548:      	sxtw	x0, w0
    254c:      	cmp	x0, #0x0
    2550:      	b.lt	0x2590 <_stogir.opcode.operand-code+0x48>
    2554:      	cmp	x0, #0x83
    2558:      	b.ge	0x2590 <_stogir.opcode.operand-code+0x48>
    255c:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x1214>
		000000000000255c:  ARM64_RELOC_PAGE21	l_stogir.338
    2560:      	ldr	x16, [x16]
		0000000000002560:  ARM64_RELOC_PAGEOFF12	l_stogir.338
    2564:      	orr	x2, x16, xzr
    2568:      	lsl	x3, x0, #2
    256c:      	sxtw	x1, w1
    2570:      	add	x0, x2, x0, lsl #2
    2574:      	ldr	w0, [x0]
    2578:      	cmp	x1, #0x0
    257c:      	b.le	0x2598 <_stogir.opcode.operand-code+0x50>
    2580:      	cmp	x1, #0x4
    2584:      	b.le	0x25a0 <_stogir.opcode.operand-code+0x58>
    2588:      	mov	x1, #0x4                ; =4
    258c:      	b	0x25ac <_stogir.opcode.operand-code+0x64>
    2590:      	movz	x0, #0x0, lsl #48
    2594:      	ret
    2598:      	movz	x0, #0x0, lsl #48
    259c:      	b	0x2594 <_stogir.opcode.operand-code+0x4c>
    25a0:      	sub	x1, x1, #0x1
    25a4:      	lsr	w1, w1, #0
    25a8:      	sxtw	x1, w1
    25ac:      	lsl	x1, x1, #2
    25b0:      	lsr	w1, w1, #0
    25b4:      	ubfx	x1, x1, #0, #32
    25b8:      	lsr	x0, x0, x1
    25bc:      	lsr	w0, w0, #0
    25c0:      	and	x0, x0, #0xf
    25c4:      	lsr	w0, w0, #0
    25c8:      	b	0x259c <_stogir.opcode.operand-code+0x54>

00000000000025cc <_stogir.graph.operand>:
    25cc:      	sub	sp, sp, #0x10
    25d0:      	mov	x3, sp
    25d4:      	sxtw	x1, w1
    25d8:      	cmp	x1, #0x0
    25dc:      	b.le	0x2620 <_stogir.graph.operand+0x54>
    25e0:      	lsl	x4, x1, #2
    25e4:      	ldr	x5, [x0, #0x8]
    25e8:      	cmp	x1, x5
    25ec:      	b.ge	0x2654 <_stogir.graph.operand+0x88>
    25f0:      	add	x5, x0, #0x78
    25f4:      	ldr	x5, [x5, #0x8]
    25f8:      	cmp	x1, x5
    25fc:      	b.ge	0x264c <_stogir.graph.operand+0x80>
    2600:      	ldr	x5, [x0, #0x78]
    2604:      	add	x5, x4, x5
    2608:      	ldr	w5, [x5]
    260c:      	sxtw	x5, w5
    2610:      	cmp	x5, #0x0
    2614:      	cset	w5, ge
    2618:      	ubfx	x5, x5, #0, #8
    261c:      	b	0x2650 <_stogir.graph.operand+0x84>
    2620:      	movz	x0, #0x0, lsl #48
    2624:      	movz	x1, #0x0, lsl #48
    2628:      	str	x0, [x3]
    262c:      	str	x1, [x3, #0x8]
    2630:      	ldr	x0, [sp]
    2634:      	ldr	x1, [sp, #0x8]
    2638:      	add	sp, sp, #0x10
    263c:      	ret
    2640:      	movz	x0, #0x0, lsl #48
    2644:      	movz	x1, #0x0, lsl #48
    2648:      	b	0x2628 <_stogir.graph.operand+0x5c>
    264c:      	movz	x5, #0x0, lsl #48
    2650:      	b	0x2658 <_stogir.graph.operand+0x8c>
    2654:      	movz	x5, #0x0, lsl #48
    2658:      	cmp	x5, #0x0
    265c:      	b.eq	0x2620 <_stogir.graph.operand+0x54>
    2660:      	sxtw	x2, w2
    2664:      	cmp	x2, #0x1
    2668:      	b.lt	0x2640 <_stogir.graph.operand+0x74>
    266c:      	ldr	x5, [x0, #0x78]
    2670:      	add	x4, x4, x5
    2674:      	ldr	w4, [x4]
    2678:      	sxtw	x4, w4
    267c:      	cmp	x2, x4
    2680:      	b.gt	0x2640 <_stogir.graph.operand+0x74>
    2684:      	asr	x16, x2, #63
    2688:      	lsr	x16, x16, #62
    268c:      	add	x4, x2, x16
    2690:      	asr	x4, x4, #2
    2694:      	asr	x16, x2, #63
    2698:      	lsr	x16, x16, #62
    269c:      	add	x2, x2, x16
    26a0:      	and	x2, x2, #0x3
    26a4:      	sub	x2, x2, x16
    26a8:      	ldr	x0, [x0]
    26ac:      	add	x1, x4, x1
    26b0:      	lsl	x4, x2, #2
    26b4:      	lsl	x4, x1, #4
    26b8:      	add	x0, x0, x1, lsl #4
    26bc:      	add	x0, x0, x2, lsl #2
    26c0:      	ldr	w0, [x0]
    26c4:      	sxtw	x0, w0
    26c8:      	and	x0, x0, #0xffffffff
    26cc:      	mov	x1, x0
    26d0:      	mov	x0, #0x1                ; =1
    26d4:      	b	0x2648 <_stogir.graph.operand+0x7c>

00000000000026d8 <_stogir.graph.borrow-node>:
    26d8:      	sxtw	x1, w1
    26dc:      	cmp	x1, #0x0
    26e0:      	cset	w2, gt
    26e4:      	movz	x16, #0x0, lsl #48
    26e8:      	sub	x3, x16, x1
    26ec:      	sub	x4, x3, #0x1
    26f0:      	uxtb	w16, w2
    26f4:      	cmp	w16, wzr
    26f8:      	b.eq	0x273c <_stogir.graph.borrow-node+0x64>
    26fc:      	ldr	x3, [x0, #0x8]
    2700:      	cmp	x1, x3
    2704:      	b.ge	0x2790 <_stogir.graph.borrow-node+0xb8>
    2708:      	add	x3, x0, #0x78
    270c:      	ldr	x3, [x3, #0x8]
    2710:      	cmp	x1, x3
    2714:      	b.ge	0x27d8 <_stogir.graph.borrow-node+0x100>
    2718:      	lsl	x3, x1, #2
    271c:      	ldr	x3, [x0, #0x78]
    2720:      	add	x3, x3, x1, lsl #2
    2724:      	ldr	w3, [x3]
    2728:      	sxtw	x3, w3
    272c:      	cmp	x3, #0x0
    2730:      	cset	w3, ge
    2734:      	ubfx	x3, x3, #0, #8
    2738:      	b	0x27dc <_stogir.graph.borrow-node+0x104>
    273c:      	cmp	x1, #0x0
    2740:      	b.ge	0x2798 <_stogir.graph.borrow-node+0xc0>
    2744:      	add	x5, x0, #0x28
    2748:      	add	x6, x0, #0x50
    274c:      	ldr	x5, [x5, #0x8]
    2750:      	ldr	x6, [x6, #0x8]
    2754:      	cmp	x5, x6
    2758:      	b.ne	0x2788 <_stogir.graph.borrow-node+0xb0>
    275c:      	cmp	x3, x5
    2760:      	b.gt	0x27e0 <_stogir.graph.borrow-node+0x108>
    2764:      	lsl	x3, x4, #2
    2768:      	ldr	x3, [x0, #0x50]
    276c:      	add	x3, x3, x4, lsl #2
    2770:      	ldr	w3, [x3]
    2774:      	sxtw	x3, w3
    2778:      	cmp	x3, #0x0
    277c:      	cset	w3, gt
    2780:      	ubfx	x3, x3, #0, #8
    2784:      	b	0x27e4 <_stogir.graph.borrow-node+0x10c>
    2788:      	movz	x3, #0x0, lsl #48
    278c:      	b	0x279c <_stogir.graph.borrow-node+0xc4>
    2790:      	movz	x3, #0x0, lsl #48
    2794:      	b	0x279c <_stogir.graph.borrow-node+0xc4>
    2798:      	movz	x3, #0x0, lsl #48
    279c:      	cmp	x3, #0x0
    27a0:      	b.eq	0x27d0 <_stogir.graph.borrow-node+0xf8>
    27a4:      	uxtb	w16, w2
    27a8:      	cmp	w16, wzr
    27ac:      	b.eq	0x27c0 <_stogir.graph.borrow-node+0xe8>
    27b0:      	lsl	x2, x1, #4
    27b4:      	ldr	x0, [x0]
    27b8:      	add	x0, x0, x1, lsl #4
    27bc:      	b	0x27cc <_stogir.graph.borrow-node+0xf4>
    27c0:      	lsl	x1, x4, #4
    27c4:      	ldr	x0, [x0, #0x28]
    27c8:      	add	x0, x0, x4, lsl #4
    27cc:      	b	0x27d4 <_stogir.graph.borrow-node+0xfc>
    27d0:      	movz	x0, #0x0, lsl #48
    27d4:      	ret
    27d8:      	movz	x3, #0x0, lsl #48
    27dc:      	b	0x2794 <_stogir.graph.borrow-node+0xbc>
    27e0:      	movz	x3, #0x0, lsl #48
    27e4:      	b	0x278c <_stogir.graph.borrow-node+0xb4>

00000000000027e8 <_stogir.strings.lookup>:
    27e8:      	sxtw	x1, w1
    27ec:      	cmp	x1, #0x0
    27f0:      	b.le	0x286c <_stogir.strings.lookup+0x84>
    27f4:      	add	x2, x0, #0x28
    27f8:      	ldr	x2, [x2, #0x8]
    27fc:      	cmp	x1, x2
    2800:      	b.gt	0x286c <_stogir.strings.lookup+0x84>
    2804:      	sub	x1, x1, #0x1
    2808:      	mov	x17, #0x18              ; =24
    280c:      	mul	x1, x1, x17
    2810:      	ldr	x2, [x0, #0x28]
    2814:      	add	x1, x1, x2
    2818:      	ldr	x2, [x1]
    281c:      	ldr	x1, [x1, #0x8]
    2820:      	ldr	x3, [x0, #0x8]
    2824:      	cmp	x2, #0x0
    2828:      	b.lt	0x2888 <_stogir.strings.lookup+0xa0>
    282c:      	cmp	x2, x3
    2830:      	b.gt	0x2888 <_stogir.strings.lookup+0xa0>
    2834:      	cmp	x1, #0x0
    2838:      	b.lt	0x2888 <_stogir.strings.lookup+0xa0>
    283c:      	sub	x3, x3, x2
    2840:      	cmp	x1, x3
    2844:      	b.gt	0x2888 <_stogir.strings.lookup+0xa0>
    2848:      	add	x1, x1, x2
    284c:      	lsr	x3, x2, #0
    2850:      	sub	x1, x1, x2
    2854:      	ldr	x0, [x0]
    2858:      	add	x0, x0, x2
    285c:      	mov	x2, x1
    2860:      	mov	x1, x0
    2864:      	mov	x0, #0x1                ; =1
    2868:      	b	0x2894 <_stogir.strings.lookup+0xac>
    286c:      	movz	x0, #0x0, lsl #48
    2870:      	movz	x1, #0x0, lsl #48
    2874:      	movz	x2, #0x0, lsl #48
    2878:      	str	x0, [x8]
    287c:      	str	x1, [x8, #0x8]
    2880:      	str	x2, [x8, #0x10]
    2884:      	ret
    2888:      	movz	x0, #0x0, lsl #48
    288c:      	movz	x1, #0x0, lsl #48
    2890:      	movz	x2, #0x0, lsl #48
    2894:      	b	0x2878 <_stogir.strings.lookup+0x90>

0000000000002898 <_stogir.uses.edge-code?>:
    2898:      	ubfx	x0, x0, #0, #32
    289c:      	cmp	x0, #0xf
    28a0:      	b.hs	0x28d4 <_stogir.uses.edge-code?+0x3c>
    28a4:      	mov	x16, #0x1               ; =1
    28a8:      	lsl	x0, x16, x0
    28ac:      	lsr	w0, w0, #0
    28b0:      	mov	x17, #0x5e1c            ; =24092
    28b4:      	and	x0, x0, x17
    28b8:      	lsr	w0, w0, #0
    28bc:      	cmp	x0, #0x0
    28c0:      	cset	w0, eq
    28c4:      	uxtb	w16, w0
    28c8:      	cmp	w16, wzr
    28cc:      	cset	x0, eq
    28d0:      	b	0x28d8 <_stogir.uses.edge-code?+0x40>
    28d4:      	movz	x0, #0x0, lsl #48
    28d8:      	ret

00000000000028dc <_stogir.graph.contains?>:
    28dc:      	sxtw	x1, w1
    28e0:      	cmp	x1, #0x0
    28e4:      	b.le	0x2928 <_stogir.graph.contains?+0x4c>
    28e8:      	ldr	x2, [x0, #0x8]
    28ec:      	cmp	x1, x2
    28f0:      	b.ge	0x2988 <_stogir.graph.contains?+0xac>
    28f4:      	add	x2, x0, #0x78
    28f8:      	ldr	x2, [x2, #0x8]
    28fc:      	cmp	x1, x2
    2900:      	b.ge	0x2998 <_stogir.graph.contains?+0xbc>
    2904:      	lsl	x2, x1, #2
    2908:      	ldr	x0, [x0, #0x78]
    290c:      	add	x0, x0, x1, lsl #2
    2910:      	ldr	w0, [x0]
    2914:      	sxtw	x0, w0
    2918:      	cmp	x0, #0x0
    291c:      	cset	w0, ge
    2920:      	ubfx	x0, x0, #0, #8
    2924:      	b	0x299c <_stogir.graph.contains?+0xc0>
    2928:      	cmp	x1, #0x0
    292c:      	b.ge	0x2990 <_stogir.graph.contains?+0xb4>
    2930:      	add	x2, x0, #0x28
    2934:      	add	x3, x0, #0x50
    2938:      	ldr	x2, [x2, #0x8]
    293c:      	ldr	x3, [x3, #0x8]
    2940:      	cmp	x2, x3
    2944:      	b.ne	0x29a8 <_stogir.graph.contains?+0xcc>
    2948:      	movz	x16, #0x0, lsl #48
    294c:      	sub	x3, x16, x1
    2950:      	cmp	x3, x2
    2954:      	b.gt	0x29a0 <_stogir.graph.contains?+0xc4>
    2958:      	movz	x16, #0x0, lsl #48
    295c:      	sub	x1, x16, x1
    2960:      	sub	x1, x1, #0x1
    2964:      	lsl	x2, x1, #2
    2968:      	ldr	x0, [x0, #0x50]
    296c:      	add	x0, x0, x1, lsl #2
    2970:      	ldr	w0, [x0]
    2974:      	sxtw	x0, w0
    2978:      	cmp	x0, #0x0
    297c:      	cset	w0, gt
    2980:      	ubfx	x0, x0, #0, #8
    2984:      	b	0x29a4 <_stogir.graph.contains?+0xc8>
    2988:      	movz	x0, #0x0, lsl #48
    298c:      	b	0x299c <_stogir.graph.contains?+0xc0>
    2990:      	movz	x0, #0x0, lsl #48
    2994:      	b	0x29a4 <_stogir.graph.contains?+0xc8>
    2998:      	movz	x0, #0x0, lsl #48
    299c:      	b	0x29a4 <_stogir.graph.contains?+0xc8>
    29a0:      	movz	x0, #0x0, lsl #48
    29a4:      	ret
    29a8:      	movz	x0, #0x0, lsl #48
    29ac:      	b	0x29a4 <_stogir.graph.contains?+0xc8>

00000000000029b0 <_stogir.opcode.optional-reference?>:
    29b0:      	sxtw	x0, w0
    29b4:      	sxtw	x2, w2
    29b8:      	cmp	x0, #0x0
    29bc:      	b.lt	0x29f8 <_stogir.opcode.optional-reference?+0x48>
    29c0:      	cmp	x0, #0x83
    29c4:      	b.ge	0x29f8 <_stogir.opcode.optional-reference?+0x48>
    29c8:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x1214>
		00000000000029c8:  ARM64_RELOC_PAGE21	l_stogir.339
    29cc:      	ldr	x16, [x16]
		00000000000029cc:  ARM64_RELOC_PAGEOFF12	l_stogir.339
    29d0:      	orr	x3, x16, xzr
    29d4:      	lsl	x4, x0, #2
    29d8:      	add	x3, x3, x0, lsl #2
    29dc:      	ldr	w3, [x3]
    29e0:      	cmp	x2, #0x0
    29e4:      	b.le	0x2a40 <_stogir.opcode.optional-reference?+0x90>
    29e8:      	cmp	x2, #0x4
    29ec:      	b.le	0x2a64 <_stogir.opcode.optional-reference?+0xb4>
    29f0:      	mov	x4, #0x4                ; =4
    29f4:      	b	0x2a70 <_stogir.opcode.optional-reference?+0xc0>
    29f8:      	movz	x3, #0x0, lsl #48
    29fc:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x1214>
		00000000000029fc:  ARM64_RELOC_PAGE21	l_stogir.340
    2a00:      	ldr	x16, [x16]
		0000000000002a00:  ARM64_RELOC_PAGEOFF12	l_stogir.340
    2a04:      	ldr	w4, [x16]
    2a08:      	lsr	w3, w3, #0
    2a0c:      	cmp	x3, x4
    2a10:      	b.ne	0x2a24 <_stogir.opcode.optional-reference?+0x74>
    2a14:      	mov	x0, #0x1                ; =1
    2a18:      	b	0x2a20 <_stogir.opcode.optional-reference?+0x70>
    2a1c:      	movz	x0, #0x0, lsl #48
    2a20:      	ret
    2a24:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x1214>
		0000000000002a24:  ARM64_RELOC_PAGE21	l_stogir.341
    2a28:      	ldr	x16, [x16]
		0000000000002a28:  ARM64_RELOC_PAGEOFF12	l_stogir.341
    2a2c:      	ldr	w4, [x16]
    2a30:      	cmp	x3, x4
    2a34:      	b.ne	0x2a48 <_stogir.opcode.optional-reference?+0x98>
    2a38:      	mov	x0, #0x1                ; =1
    2a3c:      	b	0x2a20 <_stogir.opcode.optional-reference?+0x70>
    2a40:      	movz	x3, #0x0, lsl #48
    2a44:      	b	0x29fc <_stogir.opcode.optional-reference?+0x4c>
    2a48:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x1214>
		0000000000002a48:  ARM64_RELOC_PAGE21	l_stogir.342
    2a4c:      	ldr	x16, [x16]
		0000000000002a4c:  ARM64_RELOC_PAGEOFF12	l_stogir.342
    2a50:      	ldr	w4, [x16]
    2a54:      	cmp	x3, x4
    2a58:      	b.ne	0x2a90 <_stogir.opcode.optional-reference?+0xe0>
    2a5c:      	mov	x0, #0x1                ; =1
    2a60:      	b	0x2a20 <_stogir.opcode.optional-reference?+0x70>
    2a64:      	sub	x4, x2, #0x1
    2a68:      	lsr	w4, w4, #0
    2a6c:      	sxtw	x4, w4
    2a70:      	lsl	x4, x4, #2
    2a74:      	lsr	w4, w4, #0
    2a78:      	ubfx	x4, x4, #0, #32
    2a7c:      	lsr	x3, x3, x4
    2a80:      	lsr	w3, w3, #0
    2a84:      	and	x3, x3, #0xf
    2a88:      	lsr	w3, w3, #0
    2a8c:      	b	0x2a44 <_stogir.opcode.optional-reference?+0x94>
    2a90:      	cmp	x0, #0x78
    2a94:      	b.ne	0x2a1c <_stogir.opcode.optional-reference?+0x6c>
    2a98:      	sxtw	x1, w1
    2a9c:      	cmp	x1, #0x0
    2aa0:      	b.ne	0x2ab4 <_stogir.opcode.optional-reference?+0x104>
    2aa4:      	cmp	x2, #0x2
    2aa8:      	cset	w0, eq
    2aac:      	ubfx	x0, x0, #0, #8
    2ab0:      	b	0x2ab8 <_stogir.opcode.optional-reference?+0x108>
    2ab4:      	movz	x0, #0x0, lsl #48
    2ab8:      	b	0x2a20 <_stogir.opcode.optional-reference?+0x70>

0000000000002abc <_stogir.integer-binary.operation?>:
    2abc:      	sxtw	x0, w0
    2ac0:      	cmp	x0, #0x1a
    2ac4:      	b.lt	0x2ad8 <_stogir.integer-binary.operation?+0x1c>
    2ac8:      	cmp	x0, #0x1e
    2acc:      	b.gt	0x2ad8 <_stogir.integer-binary.operation?+0x1c>
    2ad0:      	mov	x0, #0x1                ; =1
    2ad4:      	b	0x2b0c <_stogir.integer-binary.operation?+0x50>
    2ad8:      	cmp	x0, #0x2e
    2adc:      	b.lt	0x2af0 <_stogir.integer-binary.operation?+0x34>
    2ae0:      	cmp	x0, #0x35
    2ae4:      	b.gt	0x2af0 <_stogir.integer-binary.operation?+0x34>
    2ae8:      	mov	x0, #0x1                ; =1
    2aec:      	b	0x2b0c <_stogir.integer-binary.operation?+0x50>
    2af0:      	cmp	x0, #0x3a
    2af4:      	b.ne	0x2b00 <_stogir.integer-binary.operation?+0x44>
    2af8:      	mov	x0, #0x1                ; =1
    2afc:      	b	0x2b0c <_stogir.integer-binary.operation?+0x50>
    2b00:      	cmp	x0, #0x3b
    2b04:      	cset	w0, eq
    2b08:      	ubfx	x0, x0, #0, #8
    2b0c:      	ret

0000000000002b10 <_stogir.integer-unary.operation?>:
    2b10:      	sxtw	x0, w0
    2b14:      	cmp	x0, #0x1f
    2b18:      	b.ne	0x2b34 <_stogir.integer-unary.operation?+0x24>
    2b1c:      	mov	x0, #0x1                ; =1
    2b20:      	b	0x2b30 <_stogir.integer-unary.operation?+0x20>
    2b24:      	cmp	x0, #0x39
    2b28:      	cset	w0, eq
    2b2c:      	ubfx	x0, x0, #0, #8
    2b30:      	ret
    2b34:      	cmp	x0, #0x20
    2b38:      	b.ne	0x2b44 <_stogir.integer-unary.operation?+0x34>
    2b3c:      	mov	x0, #0x1                ; =1
    2b40:      	b	0x2b30 <_stogir.integer-unary.operation?+0x20>
    2b44:      	cmp	x0, #0x2d
    2b48:      	b.ne	0x2b54 <_stogir.integer-unary.operation?+0x44>
    2b4c:      	mov	x0, #0x1                ; =1
    2b50:      	b	0x2b30 <_stogir.integer-unary.operation?+0x20>
    2b54:      	cmp	x0, #0x36
    2b58:      	b.ne	0x2b64 <_stogir.integer-unary.operation?+0x54>
    2b5c:      	mov	x0, #0x1                ; =1
    2b60:      	b	0x2b30 <_stogir.integer-unary.operation?+0x20>
    2b64:      	cmp	x0, #0x37
    2b68:      	b.ne	0x2b74 <_stogir.integer-unary.operation?+0x64>
    2b6c:      	mov	x0, #0x1                ; =1
    2b70:      	b	0x2b30 <_stogir.integer-unary.operation?+0x20>
    2b74:      	cmp	x0, #0x38
    2b78:      	b.ne	0x2b24 <_stogir.integer-unary.operation?+0x14>
    2b7c:      	mov	x0, #0x1                ; =1
    2b80:      	b	0x2b30 <_stogir.integer-unary.operation?+0x20>

0000000000002b84 <_stogir.verify.classifications>:
    2b84:      	sub	sp, sp, #0x70
    2b88:      	str	x29, [sp]
    2b8c:      	str	x30, [sp, #0x8]
    2b90:      	mov	x29, sp
    2b94:      	str	x19, [sp, #0x20]
    2b98:      	str	x20, [sp, #0x28]
    2b9c:      	str	x21, [sp, #0x30]
    2ba0:      	str	x22, [sp, #0x38]
    2ba4:      	str	x23, [sp, #0x40]
    2ba8:      	str	x24, [sp, #0x48]
    2bac:      	str	x25, [sp, #0x50]
    2bb0:      	str	x26, [sp, #0x58]
    2bb4:      	str	x27, [sp, #0x60]
    2bb8:      	str	x28, [sp, #0x68]
    2bbc:      	ldr	w4, [x2]
    2bc0:      	uxtb	w19, w4
    2bc4:      	orr	x5, x19, xzr
    2bc8:      	lsr	w20, w5, #0
    2bcc:      	ubfx	x21, x4, #8, #8
    2bd0:      	orr	x4, x21, xzr
    2bd4:      	lsr	w4, w4, #0
    2bd8:      	mov	x22, x0
    2bdc:      	mov	w0, w4
    2be0:      	mov	w23, w1
    2be4:      	mov	x24, x2
    2be8:      	mov	w25, w3
    2bec:      	bl	0x2bec <_stogir.verify.classifications+0x68>
		0000000000002bec:  ARM64_RELOC_BRANCH26	_stogir.types.vector?
    2bf0:      	fmov	d31, x0
    2bf4:      	mov	w0, w20
    2bf8:      	fmov	x20, d31
    2bfc:      	bl	0x2bfc <_stogir.verify.classifications+0x78>
		0000000000002bfc:  ARM64_RELOC_BRANCH26	_stogir.floating.operation?
    2c00:      	cmp	x0, #0x0
    2c04:      	b.eq	0x2c24 <_stogir.verify.classifications+0xa0>
    2c08:      	cmp	x20, #0x0
    2c0c:      	cset	w0, ne
    2c10:      	uxtb	w16, w0
    2c14:      	cmp	w16, wzr
    2c18:      	cset	x0, eq
    2c1c:      	mov	x26, x0
    2c20:      	b	0x2c28 <_stogir.verify.classifications+0xa4>
    2c24:      	movz	x26, #0x0, lsl #48
    2c28:      	cmp	x26, #0x0
    2c2c:      	cset	w27, ne
    2c30:      	uxtb	w16, w27
    2c34:      	cmp	w16, wzr
    2c38:      	b.eq	0x2c6c <_stogir.verify.classifications+0xe8>
    2c3c:      	ldr	w0, [x24, #0x4]
    2c40:      	lsr	w0, w0, #0
    2c44:      	mov	w1, w0
    2c48:      	mov	x0, x22
    2c4c:      	bl	0x2c4c <_stogir.verify.classifications+0xc8>
		0000000000002c4c:  ARM64_RELOC_BRANCH26	_stogir.graph.borrow-node
    2c50:      	cmp	x0, #0x0
    2c54:      	b.ne	0x2c60 <_stogir.verify.classifications+0xdc>
    2c58:      	movn	x0, #0x0, lsl #48
    2c5c:      	b	0x2c68 <_stogir.verify.classifications+0xe4>
    2c60:      	ldr	w0, [x0]
    2c64:      	ubfx	x0, x0, #8, #8
    2c68:      	b	0x2c70 <_stogir.verify.classifications+0xec>
    2c6c:      	movn	x0, #0x0, lsl #48
    2c70:      	lsr	w0, w0, #0
    2c74:      	sxtw	x28, w0
    2c78:      	cmp	x26, #0x0
    2c7c:      	b.eq	0x2cac <_stogir.verify.classifications+0x128>
    2c80:      	bl	0x2c80 <_stogir.verify.classifications+0xfc>
		0000000000002c80:  ARM64_RELOC_BRANCH26	_stogir.types.vector?
    2c84:      	cmp	x0, #0x0
    2c88:      	b.eq	0x3104 <_stogir.verify.classifications+0x580>
    2c8c:      	movz	x0, #0x0, lsl #48
    2c90:      	b	0x2c98 <_stogir.verify.classifications+0x114>
    2c94:      	mov	x0, #0x1                ; =1
    2c98:      	b	0x2cb0 <_stogir.verify.classifications+0x12c>
    2c9c:      	movz	x20, #0x0, lsl #48
    2ca0:      	b	0x2d38 <_stogir.verify.classifications+0x1b4>
    2ca4:      	movz	x13, #0x0, lsl #48
    2ca8:      	b	0x2d40 <_stogir.verify.classifications+0x1bc>
    2cac:      	movz	x0, #0x0, lsl #48
    2cb0:      	sxtw	x25, w25
    2cb4:      	cmp	x28, #0xf
    2cb8:      	cset	w1, gt
    2cbc:      	cmp	x28, #0x80
    2cc0:      	cset	w2, lt
    2cc4:      	and	x3, x28, #0xf
    2cc8:      	cmp	x19, #0x83
    2ccc:      	cset	w4, lt
    2cd0:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x1214>
		0000000000002cd0:  ARM64_RELOC_PAGE21	l_stogir.343
    2cd4:      	ldr	x16, [x16]
		0000000000002cd4:  ARM64_RELOC_PAGEOFF12	l_stogir.343
    2cd8:      	orr	x5, x16, xzr
    2cdc:      	lsl	x6, x19, #2
    2ce0:      	add	x6, x22, #0x78
    2ce4:      	add	x7, x22, #0x28
    2ce8:      	add	x8, x22, #0x50
    2cec:      	sxtw	x23, w23
    2cf0:      	add	x9, x22, #0x78
    2cf4:      	lsr	w3, w3, #0
    2cf8:      	add	x5, x5, x19, lsl #2
    2cfc:      	cmp	x23, #0x0
    2d00:      	cset	w10, le
    2d04:      	lsl	x11, x23, #2
    2d08:      	sxtw	x3, w3
    2d0c:      	cmp	x3, #0x1
    2d10:      	cset	w12, ge
    2d14:      	cmp	x3, #0xd
    2d18:      	cset	w3, le
    2d1c:      	ubfx	x3, x3, #0, #8
    2d20:      	mov	x13, x20
    2d24:      	mov	x14, #0x1               ; =1
    2d28:      	b	0x2e00 <_stogir.verify.classifications+0x27c>
    2d2c:      	movz	x20, #0x0, lsl #48
    2d30:      	b	0x2d74 <_stogir.verify.classifications+0x1f0>
    2d34:      	movz	x20, #0x0, lsl #48
    2d38:      	b	0x2d7c <_stogir.verify.classifications+0x1f8>
    2d3c:      	movz	x13, #0x0, lsl #48
    2d40:      	b	0x2df4 <_stogir.verify.classifications+0x270>
    2d44:      	sub	x20, x15, #0x1
    2d48:      	lsr	w20, w20, #0
    2d4c:      	sxtw	x20, w20
    2d50:      	lsl	x20, x20, #2
    2d54:      	lsr	w20, w20, #0
    2d58:      	ubfx	x20, x20, #0, #32
    2d5c:      	lsr	x19, x19, x20
    2d60:      	lsr	w19, w19, #0
    2d64:      	and	x19, x19, #0xf
    2d68:      	lsr	w19, w19, #0
    2d6c:      	b	0x2e44 <_stogir.verify.classifications+0x2c0>
    2d70:      	movz	x20, #0x0, lsl #48
    2d74:      	b	0x2d7c <_stogir.verify.classifications+0x1f8>
    2d78:      	movz	x20, #0x0, lsl #48
    2d7c:      	cmp	x20, #0x0
    2d80:      	b.eq	0x2db0 <_stogir.verify.classifications+0x22c>
    2d84:      	uxtb	w16, w19
    2d88:      	cmp	w16, wzr
    2d8c:      	b.eq	0x2da0 <_stogir.verify.classifications+0x21c>
    2d90:      	lsl	x19, x15, #4
    2d94:      	ldr	x19, [x22]
    2d98:      	add	x15, x19, x15, lsl #4
    2d9c:      	b	0x2dac <_stogir.verify.classifications+0x228>
    2da0:      	lsl	x15, x21, #4
    2da4:      	ldr	x15, [x22, #0x28]
    2da8:      	add	x15, x15, x21, lsl #4
    2dac:      	b	0x2db4 <_stogir.verify.classifications+0x230>
    2db0:      	movz	x15, #0x0, lsl #48
    2db4:      	cmp	x15, #0x0
    2db8:      	b.eq	0x2df4 <_stogir.verify.classifications+0x270>
    2dbc:      	ldr	w15, [x15]
    2dc0:      	ubfx	x15, x15, #8, #8
    2dc4:      	cmp	x15, #0xf
    2dc8:      	b.le	0x2df4 <_stogir.verify.classifications+0x270>
    2dcc:      	cmp	x15, #0x80
    2dd0:      	b.ge	0x2df4 <_stogir.verify.classifications+0x270>
    2dd4:      	and	x15, x15, #0xf
    2dd8:      	lsr	w15, w15, #0
    2ddc:      	sxtw	x15, w15
    2de0:      	cmp	x15, #0x1
    2de4:      	b.lt	0x2df4 <_stogir.verify.classifications+0x270>
    2de8:      	cmp	x15, #0xd
    2dec:      	b.gt	0x2df4 <_stogir.verify.classifications+0x270>
    2df0:      	mov	x13, #0x1               ; =1
    2df4:      	add	x14, x14, #0x1
    2df8:      	lsr	w14, w14, #0
    2dfc:      	sxtw	x14, w14
    2e00:      	cmp	x13, #0x0
    2e04:      	b.ne	0x2f98 <_stogir.verify.classifications+0x414>
    2e08:      	cmp	x14, x25
    2e0c:      	b.gt	0x2f98 <_stogir.verify.classifications+0x414>
    2e10:      	lsr	w15, w14, #0
    2e14:      	sxtw	x15, w15
    2e18:      	uxtb	w16, w4
    2e1c:      	cmp	w16, wzr
    2e20:      	b.eq	0x2e48 <_stogir.verify.classifications+0x2c4>
    2e24:      	ldr	w19, [x5]
    2e28:      	cmp	x15, #0x0
    2e2c:      	b.le	0x2e40 <_stogir.verify.classifications+0x2bc>
    2e30:      	cmp	x15, #0x4
    2e34:      	b.le	0x2d44 <_stogir.verify.classifications+0x1c0>
    2e38:      	mov	x20, #0x4               ; =4
    2e3c:      	b	0x2d50 <_stogir.verify.classifications+0x1cc>
    2e40:      	movz	x19, #0x0, lsl #48
    2e44:      	b	0x2e4c <_stogir.verify.classifications+0x2c8>
    2e48:      	movz	x19, #0x0, lsl #48
    2e4c:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x1214>
		0000000000002e4c:  ARM64_RELOC_PAGE21	l_stogir.344
    2e50:      	ldr	x16, [x16]
		0000000000002e50:  ARM64_RELOC_PAGEOFF12	l_stogir.344
    2e54:      	ldr	w20, [x16]
    2e58:      	lsr	w19, w19, #0
    2e5c:      	cmp	x19, x20
    2e60:      	b.eq	0x2e78 <_stogir.verify.classifications+0x2f4>
    2e64:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x1214>
		0000000000002e64:  ARM64_RELOC_PAGE21	l_stogir.345
    2e68:      	ldr	x16, [x16]
		0000000000002e68:  ARM64_RELOC_PAGEOFF12	l_stogir.345
    2e6c:      	ldr	w20, [x16]
    2e70:      	cmp	x19, x20
    2e74:      	b.ne	0x2df4 <_stogir.verify.classifications+0x270>
    2e78:      	cmp	x14, #0x1
    2e7c:      	b.ne	0x2eb8 <_stogir.verify.classifications+0x334>
    2e80:      	uxtb	w16, w27
    2e84:      	cmp	w16, wzr
    2e88:      	b.eq	0x2eb8 <_stogir.verify.classifications+0x334>
    2e8c:      	uxtb	w16, w1
    2e90:      	cmp	w16, wzr
    2e94:      	b.eq	0x2d3c <_stogir.verify.classifications+0x1b8>
    2e98:      	uxtb	w16, w2
    2e9c:      	cmp	w16, wzr
    2ea0:      	b.eq	0x2ca4 <_stogir.verify.classifications+0x120>
    2ea4:      	uxtb	w16, w12
    2ea8:      	cmp	w16, wzr
    2eac:      	b.eq	0x30ac <_stogir.verify.classifications+0x528>
    2eb0:      	mov	x13, x3
    2eb4:      	b	0x30b0 <_stogir.verify.classifications+0x52c>
    2eb8:      	cmp	x14, #0x1
    2ebc:      	b.ne	0x2f2c <_stogir.verify.classifications+0x3a8>
    2ec0:      	ldr	w15, [x24, #0x4]
    2ec4:      	sxtw	x15, w15
    2ec8:      	lsr	w15, w15, #0
    2ecc:      	sxtw	x15, w15
    2ed0:      	cmp	x15, #0x0
    2ed4:      	cset	w19, gt
    2ed8:      	movz	x16, #0x0, lsl #48
    2edc:      	sub	x20, x16, x15
    2ee0:      	sub	x21, x20, #0x1
    2ee4:      	uxtb	w16, w19
    2ee8:      	cmp	w16, wzr
    2eec:      	b.eq	0x2f40 <_stogir.verify.classifications+0x3bc>
    2ef0:      	ldr	x20, [x22, #0x8]
    2ef4:      	cmp	x15, x20
    2ef8:      	b.ge	0x2d70 <_stogir.verify.classifications+0x1ec>
    2efc:      	ldr	x20, [x6, #0x8]
    2f00:      	cmp	x15, x20
    2f04:      	b.ge	0x2d2c <_stogir.verify.classifications+0x1a8>
    2f08:      	lsl	x20, x15, #2
    2f0c:      	ldr	x20, [x22, #0x78]
    2f10:      	add	x20, x20, x15, lsl #2
    2f14:      	ldr	w20, [x20]
    2f18:      	sxtw	x20, w20
    2f1c:      	cmp	x20, #0x0
    2f20:      	cset	w20, ge
    2f24:      	ubfx	x20, x20, #0, #8
    2f28:      	b	0x2d30 <_stogir.verify.classifications+0x1ac>
    2f2c:      	cmp	x14, #0x2
    2f30:      	b.ne	0x2f84 <_stogir.verify.classifications+0x400>
    2f34:      	ldr	w15, [x24, #0x8]
    2f38:      	sxtw	x15, w15
    2f3c:      	b	0x2ec8 <_stogir.verify.classifications+0x344>
    2f40:      	cmp	x15, #0x0
    2f44:      	b.ge	0x2d78 <_stogir.verify.classifications+0x1f4>
    2f48:      	ldr	x26, [x7, #0x8]
    2f4c:      	ldr	x28, [x8, #0x8]
    2f50:      	cmp	x26, x28
    2f54:      	b.ne	0x2d34 <_stogir.verify.classifications+0x1b0>
    2f58:      	cmp	x20, x26
    2f5c:      	b.gt	0x2c9c <_stogir.verify.classifications+0x118>
    2f60:      	lsl	x20, x21, #2
    2f64:      	ldr	x20, [x22, #0x50]
    2f68:      	add	x20, x20, x21, lsl #2
    2f6c:      	ldr	w20, [x20]
    2f70:      	sxtw	x20, w20
    2f74:      	cmp	x20, #0x0
    2f78:      	cset	w20, gt
    2f7c:      	ubfx	x20, x20, #0, #8
    2f80:      	b	0x2ca0 <_stogir.verify.classifications+0x11c>
    2f84:      	cmp	x14, #0x3
    2f88:      	b.ne	0x2ffc <_stogir.verify.classifications+0x478>
    2f8c:      	ldr	w15, [x24, #0xc]
    2f90:      	sxtw	x15, w15
    2f94:      	b	0x2f3c <_stogir.verify.classifications+0x3b8>
    2f98:      	uxtb	w13, w13
    2f9c:      	uxtb	w0, w0
    2fa0:      	add	x16, sp, #0x10
    2fa4:      	movz	w17, #0x0, lsl #16
    2fa8:      	strh	w17, [x16]
    2fac:      	add	x16, sp, #0x10
    2fb0:      	strb	w13, [x16]
    2fb4:      	add	x16, sp, #0x10
    2fb8:      	strb	w0, [x16, #0x1]
    2fbc:      	add	x16, sp, #0x10
    2fc0:      	ldrh	w0, [x16]
    2fc4:      	ldr	x19, [sp, #0x20]
    2fc8:      	ldr	x20, [sp, #0x28]
    2fcc:      	ldr	x21, [sp, #0x30]
    2fd0:      	ldr	x22, [sp, #0x38]
    2fd4:      	ldr	x23, [sp, #0x40]
    2fd8:      	ldr	x24, [sp, #0x48]
    2fdc:      	ldr	x25, [sp, #0x50]
    2fe0:      	ldr	x26, [sp, #0x58]
    2fe4:      	ldr	x27, [sp, #0x60]
    2fe8:      	ldr	x28, [sp, #0x68]
    2fec:      	ldr	x29, [sp]
    2ff0:      	ldr	x30, [sp, #0x8]
    2ff4:      	add	sp, sp, #0x70
    2ff8:      	ret
    2ffc:      	uxtb	w16, w10
    3000:      	cmp	w16, wzr
    3004:      	b.ne	0x30c4 <_stogir.verify.classifications+0x540>
    3008:      	ldr	x19, [x22, #0x8]
    300c:      	cmp	x23, x19
    3010:      	b.ge	0x30c4 <_stogir.verify.classifications+0x540>
    3014:      	ldr	x19, [x9, #0x8]
    3018:      	cmp	x23, x19
    301c:      	b.ge	0x30c4 <_stogir.verify.classifications+0x540>
    3020:      	ldr	x19, [x22, #0x78]
    3024:      	add	x19, x11, x19
    3028:      	ldr	w19, [x19]
    302c:      	sxtw	x19, w19
    3030:      	cmp	x19, #0x0
    3034:      	b.lt	0x30c4 <_stogir.verify.classifications+0x540>
    3038:      	cmp	x15, #0x1
    303c:      	b.lt	0x3144 <_stogir.verify.classifications+0x5c0>
    3040:      	ldr	x19, [x22, #0x78]
    3044:      	add	x19, x11, x19
    3048:      	ldr	w19, [x19]
    304c:      	sxtw	x19, w19
    3050:      	cmp	x15, x19
    3054:      	b.gt	0x3144 <_stogir.verify.classifications+0x5c0>
    3058:      	ldr	x19, [x22]
    305c:      	asr	x16, x15, #63
    3060:      	lsr	x16, x16, #62
    3064:      	add	x20, x15, x16
    3068:      	asr	x20, x20, #2
    306c:      	asr	x16, x15, #63
    3070:      	lsr	x16, x16, #62
    3074:      	add	x15, x15, x16
    3078:      	and	x15, x15, #0x3
    307c:      	sub	x15, x15, x16
    3080:      	add	x20, x20, x23
    3084:      	lsl	x21, x15, #2
    3088:      	lsl	x21, x20, #4
    308c:      	add	x19, x19, x20, lsl #4
    3090:      	add	x15, x19, x15, lsl #2
    3094:      	ldr	w15, [x15]
    3098:      	sxtw	x15, w15
    309c:      	and	x15, x15, #0xffffffff
    30a0:      	mov	x19, x15
    30a4:      	mov	x15, #0x1               ; =1
    30a8:      	b	0x314c <_stogir.verify.classifications+0x5c8>
    30ac:      	movz	x13, #0x0, lsl #48
    30b0:      	b	0x2ca8 <_stogir.verify.classifications+0x124>
    30b4:      	lsr	w19, w19, #0
    30b8:      	sxtw	x19, w19
    30bc:      	mov	x15, x19
    30c0:      	b	0x2f94 <_stogir.verify.classifications+0x410>
    30c4:      	movz	x15, #0x0, lsl #48
    30c8:      	movz	x19, #0x0, lsl #48
    30cc:      	lsr	w15, w15, #0
    30d0:      	lsr	x16, x15, #0
    30d4:      	cmp	x16, #0x1
    30d8:      	b.eq	0x30f4 <_stogir.verify.classifications+0x570>
    30dc:      	b.lo	0x30e4 <_stogir.verify.classifications+0x560>
    30e0:      	b	0x30f8 <_stogir.verify.classifications+0x574>
    30e4:      	cmp	x16, #0x0
    30e8:      	b.eq	0x30f0 <_stogir.verify.classifications+0x56c>
    30ec:      	b	0x30f8 <_stogir.verify.classifications+0x574>
    30f0:      	b	0x30fc <_stogir.verify.classifications+0x578>
    30f4:      	b	0x30b4 <_stogir.verify.classifications+0x530>
    30f8:      	b	0x3160 <_stogir.verify.classifications+0x5dc>
    30fc:      	movz	x15, #0x0, lsl #48
    3100:      	b	0x30c0 <_stogir.verify.classifications+0x53c>
    3104:      	cmp	x19, #0x18
    3108:      	b.ne	0x3114 <_stogir.verify.classifications+0x590>
    310c:      	mov	x0, #0x1                ; =1
    3110:      	b	0x2c98 <_stogir.verify.classifications+0x114>
    3114:      	cmp	x19, #0x19
    3118:      	b.ne	0x3124 <_stogir.verify.classifications+0x5a0>
    311c:      	mov	x0, #0x1                ; =1
    3120:      	b	0x2c98 <_stogir.verify.classifications+0x114>
    3124:      	cmp	x21, #0xc
    3128:      	b.eq	0x2c94 <_stogir.verify.classifications+0x110>
    312c:      	cmp	x21, #0xd
    3130:      	b.eq	0x2c94 <_stogir.verify.classifications+0x110>
    3134:      	cmp	x28, #0xc
    3138:      	b.ne	0x3150 <_stogir.verify.classifications+0x5cc>
    313c:      	mov	x0, #0x1                ; =1
    3140:      	b	0x315c <_stogir.verify.classifications+0x5d8>
    3144:      	movz	x15, #0x0, lsl #48
    3148:      	movz	x19, #0x0, lsl #48
    314c:      	b	0x30cc <_stogir.verify.classifications+0x548>
    3150:      	cmp	x28, #0xd
    3154:      	cset	w0, eq
    3158:      	ubfx	x0, x0, #0, #8
    315c:      	b	0x2c98 <_stogir.verify.classifications+0x114>
    3160:      	brk	#0
    3164:      	b	0x3160 <_stogir.verify.classifications+0x5dc>

0000000000003168 <_stogir.vector-lanes.operation?>:
    3168:      	sxtw	x0, w0
    316c:      	cmp	x0, #0x3d
    3170:      	b.lt	0x3184 <_stogir.vector-lanes.operation?+0x1c>
    3174:      	cmp	x0, #0x3f
    3178:      	cset	w0, le
    317c:      	ubfx	x0, x0, #0, #8
    3180:      	b	0x3188 <_stogir.vector-lanes.operation?+0x20>
    3184:      	movz	x0, #0x0, lsl #48
    3188:      	ret
    318c:      	udf	#0x0

0000000000003190 <_stogir.vector.validate>:
    3190:      	sub	sp, sp, #0x210
    3194:      	str	x29, [sp]
    3198:      	str	x30, [sp, #0x8]
    319c:      	mov	x29, sp
    31a0:      	str	x19, [sp, #0x1c0]
    31a4:      	str	x20, [sp, #0x1c8]
    31a8:      	str	x21, [sp, #0x1d0]
    31ac:      	str	x22, [sp, #0x1d8]
    31b0:      	str	x23, [sp, #0x1e0]
    31b4:      	str	x24, [sp, #0x1e8]
    31b8:      	str	x25, [sp, #0x1f0]
    31bc:      	str	x26, [sp, #0x1f8]
    31c0:      	str	x27, [sp, #0x200]
    31c4:      	str	x28, [sp, #0x208]
    31c8:      	lsr	w19, w1, #0
    31cc:      	mov	x20, x8
    31d0:      	add	x8, sp, #0x10
    31d4:      	mov	x21, x0
    31d8:      	mov	w22, w1
    31dc:      	mov	w1, w19
    31e0:      	mov	w23, w2
    31e4:      	bl	0x31e4 <_stogir.vector.validate+0x54>
		00000000000031e4:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    31e8:      	add	x16, sp, #0x10
    31ec:      	ldr	w0, [x16]
    31f0:      	lsr	x16, x0, #0
    31f4:      	cmp	x16, #0x1
    31f8:      	b.eq	0x3214 <_stogir.vector.validate+0x84>
    31fc:      	b.lo	0x3204 <_stogir.vector.validate+0x74>
    3200:      	b	0x3218 <_stogir.vector.validate+0x88>
    3204:      	cmp	x16, #0x0
    3208:      	b.eq	0x3210 <_stogir.vector.validate+0x80>
    320c:      	b	0x3218 <_stogir.vector.validate+0x88>
    3210:      	b	0x321c <_stogir.vector.validate+0x8c>
    3214:      	b	0x32b4 <_stogir.vector.validate+0x124>
    3218:      	b	0x34d4 <_stogir.vector.validate+0x344>
    321c:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x47c>
		000000000000321c:  ARM64_RELOC_PAGE21	l_stogir.346
    3220:      	ldr	x16, [x16]
		0000000000003220:  ARM64_RELOC_PAGEOFF12	l_stogir.346
    3224:      	orr	x0, x16, xzr
    3228:      	str	x20, [sp, #0x1a8]
    322c:      	mov	x1, x0
    3230:      	mov	x0, #0x1                ; =1
    3234:      	mov	x2, #0x1a               ; =26
    3238:      	b	0x326c <_stogir.vector.validate+0xdc>
    323c:      	lsr	w23, w23, #0
    3240:      	add	x8, sp, #0x70
    3244:      	mov	x0, x21
    3248:      	ldr	w1, [sp, #0x1a0]
    324c:      	mov	w2, w23
    3250:      	bl	0x3250 <_stogir.vector.validate+0xc0>
		0000000000003250:  ARM64_RELOC_BRANCH26	_stogir.conversion.validate
    3254:      	add	x16, sp, #0x70
    3258:      	ldr	x0, [x16]
    325c:      	add	x16, sp, #0x70
    3260:      	ldr	x1, [x16, #0x8]
    3264:      	add	x16, sp, #0x70
    3268:      	ldr	x2, [x16, #0x10]
    326c:      	ldr	x3, [sp, #0x1a8]
    3270:      	str	x0, [x3]
    3274:      	str	x1, [x3, #0x8]
    3278:      	str	x2, [x3, #0x10]
    327c:      	ldr	x19, [sp, #0x1c0]
    3280:      	ldr	x20, [sp, #0x1c8]
    3284:      	ldr	x21, [sp, #0x1d0]
    3288:      	ldr	x22, [sp, #0x1d8]
    328c:      	ldr	x23, [sp, #0x1e0]
    3290:      	ldr	x24, [sp, #0x1e8]
    3294:      	ldr	x25, [sp, #0x1f0]
    3298:      	ldr	x26, [sp, #0x1f8]
    329c:      	ldr	x27, [sp, #0x200]
    32a0:      	ldr	x28, [sp, #0x208]
    32a4:      	ldr	x29, [sp]
    32a8:      	ldr	x30, [sp, #0x8]
    32ac:      	add	sp, sp, #0x210
    32b0:      	ret
    32b4:      	sxtw	x22, w22
    32b8:      	add	x16, sp, #0x10
    32bc:      	orr	x0, x16, xzr
    32c0:      	cmp	x22, #0x0
    32c4:      	cset	w24, le
    32c8:      	add	x0, x0, #0x8
    32cc:      	add	x16, sp, #0x10
    32d0:      	ldr	x25, [x16, #0x8]
    32d4:      	add	x16, sp, #0x40
    32d8:      	str	x25, [x16]
    32dc:      	ldr	x0, [x0, #0x8]
    32e0:      	add	x16, sp, #0x40
    32e4:      	str	x0, [x16, #0x8]
    32e8:      	uxtb	w16, w24
    32ec:      	cmp	w16, wzr
    32f0:      	b.eq	0x3314 <_stogir.vector.validate+0x184>
    32f4:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x47c>
		00000000000032f4:  ARM64_RELOC_PAGE21	l_stogir.347
    32f8:      	ldr	x16, [x16]
		00000000000032f8:  ARM64_RELOC_PAGEOFF12	l_stogir.347
    32fc:      	orr	x0, x16, xzr
    3300:      	str	x20, [sp, #0x1a8]
    3304:      	mov	x1, x0
    3308:      	mov	x0, #0x1                ; =1
    330c:      	mov	x2, #0x3b               ; =59
    3310:      	b	0x326c <_stogir.vector.validate+0xdc>
    3314:      	lsl	x26, x22, #2
    3318:      	uxtb	w0, w25
    331c:      	orr	x27, x0, xzr
    3320:      	ldr	x0, [x21, #0x78]
    3324:      	cmp	x27, #0x44
    3328:      	cset	w1, eq
    332c:      	add	x0, x0, x22, lsl #2
    3330:      	ldr	w28, [x0]
    3334:      	cmp	x27, #0x24
    3338:      	b.ne	0x337c <_stogir.vector.validate+0x1ec>
    333c:      	str	x20, [sp, #0x1a8]
    3340:      	str	w19, [sp, #0x1a0]
    3344:      	uxtb	w16, w1
    3348:      	cmp	w16, wzr
    334c:      	b.eq	0x323c <_stogir.vector.validate+0xac>
    3350:      	add	x8, sp, #0x50
    3354:      	mov	x0, x21
    3358:      	ldr	w1, [sp, #0x1a0]
    335c:      	bl	0x335c <_stogir.vector.validate+0x1cc>
		000000000000335c:  ARM64_RELOC_BRANCH26	_stogir.copy.validate
    3360:      	add	x16, sp, #0x50
    3364:      	ldr	x0, [x16]
    3368:      	add	x16, sp, #0x50
    336c:      	ldr	x1, [x16, #0x8]
    3370:      	add	x16, sp, #0x50
    3374:      	ldr	x2, [x16, #0x10]
    3378:      	b	0x326c <_stogir.vector.validate+0xdc>
    337c:      	uxtb	w16, w1
    3380:      	cmp	w16, wzr
    3384:      	b.ne	0x3c4c <_stogir.vector.validate+0xabc>
    3388:      	cmp	x27, #0x3c
    338c:      	b.ne	0x3440 <_stogir.vector.validate+0x2b0>
    3390:      	add	x8, sp, #0x90
    3394:      	mov	x0, x21
    3398:      	mov	w1, w19
    339c:      	bl	0x339c <_stogir.vector.validate+0x20c>
		000000000000339c:  ARM64_RELOC_BRANCH26	_stogir.conditional.validate
    33a0:      	add	x16, sp, #0x90
    33a4:      	ldr	x0, [x16]
    33a8:      	add	x16, sp, #0x90
    33ac:      	ldr	x1, [x16, #0x8]
    33b0:      	add	x16, sp, #0x90
    33b4:      	ldr	x2, [x16, #0x10]
    33b8:      	str	x20, [sp, #0x1a8]
    33bc:      	b	0x343c <_stogir.vector.validate+0x2ac>
    33c0:      	cmp	x27, #0x41
    33c4:      	cset	w0, eq
    33c8:      	cmp	x27, #0x48
    33cc:      	cset	w1, eq
    33d0:      	cmp	x27, #0x55
    33d4:      	cset	w2, ge
    33d8:      	cmp	x27, #0x58
    33dc:      	cset	w3, le
    33e0:      	cmp	x27, #0x47
    33e4:      	b.ne	0x34dc <_stogir.vector.validate+0x34c>
    33e8:      	str	x20, [sp, #0x1a8]
    33ec:      	str	w19, [sp, #0x1a0]
    33f0:      	mov	w19, w0
    33f4:      	mov	w20, w1
    33f8:      	str	w2, [sp, #0x1b0]
    33fc:      	str	w3, [sp, #0x1b8]
    3400:      	mov	x0, x21
    3404:      	ldr	w1, [sp, #0x1a0]
    3408:      	bl	0x3408 <_stogir.vector.validate+0x278>
		0000000000003408:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.node?
    340c:      	cmp	x0, #0x0
    3410:      	b.eq	0x3500 <_stogir.vector.validate+0x370>
    3414:      	add	x8, sp, #0xf0
    3418:      	mov	x0, x21
    341c:      	ldr	w1, [sp, #0x1a0]
    3420:      	bl	0x3420 <_stogir.vector.validate+0x290>
		0000000000003420:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.validate
    3424:      	add	x16, sp, #0xf0
    3428:      	ldr	x0, [x16]
    342c:      	add	x16, sp, #0xf0
    3430:      	ldr	x1, [x16, #0x8]
    3434:      	add	x16, sp, #0xf0
    3438:      	ldr	x2, [x16, #0x10]
    343c:      	b	0x326c <_stogir.vector.validate+0xdc>
    3440:      	cmp	x27, #0x3d
    3444:      	b.lt	0x3488 <_stogir.vector.validate+0x2f8>
    3448:      	cmp	x27, #0x3f
    344c:      	b.gt	0x3488 <_stogir.vector.validate+0x2f8>
    3450:      	lsr	w23, w23, #0
    3454:      	add	x8, sp, #0xb0
    3458:      	mov	x0, x21
    345c:      	mov	w1, w19
    3460:      	mov	w2, w23
    3464:      	bl	0x3464 <_stogir.vector.validate+0x2d4>
		0000000000003464:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.validate
    3468:      	add	x16, sp, #0xb0
    346c:      	ldr	x0, [x16]
    3470:      	add	x16, sp, #0xb0
    3474:      	ldr	x1, [x16, #0x8]
    3478:      	add	x16, sp, #0xb0
    347c:      	ldr	x2, [x16, #0x10]
    3480:      	str	x20, [sp, #0x1a8]
    3484:      	b	0x343c <_stogir.vector.validate+0x2ac>
    3488:      	mov	x0, x21
    348c:      	mov	w1, w19
    3490:      	bl	0x3490 <_stogir.vector.validate+0x300>
		0000000000003490:  ARM64_RELOC_BRANCH26	_stogir.vector-comparison.node?
    3494:      	cmp	x0, #0x0
    3498:      	b.eq	0x33c0 <_stogir.vector.validate+0x230>
    349c:      	lsr	w23, w23, #0
    34a0:      	add	x8, sp, #0xd0
    34a4:      	mov	x0, x21
    34a8:      	mov	w1, w19
    34ac:      	mov	w2, w23
    34b0:      	bl	0x34b0 <_stogir.vector.validate+0x320>
		00000000000034b0:  ARM64_RELOC_BRANCH26	_stogir.vector-comparison.validate
    34b4:      	add	x16, sp, #0xd0
    34b8:      	ldr	x0, [x16]
    34bc:      	add	x16, sp, #0xd0
    34c0:      	ldr	x1, [x16, #0x8]
    34c4:      	add	x16, sp, #0xd0
    34c8:      	ldr	x2, [x16, #0x10]
    34cc:      	str	x20, [sp, #0x1a8]
    34d0:      	b	0x343c <_stogir.vector.validate+0x2ac>
    34d4:      	brk	#0
    34d8:      	b	0x34d4 <_stogir.vector.validate+0x344>
    34dc:      	cmp	x27, #0x4f
    34e0:      	b.ne	0x357c <_stogir.vector.validate+0x3ec>
    34e4:      	str	x20, [sp, #0x1a8]
    34e8:      	str	w19, [sp, #0x1a0]
    34ec:      	mov	w19, w0
    34f0:      	mov	w20, w1
    34f4:      	str	w2, [sp, #0x1b0]
    34f8:      	str	w3, [sp, #0x1b8]
    34fc:      	b	0x3400 <_stogir.vector.validate+0x270>
    3500:      	uxtb	w16, w19
    3504:      	cmp	w16, wzr
    3508:      	b.ne	0x3548 <_stogir.vector.validate+0x3b8>
    350c:      	uxtb	w16, w20
    3510:      	cmp	w16, wzr
    3514:      	b.ne	0x3548 <_stogir.vector.validate+0x3b8>
    3518:      	ldr	w0, [sp, #0x1b0]
    351c:      	uxtb	w16, w0
    3520:      	cmp	w16, wzr
    3524:      	b.eq	0x3538 <_stogir.vector.validate+0x3a8>
    3528:      	ldr	w0, [sp, #0x1b8]
    352c:      	uxtb	w16, w0
    3530:      	cmp	w16, wzr
    3534:      	b.ne	0x3548 <_stogir.vector.validate+0x3b8>
    3538:      	movz	x0, #0x0, lsl #48
    353c:      	movz	x1, #0x0, lsl #48
    3540:      	movz	x2, #0x0, lsl #48
    3544:      	b	0x3578 <_stogir.vector.validate+0x3e8>
    3548:      	lsr	w23, w23, #0
    354c:      	add	x8, sp, #0x110
    3550:      	mov	x0, x21
    3554:      	ldr	w1, [sp, #0x1a0]
    3558:      	mov	w2, w23
    355c:      	bl	0x355c <_stogir.vector.validate+0x3cc>
		000000000000355c:  ARM64_RELOC_BRANCH26	_stogir.locals.validate
    3560:      	add	x16, sp, #0x110
    3564:      	ldr	x0, [x16]
    3568:      	add	x16, sp, #0x110
    356c:      	ldr	x1, [x16, #0x8]
    3570:      	add	x16, sp, #0x110
    3574:      	ldr	x2, [x16, #0x10]
    3578:      	b	0x343c <_stogir.vector.validate+0x2ac>
    357c:      	cmp	x27, #0x50
    3580:      	b.eq	0x3c58 <_stogir.vector.validate+0xac8>
    3584:      	cmp	x27, #0x78
    3588:      	b.ne	0x35a8 <_stogir.vector.validate+0x418>
    358c:      	str	x20, [sp, #0x1a8]
    3590:      	str	w19, [sp, #0x1a0]
    3594:      	mov	w19, w0
    3598:      	mov	w20, w1
    359c:      	str	w2, [sp, #0x1b0]
    35a0:      	str	w3, [sp, #0x1b8]
    35a4:      	b	0x3400 <_stogir.vector.validate+0x270>
    35a8:      	uxtb	w16, w0
    35ac:      	cmp	w16, wzr
    35b0:      	b.ne	0x36b0 <_stogir.vector.validate+0x520>
    35b4:      	uxtb	w16, w1
    35b8:      	cmp	w16, wzr
    35bc:      	b.ne	0x36b0 <_stogir.vector.validate+0x520>
    35c0:      	uxtb	w16, w2
    35c4:      	cmp	w16, wzr
    35c8:      	b.eq	0x35d8 <_stogir.vector.validate+0x448>
    35cc:      	uxtb	w16, w3
    35d0:      	cmp	w16, wzr
    35d4:      	b.ne	0x36b0 <_stogir.vector.validate+0x520>
    35d8:      	str	w2, [sp, #0x1b0]
    35dc:      	str	w3, [sp, #0x1b8]
    35e0:      	str	w19, [sp, #0x1a0]
    35e4:      	str	x20, [sp, #0x1a8]
    35e8:      	mov	w20, w1
    35ec:      	mov	w1, w19
    35f0:      	mov	w19, w0
    35f4:      	mov	x0, x21
    35f8:      	bl	0x35f8 <_stogir.vector.validate+0x468>
		00000000000035f8:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.node?
    35fc:      	cmp	x0, #0x0
    3600:      	b.ne	0x3400 <_stogir.vector.validate+0x270>
    3604:      	sxtw	x28, w28
    3608:      	lsr	w25, w25, #0
    360c:      	ubfx	x0, x25, #8, #8
    3610:      	orr	x1, x0, xzr
    3614:      	lsr	w19, w1, #0
    3618:      	cmp	x27, #0x5b
    361c:      	b.eq	0x36e8 <_stogir.vector.validate+0x558>
    3620:      	cmp	x27, #0x5c
    3624:      	b.eq	0x36e8 <_stogir.vector.validate+0x558>
    3628:      	orr	x20, x0, xzr
    362c:      	cmp	x27, #0x5d
    3630:      	b.eq	0x3760 <_stogir.vector.validate+0x5d0>
    3634:      	cmp	x27, #0x5e
    3638:      	b.eq	0x3760 <_stogir.vector.validate+0x5d0>
    363c:      	cmp	x27, #0x43
    3640:      	b.ne	0x37dc <_stogir.vector.validate+0x64c>
    3644:      	cmp	x20, #0xf
    3648:      	b.le	0x3b00 <_stogir.vector.validate+0x970>
    364c:      	cmp	x20, #0x80
    3650:      	b.ge	0x3b00 <_stogir.vector.validate+0x970>
    3654:      	and	x0, x20, #0xf
    3658:      	lsr	w0, w0, #0
    365c:      	sxtw	x0, w0
    3660:      	cmp	x0, #0x1
    3664:      	b.lt	0x3b00 <_stogir.vector.validate+0x970>
    3668:      	cmp	x0, #0xd
    366c:      	b.gt	0x3b00 <_stogir.vector.validate+0x970>
    3670:      	lsr	w23, w23, #0
    3674:      	mov	w0, w19
    3678:      	mov	w1, w23
    367c:      	bl	0x367c <_stogir.vector.validate+0x4ec>
		000000000000367c:  ARM64_RELOC_BRANCH26	_stogir.types.size
    3680:      	lsr	w0, w0, #0
    3684:      	sxtw	x0, w0
    3688:      	cmp	x0, #0x0
    368c:      	b.le	0x3b00 <_stogir.vector.validate+0x970>
    3690:      	cmp	x28, #0x3
    3694:      	b.lt	0x3b00 <_stogir.vector.validate+0x970>
    3698:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x47c>
		0000000000003698:  ARM64_RELOC_PAGE21	l_stogir.348
    369c:      	ldr	x16, [x16]
		000000000000369c:  ARM64_RELOC_PAGEOFF12	l_stogir.348
    36a0:      	orr	x0, x16, xzr
    36a4:      	mov	x25, x0
    36a8:      	movz	x27, #0x0, lsl #48
    36ac:      	b	0x3b14 <_stogir.vector.validate+0x984>
    36b0:      	str	x20, [sp, #0x1a8]
    36b4:      	str	w19, [sp, #0x1a0]
    36b8:      	mov	w19, w0
    36bc:      	mov	w20, w1
    36c0:      	str	w2, [sp, #0x1b0]
    36c4:      	str	w3, [sp, #0x1b8]
    36c8:      	b	0x3400 <_stogir.vector.validate+0x270>
    36cc:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x47c>
		00000000000036cc:  ARM64_RELOC_PAGE21	l_stogir.349
    36d0:      	ldr	x16, [x16]
		00000000000036d0:  ARM64_RELOC_PAGEOFF12	l_stogir.349
    36d4:      	orr	x0, x16, xzr
    36d8:      	mov	x1, x0
    36dc:      	mov	x0, #0x1                ; =1
    36e0:      	mov	x2, #0x19               ; =25
    36e4:      	b	0x343c <_stogir.vector.validate+0x2ac>
    36e8:      	cmp	x28, #0x2
    36ec:      	b.ne	0x36cc <_stogir.vector.validate+0x53c>
    36f0:      	lsr	w23, w23, #0
    36f4:      	add	x16, sp, #0x40
    36f8:      	ldr	w0, [x16, #0x4]
    36fc:      	add	x16, sp, #0x40
    3700:      	ldr	w1, [x16, #0x8]
    3704:      	lsr	w0, w0, #0
    3708:      	lsr	w1, w1, #0
    370c:      	add	x8, sp, #0x130
    3710:      	mov	w2, w23
    3714:      	mov	w3, w0
    3718:      	mov	x0, x21
    371c:      	mov	w4, w1
    3720:      	mov	w1, w19
    3724:      	bl	0x3724 <_stogir.vector.validate+0x594>
		0000000000003724:  ARM64_RELOC_BRANCH26	_stogir.vector.memory-inputs
    3728:      	add	x16, sp, #0x130
    372c:      	ldr	x0, [x16]
    3730:      	add	x16, sp, #0x130
    3734:      	ldr	x1, [x16, #0x8]
    3738:      	add	x16, sp, #0x130
    373c:      	ldr	x2, [x16, #0x10]
    3740:      	b	0x36e4 <_stogir.vector.validate+0x554>
    3744:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x47c>
		0000000000003744:  ARM64_RELOC_PAGE21	l_stogir.350
    3748:      	ldr	x16, [x16]
		0000000000003748:  ARM64_RELOC_PAGEOFF12	l_stogir.350
    374c:      	orr	x0, x16, xzr
    3750:      	mov	x1, x0
    3754:      	mov	x0, #0x1                ; =1
    3758:      	mov	x2, #0x1a               ; =26
    375c:      	b	0x36e4 <_stogir.vector.validate+0x554>
    3760:      	cmp	x28, #0x3
    3764:      	b.ne	0x3744 <_stogir.vector.validate+0x5b4>
    3768:      	cmp	x20, #0x0
    376c:      	b.ne	0x3744 <_stogir.vector.validate+0x5b4>
    3770:      	lsr	w23, w23, #0
    3774:      	add	x16, sp, #0x40
    3778:      	ldr	w0, [x16, #0x4]
    377c:      	add	x16, sp, #0x40
    3780:      	ldr	w1, [x16, #0x8]
    3784:      	lsr	w0, w0, #0
    3788:      	add	x16, sp, #0x40
    378c:      	ldr	w2, [x16, #0xc]
    3790:      	lsr	w1, w1, #0
    3794:      	lsr	w2, w2, #0
    3798:      	add	x8, sp, #0x150
    379c:      	mov	w3, w1
    37a0:      	mov	w1, w23
    37a4:      	mov	w4, w2
    37a8:      	mov	w2, w0
    37ac:      	mov	x0, x21
    37b0:      	bl	0x37b0 <_stogir.vector.validate+0x620>
		00000000000037b0:  ARM64_RELOC_BRANCH26	_stogir.vector.store-inputs
    37b4:      	add	x16, sp, #0x150
    37b8:      	ldr	x0, [x16]
    37bc:      	add	x16, sp, #0x150
    37c0:      	ldr	x1, [x16, #0x8]
    37c4:      	add	x16, sp, #0x150
    37c8:      	ldr	x2, [x16, #0x10]
    37cc:      	b	0x375c <_stogir.vector.validate+0x5cc>
    37d0:      	mov	x2, x8
    37d4:      	mov	x0, #0x1                ; =1
    37d8:      	b	0x375c <_stogir.vector.validate+0x5cc>
    37dc:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x47c>
		00000000000037dc:  ARM64_RELOC_PAGE21	l_stogir.351
    37e0:      	ldr	x16, [x16]
		00000000000037e0:  ARM64_RELOC_PAGEOFF12	l_stogir.351
    37e4:      	orr	x0, x16, xzr
    37e8:      	mov	x1, x0
    37ec:      	mov	x0, #0x1                ; =1
    37f0:      	mov	x2, #0x28               ; =40
    37f4:      	b	0x37d8 <_stogir.vector.validate+0x648>
    37f8:      	mov	x0, x1
    37fc:      	mov	x1, x27
    3800:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x47c>
		0000000000003800:  ARM64_RELOC_PAGE21	l_stogir.352
    3804:      	ldr	x16, [x16]
		0000000000003804:  ARM64_RELOC_PAGEOFF12	l_stogir.352
    3808:      	orr	x2, x16, xzr
    380c:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x47c>
		000000000000380c:  ARM64_RELOC_PAGE21	l_stogir.353
    3810:      	ldr	x16, [x16]
		0000000000003810:  ARM64_RELOC_PAGEOFF12	l_stogir.353
    3814:      	orr	x3, x16, xzr
    3818:      	add	x4, x21, #0x78
    381c:      	add	x5, x21, #0x28
    3820:      	add	x6, x21, #0x50
    3824:      	add	x7, x21, #0x78
    3828:      	mov	x8, x1
    382c:      	mov	x1, x0
    3830:      	mov	x0, #0x2                ; =2
    3834:      	b	0x38ac <_stogir.vector.validate+0x71c>
    3838:      	lsr	w10, w10, #0
    383c:      	ubfx	x9, x10, #8, #8
    3840:      	cmp	x9, x20
    3844:      	b.eq	0x3850 <_stogir.vector.validate+0x6c0>
    3848:      	mov	x1, x3
    384c:      	mov	x8, #0x1e               ; =30
    3850:      	b	0x38a0 <_stogir.vector.validate+0x710>
    3854:      	movz	x9, #0x0, lsl #48
    3858:      	movz	x10, #0x0, lsl #48
    385c:      	b	0x3868 <_stogir.vector.validate+0x6d8>
    3860:      	movz	x9, #0x0, lsl #48
    3864:      	movz	x10, #0x0, lsl #48
    3868:      	lsr	w9, w9, #0
    386c:      	lsr	x16, x9, #0
    3870:      	cmp	x16, #0x1
    3874:      	b.eq	0x3890 <_stogir.vector.validate+0x700>
    3878:      	b.lo	0x3880 <_stogir.vector.validate+0x6f0>
    387c:      	b	0x3894 <_stogir.vector.validate+0x704>
    3880:      	cmp	x16, #0x0
    3884:      	b.eq	0x388c <_stogir.vector.validate+0x6fc>
    3888:      	b	0x3894 <_stogir.vector.validate+0x704>
    388c:      	b	0x3898 <_stogir.vector.validate+0x708>
    3890:      	b	0x3900 <_stogir.vector.validate+0x770>
    3894:      	b	0x3c34 <_stogir.vector.validate+0xaa4>
    3898:      	mov	x1, x2
    389c:      	mov	x8, #0x18               ; =24
    38a0:      	add	x0, x0, #0x1
    38a4:      	lsr	w0, w0, #0
    38a8:      	sxtw	x0, w0
    38ac:      	cmp	x8, #0x0
    38b0:      	b.ne	0x3a38 <_stogir.vector.validate+0x8a8>
    38b4:      	cmp	x0, x28
    38b8:      	b.gt	0x3a38 <_stogir.vector.validate+0x8a8>
    38bc:      	uxtb	w16, w24
    38c0:      	cmp	w16, wzr
    38c4:      	b.ne	0x3860 <_stogir.vector.validate+0x6d0>
    38c8:      	ldr	x9, [x21, #0x8]
    38cc:      	cmp	x22, x9
    38d0:      	b.ge	0x396c <_stogir.vector.validate+0x7dc>
    38d4:      	ldr	x9, [x7, #0x8]
    38d8:      	cmp	x22, x9
    38dc:      	b.ge	0x3964 <_stogir.vector.validate+0x7d4>
    38e0:      	ldr	x9, [x21, #0x78]
    38e4:      	add	x9, x26, x9
    38e8:      	ldr	w9, [x9]
    38ec:      	sxtw	x9, w9
    38f0:      	cmp	x9, #0x0
    38f4:      	cset	w9, ge
    38f8:      	ubfx	x9, x9, #0, #8
    38fc:      	b	0x3968 <_stogir.vector.validate+0x7d8>
    3900:      	lsr	w10, w10, #0
    3904:      	sxtw	x10, w10
    3908:      	cmp	x10, #0x0
    390c:      	cset	w9, gt
    3910:      	movz	x16, #0x0, lsl #48
    3914:      	sub	x11, x16, x10
    3918:      	sub	x12, x11, #0x1
    391c:      	uxtb	w16, w9
    3920:      	cmp	w16, wzr
    3924:      	b.eq	0x39f4 <_stogir.vector.validate+0x864>
    3928:      	ldr	x11, [x21, #0x8]
    392c:      	cmp	x10, x11
    3930:      	b.ge	0x3a6c <_stogir.vector.validate+0x8dc>
    3934:      	ldr	x11, [x4, #0x8]
    3938:      	cmp	x10, x11
    393c:      	b.ge	0x3b80 <_stogir.vector.validate+0x9f0>
    3940:      	lsl	x11, x10, #2
    3944:      	ldr	x11, [x21, #0x78]
    3948:      	add	x11, x11, x10, lsl #2
    394c:      	ldr	w11, [x11]
    3950:      	sxtw	x11, w11
    3954:      	cmp	x11, #0x0
    3958:      	cset	w11, ge
    395c:      	ubfx	x11, x11, #0, #8
    3960:      	b	0x3b84 <_stogir.vector.validate+0x9f4>
    3964:      	movz	x9, #0x0, lsl #48
    3968:      	b	0x3970 <_stogir.vector.validate+0x7e0>
    396c:      	movz	x9, #0x0, lsl #48
    3970:      	cmp	x9, #0x0
    3974:      	b.eq	0x3860 <_stogir.vector.validate+0x6d0>
    3978:      	lsr	w9, w0, #0
    397c:      	sxtw	x9, w9
    3980:      	cmp	x9, #0x1
    3984:      	b.lt	0x3854 <_stogir.vector.validate+0x6c4>
    3988:      	ldr	x10, [x21, #0x78]
    398c:      	add	x10, x26, x10
    3990:      	ldr	w10, [x10]
    3994:      	sxtw	x10, w10
    3998:      	cmp	x9, x10
    399c:      	b.gt	0x3854 <_stogir.vector.validate+0x6c4>
    39a0:      	ldr	x10, [x21]
    39a4:      	asr	x16, x9, #63
    39a8:      	lsr	x16, x16, #62
    39ac:      	add	x11, x9, x16
    39b0:      	asr	x11, x11, #2
    39b4:      	asr	x16, x9, #63
    39b8:      	lsr	x16, x16, #62
    39bc:      	add	x9, x9, x16
    39c0:      	and	x9, x9, #0x3
    39c4:      	sub	x9, x9, x16
    39c8:      	add	x11, x11, x22
    39cc:      	lsl	x12, x9, #2
    39d0:      	lsl	x12, x11, #4
    39d4:      	add	x10, x10, x11, lsl #4
    39d8:      	add	x9, x10, x9, lsl #2
    39dc:      	ldr	w9, [x9]
    39e0:      	sxtw	x9, w9
    39e4:      	and	x9, x9, #0xffffffff
    39e8:      	mov	x10, x9
    39ec:      	mov	x9, #0x1                ; =1
    39f0:      	b	0x385c <_stogir.vector.validate+0x6cc>
    39f4:      	cmp	x10, #0x0
    39f8:      	b.ge	0x3a74 <_stogir.vector.validate+0x8e4>
    39fc:      	ldr	x13, [x5, #0x8]
    3a00:      	ldr	x14, [x6, #0x8]
    3a04:      	cmp	x13, x14
    3a08:      	b.ne	0x3b78 <_stogir.vector.validate+0x9e8>
    3a0c:      	cmp	x11, x13
    3a10:      	b.gt	0x3bb0 <_stogir.vector.validate+0xa20>
    3a14:      	lsl	x11, x12, #2
    3a18:      	ldr	x11, [x21, #0x50]
    3a1c:      	add	x11, x11, x12, lsl #2
    3a20:      	ldr	w11, [x11]
    3a24:      	sxtw	x11, w11
    3a28:      	cmp	x11, #0x0
    3a2c:      	cset	w11, gt
    3a30:      	ubfx	x11, x11, #0, #8
    3a34:      	b	0x3bb4 <_stogir.vector.validate+0xa24>
    3a38:      	cmp	x8, #0x0
    3a3c:      	b.ne	0x37d0 <_stogir.vector.validate+0x640>
    3a40:      	lsr	w23, w23, #0
    3a44:      	mov	w0, w19
    3a48:      	mov	w1, w23
    3a4c:      	bl	0x3a4c <_stogir.vector.validate+0x8bc>
		0000000000003a4c:  ARM64_RELOC_BRANCH26	_stogir.types.size
    3a50:      	lsr	w0, w0, #0
    3a54:      	sxtw	x0, w0
    3a58:      	and	x0, x0, #0xffffffff
    3a5c:      	mov	x1, x0
    3a60:      	movz	x0, #0x0, lsl #48
    3a64:      	movz	x2, #0x0, lsl #48
    3a68:      	b	0x37d8 <_stogir.vector.validate+0x648>
    3a6c:      	movz	x11, #0x0, lsl #48
    3a70:      	b	0x3a78 <_stogir.vector.validate+0x8e8>
    3a74:      	movz	x11, #0x0, lsl #48
    3a78:      	cmp	x11, #0x0
    3a7c:      	b.eq	0x3abc <_stogir.vector.validate+0x92c>
    3a80:      	uxtb	w16, w9
    3a84:      	cmp	w16, wzr
    3a88:      	b.eq	0x3aa0 <_stogir.vector.validate+0x910>
    3a8c:      	lsl	x9, x10, #4
    3a90:      	ldr	x9, [x21]
    3a94:      	add	x9, x9, x10, lsl #4
    3a98:      	ldr	x9, [x9]
    3a9c:      	b	0x3ab0 <_stogir.vector.validate+0x920>
    3aa0:      	lsl	x9, x12, #4
    3aa4:      	ldr	x9, [x21, #0x28]
    3aa8:      	add	x9, x9, x12, lsl #4
    3aac:      	ldr	x9, [x9]
    3ab0:      	mov	x10, x9
    3ab4:      	mov	x9, #0x1                ; =1
    3ab8:      	b	0x3ac4 <_stogir.vector.validate+0x934>
    3abc:      	movz	x9, #0x0, lsl #48
    3ac0:      	movz	x10, #0x0, lsl #48
    3ac4:      	lsr	w9, w9, #0
    3ac8:      	lsr	x16, x9, #0
    3acc:      	cmp	x16, #0x1
    3ad0:      	b.eq	0x3aec <_stogir.vector.validate+0x95c>
    3ad4:      	b.lo	0x3adc <_stogir.vector.validate+0x94c>
    3ad8:      	b	0x3af0 <_stogir.vector.validate+0x960>
    3adc:      	cmp	x16, #0x0
    3ae0:      	b.eq	0x3ae8 <_stogir.vector.validate+0x958>
    3ae4:      	b	0x3af0 <_stogir.vector.validate+0x960>
    3ae8:      	b	0x3af4 <_stogir.vector.validate+0x964>
    3aec:      	b	0x3838 <_stogir.vector.validate+0x6a8>
    3af0:      	b	0x3c3c <_stogir.vector.validate+0xaac>
    3af4:      	mov	x1, x2
    3af8:      	mov	x8, #0x18               ; =24
    3afc:      	b	0x3850 <_stogir.vector.validate+0x6c0>
    3b00:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x47c>
		0000000000003b00:  ARM64_RELOC_PAGE21	l_stogir.354
    3b04:      	ldr	x16, [x16]
		0000000000003b04:  ARM64_RELOC_PAGEOFF12	l_stogir.354
    3b08:      	orr	x0, x16, xzr
    3b0c:      	mov	x25, x0
    3b10:      	mov	x27, #0x20              ; =32
    3b14:      	add	x16, sp, #0x40
    3b18:      	ldr	w0, [x16, #0x4]
    3b1c:      	lsr	w0, w0, #0
    3b20:      	add	x8, sp, #0x170
    3b24:      	mov	w1, w0
    3b28:      	mov	x0, x21
    3b2c:      	bl	0x3b2c <_stogir.vector.validate+0x99c>
		0000000000003b2c:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    3b30:      	add	x16, sp, #0x170
    3b34:      	ldr	w0, [x16]
    3b38:      	lsr	x16, x0, #0
    3b3c:      	cmp	x16, #0x1
    3b40:      	b.eq	0x3b5c <_stogir.vector.validate+0x9cc>
    3b44:      	b.lo	0x3b4c <_stogir.vector.validate+0x9bc>
    3b48:      	b	0x3b60 <_stogir.vector.validate+0x9d0>
    3b4c:      	cmp	x16, #0x0
    3b50:      	b.eq	0x3b58 <_stogir.vector.validate+0x9c8>
    3b54:      	b	0x3b60 <_stogir.vector.validate+0x9d0>
    3b58:      	b	0x3b64 <_stogir.vector.validate+0x9d4>
    3b5c:      	b	0x3b88 <_stogir.vector.validate+0x9f8>
    3b60:      	b	0x3c44 <_stogir.vector.validate+0xab4>
    3b64:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x47c>
		0000000000003b64:  ARM64_RELOC_PAGE21	l_stogir.355
    3b68:      	ldr	x16, [x16]
		0000000000003b68:  ARM64_RELOC_PAGEOFF12	l_stogir.355
    3b6c:      	orr	x0, x16, xzr
    3b70:      	mov	x1, #0x19               ; =25
    3b74:      	b	0x3800 <_stogir.vector.validate+0x670>
    3b78:      	movz	x11, #0x0, lsl #48
    3b7c:      	b	0x3a78 <_stogir.vector.validate+0x8e8>
    3b80:      	movz	x11, #0x0, lsl #48
    3b84:      	b	0x3a70 <_stogir.vector.validate+0x8e0>
    3b88:      	add	x16, sp, #0x170
    3b8c:      	ldr	x0, [x16, #0x8]
    3b90:      	add	x16, sp, #0x40
    3b94:      	ldr	w1, [x16, #0x4]
    3b98:      	sxtw	x1, w1
    3b9c:      	cmp	x1, #0x0
    3ba0:      	b.gt	0x3c18 <_stogir.vector.validate+0xa88>
    3ba4:      	mov	x1, x25
    3ba8:      	mov	x0, #0x1                ; =1
    3bac:      	b	0x3bfc <_stogir.vector.validate+0xa6c>
    3bb0:      	movz	x11, #0x0, lsl #48
    3bb4:      	b	0x3b7c <_stogir.vector.validate+0x9ec>
    3bb8:      	add	x16, sp, #0x40
    3bbc:      	ldr	w0, [x16, #0x4]
    3bc0:      	sxtw	x0, w0
    3bc4:      	ldr	x1, [x21, #0x78]
    3bc8:      	lsl	x2, x0, #2
    3bcc:      	add	x0, x1, x0, lsl #2
    3bd0:      	ldr	w0, [x0]
    3bd4:      	sxtw	x0, w0
    3bd8:      	add	x0, x0, #0x1
    3bdc:      	lsr	w0, w0, #0
    3be0:      	sxtw	x0, w0
    3be4:      	cmp	x28, x0
    3be8:      	cset	w0, eq
    3bec:      	uxtb	w16, w0
    3bf0:      	cmp	w16, wzr
    3bf4:      	cset	x0, eq
    3bf8:      	mov	x1, x25
    3bfc:      	cmp	x0, #0x0
    3c00:      	b.eq	0x37f8 <_stogir.vector.validate+0x668>
    3c04:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x47c>
		0000000000003c04:  ARM64_RELOC_PAGE21	l_stogir.356
    3c08:      	ldr	x16, [x16]
		0000000000003c08:  ARM64_RELOC_PAGEOFF12	l_stogir.356
    3c0c:      	orr	x0, x16, xzr
    3c10:      	mov	x1, #0x19               ; =25
    3c14:      	b	0x3800 <_stogir.vector.validate+0x670>
    3c18:      	uxtb	w0, w0
    3c1c:      	cmp	x0, #0x70
    3c20:      	b.eq	0x3bb8 <_stogir.vector.validate+0xa28>
    3c24:      	cmp	x0, #0x71
    3c28:      	b.eq	0x3bb8 <_stogir.vector.validate+0xa28>
    3c2c:      	mov	x0, #0x1                ; =1
    3c30:      	b	0x3bf8 <_stogir.vector.validate+0xa68>
    3c34:      	brk	#0
    3c38:      	b	0x3c34 <_stogir.vector.validate+0xaa4>
    3c3c:      	brk	#0
    3c40:      	b	0x3c3c <_stogir.vector.validate+0xaac>
    3c44:      	brk	#0
    3c48:      	b	0x3c44 <_stogir.vector.validate+0xab4>
    3c4c:      	str	x20, [sp, #0x1a8]
    3c50:      	str	w19, [sp, #0x1a0]
    3c54:      	b	0x3344 <_stogir.vector.validate+0x1b4>
    3c58:      	str	x20, [sp, #0x1a8]
    3c5c:      	str	w19, [sp, #0x1a0]
    3c60:      	mov	w19, w0
    3c64:      	mov	w20, w1
    3c68:      	str	w2, [sp, #0x1b0]
    3c6c:      	str	w3, [sp, #0x1b8]
    3c70:      	b	0x3400 <_stogir.vector.validate+0x270>

0000000000003c74 <_stogir.copy.validate>:
    3c74:      	sub	sp, sp, #0x10
    3c78:      	sxtw	x1, w1
    3c7c:      	lsl	x2, x1, #2
    3c80:      	cmp	x1, #0x0
    3c84:      	cset	w3, gt
    3c88:      	movz	x16, #0x0, lsl #48
    3c8c:      	sub	x4, x16, x1
    3c90:      	sub	x5, x4, #0x1
    3c94:      	uxtb	w16, w3
    3c98:      	cmp	w16, wzr
    3c9c:      	b.eq	0x3cdc <_stogir.copy.validate+0x68>
    3ca0:      	ldr	x4, [x0, #0x8]
    3ca4:      	cmp	x1, x4
    3ca8:      	b.ge	0x3d4c <_stogir.copy.validate+0xd8>
    3cac:      	add	x4, x0, #0x78
    3cb0:      	ldr	x4, [x4, #0x8]
    3cb4:      	cmp	x1, x4
    3cb8:      	b.ge	0x3f14 <_stogir.copy.validate+0x2a0>
    3cbc:      	ldr	x4, [x0, #0x78]
    3cc0:      	add	x4, x2, x4
    3cc4:      	ldr	w4, [x4]
    3cc8:      	sxtw	x4, w4
    3ccc:      	cmp	x4, #0x0
    3cd0:      	cset	w4, ge
    3cd4:      	ubfx	x4, x4, #0, #8
    3cd8:      	b	0x3f18 <_stogir.copy.validate+0x2a4>
    3cdc:      	cmp	x1, #0x0
    3ce0:      	b.ge	0x3d54 <_stogir.copy.validate+0xe0>
    3ce4:      	add	x6, x0, #0x28
    3ce8:      	add	x7, x0, #0x50
    3cec:      	ldr	x6, [x6, #0x8]
    3cf0:      	ldr	x7, [x7, #0x8]
    3cf4:      	cmp	x6, x7
    3cf8:      	b.ne	0x3d28 <_stogir.copy.validate+0xb4>
    3cfc:      	cmp	x4, x6
    3d00:      	b.gt	0x3f1c <_stogir.copy.validate+0x2a8>
    3d04:      	lsl	x4, x5, #2
    3d08:      	ldr	x4, [x0, #0x50]
    3d0c:      	add	x4, x4, x5, lsl #2
    3d10:      	ldr	w4, [x4]
    3d14:      	sxtw	x4, w4
    3d18:      	cmp	x4, #0x0
    3d1c:      	cset	w4, gt
    3d20:      	ubfx	x4, x4, #0, #8
    3d24:      	b	0x3f20 <_stogir.copy.validate+0x2ac>
    3d28:      	movz	x4, #0x0, lsl #48
    3d2c:      	b	0x3d58 <_stogir.copy.validate+0xe4>
    3d30:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x47c>
		0000000000003d30:  ARM64_RELOC_PAGE21	l_stogir.357
    3d34:      	ldr	x16, [x16]
		0000000000003d34:  ARM64_RELOC_PAGEOFF12	l_stogir.357
    3d38:      	orr	x0, x16, xzr
    3d3c:      	mov	x1, x0
    3d40:      	mov	x0, #0x1                ; =1
    3d44:      	mov	x2, #0x21               ; =33
    3d48:      	b	0x3e14 <_stogir.copy.validate+0x1a0>
    3d4c:      	movz	x4, #0x0, lsl #48
    3d50:      	b	0x3d58 <_stogir.copy.validate+0xe4>
    3d54:      	movz	x4, #0x0, lsl #48
    3d58:      	cmp	x4, #0x0
    3d5c:      	b.eq	0x3dc0 <_stogir.copy.validate+0x14c>
    3d60:      	uxtb	w16, w3
    3d64:      	cmp	w16, wzr
    3d68:      	b.eq	0x3d90 <_stogir.copy.validate+0x11c>
    3d6c:      	lsl	x3, x1, #4
    3d70:      	ldr	x3, [x0]
    3d74:      	add	x3, x3, x1, lsl #4
    3d78:      	ldr	x4, [x3]
    3d7c:      	ldr	x3, [x3, #0x8]
    3d80:      	fmov	d31, x3
    3d84:      	mov	x3, x4
    3d88:      	fmov	x4, d31
    3d8c:      	b	0x3db0 <_stogir.copy.validate+0x13c>
    3d90:      	lsl	x3, x5, #4
    3d94:      	ldr	x3, [x0, #0x28]
    3d98:      	add	x3, x3, x5, lsl #4
    3d9c:      	ldr	x4, [x3]
    3da0:      	ldr	x3, [x3, #0x8]
    3da4:      	fmov	d31, x3
    3da8:      	mov	x3, x4
    3dac:      	fmov	x4, d31
    3db0:      	mov	x5, x4
    3db4:      	mov	x4, x3
    3db8:      	mov	x3, #0x1                ; =1
    3dbc:      	b	0x3dcc <_stogir.copy.validate+0x158>
    3dc0:      	movz	x3, #0x0, lsl #48
    3dc4:      	movz	x4, #0x0, lsl #48
    3dc8:      	movz	x5, #0x0, lsl #48
    3dcc:      	lsr	w3, w3, #0
    3dd0:      	lsr	x16, x3, #0
    3dd4:      	cmp	x16, #0x1
    3dd8:      	b.eq	0x3df4 <_stogir.copy.validate+0x180>
    3ddc:      	b.lo	0x3de4 <_stogir.copy.validate+0x170>
    3de0:      	b	0x3df8 <_stogir.copy.validate+0x184>
    3de4:      	cmp	x16, #0x0
    3de8:      	b.eq	0x3df0 <_stogir.copy.validate+0x17c>
    3dec:      	b	0x3df8 <_stogir.copy.validate+0x184>
    3df0:      	b	0x3dfc <_stogir.copy.validate+0x188>
    3df4:      	b	0x3e28 <_stogir.copy.validate+0x1b4>
    3df8:      	b	0x3f24 <_stogir.copy.validate+0x2b0>
    3dfc:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x47c>
		0000000000003dfc:  ARM64_RELOC_PAGE21	l_stogir.358
    3e00:      	ldr	x16, [x16]
		0000000000003e00:  ARM64_RELOC_PAGEOFF12	l_stogir.358
    3e04:      	orr	x0, x16, xzr
    3e08:      	mov	x1, x0
    3e0c:      	mov	x0, #0x1                ; =1
    3e10:      	mov	x2, #0x18               ; =24
    3e14:      	str	x0, [x8]
    3e18:      	str	x1, [x8, #0x8]
    3e1c:      	str	x2, [x8, #0x10]
    3e20:      	add	sp, sp, #0x10
    3e24:      	ret
    3e28:      	mov	x16, sp
    3e2c:      	str	x4, [x16]
    3e30:      	mov	x16, sp
    3e34:      	str	x5, [x16, #0x8]
    3e38:      	cmp	x1, #0x0
    3e3c:      	b.le	0x3d30 <_stogir.copy.validate+0xbc>
    3e40:      	uxtb	w1, w4
    3e44:      	cmp	x1, #0x44
    3e48:      	b.ne	0x3d30 <_stogir.copy.validate+0xbc>
    3e4c:      	ldr	x1, [x0, #0x78]
    3e50:      	add	x1, x2, x1
    3e54:      	ldr	w1, [x1]
    3e58:      	sxtw	x1, w1
    3e5c:      	cmp	x1, #0x2
    3e60:      	b.ne	0x3d30 <_stogir.copy.validate+0xbc>
    3e64:      	lsr	w4, w4, #0
    3e68:      	ubfx	x1, x4, #8, #8
    3e6c:      	cmp	x1, #0x0
    3e70:      	b.eq	0x3d30 <_stogir.copy.validate+0xbc>
    3e74:      	cmp	x1, #0xd
    3e78:      	b.le	0x3ea8 <_stogir.copy.validate+0x234>
    3e7c:      	cmp	x1, #0xf
    3e80:      	b.le	0x3d30 <_stogir.copy.validate+0xbc>
    3e84:      	cmp	x1, #0x80
    3e88:      	b.ge	0x3d30 <_stogir.copy.validate+0xbc>
    3e8c:      	and	x2, x1, #0xf
    3e90:      	lsr	w2, w2, #0
    3e94:      	sxtw	x2, w2
    3e98:      	cmp	x2, #0x1
    3e9c:      	b.lt	0x3d30 <_stogir.copy.validate+0xbc>
    3ea0:      	cmp	x2, #0xd
    3ea4:      	b.gt	0x3d30 <_stogir.copy.validate+0xbc>
    3ea8:      	mov	x16, sp
    3eac:      	ldr	w2, [x16, #0x4]
    3eb0:      	sxtw	x2, w2
    3eb4:      	cmp	x2, #0x0
    3eb8:      	cset	w3, gt
    3ebc:      	movz	x16, #0x0, lsl #48
    3ec0:      	sub	x4, x16, x2
    3ec4:      	sub	x5, x4, #0x1
    3ec8:      	uxtb	w16, w3
    3ecc:      	cmp	w16, wzr
    3ed0:      	b.eq	0x3f48 <_stogir.copy.validate+0x2d4>
    3ed4:      	ldr	x4, [x0, #0x8]
    3ed8:      	cmp	x2, x4
    3edc:      	b.ge	0x3f94 <_stogir.copy.validate+0x320>
    3ee0:      	add	x4, x0, #0x78
    3ee4:      	ldr	x4, [x4, #0x8]
    3ee8:      	cmp	x2, x4
    3eec:      	b.ge	0x4070 <_stogir.copy.validate+0x3fc>
    3ef0:      	lsl	x4, x2, #2
    3ef4:      	ldr	x4, [x0, #0x78]
    3ef8:      	add	x4, x4, x2, lsl #2
    3efc:      	ldr	w4, [x4]
    3f00:      	sxtw	x4, w4
    3f04:      	cmp	x4, #0x0
    3f08:      	cset	w4, ge
    3f0c:      	ubfx	x4, x4, #0, #8
    3f10:      	b	0x4074 <_stogir.copy.validate+0x400>
    3f14:      	movz	x4, #0x0, lsl #48
    3f18:      	b	0x3d50 <_stogir.copy.validate+0xdc>
    3f1c:      	movz	x4, #0x0, lsl #48
    3f20:      	b	0x3d2c <_stogir.copy.validate+0xb8>
    3f24:      	brk	#0
    3f28:      	b	0x3f24 <_stogir.copy.validate+0x2b0>
    3f2c:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x47c>
		0000000000003f2c:  ARM64_RELOC_PAGE21	l_stogir.359
    3f30:      	ldr	x16, [x16]
		0000000000003f30:  ARM64_RELOC_PAGEOFF12	l_stogir.359
    3f34:      	orr	x0, x16, xzr
    3f38:      	mov	x1, x0
    3f3c:      	mov	x0, #0x1                ; =1
    3f40:      	mov	x2, #0x20               ; =32
    3f44:      	b	0x3d48 <_stogir.copy.validate+0xd4>
    3f48:      	cmp	x2, #0x0
    3f4c:      	b.ge	0x3f9c <_stogir.copy.validate+0x328>
    3f50:      	add	x6, x0, #0x28
    3f54:      	add	x7, x0, #0x50
    3f58:      	ldr	x6, [x6, #0x8]
    3f5c:      	ldr	x7, [x7, #0x8]
    3f60:      	cmp	x6, x7
    3f64:      	b.ne	0x4068 <_stogir.copy.validate+0x3f4>
    3f68:      	cmp	x4, x6
    3f6c:      	b.gt	0x4078 <_stogir.copy.validate+0x404>
    3f70:      	lsl	x4, x5, #2
    3f74:      	ldr	x4, [x0, #0x50]
    3f78:      	add	x4, x4, x5, lsl #2
    3f7c:      	ldr	w4, [x4]
    3f80:      	sxtw	x4, w4
    3f84:      	cmp	x4, #0x0
    3f88:      	cset	w4, gt
    3f8c:      	ubfx	x4, x4, #0, #8
    3f90:      	b	0x407c <_stogir.copy.validate+0x408>
    3f94:      	movz	x4, #0x0, lsl #48
    3f98:      	b	0x3fa0 <_stogir.copy.validate+0x32c>
    3f9c:      	movz	x4, #0x0, lsl #48
    3fa0:      	cmp	x4, #0x0
    3fa4:      	b.eq	0x3fe4 <_stogir.copy.validate+0x370>
    3fa8:      	uxtb	w16, w3
    3fac:      	cmp	w16, wzr
    3fb0:      	b.eq	0x3fc8 <_stogir.copy.validate+0x354>
    3fb4:      	lsl	x3, x2, #4
    3fb8:      	ldr	x0, [x0]
    3fbc:      	add	x0, x0, x2, lsl #4
    3fc0:      	ldr	x0, [x0]
    3fc4:      	b	0x3fd8 <_stogir.copy.validate+0x364>
    3fc8:      	lsl	x2, x5, #4
    3fcc:      	ldr	x0, [x0, #0x28]
    3fd0:      	add	x0, x0, x5, lsl #4
    3fd4:      	ldr	x0, [x0]
    3fd8:      	mov	x2, x0
    3fdc:      	mov	x0, #0x1                ; =1
    3fe0:      	b	0x3fec <_stogir.copy.validate+0x378>
    3fe4:      	movz	x0, #0x0, lsl #48
    3fe8:      	movz	x2, #0x0, lsl #48
    3fec:      	lsr	w0, w0, #0
    3ff0:      	lsr	x16, x0, #0
    3ff4:      	cmp	x16, #0x1
    3ff8:      	b.eq	0x4014 <_stogir.copy.validate+0x3a0>
    3ffc:      	b.lo	0x4004 <_stogir.copy.validate+0x390>
    4000:      	b	0x4018 <_stogir.copy.validate+0x3a4>
    4004:      	cmp	x16, #0x0
    4008:      	b.eq	0x4010 <_stogir.copy.validate+0x39c>
    400c:      	b	0x4018 <_stogir.copy.validate+0x3a4>
    4010:      	b	0x401c <_stogir.copy.validate+0x3a8>
    4014:      	b	0x4038 <_stogir.copy.validate+0x3c4>
    4018:      	b	0x4080 <_stogir.copy.validate+0x40c>
    401c:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x38c>
		000000000000401c:  ARM64_RELOC_PAGE21	l_stogir.360
    4020:      	ldr	x16, [x16]
		0000000000004020:  ARM64_RELOC_PAGEOFF12	l_stogir.360
    4024:      	orr	x0, x16, xzr
    4028:      	mov	x1, x0
    402c:      	mov	x0, #0x1                ; =1
    4030:      	mov	x2, #0x13               ; =19
    4034:      	b	0x3f44 <_stogir.copy.validate+0x2d0>
    4038:      	lsr	w2, w2, #0
    403c:      	mov	x16, sp
    4040:      	ldr	w0, [x16]
    4044:      	ubfx	x2, x2, #8, #8
    4048:      	ubfx	x0, x0, #8, #8
    404c:      	cmp	x2, x0
    4050:      	b.ne	0x3f2c <_stogir.copy.validate+0x2b8>
    4054:      	and	x0, x1, #0xffffffff
    4058:      	mov	x1, x0
    405c:      	movz	x0, #0x0, lsl #48
    4060:      	movz	x2, #0x0, lsl #48
    4064:      	b	0x3f44 <_stogir.copy.validate+0x2d0>
    4068:      	movz	x4, #0x0, lsl #48
    406c:      	b	0x3fa0 <_stogir.copy.validate+0x32c>
    4070:      	movz	x4, #0x0, lsl #48
    4074:      	b	0x3f98 <_stogir.copy.validate+0x324>
    4078:      	movz	x4, #0x0, lsl #48
    407c:      	b	0x406c <_stogir.copy.validate+0x3f8>
    4080:      	brk	#0
    4084:      	b	0x4080 <_stogir.copy.validate+0x40c>

0000000000004088 <_stogir.graph.lookup>:
    4088:      	sxtw	x1, w1
    408c:      	cmp	x1, #0x0
    4090:      	cset	w2, gt
    4094:      	movz	x16, #0x0, lsl #48
    4098:      	sub	x3, x16, x1
    409c:      	sub	x4, x3, #0x1
    40a0:      	uxtb	w16, w2
    40a4:      	cmp	w16, wzr
    40a8:      	b.eq	0x40ec <_stogir.graph.lookup+0x64>
    40ac:      	ldr	x3, [x0, #0x8]
    40b0:      	cmp	x1, x3
    40b4:      	b.ge	0x4140 <_stogir.graph.lookup+0xb8>
    40b8:      	add	x3, x0, #0x78
    40bc:      	ldr	x3, [x3, #0x8]
    40c0:      	cmp	x1, x3
    40c4:      	b.ge	0x41e0 <_stogir.graph.lookup+0x158>
    40c8:      	lsl	x3, x1, #2
    40cc:      	ldr	x3, [x0, #0x78]
    40d0:      	add	x3, x3, x1, lsl #2
    40d4:      	ldr	w3, [x3]
    40d8:      	sxtw	x3, w3
    40dc:      	cmp	x3, #0x0
    40e0:      	cset	w3, ge
    40e4:      	ubfx	x3, x3, #0, #8
    40e8:      	b	0x41e4 <_stogir.graph.lookup+0x15c>
    40ec:      	cmp	x1, #0x0
    40f0:      	b.ge	0x4148 <_stogir.graph.lookup+0xc0>
    40f4:      	add	x5, x0, #0x28
    40f8:      	add	x6, x0, #0x50
    40fc:      	ldr	x5, [x5, #0x8]
    4100:      	ldr	x6, [x6, #0x8]
    4104:      	cmp	x5, x6
    4108:      	b.ne	0x4138 <_stogir.graph.lookup+0xb0>
    410c:      	cmp	x3, x5
    4110:      	b.gt	0x41e8 <_stogir.graph.lookup+0x160>
    4114:      	lsl	x3, x4, #2
    4118:      	ldr	x3, [x0, #0x50]
    411c:      	add	x3, x3, x4, lsl #2
    4120:      	ldr	w3, [x3]
    4124:      	sxtw	x3, w3
    4128:      	cmp	x3, #0x0
    412c:      	cset	w3, gt
    4130:      	ubfx	x3, x3, #0, #8
    4134:      	b	0x41ec <_stogir.graph.lookup+0x164>
    4138:      	movz	x3, #0x0, lsl #48
    413c:      	b	0x414c <_stogir.graph.lookup+0xc4>
    4140:      	movz	x3, #0x0, lsl #48
    4144:      	b	0x414c <_stogir.graph.lookup+0xc4>
    4148:      	movz	x3, #0x0, lsl #48
    414c:      	cmp	x3, #0x0
    4150:      	b.eq	0x41b4 <_stogir.graph.lookup+0x12c>
    4154:      	uxtb	w16, w2
    4158:      	cmp	w16, wzr
    415c:      	b.eq	0x4184 <_stogir.graph.lookup+0xfc>
    4160:      	lsl	x2, x1, #4
    4164:      	ldr	x0, [x0]
    4168:      	add	x0, x0, x1, lsl #4
    416c:      	ldr	x1, [x0]
    4170:      	ldr	x0, [x0, #0x8]
    4174:      	fmov	d31, x0
    4178:      	mov	x0, x1
    417c:      	fmov	x1, d31
    4180:      	b	0x41a4 <_stogir.graph.lookup+0x11c>
    4184:      	lsl	x1, x4, #4
    4188:      	ldr	x0, [x0, #0x28]
    418c:      	add	x0, x0, x4, lsl #4
    4190:      	ldr	x1, [x0]
    4194:      	ldr	x0, [x0, #0x8]
    4198:      	fmov	d31, x0
    419c:      	mov	x0, x1
    41a0:      	fmov	x1, d31
    41a4:      	mov	x2, x1
    41a8:      	mov	x1, x0
    41ac:      	mov	x0, #0x1                ; =1
    41b0:      	b	0x41c0 <_stogir.graph.lookup+0x138>
    41b4:      	movz	x0, #0x0, lsl #48
    41b8:      	movz	x1, #0x0, lsl #48
    41bc:      	movz	x2, #0x0, lsl #48
    41c0:      	str	x0, [x8]
    41c4:      	str	x1, [x8, #0x8]
    41c8:      	str	x2, [x8, #0x10]
    41cc:      	movz	x17, #0x0, lsl #48
    41d0:      	str	x17, [x8, #0x18]
    41d4:      	movz	x17, #0x0, lsl #48
    41d8:      	str	x17, [x8, #0x20]
    41dc:      	ret
    41e0:      	movz	x3, #0x0, lsl #48
    41e4:      	b	0x4144 <_stogir.graph.lookup+0xbc>
    41e8:      	movz	x3, #0x0, lsl #48
    41ec:      	b	0x413c <_stogir.graph.lookup+0xb4>

00000000000041f0 <_stogir.opcode.block-start?>:
    41f0:      	sxtw	x0, w0
    41f4:      	cmp	x0, #0x0
    41f8:      	b.lt	0x4220 <_stogir.opcode.block-start?+0x30>
    41fc:      	cmp	x0, #0x83
    4200:      	b.ge	0x4220 <_stogir.opcode.block-start?+0x30>
    4204:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x38c>
		0000000000004204:  ARM64_RELOC_PAGE21	l_stogir.361
    4208:      	ldr	x16, [x16]
		0000000000004208:  ARM64_RELOC_PAGEOFF12	l_stogir.361
    420c:      	orr	x1, x16, xzr
    4210:      	lsr	x2, x0, #0
    4214:      	add	x0, x1, x0
    4218:      	ldrb	w0, [x0]
    421c:      	b	0x4224 <_stogir.opcode.block-start?+0x34>
    4220:      	movz	x0, #0x0, lsl #48
    4224:      	uxtb	w0, w0
    4228:      	and	x0, x0, #0x2
    422c:      	uxtb	w0, w0
    4230:      	cmp	x0, #0x0
    4234:      	cset	w0, eq
    4238:      	uxtb	w16, w0
    423c:      	cmp	w16, wzr
    4240:      	cset	x0, eq
    4244:      	ret

0000000000004248 <_stogir.checked.operation?>:
    4248:      	sxtw	x0, w0
    424c:      	cmp	x0, #0x29
    4250:      	b.lt	0x4264 <_stogir.checked.operation?+0x1c>
    4254:      	cmp	x0, #0x2b
    4258:      	cset	w0, le
    425c:      	ubfx	x0, x0, #0, #8
    4260:      	b	0x4268 <_stogir.checked.operation?+0x20>
    4264:      	movz	x0, #0x0, lsl #48
    4268:      	ret

000000000000426c <_stogir.checked.validate-projection>:
    426c:      	sub	sp, sp, #0x40
    4270:      	str	x29, [sp]
    4274:      	str	x30, [sp, #0x8]
    4278:      	mov	x29, sp
    427c:      	str	x19, [sp, #0x30]
    4280:      	sxtw	x1, w1
    4284:      	lsl	x2, x1, #2
    4288:      	cmp	x1, #0x0
    428c:      	cset	w3, gt
    4290:      	movz	x16, #0x0, lsl #48
    4294:      	sub	x4, x16, x1
    4298:      	sub	x5, x4, #0x1
    429c:      	uxtb	w16, w3
    42a0:      	cmp	w16, wzr
    42a4:      	b.eq	0x42e4 <_stogir.checked.validate-projection+0x78>
    42a8:      	ldr	x4, [x0, #0x8]
    42ac:      	cmp	x1, x4
    42b0:      	b.ge	0x4338 <_stogir.checked.validate-projection+0xcc>
    42b4:      	add	x4, x0, #0x78
    42b8:      	ldr	x4, [x4, #0x8]
    42bc:      	cmp	x1, x4
    42c0:      	b.ge	0x4424 <_stogir.checked.validate-projection+0x1b8>
    42c4:      	ldr	x4, [x0, #0x78]
    42c8:      	add	x4, x2, x4
    42cc:      	ldr	w4, [x4]
    42d0:      	sxtw	x4, w4
    42d4:      	cmp	x4, #0x0
    42d8:      	cset	w4, ge
    42dc:      	ubfx	x4, x4, #0, #8
    42e0:      	b	0x4428 <_stogir.checked.validate-projection+0x1bc>
    42e4:      	cmp	x1, #0x0
    42e8:      	b.ge	0x4340 <_stogir.checked.validate-projection+0xd4>
    42ec:      	add	x6, x0, #0x28
    42f0:      	add	x7, x0, #0x50
    42f4:      	ldr	x6, [x6, #0x8]
    42f8:      	ldr	x7, [x7, #0x8]
    42fc:      	cmp	x6, x7
    4300:      	b.ne	0x4330 <_stogir.checked.validate-projection+0xc4>
    4304:      	cmp	x4, x6
    4308:      	b.gt	0x4490 <_stogir.checked.validate-projection+0x224>
    430c:      	lsl	x4, x5, #2
    4310:      	ldr	x4, [x0, #0x50]
    4314:      	add	x4, x4, x5, lsl #2
    4318:      	ldr	w4, [x4]
    431c:      	sxtw	x4, w4
    4320:      	cmp	x4, #0x0
    4324:      	cset	w4, gt
    4328:      	ubfx	x4, x4, #0, #8
    432c:      	b	0x4494 <_stogir.checked.validate-projection+0x228>
    4330:      	movz	x4, #0x0, lsl #48
    4334:      	b	0x4344 <_stogir.checked.validate-projection+0xd8>
    4338:      	movz	x4, #0x0, lsl #48
    433c:      	b	0x4344 <_stogir.checked.validate-projection+0xd8>
    4340:      	movz	x4, #0x0, lsl #48
    4344:      	cmp	x4, #0x0
    4348:      	b.eq	0x4388 <_stogir.checked.validate-projection+0x11c>
    434c:      	uxtb	w16, w3
    4350:      	cmp	w16, wzr
    4354:      	b.eq	0x436c <_stogir.checked.validate-projection+0x100>
    4358:      	lsl	x3, x1, #4
    435c:      	ldr	x3, [x0]
    4360:      	add	x3, x3, x1, lsl #4
    4364:      	ldr	x3, [x3]
    4368:      	b	0x437c <_stogir.checked.validate-projection+0x110>
    436c:      	lsl	x3, x5, #4
    4370:      	ldr	x3, [x0, #0x28]
    4374:      	add	x3, x3, x5, lsl #4
    4378:      	ldr	x3, [x3]
    437c:      	mov	x4, x3
    4380:      	mov	x3, #0x1                ; =1
    4384:      	b	0x4390 <_stogir.checked.validate-projection+0x124>
    4388:      	movz	x3, #0x0, lsl #48
    438c:      	movz	x4, #0x0, lsl #48
    4390:      	lsr	w3, w3, #0
    4394:      	lsr	x16, x3, #0
    4398:      	cmp	x16, #0x1
    439c:      	b.eq	0x43b8 <_stogir.checked.validate-projection+0x14c>
    43a0:      	b.lo	0x43a8 <_stogir.checked.validate-projection+0x13c>
    43a4:      	b	0x43bc <_stogir.checked.validate-projection+0x150>
    43a8:      	cmp	x16, #0x0
    43ac:      	b.eq	0x43b4 <_stogir.checked.validate-projection+0x148>
    43b0:      	b	0x43bc <_stogir.checked.validate-projection+0x150>
    43b4:      	b	0x43c0 <_stogir.checked.validate-projection+0x154>
    43b8:      	b	0x43e0 <_stogir.checked.validate-projection+0x174>
    43bc:      	b	0x4498 <_stogir.checked.validate-projection+0x22c>
    43c0:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x38c>
		00000000000043c0:  ARM64_RELOC_PAGE21	l_stogir.362
    43c4:      	ldr	x16, [x16]
		00000000000043c4:  ARM64_RELOC_PAGEOFF12	l_stogir.362
    43c8:      	orr	x0, x16, xzr
    43cc:      	mov	x19, x8
    43d0:      	mov	x1, x0
    43d4:      	mov	x0, #0x1                ; =1
    43d8:      	mov	x2, #0x10               ; =16
    43dc:      	b	0x4404 <_stogir.checked.validate-projection+0x198>
    43e0:      	cmp	x1, #0x0
    43e4:      	b.gt	0x442c <_stogir.checked.validate-projection+0x1c0>
    43e8:      	mov	x19, x8
    43ec:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x38c>
		00000000000043ec:  ARM64_RELOC_PAGE21	l_stogir.363
    43f0:      	ldr	x16, [x16]
		00000000000043f0:  ARM64_RELOC_PAGEOFF12	l_stogir.363
    43f4:      	orr	x0, x16, xzr
    43f8:      	mov	x1, x0
    43fc:      	mov	x0, #0x1                ; =1
    4400:      	mov	x2, #0x1c               ; =28
    4404:      	str	x0, [x19]
    4408:      	str	x1, [x19, #0x8]
    440c:      	str	x2, [x19, #0x10]
    4410:      	ldr	x19, [sp, #0x30]
    4414:      	ldr	x29, [sp]
    4418:      	ldr	x30, [sp, #0x8]
    441c:      	add	sp, sp, #0x40
    4420:      	ret
    4424:      	movz	x4, #0x0, lsl #48
    4428:      	b	0x433c <_stogir.checked.validate-projection+0xd0>
    442c:      	uxtb	w1, w4
    4430:      	cmp	x1, #0x2c
    4434:      	b.ne	0x44a0 <_stogir.checked.validate-projection+0x234>
    4438:      	lsr	w1, w4, #0
    443c:      	ubfx	x1, x1, #8, #8
    4440:      	cmp	x1, #0x1
    4444:      	b.ne	0x44a8 <_stogir.checked.validate-projection+0x23c>
    4448:      	ldr	x1, [x0, #0x78]
    444c:      	add	x1, x2, x1
    4450:      	ldr	w1, [x1]
    4454:      	sxtw	x1, w1
    4458:      	cmp	x1, #0x1
    445c:      	b.ne	0x44b0 <_stogir.checked.validate-projection+0x244>
    4460:      	lsr	x1, x4, #32
    4464:      	lsr	w1, w1, #0
    4468:      	mov	x19, x8
    446c:      	add	x8, sp, #0x10
    4470:      	bl	0x4470 <_stogir.checked.validate-projection+0x204>
		0000000000004470:  ARM64_RELOC_BRANCH26	_stogir.checked.projection
    4474:      	add	x16, sp, #0x10
    4478:      	ldr	x0, [x16]
    447c:      	add	x16, sp, #0x10
    4480:      	ldr	x1, [x16, #0x8]
    4484:      	add	x16, sp, #0x10
    4488:      	ldr	x2, [x16, #0x10]
    448c:      	b	0x4404 <_stogir.checked.validate-projection+0x198>
    4490:      	movz	x4, #0x0, lsl #48
    4494:      	b	0x4334 <_stogir.checked.validate-projection+0xc8>
    4498:      	brk	#0
    449c:      	b	0x4498 <_stogir.checked.validate-projection+0x22c>
    44a0:      	mov	x19, x8
    44a4:      	b	0x43ec <_stogir.checked.validate-projection+0x180>
    44a8:      	mov	x19, x8
    44ac:      	b	0x43ec <_stogir.checked.validate-projection+0x180>
    44b0:      	mov	x19, x8
    44b4:      	b	0x43ec <_stogir.checked.validate-projection+0x180>

00000000000044b8 <_stogir.checked.validate>:
    44b8:      	sub	sp, sp, #0x30
    44bc:      	str	x29, [sp]
    44c0:      	str	x30, [sp, #0x8]
    44c4:      	mov	x29, sp
    44c8:      	str	x19, [sp, #0x10]
    44cc:      	str	x20, [sp, #0x18]
    44d0:      	str	x21, [sp, #0x20]
    44d4:      	sxtw	x1, w1
    44d8:      	lsl	x2, x1, #2
    44dc:      	cmp	x1, #0x0
    44e0:      	cset	w3, gt
    44e4:      	movz	x16, #0x0, lsl #48
    44e8:      	sub	x4, x16, x1
    44ec:      	sub	x5, x4, #0x1
    44f0:      	uxtb	w16, w3
    44f4:      	cmp	w16, wzr
    44f8:      	b.eq	0x4538 <_stogir.checked.validate+0x80>
    44fc:      	ldr	x4, [x0, #0x8]
    4500:      	cmp	x1, x4
    4504:      	b.ge	0x458c <_stogir.checked.validate+0xd4>
    4508:      	add	x4, x0, #0x78
    450c:      	ldr	x4, [x4, #0x8]
    4510:      	cmp	x1, x4
    4514:      	b.ge	0x4718 <_stogir.checked.validate+0x260>
    4518:      	ldr	x4, [x0, #0x78]
    451c:      	add	x4, x2, x4
    4520:      	ldr	w4, [x4]
    4524:      	sxtw	x4, w4
    4528:      	cmp	x4, #0x0
    452c:      	cset	w4, ge
    4530:      	ubfx	x4, x4, #0, #8
    4534:      	b	0x471c <_stogir.checked.validate+0x264>
    4538:      	cmp	x1, #0x0
    453c:      	b.ge	0x4594 <_stogir.checked.validate+0xdc>
    4540:      	add	x6, x0, #0x28
    4544:      	add	x7, x0, #0x50
    4548:      	ldr	x6, [x6, #0x8]
    454c:      	ldr	x7, [x7, #0x8]
    4550:      	cmp	x6, x7
    4554:      	b.ne	0x4584 <_stogir.checked.validate+0xcc>
    4558:      	cmp	x4, x6
    455c:      	b.gt	0x4720 <_stogir.checked.validate+0x268>
    4560:      	lsl	x4, x5, #2
    4564:      	ldr	x4, [x0, #0x50]
    4568:      	add	x4, x4, x5, lsl #2
    456c:      	ldr	w4, [x4]
    4570:      	sxtw	x4, w4
    4574:      	cmp	x4, #0x0
    4578:      	cset	w4, gt
    457c:      	ubfx	x4, x4, #0, #8
    4580:      	b	0x4724 <_stogir.checked.validate+0x26c>
    4584:      	movz	x4, #0x0, lsl #48
    4588:      	b	0x4598 <_stogir.checked.validate+0xe0>
    458c:      	movz	x4, #0x0, lsl #48
    4590:      	b	0x4598 <_stogir.checked.validate+0xe0>
    4594:      	movz	x4, #0x0, lsl #48
    4598:      	cmp	x4, #0x0
    459c:      	b.eq	0x4600 <_stogir.checked.validate+0x148>
    45a0:      	uxtb	w16, w3
    45a4:      	cmp	w16, wzr
    45a8:      	b.eq	0x45d0 <_stogir.checked.validate+0x118>
    45ac:      	lsl	x3, x1, #4
    45b0:      	ldr	x3, [x0]
    45b4:      	add	x3, x3, x1, lsl #4
    45b8:      	ldr	x4, [x3]
    45bc:      	ldr	x3, [x3, #0x8]
    45c0:      	fmov	d31, x3
    45c4:      	mov	x3, x4
    45c8:      	fmov	x4, d31
    45cc:      	b	0x45f0 <_stogir.checked.validate+0x138>
    45d0:      	lsl	x3, x5, #4
    45d4:      	ldr	x3, [x0, #0x28]
    45d8:      	add	x3, x3, x5, lsl #4
    45dc:      	ldr	x4, [x3]
    45e0:      	ldr	x3, [x3, #0x8]
    45e4:      	fmov	d31, x3
    45e8:      	mov	x3, x4
    45ec:      	fmov	x4, d31
    45f0:      	mov	x5, x4
    45f4:      	mov	x4, x3
    45f8:      	mov	x3, #0x1                ; =1
    45fc:      	b	0x460c <_stogir.checked.validate+0x154>
    4600:      	movz	x3, #0x0, lsl #48
    4604:      	movz	x4, #0x0, lsl #48
    4608:      	movz	x5, #0x0, lsl #48
    460c:      	lsr	w3, w3, #0
    4610:      	lsr	x16, x3, #0
    4614:      	cmp	x16, #0x1
    4618:      	b.eq	0x4634 <_stogir.checked.validate+0x17c>
    461c:      	b.lo	0x4624 <_stogir.checked.validate+0x16c>
    4620:      	b	0x4638 <_stogir.checked.validate+0x180>
    4624:      	cmp	x16, #0x0
    4628:      	b.eq	0x4630 <_stogir.checked.validate+0x178>
    462c:      	b	0x4638 <_stogir.checked.validate+0x180>
    4630:      	b	0x463c <_stogir.checked.validate+0x184>
    4634:      	b	0x469c <_stogir.checked.validate+0x1e4>
    4638:      	b	0x4998 <_stogir.checked.validate+0x4e0>
    463c:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x38c>
		000000000000463c:  ARM64_RELOC_PAGE21	l_stogir.364
    4640:      	ldr	x16, [x16]
		0000000000004640:  ARM64_RELOC_PAGEOFF12	l_stogir.364
    4644:      	orr	x0, x16, xzr
    4648:      	mov	x1, x0
    464c:      	mov	x0, #0x1                ; =1
    4650:      	mov	x2, #0x1a               ; =26
    4654:      	b	0x4670 <_stogir.checked.validate+0x1b8>
    4658:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x38c>
		0000000000004658:  ARM64_RELOC_PAGE21	l_stogir.365
    465c:      	ldr	x16, [x16]
		000000000000465c:  ARM64_RELOC_PAGEOFF12	l_stogir.365
    4660:      	orr	x0, x16, xzr
    4664:      	mov	x1, x0
    4668:      	mov	x0, #0x1                ; =1
    466c:      	mov	x2, #0x26               ; =38
    4670:      	str	x0, [x8]
    4674:      	str	x1, [x8, #0x8]
    4678:      	str	x2, [x8, #0x10]
    467c:      	sub	sp, x29, #0x0
    4680:      	ldr	x19, [sp, #0x10]
    4684:      	ldr	x20, [sp, #0x18]
    4688:      	ldr	x21, [sp, #0x20]
    468c:      	ldr	x29, [sp]
    4690:      	ldr	x30, [sp, #0x8]
    4694:      	add	sp, sp, #0x30
    4698:      	ret
    469c:      	cmp	x1, #0x0
    46a0:      	b.le	0x4658 <_stogir.checked.validate+0x1a0>
    46a4:      	uxtb	w1, w4
    46a8:      	cmp	x1, #0x29
    46ac:      	b.lt	0x4658 <_stogir.checked.validate+0x1a0>
    46b0:      	cmp	x1, #0x2b
    46b4:      	b.gt	0x4658 <_stogir.checked.validate+0x1a0>
    46b8:      	ldr	x1, [x0, #0x78]
    46bc:      	add	x1, x2, x1
    46c0:      	ldr	w1, [x1]
    46c4:      	sxtw	x1, w1
    46c8:      	cmp	x1, #0x2
    46cc:      	b.ne	0x4658 <_stogir.checked.validate+0x1a0>
    46d0:      	lsr	w1, w4, #0
    46d4:      	mov	x2, sp
    46d8:      	sub	sp, sp, #0x10
    46dc:      	mov	x3, sp
    46e0:      	sub	sp, sp, #0x10
    46e4:      	mov	x6, sp
    46e8:      	ubfx	x1, x1, #8, #8
    46ec:      	cmp	x1, #0x1
    46f0:      	b.lt	0x4920 <_stogir.checked.validate+0x468>
    46f4:      	cmp	x1, #0xb
    46f8:      	b.gt	0x4920 <_stogir.checked.validate+0x468>
    46fc:      	cmp	x1, #0x1
    4700:      	b.eq	0x4920 <_stogir.checked.validate+0x468>
    4704:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x38c>
		0000000000004704:  ARM64_RELOC_PAGE21	l_stogir.366
    4708:      	ldr	x16, [x16]
		0000000000004708:  ARM64_RELOC_PAGEOFF12	l_stogir.366
    470c:      	orr	x7, x16, xzr
    4710:      	movz	x9, #0x0, lsl #48
    4714:      	b	0x4930 <_stogir.checked.validate+0x478>
    4718:      	movz	x4, #0x0, lsl #48
    471c:      	b	0x4590 <_stogir.checked.validate+0xd8>
    4720:      	movz	x4, #0x0, lsl #48
    4724:      	b	0x4588 <_stogir.checked.validate+0xd0>
    4728:      	mov	x1, x3
    472c:      	mov	x3, x4
    4730:      	mov	x0, #0x1                ; =1
    4734:      	mov	sp, x2
    4738:      	mov	x2, x3
    473c:      	b	0x4670 <_stogir.checked.validate+0x1b8>
    4740:      	movz	x5, #0x0, lsl #48
    4744:      	movz	x6, #0x0, lsl #48
    4748:      	lsr	w5, w5, #0
    474c:      	lsr	x16, x5, #0
    4750:      	cmp	x16, #0x1
    4754:      	b.eq	0x4770 <_stogir.checked.validate+0x2b8>
    4758:      	b.lo	0x4760 <_stogir.checked.validate+0x2a8>
    475c:      	b	0x4774 <_stogir.checked.validate+0x2bc>
    4760:      	cmp	x16, #0x0
    4764:      	b.eq	0x476c <_stogir.checked.validate+0x2b4>
    4768:      	b	0x4774 <_stogir.checked.validate+0x2bc>
    476c:      	b	0x4778 <_stogir.checked.validate+0x2c0>
    4770:      	b	0x4904 <_stogir.checked.validate+0x44c>
    4774:      	b	0x49b0 <_stogir.checked.validate+0x4f8>
    4778:      	mov	x3, x11
    477c:      	mov	x4, #0x22               ; =34
    4780:      	mov	x5, x7
    4784:      	cmp	x5, #0x2
    4788:      	b.ge	0x47b4 <_stogir.checked.validate+0x2fc>
    478c:      	add	x6, x5, #0x1
    4790:      	lsl	x7, x5, #2
    4794:      	add	x5, x10, x5, lsl #2
    4798:      	ldr	w5, [x5]
    479c:      	sxtw	x5, w5
    47a0:      	and	x5, x5, #0xffffffff
    47a4:      	mov	x7, x6
    47a8:      	mov	x6, x5
    47ac:      	mov	x5, #0x1                ; =1
    47b0:      	b	0x47c0 <_stogir.checked.validate+0x308>
    47b4:      	mov	x7, x5
    47b8:      	movz	x5, #0x0, lsl #48
    47bc:      	movz	x6, #0x0, lsl #48
    47c0:      	lsr	w5, w5, #0
    47c4:      	lsr	x16, x5, #0
    47c8:      	cmp	x16, #0x1
    47cc:      	b.eq	0x47e8 <_stogir.checked.validate+0x330>
    47d0:      	b.lo	0x47d8 <_stogir.checked.validate+0x320>
    47d4:      	b	0x47ec <_stogir.checked.validate+0x334>
    47d8:      	cmp	x16, #0x0
    47dc:      	b.eq	0x47e4 <_stogir.checked.validate+0x32c>
    47e0:      	b	0x47ec <_stogir.checked.validate+0x334>
    47e4:      	b	0x4854 <_stogir.checked.validate+0x39c>
    47e8:      	b	0x47f0 <_stogir.checked.validate+0x338>
    47ec:      	b	0x49a8 <_stogir.checked.validate+0x4f0>
    47f0:      	lsr	w6, w6, #0
    47f4:      	sxtw	x6, w6
    47f8:      	cmp	x6, #0x0
    47fc:      	cset	w5, gt
    4800:      	movz	x16, #0x0, lsl #48
    4804:      	sub	x9, x16, x6
    4808:      	sub	x19, x9, #0x1
    480c:      	uxtb	w16, w5
    4810:      	cmp	w16, wzr
    4814:      	b.eq	0x48c0 <_stogir.checked.validate+0x408>
    4818:      	ldr	x9, [x0, #0x8]
    481c:      	cmp	x6, x9
    4820:      	b.ge	0x48b8 <_stogir.checked.validate+0x400>
    4824:      	ldr	x9, [x13, #0x8]
    4828:      	cmp	x6, x9
    482c:      	b.ge	0x4990 <_stogir.checked.validate+0x4d8>
    4830:      	lsl	x9, x6, #2
    4834:      	ldr	x9, [x0, #0x78]
    4838:      	add	x9, x9, x6, lsl #2
    483c:      	ldr	w9, [x9]
    4840:      	sxtw	x9, w9
    4844:      	cmp	x9, #0x0
    4848:      	cset	w9, ge
    484c:      	ubfx	x9, x9, #0, #8
    4850:      	b	0x4994 <_stogir.checked.validate+0x4dc>
    4854:      	cmp	x4, #0x0
    4858:      	b.ne	0x4728 <_stogir.checked.validate+0x270>
    485c:      	and	x0, x1, #0xffffffff
    4860:      	mov	x1, x0
    4864:      	movz	x0, #0x0, lsl #48
    4868:      	movz	x3, #0x0, lsl #48
    486c:      	b	0x4734 <_stogir.checked.validate+0x27c>
    4870:      	lsl	x5, x19, #4
    4874:      	ldr	x5, [x0, #0x28]
    4878:      	add	x5, x5, x19, lsl #4
    487c:      	ldr	x5, [x5]
    4880:      	mov	x6, x5
    4884:      	mov	x5, #0x1                ; =1
    4888:      	b	0x4748 <_stogir.checked.validate+0x290>
    488c:      	movz	x9, #0x0, lsl #48
    4890:      	cmp	x9, #0x0
    4894:      	b.eq	0x4740 <_stogir.checked.validate+0x288>
    4898:      	uxtb	w16, w5
    489c:      	cmp	w16, wzr
    48a0:      	b.eq	0x4870 <_stogir.checked.validate+0x3b8>
    48a4:      	lsl	x5, x6, #4
    48a8:      	ldr	x5, [x0]
    48ac:      	add	x5, x5, x6, lsl #4
    48b0:      	ldr	x5, [x5]
    48b4:      	b	0x4880 <_stogir.checked.validate+0x3c8>
    48b8:      	movz	x9, #0x0, lsl #48
    48bc:      	b	0x4890 <_stogir.checked.validate+0x3d8>
    48c0:      	cmp	x6, #0x0
    48c4:      	b.ge	0x488c <_stogir.checked.validate+0x3d4>
    48c8:      	ldr	x20, [x14, #0x8]
    48cc:      	ldr	x21, [x15, #0x8]
    48d0:      	cmp	x20, x21
    48d4:      	b.ne	0x4988 <_stogir.checked.validate+0x4d0>
    48d8:      	cmp	x9, x20
    48dc:      	b.gt	0x49a0 <_stogir.checked.validate+0x4e8>
    48e0:      	lsl	x9, x19, #2
    48e4:      	ldr	x9, [x0, #0x50]
    48e8:      	add	x9, x9, x19, lsl #2
    48ec:      	ldr	w9, [x9]
    48f0:      	sxtw	x9, w9
    48f4:      	cmp	x9, #0x0
    48f8:      	cset	w9, gt
    48fc:      	ubfx	x9, x9, #0, #8
    4900:      	b	0x49a4 <_stogir.checked.validate+0x4ec>
    4904:      	lsr	w6, w6, #0
    4908:      	ubfx	x5, x6, #8, #8
    490c:      	cmp	x5, x1
    4910:      	b.eq	0x491c <_stogir.checked.validate+0x464>
    4914:      	mov	x3, x12
    4918:      	mov	x4, #0x28               ; =40
    491c:      	b	0x4780 <_stogir.checked.validate+0x2c8>
    4920:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x38c>
		0000000000004920:  ARM64_RELOC_PAGE21	l_stogir.367
    4924:      	ldr	x16, [x16]
		0000000000004924:  ARM64_RELOC_PAGEOFF12	l_stogir.367
    4928:      	orr	x7, x16, xzr
    492c:      	mov	x9, #0x36               ; =54
    4930:      	orr	x10, x6, xzr
    4934:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x38c>
		0000000000004934:  ARM64_RELOC_PAGE21	l_stogir.368
    4938:      	ldr	x16, [x16]
		0000000000004938:  ARM64_RELOC_PAGEOFF12	l_stogir.368
    493c:      	orr	x11, x16, xzr
    4940:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x38c>
		0000000000004940:  ARM64_RELOC_PAGE21	l_stogir.369
    4944:      	ldr	x16, [x16]
		0000000000004944:  ARM64_RELOC_PAGEOFF12	l_stogir.369
    4948:      	orr	x12, x16, xzr
    494c:      	add	x13, x0, #0x78
    4950:      	add	x14, x0, #0x28
    4954:      	add	x15, x0, #0x50
    4958:      	lsr	w5, w5, #0
    495c:      	lsr	x4, x4, #32
    4960:      	lsr	w5, w5, #0
    4964:      	lsr	w4, w4, #0
    4968:      	str	w4, [x3]
    496c:      	str	w5, [x3, #0x4]
    4970:      	ldr	x3, [x3]
    4974:      	str	x3, [x6]
    4978:      	mov	x3, x7
    497c:      	mov	x4, x9
    4980:      	movz	x5, #0x0, lsl #48
    4984:      	b	0x4784 <_stogir.checked.validate+0x2cc>
    4988:      	movz	x9, #0x0, lsl #48
    498c:      	b	0x4890 <_stogir.checked.validate+0x3d8>
    4990:      	movz	x9, #0x0, lsl #48
    4994:      	b	0x48bc <_stogir.checked.validate+0x404>
    4998:      	brk	#0
    499c:      	b	0x4998 <_stogir.checked.validate+0x4e0>
    49a0:      	movz	x9, #0x0, lsl #48
    49a4:      	b	0x498c <_stogir.checked.validate+0x4d4>
    49a8:      	brk	#0
    49ac:      	b	0x49a8 <_stogir.checked.validate+0x4f0>
    49b0:      	brk	#0
    49b4:      	b	0x49b0 <_stogir.checked.validate+0x4f8>

00000000000049b8 <_stogir.atomic.operation?>:
    49b8:      	sxtw	x0, w0
    49bc:      	cmp	x0, #0x7e
    49c0:      	b.lt	0x49d4 <_stogir.atomic.operation?+0x1c>
    49c4:      	cmp	x0, #0x82
    49c8:      	cset	w0, le
    49cc:      	ubfx	x0, x0, #0, #8
    49d0:      	b	0x49d8 <_stogir.atomic.operation?+0x20>
    49d4:      	movz	x0, #0x0, lsl #48
    49d8:      	ret

00000000000049dc <_stogir.atomic.validate>:
    49dc:      	sub	sp, sp, #0xf0
    49e0:      	str	x29, [sp, #0x10]
    49e4:      	str	x30, [sp, #0x18]
    49e8:      	add	x29, sp, #0x10
    49ec:      	str	x19, [sp, #0xa0]
    49f0:      	str	x20, [sp, #0xa8]
    49f4:      	str	x21, [sp, #0xb0]
    49f8:      	str	x22, [sp, #0xb8]
    49fc:      	str	x23, [sp, #0xc0]
    4a00:      	str	x24, [sp, #0xc8]
    4a04:      	str	x25, [sp, #0xd0]
    4a08:      	str	x26, [sp, #0xd8]
    4a0c:      	str	x27, [sp, #0xe0]
    4a10:      	sxtw	x2, w1
    4a14:      	lsl	x3, x2, #2
    4a18:      	cmp	x2, #0x0
    4a1c:      	cset	w4, gt
    4a20:      	movz	x16, #0x0, lsl #48
    4a24:      	sub	x5, x16, x2
    4a28:      	sub	x6, x5, #0x1
    4a2c:      	uxtb	w16, w4
    4a30:      	cmp	w16, wzr
    4a34:      	b.eq	0x4a74 <_stogir.atomic.validate+0x98>
    4a38:      	ldr	x5, [x0, #0x8]
    4a3c:      	cmp	x2, x5
    4a40:      	b.ge	0x4ac8 <_stogir.atomic.validate+0xec>
    4a44:      	add	x5, x0, #0x78
    4a48:      	ldr	x5, [x5, #0x8]
    4a4c:      	cmp	x2, x5
    4a50:      	b.ge	0x4c30 <_stogir.atomic.validate+0x254>
    4a54:      	ldr	x5, [x0, #0x78]
    4a58:      	add	x5, x3, x5
    4a5c:      	ldr	w5, [x5]
    4a60:      	sxtw	x5, w5
    4a64:      	cmp	x5, #0x0
    4a68:      	cset	w5, ge
    4a6c:      	ubfx	x5, x5, #0, #8
    4a70:      	b	0x4c34 <_stogir.atomic.validate+0x258>
    4a74:      	cmp	x2, #0x0
    4a78:      	b.ge	0x4ad0 <_stogir.atomic.validate+0xf4>
    4a7c:      	add	x7, x0, #0x28
    4a80:      	add	x9, x0, #0x50
    4a84:      	ldr	x7, [x7, #0x8]
    4a88:      	ldr	x9, [x9, #0x8]
    4a8c:      	cmp	x7, x9
    4a90:      	b.ne	0x4ac0 <_stogir.atomic.validate+0xe4>
    4a94:      	cmp	x5, x7
    4a98:      	b.gt	0x4cc8 <_stogir.atomic.validate+0x2ec>
    4a9c:      	lsl	x5, x6, #2
    4aa0:      	ldr	x5, [x0, #0x50]
    4aa4:      	add	x5, x5, x6, lsl #2
    4aa8:      	ldr	w5, [x5]
    4aac:      	sxtw	x5, w5
    4ab0:      	cmp	x5, #0x0
    4ab4:      	cset	w5, gt
    4ab8:      	ubfx	x5, x5, #0, #8
    4abc:      	b	0x4ccc <_stogir.atomic.validate+0x2f0>
    4ac0:      	movz	x5, #0x0, lsl #48
    4ac4:      	b	0x4ad4 <_stogir.atomic.validate+0xf8>
    4ac8:      	movz	x5, #0x0, lsl #48
    4acc:      	b	0x4ad4 <_stogir.atomic.validate+0xf8>
    4ad0:      	movz	x5, #0x0, lsl #48
    4ad4:      	cmp	x5, #0x0
    4ad8:      	b.eq	0x4b38 <_stogir.atomic.validate+0x15c>
    4adc:      	uxtb	w16, w4
    4ae0:      	cmp	w16, wzr
    4ae4:      	b.eq	0x4b0c <_stogir.atomic.validate+0x130>
    4ae8:      	lsl	x4, x2, #4
    4aec:      	ldr	x4, [x0]
    4af0:      	add	x4, x4, x2, lsl #4
    4af4:      	ldr	x5, [x4]
    4af8:      	ldr	x4, [x4, #0x8]
    4afc:      	fmov	d31, x4
    4b00:      	mov	x4, x5
    4b04:      	fmov	x5, d31
    4b08:      	b	0x4b2c <_stogir.atomic.validate+0x150>
    4b0c:      	lsl	x4, x6, #4
    4b10:      	ldr	x4, [x0, #0x28]
    4b14:      	add	x4, x4, x6, lsl #4
    4b18:      	ldr	x5, [x4]
    4b1c:      	ldr	x4, [x4, #0x8]
    4b20:      	fmov	d31, x4
    4b24:      	mov	x4, x5
    4b28:      	fmov	x5, d31
    4b2c:      	mov	x19, x4
    4b30:      	mov	x4, #0x1                ; =1
    4b34:      	b	0x4b44 <_stogir.atomic.validate+0x168>
    4b38:      	movz	x4, #0x0, lsl #48
    4b3c:      	movz	x19, #0x0, lsl #48
    4b40:      	movz	x5, #0x0, lsl #48
    4b44:      	lsr	w4, w4, #0
    4b48:      	lsr	x16, x4, #0
    4b4c:      	cmp	x16, #0x1
    4b50:      	b.eq	0x4b6c <_stogir.atomic.validate+0x190>
    4b54:      	b.lo	0x4b5c <_stogir.atomic.validate+0x180>
    4b58:      	b	0x4b70 <_stogir.atomic.validate+0x194>
    4b5c:      	cmp	x16, #0x0
    4b60:      	b.eq	0x4b68 <_stogir.atomic.validate+0x18c>
    4b64:      	b	0x4b70 <_stogir.atomic.validate+0x194>
    4b68:      	b	0x4b74 <_stogir.atomic.validate+0x198>
    4b6c:      	b	0x4bd0 <_stogir.atomic.validate+0x1f4>
    4b70:      	b	0x5278 <_stogir.atomic.validate+0x89c>
    4b74:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x38c>
		0000000000004b74:  ARM64_RELOC_PAGE21	l_stogir.370
    4b78:      	ldr	x16, [x16]
		0000000000004b78:  ARM64_RELOC_PAGEOFF12	l_stogir.370
    4b7c:      	orr	x0, x16, xzr
    4b80:      	mov	x23, x8
    4b84:      	mov	x1, x0
    4b88:      	mov	x0, #0x1                ; =1
    4b8c:      	mov	x2, #0x1a               ; =26
    4b90:      	str	x0, [x23]
    4b94:      	str	x1, [x23, #0x8]
    4b98:      	str	x2, [x23, #0x10]
    4b9c:      	ldr	x19, [sp, #0xa0]
    4ba0:      	ldr	x20, [sp, #0xa8]
    4ba4:      	ldr	x21, [sp, #0xb0]
    4ba8:      	ldr	x22, [sp, #0xb8]
    4bac:      	ldr	x23, [sp, #0xc0]
    4bb0:      	ldr	x24, [sp, #0xc8]
    4bb4:      	ldr	x25, [sp, #0xd0]
    4bb8:      	ldr	x26, [sp, #0xd8]
    4bbc:      	ldr	x27, [sp, #0xe0]
    4bc0:      	ldr	x29, [sp, #0x10]
    4bc4:      	ldr	x30, [sp, #0x18]
    4bc8:      	add	sp, sp, #0xf0
    4bcc:      	ret
    4bd0:      	uxtb	w4, w19
    4bd4:      	add	x16, sp, #0x20
    4bd8:      	str	x19, [x16]
    4bdc:      	orr	x20, x4, xzr
    4be0:      	add	x16, sp, #0x20
    4be4:      	str	x5, [x16, #0x8]
    4be8:      	cmp	x2, #0x0
    4bec:      	b.le	0x4c48 <_stogir.atomic.validate+0x26c>
    4bf0:      	cmp	x20, #0x7e
    4bf4:      	b.lt	0x4c48 <_stogir.atomic.validate+0x26c>
    4bf8:      	cmp	x20, #0x82
    4bfc:      	b.gt	0x4c48 <_stogir.atomic.validate+0x26c>
    4c00:      	ldr	x2, [x0, #0x78]
    4c04:      	add	x2, x3, x2
    4c08:      	ldr	w2, [x2]
    4c0c:      	cmp	x20, #0x83
    4c10:      	b.ge	0x5198 <_stogir.atomic.validate+0x7bc>
    4c14:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x38c>
		0000000000004c14:  ARM64_RELOC_PAGE21	l_stogir.371
    4c18:      	ldr	x16, [x16]
		0000000000004c18:  ARM64_RELOC_PAGEOFF12	l_stogir.371
    4c1c:      	orr	x3, x16, xzr
    4c20:      	add	x3, x20, x3
    4c24:      	ldrsb	w3, [x3]
    4c28:      	sxtb	x3, w3
    4c2c:      	b	0x519c <_stogir.atomic.validate+0x7c0>
    4c30:      	movz	x5, #0x0, lsl #48
    4c34:      	b	0x4acc <_stogir.atomic.validate+0xf0>
    4c38:      	mov	x2, x1
    4c3c:      	mov	x1, x0
    4c40:      	mov	x0, #0x1                ; =1
    4c44:      	b	0x4b90 <_stogir.atomic.validate+0x1b4>
    4c48:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x38c>
		0000000000004c48:  ARM64_RELOC_PAGE21	l_stogir.372
    4c4c:      	ldr	x16, [x16]
		0000000000004c4c:  ARM64_RELOC_PAGEOFF12	l_stogir.372
    4c50:      	orr	x2, x16, xzr
    4c54:      	mov	x21, x2
    4c58:      	mov	x22, #0x20              ; =32
    4c5c:      	add	x16, sp, #0x20
    4c60:      	ldr	w2, [x16, #0x4]
    4c64:      	lsr	w2, w2, #0
    4c68:      	mov	x23, x8
    4c6c:      	add	x8, sp, #0x30
    4c70:      	mov	x24, x0
    4c74:      	mov	w25, w1
    4c78:      	mov	w1, w2
    4c7c:      	bl	0x4c7c <_stogir.atomic.validate+0x2a0>
		0000000000004c7c:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    4c80:      	add	x16, sp, #0x30
    4c84:      	ldr	w0, [x16]
    4c88:      	lsr	x16, x0, #0
    4c8c:      	cmp	x16, #0x1
    4c90:      	b.eq	0x4cac <_stogir.atomic.validate+0x2d0>
    4c94:      	b.lo	0x4c9c <_stogir.atomic.validate+0x2c0>
    4c98:      	b	0x4cb0 <_stogir.atomic.validate+0x2d4>
    4c9c:      	cmp	x16, #0x0
    4ca0:      	b.eq	0x4ca8 <_stogir.atomic.validate+0x2cc>
    4ca4:      	b	0x4cb0 <_stogir.atomic.validate+0x2d4>
    4ca8:      	b	0x4cb4 <_stogir.atomic.validate+0x2d8>
    4cac:      	b	0x4dac <_stogir.atomic.validate+0x3d0>
    4cb0:      	b	0x52ac <_stogir.atomic.validate+0x8d0>
    4cb4:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x38c>
		0000000000004cb4:  ARM64_RELOC_PAGE21	l_stogir.373
    4cb8:      	ldr	x16, [x16]
		0000000000004cb8:  ARM64_RELOC_PAGEOFF12	l_stogir.373
    4cbc:      	orr	x0, x16, xzr
    4cc0:      	mov	x1, #0x16               ; =22
    4cc4:      	b	0x4cd8 <_stogir.atomic.validate+0x2fc>
    4cc8:      	movz	x5, #0x0, lsl #48
    4ccc:      	b	0x4ac4 <_stogir.atomic.validate+0xe8>
    4cd0:      	mov	x0, x1
    4cd4:      	mov	x1, x22
    4cd8:      	cmp	x20, #0x82
    4cdc:      	cset	w21, eq
    4ce0:      	lsr	w19, w19, #0
    4ce4:      	ubfx	x2, x19, #8, #8
    4ce8:      	orr	x19, x2, xzr
    4cec:      	cmp	x19, #0x0
    4cf0:      	cset	w22, eq
    4cf4:      	uxtb	w16, w21
    4cf8:      	cmp	w16, wzr
    4cfc:      	b.eq	0x4d24 <_stogir.atomic.validate+0x348>
    4d00:      	uxtb	w16, w22
    4d04:      	cmp	w16, wzr
    4d08:      	b.ne	0x4d1c <_stogir.atomic.validate+0x340>
    4d0c:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x38c>
		0000000000004d0c:  ARM64_RELOC_PAGE21	l_stogir.374
    4d10:      	ldr	x16, [x16]
		0000000000004d10:  ARM64_RELOC_PAGEOFF12	l_stogir.374
    4d14:      	orr	x0, x16, xzr
    4d18:      	mov	x1, #0x19               ; =25
    4d1c:      	mov	x26, x1
    4d20:      	b	0x4d28 <_stogir.atomic.validate+0x34c>
    4d24:      	mov	x26, x1
    4d28:      	uxtb	w16, w21
    4d2c:      	cmp	w16, wzr
    4d30:      	b.eq	0x4d40 <_stogir.atomic.validate+0x364>
    4d34:      	mov	x27, x0
    4d38:      	movz	x0, #0x0, lsl #48
    4d3c:      	b	0x4d48 <_stogir.atomic.validate+0x36c>
    4d40:      	mov	x27, x0
    4d44:      	mov	x0, #0x1                ; =1
    4d48:      	cmp	x0, #0x0
    4d4c:      	b.eq	0x4d80 <_stogir.atomic.validate+0x3a4>
    4d50:      	add	x16, sp, #0x20
    4d54:      	ldr	w0, [x16, #0x8]
    4d58:      	lsr	w0, w0, #0
    4d5c:      	mov	w1, w0
    4d60:      	mov	x0, x24
    4d64:      	mov	x2, #0x6                ; =6
    4d68:      	bl	0x4d68 <_stogir.atomic.validate+0x38c>
		0000000000004d68:  ARM64_RELOC_BRANCH26	_stogir.atomic.ordinary?
    4d6c:      	cmp	x0, #0x0
    4d70:      	b.eq	0x4ee4 <_stogir.atomic.validate+0x508>
    4d74:      	mov	x1, x27
    4d78:      	movz	x0, #0x0, lsl #48
    4d7c:      	b	0x4eec <_stogir.atomic.validate+0x510>
    4d80:      	mov	x0, x19
    4d84:      	mov	x1, x27
    4d88:      	mov	x19, x26
    4d8c:      	cmp	x20, #0x80
    4d90:      	cset	w22, eq
    4d94:      	uxtb	w16, w22
    4d98:      	cmp	w16, wzr
    4d9c:      	b.eq	0x4dd4 <_stogir.atomic.validate+0x3f8>
    4da0:      	mov	x20, x1
    4da4:      	mov	x1, #0x1                ; =1
    4da8:      	b	0x4de8 <_stogir.atomic.validate+0x40c>
    4dac:      	add	x16, sp, #0x30
    4db0:      	ldr	x0, [x16, #0x8]
    4db4:      	add	x16, sp, #0x20
    4db8:      	ldr	w1, [x16, #0x4]
    4dbc:      	sxtw	x1, w1
    4dc0:      	cmp	x1, #0x0
    4dc4:      	b.gt	0x4f54 <_stogir.atomic.validate+0x578>
    4dc8:      	mov	x1, x21
    4dcc:      	mov	x0, #0x1                ; =1
    4dd0:      	b	0x4f38 <_stogir.atomic.validate+0x55c>
    4dd4:      	cmp	x20, #0x81
    4dd8:      	cset	w2, eq
    4ddc:      	ubfx	x2, x2, #0, #8
    4de0:      	mov	x20, x1
    4de4:      	mov	x1, x2
    4de8:      	lsr	w26, w0, #0
    4dec:      	cmp	x1, #0x0
    4df0:      	b.eq	0x4e70 <_stogir.atomic.validate+0x494>
    4df4:      	lsr	w25, w25, #0
    4df8:      	add	x16, sp, #0x90
    4dfc:      	str	x16, [sp]
    4e00:      	mov	x0, x24
    4e04:      	mov	w1, w25
    4e08:      	mov	x2, #0x4                ; =4
    4e0c:      	bl	0x4e0c <_stogir.atomic.validate+0x430>
		0000000000004e0c:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    4e10:      	ldr	x16, [sp]
    4e14:      	str	x0, [x16]
    4e18:      	str	x1, [x16, #0x8]
    4e1c:      	add	x16, sp, #0x90
    4e20:      	ldr	x0, [x16]
    4e24:      	add	x16, sp, #0x90
    4e28:      	ldr	x1, [x16, #0x8]
    4e2c:      	lsr	w0, w0, #0
    4e30:      	lsr	x16, x0, #0
    4e34:      	cmp	x16, #0x1
    4e38:      	b.eq	0x4e54 <_stogir.atomic.validate+0x478>
    4e3c:      	b.lo	0x4e44 <_stogir.atomic.validate+0x468>
    4e40:      	b	0x4e58 <_stogir.atomic.validate+0x47c>
    4e44:      	cmp	x16, #0x0
    4e48:      	b.eq	0x4e50 <_stogir.atomic.validate+0x474>
    4e4c:      	b	0x4e58 <_stogir.atomic.validate+0x47c>
    4e50:      	b	0x4e5c <_stogir.atomic.validate+0x480>
    4e54:      	b	0x508c <_stogir.atomic.validate+0x6b0>
    4e58:      	b	0x52bc <_stogir.atomic.validate+0x8e0>
    4e5c:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x38c>
		0000000000004e5c:  ARM64_RELOC_PAGE21	l_stogir.375
    4e60:      	ldr	x16, [x16]
		0000000000004e60:  ARM64_RELOC_PAGEOFF12	l_stogir.375
    4e64:      	orr	x0, x16, xzr
    4e68:      	mov	x1, #0x1d               ; =29
    4e6c:      	b	0x4ee0 <_stogir.atomic.validate+0x504>
    4e70:      	mov	x0, x20
    4e74:      	mov	x1, x19
    4e78:      	cmp	x1, #0x0
    4e7c:      	b.ne	0x4c38 <_stogir.atomic.validate+0x25c>
    4e80:      	uxtb	w16, w21
    4e84:      	cmp	w16, wzr
    4e88:      	b.eq	0x5078 <_stogir.atomic.validate+0x69c>
    4e8c:      	movz	x0, #0x0, lsl #48
    4e90:      	b	0x4ebc <_stogir.atomic.validate+0x4e0>
    4e94:      	mov	x0, x1
    4e98:      	mov	x1, x22
    4e9c:      	fmov	d31, x0
    4ea0:      	mov	x0, x19
    4ea4:      	mov	x19, x1
    4ea8:      	fmov	x1, d31
    4eac:      	b	0x4d8c <_stogir.atomic.validate+0x3b0>
    4eb0:      	mov	x0, #0x1                ; =1
    4eb4:      	lsr	w0, w0, #0
    4eb8:      	sxtw	x0, w0
    4ebc:      	and	x0, x0, #0xffffffff
    4ec0:      	mov	x1, x0
    4ec4:      	movz	x0, #0x0, lsl #48
    4ec8:      	movz	x2, #0x0, lsl #48
    4ecc:      	b	0x4c44 <_stogir.atomic.validate+0x268>
    4ed0:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x38c>
		0000000000004ed0:  ARM64_RELOC_PAGE21	l_stogir.376
    4ed4:      	ldr	x16, [x16]
		0000000000004ed4:  ARM64_RELOC_PAGEOFF12	l_stogir.376
    4ed8:      	orr	x0, x16, xzr
    4edc:      	mov	x1, #0x24               ; =36
    4ee0:      	b	0x4e78 <_stogir.atomic.validate+0x49c>
    4ee4:      	mov	x1, x27
    4ee8:      	mov	x0, #0x1                ; =1
    4eec:      	cmp	x0, #0x0
    4ef0:      	b.eq	0x4f08 <_stogir.atomic.validate+0x52c>
    4ef4:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x38c>
		0000000000004ef4:  ARM64_RELOC_PAGE21	l_stogir.377
    4ef8:      	ldr	x16, [x16]
		0000000000004ef8:  ARM64_RELOC_PAGEOFF12	l_stogir.377
    4efc:      	orr	x0, x16, xzr
    4f00:      	mov	x1, #0x1b               ; =27
    4f04:      	b	0x4f10 <_stogir.atomic.validate+0x534>
    4f08:      	mov	x0, x1
    4f0c:      	mov	x1, x26
    4f10:      	cmp	x20, #0x7f
    4f14:      	b.ne	0x4fa8 <_stogir.atomic.validate+0x5cc>
    4f18:      	uxtb	w16, w22
    4f1c:      	cmp	w16, wzr
    4f20:      	b.eq	0x50b4 <_stogir.atomic.validate+0x6d8>
    4f24:      	mov	x22, x0
    4f28:      	mov	x26, x1
    4f2c:      	b	0x50c8 <_stogir.atomic.validate+0x6ec>
    4f30:      	mov	x0, #0x1                ; =1
    4f34:      	mov	x1, x21
    4f38:      	cmp	x0, #0x0
    4f3c:      	b.eq	0x4cd0 <_stogir.atomic.validate+0x2f4>
    4f40:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x38c>
		0000000000004f40:  ARM64_RELOC_PAGE21	l_stogir.378
    4f44:      	ldr	x16, [x16]
		0000000000004f44:  ARM64_RELOC_PAGEOFF12	l_stogir.378
    4f48:      	orr	x0, x16, xzr
    4f4c:      	mov	x1, #0x16               ; =22
    4f50:      	b	0x4cd8 <_stogir.atomic.validate+0x2fc>
    4f54:      	uxtb	w0, w0
    4f58:      	cmp	x0, #0x83
    4f5c:      	cset	w1, lt
    4f60:      	uxtb	w16, w1
    4f64:      	cmp	w16, wzr
    4f68:      	b.eq	0x515c <_stogir.atomic.validate+0x780>
    4f6c:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x38c>
		0000000000004f6c:  ARM64_RELOC_PAGE21	l_stogir.379
    4f70:      	ldr	x16, [x16]
		0000000000004f70:  ARM64_RELOC_PAGEOFF12	l_stogir.379
    4f74:      	orr	x2, x16, xzr
    4f78:      	add	x2, x0, x2
    4f7c:      	ldrb	w2, [x2]
    4f80:      	b	0x5160 <_stogir.atomic.validate+0x784>
    4f84:      	add	x16, sp, #0x60
    4f88:      	ldr	x0, [x16, #0x8]
    4f8c:      	lsr	w0, w0, #0
    4f90:      	ubfx	x0, x0, #8, #8
    4f94:      	mov	x1, x22
    4f98:      	mov	x2, x26
    4f9c:      	mov	x19, x0
    4fa0:      	mov	x0, x1
    4fa4:      	mov	x1, x2
    4fa8:      	cmp	x19, #0x2
    4fac:      	b.ge	0x5044 <_stogir.atomic.validate+0x668>
    4fb0:      	mov	x2, x1
    4fb4:      	mov	x1, #0x1                ; =1
    4fb8:      	b	0x505c <_stogir.atomic.validate+0x680>
    4fbc:      	mov	x1, x26
    4fc0:      	movz	x0, #0x0, lsl #48
    4fc4:      	cmp	x0, #0x0
    4fc8:      	b.eq	0x4e94 <_stogir.atomic.validate+0x4b8>
    4fcc:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x38c>
		0000000000004fcc:  ARM64_RELOC_PAGE21	l_stogir.380
    4fd0:      	ldr	x16, [x16]
		0000000000004fd0:  ARM64_RELOC_PAGEOFF12	l_stogir.380
    4fd4:      	orr	x0, x16, xzr
    4fd8:      	mov	x1, #0x22               ; =34
    4fdc:      	b	0x4e9c <_stogir.atomic.validate+0x4c0>
    4fe0:      	mov	x1, x26
    4fe4:      	mov	x0, #0x1                ; =1
    4fe8:      	b	0x4fc4 <_stogir.atomic.validate+0x5e8>
    4fec:      	mov	x26, x0
    4ff0:      	mov	x0, #0x1                ; =1
    4ff4:      	cmp	x0, #0x0
    4ff8:      	b.eq	0x4fbc <_stogir.atomic.validate+0x5e0>
    4ffc:      	lsr	w0, w19, #0
    5000:      	add	x16, sp, #0x20
    5004:      	ldr	w1, [x16, #0xc]
    5008:      	lsr	w1, w1, #0
    500c:      	mov	w2, w0
    5010:      	mov	x0, x24
    5014:      	bl	0x5014 <_stogir.atomic.validate+0x638>
		0000000000005014:  ARM64_RELOC_BRANCH26	_stogir.atomic.ordinary?
    5018:      	cmp	x0, #0x0
    501c:      	b.eq	0x4fe0 <_stogir.atomic.validate+0x604>
    5020:      	mov	x1, x26
    5024:      	movz	x0, #0x0, lsl #48
    5028:      	b	0x4fe8 <_stogir.atomic.validate+0x60c>
    502c:      	mov	x22, x2
    5030:      	cmp	x20, #0x7e
    5034:      	b.ne	0x4fec <_stogir.atomic.validate+0x610>
    5038:      	mov	x26, x0
    503c:      	movz	x0, #0x0, lsl #48
    5040:      	b	0x4ff4 <_stogir.atomic.validate+0x618>
    5044:      	cmp	x19, #0x5
    5048:      	cset	w2, gt
    504c:      	ubfx	x2, x2, #0, #8
    5050:      	fmov	d31, x1
    5054:      	mov	x1, x2
    5058:      	fmov	x2, d31
    505c:      	cmp	x1, #0x0
    5060:      	b.eq	0x502c <_stogir.atomic.validate+0x650>
    5064:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x624>
		0000000000005064:  ARM64_RELOC_PAGE21	l_stogir.381
    5068:      	ldr	x16, [x16]
		0000000000005068:  ARM64_RELOC_PAGEOFF12	l_stogir.381
    506c:      	orr	x0, x16, xzr
    5070:      	mov	x22, #0x25              ; =37
    5074:      	b	0x5030 <_stogir.atomic.validate+0x654>
    5078:      	sxtw	x26, w26
    507c:      	cmp	x26, #0x0
    5080:      	b.ne	0x51c8 <_stogir.atomic.validate+0x7ec>
    5084:      	movz	x0, #0x0, lsl #48
    5088:      	b	0x4eb4 <_stogir.atomic.validate+0x4d8>
    508c:      	lsr	w1, w1, #0
    5090:      	uxtb	w16, w22
    5094:      	cmp	w16, wzr
    5098:      	b.eq	0x5254 <_stogir.atomic.validate+0x878>
    509c:      	sxtw	x1, w1
    50a0:      	cmp	x1, #0x0
    50a4:      	b.ge	0x5280 <_stogir.atomic.validate+0x8a4>
    50a8:      	mov	x1, x20
    50ac:      	mov	x0, #0x1                ; =1
    50b0:      	b	0x5290 <_stogir.atomic.validate+0x8b4>
    50b4:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x624>
		00000000000050b4:  ARM64_RELOC_PAGE21	l_stogir.382
    50b8:      	ldr	x16, [x16]
		00000000000050b8:  ARM64_RELOC_PAGEOFF12	l_stogir.382
    50bc:      	orr	x0, x16, xzr
    50c0:      	mov	x22, x0
    50c4:      	mov	x26, #0x19              ; =25
    50c8:      	add	x16, sp, #0x20
    50cc:      	ldr	w0, [x16, #0xc]
    50d0:      	lsr	w0, w0, #0
    50d4:      	add	x8, sp, #0x60
    50d8:      	mov	w1, w0
    50dc:      	mov	x0, x24
    50e0:      	bl	0x50e0 <_stogir.atomic.validate+0x704>
		00000000000050e0:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    50e4:      	add	x16, sp, #0x60
    50e8:      	ldr	w0, [x16]
    50ec:      	lsr	x16, x0, #0
    50f0:      	cmp	x16, #0x1
    50f4:      	b.eq	0x5110 <_stogir.atomic.validate+0x734>
    50f8:      	b.lo	0x5100 <_stogir.atomic.validate+0x724>
    50fc:      	b	0x5114 <_stogir.atomic.validate+0x738>
    5100:      	cmp	x16, #0x0
    5104:      	b.eq	0x510c <_stogir.atomic.validate+0x730>
    5108:      	b	0x5114 <_stogir.atomic.validate+0x738>
    510c:      	b	0x5118 <_stogir.atomic.validate+0x73c>
    5110:      	b	0x4f84 <_stogir.atomic.validate+0x5a8>
    5114:      	b	0x52c4 <_stogir.atomic.validate+0x8e8>
    5118:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x624>
		0000000000005118:  ARM64_RELOC_PAGE21	l_stogir.383
    511c:      	ldr	x16, [x16]
		000000000000511c:  ARM64_RELOC_PAGEOFF12	l_stogir.383
    5120:      	orr	x0, x16, xzr
    5124:      	mov	x1, x0
    5128:      	mov	x0, x19
    512c:      	mov	x2, #0x1a               ; =26
    5130:      	b	0x4f9c <_stogir.atomic.validate+0x5c0>
    5134:      	movz	x0, #0x0, lsl #48
    5138:      	uxtb	w0, w0
    513c:      	and	x0, x0, #0x4
    5140:      	uxtb	w0, w0
    5144:      	cmp	x0, #0x0
    5148:      	cset	w0, eq
    514c:      	uxtb	w16, w0
    5150:      	cmp	w16, wzr
    5154:      	cset	x0, eq
    5158:      	b	0x4f34 <_stogir.atomic.validate+0x558>
    515c:      	movz	x2, #0x0, lsl #48
    5160:      	uxtb	w2, w2
    5164:      	and	x2, x2, #0x1
    5168:      	uxtb	w2, w2
    516c:      	cmp	x2, #0x0
    5170:      	b.eq	0x4f30 <_stogir.atomic.validate+0x554>
    5174:      	uxtb	w16, w1
    5178:      	cmp	w16, wzr
    517c:      	b.eq	0x5134 <_stogir.atomic.validate+0x758>
    5180:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x624>
		0000000000005180:  ARM64_RELOC_PAGE21	l_stogir.379
    5184:      	ldr	x16, [x16]
		0000000000005184:  ARM64_RELOC_PAGEOFF12	l_stogir.379
    5188:      	orr	x1, x16, xzr
    518c:      	add	x0, x0, x1
    5190:      	ldrb	w0, [x0]
    5194:      	b	0x5138 <_stogir.atomic.validate+0x75c>
    5198:      	mov	x3, #-0x2               ; =-2
    519c:      	sxtw	x2, w2
    51a0:      	lsr	w3, w3, #0
    51a4:      	sxtw	x3, w3
    51a8:      	cmp	x2, x3
    51ac:      	b.ne	0x4c48 <_stogir.atomic.validate+0x26c>
    51b0:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x624>
		00000000000051b0:  ARM64_RELOC_PAGE21	l_stogir.384
    51b4:      	ldr	x16, [x16]
		00000000000051b4:  ARM64_RELOC_PAGEOFF12	l_stogir.384
    51b8:      	orr	x2, x16, xzr
    51bc:      	mov	x21, x2
    51c0:      	movz	x22, #0x0, lsl #48
    51c4:      	b	0x4c5c <_stogir.atomic.validate+0x280>
    51c8:      	cmp	x26, #0x1
    51cc:      	b.eq	0x4eb0 <_stogir.atomic.validate+0x4d4>
    51d0:      	cmp	x26, #0x2
    51d4:      	b.eq	0x4eb0 <_stogir.atomic.validate+0x4d4>
    51d8:      	cmp	x26, #0x7
    51dc:      	b.eq	0x4eb0 <_stogir.atomic.validate+0x4d4>
    51e0:      	cmp	x26, #0x8
    51e4:      	b.eq	0x4eb0 <_stogir.atomic.validate+0x4d4>
    51e8:      	cmp	x26, #0x3
    51ec:      	b.eq	0x52b4 <_stogir.atomic.validate+0x8d8>
    51f0:      	cmp	x26, #0x9
    51f4:      	b.eq	0x52b4 <_stogir.atomic.validate+0x8d8>
    51f8:      	cmp	x26, #0x4
    51fc:      	b.eq	0x52cc <_stogir.atomic.validate+0x8f0>
    5200:      	cmp	x26, #0xa
    5204:      	b.eq	0x52cc <_stogir.atomic.validate+0x8f0>
    5208:      	cmp	x26, #0xd
    520c:      	b.eq	0x52cc <_stogir.atomic.validate+0x8f0>
    5210:      	cmp	x26, #0x5
    5214:      	b.eq	0x52d4 <_stogir.atomic.validate+0x8f8>
    5218:      	cmp	x26, #0xb
    521c:      	b.eq	0x52d4 <_stogir.atomic.validate+0x8f8>
    5220:      	cmp	x26, #0xc
    5224:      	b.eq	0x52d4 <_stogir.atomic.validate+0x8f8>
    5228:      	cmp	x26, #0x6
    522c:      	cset	w0, eq
    5230:      	uxtb	w16, w0
    5234:      	cmp	w16, wzr
    5238:      	mov	x16, #0x8               ; =8
    523c:      	movn	x17, #0x0, lsl #48
    5240:      	csel	x0, x16, x17, ne
    5244:      	b	0x52d8 <_stogir.atomic.validate+0x8fc>
    5248:      	mov	x0, x1
    524c:      	mov	x1, x19
    5250:      	b	0x4ee0 <_stogir.atomic.validate+0x504>
    5254:      	lsr	w1, w1, #0
    5258:      	mov	x0, x24
    525c:      	mov	w2, w26
    5260:      	bl	0x5260 <_stogir.atomic.validate+0x884>
		0000000000005260:  ARM64_RELOC_BRANCH26	_stogir.atomic.ordinary?
    5264:      	cmp	x0, #0x0
    5268:      	b.eq	0x4ed0 <_stogir.atomic.validate+0x4f4>
    526c:      	mov	x0, x20
    5270:      	mov	x1, x19
    5274:      	b	0x4ee0 <_stogir.atomic.validate+0x504>
    5278:      	brk	#0
    527c:      	b	0x5278 <_stogir.atomic.validate+0x89c>
    5280:      	cmp	x1, #0x9
    5284:      	cset	w0, gt
    5288:      	ubfx	x0, x0, #0, #8
    528c:      	mov	x1, x20
    5290:      	cmp	x0, #0x0
    5294:      	b.eq	0x5248 <_stogir.atomic.validate+0x86c>
    5298:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x624>
		0000000000005298:  ARM64_RELOC_PAGE21	l_stogir.385
    529c:      	ldr	x16, [x16]
		000000000000529c:  ARM64_RELOC_PAGEOFF12	l_stogir.385
    52a0:      	orr	x0, x16, xzr
    52a4:      	mov	x1, #0x1c               ; =28
    52a8:      	b	0x5250 <_stogir.atomic.validate+0x874>
    52ac:      	brk	#0
    52b0:      	b	0x52ac <_stogir.atomic.validate+0x8d0>
    52b4:      	mov	x0, #0x2                ; =2
    52b8:      	b	0x4eb4 <_stogir.atomic.validate+0x4d8>
    52bc:      	brk	#0
    52c0:      	b	0x52bc <_stogir.atomic.validate+0x8e0>
    52c4:      	brk	#0
    52c8:      	b	0x52c4 <_stogir.atomic.validate+0x8e8>
    52cc:      	mov	x0, #0x4                ; =4
    52d0:      	b	0x52b8 <_stogir.atomic.validate+0x8dc>
    52d4:      	mov	x0, #0x8                ; =8
    52d8:      	b	0x52d0 <_stogir.atomic.validate+0x8f4>

00000000000052dc <_stogir.terminal.operation?>:
    52dc:      	sxtw	x0, w0
    52e0:      	cmp	x0, #0x60
    52e4:      	b.ne	0x52f0 <_stogir.terminal.operation?+0x14>
    52e8:      	mov	x0, #0x1                ; =1
    52ec:      	b	0x52fc <_stogir.terminal.operation?+0x20>
    52f0:      	cmp	x0, #0x79
    52f4:      	cset	w0, eq
    52f8:      	ubfx	x0, x0, #0, #8
    52fc:      	ret

0000000000005300 <_stogir.terminal.validate>:
    5300:      	sub	sp, sp, #0x50
    5304:      	str	x29, [sp]
    5308:      	str	x30, [sp, #0x8]
    530c:      	mov	x29, sp
    5310:      	str	x19, [sp, #0x40]
    5314:      	sxtw	x1, w1
    5318:      	lsl	x2, x1, #2
    531c:      	cmp	x1, #0x0
    5320:      	cset	w3, gt
    5324:      	movz	x16, #0x0, lsl #48
    5328:      	sub	x4, x16, x1
    532c:      	sub	x5, x4, #0x1
    5330:      	uxtb	w16, w3
    5334:      	cmp	w16, wzr
    5338:      	b.eq	0x5378 <_stogir.terminal.validate+0x78>
    533c:      	ldr	x4, [x0, #0x8]
    5340:      	cmp	x1, x4
    5344:      	b.ge	0x53cc <_stogir.terminal.validate+0xcc>
    5348:      	add	x4, x0, #0x78
    534c:      	ldr	x4, [x4, #0x8]
    5350:      	cmp	x1, x4
    5354:      	b.ge	0x54f0 <_stogir.terminal.validate+0x1f0>
    5358:      	ldr	x4, [x0, #0x78]
    535c:      	add	x4, x2, x4
    5360:      	ldr	w4, [x4]
    5364:      	sxtw	x4, w4
    5368:      	cmp	x4, #0x0
    536c:      	cset	w4, ge
    5370:      	ubfx	x4, x4, #0, #8
    5374:      	b	0x54f4 <_stogir.terminal.validate+0x1f4>
    5378:      	cmp	x1, #0x0
    537c:      	b.ge	0x53d4 <_stogir.terminal.validate+0xd4>
    5380:      	add	x6, x0, #0x28
    5384:      	add	x7, x0, #0x50
    5388:      	ldr	x6, [x6, #0x8]
    538c:      	ldr	x7, [x7, #0x8]
    5390:      	cmp	x6, x7
    5394:      	b.ne	0x53c4 <_stogir.terminal.validate+0xc4>
    5398:      	cmp	x4, x6
    539c:      	b.gt	0x5530 <_stogir.terminal.validate+0x230>
    53a0:      	lsl	x4, x5, #2
    53a4:      	ldr	x4, [x0, #0x50]
    53a8:      	add	x4, x4, x5, lsl #2
    53ac:      	ldr	w4, [x4]
    53b0:      	sxtw	x4, w4
    53b4:      	cmp	x4, #0x0
    53b8:      	cset	w4, gt
    53bc:      	ubfx	x4, x4, #0, #8
    53c0:      	b	0x5534 <_stogir.terminal.validate+0x234>
    53c4:      	movz	x4, #0x0, lsl #48
    53c8:      	b	0x53d8 <_stogir.terminal.validate+0xd8>
    53cc:      	movz	x4, #0x0, lsl #48
    53d0:      	b	0x53d8 <_stogir.terminal.validate+0xd8>
    53d4:      	movz	x4, #0x0, lsl #48
    53d8:      	cmp	x4, #0x0
    53dc:      	b.eq	0x5440 <_stogir.terminal.validate+0x140>
    53e0:      	uxtb	w16, w3
    53e4:      	cmp	w16, wzr
    53e8:      	b.eq	0x5410 <_stogir.terminal.validate+0x110>
    53ec:      	lsl	x3, x1, #4
    53f0:      	ldr	x3, [x0]
    53f4:      	add	x3, x3, x1, lsl #4
    53f8:      	ldr	x4, [x3]
    53fc:      	ldr	x3, [x3, #0x8]
    5400:      	fmov	d31, x3
    5404:      	mov	x3, x4
    5408:      	fmov	x4, d31
    540c:      	b	0x5430 <_stogir.terminal.validate+0x130>
    5410:      	lsl	x3, x5, #4
    5414:      	ldr	x3, [x0, #0x28]
    5418:      	add	x3, x3, x5, lsl #4
    541c:      	ldr	x4, [x3]
    5420:      	ldr	x3, [x3, #0x8]
    5424:      	fmov	d31, x3
    5428:      	mov	x3, x4
    542c:      	fmov	x4, d31
    5430:      	mov	x5, x4
    5434:      	mov	x4, x3
    5438:      	mov	x3, #0x1                ; =1
    543c:      	b	0x544c <_stogir.terminal.validate+0x14c>
    5440:      	movz	x3, #0x0, lsl #48
    5444:      	movz	x4, #0x0, lsl #48
    5448:      	movz	x5, #0x0, lsl #48
    544c:      	lsr	w3, w3, #0
    5450:      	lsr	x16, x3, #0
    5454:      	cmp	x16, #0x1
    5458:      	b.eq	0x5474 <_stogir.terminal.validate+0x174>
    545c:      	b.lo	0x5464 <_stogir.terminal.validate+0x164>
    5460:      	b	0x5478 <_stogir.terminal.validate+0x178>
    5464:      	cmp	x16, #0x0
    5468:      	b.eq	0x5470 <_stogir.terminal.validate+0x170>
    546c:      	b	0x5478 <_stogir.terminal.validate+0x178>
    5470:      	b	0x547c <_stogir.terminal.validate+0x17c>
    5474:      	b	0x549c <_stogir.terminal.validate+0x19c>
    5478:      	b	0x560c <_stogir.terminal.validate+0x30c>
    547c:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x624>
		000000000000547c:  ARM64_RELOC_PAGE21	l_stogir.386
    5480:      	ldr	x16, [x16]
		0000000000005480:  ARM64_RELOC_PAGEOFF12	l_stogir.386
    5484:      	orr	x0, x16, xzr
    5488:      	mov	x19, x8
    548c:      	mov	x1, x0
    5490:      	mov	x0, #0x1                ; =1
    5494:      	mov	x2, #0x21               ; =33
    5498:      	b	0x54d0 <_stogir.terminal.validate+0x1d0>
    549c:      	add	x16, sp, #0x10
    54a0:      	str	x4, [x16]
    54a4:      	add	x16, sp, #0x10
    54a8:      	str	x5, [x16, #0x8]
    54ac:      	cmp	x1, #0x0
    54b0:      	b.gt	0x54f8 <_stogir.terminal.validate+0x1f8>
    54b4:      	mov	x19, x8
    54b8:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x624>
		00000000000054b8:  ARM64_RELOC_PAGE21	l_stogir.387
    54bc:      	ldr	x16, [x16]
		00000000000054bc:  ARM64_RELOC_PAGEOFF12	l_stogir.387
    54c0:      	orr	x0, x16, xzr
    54c4:      	mov	x1, x0
    54c8:      	mov	x0, #0x1                ; =1
    54cc:      	mov	x2, #0x1b               ; =27
    54d0:      	str	x0, [x19]
    54d4:      	str	x1, [x19, #0x8]
    54d8:      	str	x2, [x19, #0x10]
    54dc:      	ldr	x19, [sp, #0x40]
    54e0:      	ldr	x29, [sp]
    54e4:      	ldr	x30, [sp, #0x8]
    54e8:      	add	sp, sp, #0x50
    54ec:      	ret
    54f0:      	movz	x4, #0x0, lsl #48
    54f4:      	b	0x53d0 <_stogir.terminal.validate+0xd0>
    54f8:      	uxtb	w4, w4
    54fc:      	orr	x1, x4, xzr
    5500:      	cmp	x1, #0x60
    5504:      	cset	w3, eq
    5508:      	cmp	x1, #0x79
    550c:      	cset	w1, eq
    5510:      	uxtb	w16, w3
    5514:      	cmp	w16, wzr
    5518:      	b.ne	0x5538 <_stogir.terminal.validate+0x238>
    551c:      	uxtb	w16, w1
    5520:      	cmp	w16, wzr
    5524:      	b.ne	0x5538 <_stogir.terminal.validate+0x238>
    5528:      	mov	x19, x8
    552c:      	b	0x54b8 <_stogir.terminal.validate+0x1b8>
    5530:      	movz	x4, #0x0, lsl #48
    5534:      	b	0x53c8 <_stogir.terminal.validate+0xc8>
    5538:      	add	x16, sp, #0x10
    553c:      	ldr	w5, [x16]
    5540:      	ubfx	x5, x5, #8, #8
    5544:      	cmp	x5, #0x0
    5548:      	b.ne	0x5614 <_stogir.terminal.validate+0x314>
    554c:      	uxtb	w16, w3
    5550:      	cmp	w16, wzr
    5554:      	mov	x16, #0x1               ; =1
    5558:      	mov	x17, #0x3               ; =3
    555c:      	csel	x3, x16, x17, ne
    5560:      	lsr	w3, w3, #0
    5564:      	sxtw	x3, w3
    5568:      	ldr	x5, [x0, #0x78]
    556c:      	add	x2, x2, x5
    5570:      	ldr	w2, [x2]
    5574:      	sxtw	x2, w2
    5578:      	cmp	x2, x3
    557c:      	b.ne	0x561c <_stogir.terminal.validate+0x31c>
    5580:      	uxtb	w16, w1
    5584:      	cmp	w16, wzr
    5588:      	b.eq	0x55e8 <_stogir.terminal.validate+0x2e8>
    558c:      	add	x16, sp, #0x10
    5590:      	ldr	w2, [x16, #0x8]
    5594:      	sxtw	x2, w2
    5598:      	cmp	x2, #0x0
    559c:      	b.eq	0x55e8 <_stogir.terminal.validate+0x2e8>
    55a0:      	mov	x19, x8
    55a4:      	b	0x54b8 <_stogir.terminal.validate+0x1b8>
    55a8:      	movz	x1, #0x0, lsl #48
    55ac:      	lsr	w2, w2, #0
    55b0:      	lsr	w4, w4, #0
    55b4:      	lsr	w1, w1, #0
    55b8:      	mov	w3, w1
    55bc:      	mov	w1, w4
    55c0:      	mov	x19, x8
    55c4:      	add	x8, sp, #0x20
    55c8:      	bl	0x55c8 <_stogir.terminal.validate+0x2c8>
		00000000000055c8:  ARM64_RELOC_BRANCH26	_stogir.terminal.inputs
    55cc:      	add	x16, sp, #0x20
    55d0:      	ldr	x0, [x16]
    55d4:      	add	x16, sp, #0x20
    55d8:      	ldr	x1, [x16, #0x8]
    55dc:      	add	x16, sp, #0x20
    55e0:      	ldr	x2, [x16, #0x10]
    55e4:      	b	0x54d0 <_stogir.terminal.validate+0x1d0>
    55e8:      	add	x16, sp, #0x10
    55ec:      	ldr	w2, [x16, #0x4]
    55f0:      	uxtb	w16, w1
    55f4:      	cmp	w16, wzr
    55f8:      	b.eq	0x55a8 <_stogir.terminal.validate+0x2a8>
    55fc:      	add	x16, sp, #0x10
    5600:      	ldr	w1, [x16, #0xc]
    5604:      	sxtw	x1, w1
    5608:      	b	0x55ac <_stogir.terminal.validate+0x2ac>
    560c:      	brk	#0
    5610:      	b	0x560c <_stogir.terminal.validate+0x30c>
    5614:      	mov	x19, x8
    5618:      	b	0x54b8 <_stogir.terminal.validate+0x1b8>
    561c:      	mov	x19, x8
    5620:      	b	0x54b8 <_stogir.terminal.validate+0x1b8>

0000000000005624 <_stogir.switch.operation?>:
    5624:      	sxtw	x0, w0
    5628:      	cmp	x0, #0x75
    562c:      	b.ne	0x5640 <_stogir.switch.operation?+0x1c>
    5630:      	mov	x0, #0x1                ; =1
    5634:      	b	0x563c <_stogir.switch.operation?+0x18>
    5638:      	movz	x0, #0x0, lsl #48
    563c:      	ret
    5640:      	cmp	x0, #0x6d
    5644:      	b.lt	0x5638 <_stogir.switch.operation?+0x14>
    5648:      	cmp	x0, #0x6f
    564c:      	cset	w0, le
    5650:      	ubfx	x0, x0, #0, #8
    5654:      	b	0x563c <_stogir.switch.operation?+0x18>

0000000000005658 <_stogir.switch.validate>:
    5658:      	sub	sp, sp, #0x70
    565c:      	str	x29, [sp]
    5660:      	str	x30, [sp, #0x8]
    5664:      	mov	x29, sp
    5668:      	str	x19, [sp, #0x60]
    566c:      	sxtw	x1, w1
    5670:      	lsl	x2, x1, #2
    5674:      	cmp	x1, #0x0
    5678:      	cset	w3, gt
    567c:      	movz	x16, #0x0, lsl #48
    5680:      	sub	x4, x16, x1
    5684:      	sub	x5, x4, #0x1
    5688:      	uxtb	w16, w3
    568c:      	cmp	w16, wzr
    5690:      	b.eq	0x56d0 <_stogir.switch.validate+0x78>
    5694:      	ldr	x4, [x0, #0x8]
    5698:      	cmp	x1, x4
    569c:      	b.ge	0x5724 <_stogir.switch.validate+0xcc>
    56a0:      	add	x4, x0, #0x78
    56a4:      	ldr	x4, [x4, #0x8]
    56a8:      	cmp	x1, x4
    56ac:      	b.ge	0x5848 <_stogir.switch.validate+0x1f0>
    56b0:      	ldr	x4, [x0, #0x78]
    56b4:      	add	x4, x2, x4
    56b8:      	ldr	w4, [x4]
    56bc:      	sxtw	x4, w4
    56c0:      	cmp	x4, #0x0
    56c4:      	cset	w4, ge
    56c8:      	ubfx	x4, x4, #0, #8
    56cc:      	b	0x584c <_stogir.switch.validate+0x1f4>
    56d0:      	cmp	x1, #0x0
    56d4:      	b.ge	0x572c <_stogir.switch.validate+0xd4>
    56d8:      	add	x6, x0, #0x28
    56dc:      	add	x7, x0, #0x50
    56e0:      	ldr	x6, [x6, #0x8]
    56e4:      	ldr	x7, [x7, #0x8]
    56e8:      	cmp	x6, x7
    56ec:      	b.ne	0x571c <_stogir.switch.validate+0xc4>
    56f0:      	cmp	x4, x6
    56f4:      	b.gt	0x5884 <_stogir.switch.validate+0x22c>
    56f8:      	lsl	x4, x5, #2
    56fc:      	ldr	x4, [x0, #0x50]
    5700:      	add	x4, x4, x5, lsl #2
    5704:      	ldr	w4, [x4]
    5708:      	sxtw	x4, w4
    570c:      	cmp	x4, #0x0
    5710:      	cset	w4, gt
    5714:      	ubfx	x4, x4, #0, #8
    5718:      	b	0x5888 <_stogir.switch.validate+0x230>
    571c:      	movz	x4, #0x0, lsl #48
    5720:      	b	0x5730 <_stogir.switch.validate+0xd8>
    5724:      	movz	x4, #0x0, lsl #48
    5728:      	b	0x5730 <_stogir.switch.validate+0xd8>
    572c:      	movz	x4, #0x0, lsl #48
    5730:      	cmp	x4, #0x0
    5734:      	b.eq	0x5798 <_stogir.switch.validate+0x140>
    5738:      	uxtb	w16, w3
    573c:      	cmp	w16, wzr
    5740:      	b.eq	0x5768 <_stogir.switch.validate+0x110>
    5744:      	lsl	x3, x1, #4
    5748:      	ldr	x3, [x0]
    574c:      	add	x3, x3, x1, lsl #4
    5750:      	ldr	x4, [x3]
    5754:      	ldr	x3, [x3, #0x8]
    5758:      	fmov	d31, x3
    575c:      	mov	x3, x4
    5760:      	fmov	x4, d31
    5764:      	b	0x5788 <_stogir.switch.validate+0x130>
    5768:      	lsl	x3, x5, #4
    576c:      	ldr	x3, [x0, #0x28]
    5770:      	add	x3, x3, x5, lsl #4
    5774:      	ldr	x4, [x3]
    5778:      	ldr	x3, [x3, #0x8]
    577c:      	fmov	d31, x3
    5780:      	mov	x3, x4
    5784:      	fmov	x4, d31
    5788:      	mov	x5, x4
    578c:      	mov	x4, x3
    5790:      	mov	x3, #0x1                ; =1
    5794:      	b	0x57a4 <_stogir.switch.validate+0x14c>
    5798:      	movz	x3, #0x0, lsl #48
    579c:      	movz	x4, #0x0, lsl #48
    57a0:      	movz	x5, #0x0, lsl #48
    57a4:      	lsr	w3, w3, #0
    57a8:      	lsr	x16, x3, #0
    57ac:      	cmp	x16, #0x1
    57b0:      	b.eq	0x57cc <_stogir.switch.validate+0x174>
    57b4:      	b.lo	0x57bc <_stogir.switch.validate+0x164>
    57b8:      	b	0x57d0 <_stogir.switch.validate+0x178>
    57bc:      	cmp	x16, #0x0
    57c0:      	b.eq	0x57c8 <_stogir.switch.validate+0x170>
    57c4:      	b	0x57d0 <_stogir.switch.validate+0x178>
    57c8:      	b	0x57d4 <_stogir.switch.validate+0x17c>
    57cc:      	b	0x57f4 <_stogir.switch.validate+0x19c>
    57d0:      	b	0x5988 <_stogir.switch.validate+0x330>
    57d4:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x624>
		00000000000057d4:  ARM64_RELOC_PAGE21	l_stogir.388
    57d8:      	ldr	x16, [x16]
		00000000000057d8:  ARM64_RELOC_PAGEOFF12	l_stogir.388
    57dc:      	orr	x0, x16, xzr
    57e0:      	mov	x19, x8
    57e4:      	mov	x1, x0
    57e8:      	mov	x0, #0x1                ; =1
    57ec:      	mov	x2, #0x1a               ; =26
    57f0:      	b	0x5828 <_stogir.switch.validate+0x1d0>
    57f4:      	add	x16, sp, #0x10
    57f8:      	str	x4, [x16]
    57fc:      	add	x16, sp, #0x10
    5800:      	str	x5, [x16, #0x8]
    5804:      	cmp	x1, #0x0
    5808:      	b.gt	0x5850 <_stogir.switch.validate+0x1f8>
    580c:      	mov	x19, x8
    5810:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x624>
		0000000000005810:  ARM64_RELOC_PAGE21	l_stogir.389
    5814:      	ldr	x16, [x16]
		0000000000005814:  ARM64_RELOC_PAGEOFF12	l_stogir.389
    5818:      	orr	x0, x16, xzr
    581c:      	mov	x1, x0
    5820:      	mov	x0, #0x1                ; =1
    5824:      	mov	x2, #0x20               ; =32
    5828:      	str	x0, [x19]
    582c:      	str	x1, [x19, #0x8]
    5830:      	str	x2, [x19, #0x10]
    5834:      	ldr	x19, [sp, #0x60]
    5838:      	ldr	x29, [sp]
    583c:      	ldr	x30, [sp, #0x8]
    5840:      	add	sp, sp, #0x70
    5844:      	ret
    5848:      	movz	x4, #0x0, lsl #48
    584c:      	b	0x5728 <_stogir.switch.validate+0xd0>
    5850:      	uxtb	w4, w4
    5854:      	orr	x1, x4, xzr
    5858:      	cmp	x1, #0x75
    585c:      	cset	w3, eq
    5860:      	uxtb	w16, w3
    5864:      	cmp	w16, wzr
    5868:      	b.ne	0x588c <_stogir.switch.validate+0x234>
    586c:      	cmp	x1, #0x6d
    5870:      	b.lt	0x5990 <_stogir.switch.validate+0x338>
    5874:      	cmp	x1, #0x6f
    5878:      	b.le	0x588c <_stogir.switch.validate+0x234>
    587c:      	mov	x19, x8
    5880:      	b	0x5810 <_stogir.switch.validate+0x1b8>
    5884:      	movz	x4, #0x0, lsl #48
    5888:      	b	0x5720 <_stogir.switch.validate+0xc8>
    588c:      	add	x16, sp, #0x10
    5890:      	ldr	w5, [x16]
    5894:      	ubfx	x5, x5, #8, #8
    5898:      	cmp	x5, #0x0
    589c:      	b.ne	0x5998 <_stogir.switch.validate+0x340>
    58a0:      	ldr	x5, [x0, #0x78]
    58a4:      	add	x2, x2, x5
    58a8:      	ldr	w2, [x2]
    58ac:      	cmp	x1, #0x6d
    58b0:      	b.eq	0x5924 <_stogir.switch.validate+0x2cc>
    58b4:      	cmp	x1, #0x6e
    58b8:      	b.eq	0x5924 <_stogir.switch.validate+0x2cc>
    58bc:      	mov	x1, #0x2                ; =2
    58c0:      	b	0x5928 <_stogir.switch.validate+0x2d0>
    58c4:      	lsr	w4, w4, #0
    58c8:      	add	x16, sp, #0x10
    58cc:      	ldr	w1, [x16, #0x4]
    58d0:      	add	x16, sp, #0x10
    58d4:      	ldr	w2, [x16, #0x8]
    58d8:      	lsr	w1, w1, #0
    58dc:      	add	x16, sp, #0x10
    58e0:      	ldr	w3, [x16, #0xc]
    58e4:      	lsr	w2, w2, #0
    58e8:      	lsr	w3, w3, #0
    58ec:      	add	x8, sp, #0x40
    58f0:      	fmov	s31, w1
    58f4:      	mov	w1, w4
    58f8:      	mov	w4, w3
    58fc:      	mov	w3, w2
    5900:      	fmov	w2, s31
    5904:      	bl	0x5904 <_stogir.switch.validate+0x2ac>
		0000000000005904:  ARM64_RELOC_BRANCH26	_stogir.switch.case-inputs
    5908:      	add	x16, sp, #0x40
    590c:      	ldr	x0, [x16]
    5910:      	add	x16, sp, #0x40
    5914:      	ldr	x1, [x16, #0x8]
    5918:      	add	x16, sp, #0x40
    591c:      	ldr	x2, [x16, #0x10]
    5920:      	b	0x5828 <_stogir.switch.validate+0x1d0>
    5924:      	mov	x1, #0x3                ; =3
    5928:      	sxtw	x2, w2
    592c:      	lsr	w1, w1, #0
    5930:      	sxtw	x1, w1
    5934:      	cmp	x2, x1
    5938:      	b.ne	0x59a0 <_stogir.switch.validate+0x348>
    593c:      	uxtb	w16, w3
    5940:      	cmp	w16, wzr
    5944:      	b.eq	0x59a8 <_stogir.switch.validate+0x350>
    5948:      	add	x16, sp, #0x10
    594c:      	ldr	w1, [x16, #0x4]
    5950:      	add	x16, sp, #0x10
    5954:      	ldr	w2, [x16, #0x8]
    5958:      	lsr	w1, w1, #0
    595c:      	lsr	w2, w2, #0
    5960:      	mov	x19, x8
    5964:      	add	x8, sp, #0x20
    5968:      	bl	0x5968 <_stogir.switch.validate+0x310>
		0000000000005968:  ARM64_RELOC_BRANCH26	_stogir.switch.switch-inputs
    596c:      	add	x16, sp, #0x20
    5970:      	ldr	x0, [x16]
    5974:      	add	x16, sp, #0x20
    5978:      	ldr	x1, [x16, #0x8]
    597c:      	add	x16, sp, #0x20
    5980:      	ldr	x2, [x16, #0x10]
    5984:      	b	0x5920 <_stogir.switch.validate+0x2c8>
    5988:      	brk	#0
    598c:      	b	0x5988 <_stogir.switch.validate+0x330>
    5990:      	mov	x19, x8
    5994:      	b	0x5810 <_stogir.switch.validate+0x1b8>
    5998:      	mov	x19, x8
    599c:      	b	0x5810 <_stogir.switch.validate+0x1b8>
    59a0:      	mov	x19, x8
    59a4:      	b	0x5810 <_stogir.switch.validate+0x1b8>
    59a8:      	mov	x19, x8
    59ac:      	b	0x58c4 <_stogir.switch.validate+0x26c>

00000000000059b0 <_stogir.stack.operation?>:
    59b0:      	sxtw	x0, w0
    59b4:      	cmp	x0, #0x42
    59b8:      	b.ne	0x59d4 <_stogir.stack.operation?+0x24>
    59bc:      	mov	x0, #0x1                ; =1
    59c0:      	b	0x59d0 <_stogir.stack.operation?+0x20>
    59c4:      	cmp	x0, #0x54
    59c8:      	cset	w0, eq
    59cc:      	ubfx	x0, x0, #0, #8
    59d0:      	ret
    59d4:      	cmp	x0, #0x51
    59d8:      	b.ne	0x59e4 <_stogir.stack.operation?+0x34>
    59dc:      	mov	x0, #0x1                ; =1
    59e0:      	b	0x59d0 <_stogir.stack.operation?+0x20>
    59e4:      	cmp	x0, #0x52
    59e8:      	b.ne	0x59f4 <_stogir.stack.operation?+0x44>
    59ec:      	mov	x0, #0x1                ; =1
    59f0:      	b	0x59d0 <_stogir.stack.operation?+0x20>
    59f4:      	cmp	x0, #0x53
    59f8:      	b.ne	0x59c4 <_stogir.stack.operation?+0x14>
    59fc:      	mov	x0, #0x1                ; =1
    5a00:      	b	0x59d0 <_stogir.stack.operation?+0x20>

0000000000005a04 <_stogir.stack.validate>:
    5a04:      	sub	sp, sp, #0x90
    5a08:      	str	x29, [sp]
    5a0c:      	str	x30, [sp, #0x8]
    5a10:      	mov	x29, sp
    5a14:      	str	x19, [sp, #0x60]
    5a18:      	str	x20, [sp, #0x68]
    5a1c:      	str	x21, [sp, #0x70]
    5a20:      	str	x22, [sp, #0x78]
    5a24:      	str	x23, [sp, #0x80]
    5a28:      	sxtw	x1, w1
    5a2c:      	lsl	x2, x1, #2
    5a30:      	cmp	x1, #0x0
    5a34:      	cset	w3, gt
    5a38:      	movz	x16, #0x0, lsl #48
    5a3c:      	sub	x4, x16, x1
    5a40:      	cmp	x1, #0x0
    5a44:      	cset	w5, lt
    5a48:      	sub	x6, x4, #0x1
    5a4c:      	lsl	x7, x6, #2
    5a50:      	uxtb	w16, w3
    5a54:      	cmp	w16, wzr
    5a58:      	b.eq	0x5a98 <_stogir.stack.validate+0x94>
    5a5c:      	ldr	x9, [x0, #0x8]
    5a60:      	cmp	x1, x9
    5a64:      	b.ge	0x5b18 <_stogir.stack.validate+0x114>
    5a68:      	add	x9, x0, #0x78
    5a6c:      	ldr	x9, [x9, #0x8]
    5a70:      	cmp	x1, x9
    5a74:      	b.ge	0x5c84 <_stogir.stack.validate+0x280>
    5a78:      	ldr	x9, [x0, #0x78]
    5a7c:      	add	x9, x2, x9
    5a80:      	ldr	w9, [x9]
    5a84:      	sxtw	x9, w9
    5a88:      	cmp	x9, #0x0
    5a8c:      	cset	w9, ge
    5a90:      	ubfx	x9, x9, #0, #8
    5a94:      	b	0x5c88 <_stogir.stack.validate+0x284>
    5a98:      	uxtb	w16, w5
    5a9c:      	cmp	w16, wzr
    5aa0:      	b.eq	0x5b20 <_stogir.stack.validate+0x11c>
    5aa4:      	add	x9, x0, #0x28
    5aa8:      	add	x10, x0, #0x50
    5aac:      	ldr	x9, [x9, #0x8]
    5ab0:      	ldr	x10, [x10, #0x8]
    5ab4:      	cmp	x9, x10
    5ab8:      	b.ne	0x5ae4 <_stogir.stack.validate+0xe0>
    5abc:      	cmp	x4, x9
    5ac0:      	b.gt	0x5c8c <_stogir.stack.validate+0x288>
    5ac4:      	ldr	x9, [x0, #0x50]
    5ac8:      	add	x9, x7, x9
    5acc:      	ldr	w9, [x9]
    5ad0:      	sxtw	x9, w9
    5ad4:      	cmp	x9, #0x0
    5ad8:      	cset	w9, gt
    5adc:      	ubfx	x9, x9, #0, #8
    5ae0:      	b	0x5c90 <_stogir.stack.validate+0x28c>
    5ae4:      	movz	x9, #0x0, lsl #48
    5ae8:      	b	0x5b24 <_stogir.stack.validate+0x120>
    5aec:      	uxtb	w16, w9
    5af0:      	cmp	w16, wzr
    5af4:      	b.eq	0x5cb4 <_stogir.stack.validate+0x2b0>
    5af8:      	mov	x22, x8
    5afc:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x624>
		0000000000005afc:  ARM64_RELOC_PAGE21	l_stogir.390
    5b00:      	ldr	x16, [x16]
		0000000000005b00:  ARM64_RELOC_PAGEOFF12	l_stogir.390
    5b04:      	orr	x0, x16, xzr
    5b08:      	mov	x1, x0
    5b0c:      	mov	x0, #0x1                ; =1
    5b10:      	mov	x2, #0x19               ; =25
    5b14:      	b	0x5be4 <_stogir.stack.validate+0x1e0>
    5b18:      	movz	x9, #0x0, lsl #48
    5b1c:      	b	0x5b24 <_stogir.stack.validate+0x120>
    5b20:      	movz	x9, #0x0, lsl #48
    5b24:      	lsl	x10, x1, #4
    5b28:      	lsl	x6, x6, #4
    5b2c:      	cmp	x9, #0x0
    5b30:      	b.eq	0x5b8c <_stogir.stack.validate+0x188>
    5b34:      	uxtb	w16, w3
    5b38:      	cmp	w16, wzr
    5b3c:      	b.eq	0x5b60 <_stogir.stack.validate+0x15c>
    5b40:      	ldr	x9, [x0]
    5b44:      	add	x9, x10, x9
    5b48:      	ldr	x11, [x9]
    5b4c:      	ldr	x9, [x9, #0x8]
    5b50:      	fmov	d31, x9
    5b54:      	mov	x9, x11
    5b58:      	fmov	x11, d31
    5b5c:      	b	0x5b7c <_stogir.stack.validate+0x178>
    5b60:      	ldr	x9, [x0, #0x28]
    5b64:      	add	x9, x6, x9
    5b68:      	ldr	x11, [x9]
    5b6c:      	ldr	x9, [x9, #0x8]
    5b70:      	fmov	d31, x9
    5b74:      	mov	x9, x11
    5b78:      	fmov	x11, d31
    5b7c:      	mov	x12, x11
    5b80:      	mov	x11, x9
    5b84:      	mov	x9, #0x1                ; =1
    5b88:      	b	0x5b98 <_stogir.stack.validate+0x194>
    5b8c:      	movz	x9, #0x0, lsl #48
    5b90:      	movz	x11, #0x0, lsl #48
    5b94:      	movz	x12, #0x0, lsl #48
    5b98:      	lsr	w9, w9, #0
    5b9c:      	lsr	x16, x9, #0
    5ba0:      	cmp	x16, #0x1
    5ba4:      	b.eq	0x5bc0 <_stogir.stack.validate+0x1bc>
    5ba8:      	b.lo	0x5bb0 <_stogir.stack.validate+0x1ac>
    5bac:      	b	0x5bc4 <_stogir.stack.validate+0x1c0>
    5bb0:      	cmp	x16, #0x0
    5bb4:      	b.eq	0x5bbc <_stogir.stack.validate+0x1b8>
    5bb8:      	b	0x5bc4 <_stogir.stack.validate+0x1c0>
    5bbc:      	b	0x5bc8 <_stogir.stack.validate+0x1c4>
    5bc0:      	b	0x5c14 <_stogir.stack.validate+0x210>
    5bc4:      	b	0x600c <_stogir.stack.validate+0x608>
    5bc8:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x624>
		0000000000005bc8:  ARM64_RELOC_PAGE21	l_stogir.391
    5bcc:      	ldr	x16, [x16]
		0000000000005bcc:  ARM64_RELOC_PAGEOFF12	l_stogir.391
    5bd0:      	orr	x0, x16, xzr
    5bd4:      	mov	x22, x8
    5bd8:      	mov	x1, x0
    5bdc:      	mov	x0, #0x1                ; =1
    5be0:      	mov	x2, #0x19               ; =25
    5be4:      	str	x0, [x22]
    5be8:      	str	x1, [x22, #0x8]
    5bec:      	str	x2, [x22, #0x10]
    5bf0:      	ldr	x19, [sp, #0x60]
    5bf4:      	ldr	x20, [sp, #0x68]
    5bf8:      	ldr	x21, [sp, #0x70]
    5bfc:      	ldr	x22, [sp, #0x78]
    5c00:      	ldr	x23, [sp, #0x80]
    5c04:      	ldr	x29, [sp]
    5c08:      	ldr	x30, [sp, #0x8]
    5c0c:      	add	sp, sp, #0x90
    5c10:      	ret
    5c14:      	cmp	x1, #0x0
    5c18:      	cset	w9, le
    5c1c:      	uxtb	w19, w11
    5c20:      	add	x16, sp, #0x10
    5c24:      	str	x11, [x16]
    5c28:      	orr	x11, x19, xzr
    5c2c:      	add	x16, sp, #0x10
    5c30:      	str	x12, [x16, #0x8]
    5c34:      	cmp	x11, #0x42
    5c38:      	b.ne	0x5aec <_stogir.stack.validate+0xe8>
    5c3c:      	uxtb	w16, w3
    5c40:      	cmp	w16, wzr
    5c44:      	b.eq	0x5d00 <_stogir.stack.validate+0x2fc>
    5c48:      	ldr	x4, [x0, #0x8]
    5c4c:      	cmp	x1, x4
    5c50:      	b.ge	0x5d4c <_stogir.stack.validate+0x348>
    5c54:      	add	x4, x0, #0x78
    5c58:      	ldr	x4, [x4, #0x8]
    5c5c:      	cmp	x1, x4
    5c60:      	b.ge	0x5e40 <_stogir.stack.validate+0x43c>
    5c64:      	ldr	x1, [x0, #0x78]
    5c68:      	add	x1, x2, x1
    5c6c:      	ldr	w1, [x1]
    5c70:      	sxtw	x1, w1
    5c74:      	cmp	x1, #0x0
    5c78:      	cset	w1, ge
    5c7c:      	ubfx	x1, x1, #0, #8
    5c80:      	b	0x5e44 <_stogir.stack.validate+0x440>
    5c84:      	movz	x9, #0x0, lsl #48
    5c88:      	b	0x5b1c <_stogir.stack.validate+0x118>
    5c8c:      	movz	x9, #0x0, lsl #48
    5c90:      	b	0x5ae8 <_stogir.stack.validate+0xe4>
    5c94:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x624>
		0000000000005c94:  ARM64_RELOC_PAGE21	l_stogir.392
    5c98:      	ldr	x16, [x16]
		0000000000005c98:  ARM64_RELOC_PAGEOFF12	l_stogir.392
    5c9c:      	orr	x0, x16, xzr
    5ca0:      	mov	x1, x0
    5ca4:      	mov	x0, #0x1                ; =1
    5ca8:      	mov	x2, #0x1e               ; =30
    5cac:      	mov	x22, x8
    5cb0:      	b	0x5b14 <_stogir.stack.validate+0x110>
    5cb4:      	cmp	x11, #0x51
    5cb8:      	cset	w1, eq
    5cbc:      	cmp	x11, #0x53
    5cc0:      	cset	w20, eq
    5cc4:      	cmp	x11, #0x54
    5cc8:      	cset	w21, eq
    5ccc:      	uxtb	w16, w1
    5cd0:      	cmp	w16, wzr
    5cd4:      	b.ne	0x5e48 <_stogir.stack.validate+0x444>
    5cd8:      	cmp	x11, #0x52
    5cdc:      	b.eq	0x5e48 <_stogir.stack.validate+0x444>
    5ce0:      	uxtb	w16, w20
    5ce4:      	cmp	w16, wzr
    5ce8:      	b.ne	0x5e48 <_stogir.stack.validate+0x444>
    5cec:      	uxtb	w16, w21
    5cf0:      	cmp	w16, wzr
    5cf4:      	b.ne	0x5e48 <_stogir.stack.validate+0x444>
    5cf8:      	mov	x22, x8
    5cfc:      	b	0x5afc <_stogir.stack.validate+0xf8>
    5d00:      	uxtb	w16, w5
    5d04:      	cmp	w16, wzr
    5d08:      	b.eq	0x5d54 <_stogir.stack.validate+0x350>
    5d0c:      	add	x1, x0, #0x28
    5d10:      	add	x5, x0, #0x50
    5d14:      	ldr	x1, [x1, #0x8]
    5d18:      	ldr	x5, [x5, #0x8]
    5d1c:      	cmp	x1, x5
    5d20:      	b.ne	0x5e38 <_stogir.stack.validate+0x434>
    5d24:      	cmp	x4, x1
    5d28:      	b.gt	0x5fa4 <_stogir.stack.validate+0x5a0>
    5d2c:      	ldr	x1, [x0, #0x50]
    5d30:      	add	x1, x7, x1
    5d34:      	ldr	w1, [x1]
    5d38:      	sxtw	x1, w1
    5d3c:      	cmp	x1, #0x0
    5d40:      	cset	w1, gt
    5d44:      	ubfx	x1, x1, #0, #8
    5d48:      	b	0x5fa8 <_stogir.stack.validate+0x5a4>
    5d4c:      	movz	x1, #0x0, lsl #48
    5d50:      	b	0x5d58 <_stogir.stack.validate+0x354>
    5d54:      	movz	x1, #0x0, lsl #48
    5d58:      	cmp	x1, #0x0
    5d5c:      	b.eq	0x5d94 <_stogir.stack.validate+0x390>
    5d60:      	uxtb	w16, w3
    5d64:      	cmp	w16, wzr
    5d68:      	b.eq	0x5d7c <_stogir.stack.validate+0x378>
    5d6c:      	ldr	x1, [x0]
    5d70:      	add	x1, x10, x1
    5d74:      	ldr	x1, [x1]
    5d78:      	b	0x5d88 <_stogir.stack.validate+0x384>
    5d7c:      	ldr	x1, [x0, #0x28]
    5d80:      	add	x1, x6, x1
    5d84:      	ldr	x1, [x1]
    5d88:      	mov	x3, x1
    5d8c:      	mov	x1, #0x1                ; =1
    5d90:      	b	0x5d9c <_stogir.stack.validate+0x398>
    5d94:      	movz	x1, #0x0, lsl #48
    5d98:      	movz	x3, #0x0, lsl #48
    5d9c:      	lsr	w1, w1, #0
    5da0:      	lsr	x16, x1, #0
    5da4:      	cmp	x16, #0x1
    5da8:      	b.eq	0x5dc4 <_stogir.stack.validate+0x3c0>
    5dac:      	b.lo	0x5db4 <_stogir.stack.validate+0x3b0>
    5db0:      	b	0x5dc8 <_stogir.stack.validate+0x3c4>
    5db4:      	cmp	x16, #0x0
    5db8:      	b.eq	0x5dc0 <_stogir.stack.validate+0x3bc>
    5dbc:      	b	0x5dc8 <_stogir.stack.validate+0x3c4>
    5dc0:      	b	0x5dcc <_stogir.stack.validate+0x3c8>
    5dc4:      	b	0x5de8 <_stogir.stack.validate+0x3e4>
    5dc8:      	b	0x6014 <_stogir.stack.validate+0x610>
    5dcc:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x624>
		0000000000005dcc:  ARM64_RELOC_PAGE21	l_stogir.393
    5dd0:      	ldr	x16, [x16]
		0000000000005dd0:  ARM64_RELOC_PAGEOFF12	l_stogir.393
    5dd4:      	orr	x0, x16, xzr
    5dd8:      	mov	x1, x0
    5ddc:      	mov	x0, #0x1                ; =1
    5de0:      	mov	x2, #0x21               ; =33
    5de4:      	b	0x5cac <_stogir.stack.validate+0x2a8>
    5de8:      	uxtb	w16, w9
    5dec:      	cmp	w16, wzr
    5df0:      	b.ne	0x5c94 <_stogir.stack.validate+0x290>
    5df4:      	uxtb	w1, w3
    5df8:      	cmp	x1, #0x42
    5dfc:      	b.ne	0x5c94 <_stogir.stack.validate+0x290>
    5e00:      	lsr	w3, w3, #0
    5e04:      	ubfx	x1, x3, #8, #8
    5e08:      	cmp	x1, #0x6
    5e0c:      	b.ne	0x5c94 <_stogir.stack.validate+0x290>
    5e10:      	ldr	x0, [x0, #0x78]
    5e14:      	add	x0, x2, x0
    5e18:      	ldr	w0, [x0]
    5e1c:      	sxtw	x0, w0
    5e20:      	cmp	x0, #0x0
    5e24:      	b.ne	0x5c94 <_stogir.stack.validate+0x290>
    5e28:      	movz	x0, #0x0, lsl #48
    5e2c:      	mov	x1, #0x8                ; =8
    5e30:      	movz	x2, #0x0, lsl #48
    5e34:      	b	0x5cac <_stogir.stack.validate+0x2a8>
    5e38:      	movz	x1, #0x0, lsl #48
    5e3c:      	b	0x5d58 <_stogir.stack.validate+0x354>
    5e40:      	movz	x1, #0x0, lsl #48
    5e44:      	b	0x5d50 <_stogir.stack.validate+0x34c>
    5e48:      	ldr	x3, [x0, #0x78]
    5e4c:      	add	x2, x2, x3
    5e50:      	ldr	w2, [x2]
    5e54:      	uxtb	w16, w1
    5e58:      	cmp	w16, wzr
    5e5c:      	b.eq	0x5ec8 <_stogir.stack.validate+0x4c4>
    5e60:      	mov	x1, #0x3                ; =3
    5e64:      	b	0x5edc <_stogir.stack.validate+0x4d8>
    5e68:      	add	x16, sp, #0x10
    5e6c:      	ldr	w0, [x16]
    5e70:      	add	x16, sp, #0x10
    5e74:      	ldr	w1, [x16, #0x4]
    5e78:      	add	x16, sp, #0x10
    5e7c:      	ldr	w2, [x16, #0x8]
    5e80:      	lsr	w1, w1, #0
    5e84:      	ubfx	x0, x0, #8, #8
    5e88:      	lsr	w2, w2, #0
    5e8c:      	lsr	w0, w0, #0
    5e90:      	add	x8, sp, #0x20
    5e94:      	mov	w3, w1
    5e98:      	mov	w1, w19
    5e9c:      	mov	w4, w2
    5ea0:      	mov	w2, w0
    5ea4:      	mov	x0, x23
    5ea8:      	bl	0x5ea8 <_stogir.stack.validate+0x4a4>
		0000000000005ea8:  ARM64_RELOC_BRANCH26	_stogir.stack.validate-scope-inputs
    5eac:      	add	x16, sp, #0x20
    5eb0:      	ldr	x0, [x16]
    5eb4:      	add	x16, sp, #0x20
    5eb8:      	ldr	x1, [x16, #0x8]
    5ebc:      	add	x16, sp, #0x20
    5ec0:      	ldr	x2, [x16, #0x10]
    5ec4:      	b	0x5b14 <_stogir.stack.validate+0x110>
    5ec8:      	uxtb	w16, w20
    5ecc:      	cmp	w16, wzr
    5ed0:      	mov	x16, #0x1               ; =1
    5ed4:      	mov	x17, #0x2               ; =2
    5ed8:      	csel	x1, x16, x17, ne
    5edc:      	sxtw	x2, w2
    5ee0:      	lsr	w1, w1, #0
    5ee4:      	sxtw	x1, w1
    5ee8:      	cmp	x2, x1
    5eec:      	b.ne	0x601c <_stogir.stack.validate+0x618>
    5ef0:      	add	x16, sp, #0x10
    5ef4:      	ldr	w1, [x16]
    5ef8:      	orr	x2, x1, xzr
    5efc:      	ubfx	x2, x2, #16, #16
    5f00:      	and	x2, x2, #0x8000
    5f04:      	uxth	w2, w2
    5f08:      	cmp	x2, #0x0
    5f0c:      	b.ne	0x5fac <_stogir.stack.validate+0x5a8>
    5f10:      	mov	x22, x8
    5f14:      	mov	x23, x0
    5f18:      	lsr	w19, w19, #0
    5f1c:      	uxtb	w16, w20
    5f20:      	cmp	w16, wzr
    5f24:      	b.ne	0x5e68 <_stogir.stack.validate+0x464>
    5f28:      	uxtb	w16, w21
    5f2c:      	cmp	w16, wzr
    5f30:      	b.ne	0x5e68 <_stogir.stack.validate+0x464>
    5f34:      	add	x16, sp, #0x10
    5f38:      	ldr	w0, [x16]
    5f3c:      	add	x16, sp, #0x10
    5f40:      	ldr	w1, [x16, #0x4]
    5f44:      	add	x16, sp, #0x10
    5f48:      	ldr	w2, [x16, #0x8]
    5f4c:      	lsr	w1, w1, #0
    5f50:      	ubfx	x0, x0, #8, #8
    5f54:      	add	x16, sp, #0x10
    5f58:      	ldr	w3, [x16, #0xc]
    5f5c:      	lsr	w2, w2, #0
    5f60:      	lsr	w3, w3, #0
    5f64:      	lsr	w0, w0, #0
    5f68:      	add	x8, sp, #0x40
    5f6c:      	mov	w4, w2
    5f70:      	mov	w2, w0
    5f74:      	mov	x0, x23
    5f78:      	mov	w5, w3
    5f7c:      	mov	w3, w1
    5f80:      	mov	w1, w19
    5f84:      	bl	0x5f84 <_stogir.stack.validate+0x580>
		0000000000005f84:  ARM64_RELOC_BRANCH26	_stogir.stack.validate-inputs
    5f88:      	add	x16, sp, #0x40
    5f8c:      	ldr	x0, [x16]
    5f90:      	add	x16, sp, #0x40
    5f94:      	ldr	x1, [x16, #0x8]
    5f98:      	add	x16, sp, #0x40
    5f9c:      	ldr	x2, [x16, #0x10]
    5fa0:      	b	0x5ec4 <_stogir.stack.validate+0x4c0>
    5fa4:      	movz	x1, #0x0, lsl #48
    5fa8:      	b	0x5e3c <_stogir.stack.validate+0x438>
    5fac:      	uxtb	w2, w1
    5fb0:      	cmp	x2, #0x51
    5fb4:      	b.ne	0x6024 <_stogir.stack.validate+0x620>
    5fb8:      	ubfx	x1, x1, #16, #16
    5fbc:      	cmp	x1, #0x8, lsl #12       ; =0x8000
    5fc0:      	b.ne	0x602c <_stogir.stack.validate+0x628>
    5fc4:      	add	x16, sp, #0x10
    5fc8:      	ldr	w1, [x16, #0x4]
    5fcc:      	add	x16, sp, #0x10
    5fd0:      	ldr	w2, [x16, #0x8]
    5fd4:      	lsr	w1, w1, #0
    5fd8:      	lsr	w2, w2, #0
    5fdc:      	mov	x22, x8
    5fe0:      	mov	x23, x0
    5fe4:      	bl	0x5fe4 <_stogir.stack.validate+0x5e0>
		0000000000005fe4:  ARM64_RELOC_BRANCH26	_stogir.stack.valid-frame-object-inputs?
    5fe8:      	cmp	x0, #0x0
    5fec:      	b.ne	0x5f18 <_stogir.stack.validate+0x514>
    5ff0:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x624>
		0000000000005ff0:  ARM64_RELOC_PAGE21	l_stogir.394
    5ff4:      	ldr	x16, [x16]
		0000000000005ff4:  ARM64_RELOC_PAGEOFF12	l_stogir.394
    5ff8:      	orr	x0, x16, xzr
    5ffc:      	mov	x1, x0
    6000:      	mov	x0, #0x1                ; =1
    6004:      	mov	x2, #0x26               ; =38
    6008:      	b	0x5ec4 <_stogir.stack.validate+0x4c0>
    600c:      	brk	#0
    6010:      	b	0x600c <_stogir.stack.validate+0x608>
    6014:      	brk	#0
    6018:      	b	0x6014 <_stogir.stack.validate+0x610>
    601c:      	mov	x22, x8
    6020:      	b	0x5afc <_stogir.stack.validate+0xf8>
    6024:      	mov	x22, x8
    6028:      	b	0x5ff0 <_stogir.stack.validate+0x5ec>
    602c:      	mov	x22, x8
    6030:      	b	0x5ff0 <_stogir.stack.validate+0x5ec>

0000000000006034 <_stogir.locals.operation?>:
    6034:      	sxtw	x0, w0
    6038:      	cmp	x0, #0x41
    603c:      	b.ne	0x6050 <_stogir.locals.operation?+0x1c>
    6040:      	mov	x0, #0x1                ; =1
    6044:      	b	0x604c <_stogir.locals.operation?+0x18>
    6048:      	movz	x0, #0x0, lsl #48
    604c:      	ret
    6050:      	cmp	x0, #0x48
    6054:      	b.ne	0x6060 <_stogir.locals.operation?+0x2c>
    6058:      	mov	x0, #0x1                ; =1
    605c:      	b	0x604c <_stogir.locals.operation?+0x18>
    6060:      	cmp	x0, #0x55
    6064:      	b.lt	0x6048 <_stogir.locals.operation?+0x14>
    6068:      	cmp	x0, #0x58
    606c:      	cset	w0, le
    6070:      	ubfx	x0, x0, #0, #8
    6074:      	b	0x604c <_stogir.locals.operation?+0x18>

0000000000006078 <_stogir.locals.validate>:
    6078:      	sub	sp, sp, #0xb0
    607c:      	str	x29, [sp]
    6080:      	str	x30, [sp, #0x8]
    6084:      	mov	x29, sp
    6088:      	str	x19, [sp, #0x70]
    608c:      	str	x20, [sp, #0x78]
    6090:      	str	x21, [sp, #0x80]
    6094:      	str	x22, [sp, #0x88]
    6098:      	str	x23, [sp, #0x90]
    609c:      	str	x24, [sp, #0x98]
    60a0:      	str	x25, [sp, #0xa0]
    60a4:      	sxtw	x1, w1
    60a8:      	lsl	x3, x1, #2
    60ac:      	cmp	x1, #0x0
    60b0:      	cset	w4, gt
    60b4:      	movz	x16, #0x0, lsl #48
    60b8:      	sub	x5, x16, x1
    60bc:      	sub	x6, x5, #0x1
    60c0:      	uxtb	w16, w4
    60c4:      	cmp	w16, wzr
    60c8:      	b.eq	0x6108 <_stogir.locals.validate+0x90>
    60cc:      	ldr	x5, [x0, #0x8]
    60d0:      	cmp	x1, x5
    60d4:      	b.ge	0x61a8 <_stogir.locals.validate+0x130>
    60d8:      	add	x5, x0, #0x78
    60dc:      	ldr	x5, [x5, #0x8]
    60e0:      	cmp	x1, x5
    60e4:      	b.ge	0x62d0 <_stogir.locals.validate+0x258>
    60e8:      	ldr	x5, [x0, #0x78]
    60ec:      	add	x5, x3, x5
    60f0:      	ldr	w5, [x5]
    60f4:      	sxtw	x5, w5
    60f8:      	cmp	x5, #0x0
    60fc:      	cset	w5, ge
    6100:      	ubfx	x5, x5, #0, #8
    6104:      	b	0x62d4 <_stogir.locals.validate+0x25c>
    6108:      	cmp	x1, #0x0
    610c:      	b.ge	0x61b0 <_stogir.locals.validate+0x138>
    6110:      	add	x7, x0, #0x28
    6114:      	add	x9, x0, #0x50
    6118:      	ldr	x7, [x7, #0x8]
    611c:      	ldr	x9, [x9, #0x8]
    6120:      	cmp	x7, x9
    6124:      	b.ne	0x6154 <_stogir.locals.validate+0xdc>
    6128:      	cmp	x5, x7
    612c:      	b.gt	0x6358 <_stogir.locals.validate+0x2e0>
    6130:      	lsl	x5, x6, #2
    6134:      	ldr	x5, [x0, #0x50]
    6138:      	add	x5, x5, x6, lsl #2
    613c:      	ldr	w5, [x5]
    6140:      	sxtw	x5, w5
    6144:      	cmp	x5, #0x0
    6148:      	cset	w5, gt
    614c:      	ubfx	x5, x5, #0, #8
    6150:      	b	0x635c <_stogir.locals.validate+0x2e4>
    6154:      	movz	x5, #0x0, lsl #48
    6158:      	b	0x61b4 <_stogir.locals.validate+0x13c>
    615c:      	cmp	x5, #0x0
    6160:      	cset	w5, ne
    6164:      	uxtb	w16, w5
    6168:      	cmp	w16, wzr
    616c:      	mov	x16, #0x2               ; =2
    6170:      	mov	x17, #0x3               ; =3
    6174:      	csel	x5, x16, x17, ne
    6178:      	lsr	w5, w5, #0
    617c:      	sxtw	x5, w5
    6180:      	cmp	x1, #0x0
    6184:      	b.gt	0x62d8 <_stogir.locals.validate+0x260>
    6188:      	mov	x23, x8
    618c:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x5fc>
		000000000000618c:  ARM64_RELOC_PAGE21	l_stogir.395
    6190:      	ldr	x16, [x16]
		0000000000006190:  ARM64_RELOC_PAGEOFF12	l_stogir.395
    6194:      	orr	x0, x16, xzr
    6198:      	mov	x1, x0
    619c:      	mov	x0, #0x1                ; =1
    61a0:      	mov	x2, #0x17               ; =23
    61a4:      	b	0x6274 <_stogir.locals.validate+0x1fc>
    61a8:      	movz	x5, #0x0, lsl #48
    61ac:      	b	0x61b4 <_stogir.locals.validate+0x13c>
    61b0:      	movz	x5, #0x0, lsl #48
    61b4:      	cmp	x5, #0x0
    61b8:      	b.eq	0x621c <_stogir.locals.validate+0x1a4>
    61bc:      	uxtb	w16, w4
    61c0:      	cmp	w16, wzr
    61c4:      	b.eq	0x61ec <_stogir.locals.validate+0x174>
    61c8:      	lsl	x4, x1, #4
    61cc:      	ldr	x4, [x0]
    61d0:      	add	x4, x4, x1, lsl #4
    61d4:      	ldr	x5, [x4]
    61d8:      	ldr	x4, [x4, #0x8]
    61dc:      	fmov	d31, x4
    61e0:      	mov	x4, x5
    61e4:      	fmov	x5, d31
    61e8:      	b	0x620c <_stogir.locals.validate+0x194>
    61ec:      	lsl	x4, x6, #4
    61f0:      	ldr	x4, [x0, #0x28]
    61f4:      	add	x4, x4, x6, lsl #4
    61f8:      	ldr	x5, [x4]
    61fc:      	ldr	x4, [x4, #0x8]
    6200:      	fmov	d31, x4
    6204:      	mov	x4, x5
    6208:      	fmov	x5, d31
    620c:      	mov	x6, x5
    6210:      	mov	x5, x4
    6214:      	mov	x4, #0x1                ; =1
    6218:      	b	0x6228 <_stogir.locals.validate+0x1b0>
    621c:      	movz	x4, #0x0, lsl #48
    6220:      	movz	x5, #0x0, lsl #48
    6224:      	movz	x6, #0x0, lsl #48
    6228:      	lsr	w4, w4, #0
    622c:      	lsr	x16, x4, #0
    6230:      	cmp	x16, #0x1
    6234:      	b.eq	0x6250 <_stogir.locals.validate+0x1d8>
    6238:      	b.lo	0x6240 <_stogir.locals.validate+0x1c8>
    623c:      	b	0x6254 <_stogir.locals.validate+0x1dc>
    6240:      	cmp	x16, #0x0
    6244:      	b.eq	0x624c <_stogir.locals.validate+0x1d4>
    6248:      	b	0x6254 <_stogir.locals.validate+0x1dc>
    624c:      	b	0x6258 <_stogir.locals.validate+0x1e0>
    6250:      	b	0x62ac <_stogir.locals.validate+0x234>
    6254:      	b	0x649c <_stogir.locals.validate+0x424>
    6258:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x5fc>
		0000000000006258:  ARM64_RELOC_PAGE21	l_stogir.396
    625c:      	ldr	x16, [x16]
		000000000000625c:  ARM64_RELOC_PAGEOFF12	l_stogir.396
    6260:      	orr	x0, x16, xzr
    6264:      	mov	x23, x8
    6268:      	mov	x1, x0
    626c:      	mov	x0, #0x1                ; =1
    6270:      	mov	x2, #0x17               ; =23
    6274:      	str	x0, [x23]
    6278:      	str	x1, [x23, #0x8]
    627c:      	str	x2, [x23, #0x10]
    6280:      	ldr	x19, [sp, #0x70]
    6284:      	ldr	x20, [sp, #0x78]
    6288:      	ldr	x21, [sp, #0x80]
    628c:      	ldr	x22, [sp, #0x88]
    6290:      	ldr	x23, [sp, #0x90]
    6294:      	ldr	x24, [sp, #0x98]
    6298:      	ldr	x25, [sp, #0xa0]
    629c:      	ldr	x29, [sp]
    62a0:      	ldr	x30, [sp, #0x8]
    62a4:      	add	sp, sp, #0xb0
    62a8:      	ret
    62ac:      	uxtb	w4, w5
    62b0:      	add	x16, sp, #0x10
    62b4:      	str	x5, [x16]
    62b8:      	add	x16, sp, #0x10
    62bc:      	str	x6, [x16, #0x8]
    62c0:      	cmp	x4, #0x55
    62c4:      	b.ne	0x633c <_stogir.locals.validate+0x2c4>
    62c8:      	mov	x5, #0x1                ; =1
    62cc:      	b	0x6348 <_stogir.locals.validate+0x2d0>
    62d0:      	movz	x5, #0x0, lsl #48
    62d4:      	b	0x61ac <_stogir.locals.validate+0x134>
    62d8:      	cmp	x4, #0x48
    62dc:      	cset	w21, eq
    62e0:      	uxtb	w16, w20
    62e4:      	cmp	w16, wzr
    62e8:      	b.ne	0x6360 <_stogir.locals.validate+0x2e8>
    62ec:      	uxtb	w16, w21
    62f0:      	cmp	w16, wzr
    62f4:      	b.ne	0x6360 <_stogir.locals.validate+0x2e8>
    62f8:      	cmp	x4, #0x55
    62fc:      	b.lt	0x6834 <_stogir.locals.validate+0x7bc>
    6300:      	cmp	x4, #0x58
    6304:      	b.le	0x6360 <_stogir.locals.validate+0x2e8>
    6308:      	mov	x23, x8
    630c:      	b	0x618c <_stogir.locals.validate+0x114>
    6310:      	cmp	x4, #0x58
    6314:      	cset	w6, eq
    6318:      	ubfx	x6, x6, #0, #8
    631c:      	mov	x19, x6
    6320:      	cmp	x4, #0x41
    6324:      	cset	w20, eq
    6328:      	uxtb	w16, w20
    632c:      	cmp	w16, wzr
    6330:      	b.eq	0x615c <_stogir.locals.validate+0xe4>
    6334:      	mov	x5, #0x1                ; =1
    6338:      	b	0x6180 <_stogir.locals.validate+0x108>
    633c:      	cmp	x4, #0x56
    6340:      	cset	w5, eq
    6344:      	ubfx	x5, x5, #0, #8
    6348:      	cmp	x4, #0x57
    634c:      	b.ne	0x6310 <_stogir.locals.validate+0x298>
    6350:      	mov	x19, #0x1               ; =1
    6354:      	b	0x6320 <_stogir.locals.validate+0x2a8>
    6358:      	movz	x5, #0x0, lsl #48
    635c:      	b	0x6158 <_stogir.locals.validate+0xe0>
    6360:      	lsr	w5, w5, #0
    6364:      	sxtw	x5, w5
    6368:      	ldr	x4, [x0, #0x78]
    636c:      	add	x3, x3, x4
    6370:      	ldr	w3, [x3]
    6374:      	sxtw	x3, w3
    6378:      	cmp	x3, x5
    637c:      	b.ne	0x683c <_stogir.locals.validate+0x7c4>
    6380:      	uxtb	w16, w20
    6384:      	cmp	w16, wzr
    6388:      	b.ne	0x63a8 <_stogir.locals.validate+0x330>
    638c:      	uxtb	w16, w21
    6390:      	cmp	w16, wzr
    6394:      	b.ne	0x63a8 <_stogir.locals.validate+0x330>
    6398:      	add	x16, sp, #0x10
    639c:      	ldr	w1, [x16, #0x8]
    63a0:      	sxtw	x1, w1
    63a4:      	b	0x63c0 <_stogir.locals.validate+0x348>
    63a8:      	uxtb	w16, w21
    63ac:      	cmp	w16, wzr
    63b0:      	b.ne	0x63c0 <_stogir.locals.validate+0x348>
    63b4:      	add	x16, sp, #0x10
    63b8:      	ldr	w1, [x16, #0x4]
    63bc:      	sxtw	x1, w1
    63c0:      	add	x16, sp, #0x20
    63c4:      	orr	x22, x16, xzr
    63c8:      	lsr	w2, w2, #0
    63cc:      	lsr	w1, w1, #0
    63d0:      	mov	x23, x8
    63d4:      	add	x8, sp, #0x20
    63d8:      	mov	x24, x0
    63dc:      	mov	w25, w2
    63e0:      	bl	0x63e0 <_stogir.locals.validate+0x368>
		00000000000063e0:  ARM64_RELOC_BRANCH26	_stogir.locals.shape
    63e4:      	add	x16, sp, #0x20
    63e8:      	ldr	w0, [x16]
    63ec:      	lsr	x16, x0, #0
    63f0:      	cmp	x16, #0x1
    63f4:      	b.eq	0x6410 <_stogir.locals.validate+0x398>
    63f8:      	b.lo	0x6400 <_stogir.locals.validate+0x388>
    63fc:      	b	0x6414 <_stogir.locals.validate+0x39c>
    6400:      	cmp	x16, #0x0
    6404:      	b.eq	0x640c <_stogir.locals.validate+0x394>
    6408:      	b	0x6414 <_stogir.locals.validate+0x39c>
    640c:      	b	0x6434 <_stogir.locals.validate+0x3bc>
    6410:      	b	0x6418 <_stogir.locals.validate+0x3a0>
    6414:      	b	0x6694 <_stogir.locals.validate+0x61c>
    6418:      	add	x0, x22, #0x8
    641c:      	add	x16, sp, #0x20
    6420:      	ldr	x1, [x16, #0x8]
    6424:      	ldr	x0, [x0, #0x8]
    6428:      	mov	x2, x0
    642c:      	mov	x0, #0x1                ; =1
    6430:      	b	0x61a4 <_stogir.locals.validate+0x12c>
    6434:      	add	x16, sp, #0x20
    6438:      	ldr	x22, [x16, #0x8]
    643c:      	uxtb	w16, w21
    6440:      	cmp	w16, wzr
    6444:      	b.eq	0x6464 <_stogir.locals.validate+0x3ec>
    6448:      	lsr	w22, w22, #0
    644c:      	sxtw	x22, w22
    6450:      	and	x0, x22, #0xffffffff
    6454:      	mov	x1, x0
    6458:      	movz	x0, #0x0, lsl #48
    645c:      	movz	x2, #0x0, lsl #48
    6460:      	b	0x6430 <_stogir.locals.validate+0x3b8>
    6464:      	uxtb	w16, w20
    6468:      	cmp	w16, wzr
    646c:      	b.eq	0x64c0 <_stogir.locals.validate+0x448>
    6470:      	add	x16, sp, #0x10
    6474:      	ldr	w0, [x16]
    6478:      	ubfx	x0, x0, #8, #8
    647c:      	cmp	x0, #0x6
    6480:      	b.ne	0x64a4 <_stogir.locals.validate+0x42c>
    6484:      	sxtw	x25, w25
    6488:      	and	x0, x25, #0xffffffff
    648c:      	mov	x1, x0
    6490:      	movz	x0, #0x0, lsl #48
    6494:      	movz	x2, #0x0, lsl #48
    6498:      	b	0x64bc <_stogir.locals.validate+0x444>
    649c:      	brk	#0
    64a0:      	b	0x649c <_stogir.locals.validate+0x424>
    64a4:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x5fc>
		00000000000064a4:  ARM64_RELOC_PAGE21	l_stogir.397
    64a8:      	ldr	x16, [x16]
		00000000000064a8:  ARM64_RELOC_PAGEOFF12	l_stogir.397
    64ac:      	orr	x0, x16, xzr
    64b0:      	mov	x1, x0
    64b4:      	mov	x0, #0x1                ; =1
    64b8:      	mov	x2, #0x21               ; =33
    64bc:      	b	0x6460 <_stogir.locals.validate+0x3e8>
    64c0:      	add	x16, sp, #0x10
    64c4:      	ldr	w0, [x16, #0x4]
    64c8:      	sxtw	x0, w0
    64cc:      	cmp	x0, #0x0
    64d0:      	cset	w1, gt
    64d4:      	movz	x16, #0x0, lsl #48
    64d8:      	sub	x2, x16, x0
    64dc:      	sub	x3, x2, #0x1
    64e0:      	uxtb	w16, w1
    64e4:      	cmp	w16, wzr
    64e8:      	b.eq	0x65d0 <_stogir.locals.validate+0x558>
    64ec:      	ldr	x2, [x24, #0x8]
    64f0:      	cmp	x0, x2
    64f4:      	b.ge	0x65c8 <_stogir.locals.validate+0x550>
    64f8:      	add	x2, x24, #0x78
    64fc:      	ldr	x2, [x2, #0x8]
    6500:      	cmp	x0, x2
    6504:      	b.ge	0x6684 <_stogir.locals.validate+0x60c>
    6508:      	lsl	x2, x0, #2
    650c:      	ldr	x2, [x24, #0x78]
    6510:      	add	x2, x2, x0, lsl #2
    6514:      	ldr	w2, [x2]
    6518:      	sxtw	x2, w2
    651c:      	cmp	x2, #0x0
    6520:      	cset	w2, ge
    6524:      	ubfx	x2, x2, #0, #8
    6528:      	b	0x6688 <_stogir.locals.validate+0x610>
    652c:      	movz	x0, #0x0, lsl #48
    6530:      	movz	x1, #0x0, lsl #48
    6534:      	lsr	w0, w0, #0
    6538:      	lsr	x16, x0, #0
    653c:      	cmp	x16, #0x1
    6540:      	b.eq	0x655c <_stogir.locals.validate+0x4e4>
    6544:      	b.lo	0x654c <_stogir.locals.validate+0x4d4>
    6548:      	b	0x6560 <_stogir.locals.validate+0x4e8>
    654c:      	cmp	x16, #0x0
    6550:      	b.eq	0x6558 <_stogir.locals.validate+0x4e0>
    6554:      	b	0x6560 <_stogir.locals.validate+0x4e8>
    6558:      	b	0x6564 <_stogir.locals.validate+0x4ec>
    655c:      	b	0x661c <_stogir.locals.validate+0x5a4>
    6560:      	b	0x6804 <_stogir.locals.validate+0x78c>
    6564:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x5fc>
		0000000000006564:  ARM64_RELOC_PAGE21	l_stogir.398
    6568:      	ldr	x16, [x16]
		0000000000006568:  ARM64_RELOC_PAGEOFF12	l_stogir.398
    656c:      	orr	x0, x16, xzr
    6570:      	mov	x1, x0
    6574:      	mov	x0, #0x1                ; =1
    6578:      	mov	x2, #0x1c               ; =28
    657c:      	b	0x64bc <_stogir.locals.validate+0x444>
    6580:      	lsl	x0, x3, #4
    6584:      	ldr	x0, [x24, #0x28]
    6588:      	add	x0, x0, x3, lsl #4
    658c:      	ldr	x0, [x0]
    6590:      	mov	x1, x0
    6594:      	mov	x0, #0x1                ; =1
    6598:      	b	0x6534 <_stogir.locals.validate+0x4bc>
    659c:      	movz	x2, #0x0, lsl #48
    65a0:      	cmp	x2, #0x0
    65a4:      	b.eq	0x652c <_stogir.locals.validate+0x4b4>
    65a8:      	uxtb	w16, w1
    65ac:      	cmp	w16, wzr
    65b0:      	b.eq	0x6580 <_stogir.locals.validate+0x508>
    65b4:      	lsl	x1, x0, #4
    65b8:      	ldr	x1, [x24]
    65bc:      	add	x0, x1, x0, lsl #4
    65c0:      	ldr	x0, [x0]
    65c4:      	b	0x6590 <_stogir.locals.validate+0x518>
    65c8:      	movz	x2, #0x0, lsl #48
    65cc:      	b	0x65a0 <_stogir.locals.validate+0x528>
    65d0:      	cmp	x0, #0x0
    65d4:      	b.ge	0x659c <_stogir.locals.validate+0x524>
    65d8:      	add	x4, x24, #0x28
    65dc:      	add	x5, x24, #0x50
    65e0:      	ldr	x4, [x4, #0x8]
    65e4:      	ldr	x5, [x5, #0x8]
    65e8:      	cmp	x4, x5
    65ec:      	b.ne	0x667c <_stogir.locals.validate+0x604>
    65f0:      	cmp	x2, x4
    65f4:      	b.gt	0x668c <_stogir.locals.validate+0x614>
    65f8:      	lsl	x2, x3, #2
    65fc:      	ldr	x2, [x24, #0x50]
    6600:      	add	x2, x2, x3, lsl #2
    6604:      	ldr	w2, [x2]
    6608:      	sxtw	x2, w2
    660c:      	cmp	x2, #0x0
    6610:      	cset	w2, gt
    6614:      	ubfx	x2, x2, #0, #8
    6618:      	b	0x6690 <_stogir.locals.validate+0x618>
    661c:      	add	x16, sp, #0x10
    6620:      	ldr	w0, [x16, #0x4]
    6624:      	sxtw	x0, w0
    6628:      	cmp	x0, #0x0
    662c:      	b.le	0x6660 <_stogir.locals.validate+0x5e8>
    6630:      	uxtb	w1, w1
    6634:      	cmp	x1, #0x83
    6638:      	cset	w0, lt
    663c:      	uxtb	w16, w0
    6640:      	cmp	w16, wzr
    6644:      	b.eq	0x669c <_stogir.locals.validate+0x624>
    6648:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x5fc>
		0000000000006648:  ARM64_RELOC_PAGE21	l_stogir.399
    664c:      	ldr	x16, [x16]
		000000000000664c:  ARM64_RELOC_PAGEOFF12	l_stogir.399
    6650:      	orr	x2, x16, xzr
    6654:      	add	x2, x1, x2
    6658:      	ldrb	w2, [x2]
    665c:      	b	0x66a0 <_stogir.locals.validate+0x628>
    6660:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x5fc>
		0000000000006660:  ARM64_RELOC_PAGE21	l_stogir.400
    6664:      	ldr	x16, [x16]
		0000000000006664:  ARM64_RELOC_PAGEOFF12	l_stogir.400
    6668:      	orr	x0, x16, xzr
    666c:      	mov	x1, x0
    6670:      	mov	x0, #0x1                ; =1
    6674:      	mov	x2, #0x1c               ; =28
    6678:      	b	0x657c <_stogir.locals.validate+0x504>
    667c:      	movz	x2, #0x0, lsl #48
    6680:      	b	0x65a0 <_stogir.locals.validate+0x528>
    6684:      	movz	x2, #0x0, lsl #48
    6688:      	b	0x65cc <_stogir.locals.validate+0x554>
    668c:      	movz	x2, #0x0, lsl #48
    6690:      	b	0x6680 <_stogir.locals.validate+0x608>
    6694:      	brk	#0
    6698:      	b	0x6694 <_stogir.locals.validate+0x61c>
    669c:      	movz	x2, #0x0, lsl #48
    66a0:      	uxtb	w2, w2
    66a4:      	and	x2, x2, #0x1
    66a8:      	uxtb	w2, w2
    66ac:      	cmp	x2, #0x0
    66b0:      	b.eq	0x6660 <_stogir.locals.validate+0x5e8>
    66b4:      	uxtb	w16, w0
    66b8:      	cmp	w16, wzr
    66bc:      	b.eq	0x66d8 <_stogir.locals.validate+0x660>
    66c0:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x5fc>
		00000000000066c0:  ARM64_RELOC_PAGE21	l_stogir.399
    66c4:      	ldr	x16, [x16]
		00000000000066c4:  ARM64_RELOC_PAGEOFF12	l_stogir.399
    66c8:      	orr	x0, x16, xzr
    66cc:      	add	x0, x1, x0
    66d0:      	ldrb	w0, [x0]
    66d4:      	b	0x66dc <_stogir.locals.validate+0x664>
    66d8:      	movz	x0, #0x0, lsl #48
    66dc:      	uxtb	w0, w0
    66e0:      	and	x0, x0, #0x4
    66e4:      	uxtb	w0, w0
    66e8:      	cmp	x0, #0x0
    66ec:      	cset	w0, eq
    66f0:      	uxtb	w16, w0
    66f4:      	cmp	w16, wzr
    66f8:      	cset	x0, eq
    66fc:      	cmp	x0, #0x0
    6700:      	b.ne	0x6660 <_stogir.locals.validate+0x5e8>
    6704:      	cmp	x19, #0x0
    6708:      	b.eq	0x67a8 <_stogir.locals.validate+0x730>
    670c:      	add	x16, sp, #0x10
    6710:      	ldr	w0, [x16, #0xc]
    6714:      	lsr	w0, w0, #0
    6718:      	add	x8, sp, #0x40
    671c:      	mov	w1, w0
    6720:      	mov	x0, x24
    6724:      	bl	0x6724 <_stogir.locals.validate+0x6ac>
		0000000000006724:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    6728:      	add	x16, sp, #0x40
    672c:      	ldr	x0, [x16]
    6730:      	add	x16, sp, #0x40
    6734:      	ldr	x1, [x16, #0x8]
    6738:      	mov	x20, x1
    673c:      	b	0x67b8 <_stogir.locals.validate+0x740>
    6740:      	lsr	w25, w25, #0
    6744:      	lsr	w0, w20, #0
    6748:      	ubfx	x0, x0, #8, #8
    674c:      	lsr	w0, w0, #0
    6750:      	mov	w1, w25
    6754:      	bl	0x6754 <_stogir.locals.validate+0x6dc>
		0000000000006754:  ARM64_RELOC_BRANCH26	_stogir.types.size
    6758:      	lsr	w0, w0, #0
    675c:      	sxtw	x0, w0
    6760:      	cmp	x0, #0x0
    6764:      	b.le	0x678c <_stogir.locals.validate+0x714>
    6768:      	cmp	x0, x22
    676c:      	b.gt	0x678c <_stogir.locals.validate+0x714>
    6770:      	cmp	x19, #0x0
    6774:      	b.eq	0x680c <_stogir.locals.validate+0x794>
    6778:      	add	x16, sp, #0x10
    677c:      	ldr	w1, [x16]
    6780:      	ubfx	x1, x1, #8, #8
    6784:      	cmp	x1, #0x0
    6788:      	b.eq	0x680c <_stogir.locals.validate+0x794>
    678c:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x5fc>
		000000000000678c:  ARM64_RELOC_PAGE21	l_stogir.401
    6790:      	ldr	x16, [x16]
		0000000000006790:  ARM64_RELOC_PAGEOFF12	l_stogir.401
    6794:      	orr	x0, x16, xzr
    6798:      	mov	x1, x0
    679c:      	mov	x0, #0x1                ; =1
    67a0:      	mov	x2, #0x23               ; =35
    67a4:      	b	0x6678 <_stogir.locals.validate+0x600>
    67a8:      	add	x16, sp, #0x10
    67ac:      	ldr	x0, [x16]
    67b0:      	mov	x20, x0
    67b4:      	mov	x0, #0x1                ; =1
    67b8:      	lsr	w0, w0, #0
    67bc:      	lsr	x16, x0, #0
    67c0:      	cmp	x16, #0x1
    67c4:      	b.eq	0x67e0 <_stogir.locals.validate+0x768>
    67c8:      	b.lo	0x67d0 <_stogir.locals.validate+0x758>
    67cc:      	b	0x67e4 <_stogir.locals.validate+0x76c>
    67d0:      	cmp	x16, #0x0
    67d4:      	b.eq	0x67dc <_stogir.locals.validate+0x764>
    67d8:      	b	0x67e4 <_stogir.locals.validate+0x76c>
    67dc:      	b	0x67e8 <_stogir.locals.validate+0x770>
    67e0:      	b	0x6740 <_stogir.locals.validate+0x6c8>
    67e4:      	b	0x682c <_stogir.locals.validate+0x7b4>
    67e8:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x5fc>
		00000000000067e8:  ARM64_RELOC_PAGE21	l_stogir.402
    67ec:      	ldr	x16, [x16]
		00000000000067ec:  ARM64_RELOC_PAGEOFF12	l_stogir.402
    67f0:      	orr	x0, x16, xzr
    67f4:      	mov	x1, x0
    67f8:      	mov	x0, #0x1                ; =1
    67fc:      	mov	x2, #0x19               ; =25
    6800:      	b	0x67a4 <_stogir.locals.validate+0x72c>
    6804:      	brk	#0
    6808:      	b	0x6804 <_stogir.locals.validate+0x78c>
    680c:      	uxtb	w20, w20
    6810:      	cmp	x20, #0x48
    6814:      	b.eq	0x678c <_stogir.locals.validate+0x714>
    6818:      	and	x0, x0, #0xffffffff
    681c:      	mov	x1, x0
    6820:      	movz	x0, #0x0, lsl #48
    6824:      	movz	x2, #0x0, lsl #48
    6828:      	b	0x67a4 <_stogir.locals.validate+0x72c>
    682c:      	brk	#0
    6830:      	b	0x682c <_stogir.locals.validate+0x7b4>
    6834:      	mov	x23, x8
    6838:      	b	0x618c <_stogir.locals.validate+0x114>
    683c:      	mov	x23, x8
    6840:      	b	0x618c <_stogir.locals.validate+0x114>

0000000000006844 <_stogir.conversion.operation?>:
    6844:      	sxtw	x0, w0
    6848:      	cmp	x0, #0x21
    684c:      	b.lt	0x6860 <_stogir.conversion.operation?+0x1c>
    6850:      	cmp	x0, #0x27
    6854:      	cset	w0, le
    6858:      	ubfx	x0, x0, #0, #8
    685c:      	b	0x6864 <_stogir.conversion.operation?+0x20>
    6860:      	movz	x0, #0x0, lsl #48
    6864:      	ret

0000000000006868 <_stogir.conversion.validate>:
    6868:      	sub	sp, sp, #0x40
    686c:      	str	x29, [sp]
    6870:      	str	x30, [sp, #0x8]
    6874:      	mov	x29, sp
    6878:      	str	x19, [sp, #0x30]
    687c:      	sxtw	x1, w1
    6880:      	lsl	x3, x1, #2
    6884:      	cmp	x1, #0x0
    6888:      	cset	w4, gt
    688c:      	movz	x16, #0x0, lsl #48
    6890:      	sub	x5, x16, x1
    6894:      	sub	x6, x5, #0x1
    6898:      	uxtb	w16, w4
    689c:      	cmp	w16, wzr
    68a0:      	b.eq	0x68e0 <_stogir.conversion.validate+0x78>
    68a4:      	ldr	x5, [x0, #0x8]
    68a8:      	cmp	x1, x5
    68ac:      	b.ge	0x6934 <_stogir.conversion.validate+0xcc>
    68b0:      	add	x5, x0, #0x78
    68b4:      	ldr	x5, [x5, #0x8]
    68b8:      	cmp	x1, x5
    68bc:      	b.ge	0x6a20 <_stogir.conversion.validate+0x1b8>
    68c0:      	ldr	x5, [x0, #0x78]
    68c4:      	add	x5, x3, x5
    68c8:      	ldr	w5, [x5]
    68cc:      	sxtw	x5, w5
    68d0:      	cmp	x5, #0x0
    68d4:      	cset	w5, ge
    68d8:      	ubfx	x5, x5, #0, #8
    68dc:      	b	0x6a24 <_stogir.conversion.validate+0x1bc>
    68e0:      	cmp	x1, #0x0
    68e4:      	b.ge	0x693c <_stogir.conversion.validate+0xd4>
    68e8:      	add	x7, x0, #0x28
    68ec:      	add	x9, x0, #0x50
    68f0:      	ldr	x7, [x7, #0x8]
    68f4:      	ldr	x9, [x9, #0x8]
    68f8:      	cmp	x7, x9
    68fc:      	b.ne	0x692c <_stogir.conversion.validate+0xc4>
    6900:      	cmp	x5, x7
    6904:      	b.gt	0x6ab8 <_stogir.conversion.validate+0x250>
    6908:      	lsl	x5, x6, #2
    690c:      	ldr	x5, [x0, #0x50]
    6910:      	add	x5, x5, x6, lsl #2
    6914:      	ldr	w5, [x5]
    6918:      	sxtw	x5, w5
    691c:      	cmp	x5, #0x0
    6920:      	cset	w5, gt
    6924:      	ubfx	x5, x5, #0, #8
    6928:      	b	0x6abc <_stogir.conversion.validate+0x254>
    692c:      	movz	x5, #0x0, lsl #48
    6930:      	b	0x6940 <_stogir.conversion.validate+0xd8>
    6934:      	movz	x5, #0x0, lsl #48
    6938:      	b	0x6940 <_stogir.conversion.validate+0xd8>
    693c:      	movz	x5, #0x0, lsl #48
    6940:      	cmp	x5, #0x0
    6944:      	b.eq	0x6984 <_stogir.conversion.validate+0x11c>
    6948:      	uxtb	w16, w4
    694c:      	cmp	w16, wzr
    6950:      	b.eq	0x6968 <_stogir.conversion.validate+0x100>
    6954:      	lsl	x4, x1, #4
    6958:      	ldr	x4, [x0]
    695c:      	add	x4, x4, x1, lsl #4
    6960:      	ldr	x4, [x4]
    6964:      	b	0x6978 <_stogir.conversion.validate+0x110>
    6968:      	lsl	x4, x6, #4
    696c:      	ldr	x4, [x0, #0x28]
    6970:      	add	x4, x4, x6, lsl #4
    6974:      	ldr	x4, [x4]
    6978:      	mov	x5, x4
    697c:      	mov	x4, #0x1                ; =1
    6980:      	b	0x698c <_stogir.conversion.validate+0x124>
    6984:      	movz	x4, #0x0, lsl #48
    6988:      	movz	x5, #0x0, lsl #48
    698c:      	lsr	w4, w4, #0
    6990:      	lsr	x16, x4, #0
    6994:      	cmp	x16, #0x1
    6998:      	b.eq	0x69b4 <_stogir.conversion.validate+0x14c>
    699c:      	b.lo	0x69a4 <_stogir.conversion.validate+0x13c>
    69a0:      	b	0x69b8 <_stogir.conversion.validate+0x150>
    69a4:      	cmp	x16, #0x0
    69a8:      	b.eq	0x69b0 <_stogir.conversion.validate+0x148>
    69ac:      	b	0x69b8 <_stogir.conversion.validate+0x150>
    69b0:      	b	0x69bc <_stogir.conversion.validate+0x154>
    69b4:      	b	0x69f8 <_stogir.conversion.validate+0x190>
    69b8:      	b	0x6b38 <_stogir.conversion.validate+0x2d0>
    69bc:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x5fc>
		00000000000069bc:  ARM64_RELOC_PAGE21	l_stogir.403
    69c0:      	ldr	x16, [x16]
		00000000000069c0:  ARM64_RELOC_PAGEOFF12	l_stogir.403
    69c4:      	orr	x0, x16, xzr
    69c8:      	mov	x19, x8
    69cc:      	mov	x1, x0
    69d0:      	mov	x0, #0x1                ; =1
    69d4:      	mov	x2, #0x12               ; =18
    69d8:      	str	x0, [x19]
    69dc:      	str	x1, [x19, #0x8]
    69e0:      	str	x2, [x19, #0x10]
    69e4:      	ldr	x19, [sp, #0x30]
    69e8:      	ldr	x29, [sp]
    69ec:      	ldr	x30, [sp, #0x8]
    69f0:      	add	sp, sp, #0x40
    69f4:      	ret
    69f8:      	cmp	x1, #0x0
    69fc:      	b.gt	0x6a28 <_stogir.conversion.validate+0x1c0>
    6a00:      	mov	x19, x8
    6a04:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x5fc>
		0000000000006a04:  ARM64_RELOC_PAGE21	l_stogir.404
    6a08:      	ldr	x16, [x16]
		0000000000006a08:  ARM64_RELOC_PAGEOFF12	l_stogir.404
    6a0c:      	orr	x0, x16, xzr
    6a10:      	mov	x1, x0
    6a14:      	mov	x0, #0x1                ; =1
    6a18:      	mov	x2, #0x1e               ; =30
    6a1c:      	b	0x69d8 <_stogir.conversion.validate+0x170>
    6a20:      	movz	x5, #0x0, lsl #48
    6a24:      	b	0x6938 <_stogir.conversion.validate+0xd0>
    6a28:      	uxtb	w1, w5
    6a2c:      	orr	x4, x1, xzr
    6a30:      	cmp	x4, #0x21
    6a34:      	b.lt	0x6c6c <_stogir.conversion.validate+0x404>
    6a38:      	cmp	x4, #0x27
    6a3c:      	b.gt	0x6c74 <_stogir.conversion.validate+0x40c>
    6a40:      	ldr	x4, [x0, #0x78]
    6a44:      	add	x3, x3, x4
    6a48:      	ldr	w3, [x3]
    6a4c:      	sxtw	x3, w3
    6a50:      	cmp	x3, #0x1
    6a54:      	b.ne	0x6c7c <_stogir.conversion.validate+0x414>
    6a58:      	asr	x3, x5, #32
    6a5c:      	cmp	x3, #0x0
    6a60:      	cset	w6, gt
    6a64:      	movz	x16, #0x0, lsl #48
    6a68:      	sub	x7, x16, x3
    6a6c:      	sub	x9, x7, #0x1
    6a70:      	uxtb	w16, w6
    6a74:      	cmp	w16, wzr
    6a78:      	b.eq	0x6aec <_stogir.conversion.validate+0x284>
    6a7c:      	ldr	x7, [x0, #0x8]
    6a80:      	cmp	x3, x7
    6a84:      	b.ge	0x6b40 <_stogir.conversion.validate+0x2d8>
    6a88:      	add	x7, x0, #0x78
    6a8c:      	ldr	x7, [x7, #0x8]
    6a90:      	cmp	x3, x7
    6a94:      	b.ge	0x6bf0 <_stogir.conversion.validate+0x388>
    6a98:      	lsl	x7, x3, #2
    6a9c:      	add	x4, x4, x3, lsl #2
    6aa0:      	ldr	w4, [x4]
    6aa4:      	sxtw	x4, w4
    6aa8:      	cmp	x4, #0x0
    6aac:      	cset	w4, ge
    6ab0:      	ubfx	x4, x4, #0, #8
    6ab4:      	b	0x6bf4 <_stogir.conversion.validate+0x38c>
    6ab8:      	movz	x5, #0x0, lsl #48
    6abc:      	b	0x6930 <_stogir.conversion.validate+0xc8>
    6ac0:      	uxtb	w0, w3
    6ac4:      	cmp	x0, #0x48
    6ac8:      	b.ne	0x6bf8 <_stogir.conversion.validate+0x390>
    6acc:      	mov	x19, x8
    6ad0:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x5fc>
		0000000000006ad0:  ARM64_RELOC_PAGE21	l_stogir.405
    6ad4:      	ldr	x16, [x16]
		0000000000006ad4:  ARM64_RELOC_PAGEOFF12	l_stogir.405
    6ad8:      	orr	x0, x16, xzr
    6adc:      	mov	x1, x0
    6ae0:      	mov	x0, #0x1                ; =1
    6ae4:      	mov	x2, #0x25               ; =37
    6ae8:      	b	0x6a1c <_stogir.conversion.validate+0x1b4>
    6aec:      	cmp	x3, #0x0
    6af0:      	b.ge	0x6b48 <_stogir.conversion.validate+0x2e0>
    6af4:      	add	x4, x0, #0x28
    6af8:      	add	x10, x0, #0x50
    6afc:      	ldr	x4, [x4, #0x8]
    6b00:      	ldr	x10, [x10, #0x8]
    6b04:      	cmp	x4, x10
    6b08:      	b.ne	0x6be8 <_stogir.conversion.validate+0x380>
    6b0c:      	cmp	x7, x4
    6b10:      	b.gt	0x6c5c <_stogir.conversion.validate+0x3f4>
    6b14:      	lsl	x4, x9, #2
    6b18:      	ldr	x4, [x0, #0x50]
    6b1c:      	add	x4, x4, x9, lsl #2
    6b20:      	ldr	w4, [x4]
    6b24:      	sxtw	x4, w4
    6b28:      	cmp	x4, #0x0
    6b2c:      	cset	w4, gt
    6b30:      	ubfx	x4, x4, #0, #8
    6b34:      	b	0x6c60 <_stogir.conversion.validate+0x3f8>
    6b38:      	brk	#0
    6b3c:      	b	0x6b38 <_stogir.conversion.validate+0x2d0>
    6b40:      	movz	x4, #0x0, lsl #48
    6b44:      	b	0x6b4c <_stogir.conversion.validate+0x2e4>
    6b48:      	movz	x4, #0x0, lsl #48
    6b4c:      	cmp	x4, #0x0
    6b50:      	b.eq	0x6b90 <_stogir.conversion.validate+0x328>
    6b54:      	uxtb	w16, w6
    6b58:      	cmp	w16, wzr
    6b5c:      	b.eq	0x6b74 <_stogir.conversion.validate+0x30c>
    6b60:      	lsl	x4, x3, #4
    6b64:      	ldr	x0, [x0]
    6b68:      	add	x0, x0, x3, lsl #4
    6b6c:      	ldr	x0, [x0]
    6b70:      	b	0x6b84 <_stogir.conversion.validate+0x31c>
    6b74:      	lsl	x3, x9, #4
    6b78:      	ldr	x0, [x0, #0x28]
    6b7c:      	add	x0, x0, x9, lsl #4
    6b80:      	ldr	x0, [x0]
    6b84:      	mov	x3, x0
    6b88:      	mov	x0, #0x1                ; =1
    6b8c:      	b	0x6b98 <_stogir.conversion.validate+0x330>
    6b90:      	movz	x0, #0x0, lsl #48
    6b94:      	movz	x3, #0x0, lsl #48
    6b98:      	lsr	w0, w0, #0
    6b9c:      	lsr	x16, x0, #0
    6ba0:      	cmp	x16, #0x1
    6ba4:      	b.eq	0x6bc0 <_stogir.conversion.validate+0x358>
    6ba8:      	b.lo	0x6bb0 <_stogir.conversion.validate+0x348>
    6bac:      	b	0x6bc4 <_stogir.conversion.validate+0x35c>
    6bb0:      	cmp	x16, #0x0
    6bb4:      	b.eq	0x6bbc <_stogir.conversion.validate+0x354>
    6bb8:      	b	0x6bc4 <_stogir.conversion.validate+0x35c>
    6bbc:      	b	0x6bc8 <_stogir.conversion.validate+0x360>
    6bc0:      	b	0x6ac0 <_stogir.conversion.validate+0x258>
    6bc4:      	b	0x6c64 <_stogir.conversion.validate+0x3fc>
    6bc8:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x5fc>
		0000000000006bc8:  ARM64_RELOC_PAGE21	l_stogir.406
    6bcc:      	ldr	x16, [x16]
		0000000000006bcc:  ARM64_RELOC_PAGEOFF12	l_stogir.406
    6bd0:      	orr	x0, x16, xzr
    6bd4:      	mov	x19, x8
    6bd8:      	mov	x1, x0
    6bdc:      	mov	x0, #0x1                ; =1
    6be0:      	mov	x2, #0x19               ; =25
    6be4:      	b	0x6ae8 <_stogir.conversion.validate+0x280>
    6be8:      	movz	x4, #0x0, lsl #48
    6bec:      	b	0x6b4c <_stogir.conversion.validate+0x2e4>
    6bf0:      	movz	x4, #0x0, lsl #48
    6bf4:      	b	0x6b44 <_stogir.conversion.validate+0x2dc>
    6bf8:      	cmp	x0, #0x46
    6bfc:      	b.eq	0x6c84 <_stogir.conversion.validate+0x41c>
    6c00:      	lsr	w2, w2, #0
    6c04:      	lsr	w5, w5, #0
    6c08:      	lsr	w3, w3, #0
    6c0c:      	lsr	w1, w1, #0
    6c10:      	ubfx	x0, x5, #8, #8
    6c14:      	ubfx	x3, x3, #8, #8
    6c18:      	lsr	w0, w0, #0
    6c1c:      	lsr	w3, w3, #0
    6c20:      	mov	x19, x8
    6c24:      	add	x8, sp, #0x10
    6c28:      	fmov	s31, w0
    6c2c:      	mov	w0, w1
    6c30:      	mov	w1, w3
    6c34:      	mov	w3, w2
    6c38:      	fmov	w2, s31
    6c3c:      	bl	0x6c3c <_stogir.conversion.validate+0x3d4>
		0000000000006c3c:  ARM64_RELOC_BRANCH26	_stogir.conversion.policy
    6c40:      	add	x16, sp, #0x10
    6c44:      	ldr	x0, [x16]
    6c48:      	add	x16, sp, #0x10
    6c4c:      	ldr	x1, [x16, #0x8]
    6c50:      	add	x16, sp, #0x10
    6c54:      	ldr	x2, [x16, #0x10]
    6c58:      	b	0x6ae8 <_stogir.conversion.validate+0x280>
    6c5c:      	movz	x4, #0x0, lsl #48
    6c60:      	b	0x6bec <_stogir.conversion.validate+0x384>
    6c64:      	brk	#0
    6c68:      	b	0x6c64 <_stogir.conversion.validate+0x3fc>
    6c6c:      	mov	x19, x8
    6c70:      	b	0x6a04 <_stogir.conversion.validate+0x19c>
    6c74:      	mov	x19, x8
    6c78:      	b	0x6a04 <_stogir.conversion.validate+0x19c>
    6c7c:      	mov	x19, x8
    6c80:      	b	0x6a04 <_stogir.conversion.validate+0x19c>
    6c84:      	mov	x19, x8
    6c88:      	b	0x6ad0 <_stogir.conversion.validate+0x268>

0000000000006c8c <_stogir.conditional.validate>:
    6c8c:      	sub	sp, sp, #0x40
    6c90:      	str	x29, [sp]
    6c94:      	str	x30, [sp, #0x8]
    6c98:      	mov	x29, sp
    6c9c:      	str	x19, [sp, #0x30]
    6ca0:      	sxtw	x1, w1
    6ca4:      	lsl	x2, x1, #2
    6ca8:      	cmp	x1, #0x0
    6cac:      	cset	w3, gt
    6cb0:      	movz	x16, #0x0, lsl #48
    6cb4:      	sub	x4, x16, x1
    6cb8:      	sub	x5, x4, #0x1
    6cbc:      	uxtb	w16, w3
    6cc0:      	cmp	w16, wzr
    6cc4:      	b.eq	0x6d04 <_stogir.conditional.validate+0x78>
    6cc8:      	ldr	x4, [x0, #0x8]
    6ccc:      	cmp	x1, x4
    6cd0:      	b.ge	0x6d58 <_stogir.conditional.validate+0xcc>
    6cd4:      	add	x4, x0, #0x78
    6cd8:      	ldr	x4, [x4, #0x8]
    6cdc:      	cmp	x1, x4
    6ce0:      	b.ge	0x6e6c <_stogir.conditional.validate+0x1e0>
    6ce4:      	ldr	x4, [x0, #0x78]
    6ce8:      	add	x4, x2, x4
    6cec:      	ldr	w4, [x4]
    6cf0:      	sxtw	x4, w4
    6cf4:      	cmp	x4, #0x0
    6cf8:      	cset	w4, ge
    6cfc:      	ubfx	x4, x4, #0, #8
    6d00:      	b	0x6e70 <_stogir.conditional.validate+0x1e4>
    6d04:      	cmp	x1, #0x0
    6d08:      	b.ge	0x6d60 <_stogir.conditional.validate+0xd4>
    6d0c:      	add	x6, x0, #0x28
    6d10:      	add	x7, x0, #0x50
    6d14:      	ldr	x6, [x6, #0x8]
    6d18:      	ldr	x7, [x7, #0x8]
    6d1c:      	cmp	x6, x7
    6d20:      	b.ne	0x6d50 <_stogir.conditional.validate+0xc4>
    6d24:      	cmp	x4, x6
    6d28:      	b.gt	0x6ef4 <_stogir.conditional.validate+0x268>
    6d2c:      	lsl	x4, x5, #2
    6d30:      	ldr	x4, [x0, #0x50]
    6d34:      	add	x4, x4, x5, lsl #2
    6d38:      	ldr	w4, [x4]
    6d3c:      	sxtw	x4, w4
    6d40:      	cmp	x4, #0x0
    6d44:      	cset	w4, gt
    6d48:      	ubfx	x4, x4, #0, #8
    6d4c:      	b	0x6ef8 <_stogir.conditional.validate+0x26c>
    6d50:      	movz	x4, #0x0, lsl #48
    6d54:      	b	0x6d64 <_stogir.conditional.validate+0xd8>
    6d58:      	movz	x4, #0x0, lsl #48
    6d5c:      	b	0x6d64 <_stogir.conditional.validate+0xd8>
    6d60:      	movz	x4, #0x0, lsl #48
    6d64:      	cmp	x4, #0x0
    6d68:      	b.eq	0x6dcc <_stogir.conditional.validate+0x140>
    6d6c:      	uxtb	w16, w3
    6d70:      	cmp	w16, wzr
    6d74:      	b.eq	0x6d9c <_stogir.conditional.validate+0x110>
    6d78:      	lsl	x3, x1, #4
    6d7c:      	ldr	x3, [x0]
    6d80:      	add	x3, x3, x1, lsl #4
    6d84:      	ldr	x4, [x3]
    6d88:      	ldr	x3, [x3, #0x8]
    6d8c:      	fmov	d31, x3
    6d90:      	mov	x3, x4
    6d94:      	fmov	x4, d31
    6d98:      	b	0x6dbc <_stogir.conditional.validate+0x130>
    6d9c:      	lsl	x3, x5, #4
    6da0:      	ldr	x3, [x0, #0x28]
    6da4:      	add	x3, x3, x5, lsl #4
    6da8:      	ldr	x4, [x3]
    6dac:      	ldr	x3, [x3, #0x8]
    6db0:      	fmov	d31, x3
    6db4:      	mov	x3, x4
    6db8:      	fmov	x4, d31
    6dbc:      	mov	x5, x4
    6dc0:      	mov	x4, x3
    6dc4:      	mov	x3, #0x1                ; =1
    6dc8:      	b	0x6dd8 <_stogir.conditional.validate+0x14c>
    6dcc:      	movz	x3, #0x0, lsl #48
    6dd0:      	movz	x4, #0x0, lsl #48
    6dd4:      	movz	x5, #0x0, lsl #48
    6dd8:      	lsr	w3, w3, #0
    6ddc:      	lsr	x16, x3, #0
    6de0:      	cmp	x16, #0x1
    6de4:      	b.eq	0x6e00 <_stogir.conditional.validate+0x174>
    6de8:      	b.lo	0x6df0 <_stogir.conditional.validate+0x164>
    6dec:      	b	0x6e04 <_stogir.conditional.validate+0x178>
    6df0:      	cmp	x16, #0x0
    6df4:      	b.eq	0x6dfc <_stogir.conditional.validate+0x170>
    6df8:      	b	0x6e04 <_stogir.conditional.validate+0x178>
    6dfc:      	b	0x6e08 <_stogir.conditional.validate+0x17c>
    6e00:      	b	0x6e28 <_stogir.conditional.validate+0x19c>
    6e04:      	b	0x6efc <_stogir.conditional.validate+0x270>
    6e08:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x5fc>
		0000000000006e08:  ARM64_RELOC_PAGE21	l_stogir.407
    6e0c:      	ldr	x16, [x16]
		0000000000006e0c:  ARM64_RELOC_PAGEOFF12	l_stogir.407
    6e10:      	orr	x0, x16, xzr
    6e14:      	mov	x19, x8
    6e18:      	mov	x1, x0
    6e1c:      	mov	x0, #0x1                ; =1
    6e20:      	mov	x2, #0x18               ; =24
    6e24:      	b	0x6e4c <_stogir.conditional.validate+0x1c0>
    6e28:      	cmp	x1, #0x0
    6e2c:      	b.gt	0x6e74 <_stogir.conditional.validate+0x1e8>
    6e30:      	mov	x19, x8
    6e34:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x5fc>
		0000000000006e34:  ARM64_RELOC_PAGE21	l_stogir.408
    6e38:      	ldr	x16, [x16]
		0000000000006e38:  ARM64_RELOC_PAGEOFF12	l_stogir.408
    6e3c:      	orr	x0, x16, xzr
    6e40:      	mov	x1, x0
    6e44:      	mov	x0, #0x1                ; =1
    6e48:      	mov	x2, #0x18               ; =24
    6e4c:      	str	x0, [x19]
    6e50:      	str	x1, [x19, #0x8]
    6e54:      	str	x2, [x19, #0x10]
    6e58:      	ldr	x19, [sp, #0x30]
    6e5c:      	ldr	x29, [sp]
    6e60:      	ldr	x30, [sp, #0x8]
    6e64:      	add	sp, sp, #0x40
    6e68:      	ret
    6e6c:      	movz	x4, #0x0, lsl #48
    6e70:      	b	0x6d5c <_stogir.conditional.validate+0xd0>
    6e74:      	uxtb	w1, w4
    6e78:      	cmp	x1, #0x3c
    6e7c:      	b.ne	0x6f04 <_stogir.conditional.validate+0x278>
    6e80:      	ldr	x1, [x0, #0x78]
    6e84:      	add	x1, x2, x1
    6e88:      	ldr	w1, [x1]
    6e8c:      	sxtw	x1, w1
    6e90:      	cmp	x1, #0x3
    6e94:      	b.ne	0x6f0c <_stogir.conditional.validate+0x280>
    6e98:      	lsr	w1, w5, #0
    6e9c:      	lsr	w2, w4, #0
    6ea0:      	lsr	x3, x4, #32
    6ea4:      	lsr	w1, w1, #0
    6ea8:      	lsr	x4, x5, #32
    6eac:      	lsr	w3, w3, #0
    6eb0:      	lsr	w4, w4, #0
    6eb4:      	ubfx	x2, x2, #8, #8
    6eb8:      	lsr	w2, w2, #0
    6ebc:      	mov	x19, x8
    6ec0:      	add	x8, sp, #0x10
    6ec4:      	fmov	s31, w1
    6ec8:      	mov	w1, w2
    6ecc:      	mov	w2, w3
    6ed0:      	fmov	w3, s31
    6ed4:      	bl	0x6ed4 <_stogir.conditional.validate+0x248>
		0000000000006ed4:  ARM64_RELOC_BRANCH26	_stogir.conditional.operands
    6ed8:      	add	x16, sp, #0x10
    6edc:      	ldr	x0, [x16]
    6ee0:      	add	x16, sp, #0x10
    6ee4:      	ldr	x1, [x16, #0x8]
    6ee8:      	add	x16, sp, #0x10
    6eec:      	ldr	x2, [x16, #0x10]
    6ef0:      	b	0x6e4c <_stogir.conditional.validate+0x1c0>
    6ef4:      	movz	x4, #0x0, lsl #48
    6ef8:      	b	0x6d54 <_stogir.conditional.validate+0xc8>
    6efc:      	brk	#0
    6f00:      	b	0x6efc <_stogir.conditional.validate+0x270>
    6f04:      	mov	x19, x8
    6f08:      	b	0x6e34 <_stogir.conditional.validate+0x1a8>
    6f0c:      	mov	x19, x8
    6f10:      	b	0x6e34 <_stogir.conditional.validate+0x1a8>

0000000000006f14 <_stogir.floating.validate>:
    6f14:      	sub	sp, sp, #0x50
    6f18:      	str	x29, [sp]
    6f1c:      	str	x30, [sp, #0x8]
    6f20:      	mov	x29, sp
    6f24:      	str	x19, [sp, #0x40]
    6f28:      	sxtw	x1, w1
    6f2c:      	lsl	x2, x1, #2
    6f30:      	cmp	x1, #0x0
    6f34:      	cset	w3, gt
    6f38:      	movz	x16, #0x0, lsl #48
    6f3c:      	sub	x4, x16, x1
    6f40:      	sub	x5, x4, #0x1
    6f44:      	uxtb	w16, w3
    6f48:      	cmp	w16, wzr
    6f4c:      	b.eq	0x6f8c <_stogir.floating.validate+0x78>
    6f50:      	ldr	x4, [x0, #0x8]
    6f54:      	cmp	x1, x4
    6f58:      	b.ge	0x6fe0 <_stogir.floating.validate+0xcc>
    6f5c:      	add	x4, x0, #0x78
    6f60:      	ldr	x4, [x4, #0x8]
    6f64:      	cmp	x1, x4
    6f68:      	b.ge	0x7104 <_stogir.floating.validate+0x1f0>
    6f6c:      	ldr	x4, [x0, #0x78]
    6f70:      	add	x4, x2, x4
    6f74:      	ldr	w4, [x4]
    6f78:      	sxtw	x4, w4
    6f7c:      	cmp	x4, #0x0
    6f80:      	cset	w4, ge
    6f84:      	ubfx	x4, x4, #0, #8
    6f88:      	b	0x7108 <_stogir.floating.validate+0x1f4>
    6f8c:      	cmp	x1, #0x0
    6f90:      	b.ge	0x6fe8 <_stogir.floating.validate+0xd4>
    6f94:      	add	x6, x0, #0x28
    6f98:      	add	x7, x0, #0x50
    6f9c:      	ldr	x6, [x6, #0x8]
    6fa0:      	ldr	x7, [x7, #0x8]
    6fa4:      	cmp	x6, x7
    6fa8:      	b.ne	0x6fd8 <_stogir.floating.validate+0xc4>
    6fac:      	cmp	x4, x6
    6fb0:      	b.gt	0x7190 <_stogir.floating.validate+0x27c>
    6fb4:      	lsl	x4, x5, #2
    6fb8:      	ldr	x4, [x0, #0x50]
    6fbc:      	add	x4, x4, x5, lsl #2
    6fc0:      	ldr	w4, [x4]
    6fc4:      	sxtw	x4, w4
    6fc8:      	cmp	x4, #0x0
    6fcc:      	cset	w4, gt
    6fd0:      	ubfx	x4, x4, #0, #8
    6fd4:      	b	0x7194 <_stogir.floating.validate+0x280>
    6fd8:      	movz	x4, #0x0, lsl #48
    6fdc:      	b	0x6fec <_stogir.floating.validate+0xd8>
    6fe0:      	movz	x4, #0x0, lsl #48
    6fe4:      	b	0x6fec <_stogir.floating.validate+0xd8>
    6fe8:      	movz	x4, #0x0, lsl #48
    6fec:      	cmp	x4, #0x0
    6ff0:      	b.eq	0x7054 <_stogir.floating.validate+0x140>
    6ff4:      	uxtb	w16, w3
    6ff8:      	cmp	w16, wzr
    6ffc:      	b.eq	0x7024 <_stogir.floating.validate+0x110>
    7000:      	lsl	x3, x1, #4
    7004:      	ldr	x3, [x0]
    7008:      	add	x3, x3, x1, lsl #4
    700c:      	ldr	x4, [x3]
    7010:      	ldr	x3, [x3, #0x8]
    7014:      	fmov	d31, x3
    7018:      	mov	x3, x4
    701c:      	fmov	x4, d31
    7020:      	b	0x7044 <_stogir.floating.validate+0x130>
    7024:      	lsl	x3, x5, #4
    7028:      	ldr	x3, [x0, #0x28]
    702c:      	add	x3, x3, x5, lsl #4
    7030:      	ldr	x4, [x3]
    7034:      	ldr	x3, [x3, #0x8]
    7038:      	fmov	d31, x3
    703c:      	mov	x3, x4
    7040:      	fmov	x4, d31
    7044:      	mov	x5, x4
    7048:      	mov	x4, x3
    704c:      	mov	x3, #0x1                ; =1
    7050:      	b	0x7060 <_stogir.floating.validate+0x14c>
    7054:      	movz	x3, #0x0, lsl #48
    7058:      	movz	x4, #0x0, lsl #48
    705c:      	movz	x5, #0x0, lsl #48
    7060:      	lsr	w3, w3, #0
    7064:      	lsr	x16, x3, #0
    7068:      	cmp	x16, #0x1
    706c:      	b.eq	0x7088 <_stogir.floating.validate+0x174>
    7070:      	b.lo	0x7078 <_stogir.floating.validate+0x164>
    7074:      	b	0x708c <_stogir.floating.validate+0x178>
    7078:      	cmp	x16, #0x0
    707c:      	b.eq	0x7084 <_stogir.floating.validate+0x170>
    7080:      	b	0x708c <_stogir.floating.validate+0x178>
    7084:      	b	0x7090 <_stogir.floating.validate+0x17c>
    7088:      	b	0x70cc <_stogir.floating.validate+0x1b8>
    708c:      	b	0x744c <_stogir.floating.validate+0x538>
    7090:      	adrp	x16, 0x7000 <_stogir.floating.validate+0xec>
		0000000000007090:  ARM64_RELOC_PAGE21	l_stogir.409
    7094:      	ldr	x16, [x16]
		0000000000007094:  ARM64_RELOC_PAGEOFF12	l_stogir.409
    7098:      	orr	x0, x16, xzr
    709c:      	mov	x19, x8
    70a0:      	mov	x1, x0
    70a4:      	mov	x0, #0x1                ; =1
    70a8:      	mov	x2, #0x1c               ; =28
    70ac:      	str	x0, [x19]
    70b0:      	str	x1, [x19, #0x8]
    70b4:      	str	x2, [x19, #0x10]
    70b8:      	ldr	x19, [sp, #0x40]
    70bc:      	ldr	x29, [sp]
    70c0:      	ldr	x30, [sp, #0x8]
    70c4:      	add	sp, sp, #0x50
    70c8:      	ret
    70cc:      	add	x16, sp, #0x10
    70d0:      	str	x4, [x16]
    70d4:      	add	x16, sp, #0x10
    70d8:      	str	x5, [x16, #0x8]
    70dc:      	cmp	x1, #0x0
    70e0:      	b.gt	0x710c <_stogir.floating.validate+0x1f8>
    70e4:      	mov	x19, x8
    70e8:      	adrp	x16, 0x7000 <_stogir.floating.validate+0xec>
		00000000000070e8:  ARM64_RELOC_PAGE21	l_stogir.410
    70ec:      	ldr	x16, [x16]
		00000000000070ec:  ARM64_RELOC_PAGEOFF12	l_stogir.410
    70f0:      	orr	x0, x16, xzr
    70f4:      	mov	x1, x0
    70f8:      	mov	x0, #0x1                ; =1
    70fc:      	mov	x2, #0x1c               ; =28
    7100:      	b	0x70ac <_stogir.floating.validate+0x198>
    7104:      	movz	x4, #0x0, lsl #48
    7108:      	b	0x6fe4 <_stogir.floating.validate+0xd0>
    710c:      	uxtb	w4, w4
    7110:      	orr	x1, x4, xzr
    7114:      	cmp	x1, #0xe
    7118:      	cset	w3, ge
    711c:      	cmp	x1, #0x19
    7120:      	cset	w5, le
    7124:      	cmp	x1, #0x1f
    7128:      	cset	w6, eq
    712c:      	cmp	x1, #0x20
    7130:      	cset	w7, eq
    7134:      	uxtb	w16, w3
    7138:      	cmp	w16, wzr
    713c:      	b.eq	0x7198 <_stogir.floating.validate+0x284>
    7140:      	uxtb	w16, w5
    7144:      	cmp	w16, wzr
    7148:      	b.eq	0x7198 <_stogir.floating.validate+0x284>
    714c:      	cmp	x1, #0x1d
    7150:      	cset	w1, eq
    7154:      	ldr	x9, [x0, #0x78]
    7158:      	add	x2, x2, x9
    715c:      	ldr	w2, [x2]
    7160:      	uxtb	w16, w6
    7164:      	cmp	w16, wzr
    7168:      	b.ne	0x71d8 <_stogir.floating.validate+0x2c4>
    716c:      	uxtb	w16, w7
    7170:      	cmp	w16, wzr
    7174:      	b.ne	0x71d8 <_stogir.floating.validate+0x2c4>
    7178:      	uxtb	w16, w1
    717c:      	cmp	w16, wzr
    7180:      	mov	x16, #0x3               ; =3
    7184:      	mov	x17, #0x2               ; =2
    7188:      	csel	x6, x16, x17, ne
    718c:      	b	0x71dc <_stogir.floating.validate+0x2c8>
    7190:      	movz	x4, #0x0, lsl #48
    7194:      	b	0x6fdc <_stogir.floating.validate+0xc8>
    7198:      	uxtb	w16, w6
    719c:      	cmp	w16, wzr
    71a0:      	b.ne	0x714c <_stogir.floating.validate+0x238>
    71a4:      	uxtb	w16, w7
    71a8:      	cmp	w16, wzr
    71ac:      	b.ne	0x714c <_stogir.floating.validate+0x238>
    71b0:      	cmp	x1, #0x1a
    71b4:      	b.lt	0x71c0 <_stogir.floating.validate+0x2ac>
    71b8:      	cmp	x1, #0x1d
    71bc:      	b.le	0x714c <_stogir.floating.validate+0x238>
    71c0:      	cmp	x1, #0x3a
    71c4:      	b.eq	0x714c <_stogir.floating.validate+0x238>
    71c8:      	cmp	x1, #0x3b
    71cc:      	b.eq	0x714c <_stogir.floating.validate+0x238>
    71d0:      	mov	x19, x8
    71d4:      	b	0x70e8 <_stogir.floating.validate+0x1d4>
    71d8:      	mov	x6, #0x1                ; =1
    71dc:      	sxtw	x2, w2
    71e0:      	lsr	w6, w6, #0
    71e4:      	sxtw	x6, w6
    71e8:      	cmp	x2, x6
    71ec:      	b.ne	0x745c <_stogir.floating.validate+0x548>
    71f0:      	add	x16, sp, #0x10
    71f4:      	ldr	w2, [x16, #0x4]
    71f8:      	sxtw	x2, w2
    71fc:      	cmp	x2, #0x0
    7200:      	cset	w6, gt
    7204:      	movz	x16, #0x0, lsl #48
    7208:      	sub	x7, x16, x2
    720c:      	sub	x9, x7, #0x1
    7210:      	uxtb	w16, w6
    7214:      	cmp	w16, wzr
    7218:      	b.eq	0x7278 <_stogir.floating.validate+0x364>
    721c:      	ldr	x7, [x0, #0x8]
    7220:      	cmp	x2, x7
    7224:      	b.ge	0x72c4 <_stogir.floating.validate+0x3b0>
    7228:      	add	x7, x0, #0x78
    722c:      	ldr	x7, [x7, #0x8]
    7230:      	cmp	x2, x7
    7234:      	b.ge	0x73a4 <_stogir.floating.validate+0x490>
    7238:      	lsl	x7, x2, #2
    723c:      	ldr	x7, [x0, #0x78]
    7240:      	add	x7, x7, x2, lsl #2
    7244:      	ldr	w7, [x7]
    7248:      	sxtw	x7, w7
    724c:      	cmp	x7, #0x0
    7250:      	cset	w7, ge
    7254:      	ubfx	x7, x7, #0, #8
    7258:      	b	0x73a8 <_stogir.floating.validate+0x494>
    725c:      	adrp	x16, 0x7000 <_stogir.floating.validate+0xec>
		000000000000725c:  ARM64_RELOC_PAGE21	l_stogir.411
    7260:      	ldr	x16, [x16]
		0000000000007260:  ARM64_RELOC_PAGEOFF12	l_stogir.411
    7264:      	orr	x0, x16, xzr
    7268:      	mov	x1, x0
    726c:      	mov	x0, #0x1                ; =1
    7270:      	mov	x2, #0x1d               ; =29
    7274:      	b	0x7100 <_stogir.floating.validate+0x1ec>
    7278:      	cmp	x2, #0x0
    727c:      	b.ge	0x72cc <_stogir.floating.validate+0x3b8>
    7280:      	add	x10, x0, #0x28
    7284:      	add	x11, x0, #0x50
    7288:      	ldr	x10, [x10, #0x8]
    728c:      	ldr	x11, [x11, #0x8]
    7290:      	cmp	x10, x11
    7294:      	b.ne	0x739c <_stogir.floating.validate+0x488>
    7298:      	cmp	x7, x10
    729c:      	b.gt	0x7444 <_stogir.floating.validate+0x530>
    72a0:      	lsl	x7, x9, #2
    72a4:      	ldr	x7, [x0, #0x50]
    72a8:      	add	x7, x7, x9, lsl #2
    72ac:      	ldr	w7, [x7]
    72b0:      	sxtw	x7, w7
    72b4:      	cmp	x7, #0x0
    72b8:      	cset	w7, gt
    72bc:      	ubfx	x7, x7, #0, #8
    72c0:      	b	0x7448 <_stogir.floating.validate+0x534>
    72c4:      	movz	x7, #0x0, lsl #48
    72c8:      	b	0x72d0 <_stogir.floating.validate+0x3bc>
    72cc:      	movz	x7, #0x0, lsl #48
    72d0:      	cmp	x7, #0x0
    72d4:      	b.eq	0x7314 <_stogir.floating.validate+0x400>
    72d8:      	uxtb	w16, w6
    72dc:      	cmp	w16, wzr
    72e0:      	b.eq	0x72f8 <_stogir.floating.validate+0x3e4>
    72e4:      	lsl	x6, x2, #4
    72e8:      	ldr	x6, [x0]
    72ec:      	add	x2, x6, x2, lsl #4
    72f0:      	ldr	x2, [x2]
    72f4:      	b	0x7308 <_stogir.floating.validate+0x3f4>
    72f8:      	lsl	x2, x9, #4
    72fc:      	ldr	x2, [x0, #0x28]
    7300:      	add	x2, x2, x9, lsl #4
    7304:      	ldr	x2, [x2]
    7308:      	mov	x6, x2
    730c:      	mov	x2, #0x1                ; =1
    7310:      	b	0x731c <_stogir.floating.validate+0x408>
    7314:      	movz	x2, #0x0, lsl #48
    7318:      	movz	x6, #0x0, lsl #48
    731c:      	lsr	w2, w2, #0
    7320:      	lsr	x16, x2, #0
    7324:      	cmp	x16, #0x1
    7328:      	b.eq	0x7344 <_stogir.floating.validate+0x430>
    732c:      	b.lo	0x7334 <_stogir.floating.validate+0x420>
    7330:      	b	0x7348 <_stogir.floating.validate+0x434>
    7334:      	cmp	x16, #0x0
    7338:      	b.eq	0x7340 <_stogir.floating.validate+0x42c>
    733c:      	b	0x7348 <_stogir.floating.validate+0x434>
    7340:      	b	0x734c <_stogir.floating.validate+0x438>
    7344:      	b	0x736c <_stogir.floating.validate+0x458>
    7348:      	b	0x7454 <_stogir.floating.validate+0x540>
    734c:      	adrp	x16, 0x7000 <_stogir.floating.validate+0xec>
		000000000000734c:  ARM64_RELOC_PAGE21	l_stogir.412
    7350:      	ldr	x16, [x16]
		0000000000007350:  ARM64_RELOC_PAGEOFF12	l_stogir.412
    7354:      	orr	x0, x16, xzr
    7358:      	mov	x19, x8
    735c:      	mov	x1, x0
    7360:      	mov	x0, #0x1                ; =1
    7364:      	mov	x2, #0x18               ; =24
    7368:      	b	0x7274 <_stogir.floating.validate+0x360>
    736c:      	lsr	w6, w6, #0
    7370:      	add	x16, sp, #0x10
    7374:      	ldr	w2, [x16]
    7378:      	ubfx	x6, x6, #8, #8
    737c:      	uxtb	w16, w3
    7380:      	cmp	w16, wzr
    7384:      	b.eq	0x7400 <_stogir.floating.validate+0x4ec>
    7388:      	uxtb	w16, w5
    738c:      	cmp	w16, wzr
    7390:      	b.eq	0x7400 <_stogir.floating.validate+0x4ec>
    7394:      	mov	x3, #0x1                ; =1
    7398:      	b	0x7404 <_stogir.floating.validate+0x4f0>
    739c:      	movz	x7, #0x0, lsl #48
    73a0:      	b	0x72d0 <_stogir.floating.validate+0x3bc>
    73a4:      	movz	x7, #0x0, lsl #48
    73a8:      	b	0x72c8 <_stogir.floating.validate+0x3b4>
    73ac:      	movz	x1, #0x0, lsl #48
    73b0:      	lsr	w2, w2, #0
    73b4:      	lsr	w3, w3, #0
    73b8:      	lsr	w4, w4, #0
    73bc:      	lsr	w6, w6, #0
    73c0:      	lsr	w1, w1, #0
    73c4:      	mov	w5, w1
    73c8:      	mov	w1, w4
    73cc:      	mov	w4, w3
    73d0:      	mov	w3, w2
    73d4:      	mov	w2, w6
    73d8:      	mov	x19, x8
    73dc:      	add	x8, sp, #0x20
    73e0:      	bl	0x73e0 <_stogir.floating.validate+0x4cc>
		00000000000073e0:  ARM64_RELOC_BRANCH26	_stogir.floating.operands
    73e4:      	add	x16, sp, #0x20
    73e8:      	ldr	x0, [x16]
    73ec:      	add	x16, sp, #0x20
    73f0:      	ldr	x1, [x16, #0x8]
    73f4:      	add	x16, sp, #0x20
    73f8:      	ldr	x2, [x16, #0x10]
    73fc:      	b	0x7274 <_stogir.floating.validate+0x360>
    7400:      	orr	x3, x6, xzr
    7404:      	lsr	w3, w3, #0
    7408:      	ubfx	x2, x2, #8, #8
    740c:      	sxtw	x3, w3
    7410:      	cmp	x2, x3
    7414:      	b.ne	0x7464 <_stogir.floating.validate+0x550>
    7418:      	add	x16, sp, #0x10
    741c:      	ldr	w2, [x16, #0x4]
    7420:      	add	x16, sp, #0x10
    7424:      	ldr	w3, [x16, #0x8]
    7428:      	uxtb	w16, w1
    742c:      	cmp	w16, wzr
    7430:      	b.eq	0x73ac <_stogir.floating.validate+0x498>
    7434:      	add	x16, sp, #0x10
    7438:      	ldr	w1, [x16, #0xc]
    743c:      	sxtw	x1, w1
    7440:      	b	0x73b0 <_stogir.floating.validate+0x49c>
    7444:      	movz	x7, #0x0, lsl #48
    7448:      	b	0x73a0 <_stogir.floating.validate+0x48c>
    744c:      	brk	#0
    7450:      	b	0x744c <_stogir.floating.validate+0x538>
    7454:      	brk	#0
    7458:      	b	0x7454 <_stogir.floating.validate+0x540>
    745c:      	mov	x19, x8
    7460:      	b	0x70e8 <_stogir.floating.validate+0x1d4>
    7464:      	mov	x19, x8
    7468:      	b	0x725c <_stogir.floating.validate+0x348>

000000000000746c <_stogir.types.integer?>:
    746c:      	sxtw	x0, w0
    7470:      	cmp	x0, #0x1
    7474:      	b.lt	0x7488 <_stogir.types.integer?+0x1c>
    7478:      	cmp	x0, #0xb
    747c:      	cset	w0, le
    7480:      	ubfx	x0, x0, #0, #8
    7484:      	b	0x748c <_stogir.types.integer?+0x20>
    7488:      	movz	x0, #0x0, lsl #48
    748c:      	ret

0000000000007490 <_stogir.integer-unary.valid-type?>:
    7490:      	sxtw	x0, w0
    7494:      	cmp	x0, #0x2d
    7498:      	cset	w2, eq
    749c:      	cmp	x0, #0x1f
    74a0:      	cset	w3, eq
    74a4:      	cmp	x0, #0x20
    74a8:      	cset	w4, eq
    74ac:      	cmp	x0, #0x36
    74b0:      	cset	w5, eq
    74b4:      	uxtb	w16, w3
    74b8:      	cmp	w16, wzr
    74bc:      	b.ne	0x7504 <_stogir.integer-unary.valid-type?+0x74>
    74c0:      	uxtb	w16, w4
    74c4:      	cmp	w16, wzr
    74c8:      	b.ne	0x7504 <_stogir.integer-unary.valid-type?+0x74>
    74cc:      	uxtb	w16, w2
    74d0:      	cmp	w16, wzr
    74d4:      	b.ne	0x7504 <_stogir.integer-unary.valid-type?+0x74>
    74d8:      	uxtb	w16, w5
    74dc:      	cmp	w16, wzr
    74e0:      	b.ne	0x7504 <_stogir.integer-unary.valid-type?+0x74>
    74e4:      	cmp	x0, #0x37
    74e8:      	b.eq	0x7504 <_stogir.integer-unary.valid-type?+0x74>
    74ec:      	cmp	x0, #0x38
    74f0:      	b.eq	0x7504 <_stogir.integer-unary.valid-type?+0x74>
    74f4:      	cmp	x0, #0x39
    74f8:      	b.eq	0x7504 <_stogir.integer-unary.valid-type?+0x74>
    74fc:      	movz	x0, #0x0, lsl #48
    7500:      	b	0x753c <_stogir.integer-unary.valid-type?+0xac>
    7504:      	sxtw	x1, w1
    7508:      	cmp	x1, #0x1
    750c:      	b.lt	0x7538 <_stogir.integer-unary.valid-type?+0xa8>
    7510:      	cmp	x1, #0xb
    7514:      	cset	w0, le
    7518:      	uxtb	w16, w0
    751c:      	cmp	w16, wzr
    7520:      	b.eq	0x7538 <_stogir.integer-unary.valid-type?+0xa8>
    7524:      	uxtb	w16, w2
    7528:      	cmp	w16, wzr
    752c:      	b.eq	0x7548 <_stogir.integer-unary.valid-type?+0xb8>
    7530:      	mov	x0, #0x1                ; =1
    7534:      	b	0x7544 <_stogir.integer-unary.valid-type?+0xb4>
    7538:      	movz	x0, #0x0, lsl #48
    753c:      	ret
    7540:      	mov	x0, #0x1                ; =1
    7544:      	b	0x753c <_stogir.integer-unary.valid-type?+0xac>
    7548:      	cmp	x1, #0x1
    754c:      	b.ne	0x7558 <_stogir.integer-unary.valid-type?+0xc8>
    7550:      	movz	x0, #0x0, lsl #48
    7554:      	b	0x7544 <_stogir.integer-unary.valid-type?+0xb4>
    7558:      	cmp	x1, #0x6
    755c:      	cset	w2, eq
    7560:      	uxtb	w16, w3
    7564:      	cmp	w16, wzr
    7568:      	b.eq	0x757c <_stogir.integer-unary.valid-type?+0xec>
    756c:      	uxtb	w16, w2
    7570:      	cmp	w16, wzr
    7574:      	cset	x0, eq
    7578:      	b	0x7544 <_stogir.integer-unary.valid-type?+0xb4>
    757c:      	uxtb	w16, w4
    7580:      	cmp	w16, wzr
    7584:      	b.eq	0x75a0 <_stogir.integer-unary.valid-type?+0x110>
    7588:      	cmp	x1, #0x7
    758c:      	b.lt	0x7598 <_stogir.integer-unary.valid-type?+0x108>
    7590:      	ubfx	x0, x0, #0, #8
    7594:      	b	0x759c <_stogir.integer-unary.valid-type?+0x10c>
    7598:      	movz	x0, #0x0, lsl #48
    759c:      	b	0x7544 <_stogir.integer-unary.valid-type?+0xb4>
    75a0:      	uxtb	w16, w5
    75a4:      	cmp	w16, wzr
    75a8:      	b.eq	0x7540 <_stogir.integer-unary.valid-type?+0xb0>
    75ac:      	cmp	x1, #0x3
    75b0:      	b.ne	0x75cc <_stogir.integer-unary.valid-type?+0x13c>
    75b4:      	mov	x0, #0x1                ; =1
    75b8:      	b	0x75c8 <_stogir.integer-unary.valid-type?+0x138>
    75bc:      	cmp	x1, #0xb
    75c0:      	cset	w0, eq
    75c4:      	ubfx	x0, x0, #0, #8
    75c8:      	b	0x7544 <_stogir.integer-unary.valid-type?+0xb4>
    75cc:      	cmp	x1, #0x4
    75d0:      	b.ne	0x75dc <_stogir.integer-unary.valid-type?+0x14c>
    75d4:      	mov	x0, #0x1                ; =1
    75d8:      	b	0x75c8 <_stogir.integer-unary.valid-type?+0x138>
    75dc:      	cmp	x1, #0x5
    75e0:      	b.ne	0x75ec <_stogir.integer-unary.valid-type?+0x15c>
    75e4:      	mov	x0, #0x1                ; =1
    75e8:      	b	0x75c8 <_stogir.integer-unary.valid-type?+0x138>
    75ec:      	uxtb	w16, w2
    75f0:      	cmp	w16, wzr
    75f4:      	b.eq	0x7600 <_stogir.integer-unary.valid-type?+0x170>
    75f8:      	mov	x0, #0x1                ; =1
    75fc:      	b	0x75c8 <_stogir.integer-unary.valid-type?+0x138>
    7600:      	cmp	x1, #0x9
    7604:      	b.ne	0x7610 <_stogir.integer-unary.valid-type?+0x180>
    7608:      	mov	x0, #0x1                ; =1
    760c:      	b	0x75c8 <_stogir.integer-unary.valid-type?+0x138>
    7610:      	cmp	x1, #0xa
    7614:      	b.ne	0x75bc <_stogir.integer-unary.valid-type?+0x12c>
    7618:      	mov	x0, #0x1                ; =1
    761c:      	b	0x75c8 <_stogir.integer-unary.valid-type?+0x138>

0000000000007620 <_stogir.integer-binary.valid-type?>:
    7620:      	sxtw	x0, w0
    7624:      	cmp	x0, #0x3a
    7628:      	cset	w2, eq
    762c:      	cmp	x0, #0x3b
    7630:      	cset	w3, eq
    7634:      	cmp	x0, #0x1a
    7638:      	b.lt	0x768c <_stogir.integer-binary.valid-type?+0x6c>
    763c:      	cmp	x0, #0x1e
    7640:      	b.gt	0x768c <_stogir.integer-binary.valid-type?+0x6c>
    7644:      	sxtw	x1, w1
    7648:      	cmp	x1, #0x1
    764c:      	b.lt	0x76bc <_stogir.integer-binary.valid-type?+0x9c>
    7650:      	cmp	x1, #0xb
    7654:      	b.gt	0x76bc <_stogir.integer-binary.valid-type?+0x9c>
    7658:      	cmp	x1, #0x1
    765c:      	b.ne	0x76c4 <_stogir.integer-binary.valid-type?+0xa4>
    7660:      	cmp	x0, #0x2e
    7664:      	b.eq	0x76cc <_stogir.integer-binary.valid-type?+0xac>
    7668:      	cmp	x0, #0x2f
    766c:      	b.eq	0x76cc <_stogir.integer-binary.valid-type?+0xac>
    7670:      	cmp	x0, #0x30
    7674:      	b.eq	0x76cc <_stogir.integer-binary.valid-type?+0xac>
    7678:      	uxtb	w16, w2
    767c:      	cmp	w16, wzr
    7680:      	b.eq	0x76d4 <_stogir.integer-binary.valid-type?+0xb4>
    7684:      	mov	x0, #0x1                ; =1
    7688:      	b	0x76dc <_stogir.integer-binary.valid-type?+0xbc>
    768c:      	cmp	x0, #0x2e
    7690:      	b.lt	0x769c <_stogir.integer-binary.valid-type?+0x7c>
    7694:      	cmp	x0, #0x35
    7698:      	b.le	0x7644 <_stogir.integer-binary.valid-type?+0x24>
    769c:      	uxtb	w16, w2
    76a0:      	cmp	w16, wzr
    76a4:      	b.ne	0x7644 <_stogir.integer-binary.valid-type?+0x24>
    76a8:      	uxtb	w16, w3
    76ac:      	cmp	w16, wzr
    76b0:      	b.ne	0x7644 <_stogir.integer-binary.valid-type?+0x24>
    76b4:      	movz	x0, #0x0, lsl #48
    76b8:      	b	0x76c0 <_stogir.integer-binary.valid-type?+0xa0>
    76bc:      	movz	x0, #0x0, lsl #48
    76c0:      	ret
    76c4:      	mov	x0, #0x1                ; =1
    76c8:      	b	0x76c0 <_stogir.integer-binary.valid-type?+0xa0>
    76cc:      	mov	x0, #0x1                ; =1
    76d0:      	b	0x76c8 <_stogir.integer-binary.valid-type?+0xa8>
    76d4:      	ubfx	x3, x3, #0, #8
    76d8:      	mov	x0, x3
    76dc:      	b	0x76d0 <_stogir.integer-binary.valid-type?+0xb0>

00000000000076e0 <_coil.core.Len$slice$len__u8>:
    76e0:      	mov	x0, x1
    76e4:      	ret

00000000000076e8 <_inherent$slice$data__u8>:
    76e8:      	ret

00000000000076ec <_coil.mem.eql__u8>:
    76ec:      	sub	sp, sp, #0x10
    76f0:      	str	x29, [sp]
    76f4:      	str	x30, [sp, #0x8]
    76f8:      	mov	x29, sp
    76fc:      	cmp	x2, #0x0
    7700:      	b.ne	0x770c <_coil.mem.eql__u8+0x20>
    7704:      	mov	x0, #0x1                ; =1
    7708:      	b	0x7728 <_coil.mem.eql__u8+0x3c>
    770c:      	lsr	x2, x2, #0
    7710:      	bl	0x7710 <_coil.mem.eql__u8+0x24>
		0000000000007710:  ARM64_RELOC_BRANCH26	_memcmp
    7714:      	lsr	w0, w0, #0
    7718:      	sxtw	x0, w0
    771c:      	cmp	x0, #0x0
    7720:      	cset	w0, eq
    7724:      	ubfx	x0, x0, #0, #8
    7728:      	ldr	x29, [sp]
    772c:      	ldr	x30, [sp, #0x8]
    7730:      	add	sp, sp, #0x10
    7734:      	ret

0000000000007738 <_stogir.opcode.count>:
    7738:      	mov	x0, #0x83               ; =131
    773c:      	ret

0000000000007740 <_stogir.types.valid-scalar?>:
    7740:      	sxtw	x0, w0
    7744:      	cmp	x0, #0x0
    7748:      	b.lt	0x775c <_stogir.types.valid-scalar?+0x1c>
    774c:      	cmp	x0, #0xd
    7750:      	cset	w0, le
    7754:      	ubfx	x0, x0, #0, #8
    7758:      	b	0x7760 <_stogir.types.valid-scalar?+0x20>
    775c:      	movz	x0, #0x0, lsl #48
    7760:      	ret

0000000000007764 <_stogir.types.vector?>:
    7764:      	sxtw	x0, w0
    7768:      	cmp	x0, #0xf
    776c:      	b.le	0x77a8 <_stogir.types.vector?+0x44>
    7770:      	cmp	x0, #0x80
    7774:      	b.ge	0x77b8 <_stogir.types.vector?+0x54>
    7778:      	and	x1, x0, #0xf
    777c:      	lsr	w1, w1, #0
    7780:      	sxtw	x1, w1
    7784:      	cmp	x1, #0x1
    7788:      	b.lt	0x77b0 <_stogir.types.vector?+0x4c>
    778c:      	and	x0, x0, #0xf
    7790:      	lsr	w0, w0, #0
    7794:      	sxtw	x0, w0
    7798:      	cmp	x0, #0xd
    779c:      	cset	w0, le
    77a0:      	ubfx	x0, x0, #0, #8
    77a4:      	b	0x77b4 <_stogir.types.vector?+0x50>
    77a8:      	movz	x0, #0x0, lsl #48
    77ac:      	b	0x77b4 <_stogir.types.vector?+0x50>
    77b0:      	movz	x0, #0x0, lsl #48
    77b4:      	ret
    77b8:      	movz	x0, #0x0, lsl #48
    77bc:      	b	0x77b4 <_stogir.types.vector?+0x50>

00000000000077c0 <_coil.core.Get$slice$get__i8>:
    77c0:      	lsr	x1, x2, #0
    77c4:      	add	x0, x0, x2
    77c8:      	ldrsb	w0, [x0]
    77cc:      	sxtb	x0, w0
    77d0:      	ret

00000000000077d4 <_stogir.opcode.metadata>:
    77d4:      	sub	sp, sp, #0x10
    77d8:      	mov	x0, sp
    77dc:      	adrp	x16, 0x7000 <_stogir.floating.validate+0xec>
		00000000000077dc:  ARM64_RELOC_PAGE21	l_stogir.413
    77e0:      	ldr	x16, [x16]
		00000000000077e0:  ARM64_RELOC_PAGEOFF12	l_stogir.413
    77e4:      	orr	x1, x16, xzr
    77e8:      	str	x1, [x0]
    77ec:      	mov	x17, #0x83              ; =131
    77f0:      	str	x17, [x0, #0x8]
    77f4:      	ldr	x0, [sp]
    77f8:      	ldr	x1, [sp, #0x8]
    77fc:      	add	sp, sp, #0x10
    7800:      	ret

0000000000007804 <_coil.core.Get$slice$get__u32>:
    7804:      	lsl	x1, x2, #2
    7808:      	add	x0, x0, x2, lsl #2
    780c:      	ldr	w0, [x0]
    7810:      	ret

0000000000007814 <_stogir.opcode.operand-code-word>:
    7814:      	sxtw	x1, w1
    7818:      	cmp	x1, #0x0
    781c:      	b.le	0x7830 <_stogir.opcode.operand-code-word+0x1c>
    7820:      	cmp	x1, #0x4
    7824:      	b.le	0x7838 <_stogir.opcode.operand-code-word+0x24>
    7828:      	mov	x1, #0x4                ; =4
    782c:      	b	0x7844 <_stogir.opcode.operand-code-word+0x30>
    7830:      	movz	x0, #0x0, lsl #48
    7834:      	b	0x7864 <_stogir.opcode.operand-code-word+0x50>
    7838:      	sub	x1, x1, #0x1
    783c:      	lsr	w1, w1, #0
    7840:      	sxtw	x1, w1
    7844:      	ubfx	x0, x0, #0, #32
    7848:      	lsl	x1, x1, #2
    784c:      	lsr	w1, w1, #0
    7850:      	ubfx	x1, x1, #0, #32
    7854:      	lsr	x0, x0, x1
    7858:      	lsr	w0, w0, #0
    785c:      	and	x0, x0, #0xf
    7860:      	lsr	w0, w0, #0
    7864:      	ret

0000000000007868 <_inherent$coil.arraylist.ArrayList$at__stogir.node.Node>:
    7868:      	lsl	x2, x1, #4
    786c:      	ldr	x0, [x0]
    7870:      	add	x0, x0, x1, lsl #4
    7874:      	ret

0000000000007878 <_coil.core.Len$coil.arraylist.ArrayList$len__stogir.strings.Entry>:
    7878:      	ldr	x0, [x0, #0x8]
    787c:      	ret

0000000000007880 <_coil.core.Len$coil.arraylist.ArrayList$len__u8>:
    7880:      	ldr	x0, [x0, #0x8]
    7884:      	ret

0000000000007888 <_inherent$coil.arraylist.ArrayList$slice__u8>:
    7888:      	sub	sp, sp, #0x10
    788c:      	mov	x1, sp
    7890:      	ldr	x2, [x0]
    7894:      	ldr	x0, [x0, #0x8]
    7898:      	str	x2, [x1]
    789c:      	str	x0, [x1, #0x8]
    78a0:      	ldr	x0, [sp]
    78a4:      	ldr	x1, [sp, #0x8]
    78a8:      	add	sp, sp, #0x10
    78ac:      	ret

00000000000078b0 <_coil.slice.subslice__u8>:
    78b0:      	sub	sp, sp, #0x10
    78b4:      	mov	x1, sp
    78b8:      	lsr	x4, x2, #0
    78bc:      	sub	x3, x3, x2
    78c0:      	add	x0, x0, x2
    78c4:      	str	x0, [x1]
    78c8:      	str	x3, [x1, #0x8]
    78cc:      	ldr	x0, [sp]
    78d0:      	ldr	x1, [sp, #0x8]
    78d4:      	add	sp, sp, #0x10
    78d8:      	ret

00000000000078dc <_stogir.floating.operation?>:
    78dc:      	sxtw	x0, w0
    78e0:      	cmp	x0, #0xe
    78e4:      	b.lt	0x78f8 <_stogir.floating.operation?+0x1c>
    78e8:      	cmp	x0, #0x19
    78ec:      	b.gt	0x78f8 <_stogir.floating.operation?+0x1c>
    78f0:      	mov	x0, #0x1                ; =1
    78f4:      	b	0x7924 <_stogir.floating.operation?+0x48>
    78f8:      	cmp	x0, #0x1f
    78fc:      	b.eq	0x7920 <_stogir.floating.operation?+0x44>
    7900:      	cmp	x0, #0x20
    7904:      	b.eq	0x7920 <_stogir.floating.operation?+0x44>
    7908:      	cmp	x0, #0x1a
    790c:      	b.lt	0x7938 <_stogir.floating.operation?+0x5c>
    7910:      	cmp	x0, #0x1d
    7914:      	b.gt	0x7938 <_stogir.floating.operation?+0x5c>
    7918:      	mov	x0, #0x1                ; =1
    791c:      	b	0x7934 <_stogir.floating.operation?+0x58>
    7920:      	mov	x0, #0x1                ; =1
    7924:      	ret
    7928:      	cmp	x0, #0x3b
    792c:      	cset	w0, eq
    7930:      	ubfx	x0, x0, #0, #8
    7934:      	b	0x7924 <_stogir.floating.operation?+0x48>
    7938:      	cmp	x0, #0x3a
    793c:      	b.ne	0x7928 <_stogir.floating.operation?+0x4c>
    7940:      	mov	x0, #0x1                ; =1
    7944:      	b	0x7934 <_stogir.floating.operation?+0x58>

0000000000007948 <_stogir.types.floating?>:
    7948:      	sxtw	x0, w0
    794c:      	cmp	x0, #0xc
    7950:      	b.ne	0x795c <_stogir.types.floating?+0x14>
    7954:      	mov	x0, #0x1                ; =1
    7958:      	b	0x7968 <_stogir.types.floating?+0x20>
    795c:      	cmp	x0, #0xd
    7960:      	cset	w0, eq
    7964:      	ubfx	x0, x0, #0, #8
    7968:      	ret

000000000000796c <_stogir.vector-lanes.validate>:
    796c:      	sub	sp, sp, #0x50
    7970:      	str	x29, [sp]
    7974:      	str	x30, [sp, #0x8]
    7978:      	mov	x29, sp
    797c:      	str	x19, [sp, #0x40]
    7980:      	sxtw	x1, w1
    7984:      	lsl	x3, x1, #2
    7988:      	cmp	x1, #0x0
    798c:      	cset	w4, gt
    7990:      	movz	x16, #0x0, lsl #48
    7994:      	sub	x5, x16, x1
    7998:      	sub	x6, x5, #0x1
    799c:      	uxtb	w16, w4
    79a0:      	cmp	w16, wzr
    79a4:      	b.eq	0x79e4 <_stogir.vector-lanes.validate+0x78>
    79a8:      	ldr	x5, [x0, #0x8]
    79ac:      	cmp	x1, x5
    79b0:      	b.ge	0x7a38 <_stogir.vector-lanes.validate+0xcc>
    79b4:      	add	x5, x0, #0x78
    79b8:      	ldr	x5, [x5, #0x8]
    79bc:      	cmp	x1, x5
    79c0:      	b.ge	0x7b5c <_stogir.vector-lanes.validate+0x1f0>
    79c4:      	ldr	x5, [x0, #0x78]
    79c8:      	add	x5, x3, x5
    79cc:      	ldr	w5, [x5]
    79d0:      	sxtw	x5, w5
    79d4:      	cmp	x5, #0x0
    79d8:      	cset	w5, ge
    79dc:      	ubfx	x5, x5, #0, #8
    79e0:      	b	0x7b60 <_stogir.vector-lanes.validate+0x1f4>
    79e4:      	cmp	x1, #0x0
    79e8:      	b.ge	0x7a40 <_stogir.vector-lanes.validate+0xd4>
    79ec:      	add	x7, x0, #0x28
    79f0:      	add	x9, x0, #0x50
    79f4:      	ldr	x7, [x7, #0x8]
    79f8:      	ldr	x9, [x9, #0x8]
    79fc:      	cmp	x7, x9
    7a00:      	b.ne	0x7a30 <_stogir.vector-lanes.validate+0xc4>
    7a04:      	cmp	x5, x7
    7a08:      	b.gt	0x7ba0 <_stogir.vector-lanes.validate+0x234>
    7a0c:      	lsl	x5, x6, #2
    7a10:      	ldr	x5, [x0, #0x50]
    7a14:      	add	x5, x5, x6, lsl #2
    7a18:      	ldr	w5, [x5]
    7a1c:      	sxtw	x5, w5
    7a20:      	cmp	x5, #0x0
    7a24:      	cset	w5, gt
    7a28:      	ubfx	x5, x5, #0, #8
    7a2c:      	b	0x7ba4 <_stogir.vector-lanes.validate+0x238>
    7a30:      	movz	x5, #0x0, lsl #48
    7a34:      	b	0x7a44 <_stogir.vector-lanes.validate+0xd8>
    7a38:      	movz	x5, #0x0, lsl #48
    7a3c:      	b	0x7a44 <_stogir.vector-lanes.validate+0xd8>
    7a40:      	movz	x5, #0x0, lsl #48
    7a44:      	cmp	x5, #0x0
    7a48:      	b.eq	0x7aac <_stogir.vector-lanes.validate+0x140>
    7a4c:      	uxtb	w16, w4
    7a50:      	cmp	w16, wzr
    7a54:      	b.eq	0x7a7c <_stogir.vector-lanes.validate+0x110>
    7a58:      	lsl	x4, x1, #4
    7a5c:      	ldr	x4, [x0]
    7a60:      	add	x4, x4, x1, lsl #4
    7a64:      	ldr	x5, [x4]
    7a68:      	ldr	x4, [x4, #0x8]
    7a6c:      	fmov	d31, x4
    7a70:      	mov	x4, x5
    7a74:      	fmov	x5, d31
    7a78:      	b	0x7a9c <_stogir.vector-lanes.validate+0x130>
    7a7c:      	lsl	x4, x6, #4
    7a80:      	ldr	x4, [x0, #0x28]
    7a84:      	add	x4, x4, x6, lsl #4
    7a88:      	ldr	x5, [x4]
    7a8c:      	ldr	x4, [x4, #0x8]
    7a90:      	fmov	d31, x4
    7a94:      	mov	x4, x5
    7a98:      	fmov	x5, d31
    7a9c:      	mov	x6, x5
    7aa0:      	mov	x5, x4
    7aa4:      	mov	x4, #0x1                ; =1
    7aa8:      	b	0x7ab8 <_stogir.vector-lanes.validate+0x14c>
    7aac:      	movz	x4, #0x0, lsl #48
    7ab0:      	movz	x5, #0x0, lsl #48
    7ab4:      	movz	x6, #0x0, lsl #48
    7ab8:      	lsr	w4, w4, #0
    7abc:      	lsr	x16, x4, #0
    7ac0:      	cmp	x16, #0x1
    7ac4:      	b.eq	0x7ae0 <_stogir.vector-lanes.validate+0x174>
    7ac8:      	b.lo	0x7ad0 <_stogir.vector-lanes.validate+0x164>
    7acc:      	b	0x7ae4 <_stogir.vector-lanes.validate+0x178>
    7ad0:      	cmp	x16, #0x0
    7ad4:      	b.eq	0x7adc <_stogir.vector-lanes.validate+0x170>
    7ad8:      	b	0x7ae4 <_stogir.vector-lanes.validate+0x178>
    7adc:      	b	0x7ae8 <_stogir.vector-lanes.validate+0x17c>
    7ae0:      	b	0x7b08 <_stogir.vector-lanes.validate+0x19c>
    7ae4:      	b	0x7c84 <_stogir.vector-lanes.validate+0x318>
    7ae8:      	adrp	x16, 0x7000 <_stogir.floating.validate+0xec>
		0000000000007ae8:  ARM64_RELOC_PAGE21	l_stogir.414
    7aec:      	ldr	x16, [x16]
		0000000000007aec:  ARM64_RELOC_PAGEOFF12	l_stogir.414
    7af0:      	orr	x0, x16, xzr
    7af4:      	mov	x19, x8
    7af8:      	mov	x1, x0
    7afc:      	mov	x0, #0x1                ; =1
    7b00:      	mov	x2, #0x1f               ; =31
    7b04:      	b	0x7b3c <_stogir.vector-lanes.validate+0x1d0>
    7b08:      	add	x16, sp, #0x10
    7b0c:      	str	x5, [x16]
    7b10:      	add	x16, sp, #0x10
    7b14:      	str	x6, [x16, #0x8]
    7b18:      	cmp	x1, #0x0
    7b1c:      	b.gt	0x7b64 <_stogir.vector-lanes.validate+0x1f8>
    7b20:      	mov	x19, x8
    7b24:      	adrp	x16, 0x7000 <_stogir.floating.validate+0xec>
		0000000000007b24:  ARM64_RELOC_PAGE21	l_stogir.415
    7b28:      	ldr	x16, [x16]
		0000000000007b28:  ARM64_RELOC_PAGEOFF12	l_stogir.415
    7b2c:      	orr	x0, x16, xzr
    7b30:      	mov	x1, x0
    7b34:      	mov	x0, #0x1                ; =1
    7b38:      	mov	x2, #0x25               ; =37
    7b3c:      	str	x0, [x19]
    7b40:      	str	x1, [x19, #0x8]
    7b44:      	str	x2, [x19, #0x10]
    7b48:      	ldr	x19, [sp, #0x40]
    7b4c:      	ldr	x29, [sp]
    7b50:      	ldr	x30, [sp, #0x8]
    7b54:      	add	sp, sp, #0x50
    7b58:      	ret
    7b5c:      	movz	x5, #0x0, lsl #48
    7b60:      	b	0x7a3c <_stogir.vector-lanes.validate+0xd0>
    7b64:      	uxtb	w5, w5
    7b68:      	orr	x1, x5, xzr
    7b6c:      	cmp	x1, #0x3d
    7b70:      	b.lt	0x7c8c <_stogir.vector-lanes.validate+0x320>
    7b74:      	cmp	x1, #0x3f
    7b78:      	b.gt	0x7c94 <_stogir.vector-lanes.validate+0x328>
    7b7c:      	cmp	x1, #0x3e
    7b80:      	cset	w4, eq
    7b84:      	ldr	x6, [x0, #0x78]
    7b88:      	add	x3, x3, x6
    7b8c:      	ldr	w3, [x3]
    7b90:      	cmp	x1, #0x3d
    7b94:      	b.ne	0x7c14 <_stogir.vector-lanes.validate+0x2a8>
    7b98:      	mov	x6, #0x2                ; =2
    7b9c:      	b	0x7c28 <_stogir.vector-lanes.validate+0x2bc>
    7ba0:      	movz	x5, #0x0, lsl #48
    7ba4:      	b	0x7a34 <_stogir.vector-lanes.validate+0xc8>
    7ba8:      	movz	x4, #0x0, lsl #48
    7bac:      	lsr	w2, w2, #0
    7bb0:      	lsr	w6, w6, #0
    7bb4:      	lsr	w1, w1, #0
    7bb8:      	lsr	w5, w5, #0
    7bbc:      	lsr	w4, w4, #0
    7bc0:      	ubfx	x3, x3, #8, #8
    7bc4:      	lsr	w3, w3, #0
    7bc8:      	mov	x19, x8
    7bcc:      	add	x8, sp, #0x20
    7bd0:      	fmov	s31, w1
    7bd4:      	mov	w1, w5
    7bd8:      	fmov	w5, s31
    7bdc:      	fmov	s31, w2
    7be0:      	mov	w2, w3
    7be4:      	fmov	w3, s31
    7be8:      	fmov	s31, w4
    7bec:      	mov	w4, w6
    7bf0:      	fmov	w6, s31
    7bf4:      	bl	0x7bf4 <_stogir.vector-lanes.validate+0x288>
		0000000000007bf4:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.operands
    7bf8:      	add	x16, sp, #0x20
    7bfc:      	ldr	x0, [x16]
    7c00:      	add	x16, sp, #0x20
    7c04:      	ldr	x1, [x16, #0x8]
    7c08:      	add	x16, sp, #0x20
    7c0c:      	ldr	x2, [x16, #0x10]
    7c10:      	b	0x7b3c <_stogir.vector-lanes.validate+0x1d0>
    7c14:      	uxtb	w16, w4
    7c18:      	cmp	w16, wzr
    7c1c:      	mov	x16, #0x3               ; =3
    7c20:      	mov	x17, #0x1               ; =1
    7c24:      	csel	x6, x16, x17, ne
    7c28:      	sxtw	x3, w3
    7c2c:      	lsr	w6, w6, #0
    7c30:      	sxtw	x6, w6
    7c34:      	cmp	x3, x6
    7c38:      	b.ne	0x7c9c <_stogir.vector-lanes.validate+0x330>
    7c3c:      	add	x16, sp, #0x10
    7c40:      	ldr	w3, [x16]
    7c44:      	add	x16, sp, #0x10
    7c48:      	ldr	w6, [x16, #0x4]
    7c4c:      	cmp	x1, #0x3f
    7c50:      	b.ne	0x7c5c <_stogir.vector-lanes.validate+0x2f0>
    7c54:      	movz	x1, #0x0, lsl #48
    7c58:      	b	0x7c68 <_stogir.vector-lanes.validate+0x2fc>
    7c5c:      	add	x16, sp, #0x10
    7c60:      	ldr	w1, [x16, #0x8]
    7c64:      	sxtw	x1, w1
    7c68:      	uxtb	w16, w4
    7c6c:      	cmp	w16, wzr
    7c70:      	b.eq	0x7ba8 <_stogir.vector-lanes.validate+0x23c>
    7c74:      	add	x16, sp, #0x10
    7c78:      	ldr	w4, [x16, #0xc]
    7c7c:      	sxtw	x4, w4
    7c80:      	b	0x7bac <_stogir.vector-lanes.validate+0x240>
    7c84:      	brk	#0
    7c88:      	b	0x7c84 <_stogir.vector-lanes.validate+0x318>
    7c8c:      	mov	x19, x8
    7c90:      	b	0x7b24 <_stogir.vector-lanes.validate+0x1b8>
    7c94:      	mov	x19, x8
    7c98:      	b	0x7b24 <_stogir.vector-lanes.validate+0x1b8>
    7c9c:      	mov	x19, x8
    7ca0:      	b	0x7b24 <_stogir.vector-lanes.validate+0x1b8>

0000000000007ca4 <_stogir.vector-comparison.node?>:
    7ca4:      	sxtw	x1, w1
    7ca8:      	cmp	x1, #0x0
    7cac:      	cset	w2, gt
    7cb0:      	movz	x16, #0x0, lsl #48
    7cb4:      	sub	x3, x16, x1
    7cb8:      	sub	x4, x3, #0x1
    7cbc:      	uxtb	w16, w2
    7cc0:      	cmp	w16, wzr
    7cc4:      	b.eq	0x7d08 <_stogir.vector-comparison.node?+0x64>
    7cc8:      	ldr	x3, [x0, #0x8]
    7ccc:      	cmp	x1, x3
    7cd0:      	b.ge	0x7d5c <_stogir.vector-comparison.node?+0xb8>
    7cd4:      	add	x3, x0, #0x78
    7cd8:      	ldr	x3, [x3, #0x8]
    7cdc:      	cmp	x1, x3
    7ce0:      	b.ge	0x7e44 <_stogir.vector-comparison.node?+0x1a0>
    7ce4:      	lsl	x3, x1, #2
    7ce8:      	ldr	x3, [x0, #0x78]
    7cec:      	add	x3, x3, x1, lsl #2
    7cf0:      	ldr	w3, [x3]
    7cf4:      	sxtw	x3, w3
    7cf8:      	cmp	x3, #0x0
    7cfc:      	cset	w3, ge
    7d00:      	ubfx	x3, x3, #0, #8
    7d04:      	b	0x7e48 <_stogir.vector-comparison.node?+0x1a4>
    7d08:      	cmp	x1, #0x0
    7d0c:      	b.ge	0x7d64 <_stogir.vector-comparison.node?+0xc0>
    7d10:      	add	x5, x0, #0x28
    7d14:      	add	x6, x0, #0x50
    7d18:      	ldr	x5, [x5, #0x8]
    7d1c:      	ldr	x6, [x6, #0x8]
    7d20:      	cmp	x5, x6
    7d24:      	b.ne	0x7d54 <_stogir.vector-comparison.node?+0xb0>
    7d28:      	cmp	x3, x5
    7d2c:      	b.gt	0x7e4c <_stogir.vector-comparison.node?+0x1a8>
    7d30:      	lsl	x3, x4, #2
    7d34:      	ldr	x3, [x0, #0x50]
    7d38:      	add	x3, x3, x4, lsl #2
    7d3c:      	ldr	w3, [x3]
    7d40:      	sxtw	x3, w3
    7d44:      	cmp	x3, #0x0
    7d48:      	cset	w3, gt
    7d4c:      	ubfx	x3, x3, #0, #8
    7d50:      	b	0x7e50 <_stogir.vector-comparison.node?+0x1ac>
    7d54:      	movz	x3, #0x0, lsl #48
    7d58:      	b	0x7d68 <_stogir.vector-comparison.node?+0xc4>
    7d5c:      	movz	x3, #0x0, lsl #48
    7d60:      	b	0x7d68 <_stogir.vector-comparison.node?+0xc4>
    7d64:      	movz	x3, #0x0, lsl #48
    7d68:      	cmp	x3, #0x0
    7d6c:      	b.eq	0x7dac <_stogir.vector-comparison.node?+0x108>
    7d70:      	uxtb	w16, w2
    7d74:      	cmp	w16, wzr
    7d78:      	b.eq	0x7d90 <_stogir.vector-comparison.node?+0xec>
    7d7c:      	lsl	x2, x1, #4
    7d80:      	ldr	x0, [x0]
    7d84:      	add	x0, x0, x1, lsl #4
    7d88:      	ldr	x0, [x0]
    7d8c:      	b	0x7da0 <_stogir.vector-comparison.node?+0xfc>
    7d90:      	lsl	x1, x4, #4
    7d94:      	ldr	x0, [x0, #0x28]
    7d98:      	add	x0, x0, x4, lsl #4
    7d9c:      	ldr	x0, [x0]
    7da0:      	mov	x1, x0
    7da4:      	mov	x0, #0x1                ; =1
    7da8:      	b	0x7db4 <_stogir.vector-comparison.node?+0x110>
    7dac:      	movz	x0, #0x0, lsl #48
    7db0:      	movz	x1, #0x0, lsl #48
    7db4:      	lsr	w0, w0, #0
    7db8:      	lsr	x16, x0, #0
    7dbc:      	cmp	x16, #0x1
    7dc0:      	b.eq	0x7ddc <_stogir.vector-comparison.node?+0x138>
    7dc4:      	b.lo	0x7dcc <_stogir.vector-comparison.node?+0x128>
    7dc8:      	b	0x7de0 <_stogir.vector-comparison.node?+0x13c>
    7dcc:      	cmp	x16, #0x0
    7dd0:      	b.eq	0x7dd8 <_stogir.vector-comparison.node?+0x134>
    7dd4:      	b	0x7de0 <_stogir.vector-comparison.node?+0x13c>
    7dd8:      	b	0x7de4 <_stogir.vector-comparison.node?+0x140>
    7ddc:      	b	0x7df4 <_stogir.vector-comparison.node?+0x150>
    7de0:      	b	0x7e6c <_stogir.vector-comparison.node?+0x1c8>
    7de4:      	movz	x0, #0x0, lsl #48
    7de8:      	b	0x7df0 <_stogir.vector-comparison.node?+0x14c>
    7dec:      	movz	x0, #0x0, lsl #48
    7df0:      	ret
    7df4:      	uxtb	w0, w1
    7df8:      	cmp	x0, #0xe
    7dfc:      	b.lt	0x7dec <_stogir.vector-comparison.node?+0x148>
    7e00:      	cmp	x0, #0x19
    7e04:      	b.gt	0x7dec <_stogir.vector-comparison.node?+0x148>
    7e08:      	lsr	w1, w1, #0
    7e0c:      	ubfx	x0, x1, #8, #8
    7e10:      	cmp	x0, #0xf
    7e14:      	b.le	0x7e54 <_stogir.vector-comparison.node?+0x1b0>
    7e18:      	cmp	x0, #0x80
    7e1c:      	b.ge	0x7e5c <_stogir.vector-comparison.node?+0x1b8>
    7e20:      	and	x0, x0, #0xf
    7e24:      	lsr	w0, w0, #0
    7e28:      	sxtw	x0, w0
    7e2c:      	cmp	x0, #0x1
    7e30:      	b.lt	0x7e64 <_stogir.vector-comparison.node?+0x1c0>
    7e34:      	cmp	x0, #0xd
    7e38:      	cset	w0, le
    7e3c:      	ubfx	x0, x0, #0, #8
    7e40:      	b	0x7e68 <_stogir.vector-comparison.node?+0x1c4>
    7e44:      	movz	x3, #0x0, lsl #48
    7e48:      	b	0x7d60 <_stogir.vector-comparison.node?+0xbc>
    7e4c:      	movz	x3, #0x0, lsl #48
    7e50:      	b	0x7d58 <_stogir.vector-comparison.node?+0xb4>
    7e54:      	movz	x0, #0x0, lsl #48
    7e58:      	b	0x7df0 <_stogir.vector-comparison.node?+0x14c>
    7e5c:      	movz	x0, #0x0, lsl #48
    7e60:      	b	0x7e58 <_stogir.vector-comparison.node?+0x1b4>
    7e64:      	movz	x0, #0x0, lsl #48
    7e68:      	b	0x7e60 <_stogir.vector-comparison.node?+0x1bc>
    7e6c:      	brk	#0
    7e70:      	b	0x7e6c <_stogir.vector-comparison.node?+0x1c8>

0000000000007e74 <_stogir.vector-comparison.validate>:
    7e74:      	sub	sp, sp, #0x50
    7e78:      	str	x29, [sp]
    7e7c:      	str	x30, [sp, #0x8]
    7e80:      	mov	x29, sp
    7e84:      	str	x19, [sp, #0x40]
    7e88:      	sxtw	x1, w1
    7e8c:      	lsl	x3, x1, #2
    7e90:      	cmp	x1, #0x0
    7e94:      	cset	w4, gt
    7e98:      	movz	x16, #0x0, lsl #48
    7e9c:      	sub	x5, x16, x1
    7ea0:      	sub	x6, x5, #0x1
    7ea4:      	uxtb	w16, w4
    7ea8:      	cmp	w16, wzr
    7eac:      	b.eq	0x7eec <_stogir.vector-comparison.validate+0x78>
    7eb0:      	ldr	x5, [x0, #0x8]
    7eb4:      	cmp	x1, x5
    7eb8:      	b.ge	0x7f40 <_stogir.vector-comparison.validate+0xcc>
    7ebc:      	add	x5, x0, #0x78
    7ec0:      	ldr	x5, [x5, #0x8]
    7ec4:      	cmp	x1, x5
    7ec8:      	b.ge	0x8064 <_stogir.vector-comparison.validate+0x1f0>
    7ecc:      	ldr	x5, [x0, #0x78]
    7ed0:      	add	x5, x3, x5
    7ed4:      	ldr	w5, [x5]
    7ed8:      	sxtw	x5, w5
    7edc:      	cmp	x5, #0x0
    7ee0:      	cset	w5, ge
    7ee4:      	ubfx	x5, x5, #0, #8
    7ee8:      	b	0x8068 <_stogir.vector-comparison.validate+0x1f4>
    7eec:      	cmp	x1, #0x0
    7ef0:      	b.ge	0x7f48 <_stogir.vector-comparison.validate+0xd4>
    7ef4:      	add	x7, x0, #0x28
    7ef8:      	add	x9, x0, #0x50
    7efc:      	ldr	x7, [x7, #0x8]
    7f00:      	ldr	x9, [x9, #0x8]
    7f04:      	cmp	x7, x9
    7f08:      	b.ne	0x7f38 <_stogir.vector-comparison.validate+0xc4>
    7f0c:      	cmp	x5, x7
    7f10:      	b.gt	0x80b8 <_stogir.vector-comparison.validate+0x244>
    7f14:      	lsl	x5, x6, #2
    7f18:      	ldr	x5, [x0, #0x50]
    7f1c:      	add	x5, x5, x6, lsl #2
    7f20:      	ldr	w5, [x5]
    7f24:      	sxtw	x5, w5
    7f28:      	cmp	x5, #0x0
    7f2c:      	cset	w5, gt
    7f30:      	ubfx	x5, x5, #0, #8
    7f34:      	b	0x80bc <_stogir.vector-comparison.validate+0x248>
    7f38:      	movz	x5, #0x0, lsl #48
    7f3c:      	b	0x7f4c <_stogir.vector-comparison.validate+0xd8>
    7f40:      	movz	x5, #0x0, lsl #48
    7f44:      	b	0x7f4c <_stogir.vector-comparison.validate+0xd8>
    7f48:      	movz	x5, #0x0, lsl #48
    7f4c:      	lsl	x7, x1, #4
    7f50:      	cmp	x5, #0x0
    7f54:      	b.eq	0x7fb4 <_stogir.vector-comparison.validate+0x140>
    7f58:      	uxtb	w16, w4
    7f5c:      	cmp	w16, wzr
    7f60:      	b.eq	0x7f84 <_stogir.vector-comparison.validate+0x110>
    7f64:      	ldr	x4, [x0]
    7f68:      	add	x4, x7, x4
    7f6c:      	ldr	x5, [x4]
    7f70:      	ldr	x4, [x4, #0x8]
    7f74:      	fmov	d31, x4
    7f78:      	mov	x4, x5
    7f7c:      	fmov	x5, d31
    7f80:      	b	0x7fa4 <_stogir.vector-comparison.validate+0x130>
    7f84:      	lsl	x4, x6, #4
    7f88:      	ldr	x4, [x0, #0x28]
    7f8c:      	add	x4, x4, x6, lsl #4
    7f90:      	ldr	x5, [x4]
    7f94:      	ldr	x4, [x4, #0x8]
    7f98:      	fmov	d31, x4
    7f9c:      	mov	x4, x5
    7fa0:      	fmov	x5, d31
    7fa4:      	mov	x6, x5
    7fa8:      	mov	x5, x4
    7fac:      	mov	x4, #0x1                ; =1
    7fb0:      	b	0x7fc0 <_stogir.vector-comparison.validate+0x14c>
    7fb4:      	movz	x4, #0x0, lsl #48
    7fb8:      	movz	x5, #0x0, lsl #48
    7fbc:      	movz	x6, #0x0, lsl #48
    7fc0:      	lsr	w4, w4, #0
    7fc4:      	lsr	x16, x4, #0
    7fc8:      	cmp	x16, #0x1
    7fcc:      	b.eq	0x7fe8 <_stogir.vector-comparison.validate+0x174>
    7fd0:      	b.lo	0x7fd8 <_stogir.vector-comparison.validate+0x164>
    7fd4:      	b	0x7fec <_stogir.vector-comparison.validate+0x178>
    7fd8:      	cmp	x16, #0x0
    7fdc:      	b.eq	0x7fe4 <_stogir.vector-comparison.validate+0x170>
    7fe0:      	b	0x7fec <_stogir.vector-comparison.validate+0x178>
    7fe4:      	b	0x7ff0 <_stogir.vector-comparison.validate+0x17c>
    7fe8:      	b	0x802c <_stogir.vector-comparison.validate+0x1b8>
    7fec:      	b	0x81cc <_stogir.vector-comparison.validate+0x358>
    7ff0:      	adrp	x16, 0x7000 <_stogir.floating.validate+0xec>
		0000000000007ff0:  ARM64_RELOC_PAGE21	l_stogir.416
    7ff4:      	ldr	x16, [x16]
		0000000000007ff4:  ARM64_RELOC_PAGEOFF12	l_stogir.416
    7ff8:      	orr	x0, x16, xzr
    7ffc:      	mov	x19, x8
    8000:      	mov	x1, x0
    8004:      	mov	x0, #0x1                ; =1
    8008:      	mov	x2, #0x25               ; =37
    800c:      	str	x0, [x19]
    8010:      	str	x1, [x19, #0x8]
    8014:      	str	x2, [x19, #0x10]
    8018:      	ldr	x19, [sp, #0x40]
    801c:      	ldr	x29, [sp]
    8020:      	ldr	x30, [sp, #0x8]
    8024:      	add	sp, sp, #0x50
    8028:      	ret
    802c:      	add	x16, sp, #0x10
    8030:      	str	x5, [x16]
    8034:      	add	x16, sp, #0x10
    8038:      	str	x6, [x16, #0x8]
    803c:      	cmp	x1, #0x0
    8040:      	b.gt	0x806c <_stogir.vector-comparison.validate+0x1f8>
    8044:      	mov	x19, x8
    8048:      	adrp	x16, 0x8000 <_stogir.vector-comparison.validate+0x18c>
		0000000000008048:  ARM64_RELOC_PAGE21	l_stogir.417
    804c:      	ldr	x16, [x16]
		000000000000804c:  ARM64_RELOC_PAGEOFF12	l_stogir.417
    8050:      	orr	x0, x16, xzr
    8054:      	mov	x1, x0
    8058:      	mov	x0, #0x1                ; =1
    805c:      	mov	x2, #0x2b               ; =43
    8060:      	b	0x800c <_stogir.vector-comparison.validate+0x198>
    8064:      	movz	x5, #0x0, lsl #48
    8068:      	b	0x7f44 <_stogir.vector-comparison.validate+0xd0>
    806c:      	ldr	x4, [x0, #0x8]
    8070:      	cmp	x1, x4
    8074:      	b.ge	0x80c0 <_stogir.vector-comparison.validate+0x24c>
    8078:      	add	x4, x0, #0x78
    807c:      	ldr	x4, [x4, #0x8]
    8080:      	cmp	x1, x4
    8084:      	b.ge	0x80c0 <_stogir.vector-comparison.validate+0x24c>
    8088:      	ldr	x1, [x0, #0x78]
    808c:      	add	x1, x3, x1
    8090:      	ldr	w1, [x1]
    8094:      	sxtw	x1, w1
    8098:      	cmp	x1, #0x0
    809c:      	b.lt	0x80c0 <_stogir.vector-comparison.validate+0x24c>
    80a0:      	ldr	x1, [x0]
    80a4:      	add	x1, x7, x1
    80a8:      	ldr	x1, [x1]
    80ac:      	mov	x4, x1
    80b0:      	mov	x1, #0x1                ; =1
    80b4:      	b	0x80c8 <_stogir.vector-comparison.validate+0x254>
    80b8:      	movz	x5, #0x0, lsl #48
    80bc:      	b	0x7f3c <_stogir.vector-comparison.validate+0xc8>
    80c0:      	movz	x1, #0x0, lsl #48
    80c4:      	movz	x4, #0x0, lsl #48
    80c8:      	lsr	w1, w1, #0
    80cc:      	lsr	x16, x1, #0
    80d0:      	cmp	x16, #0x1
    80d4:      	b.eq	0x80f0 <_stogir.vector-comparison.validate+0x27c>
    80d8:      	b.lo	0x80e0 <_stogir.vector-comparison.validate+0x26c>
    80dc:      	b	0x80f4 <_stogir.vector-comparison.validate+0x280>
    80e0:      	cmp	x16, #0x0
    80e4:      	b.eq	0x80ec <_stogir.vector-comparison.validate+0x278>
    80e8:      	b	0x80f4 <_stogir.vector-comparison.validate+0x280>
    80ec:      	b	0x80f8 <_stogir.vector-comparison.validate+0x284>
    80f0:      	b	0x8100 <_stogir.vector-comparison.validate+0x28c>
    80f4:      	b	0x81d4 <_stogir.vector-comparison.validate+0x360>
    80f8:      	mov	x19, x8
    80fc:      	b	0x8048 <_stogir.vector-comparison.validate+0x1d4>
    8100:      	uxtb	w1, w4
    8104:      	cmp	x1, #0xe
    8108:      	b.lt	0x81dc <_stogir.vector-comparison.validate+0x368>
    810c:      	cmp	x1, #0x19
    8110:      	b.gt	0x81e4 <_stogir.vector-comparison.validate+0x370>
    8114:      	lsr	w4, w4, #0
    8118:      	ubfx	x1, x4, #8, #8
    811c:      	cmp	x1, #0xf
    8120:      	b.le	0x81ec <_stogir.vector-comparison.validate+0x378>
    8124:      	cmp	x1, #0x80
    8128:      	b.ge	0x81f4 <_stogir.vector-comparison.validate+0x380>
    812c:      	and	x1, x1, #0xf
    8130:      	lsr	w1, w1, #0
    8134:      	sxtw	x1, w1
    8138:      	cmp	x1, #0x1
    813c:      	b.lt	0x81fc <_stogir.vector-comparison.validate+0x388>
    8140:      	cmp	x1, #0xd
    8144:      	b.gt	0x8204 <_stogir.vector-comparison.validate+0x390>
    8148:      	ldr	x1, [x0, #0x78]
    814c:      	add	x1, x3, x1
    8150:      	ldr	w1, [x1]
    8154:      	sxtw	x1, w1
    8158:      	cmp	x1, #0x2
    815c:      	b.ne	0x820c <_stogir.vector-comparison.validate+0x398>
    8160:      	lsr	w2, w2, #0
    8164:      	add	x16, sp, #0x10
    8168:      	ldr	w1, [x16]
    816c:      	uxtb	w3, w1
    8170:      	add	x16, sp, #0x10
    8174:      	ldr	w4, [x16, #0x4]
    8178:      	lsr	w3, w3, #0
    817c:      	ubfx	x1, x1, #8, #8
    8180:      	add	x16, sp, #0x10
    8184:      	ldr	w5, [x16, #0x8]
    8188:      	lsr	w4, w4, #0
    818c:      	lsr	w5, w5, #0
    8190:      	lsr	w1, w1, #0
    8194:      	mov	x19, x8
    8198:      	add	x8, sp, #0x20
    819c:      	fmov	s31, w1
    81a0:      	mov	w1, w3
    81a4:      	mov	w3, w2
    81a8:      	fmov	w2, s31
    81ac:      	bl	0x81ac <_stogir.vector-comparison.validate+0x338>
		00000000000081ac:  ARM64_RELOC_BRANCH26	_stogir.vector-comparison.operands
    81b0:      	add	x16, sp, #0x20
    81b4:      	ldr	x0, [x16]
    81b8:      	add	x16, sp, #0x20
    81bc:      	ldr	x1, [x16, #0x8]
    81c0:      	add	x16, sp, #0x20
    81c4:      	ldr	x2, [x16, #0x10]
    81c8:      	b	0x8060 <_stogir.vector-comparison.validate+0x1ec>
    81cc:      	brk	#0
    81d0:      	b	0x81cc <_stogir.vector-comparison.validate+0x358>
    81d4:      	brk	#0
    81d8:      	b	0x81d4 <_stogir.vector-comparison.validate+0x360>
    81dc:      	mov	x19, x8
    81e0:      	b	0x8048 <_stogir.vector-comparison.validate+0x1d4>
    81e4:      	mov	x19, x8
    81e8:      	b	0x8048 <_stogir.vector-comparison.validate+0x1d4>
    81ec:      	mov	x19, x8
    81f0:      	b	0x8048 <_stogir.vector-comparison.validate+0x1d4>
    81f4:      	mov	x19, x8
    81f8:      	b	0x8048 <_stogir.vector-comparison.validate+0x1d4>
    81fc:      	mov	x19, x8
    8200:      	b	0x8048 <_stogir.vector-comparison.validate+0x1d4>
    8204:      	mov	x19, x8
    8208:      	b	0x8048 <_stogir.vector-comparison.validate+0x1d4>
    820c:      	mov	x19, x8
    8210:      	b	0x8048 <_stogir.vector-comparison.validate+0x1d4>

0000000000008214 <_stogir.vector-arithmetic.node?>:
    8214:      	sxtw	x1, w1
    8218:      	cmp	x1, #0x0
    821c:      	cset	w2, gt
    8220:      	movz	x16, #0x0, lsl #48
    8224:      	sub	x3, x16, x1
    8228:      	sub	x4, x3, #0x1
    822c:      	uxtb	w16, w2
    8230:      	cmp	w16, wzr
    8234:      	b.eq	0x8278 <_stogir.vector-arithmetic.node?+0x64>
    8238:      	ldr	x3, [x0, #0x8]
    823c:      	cmp	x1, x3
    8240:      	b.ge	0x82cc <_stogir.vector-arithmetic.node?+0xb8>
    8244:      	add	x3, x0, #0x78
    8248:      	ldr	x3, [x3, #0x8]
    824c:      	cmp	x1, x3
    8250:      	b.ge	0x83fc <_stogir.vector-arithmetic.node?+0x1e8>
    8254:      	lsl	x3, x1, #2
    8258:      	ldr	x3, [x0, #0x78]
    825c:      	add	x3, x3, x1, lsl #2
    8260:      	ldr	w3, [x3]
    8264:      	sxtw	x3, w3
    8268:      	cmp	x3, #0x0
    826c:      	cset	w3, ge
    8270:      	ubfx	x3, x3, #0, #8
    8274:      	b	0x8400 <_stogir.vector-arithmetic.node?+0x1ec>
    8278:      	cmp	x1, #0x0
    827c:      	b.ge	0x82d4 <_stogir.vector-arithmetic.node?+0xc0>
    8280:      	add	x5, x0, #0x28
    8284:      	add	x6, x0, #0x50
    8288:      	ldr	x5, [x5, #0x8]
    828c:      	ldr	x6, [x6, #0x8]
    8290:      	cmp	x5, x6
    8294:      	b.ne	0x82c4 <_stogir.vector-arithmetic.node?+0xb0>
    8298:      	cmp	x3, x5
    829c:      	b.gt	0x840c <_stogir.vector-arithmetic.node?+0x1f8>
    82a0:      	lsl	x3, x4, #2
    82a4:      	ldr	x3, [x0, #0x50]
    82a8:      	add	x3, x3, x4, lsl #2
    82ac:      	ldr	w3, [x3]
    82b0:      	sxtw	x3, w3
    82b4:      	cmp	x3, #0x0
    82b8:      	cset	w3, gt
    82bc:      	ubfx	x3, x3, #0, #8
    82c0:      	b	0x8410 <_stogir.vector-arithmetic.node?+0x1fc>
    82c4:      	movz	x3, #0x0, lsl #48
    82c8:      	b	0x82d8 <_stogir.vector-arithmetic.node?+0xc4>
    82cc:      	movz	x3, #0x0, lsl #48
    82d0:      	b	0x82d8 <_stogir.vector-arithmetic.node?+0xc4>
    82d4:      	movz	x3, #0x0, lsl #48
    82d8:      	cmp	x3, #0x0
    82dc:      	b.eq	0x831c <_stogir.vector-arithmetic.node?+0x108>
    82e0:      	uxtb	w16, w2
    82e4:      	cmp	w16, wzr
    82e8:      	b.eq	0x8300 <_stogir.vector-arithmetic.node?+0xec>
    82ec:      	lsl	x2, x1, #4
    82f0:      	ldr	x0, [x0]
    82f4:      	add	x0, x0, x1, lsl #4
    82f8:      	ldr	x0, [x0]
    82fc:      	b	0x8310 <_stogir.vector-arithmetic.node?+0xfc>
    8300:      	lsl	x1, x4, #4
    8304:      	ldr	x0, [x0, #0x28]
    8308:      	add	x0, x0, x4, lsl #4
    830c:      	ldr	x0, [x0]
    8310:      	mov	x1, x0
    8314:      	mov	x0, #0x1                ; =1
    8318:      	b	0x8324 <_stogir.vector-arithmetic.node?+0x110>
    831c:      	movz	x0, #0x0, lsl #48
    8320:      	movz	x1, #0x0, lsl #48
    8324:      	lsr	w0, w0, #0
    8328:      	lsr	x16, x0, #0
    832c:      	cmp	x16, #0x1
    8330:      	b.eq	0x834c <_stogir.vector-arithmetic.node?+0x138>
    8334:      	b.lo	0x833c <_stogir.vector-arithmetic.node?+0x128>
    8338:      	b	0x8350 <_stogir.vector-arithmetic.node?+0x13c>
    833c:      	cmp	x16, #0x0
    8340:      	b.eq	0x8348 <_stogir.vector-arithmetic.node?+0x134>
    8344:      	b	0x8350 <_stogir.vector-arithmetic.node?+0x13c>
    8348:      	b	0x8354 <_stogir.vector-arithmetic.node?+0x140>
    834c:      	b	0x8364 <_stogir.vector-arithmetic.node?+0x150>
    8350:      	b	0x841c <_stogir.vector-arithmetic.node?+0x208>
    8354:      	movz	x0, #0x0, lsl #48
    8358:      	b	0x8360 <_stogir.vector-arithmetic.node?+0x14c>
    835c:      	movz	x0, #0x0, lsl #48
    8360:      	ret
    8364:      	uxtb	w0, w1
    8368:      	cmp	x0, #0x1f
    836c:      	b.eq	0x83c0 <_stogir.vector-arithmetic.node?+0x1ac>
    8370:      	cmp	x0, #0x20
    8374:      	b.eq	0x83c0 <_stogir.vector-arithmetic.node?+0x1ac>
    8378:      	cmp	x0, #0x2d
    837c:      	b.eq	0x83c0 <_stogir.vector-arithmetic.node?+0x1ac>
    8380:      	cmp	x0, #0x36
    8384:      	b.eq	0x83c0 <_stogir.vector-arithmetic.node?+0x1ac>
    8388:      	cmp	x0, #0x37
    838c:      	b.eq	0x83c0 <_stogir.vector-arithmetic.node?+0x1ac>
    8390:      	cmp	x0, #0x38
    8394:      	b.eq	0x83c0 <_stogir.vector-arithmetic.node?+0x1ac>
    8398:      	cmp	x0, #0x39
    839c:      	b.eq	0x83c0 <_stogir.vector-arithmetic.node?+0x1ac>
    83a0:      	cmp	x0, #0x3a
    83a4:      	b.eq	0x83c0 <_stogir.vector-arithmetic.node?+0x1ac>
    83a8:      	cmp	x0, #0x3b
    83ac:      	b.eq	0x83c0 <_stogir.vector-arithmetic.node?+0x1ac>
    83b0:      	cmp	x0, #0x31
    83b4:      	b.lt	0x8424 <_stogir.vector-arithmetic.node?+0x210>
    83b8:      	cmp	x0, #0x35
    83bc:      	b.gt	0x8424 <_stogir.vector-arithmetic.node?+0x210>
    83c0:      	lsr	w1, w1, #0
    83c4:      	ubfx	x0, x1, #8, #8
    83c8:      	cmp	x0, #0xf
    83cc:      	b.le	0x835c <_stogir.vector-arithmetic.node?+0x148>
    83d0:      	cmp	x0, #0x80
    83d4:      	b.ge	0x8404 <_stogir.vector-arithmetic.node?+0x1f0>
    83d8:      	and	x0, x0, #0xf
    83dc:      	lsr	w0, w0, #0
    83e0:      	sxtw	x0, w0
    83e4:      	cmp	x0, #0x1
    83e8:      	b.lt	0x8414 <_stogir.vector-arithmetic.node?+0x200>
    83ec:      	cmp	x0, #0xd
    83f0:      	cset	w0, le
    83f4:      	ubfx	x0, x0, #0, #8
    83f8:      	b	0x8418 <_stogir.vector-arithmetic.node?+0x204>
    83fc:      	movz	x3, #0x0, lsl #48
    8400:      	b	0x82d0 <_stogir.vector-arithmetic.node?+0xbc>
    8404:      	movz	x0, #0x0, lsl #48
    8408:      	b	0x8360 <_stogir.vector-arithmetic.node?+0x14c>
    840c:      	movz	x3, #0x0, lsl #48
    8410:      	b	0x82c8 <_stogir.vector-arithmetic.node?+0xb4>
    8414:      	movz	x0, #0x0, lsl #48
    8418:      	b	0x8408 <_stogir.vector-arithmetic.node?+0x1f4>
    841c:      	brk	#0
    8420:      	b	0x841c <_stogir.vector-arithmetic.node?+0x208>
    8424:      	cmp	x0, #0x1a
    8428:      	b.eq	0x83c0 <_stogir.vector-arithmetic.node?+0x1ac>
    842c:      	cmp	x0, #0x1b
    8430:      	b.eq	0x83c0 <_stogir.vector-arithmetic.node?+0x1ac>
    8434:      	cmp	x0, #0x1c
    8438:      	b.eq	0x83c0 <_stogir.vector-arithmetic.node?+0x1ac>
    843c:      	cmp	x0, #0x1d
    8440:      	b.eq	0x83c0 <_stogir.vector-arithmetic.node?+0x1ac>
    8444:      	cmp	x0, #0x1e
    8448:      	b.eq	0x83c0 <_stogir.vector-arithmetic.node?+0x1ac>
    844c:      	cmp	x0, #0x2e
    8450:      	b.eq	0x83c0 <_stogir.vector-arithmetic.node?+0x1ac>
    8454:      	cmp	x0, #0x2f
    8458:      	b.eq	0x83c0 <_stogir.vector-arithmetic.node?+0x1ac>
    845c:      	cmp	x0, #0x30
    8460:      	b.eq	0x83c0 <_stogir.vector-arithmetic.node?+0x1ac>
    8464:      	movz	x0, #0x0, lsl #48
    8468:      	b	0x8360 <_stogir.vector-arithmetic.node?+0x14c>

000000000000846c <_stogir.vector-arithmetic.validate>:
    846c:      	sub	sp, sp, #0x60
    8470:      	str	x29, [sp]
    8474:      	str	x30, [sp, #0x8]
    8478:      	mov	x29, sp
    847c:      	str	x19, [sp, #0x40]
    8480:      	str	x20, [sp, #0x48]
    8484:      	str	x21, [sp, #0x50]
    8488:      	str	x22, [sp, #0x58]
    848c:      	sxtw	x2, w1
    8490:      	lsl	x19, x2, #2
    8494:      	cmp	x2, #0x0
    8498:      	cset	w3, gt
    849c:      	movz	x16, #0x0, lsl #48
    84a0:      	sub	x4, x16, x2
    84a4:      	sub	x5, x4, #0x1
    84a8:      	uxtb	w16, w3
    84ac:      	cmp	w16, wzr
    84b0:      	b.eq	0x84f0 <_stogir.vector-arithmetic.validate+0x84>
    84b4:      	ldr	x4, [x0, #0x8]
    84b8:      	cmp	x2, x4
    84bc:      	b.ge	0x8544 <_stogir.vector-arithmetic.validate+0xd8>
    84c0:      	add	x4, x0, #0x78
    84c4:      	ldr	x4, [x4, #0x8]
    84c8:      	cmp	x2, x4
    84cc:      	b.ge	0x8670 <_stogir.vector-arithmetic.validate+0x204>
    84d0:      	ldr	x4, [x0, #0x78]
    84d4:      	add	x4, x19, x4
    84d8:      	ldr	w4, [x4]
    84dc:      	sxtw	x4, w4
    84e0:      	cmp	x4, #0x0
    84e4:      	cset	w4, ge
    84e8:      	ubfx	x4, x4, #0, #8
    84ec:      	b	0x8674 <_stogir.vector-arithmetic.validate+0x208>
    84f0:      	cmp	x2, #0x0
    84f4:      	b.ge	0x854c <_stogir.vector-arithmetic.validate+0xe0>
    84f8:      	add	x6, x0, #0x28
    84fc:      	add	x7, x0, #0x50
    8500:      	ldr	x6, [x6, #0x8]
    8504:      	ldr	x7, [x7, #0x8]
    8508:      	cmp	x6, x7
    850c:      	b.ne	0x853c <_stogir.vector-arithmetic.validate+0xd0>
    8510:      	cmp	x4, x6
    8514:      	b.gt	0x870c <_stogir.vector-arithmetic.validate+0x2a0>
    8518:      	lsl	x4, x5, #2
    851c:      	ldr	x4, [x0, #0x50]
    8520:      	add	x4, x4, x5, lsl #2
    8524:      	ldr	w4, [x4]
    8528:      	sxtw	x4, w4
    852c:      	cmp	x4, #0x0
    8530:      	cset	w4, gt
    8534:      	ubfx	x4, x4, #0, #8
    8538:      	b	0x8710 <_stogir.vector-arithmetic.validate+0x2a4>
    853c:      	movz	x4, #0x0, lsl #48
    8540:      	b	0x8550 <_stogir.vector-arithmetic.validate+0xe4>
    8544:      	movz	x4, #0x0, lsl #48
    8548:      	b	0x8550 <_stogir.vector-arithmetic.validate+0xe4>
    854c:      	movz	x4, #0x0, lsl #48
    8550:      	cmp	x4, #0x0
    8554:      	b.eq	0x85b4 <_stogir.vector-arithmetic.validate+0x148>
    8558:      	uxtb	w16, w3
    855c:      	cmp	w16, wzr
    8560:      	b.eq	0x8588 <_stogir.vector-arithmetic.validate+0x11c>
    8564:      	lsl	x3, x2, #4
    8568:      	ldr	x3, [x0]
    856c:      	add	x3, x3, x2, lsl #4
    8570:      	ldr	x4, [x3]
    8574:      	ldr	x3, [x3, #0x8]
    8578:      	fmov	d31, x3
    857c:      	mov	x3, x4
    8580:      	fmov	x4, d31
    8584:      	b	0x85a8 <_stogir.vector-arithmetic.validate+0x13c>
    8588:      	lsl	x3, x5, #4
    858c:      	ldr	x3, [x0, #0x28]
    8590:      	add	x3, x3, x5, lsl #4
    8594:      	ldr	x4, [x3]
    8598:      	ldr	x3, [x3, #0x8]
    859c:      	fmov	d31, x3
    85a0:      	mov	x3, x4
    85a4:      	fmov	x4, d31
    85a8:      	mov	x20, x3
    85ac:      	mov	x3, #0x1                ; =1
    85b0:      	b	0x85c0 <_stogir.vector-arithmetic.validate+0x154>
    85b4:      	movz	x3, #0x0, lsl #48
    85b8:      	movz	x20, #0x0, lsl #48
    85bc:      	movz	x4, #0x0, lsl #48
    85c0:      	lsr	w3, w3, #0
    85c4:      	lsr	x16, x3, #0
    85c8:      	cmp	x16, #0x1
    85cc:      	b.eq	0x85e8 <_stogir.vector-arithmetic.validate+0x17c>
    85d0:      	b.lo	0x85d8 <_stogir.vector-arithmetic.validate+0x16c>
    85d4:      	b	0x85ec <_stogir.vector-arithmetic.validate+0x180>
    85d8:      	cmp	x16, #0x0
    85dc:      	b.eq	0x85e4 <_stogir.vector-arithmetic.validate+0x178>
    85e0:      	b	0x85ec <_stogir.vector-arithmetic.validate+0x180>
    85e4:      	b	0x85f0 <_stogir.vector-arithmetic.validate+0x184>
    85e8:      	b	0x8610 <_stogir.vector-arithmetic.validate+0x1a4>
    85ec:      	b	0x87c0 <_stogir.vector-arithmetic.validate+0x354>
    85f0:      	adrp	x16, 0x8000 <_stogir.vector-comparison.validate+0x18c>
		00000000000085f0:  ARM64_RELOC_PAGE21	l_stogir.418
    85f4:      	ldr	x16, [x16]
		00000000000085f4:  ARM64_RELOC_PAGEOFF12	l_stogir.418
    85f8:      	orr	x0, x16, xzr
    85fc:      	mov	x21, x8
    8600:      	mov	x1, x0
    8604:      	mov	x0, #0x1                ; =1
    8608:      	mov	x2, #0x25               ; =37
    860c:      	b	0x8644 <_stogir.vector-arithmetic.validate+0x1d8>
    8610:      	add	x16, sp, #0x10
    8614:      	str	x20, [x16]
    8618:      	add	x16, sp, #0x10
    861c:      	str	x4, [x16, #0x8]
    8620:      	cmp	x2, #0x0
    8624:      	b.gt	0x8678 <_stogir.vector-arithmetic.validate+0x20c>
    8628:      	mov	x21, x8
    862c:      	adrp	x16, 0x8000 <_stogir.vector-comparison.validate+0x18c>
		000000000000862c:  ARM64_RELOC_PAGE21	l_stogir.419
    8630:      	ldr	x16, [x16]
		0000000000008630:  ARM64_RELOC_PAGEOFF12	l_stogir.419
    8634:      	orr	x0, x16, xzr
    8638:      	mov	x1, x0
    863c:      	mov	x0, #0x1                ; =1
    8640:      	mov	x2, #0x2b               ; =43
    8644:      	str	x0, [x21]
    8648:      	str	x1, [x21, #0x8]
    864c:      	str	x2, [x21, #0x10]
    8650:      	ldr	x19, [sp, #0x40]
    8654:      	ldr	x20, [sp, #0x48]
    8658:      	ldr	x21, [sp, #0x50]
    865c:      	ldr	x22, [sp, #0x58]
    8660:      	ldr	x29, [sp]
    8664:      	ldr	x30, [sp, #0x8]
    8668:      	add	sp, sp, #0x60
    866c:      	ret
    8670:      	movz	x4, #0x0, lsl #48
    8674:      	b	0x8548 <_stogir.vector-arithmetic.validate+0xdc>
    8678:      	lsr	w1, w1, #0
    867c:      	mov	x21, x8
    8680:      	mov	x22, x0
    8684:      	bl	0x8684 <_stogir.vector-arithmetic.validate+0x218>
		0000000000008684:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.node?
    8688:      	cmp	x0, #0x0
    868c:      	b.eq	0x862c <_stogir.vector-arithmetic.validate+0x1c0>
    8690:      	uxtb	w20, w20
    8694:      	orr	x0, x20, xzr
    8698:      	ldr	x1, [x22, #0x78]
    869c:      	cmp	x0, #0x1d
    86a0:      	cset	w2, eq
    86a4:      	cmp	x0, #0x1e
    86a8:      	cset	w3, eq
    86ac:      	add	x1, x19, x1
    86b0:      	ldr	w1, [x1]
    86b4:      	cmp	x0, #0x1f
    86b8:      	b.eq	0x8770 <_stogir.vector-arithmetic.validate+0x304>
    86bc:      	cmp	x0, #0x20
    86c0:      	b.eq	0x8770 <_stogir.vector-arithmetic.validate+0x304>
    86c4:      	cmp	x0, #0x2d
    86c8:      	b.eq	0x8770 <_stogir.vector-arithmetic.validate+0x304>
    86cc:      	cmp	x0, #0x36
    86d0:      	b.eq	0x8770 <_stogir.vector-arithmetic.validate+0x304>
    86d4:      	cmp	x0, #0x37
    86d8:      	b.eq	0x8770 <_stogir.vector-arithmetic.validate+0x304>
    86dc:      	cmp	x0, #0x38
    86e0:      	b.eq	0x8770 <_stogir.vector-arithmetic.validate+0x304>
    86e4:      	cmp	x0, #0x39
    86e8:      	b.eq	0x8770 <_stogir.vector-arithmetic.validate+0x304>
    86ec:      	uxtb	w16, w2
    86f0:      	cmp	w16, wzr
    86f4:      	b.ne	0x87c8 <_stogir.vector-arithmetic.validate+0x35c>
    86f8:      	uxtb	w16, w3
    86fc:      	cmp	w16, wzr
    8700:      	b.ne	0x87c8 <_stogir.vector-arithmetic.validate+0x35c>
    8704:      	mov	x0, #0x2                ; =2
    8708:      	b	0x87cc <_stogir.vector-arithmetic.validate+0x360>
    870c:      	movz	x4, #0x0, lsl #48
    8710:      	b	0x8540 <_stogir.vector-arithmetic.validate+0xd4>
    8714:      	add	x16, sp, #0x10
    8718:      	ldr	w2, [x16, #0xc]
    871c:      	sxtw	x2, w2
    8720:      	lsr	w1, w1, #0
    8724:      	lsr	w4, w4, #0
    8728:      	lsr	w20, w20, #0
    872c:      	lsr	w2, w2, #0
    8730:      	ubfx	x0, x0, #8, #8
    8734:      	lsr	w0, w0, #0
    8738:      	add	x8, sp, #0x20
    873c:      	mov	w3, w1
    8740:      	mov	w1, w20
    8744:      	mov	w5, w2
    8748:      	mov	w2, w0
    874c:      	mov	x0, x22
    8750:      	bl	0x8750 <_stogir.vector-arithmetic.validate+0x2e4>
		0000000000008750:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.operands
    8754:      	add	x16, sp, #0x20
    8758:      	ldr	x0, [x16]
    875c:      	add	x16, sp, #0x20
    8760:      	ldr	x1, [x16, #0x8]
    8764:      	add	x16, sp, #0x20
    8768:      	ldr	x2, [x16, #0x10]
    876c:      	b	0x8644 <_stogir.vector-arithmetic.validate+0x1d8>
    8770:      	mov	x0, #0x1                ; =1
    8774:      	sxtw	x1, w1
    8778:      	lsr	w0, w0, #0
    877c:      	sxtw	x0, w0
    8780:      	cmp	x1, x0
    8784:      	b.ne	0x862c <_stogir.vector-arithmetic.validate+0x1c0>
    8788:      	add	x16, sp, #0x10
    878c:      	ldr	w0, [x16]
    8790:      	add	x16, sp, #0x10
    8794:      	ldr	w1, [x16, #0x4]
    8798:      	add	x16, sp, #0x10
    879c:      	ldr	w4, [x16, #0x8]
    87a0:      	uxtb	w16, w2
    87a4:      	cmp	w16, wzr
    87a8:      	b.ne	0x8714 <_stogir.vector-arithmetic.validate+0x2a8>
    87ac:      	uxtb	w16, w3
    87b0:      	cmp	w16, wzr
    87b4:      	b.ne	0x8714 <_stogir.vector-arithmetic.validate+0x2a8>
    87b8:      	movz	x2, #0x0, lsl #48
    87bc:      	b	0x8720 <_stogir.vector-arithmetic.validate+0x2b4>
    87c0:      	brk	#0
    87c4:      	b	0x87c0 <_stogir.vector-arithmetic.validate+0x354>
    87c8:      	mov	x0, #0x3                ; =3
    87cc:      	b	0x8774 <_stogir.vector-arithmetic.validate+0x308>

00000000000087d0 <_stogir.vector.memory-inputs>:
    87d0:      	sub	sp, sp, #0x40
    87d4:      	str	x29, [sp]
    87d8:      	str	x30, [sp, #0x8]
    87dc:      	mov	x29, sp
    87e0:      	str	x19, [sp, #0x10]
    87e4:      	str	x20, [sp, #0x18]
    87e8:      	str	x21, [sp, #0x20]
    87ec:      	str	x22, [sp, #0x28]
    87f0:      	str	x23, [sp, #0x30]
    87f4:      	str	x24, [sp, #0x38]
    87f8:      	sxtw	x5, w1
    87fc:      	cmp	x5, #0xf
    8800:      	b.le	0x8cd0 <_stogir.vector.memory-inputs+0x500>
    8804:      	cmp	x5, #0x80
    8808:      	b.ge	0x8cd8 <_stogir.vector.memory-inputs+0x508>
    880c:      	and	x6, x5, #0xf
    8810:      	lsr	w6, w6, #0
    8814:      	sxtw	x6, w6
    8818:      	cmp	x6, #0x1
    881c:      	b.lt	0x8ce0 <_stogir.vector.memory-inputs+0x510>
    8820:      	and	x5, x5, #0xf
    8824:      	lsr	w5, w5, #0
    8828:      	sxtw	x5, w5
    882c:      	cmp	x5, #0xd
    8830:      	b.gt	0x8ce8 <_stogir.vector.memory-inputs+0x518>
    8834:      	lsr	w1, w1, #0
    8838:      	lsr	w2, w2, #0
    883c:      	mov	x19, x8
    8840:      	mov	x20, x0
    8844:      	mov	w0, w1
    8848:      	mov	w21, w1
    884c:      	mov	w1, w2
    8850:      	mov	w22, w2
    8854:      	mov	w23, w3
    8858:      	mov	w24, w4
    885c:      	bl	0x885c <_stogir.vector.memory-inputs+0x8c>
		000000000000885c:  ARM64_RELOC_BRANCH26	_stogir.types.size
    8860:      	lsr	w0, w0, #0
    8864:      	sxtw	x0, w0
    8868:      	cmp	x0, #0x0
    886c:      	b.le	0x88d4 <_stogir.vector.memory-inputs+0x104>
    8870:      	sxtw	x23, w23
    8874:      	cmp	x23, #0x0
    8878:      	cset	w0, gt
    887c:      	movz	x16, #0x0, lsl #48
    8880:      	sub	x1, x16, x23
    8884:      	sub	x2, x1, #0x1
    8888:      	uxtb	w16, w0
    888c:      	cmp	w16, wzr
    8890:      	b.eq	0x89c4 <_stogir.vector.memory-inputs+0x1f4>
    8894:      	ldr	x1, [x20, #0x8]
    8898:      	cmp	x23, x1
    889c:      	b.ge	0x89bc <_stogir.vector.memory-inputs+0x1ec>
    88a0:      	add	x1, x20, #0x78
    88a4:      	ldr	x1, [x1, #0x8]
    88a8:      	cmp	x23, x1
    88ac:      	b.ge	0x8a6c <_stogir.vector.memory-inputs+0x29c>
    88b0:      	lsl	x1, x23, #2
    88b4:      	ldr	x1, [x20, #0x78]
    88b8:      	add	x1, x1, x23, lsl #2
    88bc:      	ldr	w1, [x1]
    88c0:      	sxtw	x1, w1
    88c4:      	cmp	x1, #0x0
    88c8:      	cset	w1, ge
    88cc:      	ubfx	x1, x1, #0, #8
    88d0:      	b	0x8a70 <_stogir.vector.memory-inputs+0x2a0>
    88d4:      	adrp	x16, 0x8000 <_stogir.vector-comparison.validate+0x18c>
		00000000000088d4:  ARM64_RELOC_PAGE21	l_stogir.420
    88d8:      	ldr	x16, [x16]
		00000000000088d8:  ARM64_RELOC_PAGEOFF12	l_stogir.420
    88dc:      	orr	x0, x16, xzr
    88e0:      	mov	x1, x0
    88e4:      	mov	x0, #0x1                ; =1
    88e8:      	mov	x2, #0x32               ; =50
    88ec:      	str	x0, [x19]
    88f0:      	str	x1, [x19, #0x8]
    88f4:      	str	x2, [x19, #0x10]
    88f8:      	ldr	x19, [sp, #0x10]
    88fc:      	ldr	x20, [sp, #0x18]
    8900:      	ldr	x21, [sp, #0x20]
    8904:      	ldr	x22, [sp, #0x28]
    8908:      	ldr	x23, [sp, #0x30]
    890c:      	ldr	x24, [sp, #0x38]
    8910:      	ldr	x29, [sp]
    8914:      	ldr	x30, [sp, #0x8]
    8918:      	add	sp, sp, #0x40
    891c:      	ret
    8920:      	movz	x0, #0x0, lsl #48
    8924:      	movz	x1, #0x0, lsl #48
    8928:      	lsr	w0, w0, #0
    892c:      	lsr	x16, x0, #0
    8930:      	cmp	x16, #0x1
    8934:      	b.eq	0x8950 <_stogir.vector.memory-inputs+0x180>
    8938:      	b.lo	0x8940 <_stogir.vector.memory-inputs+0x170>
    893c:      	b	0x8954 <_stogir.vector.memory-inputs+0x184>
    8940:      	cmp	x16, #0x0
    8944:      	b.eq	0x894c <_stogir.vector.memory-inputs+0x17c>
    8948:      	b	0x8954 <_stogir.vector.memory-inputs+0x184>
    894c:      	b	0x8958 <_stogir.vector.memory-inputs+0x188>
    8950:      	b	0x8a10 <_stogir.vector.memory-inputs+0x240>
    8954:      	b	0x8cb8 <_stogir.vector.memory-inputs+0x4e8>
    8958:      	adrp	x16, 0x8000 <_stogir.vector-comparison.validate+0x18c>
		0000000000008958:  ARM64_RELOC_PAGE21	l_stogir.421
    895c:      	ldr	x16, [x16]
		000000000000895c:  ARM64_RELOC_PAGEOFF12	l_stogir.421
    8960:      	orr	x0, x16, xzr
    8964:      	mov	x1, x0
    8968:      	mov	x0, #0x1                ; =1
    896c:      	mov	x2, #0x1d               ; =29
    8970:      	b	0x88ec <_stogir.vector.memory-inputs+0x11c>
    8974:      	lsl	x0, x2, #4
    8978:      	ldr	x0, [x20, #0x28]
    897c:      	add	x0, x0, x2, lsl #4
    8980:      	ldr	x0, [x0]
    8984:      	mov	x1, x0
    8988:      	mov	x0, #0x1                ; =1
    898c:      	b	0x8928 <_stogir.vector.memory-inputs+0x158>
    8990:      	movz	x1, #0x0, lsl #48
    8994:      	cmp	x1, #0x0
    8998:      	b.eq	0x8920 <_stogir.vector.memory-inputs+0x150>
    899c:      	uxtb	w16, w0
    89a0:      	cmp	w16, wzr
    89a4:      	b.eq	0x8974 <_stogir.vector.memory-inputs+0x1a4>
    89a8:      	lsl	x0, x23, #4
    89ac:      	ldr	x0, [x20]
    89b0:      	add	x0, x0, x23, lsl #4
    89b4:      	ldr	x0, [x0]
    89b8:      	b	0x8984 <_stogir.vector.memory-inputs+0x1b4>
    89bc:      	movz	x1, #0x0, lsl #48
    89c0:      	b	0x8994 <_stogir.vector.memory-inputs+0x1c4>
    89c4:      	cmp	x23, #0x0
    89c8:      	b.ge	0x8990 <_stogir.vector.memory-inputs+0x1c0>
    89cc:      	add	x3, x20, #0x28
    89d0:      	add	x4, x20, #0x50
    89d4:      	ldr	x3, [x3, #0x8]
    89d8:      	ldr	x4, [x4, #0x8]
    89dc:      	cmp	x3, x4
    89e0:      	b.ne	0x8a64 <_stogir.vector.memory-inputs+0x294>
    89e4:      	cmp	x1, x3
    89e8:      	b.gt	0x8a74 <_stogir.vector.memory-inputs+0x2a4>
    89ec:      	lsl	x1, x2, #2
    89f0:      	ldr	x1, [x20, #0x50]
    89f4:      	add	x1, x1, x2, lsl #2
    89f8:      	ldr	w1, [x1]
    89fc:      	sxtw	x1, w1
    8a00:      	cmp	x1, #0x0
    8a04:      	cset	w1, gt
    8a08:      	ubfx	x1, x1, #0, #8
    8a0c:      	b	0x8a78 <_stogir.vector.memory-inputs+0x2a8>
    8a10:      	cmp	x23, #0x0
    8a14:      	b.le	0x8a48 <_stogir.vector.memory-inputs+0x278>
    8a18:      	uxtb	w1, w1
    8a1c:      	cmp	x1, #0x83
    8a20:      	cset	w0, lt
    8a24:      	uxtb	w16, w0
    8a28:      	cmp	w16, wzr
    8a2c:      	b.eq	0x8a7c <_stogir.vector.memory-inputs+0x2ac>
    8a30:      	adrp	x16, 0x8000 <_stogir.vector-comparison.validate+0x18c>
		0000000000008a30:  ARM64_RELOC_PAGE21	l_stogir.422
    8a34:      	ldr	x16, [x16]
		0000000000008a34:  ARM64_RELOC_PAGEOFF12	l_stogir.422
    8a38:      	orr	x2, x16, xzr
    8a3c:      	add	x2, x1, x2
    8a40:      	ldrb	w2, [x2]
    8a44:      	b	0x8a80 <_stogir.vector.memory-inputs+0x2b0>
    8a48:      	adrp	x16, 0x8000 <_stogir.vector-comparison.validate+0x18c>
		0000000000008a48:  ARM64_RELOC_PAGE21	l_stogir.423
    8a4c:      	ldr	x16, [x16]
		0000000000008a4c:  ARM64_RELOC_PAGEOFF12	l_stogir.423
    8a50:      	orr	x0, x16, xzr
    8a54:      	mov	x1, x0
    8a58:      	mov	x0, #0x1                ; =1
    8a5c:      	mov	x2, #0x2c               ; =44
    8a60:      	b	0x8970 <_stogir.vector.memory-inputs+0x1a0>
    8a64:      	movz	x1, #0x0, lsl #48
    8a68:      	b	0x8994 <_stogir.vector.memory-inputs+0x1c4>
    8a6c:      	movz	x1, #0x0, lsl #48
    8a70:      	b	0x89c0 <_stogir.vector.memory-inputs+0x1f0>
    8a74:      	movz	x1, #0x0, lsl #48
    8a78:      	b	0x8a68 <_stogir.vector.memory-inputs+0x298>
    8a7c:      	movz	x2, #0x0, lsl #48
    8a80:      	uxtb	w2, w2
    8a84:      	and	x2, x2, #0x1
    8a88:      	uxtb	w2, w2
    8a8c:      	cmp	x2, #0x0
    8a90:      	b.eq	0x8a48 <_stogir.vector.memory-inputs+0x278>
    8a94:      	uxtb	w16, w0
    8a98:      	cmp	w16, wzr
    8a9c:      	b.eq	0x8ab8 <_stogir.vector.memory-inputs+0x2e8>
    8aa0:      	adrp	x16, 0x8000 <_stogir.vector-comparison.validate+0x18c>
		0000000000008aa0:  ARM64_RELOC_PAGE21	l_stogir.422
    8aa4:      	ldr	x16, [x16]
		0000000000008aa4:  ARM64_RELOC_PAGEOFF12	l_stogir.422
    8aa8:      	orr	x0, x16, xzr
    8aac:      	add	x0, x1, x0
    8ab0:      	ldrb	w0, [x0]
    8ab4:      	b	0x8abc <_stogir.vector.memory-inputs+0x2ec>
    8ab8:      	movz	x0, #0x0, lsl #48
    8abc:      	uxtb	w0, w0
    8ac0:      	and	x0, x0, #0x4
    8ac4:      	uxtb	w0, w0
    8ac8:      	cmp	x0, #0x0
    8acc:      	cset	w0, eq
    8ad0:      	uxtb	w16, w0
    8ad4:      	cmp	w16, wzr
    8ad8:      	cset	x0, eq
    8adc:      	cmp	x0, #0x0
    8ae0:      	b.ne	0x8a48 <_stogir.vector.memory-inputs+0x278>
    8ae4:      	sxtw	x24, w24
    8ae8:      	cmp	x24, #0x0
    8aec:      	cset	w0, gt
    8af0:      	movz	x16, #0x0, lsl #48
    8af4:      	sub	x1, x16, x24
    8af8:      	sub	x2, x1, #0x1
    8afc:      	uxtb	w16, w0
    8b00:      	cmp	w16, wzr
    8b04:      	b.eq	0x8b64 <_stogir.vector.memory-inputs+0x394>
    8b08:      	ldr	x1, [x20, #0x8]
    8b0c:      	cmp	x24, x1
    8b10:      	b.ge	0x8bb0 <_stogir.vector.memory-inputs+0x3e0>
    8b14:      	add	x1, x20, #0x78
    8b18:      	ldr	x1, [x1, #0x8]
    8b1c:      	cmp	x24, x1
    8b20:      	b.ge	0x8cb0 <_stogir.vector.memory-inputs+0x4e0>
    8b24:      	lsl	x1, x24, #2
    8b28:      	ldr	x1, [x20, #0x78]
    8b2c:      	add	x1, x1, x24, lsl #2
    8b30:      	ldr	w1, [x1]
    8b34:      	sxtw	x1, w1
    8b38:      	cmp	x1, #0x0
    8b3c:      	cset	w1, ge
    8b40:      	ubfx	x1, x1, #0, #8
    8b44:      	b	0x8cb4 <_stogir.vector.memory-inputs+0x4e4>
    8b48:      	adrp	x16, 0x8000 <_stogir.vector-comparison.validate+0x18c>
		0000000000008b48:  ARM64_RELOC_PAGE21	l_stogir.424
    8b4c:      	ldr	x16, [x16]
		0000000000008b4c:  ARM64_RELOC_PAGEOFF12	l_stogir.424
    8b50:      	orr	x0, x16, xzr
    8b54:      	mov	x1, x0
    8b58:      	mov	x0, #0x1                ; =1
    8b5c:      	mov	x2, #0x2b               ; =43
    8b60:      	b	0x8a60 <_stogir.vector.memory-inputs+0x290>
    8b64:      	cmp	x24, #0x0
    8b68:      	b.ge	0x8bb8 <_stogir.vector.memory-inputs+0x3e8>
    8b6c:      	add	x3, x20, #0x28
    8b70:      	add	x4, x20, #0x50
    8b74:      	ldr	x3, [x3, #0x8]
    8b78:      	ldr	x4, [x4, #0x8]
    8b7c:      	cmp	x3, x4
    8b80:      	b.ne	0x8ca8 <_stogir.vector.memory-inputs+0x4d8>
    8b84:      	cmp	x1, x3
    8b88:      	b.gt	0x8cc0 <_stogir.vector.memory-inputs+0x4f0>
    8b8c:      	lsl	x1, x2, #2
    8b90:      	ldr	x1, [x20, #0x50]
    8b94:      	add	x1, x1, x2, lsl #2
    8b98:      	ldr	w1, [x1]
    8b9c:      	sxtw	x1, w1
    8ba0:      	cmp	x1, #0x0
    8ba4:      	cset	w1, gt
    8ba8:      	ubfx	x1, x1, #0, #8
    8bac:      	b	0x8cc4 <_stogir.vector.memory-inputs+0x4f4>
    8bb0:      	movz	x1, #0x0, lsl #48
    8bb4:      	b	0x8bbc <_stogir.vector.memory-inputs+0x3ec>
    8bb8:      	movz	x1, #0x0, lsl #48
    8bbc:      	cmp	x1, #0x0
    8bc0:      	b.eq	0x8c00 <_stogir.vector.memory-inputs+0x430>
    8bc4:      	uxtb	w16, w0
    8bc8:      	cmp	w16, wzr
    8bcc:      	b.eq	0x8be4 <_stogir.vector.memory-inputs+0x414>
    8bd0:      	lsl	x0, x24, #4
    8bd4:      	ldr	x0, [x20]
    8bd8:      	add	x0, x0, x24, lsl #4
    8bdc:      	ldr	x0, [x0]
    8be0:      	b	0x8bf4 <_stogir.vector.memory-inputs+0x424>
    8be4:      	lsl	x0, x2, #4
    8be8:      	ldr	x0, [x20, #0x28]
    8bec:      	add	x0, x0, x2, lsl #4
    8bf0:      	ldr	x0, [x0]
    8bf4:      	mov	x1, x0
    8bf8:      	mov	x0, #0x1                ; =1
    8bfc:      	b	0x8c08 <_stogir.vector.memory-inputs+0x438>
    8c00:      	movz	x0, #0x0, lsl #48
    8c04:      	movz	x1, #0x0, lsl #48
    8c08:      	lsr	w0, w0, #0
    8c0c:      	lsr	x16, x0, #0
    8c10:      	cmp	x16, #0x1
    8c14:      	b.eq	0x8c30 <_stogir.vector.memory-inputs+0x460>
    8c18:      	b.lo	0x8c20 <_stogir.vector.memory-inputs+0x450>
    8c1c:      	b	0x8c34 <_stogir.vector.memory-inputs+0x464>
    8c20:      	cmp	x16, #0x0
    8c24:      	b.eq	0x8c2c <_stogir.vector.memory-inputs+0x45c>
    8c28:      	b	0x8c34 <_stogir.vector.memory-inputs+0x464>
    8c2c:      	b	0x8c38 <_stogir.vector.memory-inputs+0x468>
    8c30:      	b	0x8c54 <_stogir.vector.memory-inputs+0x484>
    8c34:      	b	0x8cc8 <_stogir.vector.memory-inputs+0x4f8>
    8c38:      	adrp	x16, 0x8000 <_stogir.vector-comparison.validate+0x18c>
		0000000000008c38:  ARM64_RELOC_PAGE21	l_stogir.425
    8c3c:      	ldr	x16, [x16]
		0000000000008c3c:  ARM64_RELOC_PAGEOFF12	l_stogir.425
    8c40:      	orr	x0, x16, xzr
    8c44:      	mov	x1, x0
    8c48:      	mov	x0, #0x1                ; =1
    8c4c:      	mov	x2, #0x1d               ; =29
    8c50:      	b	0x8b60 <_stogir.vector.memory-inputs+0x390>
    8c54:      	lsr	w0, w1, #0
    8c58:      	ubfx	x0, x0, #8, #8
    8c5c:      	cmp	x0, #0x6
    8c60:      	b.ne	0x8b48 <_stogir.vector.memory-inputs+0x378>
    8c64:      	uxtb	w1, w1
    8c68:      	cmp	x1, #0x48
    8c6c:      	b.eq	0x8b48 <_stogir.vector.memory-inputs+0x378>
    8c70:      	cmp	x1, #0x46
    8c74:      	b.eq	0x8b48 <_stogir.vector.memory-inputs+0x378>
    8c78:      	lsr	w21, w21, #0
    8c7c:      	lsr	w22, w22, #0
    8c80:      	mov	w0, w21
    8c84:      	mov	w1, w22
    8c88:      	bl	0x8c88 <_stogir.vector.memory-inputs+0x4b8>
		0000000000008c88:  ARM64_RELOC_BRANCH26	_stogir.types.size
    8c8c:      	lsr	w0, w0, #0
    8c90:      	sxtw	x0, w0
    8c94:      	and	x0, x0, #0xffffffff
    8c98:      	mov	x1, x0
    8c9c:      	movz	x0, #0x0, lsl #48
    8ca0:      	movz	x2, #0x0, lsl #48
    8ca4:      	b	0x8b60 <_stogir.vector.memory-inputs+0x390>
    8ca8:      	movz	x1, #0x0, lsl #48
    8cac:      	b	0x8bbc <_stogir.vector.memory-inputs+0x3ec>
    8cb0:      	movz	x1, #0x0, lsl #48
    8cb4:      	b	0x8bb4 <_stogir.vector.memory-inputs+0x3e4>
    8cb8:      	brk	#0
    8cbc:      	b	0x8cb8 <_stogir.vector.memory-inputs+0x4e8>
    8cc0:      	movz	x1, #0x0, lsl #48
    8cc4:      	b	0x8cac <_stogir.vector.memory-inputs+0x4dc>
    8cc8:      	brk	#0
    8ccc:      	b	0x8cc8 <_stogir.vector.memory-inputs+0x4f8>
    8cd0:      	mov	x19, x8
    8cd4:      	b	0x88d4 <_stogir.vector.memory-inputs+0x104>
    8cd8:      	mov	x19, x8
    8cdc:      	b	0x88d4 <_stogir.vector.memory-inputs+0x104>
    8ce0:      	mov	x19, x8
    8ce4:      	b	0x88d4 <_stogir.vector.memory-inputs+0x104>
    8ce8:      	mov	x19, x8
    8cec:      	b	0x88d4 <_stogir.vector.memory-inputs+0x104>

0000000000008cf0 <_stogir.vector.store-inputs>:
    8cf0:      	sub	sp, sp, #0x40
    8cf4:      	str	x29, [sp]
    8cf8:      	str	x30, [sp, #0x8]
    8cfc:      	mov	x29, sp
    8d00:      	str	x19, [sp, #0x30]
    8d04:      	sxtw	x4, w4
    8d08:      	cmp	x4, #0x0
    8d0c:      	cset	w5, gt
    8d10:      	movz	x16, #0x0, lsl #48
    8d14:      	sub	x6, x16, x4
    8d18:      	sub	x7, x6, #0x1
    8d1c:      	uxtb	w16, w5
    8d20:      	cmp	w16, wzr
    8d24:      	b.eq	0x8d68 <_stogir.vector.store-inputs+0x78>
    8d28:      	ldr	x6, [x0, #0x8]
    8d2c:      	cmp	x4, x6
    8d30:      	b.ge	0x8dbc <_stogir.vector.store-inputs+0xcc>
    8d34:      	add	x6, x0, #0x78
    8d38:      	ldr	x6, [x6, #0x8]
    8d3c:      	cmp	x4, x6
    8d40:      	b.ge	0x8ed4 <_stogir.vector.store-inputs+0x1e4>
    8d44:      	lsl	x6, x4, #2
    8d48:      	ldr	x6, [x0, #0x78]
    8d4c:      	add	x6, x6, x4, lsl #2
    8d50:      	ldr	w6, [x6]
    8d54:      	sxtw	x6, w6
    8d58:      	cmp	x6, #0x0
    8d5c:      	cset	w6, ge
    8d60:      	ubfx	x6, x6, #0, #8
    8d64:      	b	0x8ed8 <_stogir.vector.store-inputs+0x1e8>
    8d68:      	cmp	x4, #0x0
    8d6c:      	b.ge	0x8dc4 <_stogir.vector.store-inputs+0xd4>
    8d70:      	add	x9, x0, #0x28
    8d74:      	add	x10, x0, #0x50
    8d78:      	ldr	x9, [x9, #0x8]
    8d7c:      	ldr	x10, [x10, #0x8]
    8d80:      	cmp	x9, x10
    8d84:      	b.ne	0x8db4 <_stogir.vector.store-inputs+0xc4>
    8d88:      	cmp	x6, x9
    8d8c:      	b.gt	0x8edc <_stogir.vector.store-inputs+0x1ec>
    8d90:      	lsl	x6, x7, #2
    8d94:      	ldr	x6, [x0, #0x50]
    8d98:      	add	x6, x6, x7, lsl #2
    8d9c:      	ldr	w6, [x6]
    8da0:      	sxtw	x6, w6
    8da4:      	cmp	x6, #0x0
    8da8:      	cset	w6, gt
    8dac:      	ubfx	x6, x6, #0, #8
    8db0:      	b	0x8ee0 <_stogir.vector.store-inputs+0x1f0>
    8db4:      	movz	x6, #0x0, lsl #48
    8db8:      	b	0x8dc8 <_stogir.vector.store-inputs+0xd8>
    8dbc:      	movz	x6, #0x0, lsl #48
    8dc0:      	b	0x8dc8 <_stogir.vector.store-inputs+0xd8>
    8dc4:      	movz	x6, #0x0, lsl #48
    8dc8:      	cmp	x6, #0x0
    8dcc:      	b.eq	0x8e0c <_stogir.vector.store-inputs+0x11c>
    8dd0:      	uxtb	w16, w5
    8dd4:      	cmp	w16, wzr
    8dd8:      	b.eq	0x8df0 <_stogir.vector.store-inputs+0x100>
    8ddc:      	lsl	x5, x4, #4
    8de0:      	ldr	x5, [x0]
    8de4:      	add	x4, x5, x4, lsl #4
    8de8:      	ldr	x4, [x4]
    8dec:      	b	0x8e00 <_stogir.vector.store-inputs+0x110>
    8df0:      	lsl	x4, x7, #4
    8df4:      	ldr	x4, [x0, #0x28]
    8df8:      	add	x4, x4, x7, lsl #4
    8dfc:      	ldr	x4, [x4]
    8e00:      	mov	x5, x4
    8e04:      	mov	x4, #0x1                ; =1
    8e08:      	b	0x8e14 <_stogir.vector.store-inputs+0x124>
    8e0c:      	movz	x4, #0x0, lsl #48
    8e10:      	movz	x5, #0x0, lsl #48
    8e14:      	lsr	w4, w4, #0
    8e18:      	lsr	x16, x4, #0
    8e1c:      	cmp	x16, #0x1
    8e20:      	b.eq	0x8e3c <_stogir.vector.store-inputs+0x14c>
    8e24:      	b.lo	0x8e2c <_stogir.vector.store-inputs+0x13c>
    8e28:      	b	0x8e40 <_stogir.vector.store-inputs+0x150>
    8e2c:      	cmp	x16, #0x0
    8e30:      	b.eq	0x8e38 <_stogir.vector.store-inputs+0x148>
    8e34:      	b	0x8e40 <_stogir.vector.store-inputs+0x150>
    8e38:      	b	0x8e44 <_stogir.vector.store-inputs+0x154>
    8e3c:      	b	0x8e64 <_stogir.vector.store-inputs+0x174>
    8e40:      	b	0x8ee4 <_stogir.vector.store-inputs+0x1f4>
    8e44:      	adrp	x16, 0x8000 <_stogir.vector-comparison.validate+0x18c>
		0000000000008e44:  ARM64_RELOC_PAGE21	l_stogir.426
    8e48:      	ldr	x16, [x16]
		0000000000008e48:  ARM64_RELOC_PAGEOFF12	l_stogir.426
    8e4c:      	orr	x0, x16, xzr
    8e50:      	mov	x19, x8
    8e54:      	mov	x1, x0
    8e58:      	mov	x0, #0x1                ; =1
    8e5c:      	mov	x2, #0x1a               ; =26
    8e60:      	b	0x8eb4 <_stogir.vector.store-inputs+0x1c4>
    8e64:      	lsr	w1, w1, #0
    8e68:      	lsr	w2, w2, #0
    8e6c:      	lsr	w3, w3, #0
    8e70:      	lsr	w5, w5, #0
    8e74:      	ubfx	x4, x5, #8, #8
    8e78:      	lsr	w4, w4, #0
    8e7c:      	mov	x19, x8
    8e80:      	add	x8, sp, #0x10
    8e84:      	fmov	s31, w1
    8e88:      	mov	w1, w4
    8e8c:      	mov	w4, w3
    8e90:      	mov	w3, w2
    8e94:      	fmov	w2, s31
    8e98:      	bl	0x8e98 <_stogir.vector.store-inputs+0x1a8>
		0000000000008e98:  ARM64_RELOC_BRANCH26	_stogir.vector.memory-inputs
    8e9c:      	add	x16, sp, #0x10
    8ea0:      	ldr	x0, [x16]
    8ea4:      	add	x16, sp, #0x10
    8ea8:      	ldr	x1, [x16, #0x8]
    8eac:      	add	x16, sp, #0x10
    8eb0:      	ldr	x2, [x16, #0x10]
    8eb4:      	str	x0, [x19]
    8eb8:      	str	x1, [x19, #0x8]
    8ebc:      	str	x2, [x19, #0x10]
    8ec0:      	ldr	x19, [sp, #0x30]
    8ec4:      	ldr	x29, [sp]
    8ec8:      	ldr	x30, [sp, #0x8]
    8ecc:      	add	sp, sp, #0x40
    8ed0:      	ret
    8ed4:      	movz	x6, #0x0, lsl #48
    8ed8:      	b	0x8dc0 <_stogir.vector.store-inputs+0xd0>
    8edc:      	movz	x6, #0x0, lsl #48
    8ee0:      	b	0x8db8 <_stogir.vector.store-inputs+0xc8>
    8ee4:      	brk	#0
    8ee8:      	b	0x8ee4 <_stogir.vector.store-inputs+0x1f4>

0000000000008eec <_stogir.types.size>:
    8eec:      	sxtw	x0, w0
    8ef0:      	sxtw	x1, w1
    8ef4:      	cmp	x0, #0xf
    8ef8:      	cset	w2, gt
    8efc:      	cmp	x0, #0x0
    8f00:      	cset	w3, eq
    8f04:      	cmp	x1, #0x4
    8f08:      	cset	w4, eq
    8f0c:      	cmp	x1, #0x8
    8f10:      	cset	w5, eq
    8f14:      	uxtb	w16, w2
    8f18:      	cmp	w16, wzr
    8f1c:      	b.eq	0x8fe4 <_stogir.types.size+0xf8>
    8f20:      	cmp	x0, #0x80
    8f24:      	cset	w6, lt
    8f28:      	uxtb	w16, w6
    8f2c:      	cmp	w16, wzr
    8f30:      	b.eq	0x8fe4 <_stogir.types.size+0xf8>
    8f34:      	and	x7, x0, #0xf
    8f38:      	lsr	w7, w7, #0
    8f3c:      	sxtw	x7, w7
    8f40:      	cmp	x7, #0x1
    8f44:      	cset	w8, ge
    8f48:      	uxtb	w16, w8
    8f4c:      	cmp	w16, wzr
    8f50:      	b.eq	0x8fe4 <_stogir.types.size+0xf8>
    8f54:      	cmp	x7, #0xd
    8f58:      	cset	w9, le
    8f5c:      	uxtb	w16, w9
    8f60:      	cmp	w16, wzr
    8f64:      	b.eq	0x8fe4 <_stogir.types.size+0xf8>
    8f68:      	cmp	x0, #0x0
    8f6c:      	cset	w10, ge
    8f70:      	cmp	x0, #0xd
    8f74:      	cset	w11, le
    8f78:      	uxtb	w16, w10
    8f7c:      	cmp	w16, wzr
    8f80:      	b.eq	0x8f90 <_stogir.types.size+0xa4>
    8f84:      	uxtb	w16, w11
    8f88:      	cmp	w16, wzr
    8f8c:      	b.ne	0x8fc4 <_stogir.types.size+0xd8>
    8f90:      	uxtb	w16, w2
    8f94:      	cmp	w16, wzr
    8f98:      	b.eq	0x8fc0 <_stogir.types.size+0xd4>
    8f9c:      	uxtb	w16, w6
    8fa0:      	cmp	w16, wzr
    8fa4:      	b.eq	0x8fc0 <_stogir.types.size+0xd4>
    8fa8:      	uxtb	w16, w8
    8fac:      	cmp	w16, wzr
    8fb0:      	b.eq	0x8fc0 <_stogir.types.size+0xd4>
    8fb4:      	uxtb	w16, w9
    8fb8:      	cmp	w16, wzr
    8fbc:      	b.ne	0x8fc4 <_stogir.types.size+0xd8>
    8fc0:      	movn	x7, #0x0, lsl #48
    8fc4:      	uxtb	w16, w4
    8fc8:      	cmp	w16, wzr
    8fcc:      	b.ne	0x9120 <_stogir.types.size+0x234>
    8fd0:      	uxtb	w16, w5
    8fd4:      	cmp	w16, wzr
    8fd8:      	b.ne	0x9120 <_stogir.types.size+0x234>
    8fdc:      	movn	x1, #0x0, lsl #48
    8fe0:      	b	0x9094 <_stogir.types.size+0x1a8>
    8fe4:      	uxtb	w16, w4
    8fe8:      	cmp	w16, wzr
    8fec:      	b.ne	0x9004 <_stogir.types.size+0x118>
    8ff0:      	uxtb	w16, w5
    8ff4:      	cmp	w16, wzr
    8ff8:      	b.ne	0x9004 <_stogir.types.size+0x118>
    8ffc:      	movn	x0, #0x0, lsl #48
    9000:      	b	0x901c <_stogir.types.size+0x130>
    9004:      	uxtb	w16, w3
    9008:      	cmp	w16, wzr
    900c:      	b.eq	0x9020 <_stogir.types.size+0x134>
    9010:      	movz	x0, #0x0, lsl #48
    9014:      	b	0x901c <_stogir.types.size+0x130>
    9018:      	mov	x0, #0x1                ; =1
    901c:      	ret
    9020:      	cmp	x0, #0x1
    9024:      	b.eq	0x9018 <_stogir.types.size+0x12c>
    9028:      	cmp	x0, #0x2
    902c:      	b.eq	0x9018 <_stogir.types.size+0x12c>
    9030:      	cmp	x0, #0x7
    9034:      	b.eq	0x9018 <_stogir.types.size+0x12c>
    9038:      	cmp	x0, #0x8
    903c:      	b.eq	0x9018 <_stogir.types.size+0x12c>
    9040:      	cmp	x0, #0x3
    9044:      	b.eq	0x91a8 <_stogir.types.size+0x2bc>
    9048:      	cmp	x0, #0x9
    904c:      	b.eq	0x91a8 <_stogir.types.size+0x2bc>
    9050:      	cmp	x0, #0x4
    9054:      	b.eq	0x91d8 <_stogir.types.size+0x2ec>
    9058:      	cmp	x0, #0xa
    905c:      	b.eq	0x91d8 <_stogir.types.size+0x2ec>
    9060:      	cmp	x0, #0xd
    9064:      	b.eq	0x91d8 <_stogir.types.size+0x2ec>
    9068:      	cmp	x0, #0x5
    906c:      	b.eq	0x91e8 <_stogir.types.size+0x2fc>
    9070:      	cmp	x0, #0xb
    9074:      	b.eq	0x91e8 <_stogir.types.size+0x2fc>
    9078:      	cmp	x0, #0xc
    907c:      	b.eq	0x91e8 <_stogir.types.size+0x2fc>
    9080:      	cmp	x0, #0x6
    9084:      	b.ne	0x91f8 <_stogir.types.size+0x30c>
    9088:      	mov	x0, x1
    908c:      	b	0x91fc <_stogir.types.size+0x310>
    9090:      	mov	x1, #0x1                ; =1
    9094:      	lsr	w1, w1, #0
    9098:      	sxtw	x1, w1
    909c:      	cmp	x1, #0x0
    90a0:      	b.ge	0x90ac <_stogir.types.size+0x1c0>
    90a4:      	movn	x0, #0x0, lsl #48
    90a8:      	b	0x901c <_stogir.types.size+0x130>
    90ac:      	uxtb	w16, w2
    90b0:      	cmp	w16, wzr
    90b4:      	b.eq	0x91b0 <_stogir.types.size+0x2c4>
    90b8:      	uxtb	w16, w6
    90bc:      	cmp	w16, wzr
    90c0:      	b.eq	0x91b0 <_stogir.types.size+0x2c4>
    90c4:      	uxtb	w16, w8
    90c8:      	cmp	w16, wzr
    90cc:      	b.eq	0x91b0 <_stogir.types.size+0x2c4>
    90d0:      	uxtb	w16, w9
    90d4:      	cmp	w16, wzr
    90d8:      	b.eq	0x91b0 <_stogir.types.size+0x2c4>
    90dc:      	ubfx	x0, x0, #4, #32
    90e0:      	sxtw	x0, w0
    90e4:      	sub	x0, x0, #0x1
    90e8:      	lsr	w0, w0, #0
    90ec:      	sxtw	x0, w0
    90f0:      	mov	x16, #0x1               ; =1
    90f4:      	lsl	x0, x16, x0
    90f8:      	lsr	w0, w0, #0
    90fc:      	sxtw	x0, w0
    9100:      	b	0x9108 <_stogir.types.size+0x21c>
    9104:      	movn	x0, #0x0, lsl #48
    9108:      	lsr	w0, w0, #0
    910c:      	sxtw	x0, w0
    9110:      	mul	x0, x0, x1
    9114:      	lsr	w0, w0, #0
    9118:      	sxtw	x0, w0
    911c:      	b	0x90a8 <_stogir.types.size+0x1bc>
    9120:      	lsr	w7, w7, #0
    9124:      	sxtw	x7, w7
    9128:      	cmp	x7, #0x0
    912c:      	b.ne	0x9138 <_stogir.types.size+0x24c>
    9130:      	movz	x1, #0x0, lsl #48
    9134:      	b	0x9094 <_stogir.types.size+0x1a8>
    9138:      	cmp	x7, #0x1
    913c:      	b.eq	0x9090 <_stogir.types.size+0x1a4>
    9140:      	cmp	x7, #0x2
    9144:      	b.eq	0x9090 <_stogir.types.size+0x1a4>
    9148:      	cmp	x7, #0x7
    914c:      	b.eq	0x9090 <_stogir.types.size+0x1a4>
    9150:      	cmp	x7, #0x8
    9154:      	b.eq	0x9090 <_stogir.types.size+0x1a4>
    9158:      	cmp	x7, #0x3
    915c:      	b.eq	0x91e0 <_stogir.types.size+0x2f4>
    9160:      	cmp	x7, #0x9
    9164:      	b.eq	0x91e0 <_stogir.types.size+0x2f4>
    9168:      	cmp	x7, #0x4
    916c:      	b.eq	0x91f0 <_stogir.types.size+0x304>
    9170:      	cmp	x7, #0xa
    9174:      	b.eq	0x91f0 <_stogir.types.size+0x304>
    9178:      	cmp	x7, #0xd
    917c:      	b.eq	0x91f0 <_stogir.types.size+0x304>
    9180:      	cmp	x7, #0x5
    9184:      	b.eq	0x9200 <_stogir.types.size+0x314>
    9188:      	cmp	x7, #0xb
    918c:      	b.eq	0x9200 <_stogir.types.size+0x314>
    9190:      	cmp	x7, #0xc
    9194:      	b.eq	0x9200 <_stogir.types.size+0x314>
    9198:      	cmp	x7, #0x6
    919c:      	b.eq	0x91a4 <_stogir.types.size+0x2b8>
    91a0:      	movn	x1, #0x0, lsl #48
    91a4:      	b	0x9204 <_stogir.types.size+0x318>
    91a8:      	mov	x0, #0x2                ; =2
    91ac:      	b	0x901c <_stogir.types.size+0x130>
    91b0:      	uxtb	w16, w10
    91b4:      	cmp	w16, wzr
    91b8:      	b.eq	0x9104 <_stogir.types.size+0x218>
    91bc:      	uxtb	w16, w11
    91c0:      	cmp	w16, wzr
    91c4:      	b.eq	0x9104 <_stogir.types.size+0x218>
    91c8:      	uxtb	w16, w3
    91cc:      	cmp	w16, wzr
    91d0:      	cset	x0, eq
    91d4:      	b	0x9108 <_stogir.types.size+0x21c>
    91d8:      	mov	x0, #0x4                ; =4
    91dc:      	b	0x91ac <_stogir.types.size+0x2c0>
    91e0:      	mov	x1, #0x2                ; =2
    91e4:      	b	0x9094 <_stogir.types.size+0x1a8>
    91e8:      	mov	x0, #0x8                ; =8
    91ec:      	b	0x91dc <_stogir.types.size+0x2f0>
    91f0:      	mov	x1, #0x4                ; =4
    91f4:      	b	0x91e4 <_stogir.types.size+0x2f8>
    91f8:      	movn	x0, #0x0, lsl #48
    91fc:      	b	0x91ec <_stogir.types.size+0x300>
    9200:      	mov	x1, #0x8                ; =8
    9204:      	b	0x91f4 <_stogir.types.size+0x308>

0000000000009208 <_stogir.opcode.properties>:
    9208:      	sxtw	x0, w0
    920c:      	cmp	x0, #0x0
    9210:      	b.lt	0x9238 <_stogir.opcode.properties+0x30>
    9214:      	cmp	x0, #0x83
    9218:      	b.ge	0x9238 <_stogir.opcode.properties+0x30>
    921c:      	adrp	x16, 0x9000 <_stogir.types.size+0x114>
		000000000000921c:  ARM64_RELOC_PAGE21	l_stogir.427
    9220:      	ldr	x16, [x16]
		0000000000009220:  ARM64_RELOC_PAGEOFF12	l_stogir.427
    9224:      	orr	x1, x16, xzr
    9228:      	lsr	x2, x0, #0
    922c:      	add	x0, x1, x0
    9230:      	ldrb	w0, [x0]
    9234:      	b	0x923c <_stogir.opcode.properties+0x34>
    9238:      	movz	x0, #0x0, lsl #48
    923c:      	ret

0000000000009240 <_stogir.checked.projection>:
    9240:      	sub	sp, sp, #0x40
    9244:      	str	x29, [sp]
    9248:      	str	x30, [sp, #0x8]
    924c:      	mov	x29, sp
    9250:      	str	x19, [sp, #0x30]
    9254:      	sxtw	x2, w1
    9258:      	cmp	x2, #0x0
    925c:      	cset	w3, gt
    9260:      	movz	x16, #0x0, lsl #48
    9264:      	sub	x4, x16, x2
    9268:      	sub	x5, x4, #0x1
    926c:      	uxtb	w16, w3
    9270:      	cmp	w16, wzr
    9274:      	b.eq	0x92b8 <_stogir.checked.projection+0x78>
    9278:      	ldr	x4, [x0, #0x8]
    927c:      	cmp	x2, x4
    9280:      	b.ge	0x930c <_stogir.checked.projection+0xcc>
    9284:      	add	x4, x0, #0x78
    9288:      	ldr	x4, [x4, #0x8]
    928c:      	cmp	x2, x4
    9290:      	b.ge	0x942c <_stogir.checked.projection+0x1ec>
    9294:      	lsl	x4, x2, #2
    9298:      	ldr	x4, [x0, #0x78]
    929c:      	add	x4, x4, x2, lsl #2
    92a0:      	ldr	w4, [x4]
    92a4:      	sxtw	x4, w4
    92a8:      	cmp	x4, #0x0
    92ac:      	cset	w4, ge
    92b0:      	ubfx	x4, x4, #0, #8
    92b4:      	b	0x9430 <_stogir.checked.projection+0x1f0>
    92b8:      	cmp	x2, #0x0
    92bc:      	b.ge	0x9314 <_stogir.checked.projection+0xd4>
    92c0:      	add	x6, x0, #0x28
    92c4:      	add	x7, x0, #0x50
    92c8:      	ldr	x6, [x6, #0x8]
    92cc:      	ldr	x7, [x7, #0x8]
    92d0:      	cmp	x6, x7
    92d4:      	b.ne	0x9304 <_stogir.checked.projection+0xc4>
    92d8:      	cmp	x4, x6
    92dc:      	b.gt	0x945c <_stogir.checked.projection+0x21c>
    92e0:      	lsl	x4, x5, #2
    92e4:      	ldr	x4, [x0, #0x50]
    92e8:      	add	x4, x4, x5, lsl #2
    92ec:      	ldr	w4, [x4]
    92f0:      	sxtw	x4, w4
    92f4:      	cmp	x4, #0x0
    92f8:      	cset	w4, gt
    92fc:      	ubfx	x4, x4, #0, #8
    9300:      	b	0x9460 <_stogir.checked.projection+0x220>
    9304:      	movz	x4, #0x0, lsl #48
    9308:      	b	0x9318 <_stogir.checked.projection+0xd8>
    930c:      	movz	x4, #0x0, lsl #48
    9310:      	b	0x9318 <_stogir.checked.projection+0xd8>
    9314:      	movz	x4, #0x0, lsl #48
    9318:      	cmp	x4, #0x0
    931c:      	b.eq	0x935c <_stogir.checked.projection+0x11c>
    9320:      	uxtb	w16, w3
    9324:      	cmp	w16, wzr
    9328:      	b.eq	0x9340 <_stogir.checked.projection+0x100>
    932c:      	lsl	x3, x2, #4
    9330:      	ldr	x3, [x0]
    9334:      	add	x2, x3, x2, lsl #4
    9338:      	ldr	x2, [x2]
    933c:      	b	0x9350 <_stogir.checked.projection+0x110>
    9340:      	lsl	x2, x5, #4
    9344:      	ldr	x2, [x0, #0x28]
    9348:      	add	x2, x2, x5, lsl #4
    934c:      	ldr	x2, [x2]
    9350:      	mov	x3, x2
    9354:      	mov	x2, #0x1                ; =1
    9358:      	b	0x9364 <_stogir.checked.projection+0x124>
    935c:      	movz	x2, #0x0, lsl #48
    9360:      	movz	x3, #0x0, lsl #48
    9364:      	lsr	w2, w2, #0
    9368:      	lsr	x16, x2, #0
    936c:      	cmp	x16, #0x1
    9370:      	b.eq	0x938c <_stogir.checked.projection+0x14c>
    9374:      	b.lo	0x937c <_stogir.checked.projection+0x13c>
    9378:      	b	0x9390 <_stogir.checked.projection+0x150>
    937c:      	cmp	x16, #0x0
    9380:      	b.eq	0x9388 <_stogir.checked.projection+0x148>
    9384:      	b	0x9390 <_stogir.checked.projection+0x150>
    9388:      	b	0x9394 <_stogir.checked.projection+0x154>
    938c:      	b	0x93ec <_stogir.checked.projection+0x1ac>
    9390:      	b	0x9464 <_stogir.checked.projection+0x224>
    9394:      	adrp	x16, 0x9000 <_stogir.types.size+0x114>
		0000000000009394:  ARM64_RELOC_PAGE21	l_stogir.428
    9398:      	ldr	x16, [x16]
		0000000000009398:  ARM64_RELOC_PAGEOFF12	l_stogir.428
    939c:      	orr	x0, x16, xzr
    93a0:      	mov	x19, x8
    93a4:      	mov	x1, x0
    93a8:      	mov	x0, #0x1                ; =1
    93ac:      	mov	x2, #0x17               ; =23
    93b0:      	b	0x93cc <_stogir.checked.projection+0x18c>
    93b4:      	adrp	x16, 0x9000 <_stogir.types.size+0x114>
		00000000000093b4:  ARM64_RELOC_PAGE21	l_stogir.429
    93b8:      	ldr	x16, [x16]
		00000000000093b8:  ARM64_RELOC_PAGEOFF12	l_stogir.429
    93bc:      	orr	x0, x16, xzr
    93c0:      	mov	x1, x0
    93c4:      	mov	x0, #0x1                ; =1
    93c8:      	mov	x2, #0x20               ; =32
    93cc:      	str	x0, [x19]
    93d0:      	str	x1, [x19, #0x8]
    93d4:      	str	x2, [x19, #0x10]
    93d8:      	ldr	x19, [sp, #0x30]
    93dc:      	ldr	x29, [sp]
    93e0:      	ldr	x30, [sp, #0x8]
    93e4:      	add	sp, sp, #0x40
    93e8:      	ret
    93ec:      	uxtb	w2, w3
    93f0:      	cmp	x2, #0x29
    93f4:      	b.lt	0x946c <_stogir.checked.projection+0x22c>
    93f8:      	cmp	x2, #0x2b
    93fc:      	b.gt	0x9474 <_stogir.checked.projection+0x234>
    9400:      	lsr	w1, w1, #0
    9404:      	mov	x19, x8
    9408:      	add	x8, sp, #0x10
    940c:      	bl	0x940c <_stogir.checked.projection+0x1cc>
		000000000000940c:  ARM64_RELOC_BRANCH26	_stogir.checked.validate
    9410:      	add	x16, sp, #0x10
    9414:      	ldr	x0, [x16]
    9418:      	add	x16, sp, #0x10
    941c:      	ldr	x1, [x16, #0x8]
    9420:      	add	x16, sp, #0x10
    9424:      	ldr	x2, [x16, #0x10]
    9428:      	b	0x93cc <_stogir.checked.projection+0x18c>
    942c:      	movz	x4, #0x0, lsl #48
    9430:      	b	0x9310 <_stogir.checked.projection+0xd0>
    9434:      	lsr	w3, w3, #0
    9438:      	ubfx	x0, x3, #8, #8
    943c:      	cmp	x0, #0x0
    9440:      	b.eq	0x93b4 <_stogir.checked.projection+0x174>
    9444:      	cmp	x0, #0xd
    9448:      	b.gt	0x93b4 <_stogir.checked.projection+0x174>
    944c:      	movz	x0, #0x0, lsl #48
    9450:      	movz	x1, #0x0, lsl #48
    9454:      	movz	x2, #0x0, lsl #48
    9458:      	b	0x93cc <_stogir.checked.projection+0x18c>
    945c:      	movz	x4, #0x0, lsl #48
    9460:      	b	0x9308 <_stogir.checked.projection+0xc8>
    9464:      	brk	#0
    9468:      	b	0x9464 <_stogir.checked.projection+0x224>
    946c:      	mov	x19, x8
    9470:      	b	0x9434 <_stogir.checked.projection+0x1f4>
    9474:      	mov	x19, x8
    9478:      	b	0x9434 <_stogir.checked.projection+0x1f4>

000000000000947c <_stogir.checked.operands>:
    947c:      	sub	sp, sp, #0x30
    9480:      	str	x19, [sp, #0x20]
    9484:      	str	x20, [sp, #0x28]
    9488:      	sxtw	x1, w1
    948c:      	sxtw	x2, w2
    9490:      	cmp	x1, #0x29
    9494:      	b.lt	0x94dc <_stogir.checked.operands+0x60>
    9498:      	cmp	x1, #0x2b
    949c:      	b.gt	0x94dc <_stogir.checked.operands+0x60>
    94a0:      	cmp	x2, #0x1
    94a4:      	b.lt	0x94dc <_stogir.checked.operands+0x60>
    94a8:      	cmp	x2, #0xb
    94ac:      	b.gt	0x94dc <_stogir.checked.operands+0x60>
    94b0:      	cmp	x2, #0x1
    94b4:      	b.eq	0x94dc <_stogir.checked.operands+0x60>
    94b8:      	adrp	x16, 0x9000 <_stogir.types.size+0x114>
		00000000000094b8:  ARM64_RELOC_PAGE21	l_stogir.430
    94bc:      	ldr	x16, [x16]
		00000000000094bc:  ARM64_RELOC_PAGEOFF12	l_stogir.430
    94c0:      	orr	x1, x16, xzr
    94c4:      	movz	x5, #0x0, lsl #48
    94c8:      	b	0x94ec <_stogir.checked.operands+0x70>
    94cc:      	movz	x14, #0x0, lsl #48
    94d0:      	b	0x9550 <_stogir.checked.operands+0xd4>
    94d4:      	movz	x14, #0x0, lsl #48
    94d8:      	b	0x9564 <_stogir.checked.operands+0xe8>
    94dc:      	adrp	x16, 0x9000 <_stogir.types.size+0x114>
		00000000000094dc:  ARM64_RELOC_PAGE21	l_stogir.431
    94e0:      	ldr	x16, [x16]
		00000000000094e0:  ARM64_RELOC_PAGEOFF12	l_stogir.431
    94e4:      	orr	x1, x16, xzr
    94e8:      	mov	x5, #0x36               ; =54
    94ec:      	add	x16, sp, #0x10
    94f0:      	orr	x6, x16, xzr
    94f4:      	adrp	x16, 0x9000 <_stogir.types.size+0x114>
		00000000000094f4:  ARM64_RELOC_PAGE21	l_stogir.432
    94f8:      	ldr	x16, [x16]
		00000000000094f8:  ARM64_RELOC_PAGEOFF12	l_stogir.432
    94fc:      	orr	x7, x16, xzr
    9500:      	adrp	x16, 0x9000 <_stogir.types.size+0x114>
		0000000000009500:  ARM64_RELOC_PAGE21	l_stogir.433
    9504:      	ldr	x16, [x16]
		0000000000009504:  ARM64_RELOC_PAGEOFF12	l_stogir.433
    9508:      	orr	x9, x16, xzr
    950c:      	lsr	w3, w3, #0
    9510:      	lsr	w4, w4, #0
    9514:      	add	x10, x0, #0x78
    9518:      	add	x11, x0, #0x28
    951c:      	add	x12, x0, #0x50
    9520:      	mov	x16, sp
    9524:      	str	w3, [x16]
    9528:      	mov	x16, sp
    952c:      	str	w4, [x16, #0x4]
    9530:      	mov	x16, sp
    9534:      	ldr	x3, [x16]
    9538:      	add	x16, sp, #0x10
    953c:      	str	x3, [x16]
    9540:      	mov	x3, x5
    9544:      	movz	x4, #0x0, lsl #48
    9548:      	b	0x9614 <_stogir.checked.operands+0x198>
    954c:      	movz	x14, #0x0, lsl #48
    9550:      	fmov	d31, x13
    9554:      	mov	x13, x14
    9558:      	fmov	x14, d31
    955c:      	b	0x9570 <_stogir.checked.operands+0xf4>
    9560:      	movz	x14, #0x0, lsl #48
    9564:      	fmov	d31, x13
    9568:      	mov	x13, x14
    956c:      	fmov	x14, d31
    9570:      	cmp	x13, #0x0
    9574:      	b.eq	0x95b4 <_stogir.checked.operands+0x138>
    9578:      	uxtb	w16, w4
    957c:      	cmp	w16, wzr
    9580:      	b.eq	0x9598 <_stogir.checked.operands+0x11c>
    9584:      	lsl	x4, x5, #4
    9588:      	ldr	x4, [x0]
    958c:      	add	x4, x4, x5, lsl #4
    9590:      	ldr	x4, [x4]
    9594:      	b	0x95a8 <_stogir.checked.operands+0x12c>
    9598:      	lsl	x4, x15, #4
    959c:      	ldr	x4, [x0, #0x28]
    95a0:      	add	x4, x4, x15, lsl #4
    95a4:      	ldr	x4, [x4]
    95a8:      	mov	x5, x4
    95ac:      	mov	x4, #0x1                ; =1
    95b0:      	b	0x95bc <_stogir.checked.operands+0x140>
    95b4:      	movz	x4, #0x0, lsl #48
    95b8:      	movz	x5, #0x0, lsl #48
    95bc:      	lsr	w4, w4, #0
    95c0:      	lsr	x16, x4, #0
    95c4:      	cmp	x16, #0x1
    95c8:      	b.eq	0x95e4 <_stogir.checked.operands+0x168>
    95cc:      	b.lo	0x95d4 <_stogir.checked.operands+0x158>
    95d0:      	b	0x95e8 <_stogir.checked.operands+0x16c>
    95d4:      	cmp	x16, #0x0
    95d8:      	b.eq	0x95e0 <_stogir.checked.operands+0x164>
    95dc:      	b	0x95e8 <_stogir.checked.operands+0x16c>
    95e0:      	b	0x95ec <_stogir.checked.operands+0x170>
    95e4:      	b	0x95f8 <_stogir.checked.operands+0x17c>
    95e8:      	b	0x9778 <_stogir.checked.operands+0x2fc>
    95ec:      	mov	x1, x7
    95f0:      	mov	x3, #0x22               ; =34
    95f4:      	b	0x9610 <_stogir.checked.operands+0x194>
    95f8:      	lsr	w5, w5, #0
    95fc:      	ubfx	x4, x5, #8, #8
    9600:      	cmp	x4, x2
    9604:      	b.eq	0x9610 <_stogir.checked.operands+0x194>
    9608:      	mov	x1, x9
    960c:      	mov	x3, #0x28               ; =40
    9610:      	mov	x4, x14
    9614:      	cmp	x4, #0x2
    9618:      	b.ge	0x9644 <_stogir.checked.operands+0x1c8>
    961c:      	add	x5, x4, #0x1
    9620:      	lsl	x13, x4, #2
    9624:      	add	x4, x6, x4, lsl #2
    9628:      	ldr	w4, [x4]
    962c:      	sxtw	x4, w4
    9630:      	and	x4, x4, #0xffffffff
    9634:      	mov	x13, x5
    9638:      	mov	x5, x4
    963c:      	mov	x4, #0x1                ; =1
    9640:      	b	0x9650 <_stogir.checked.operands+0x1d4>
    9644:      	mov	x13, x4
    9648:      	movz	x4, #0x0, lsl #48
    964c:      	movz	x5, #0x0, lsl #48
    9650:      	lsr	w4, w4, #0
    9654:      	lsr	x16, x4, #0
    9658:      	cmp	x16, #0x1
    965c:      	b.eq	0x9678 <_stogir.checked.operands+0x1fc>
    9660:      	b.lo	0x9668 <_stogir.checked.operands+0x1ec>
    9664:      	b	0x967c <_stogir.checked.operands+0x200>
    9668:      	cmp	x16, #0x0
    966c:      	b.eq	0x9674 <_stogir.checked.operands+0x1f8>
    9670:      	b	0x967c <_stogir.checked.operands+0x200>
    9674:      	b	0x96e4 <_stogir.checked.operands+0x268>
    9678:      	b	0x9680 <_stogir.checked.operands+0x204>
    967c:      	b	0x9770 <_stogir.checked.operands+0x2f4>
    9680:      	lsr	w5, w5, #0
    9684:      	sxtw	x5, w5
    9688:      	cmp	x5, #0x0
    968c:      	cset	w4, gt
    9690:      	movz	x16, #0x0, lsl #48
    9694:      	sub	x14, x16, x5
    9698:      	sub	x15, x14, #0x1
    969c:      	uxtb	w16, w4
    96a0:      	cmp	w16, wzr
    96a4:      	b.eq	0x9724 <_stogir.checked.operands+0x2a8>
    96a8:      	ldr	x14, [x0, #0x8]
    96ac:      	cmp	x5, x14
    96b0:      	b.ge	0x954c <_stogir.checked.operands+0xd0>
    96b4:      	ldr	x14, [x10, #0x8]
    96b8:      	cmp	x5, x14
    96bc:      	b.ge	0x94cc <_stogir.checked.operands+0x50>
    96c0:      	lsl	x14, x5, #2
    96c4:      	ldr	x14, [x0, #0x78]
    96c8:      	add	x14, x14, x5, lsl #2
    96cc:      	ldr	w14, [x14]
    96d0:      	sxtw	x14, w14
    96d4:      	cmp	x14, #0x0
    96d8:      	cset	w14, ge
    96dc:      	ubfx	x14, x14, #0, #8
    96e0:      	b	0x94d0 <_stogir.checked.operands+0x54>
    96e4:      	cmp	x3, #0x0
    96e8:      	b.ne	0x9700 <_stogir.checked.operands+0x284>
    96ec:      	and	x0, x2, #0xffffffff
    96f0:      	mov	x1, x0
    96f4:      	movz	x0, #0x0, lsl #48
    96f8:      	movz	x2, #0x0, lsl #48
    96fc:      	b	0x9708 <_stogir.checked.operands+0x28c>
    9700:      	mov	x2, x3
    9704:      	mov	x0, #0x1                ; =1
    9708:      	str	x0, [x8]
    970c:      	str	x1, [x8, #0x8]
    9710:      	str	x2, [x8, #0x10]
    9714:      	ldr	x19, [sp, #0x20]
    9718:      	ldr	x20, [sp, #0x28]
    971c:      	add	sp, sp, #0x30
    9720:      	ret
    9724:      	cmp	x5, #0x0
    9728:      	b.ge	0x9560 <_stogir.checked.operands+0xe4>
    972c:      	ldr	x19, [x11, #0x8]
    9730:      	ldr	x20, [x12, #0x8]
    9734:      	cmp	x19, x20
    9738:      	b.ne	0x94d4 <_stogir.checked.operands+0x58>
    973c:      	cmp	x14, x19
    9740:      	b.gt	0x9768 <_stogir.checked.operands+0x2ec>
    9744:      	lsl	x14, x15, #2
    9748:      	ldr	x14, [x0, #0x50]
    974c:      	add	x14, x14, x15, lsl #2
    9750:      	ldr	w14, [x14]
    9754:      	sxtw	x14, w14
    9758:      	cmp	x14, #0x0
    975c:      	cset	w14, gt
    9760:      	ubfx	x14, x14, #0, #8
    9764:      	b	0x976c <_stogir.checked.operands+0x2f0>
    9768:      	movz	x14, #0x0, lsl #48
    976c:      	b	0x94d8 <_stogir.checked.operands+0x5c>
    9770:      	brk	#0
    9774:      	b	0x9770 <_stogir.checked.operands+0x2f4>
    9778:      	brk	#0
    977c:      	b	0x9778 <_stogir.checked.operands+0x2fc>

0000000000009780 <_stogir.opcode.control?>:
    9780:      	sxtw	x0, w0
    9784:      	cmp	x0, #0x0
    9788:      	b.lt	0x97b0 <_stogir.opcode.control?+0x30>
    978c:      	cmp	x0, #0x83
    9790:      	b.ge	0x97b0 <_stogir.opcode.control?+0x30>
    9794:      	adrp	x16, 0x9000 <_stogir.types.size+0x114>
		0000000000009794:  ARM64_RELOC_PAGE21	l_stogir.434
    9798:      	ldr	x16, [x16]
		0000000000009798:  ARM64_RELOC_PAGEOFF12	l_stogir.434
    979c:      	orr	x1, x16, xzr
    97a0:      	lsr	x2, x0, #0
    97a4:      	add	x0, x1, x0
    97a8:      	ldrb	w0, [x0]
    97ac:      	b	0x97b4 <_stogir.opcode.control?+0x34>
    97b0:      	movz	x0, #0x0, lsl #48
    97b4:      	uxtb	w0, w0
    97b8:      	and	x0, x0, #0x1
    97bc:      	uxtb	w0, w0
    97c0:      	ret

00000000000097c4 <_stogir.opcode.block-end?>:
    97c4:      	sxtw	x0, w0
    97c8:      	cmp	x0, #0x0
    97cc:      	b.lt	0x97f4 <_stogir.opcode.block-end?+0x30>
    97d0:      	cmp	x0, #0x83
    97d4:      	b.ge	0x97f4 <_stogir.opcode.block-end?+0x30>
    97d8:      	adrp	x16, 0x9000 <_stogir.types.size+0x114>
		00000000000097d8:  ARM64_RELOC_PAGE21	l_stogir.435
    97dc:      	ldr	x16, [x16]
		00000000000097dc:  ARM64_RELOC_PAGEOFF12	l_stogir.435
    97e0:      	orr	x1, x16, xzr
    97e4:      	lsr	x2, x0, #0
    97e8:      	add	x0, x1, x0
    97ec:      	ldrb	w0, [x0]
    97f0:      	b	0x97f8 <_stogir.opcode.block-end?+0x34>
    97f4:      	movz	x0, #0x0, lsl #48
    97f8:      	uxtb	w0, w0
    97fc:      	and	x0, x0, #0x4
    9800:      	uxtb	w0, w0
    9804:      	cmp	x0, #0x0
    9808:      	cset	w0, eq
    980c:      	uxtb	w16, w0
    9810:      	cmp	w16, wzr
    9814:      	cset	x0, eq
    9818:      	ret

000000000000981c <_stogir.atomic.ordinary?>:
    981c:      	sxtw	x1, w1
    9820:      	cmp	x1, #0x0
    9824:      	cset	w3, gt
    9828:      	movz	x16, #0x0, lsl #48
    982c:      	sub	x4, x16, x1
    9830:      	sub	x5, x4, #0x1
    9834:      	uxtb	w16, w3
    9838:      	cmp	w16, wzr
    983c:      	b.eq	0x9880 <_stogir.atomic.ordinary?+0x64>
    9840:      	ldr	x4, [x0, #0x8]
    9844:      	cmp	x1, x4
    9848:      	b.ge	0x98d4 <_stogir.atomic.ordinary?+0xb8>
    984c:      	add	x4, x0, #0x78
    9850:      	ldr	x4, [x4, #0x8]
    9854:      	cmp	x1, x4
    9858:      	b.ge	0x9994 <_stogir.atomic.ordinary?+0x178>
    985c:      	lsl	x4, x1, #2
    9860:      	ldr	x4, [x0, #0x78]
    9864:      	add	x4, x4, x1, lsl #2
    9868:      	ldr	w4, [x4]
    986c:      	sxtw	x4, w4
    9870:      	cmp	x4, #0x0
    9874:      	cset	w4, ge
    9878:      	ubfx	x4, x4, #0, #8
    987c:      	b	0x9998 <_stogir.atomic.ordinary?+0x17c>
    9880:      	cmp	x1, #0x0
    9884:      	b.ge	0x98dc <_stogir.atomic.ordinary?+0xc0>
    9888:      	add	x6, x0, #0x28
    988c:      	add	x7, x0, #0x50
    9890:      	ldr	x6, [x6, #0x8]
    9894:      	ldr	x7, [x7, #0x8]
    9898:      	cmp	x6, x7
    989c:      	b.ne	0x98cc <_stogir.atomic.ordinary?+0xb0>
    98a0:      	cmp	x4, x6
    98a4:      	b.gt	0x99b4 <_stogir.atomic.ordinary?+0x198>
    98a8:      	lsl	x4, x5, #2
    98ac:      	ldr	x4, [x0, #0x50]
    98b0:      	add	x4, x4, x5, lsl #2
    98b4:      	ldr	w4, [x4]
    98b8:      	sxtw	x4, w4
    98bc:      	cmp	x4, #0x0
    98c0:      	cset	w4, gt
    98c4:      	ubfx	x4, x4, #0, #8
    98c8:      	b	0x99b8 <_stogir.atomic.ordinary?+0x19c>
    98cc:      	movz	x4, #0x0, lsl #48
    98d0:      	b	0x98e0 <_stogir.atomic.ordinary?+0xc4>
    98d4:      	movz	x4, #0x0, lsl #48
    98d8:      	b	0x98e0 <_stogir.atomic.ordinary?+0xc4>
    98dc:      	movz	x4, #0x0, lsl #48
    98e0:      	cmp	x4, #0x0
    98e4:      	b.eq	0x9924 <_stogir.atomic.ordinary?+0x108>
    98e8:      	uxtb	w16, w3
    98ec:      	cmp	w16, wzr
    98f0:      	b.eq	0x9908 <_stogir.atomic.ordinary?+0xec>
    98f4:      	lsl	x3, x1, #4
    98f8:      	ldr	x0, [x0]
    98fc:      	add	x0, x0, x1, lsl #4
    9900:      	ldr	x0, [x0]
    9904:      	b	0x9918 <_stogir.atomic.ordinary?+0xfc>
    9908:      	lsl	x1, x5, #4
    990c:      	ldr	x0, [x0, #0x28]
    9910:      	add	x0, x0, x5, lsl #4
    9914:      	ldr	x0, [x0]
    9918:      	mov	x1, x0
    991c:      	mov	x0, #0x1                ; =1
    9920:      	b	0x992c <_stogir.atomic.ordinary?+0x110>
    9924:      	movz	x0, #0x0, lsl #48
    9928:      	movz	x1, #0x0, lsl #48
    992c:      	lsr	w0, w0, #0
    9930:      	lsr	x16, x0, #0
    9934:      	cmp	x16, #0x1
    9938:      	b.eq	0x9954 <_stogir.atomic.ordinary?+0x138>
    993c:      	b.lo	0x9944 <_stogir.atomic.ordinary?+0x128>
    9940:      	b	0x9958 <_stogir.atomic.ordinary?+0x13c>
    9944:      	cmp	x16, #0x0
    9948:      	b.eq	0x9950 <_stogir.atomic.ordinary?+0x134>
    994c:      	b	0x9958 <_stogir.atomic.ordinary?+0x13c>
    9950:      	b	0x995c <_stogir.atomic.ordinary?+0x140>
    9954:      	b	0x996c <_stogir.atomic.ordinary?+0x150>
    9958:      	b	0x99bc <_stogir.atomic.ordinary?+0x1a0>
    995c:      	movz	x0, #0x0, lsl #48
    9960:      	b	0x9968 <_stogir.atomic.ordinary?+0x14c>
    9964:      	movz	x0, #0x0, lsl #48
    9968:      	ret
    996c:      	sxtw	x2, w2
    9970:      	lsr	w0, w1, #0
    9974:      	ubfx	x0, x0, #8, #8
    9978:      	cmp	x0, x2
    997c:      	b.ne	0x9964 <_stogir.atomic.ordinary?+0x148>
    9980:      	uxtb	w1, w1
    9984:      	cmp	x1, #0x46
    9988:      	b.ne	0x999c <_stogir.atomic.ordinary?+0x180>
    998c:      	movz	x0, #0x0, lsl #48
    9990:      	b	0x99b0 <_stogir.atomic.ordinary?+0x194>
    9994:      	movz	x4, #0x0, lsl #48
    9998:      	b	0x98d8 <_stogir.atomic.ordinary?+0xbc>
    999c:      	cmp	x1, #0x48
    99a0:      	cset	w0, eq
    99a4:      	uxtb	w16, w0
    99a8:      	cmp	w16, wzr
    99ac:      	cset	x0, eq
    99b0:      	b	0x9968 <_stogir.atomic.ordinary?+0x14c>
    99b4:      	movz	x4, #0x0, lsl #48
    99b8:      	b	0x98d0 <_stogir.atomic.ordinary?+0xb4>
    99bc:      	brk	#0
    99c0:      	b	0x99bc <_stogir.atomic.ordinary?+0x1a0>

00000000000099c4 <_stogir.types.scalar-size>:
    99c4:      	sxtw	x1, w1
    99c8:      	cmp	x1, #0x4
    99cc:      	b.eq	0x99e0 <_stogir.types.scalar-size+0x1c>
    99d0:      	cmp	x1, #0x8
    99d4:      	b.eq	0x99e0 <_stogir.types.scalar-size+0x1c>
    99d8:      	movn	x0, #0x0, lsl #48
    99dc:      	b	0x99f8 <_stogir.types.scalar-size+0x34>
    99e0:      	sxtw	x0, w0
    99e4:      	cmp	x0, #0x0
    99e8:      	b.ne	0x99fc <_stogir.types.scalar-size+0x38>
    99ec:      	movz	x0, #0x0, lsl #48
    99f0:      	b	0x99f8 <_stogir.types.scalar-size+0x34>
    99f4:      	mov	x0, #0x1                ; =1
    99f8:      	ret
    99fc:      	cmp	x0, #0x1
    9a00:      	b.eq	0x99f4 <_stogir.types.scalar-size+0x30>
    9a04:      	cmp	x0, #0x2
    9a08:      	b.eq	0x99f4 <_stogir.types.scalar-size+0x30>
    9a0c:      	cmp	x0, #0x7
    9a10:      	b.eq	0x99f4 <_stogir.types.scalar-size+0x30>
    9a14:      	cmp	x0, #0x8
    9a18:      	b.eq	0x99f4 <_stogir.types.scalar-size+0x30>
    9a1c:      	cmp	x0, #0x3
    9a20:      	b.eq	0x9a6c <_stogir.types.scalar-size+0xa8>
    9a24:      	cmp	x0, #0x9
    9a28:      	b.eq	0x9a6c <_stogir.types.scalar-size+0xa8>
    9a2c:      	cmp	x0, #0x4
    9a30:      	b.eq	0x9a74 <_stogir.types.scalar-size+0xb0>
    9a34:      	cmp	x0, #0xa
    9a38:      	b.eq	0x9a74 <_stogir.types.scalar-size+0xb0>
    9a3c:      	cmp	x0, #0xd
    9a40:      	b.eq	0x9a74 <_stogir.types.scalar-size+0xb0>
    9a44:      	cmp	x0, #0x5
    9a48:      	b.eq	0x9a7c <_stogir.types.scalar-size+0xb8>
    9a4c:      	cmp	x0, #0xb
    9a50:      	b.eq	0x9a7c <_stogir.types.scalar-size+0xb8>
    9a54:      	cmp	x0, #0xc
    9a58:      	b.eq	0x9a7c <_stogir.types.scalar-size+0xb8>
    9a5c:      	cmp	x0, #0x6
    9a60:      	b.ne	0x9a84 <_stogir.types.scalar-size+0xc0>
    9a64:      	mov	x0, x1
    9a68:      	b	0x9a88 <_stogir.types.scalar-size+0xc4>
    9a6c:      	mov	x0, #0x2                ; =2
    9a70:      	b	0x99f8 <_stogir.types.scalar-size+0x34>
    9a74:      	mov	x0, #0x4                ; =4
    9a78:      	b	0x9a70 <_stogir.types.scalar-size+0xac>
    9a7c:      	mov	x0, #0x8                ; =8
    9a80:      	b	0x9a78 <_stogir.types.scalar-size+0xb4>
    9a84:      	movn	x0, #0x0, lsl #48
    9a88:      	b	0x9a80 <_stogir.types.scalar-size+0xbc>

0000000000009a8c <_stogir.terminal.inputs>:
    9a8c:      	sxtw	x1, w1
    9a90:      	cmp	x1, #0x60
    9a94:      	cset	w4, eq
    9a98:      	uxtb	w16, w4
    9a9c:      	cmp	w16, wzr
    9aa0:      	b.ne	0x9ad4 <_stogir.terminal.inputs+0x48>
    9aa4:      	cmp	x1, #0x79
    9aa8:      	b.eq	0x9ad4 <_stogir.terminal.inputs+0x48>
    9aac:      	adrp	x16, 0x9000 <_stogir.types.size+0x114>
		0000000000009aac:  ARM64_RELOC_PAGE21	l_stogir.436
    9ab0:      	ldr	x16, [x16]
		0000000000009ab0:  ARM64_RELOC_PAGEOFF12	l_stogir.436
    9ab4:      	orr	x0, x16, xzr
    9ab8:      	mov	x1, x0
    9abc:      	mov	x0, #0x1                ; =1
    9ac0:      	mov	x2, #0x25               ; =37
    9ac4:      	str	x0, [x8]
    9ac8:      	str	x1, [x8, #0x8]
    9acc:      	str	x2, [x8, #0x10]
    9ad0:      	ret
    9ad4:      	sxtw	x3, w3
    9ad8:      	uxtb	w16, w4
    9adc:      	cmp	w16, wzr
    9ae0:      	b.eq	0x9aec <_stogir.terminal.inputs+0x60>
    9ae4:      	cmp	x3, #0x0
    9ae8:      	b.ne	0x9aac <_stogir.terminal.inputs+0x20>
    9aec:      	sxtw	x2, w2
    9af0:      	cmp	x2, #0x0
    9af4:      	cset	w1, gt
    9af8:      	movz	x16, #0x0, lsl #48
    9afc:      	sub	x4, x16, x2
    9b00:      	sub	x5, x4, #0x1
    9b04:      	uxtb	w16, w1
    9b08:      	cmp	w16, wzr
    9b0c:      	b.eq	0x9bf4 <_stogir.terminal.inputs+0x168>
    9b10:      	ldr	x4, [x0, #0x8]
    9b14:      	cmp	x2, x4
    9b18:      	b.ge	0x9bec <_stogir.terminal.inputs+0x160>
    9b1c:      	add	x4, x0, #0x78
    9b20:      	ldr	x4, [x4, #0x8]
    9b24:      	cmp	x2, x4
    9b28:      	b.ge	0x9c9c <_stogir.terminal.inputs+0x210>
    9b2c:      	lsl	x4, x2, #2
    9b30:      	ldr	x4, [x0, #0x78]
    9b34:      	add	x4, x4, x2, lsl #2
    9b38:      	ldr	w4, [x4]
    9b3c:      	sxtw	x4, w4
    9b40:      	cmp	x4, #0x0
    9b44:      	cset	w4, ge
    9b48:      	ubfx	x4, x4, #0, #8
    9b4c:      	b	0x9ca0 <_stogir.terminal.inputs+0x214>
    9b50:      	movz	x1, #0x0, lsl #48
    9b54:      	movz	x4, #0x0, lsl #48
    9b58:      	lsr	w1, w1, #0
    9b5c:      	lsr	x16, x1, #0
    9b60:      	cmp	x16, #0x1
    9b64:      	b.eq	0x9b80 <_stogir.terminal.inputs+0xf4>
    9b68:      	b.lo	0x9b70 <_stogir.terminal.inputs+0xe4>
    9b6c:      	b	0x9b84 <_stogir.terminal.inputs+0xf8>
    9b70:      	cmp	x16, #0x0
    9b74:      	b.eq	0x9b7c <_stogir.terminal.inputs+0xf0>
    9b78:      	b	0x9b84 <_stogir.terminal.inputs+0xf8>
    9b7c:      	b	0x9b88 <_stogir.terminal.inputs+0xfc>
    9b80:      	b	0x9c40 <_stogir.terminal.inputs+0x1b4>
    9b84:      	b	0x9df4 <_stogir.terminal.inputs+0x368>
    9b88:      	adrp	x16, 0x9000 <_stogir.types.size+0x114>
		0000000000009b88:  ARM64_RELOC_PAGE21	l_stogir.437
    9b8c:      	ldr	x16, [x16]
		0000000000009b8c:  ARM64_RELOC_PAGEOFF12	l_stogir.437
    9b90:      	orr	x0, x16, xzr
    9b94:      	mov	x1, x0
    9b98:      	mov	x0, #0x1                ; =1
    9b9c:      	mov	x2, #0x1d               ; =29
    9ba0:      	b	0x9ac4 <_stogir.terminal.inputs+0x38>
    9ba4:      	lsl	x1, x5, #4
    9ba8:      	ldr	x1, [x0, #0x28]
    9bac:      	add	x1, x1, x5, lsl #4
    9bb0:      	ldr	x1, [x1]
    9bb4:      	mov	x4, x1
    9bb8:      	mov	x1, #0x1                ; =1
    9bbc:      	b	0x9b58 <_stogir.terminal.inputs+0xcc>
    9bc0:      	movz	x4, #0x0, lsl #48
    9bc4:      	cmp	x4, #0x0
    9bc8:      	b.eq	0x9b50 <_stogir.terminal.inputs+0xc4>
    9bcc:      	uxtb	w16, w1
    9bd0:      	cmp	w16, wzr
    9bd4:      	b.eq	0x9ba4 <_stogir.terminal.inputs+0x118>
    9bd8:      	lsl	x1, x2, #4
    9bdc:      	ldr	x1, [x0]
    9be0:      	add	x1, x1, x2, lsl #4
    9be4:      	ldr	x1, [x1]
    9be8:      	b	0x9bb4 <_stogir.terminal.inputs+0x128>
    9bec:      	movz	x4, #0x0, lsl #48
    9bf0:      	b	0x9bc4 <_stogir.terminal.inputs+0x138>
    9bf4:      	cmp	x2, #0x0
    9bf8:      	b.ge	0x9bc0 <_stogir.terminal.inputs+0x134>
    9bfc:      	add	x6, x0, #0x28
    9c00:      	add	x7, x0, #0x50
    9c04:      	ldr	x6, [x6, #0x8]
    9c08:      	ldr	x7, [x7, #0x8]
    9c0c:      	cmp	x6, x7
    9c10:      	b.ne	0x9c94 <_stogir.terminal.inputs+0x208>
    9c14:      	cmp	x4, x6
    9c18:      	b.gt	0x9ca4 <_stogir.terminal.inputs+0x218>
    9c1c:      	lsl	x4, x5, #2
    9c20:      	ldr	x4, [x0, #0x50]
    9c24:      	add	x4, x4, x5, lsl #2
    9c28:      	ldr	w4, [x4]
    9c2c:      	sxtw	x4, w4
    9c30:      	cmp	x4, #0x0
    9c34:      	cset	w4, gt
    9c38:      	ubfx	x4, x4, #0, #8
    9c3c:      	b	0x9ca8 <_stogir.terminal.inputs+0x21c>
    9c40:      	cmp	x2, #0x0
    9c44:      	b.le	0x9c78 <_stogir.terminal.inputs+0x1ec>
    9c48:      	uxtb	w4, w4
    9c4c:      	cmp	x4, #0x83
    9c50:      	cset	w1, lt
    9c54:      	uxtb	w16, w1
    9c58:      	cmp	w16, wzr
    9c5c:      	b.eq	0x9cac <_stogir.terminal.inputs+0x220>
    9c60:      	adrp	x16, 0x9000 <_stogir.types.size+0x114>
		0000000000009c60:  ARM64_RELOC_PAGE21	l_stogir.438
    9c64:      	ldr	x16, [x16]
		0000000000009c64:  ARM64_RELOC_PAGEOFF12	l_stogir.438
    9c68:      	orr	x2, x16, xzr
    9c6c:      	add	x2, x4, x2
    9c70:      	ldrb	w2, [x2]
    9c74:      	b	0x9cb0 <_stogir.terminal.inputs+0x224>
    9c78:      	adrp	x16, 0x9000 <_stogir.types.size+0x114>
		0000000000009c78:  ARM64_RELOC_PAGE21	l_stogir.439
    9c7c:      	ldr	x16, [x16]
		0000000000009c7c:  ARM64_RELOC_PAGEOFF12	l_stogir.439
    9c80:      	orr	x0, x16, xzr
    9c84:      	mov	x1, x0
    9c88:      	mov	x0, #0x1                ; =1
    9c8c:      	mov	x2, #0x2c               ; =44
    9c90:      	b	0x9ba0 <_stogir.terminal.inputs+0x114>
    9c94:      	movz	x4, #0x0, lsl #48
    9c98:      	b	0x9bc4 <_stogir.terminal.inputs+0x138>
    9c9c:      	movz	x4, #0x0, lsl #48
    9ca0:      	b	0x9bf0 <_stogir.terminal.inputs+0x164>
    9ca4:      	movz	x4, #0x0, lsl #48
    9ca8:      	b	0x9c98 <_stogir.terminal.inputs+0x20c>
    9cac:      	movz	x2, #0x0, lsl #48
    9cb0:      	uxtb	w2, w2
    9cb4:      	and	x2, x2, #0x1
    9cb8:      	uxtb	w2, w2
    9cbc:      	cmp	x2, #0x0
    9cc0:      	b.eq	0x9c78 <_stogir.terminal.inputs+0x1ec>
    9cc4:      	uxtb	w16, w1
    9cc8:      	cmp	w16, wzr
    9ccc:      	b.eq	0x9ce8 <_stogir.terminal.inputs+0x25c>
    9cd0:      	adrp	x16, 0x9000 <_stogir.types.size+0x114>
		0000000000009cd0:  ARM64_RELOC_PAGE21	l_stogir.438
    9cd4:      	ldr	x16, [x16]
		0000000000009cd4:  ARM64_RELOC_PAGEOFF12	l_stogir.438
    9cd8:      	orr	x1, x16, xzr
    9cdc:      	add	x1, x4, x1
    9ce0:      	ldrb	w1, [x1]
    9ce4:      	b	0x9cec <_stogir.terminal.inputs+0x260>
    9ce8:      	movz	x1, #0x0, lsl #48
    9cec:      	uxtb	w1, w1
    9cf0:      	and	x1, x1, #0x4
    9cf4:      	uxtb	w1, w1
    9cf8:      	cmp	x1, #0x0
    9cfc:      	cset	w1, eq
    9d00:      	uxtb	w16, w1
    9d04:      	cmp	w16, wzr
    9d08:      	cset	x1, eq
    9d0c:      	cmp	x1, #0x0
    9d10:      	b.ne	0x9c78 <_stogir.terminal.inputs+0x1ec>
    9d14:      	cmp	x3, #0x0
    9d18:      	b.ne	0x9d2c <_stogir.terminal.inputs+0x2a0>
    9d1c:      	movz	x0, #0x0, lsl #48
    9d20:      	movz	x1, #0x0, lsl #48
    9d24:      	movz	x2, #0x0, lsl #48
    9d28:      	b	0x9c90 <_stogir.terminal.inputs+0x204>
    9d2c:      	cmp	x3, #0x0
    9d30:      	cset	w1, gt
    9d34:      	movz	x16, #0x0, lsl #48
    9d38:      	sub	x2, x16, x3
    9d3c:      	sub	x4, x2, #0x1
    9d40:      	uxtb	w16, w1
    9d44:      	cmp	w16, wzr
    9d48:      	b.eq	0x9da8 <_stogir.terminal.inputs+0x31c>
    9d4c:      	ldr	x2, [x0, #0x8]
    9d50:      	cmp	x3, x2
    9d54:      	b.ge	0x9dfc <_stogir.terminal.inputs+0x370>
    9d58:      	add	x2, x0, #0x78
    9d5c:      	ldr	x2, [x2, #0x8]
    9d60:      	cmp	x3, x2
    9d64:      	b.ge	0x9ed4 <_stogir.terminal.inputs+0x448>
    9d68:      	lsl	x2, x3, #2
    9d6c:      	ldr	x2, [x0, #0x78]
    9d70:      	add	x2, x2, x3, lsl #2
    9d74:      	ldr	w2, [x2]
    9d78:      	sxtw	x2, w2
    9d7c:      	cmp	x2, #0x0
    9d80:      	cset	w2, ge
    9d84:      	ubfx	x2, x2, #0, #8
    9d88:      	b	0x9ed8 <_stogir.terminal.inputs+0x44c>
    9d8c:      	adrp	x16, 0x9000 <_stogir.types.size+0x114>
		0000000000009d8c:  ARM64_RELOC_PAGE21	l_stogir.440
    9d90:      	ldr	x16, [x16]
		0000000000009d90:  ARM64_RELOC_PAGEOFF12	l_stogir.440
    9d94:      	orr	x0, x16, xzr
    9d98:      	mov	x1, x0
    9d9c:      	mov	x0, #0x1                ; =1
    9da0:      	mov	x2, #0x2e               ; =46
    9da4:      	b	0x9d28 <_stogir.terminal.inputs+0x29c>
    9da8:      	cmp	x3, #0x0
    9dac:      	b.ge	0x9e04 <_stogir.terminal.inputs+0x378>
    9db0:      	add	x5, x0, #0x28
    9db4:      	add	x6, x0, #0x50
    9db8:      	ldr	x5, [x5, #0x8]
    9dbc:      	ldr	x6, [x6, #0x8]
    9dc0:      	cmp	x5, x6
    9dc4:      	b.ne	0x9ecc <_stogir.terminal.inputs+0x440>
    9dc8:      	cmp	x2, x5
    9dcc:      	b.gt	0x9edc <_stogir.terminal.inputs+0x450>
    9dd0:      	lsl	x2, x4, #2
    9dd4:      	ldr	x2, [x0, #0x50]
    9dd8:      	add	x2, x2, x4, lsl #2
    9ddc:      	ldr	w2, [x2]
    9de0:      	sxtw	x2, w2
    9de4:      	cmp	x2, #0x0
    9de8:      	cset	w2, gt
    9dec:      	ubfx	x2, x2, #0, #8
    9df0:      	b	0x9ee0 <_stogir.terminal.inputs+0x454>
    9df4:      	brk	#0
    9df8:      	b	0x9df4 <_stogir.terminal.inputs+0x368>
    9dfc:      	movz	x2, #0x0, lsl #48
    9e00:      	b	0x9e08 <_stogir.terminal.inputs+0x37c>
    9e04:      	movz	x2, #0x0, lsl #48
    9e08:      	cmp	x2, #0x0
    9e0c:      	b.eq	0x9e4c <_stogir.terminal.inputs+0x3c0>
    9e10:      	uxtb	w16, w1
    9e14:      	cmp	w16, wzr
    9e18:      	b.eq	0x9e30 <_stogir.terminal.inputs+0x3a4>
    9e1c:      	lsl	x1, x3, #4
    9e20:      	ldr	x0, [x0]
    9e24:      	add	x0, x0, x3, lsl #4
    9e28:      	ldr	x0, [x0]
    9e2c:      	b	0x9e40 <_stogir.terminal.inputs+0x3b4>
    9e30:      	lsl	x1, x4, #4
    9e34:      	ldr	x0, [x0, #0x28]
    9e38:      	add	x0, x0, x4, lsl #4
    9e3c:      	ldr	x0, [x0]
    9e40:      	mov	x1, x0
    9e44:      	mov	x0, #0x1                ; =1
    9e48:      	b	0x9e54 <_stogir.terminal.inputs+0x3c8>
    9e4c:      	movz	x0, #0x0, lsl #48
    9e50:      	movz	x1, #0x0, lsl #48
    9e54:      	lsr	w0, w0, #0
    9e58:      	lsr	x16, x0, #0
    9e5c:      	cmp	x16, #0x1
    9e60:      	b.eq	0x9e7c <_stogir.terminal.inputs+0x3f0>
    9e64:      	b.lo	0x9e6c <_stogir.terminal.inputs+0x3e0>
    9e68:      	b	0x9e80 <_stogir.terminal.inputs+0x3f4>
    9e6c:      	cmp	x16, #0x0
    9e70:      	b.eq	0x9e78 <_stogir.terminal.inputs+0x3ec>
    9e74:      	b	0x9e80 <_stogir.terminal.inputs+0x3f4>
    9e78:      	b	0x9e84 <_stogir.terminal.inputs+0x3f8>
    9e7c:      	b	0x9ea0 <_stogir.terminal.inputs+0x414>
    9e80:      	b	0x9f24 <_stogir.terminal.inputs+0x498>
    9e84:      	adrp	x16, 0x9000 <_stogir.types.size+0x114>
		0000000000009e84:  ARM64_RELOC_PAGE21	l_stogir.441
    9e88:      	ldr	x16, [x16]
		0000000000009e88:  ARM64_RELOC_PAGEOFF12	l_stogir.441
    9e8c:      	orr	x0, x16, xzr
    9e90:      	mov	x1, x0
    9e94:      	mov	x0, #0x1                ; =1
    9e98:      	mov	x2, #0x1d               ; =29
    9e9c:      	b	0x9da4 <_stogir.terminal.inputs+0x318>
    9ea0:      	cmp	x3, #0x0
    9ea4:      	b.le	0x9d8c <_stogir.terminal.inputs+0x300>
    9ea8:      	uxtb	w1, w1
    9eac:      	cmp	x1, #0x83
    9eb0:      	b.ge	0x9ee4 <_stogir.terminal.inputs+0x458>
    9eb4:      	adrp	x16, 0x9000 <_stogir.types.size+0x114>
		0000000000009eb4:  ARM64_RELOC_PAGE21	l_stogir.438
    9eb8:      	ldr	x16, [x16]
		0000000000009eb8:  ARM64_RELOC_PAGEOFF12	l_stogir.438
    9ebc:      	orr	x0, x16, xzr
    9ec0:      	add	x0, x1, x0
    9ec4:      	ldrb	w0, [x0]
    9ec8:      	b	0x9ee8 <_stogir.terminal.inputs+0x45c>
    9ecc:      	movz	x2, #0x0, lsl #48
    9ed0:      	b	0x9e08 <_stogir.terminal.inputs+0x37c>
    9ed4:      	movz	x2, #0x0, lsl #48
    9ed8:      	b	0x9e00 <_stogir.terminal.inputs+0x374>
    9edc:      	movz	x2, #0x0, lsl #48
    9ee0:      	b	0x9ed0 <_stogir.terminal.inputs+0x444>
    9ee4:      	movz	x0, #0x0, lsl #48
    9ee8:      	uxtb	w0, w0
    9eec:      	and	x0, x0, #0x8
    9ef0:      	uxtb	w0, w0
    9ef4:      	cmp	x0, #0x0
    9ef8:      	cset	w0, eq
    9efc:      	uxtb	w16, w0
    9f00:      	cmp	w16, wzr
    9f04:      	cset	x0, eq
    9f08:      	cmp	x0, #0x0
    9f0c:      	b.eq	0x9d8c <_stogir.terminal.inputs+0x300>
    9f10:      	and	x0, x3, #0xffffffff
    9f14:      	mov	x1, x0
    9f18:      	movz	x0, #0x0, lsl #48
    9f1c:      	movz	x2, #0x0, lsl #48
    9f20:      	b	0x9da4 <_stogir.terminal.inputs+0x318>
    9f24:      	brk	#0
    9f28:      	b	0x9f24 <_stogir.terminal.inputs+0x498>

0000000000009f2c <_stogir.switch.switch-inputs>:
    9f2c:      	sxtw	x1, w1
    9f30:      	cmp	x1, #0x0
    9f34:      	cset	w3, gt
    9f38:      	movz	x16, #0x0, lsl #48
    9f3c:      	sub	x4, x16, x1
    9f40:      	sub	x5, x4, #0x1
    9f44:      	uxtb	w16, w3
    9f48:      	cmp	w16, wzr
    9f4c:      	b.eq	0x9f90 <_stogir.switch.switch-inputs+0x64>
    9f50:      	ldr	x4, [x0, #0x8]
    9f54:      	cmp	x1, x4
    9f58:      	b.ge	0xa000 <_stogir.switch.switch-inputs+0xd4>
    9f5c:      	add	x4, x0, #0x78
    9f60:      	ldr	x4, [x4, #0x8]
    9f64:      	cmp	x1, x4
    9f68:      	b.ge	0xa0e8 <_stogir.switch.switch-inputs+0x1bc>
    9f6c:      	lsl	x4, x1, #2
    9f70:      	ldr	x4, [x0, #0x78]
    9f74:      	add	x4, x4, x1, lsl #2
    9f78:      	ldr	w4, [x4]
    9f7c:      	sxtw	x4, w4
    9f80:      	cmp	x4, #0x0
    9f84:      	cset	w4, ge
    9f88:      	ubfx	x4, x4, #0, #8
    9f8c:      	b	0xa0ec <_stogir.switch.switch-inputs+0x1c0>
    9f90:      	cmp	x1, #0x0
    9f94:      	b.ge	0xa008 <_stogir.switch.switch-inputs+0xdc>
    9f98:      	add	x6, x0, #0x28
    9f9c:      	add	x7, x0, #0x50
    9fa0:      	ldr	x6, [x6, #0x8]
    9fa4:      	ldr	x7, [x7, #0x8]
    9fa8:      	cmp	x6, x7
    9fac:      	b.ne	0x9fdc <_stogir.switch.switch-inputs+0xb0>
    9fb0:      	cmp	x4, x6
    9fb4:      	b.gt	0xa0f0 <_stogir.switch.switch-inputs+0x1c4>
    9fb8:      	lsl	x4, x5, #2
    9fbc:      	ldr	x4, [x0, #0x50]
    9fc0:      	add	x4, x4, x5, lsl #2
    9fc4:      	ldr	w4, [x4]
    9fc8:      	sxtw	x4, w4
    9fcc:      	cmp	x4, #0x0
    9fd0:      	cset	w4, gt
    9fd4:      	ubfx	x4, x4, #0, #8
    9fd8:      	b	0xa0f4 <_stogir.switch.switch-inputs+0x1c8>
    9fdc:      	movz	x4, #0x0, lsl #48
    9fe0:      	b	0xa00c <_stogir.switch.switch-inputs+0xe0>
    9fe4:      	adrp	x16, 0x9000 <_stogir.types.size+0x114>
		0000000000009fe4:  ARM64_RELOC_PAGE21	l_stogir.442
    9fe8:      	ldr	x16, [x16]
		0000000000009fe8:  ARM64_RELOC_PAGEOFF12	l_stogir.442
    9fec:      	orr	x0, x16, xzr
    9ff0:      	mov	x1, x0
    9ff4:      	mov	x0, #0x1                ; =1
    9ff8:      	mov	x2, #0x16               ; =22
    9ffc:      	b	0xa0a0 <_stogir.switch.switch-inputs+0x174>
    a000:      	movz	x4, #0x0, lsl #48
    a004:      	b	0xa00c <_stogir.switch.switch-inputs+0xe0>
    a008:      	movz	x4, #0x0, lsl #48
    a00c:      	cmp	x4, #0x0
    a010:      	b.eq	0xa050 <_stogir.switch.switch-inputs+0x124>
    a014:      	uxtb	w16, w3
    a018:      	cmp	w16, wzr
    a01c:      	b.eq	0xa034 <_stogir.switch.switch-inputs+0x108>
    a020:      	lsl	x3, x1, #4
    a024:      	ldr	x3, [x0]
    a028:      	add	x3, x3, x1, lsl #4
    a02c:      	ldr	x3, [x3]
    a030:      	b	0xa044 <_stogir.switch.switch-inputs+0x118>
    a034:      	lsl	x3, x5, #4
    a038:      	ldr	x3, [x0, #0x28]
    a03c:      	add	x3, x3, x5, lsl #4
    a040:      	ldr	x3, [x3]
    a044:      	mov	x4, x3
    a048:      	mov	x3, #0x1                ; =1
    a04c:      	b	0xa058 <_stogir.switch.switch-inputs+0x12c>
    a050:      	movz	x3, #0x0, lsl #48
    a054:      	movz	x4, #0x0, lsl #48
    a058:      	lsr	w3, w3, #0
    a05c:      	lsr	x16, x3, #0
    a060:      	cmp	x16, #0x1
    a064:      	b.eq	0xa080 <_stogir.switch.switch-inputs+0x154>
    a068:      	b.lo	0xa070 <_stogir.switch.switch-inputs+0x144>
    a06c:      	b	0xa084 <_stogir.switch.switch-inputs+0x158>
    a070:      	cmp	x16, #0x0
    a074:      	b.eq	0xa07c <_stogir.switch.switch-inputs+0x150>
    a078:      	b	0xa084 <_stogir.switch.switch-inputs+0x158>
    a07c:      	b	0xa088 <_stogir.switch.switch-inputs+0x15c>
    a080:      	b	0xa0b0 <_stogir.switch.switch-inputs+0x184>
    a084:      	b	0xa318 <_stogir.switch.switch-inputs+0x3ec>
    a088:      	adrp	x16, 0xa000 <_stogir.switch.switch-inputs+0xd4>
		000000000000a088:  ARM64_RELOC_PAGE21	l_stogir.443
    a08c:      	ldr	x16, [x16]
		000000000000a08c:  ARM64_RELOC_PAGEOFF12	l_stogir.443
    a090:      	orr	x0, x16, xzr
    a094:      	mov	x1, x0
    a098:      	mov	x0, #0x1                ; =1
    a09c:      	mov	x2, #0x16               ; =22
    a0a0:      	str	x0, [x8]
    a0a4:      	str	x1, [x8, #0x8]
    a0a8:      	str	x2, [x8, #0x10]
    a0ac:      	ret
    a0b0:      	cmp	x1, #0x0
    a0b4:      	b.le	0x9fe4 <_stogir.switch.switch-inputs+0xb8>
    a0b8:      	uxtb	w4, w4
    a0bc:      	cmp	x4, #0x83
    a0c0:      	cset	w1, lt
    a0c4:      	uxtb	w16, w1
    a0c8:      	cmp	w16, wzr
    a0cc:      	b.eq	0xa0f8 <_stogir.switch.switch-inputs+0x1cc>
    a0d0:      	adrp	x16, 0xa000 <_stogir.switch.switch-inputs+0xd4>
		000000000000a0d0:  ARM64_RELOC_PAGE21	l_stogir.444
    a0d4:      	ldr	x16, [x16]
		000000000000a0d4:  ARM64_RELOC_PAGEOFF12	l_stogir.444
    a0d8:      	orr	x3, x16, xzr
    a0dc:      	add	x3, x4, x3
    a0e0:      	ldrb	w3, [x3]
    a0e4:      	b	0xa0fc <_stogir.switch.switch-inputs+0x1d0>
    a0e8:      	movz	x4, #0x0, lsl #48
    a0ec:      	b	0xa004 <_stogir.switch.switch-inputs+0xd8>
    a0f0:      	movz	x4, #0x0, lsl #48
    a0f4:      	b	0x9fe0 <_stogir.switch.switch-inputs+0xb4>
    a0f8:      	movz	x3, #0x0, lsl #48
    a0fc:      	uxtb	w3, w3
    a100:      	and	x3, x3, #0x1
    a104:      	uxtb	w3, w3
    a108:      	cmp	x3, #0x0
    a10c:      	b.eq	0x9fe4 <_stogir.switch.switch-inputs+0xb8>
    a110:      	uxtb	w16, w1
    a114:      	cmp	w16, wzr
    a118:      	b.eq	0xa134 <_stogir.switch.switch-inputs+0x208>
    a11c:      	adrp	x16, 0xa000 <_stogir.switch.switch-inputs+0xd4>
		000000000000a11c:  ARM64_RELOC_PAGE21	l_stogir.444
    a120:      	ldr	x16, [x16]
		000000000000a120:  ARM64_RELOC_PAGEOFF12	l_stogir.444
    a124:      	orr	x1, x16, xzr
    a128:      	add	x1, x4, x1
    a12c:      	ldrb	w1, [x1]
    a130:      	b	0xa138 <_stogir.switch.switch-inputs+0x20c>
    a134:      	movz	x1, #0x0, lsl #48
    a138:      	uxtb	w1, w1
    a13c:      	and	x1, x1, #0x4
    a140:      	uxtb	w1, w1
    a144:      	cmp	x1, #0x0
    a148:      	cset	w1, eq
    a14c:      	uxtb	w16, w1
    a150:      	cmp	w16, wzr
    a154:      	cset	x1, eq
    a158:      	cmp	x1, #0x0
    a15c:      	b.ne	0x9fe4 <_stogir.switch.switch-inputs+0xb8>
    a160:      	sxtw	x2, w2
    a164:      	cmp	x2, #0x0
    a168:      	cset	w1, gt
    a16c:      	movz	x16, #0x0, lsl #48
    a170:      	sub	x3, x16, x2
    a174:      	sub	x4, x3, #0x1
    a178:      	uxtb	w16, w1
    a17c:      	cmp	w16, wzr
    a180:      	b.eq	0xa1e0 <_stogir.switch.switch-inputs+0x2b4>
    a184:      	ldr	x3, [x0, #0x8]
    a188:      	cmp	x2, x3
    a18c:      	b.ge	0xa22c <_stogir.switch.switch-inputs+0x300>
    a190:      	add	x3, x0, #0x78
    a194:      	ldr	x3, [x3, #0x8]
    a198:      	cmp	x2, x3
    a19c:      	b.ge	0xa310 <_stogir.switch.switch-inputs+0x3e4>
    a1a0:      	lsl	x3, x2, #2
    a1a4:      	ldr	x3, [x0, #0x78]
    a1a8:      	add	x3, x3, x2, lsl #2
    a1ac:      	ldr	w3, [x3]
    a1b0:      	sxtw	x3, w3
    a1b4:      	cmp	x3, #0x0
    a1b8:      	cset	w3, ge
    a1bc:      	ubfx	x3, x3, #0, #8
    a1c0:      	b	0xa314 <_stogir.switch.switch-inputs+0x3e8>
    a1c4:      	adrp	x16, 0xa000 <_stogir.switch.switch-inputs+0xd4>
		000000000000a1c4:  ARM64_RELOC_PAGE21	l_stogir.445
    a1c8:      	ldr	x16, [x16]
		000000000000a1c8:  ARM64_RELOC_PAGEOFF12	l_stogir.445
    a1cc:      	orr	x0, x16, xzr
    a1d0:      	mov	x1, x0
    a1d4:      	mov	x0, #0x1                ; =1
    a1d8:      	mov	x2, #0x20               ; =32
    a1dc:      	b	0x9ffc <_stogir.switch.switch-inputs+0xd0>
    a1e0:      	cmp	x2, #0x0
    a1e4:      	b.ge	0xa234 <_stogir.switch.switch-inputs+0x308>
    a1e8:      	add	x5, x0, #0x28
    a1ec:      	add	x6, x0, #0x50
    a1f0:      	ldr	x5, [x5, #0x8]
    a1f4:      	ldr	x6, [x6, #0x8]
    a1f8:      	cmp	x5, x6
    a1fc:      	b.ne	0xa308 <_stogir.switch.switch-inputs+0x3dc>
    a200:      	cmp	x3, x5
    a204:      	b.gt	0xa320 <_stogir.switch.switch-inputs+0x3f4>
    a208:      	lsl	x3, x4, #2
    a20c:      	ldr	x3, [x0, #0x50]
    a210:      	add	x3, x3, x4, lsl #2
    a214:      	ldr	w3, [x3]
    a218:      	sxtw	x3, w3
    a21c:      	cmp	x3, #0x0
    a220:      	cset	w3, gt
    a224:      	ubfx	x3, x3, #0, #8
    a228:      	b	0xa324 <_stogir.switch.switch-inputs+0x3f8>
    a22c:      	movz	x3, #0x0, lsl #48
    a230:      	b	0xa238 <_stogir.switch.switch-inputs+0x30c>
    a234:      	movz	x3, #0x0, lsl #48
    a238:      	cmp	x3, #0x0
    a23c:      	b.eq	0xa27c <_stogir.switch.switch-inputs+0x350>
    a240:      	uxtb	w16, w1
    a244:      	cmp	w16, wzr
    a248:      	b.eq	0xa260 <_stogir.switch.switch-inputs+0x334>
    a24c:      	lsl	x1, x2, #4
    a250:      	ldr	x0, [x0]
    a254:      	add	x0, x0, x2, lsl #4
    a258:      	ldr	x0, [x0]
    a25c:      	b	0xa270 <_stogir.switch.switch-inputs+0x344>
    a260:      	lsl	x1, x4, #4
    a264:      	ldr	x0, [x0, #0x28]
    a268:      	add	x0, x0, x4, lsl #4
    a26c:      	ldr	x0, [x0]
    a270:      	mov	x1, x0
    a274:      	mov	x0, #0x1                ; =1
    a278:      	b	0xa284 <_stogir.switch.switch-inputs+0x358>
    a27c:      	movz	x0, #0x0, lsl #48
    a280:      	movz	x1, #0x0, lsl #48
    a284:      	lsr	w0, w0, #0
    a288:      	lsr	x16, x0, #0
    a28c:      	cmp	x16, #0x1
    a290:      	b.eq	0xa2ac <_stogir.switch.switch-inputs+0x380>
    a294:      	b.lo	0xa29c <_stogir.switch.switch-inputs+0x370>
    a298:      	b	0xa2b0 <_stogir.switch.switch-inputs+0x384>
    a29c:      	cmp	x16, #0x0
    a2a0:      	b.eq	0xa2a8 <_stogir.switch.switch-inputs+0x37c>
    a2a4:      	b	0xa2b0 <_stogir.switch.switch-inputs+0x384>
    a2a8:      	b	0xa2b4 <_stogir.switch.switch-inputs+0x388>
    a2ac:      	b	0xa2d0 <_stogir.switch.switch-inputs+0x3a4>
    a2b0:      	b	0xa328 <_stogir.switch.switch-inputs+0x3fc>
    a2b4:      	adrp	x16, 0xa000 <_stogir.switch.switch-inputs+0xd4>
		000000000000a2b4:  ARM64_RELOC_PAGE21	l_stogir.446
    a2b8:      	ldr	x16, [x16]
		000000000000a2b8:  ARM64_RELOC_PAGEOFF12	l_stogir.446
    a2bc:      	orr	x0, x16, xzr
    a2c0:      	mov	x1, x0
    a2c4:      	mov	x0, #0x1                ; =1
    a2c8:      	mov	x2, #0x17               ; =23
    a2cc:      	b	0xa1dc <_stogir.switch.switch-inputs+0x2b0>
    a2d0:      	lsr	w0, w1, #0
    a2d4:      	ubfx	x0, x0, #8, #8
    a2d8:      	cmp	x0, #0x1
    a2dc:      	b.lt	0xa1c4 <_stogir.switch.switch-inputs+0x298>
    a2e0:      	cmp	x0, #0xb
    a2e4:      	b.gt	0xa1c4 <_stogir.switch.switch-inputs+0x298>
    a2e8:      	uxtb	w1, w1
    a2ec:      	cmp	x1, #0x48
    a2f0:      	b.eq	0xa1c4 <_stogir.switch.switch-inputs+0x298>
    a2f4:      	and	x0, x0, #0xffffffff
    a2f8:      	mov	x1, x0
    a2fc:      	movz	x0, #0x0, lsl #48
    a300:      	movz	x2, #0x0, lsl #48
    a304:      	b	0xa1dc <_stogir.switch.switch-inputs+0x2b0>
    a308:      	movz	x3, #0x0, lsl #48
    a30c:      	b	0xa238 <_stogir.switch.switch-inputs+0x30c>
    a310:      	movz	x3, #0x0, lsl #48
    a314:      	b	0xa230 <_stogir.switch.switch-inputs+0x304>
    a318:      	brk	#0
    a31c:      	b	0xa318 <_stogir.switch.switch-inputs+0x3ec>
    a320:      	movz	x3, #0x0, lsl #48
    a324:      	b	0xa30c <_stogir.switch.switch-inputs+0x3e0>
    a328:      	brk	#0
    a32c:      	b	0xa328 <_stogir.switch.switch-inputs+0x3fc>

000000000000a330 <_stogir.switch.case-inputs>:
    a330:      	sub	sp, sp, #0xb0
    a334:      	str	x29, [sp]
    a338:      	str	x30, [sp, #0x8]
    a33c:      	mov	x29, sp
    a340:      	str	x19, [sp, #0x70]
    a344:      	str	x20, [sp, #0x78]
    a348:      	str	x21, [sp, #0x80]
    a34c:      	str	x22, [sp, #0x88]
    a350:      	str	x23, [sp, #0x90]
    a354:      	str	x24, [sp, #0x98]
    a358:      	str	x25, [sp, #0xa0]
    a35c:      	str	x26, [sp, #0xa8]
    a360:      	sxtw	x2, w2
    a364:      	lsl	x5, x2, #2
    a368:      	cmp	x2, #0x0
    a36c:      	cset	w6, gt
    a370:      	movz	x16, #0x0, lsl #48
    a374:      	sub	x7, x16, x2
    a378:      	sub	x9, x7, #0x1
    a37c:      	uxtb	w16, w6
    a380:      	cmp	w16, wzr
    a384:      	b.eq	0xa3c4 <_stogir.switch.case-inputs+0x94>
    a388:      	ldr	x7, [x0, #0x8]
    a38c:      	cmp	x2, x7
    a390:      	b.ge	0xa418 <_stogir.switch.case-inputs+0xe8>
    a394:      	add	x7, x0, #0x78
    a398:      	ldr	x7, [x7, #0x8]
    a39c:      	cmp	x2, x7
    a3a0:      	b.ge	0xa548 <_stogir.switch.case-inputs+0x218>
    a3a4:      	ldr	x7, [x0, #0x78]
    a3a8:      	add	x7, x5, x7
    a3ac:      	ldr	w7, [x7]
    a3b0:      	sxtw	x7, w7
    a3b4:      	cmp	x7, #0x0
    a3b8:      	cset	w7, ge
    a3bc:      	ubfx	x7, x7, #0, #8
    a3c0:      	b	0xa54c <_stogir.switch.case-inputs+0x21c>
    a3c4:      	cmp	x2, #0x0
    a3c8:      	b.ge	0xa420 <_stogir.switch.case-inputs+0xf0>
    a3cc:      	add	x10, x0, #0x28
    a3d0:      	add	x11, x0, #0x50
    a3d4:      	ldr	x10, [x10, #0x8]
    a3d8:      	ldr	x11, [x11, #0x8]
    a3dc:      	cmp	x10, x11
    a3e0:      	b.ne	0xa410 <_stogir.switch.case-inputs+0xe0>
    a3e4:      	cmp	x7, x10
    a3e8:      	b.gt	0xa61c <_stogir.switch.case-inputs+0x2ec>
    a3ec:      	lsl	x7, x9, #2
    a3f0:      	ldr	x7, [x0, #0x50]
    a3f4:      	add	x7, x7, x9, lsl #2
    a3f8:      	ldr	w7, [x7]
    a3fc:      	sxtw	x7, w7
    a400:      	cmp	x7, #0x0
    a404:      	cset	w7, gt
    a408:      	ubfx	x7, x7, #0, #8
    a40c:      	b	0xa620 <_stogir.switch.case-inputs+0x2f0>
    a410:      	movz	x7, #0x0, lsl #48
    a414:      	b	0xa424 <_stogir.switch.case-inputs+0xf4>
    a418:      	movz	x7, #0x0, lsl #48
    a41c:      	b	0xa424 <_stogir.switch.case-inputs+0xf4>
    a420:      	movz	x7, #0x0, lsl #48
    a424:      	cmp	x7, #0x0
    a428:      	b.eq	0xa48c <_stogir.switch.case-inputs+0x15c>
    a42c:      	uxtb	w16, w6
    a430:      	cmp	w16, wzr
    a434:      	b.eq	0xa45c <_stogir.switch.case-inputs+0x12c>
    a438:      	lsl	x6, x2, #4
    a43c:      	ldr	x6, [x0]
    a440:      	add	x6, x6, x2, lsl #4
    a444:      	ldr	x7, [x6]
    a448:      	ldr	x6, [x6, #0x8]
    a44c:      	fmov	d31, x6
    a450:      	mov	x6, x7
    a454:      	fmov	x7, d31
    a458:      	b	0xa47c <_stogir.switch.case-inputs+0x14c>
    a45c:      	lsl	x6, x9, #4
    a460:      	ldr	x6, [x0, #0x28]
    a464:      	add	x6, x6, x9, lsl #4
    a468:      	ldr	x7, [x6]
    a46c:      	ldr	x6, [x6, #0x8]
    a470:      	fmov	d31, x6
    a474:      	mov	x6, x7
    a478:      	fmov	x7, d31
    a47c:      	mov	x9, x7
    a480:      	mov	x7, x6
    a484:      	mov	x6, #0x1                ; =1
    a488:      	b	0xa498 <_stogir.switch.case-inputs+0x168>
    a48c:      	movz	x6, #0x0, lsl #48
    a490:      	movz	x7, #0x0, lsl #48
    a494:      	movz	x9, #0x0, lsl #48
    a498:      	lsr	w6, w6, #0
    a49c:      	lsr	x16, x6, #0
    a4a0:      	cmp	x16, #0x1
    a4a4:      	b.eq	0xa4c0 <_stogir.switch.case-inputs+0x190>
    a4a8:      	b.lo	0xa4b0 <_stogir.switch.case-inputs+0x180>
    a4ac:      	b	0xa4c4 <_stogir.switch.case-inputs+0x194>
    a4b0:      	cmp	x16, #0x0
    a4b4:      	b.eq	0xa4bc <_stogir.switch.case-inputs+0x18c>
    a4b8:      	b	0xa4c4 <_stogir.switch.case-inputs+0x194>
    a4bc:      	b	0xa4c8 <_stogir.switch.case-inputs+0x198>
    a4c0:      	b	0xa520 <_stogir.switch.case-inputs+0x1f0>
    a4c4:      	b	0xa624 <_stogir.switch.case-inputs+0x2f4>
    a4c8:      	adrp	x16, 0xa000 <_stogir.switch.switch-inputs+0xd4>
		000000000000a4c8:  ARM64_RELOC_PAGE21	l_stogir.447
    a4cc:      	ldr	x16, [x16]
		000000000000a4cc:  ARM64_RELOC_PAGEOFF12	l_stogir.447
    a4d0:      	orr	x0, x16, xzr
    a4d4:      	mov	x21, x8
    a4d8:      	mov	x1, x0
    a4dc:      	mov	x0, #0x1                ; =1
    a4e0:      	mov	x2, #0x1a               ; =26
    a4e4:      	str	x0, [x21]
    a4e8:      	str	x1, [x21, #0x8]
    a4ec:      	str	x2, [x21, #0x10]
    a4f0:      	ldr	x19, [sp, #0x70]
    a4f4:      	ldr	x20, [sp, #0x78]
    a4f8:      	ldr	x21, [sp, #0x80]
    a4fc:      	ldr	x22, [sp, #0x88]
    a500:      	ldr	x23, [sp, #0x90]
    a504:      	ldr	x24, [sp, #0x98]
    a508:      	ldr	x25, [sp, #0xa0]
    a50c:      	ldr	x26, [sp, #0xa8]
    a510:      	ldr	x29, [sp]
    a514:      	ldr	x30, [sp, #0x8]
    a518:      	add	sp, sp, #0xb0
    a51c:      	ret
    a520:      	cmp	x2, #0x0
    a524:      	b.gt	0xa550 <_stogir.switch.case-inputs+0x220>
    a528:      	mov	x21, x8
    a52c:      	adrp	x16, 0xa000 <_stogir.switch.switch-inputs+0xd4>
		000000000000a52c:  ARM64_RELOC_PAGE21	l_stogir.448
    a530:      	ldr	x16, [x16]
		000000000000a530:  ARM64_RELOC_PAGEOFF12	l_stogir.448
    a534:      	orr	x0, x16, xzr
    a538:      	mov	x1, x0
    a53c:      	mov	x0, #0x1                ; =1
    a540:      	mov	x2, #0x1f               ; =31
    a544:      	b	0xa4e4 <_stogir.switch.case-inputs+0x1b4>
    a548:      	movz	x7, #0x0, lsl #48
    a54c:      	b	0xa41c <_stogir.switch.case-inputs+0xec>
    a550:      	uxtb	w2, w7
    a554:      	cmp	x2, #0x75
    a558:      	b.ne	0xa7b4 <_stogir.switch.case-inputs+0x484>
    a55c:      	lsr	w2, w7, #0
    a560:      	ubfx	x2, x2, #8, #8
    a564:      	cmp	x2, #0x0
    a568:      	b.ne	0xa7bc <_stogir.switch.case-inputs+0x48c>
    a56c:      	ldr	x2, [x0, #0x78]
    a570:      	add	x2, x5, x2
    a574:      	ldr	w2, [x2]
    a578:      	sxtw	x2, w2
    a57c:      	cmp	x2, #0x2
    a580:      	b.ne	0xa7c4 <_stogir.switch.case-inputs+0x494>
    a584:      	sxtw	x19, w1
    a588:      	cmp	x19, #0x6d
    a58c:      	b.lt	0xa7cc <_stogir.switch.case-inputs+0x49c>
    a590:      	cmp	x19, #0x6f
    a594:      	b.gt	0xa7d4 <_stogir.switch.case-inputs+0x4a4>
    a598:      	add	x16, sp, #0x10
    a59c:      	orr	x20, x16, xzr
    a5a0:      	lsr	w9, w9, #0
    a5a4:      	lsr	x1, x7, #32
    a5a8:      	lsr	w9, w9, #0
    a5ac:      	lsr	w1, w1, #0
    a5b0:      	mov	w2, w9
    a5b4:      	mov	x21, x8
    a5b8:      	add	x8, sp, #0x10
    a5bc:      	mov	x22, x0
    a5c0:      	mov	w23, w3
    a5c4:      	mov	w24, w4
    a5c8:      	bl	0xa5c8 <_stogir.switch.case-inputs+0x298>
		000000000000a5c8:  ARM64_RELOC_BRANCH26	_stogir.switch.switch-inputs
    a5cc:      	add	x16, sp, #0x10
    a5d0:      	ldr	w0, [x16]
    a5d4:      	lsr	x16, x0, #0
    a5d8:      	cmp	x16, #0x1
    a5dc:      	b.eq	0xa5f8 <_stogir.switch.case-inputs+0x2c8>
    a5e0:      	b.lo	0xa5e8 <_stogir.switch.case-inputs+0x2b8>
    a5e4:      	b	0xa5fc <_stogir.switch.case-inputs+0x2cc>
    a5e8:      	cmp	x16, #0x0
    a5ec:      	b.eq	0xa5f4 <_stogir.switch.case-inputs+0x2c4>
    a5f0:      	b	0xa5fc <_stogir.switch.case-inputs+0x2cc>
    a5f4:      	b	0xa62c <_stogir.switch.case-inputs+0x2fc>
    a5f8:      	b	0xa600 <_stogir.switch.case-inputs+0x2d0>
    a5fc:      	b	0xa79c <_stogir.switch.case-inputs+0x46c>
    a600:      	add	x0, x20, #0x8
    a604:      	add	x16, sp, #0x10
    a608:      	ldr	x1, [x16, #0x8]
    a60c:      	ldr	x0, [x0, #0x8]
    a610:      	mov	x2, x0
    a614:      	mov	x0, #0x1                ; =1
    a618:      	b	0xa544 <_stogir.switch.case-inputs+0x214>
    a61c:      	movz	x7, #0x0, lsl #48
    a620:      	b	0xa414 <_stogir.switch.case-inputs+0xe4>
    a624:      	brk	#0
    a628:      	b	0xa624 <_stogir.switch.case-inputs+0x2f4>
    a62c:      	add	x16, sp, #0x10
    a630:      	ldr	w20, [x16, #0x8]
    a634:      	sxtw	x0, w20
    a638:      	and	x25, x0, #0xffffffff
    a63c:      	cmp	x19, #0x6f
    a640:      	b.ne	0xa654 <_stogir.switch.case-inputs+0x324>
    a644:      	mov	x1, x25
    a648:      	movz	x0, #0x0, lsl #48
    a64c:      	movz	x2, #0x0, lsl #48
    a650:      	b	0xa618 <_stogir.switch.case-inputs+0x2e8>
    a654:      	add	x16, sp, #0x30
    a658:      	orr	x26, x16, xzr
    a65c:      	lsr	w23, w23, #0
    a660:      	lsr	w20, w20, #0
    a664:      	add	x8, sp, #0x30
    a668:      	mov	x0, x22
    a66c:      	mov	w1, w23
    a670:      	mov	w2, w20
    a674:      	bl	0xa674 <_stogir.switch.case-inputs+0x344>
		000000000000a674:  ARM64_RELOC_BRANCH26	_stogir.switch.key
    a678:      	add	x16, sp, #0x30
    a67c:      	ldr	w0, [x16]
    a680:      	lsr	x16, x0, #0
    a684:      	cmp	x16, #0x1
    a688:      	b.eq	0xa6a4 <_stogir.switch.case-inputs+0x374>
    a68c:      	b.lo	0xa694 <_stogir.switch.case-inputs+0x364>
    a690:      	b	0xa6a8 <_stogir.switch.case-inputs+0x378>
    a694:      	cmp	x16, #0x0
    a698:      	b.eq	0xa6a0 <_stogir.switch.case-inputs+0x370>
    a69c:      	b	0xa6a8 <_stogir.switch.case-inputs+0x378>
    a6a0:      	b	0xa6c8 <_stogir.switch.case-inputs+0x398>
    a6a4:      	b	0xa6ac <_stogir.switch.case-inputs+0x37c>
    a6a8:      	b	0xa7a4 <_stogir.switch.case-inputs+0x474>
    a6ac:      	add	x0, x26, #0x8
    a6b0:      	add	x16, sp, #0x30
    a6b4:      	ldr	x1, [x16, #0x8]
    a6b8:      	ldr	x0, [x0, #0x8]
    a6bc:      	mov	x2, x0
    a6c0:      	mov	x0, #0x1                ; =1
    a6c4:      	b	0xa650 <_stogir.switch.case-inputs+0x320>
    a6c8:      	add	x16, sp, #0x30
    a6cc:      	ldr	x26, [x16, #0x8]
    a6d0:      	cmp	x19, #0x6d
    a6d4:      	b.ne	0xa6f4 <_stogir.switch.case-inputs+0x3c4>
    a6d8:      	sxtw	x23, w23
    a6dc:      	mov	x0, x23
    a6e0:      	b	0xa6fc <_stogir.switch.case-inputs+0x3cc>
    a6e4:      	mov	x1, x25
    a6e8:      	movz	x0, #0x0, lsl #48
    a6ec:      	movz	x2, #0x0, lsl #48
    a6f0:      	b	0xa6c4 <_stogir.switch.case-inputs+0x394>
    a6f4:      	sxtw	x24, w24
    a6f8:      	mov	x0, x24
    a6fc:      	add	x16, sp, #0x50
    a700:      	orr	x19, x16, xzr
    a704:      	lsr	w20, w20, #0
    a708:      	lsr	w0, w0, #0
    a70c:      	add	x8, sp, #0x50
    a710:      	mov	w1, w0
    a714:      	mov	x0, x22
    a718:      	mov	w2, w20
    a71c:      	bl	0xa71c <_stogir.switch.case-inputs+0x3ec>
		000000000000a71c:  ARM64_RELOC_BRANCH26	_stogir.switch.key
    a720:      	add	x16, sp, #0x50
    a724:      	ldr	w0, [x16]
    a728:      	lsr	x16, x0, #0
    a72c:      	cmp	x16, #0x1
    a730:      	b.eq	0xa74c <_stogir.switch.case-inputs+0x41c>
    a734:      	b.lo	0xa73c <_stogir.switch.case-inputs+0x40c>
    a738:      	b	0xa750 <_stogir.switch.case-inputs+0x420>
    a73c:      	cmp	x16, #0x0
    a740:      	b.eq	0xa748 <_stogir.switch.case-inputs+0x418>
    a744:      	b	0xa750 <_stogir.switch.case-inputs+0x420>
    a748:      	b	0xa770 <_stogir.switch.case-inputs+0x440>
    a74c:      	b	0xa754 <_stogir.switch.case-inputs+0x424>
    a750:      	b	0xa7ac <_stogir.switch.case-inputs+0x47c>
    a754:      	add	x0, x19, #0x8
    a758:      	add	x16, sp, #0x50
    a75c:      	ldr	x1, [x16, #0x8]
    a760:      	ldr	x0, [x0, #0x8]
    a764:      	mov	x2, x0
    a768:      	mov	x0, #0x1                ; =1
    a76c:      	b	0xa6f0 <_stogir.switch.case-inputs+0x3c0>
    a770:      	add	x16, sp, #0x50
    a774:      	ldr	x0, [x16, #0x8]
    a778:      	cmp	x26, x0
    a77c:      	b.ls	0xa6e4 <_stogir.switch.case-inputs+0x3b4>
    a780:      	adrp	x16, 0xa000 <_stogir.switch.switch-inputs+0xd4>
		000000000000a780:  ARM64_RELOC_PAGE21	l_stogir.449
    a784:      	ldr	x16, [x16]
		000000000000a784:  ARM64_RELOC_PAGEOFF12	l_stogir.449
    a788:      	orr	x0, x16, xzr
    a78c:      	mov	x1, x0
    a790:      	mov	x0, #0x1                ; =1
    a794:      	mov	x2, #0x1a               ; =26
    a798:      	b	0xa6f0 <_stogir.switch.case-inputs+0x3c0>
    a79c:      	brk	#0
    a7a0:      	b	0xa79c <_stogir.switch.case-inputs+0x46c>
    a7a4:      	brk	#0
    a7a8:      	b	0xa7a4 <_stogir.switch.case-inputs+0x474>
    a7ac:      	brk	#0
    a7b0:      	b	0xa7ac <_stogir.switch.case-inputs+0x47c>
    a7b4:      	mov	x21, x8
    a7b8:      	b	0xa52c <_stogir.switch.case-inputs+0x1fc>
    a7bc:      	mov	x21, x8
    a7c0:      	b	0xa52c <_stogir.switch.case-inputs+0x1fc>
    a7c4:      	mov	x21, x8
    a7c8:      	b	0xa52c <_stogir.switch.case-inputs+0x1fc>
    a7cc:      	mov	x21, x8
    a7d0:      	b	0xa52c <_stogir.switch.case-inputs+0x1fc>
    a7d4:      	mov	x21, x8
    a7d8:      	b	0xa52c <_stogir.switch.case-inputs+0x1fc>

000000000000a7dc <_stogir.stack.validate-frame-address>:
    a7dc:      	sxtw	x1, w1
    a7e0:      	lsl	x2, x1, #2
    a7e4:      	cmp	x1, #0x0
    a7e8:      	cset	w3, gt
    a7ec:      	movz	x16, #0x0, lsl #48
    a7f0:      	sub	x4, x16, x1
    a7f4:      	sub	x5, x4, #0x1
    a7f8:      	uxtb	w16, w3
    a7fc:      	cmp	w16, wzr
    a800:      	b.eq	0xa840 <_stogir.stack.validate-frame-address+0x64>
    a804:      	ldr	x4, [x0, #0x8]
    a808:      	cmp	x1, x4
    a80c:      	b.ge	0xa894 <_stogir.stack.validate-frame-address+0xb8>
    a810:      	add	x4, x0, #0x78
    a814:      	ldr	x4, [x4, #0x8]
    a818:      	cmp	x1, x4
    a81c:      	b.ge	0xa9ac <_stogir.stack.validate-frame-address+0x1d0>
    a820:      	ldr	x4, [x0, #0x78]
    a824:      	add	x4, x2, x4
    a828:      	ldr	w4, [x4]
    a82c:      	sxtw	x4, w4
    a830:      	cmp	x4, #0x0
    a834:      	cset	w4, ge
    a838:      	ubfx	x4, x4, #0, #8
    a83c:      	b	0xa9b0 <_stogir.stack.validate-frame-address+0x1d4>
    a840:      	cmp	x1, #0x0
    a844:      	b.ge	0xa89c <_stogir.stack.validate-frame-address+0xc0>
    a848:      	add	x6, x0, #0x28
    a84c:      	add	x7, x0, #0x50
    a850:      	ldr	x6, [x6, #0x8]
    a854:      	ldr	x7, [x7, #0x8]
    a858:      	cmp	x6, x7
    a85c:      	b.ne	0xa88c <_stogir.stack.validate-frame-address+0xb0>
    a860:      	cmp	x4, x6
    a864:      	b.gt	0xa9b4 <_stogir.stack.validate-frame-address+0x1d8>
    a868:      	lsl	x4, x5, #2
    a86c:      	ldr	x4, [x0, #0x50]
    a870:      	add	x4, x4, x5, lsl #2
    a874:      	ldr	w4, [x4]
    a878:      	sxtw	x4, w4
    a87c:      	cmp	x4, #0x0
    a880:      	cset	w4, gt
    a884:      	ubfx	x4, x4, #0, #8
    a888:      	b	0xa9b8 <_stogir.stack.validate-frame-address+0x1dc>
    a88c:      	movz	x4, #0x0, lsl #48
    a890:      	b	0xa8a0 <_stogir.stack.validate-frame-address+0xc4>
    a894:      	movz	x4, #0x0, lsl #48
    a898:      	b	0xa8a0 <_stogir.stack.validate-frame-address+0xc4>
    a89c:      	movz	x4, #0x0, lsl #48
    a8a0:      	cmp	x4, #0x0
    a8a4:      	b.eq	0xa8e4 <_stogir.stack.validate-frame-address+0x108>
    a8a8:      	uxtb	w16, w3
    a8ac:      	cmp	w16, wzr
    a8b0:      	b.eq	0xa8c8 <_stogir.stack.validate-frame-address+0xec>
    a8b4:      	lsl	x3, x1, #4
    a8b8:      	ldr	x3, [x0]
    a8bc:      	add	x3, x3, x1, lsl #4
    a8c0:      	ldr	x3, [x3]
    a8c4:      	b	0xa8d8 <_stogir.stack.validate-frame-address+0xfc>
    a8c8:      	lsl	x3, x5, #4
    a8cc:      	ldr	x3, [x0, #0x28]
    a8d0:      	add	x3, x3, x5, lsl #4
    a8d4:      	ldr	x3, [x3]
    a8d8:      	mov	x4, x3
    a8dc:      	mov	x3, #0x1                ; =1
    a8e0:      	b	0xa8ec <_stogir.stack.validate-frame-address+0x110>
    a8e4:      	movz	x3, #0x0, lsl #48
    a8e8:      	movz	x4, #0x0, lsl #48
    a8ec:      	lsr	w3, w3, #0
    a8f0:      	lsr	x16, x3, #0
    a8f4:      	cmp	x16, #0x1
    a8f8:      	b.eq	0xa914 <_stogir.stack.validate-frame-address+0x138>
    a8fc:      	b.lo	0xa904 <_stogir.stack.validate-frame-address+0x128>
    a900:      	b	0xa918 <_stogir.stack.validate-frame-address+0x13c>
    a904:      	cmp	x16, #0x0
    a908:      	b.eq	0xa910 <_stogir.stack.validate-frame-address+0x134>
    a90c:      	b	0xa918 <_stogir.stack.validate-frame-address+0x13c>
    a910:      	b	0xa91c <_stogir.stack.validate-frame-address+0x140>
    a914:      	b	0xa960 <_stogir.stack.validate-frame-address+0x184>
    a918:      	b	0xa9bc <_stogir.stack.validate-frame-address+0x1e0>
    a91c:      	adrp	x16, 0xa000 <_stogir.switch.switch-inputs+0xd4>
		000000000000a91c:  ARM64_RELOC_PAGE21	l_stogir.450
    a920:      	ldr	x16, [x16]
		000000000000a920:  ARM64_RELOC_PAGEOFF12	l_stogir.450
    a924:      	orr	x0, x16, xzr
    a928:      	mov	x1, x0
    a92c:      	mov	x0, #0x1                ; =1
    a930:      	mov	x2, #0x21               ; =33
    a934:      	b	0xa950 <_stogir.stack.validate-frame-address+0x174>
    a938:      	adrp	x16, 0xa000 <_stogir.switch.switch-inputs+0xd4>
		000000000000a938:  ARM64_RELOC_PAGE21	l_stogir.451
    a93c:      	ldr	x16, [x16]
		000000000000a93c:  ARM64_RELOC_PAGEOFF12	l_stogir.451
    a940:      	orr	x0, x16, xzr
    a944:      	mov	x1, x0
    a948:      	mov	x0, #0x1                ; =1
    a94c:      	mov	x2, #0x1e               ; =30
    a950:      	str	x0, [x8]
    a954:      	str	x1, [x8, #0x8]
    a958:      	str	x2, [x8, #0x10]
    a95c:      	ret
    a960:      	cmp	x1, #0x0
    a964:      	b.le	0xa938 <_stogir.stack.validate-frame-address+0x15c>
    a968:      	uxtb	w1, w4
    a96c:      	cmp	x1, #0x42
    a970:      	b.ne	0xa938 <_stogir.stack.validate-frame-address+0x15c>
    a974:      	lsr	w4, w4, #0
    a978:      	ubfx	x1, x4, #8, #8
    a97c:      	cmp	x1, #0x6
    a980:      	b.ne	0xa938 <_stogir.stack.validate-frame-address+0x15c>
    a984:      	ldr	x0, [x0, #0x78]
    a988:      	add	x0, x2, x0
    a98c:      	ldr	w0, [x0]
    a990:      	sxtw	x0, w0
    a994:      	cmp	x0, #0x0
    a998:      	b.ne	0xa938 <_stogir.stack.validate-frame-address+0x15c>
    a99c:      	movz	x0, #0x0, lsl #48
    a9a0:      	mov	x1, #0x8                ; =8
    a9a4:      	movz	x2, #0x0, lsl #48
    a9a8:      	b	0xa950 <_stogir.stack.validate-frame-address+0x174>
    a9ac:      	movz	x4, #0x0, lsl #48
    a9b0:      	b	0xa898 <_stogir.stack.validate-frame-address+0xbc>
    a9b4:      	movz	x4, #0x0, lsl #48
    a9b8:      	b	0xa890 <_stogir.stack.validate-frame-address+0xb4>
    a9bc:      	brk	#0
    a9c0:      	b	0xa9bc <_stogir.stack.validate-frame-address+0x1e0>

000000000000a9c4 <_stogir.stack.frame-object?>:
    a9c4:      	ldr	w0, [x0]
    a9c8:      	uxtb	w1, w0
    a9cc:      	cmp	x1, #0x51
    a9d0:      	b.ne	0xa9e8 <_stogir.stack.frame-object?+0x24>
    a9d4:      	ubfx	x0, x0, #16, #16
    a9d8:      	cmp	x0, #0x8, lsl #12       ; =0x8000
    a9dc:      	cset	w0, eq
    a9e0:      	ubfx	x0, x0, #0, #8
    a9e4:      	b	0xa9ec <_stogir.stack.frame-object?+0x28>
    a9e8:      	movz	x0, #0x0, lsl #48
    a9ec:      	ret

000000000000a9f0 <_stogir.stack.valid-frame-object-inputs?>:
    a9f0:      	sub	sp, sp, #0x50
    a9f4:      	str	x29, [sp]
    a9f8:      	str	x30, [sp, #0x8]
    a9fc:      	mov	x29, sp
    aa00:      	str	x19, [sp, #0x30]
    aa04:      	str	x20, [sp, #0x38]
    aa08:      	str	x21, [sp, #0x40]
    aa0c:      	add	x3, x0, #0x78
    aa10:      	add	x4, x0, #0x28
    aa14:      	add	x5, x0, #0x50
    aa18:      	add	x6, x0, #0x78
    aa1c:      	add	x7, x0, #0x28
    aa20:      	add	x8, x0, #0x50
    aa24:      	sxtw	x1, w1
    aa28:      	mov	x9, sp
    aa2c:      	sub	sp, sp, #0x10
    aa30:      	mov	x10, sp
    aa34:      	mov	x12, x1
    aa38:      	mov	x1, #0x1                ; =1
    aa3c:      	movz	x11, #0x0, lsl #48
    aa40:      	b	0xab90 <_stogir.stack.valid-frame-object-inputs?+0x1a0>
    aa44:      	movz	x15, #0x0, lsl #48
    aa48:      	b	0xaac0 <_stogir.stack.valid-frame-object-inputs?+0xd0>
    aa4c:      	movz	x13, #0x0, lsl #48
    aa50:      	movz	x14, #0x0, lsl #48
    aa54:      	lsr	w13, w13, #0
    aa58:      	lsr	x16, x13, #0
    aa5c:      	cmp	x16, #0x1
    aa60:      	b.eq	0xaa7c <_stogir.stack.valid-frame-object-inputs?+0x8c>
    aa64:      	b.lo	0xaa6c <_stogir.stack.valid-frame-object-inputs?+0x7c>
    aa68:      	b	0xaa80 <_stogir.stack.valid-frame-object-inputs?+0x90>
    aa6c:      	cmp	x16, #0x0
    aa70:      	b.eq	0xaa78 <_stogir.stack.valid-frame-object-inputs?+0x88>
    aa74:      	b	0xaa80 <_stogir.stack.valid-frame-object-inputs?+0x90>
    aa78:      	b	0xaaa0 <_stogir.stack.valid-frame-object-inputs?+0xb0>
    aa7c:      	b	0xaa84 <_stogir.stack.valid-frame-object-inputs?+0x94>
    aa80:      	b	0xae78 <_stogir.stack.valid-frame-object-inputs?+0x488>
    aa84:      	uxtb	w13, w14
    aa88:      	lsr	w14, w14, #0
    aa8c:      	ubfx	x14, x14, #8, #8
    aa90:      	cmp	x13, x14
    aa94:      	b.eq	0xae64 <_stogir.stack.valid-frame-object-inputs?+0x474>
    aa98:      	cmp	x13, #0x49
    aa9c:      	b.eq	0xae64 <_stogir.stack.valid-frame-object-inputs?+0x474>
    aaa0:      	movz	x1, #0x0, lsl #48
    aaa4:      	fmov	d31, x11
    aaa8:      	mov	x11, x12
    aaac:      	fmov	x12, d31
    aab0:      	b	0xac74 <_stogir.stack.valid-frame-object-inputs?+0x284>
    aab4:      	movz	x15, #0x0, lsl #48
    aab8:      	b	0xaac8 <_stogir.stack.valid-frame-object-inputs?+0xd8>
    aabc:      	movz	x15, #0x0, lsl #48
    aac0:      	b	0xaad0 <_stogir.stack.valid-frame-object-inputs?+0xe0>
    aac4:      	movz	x15, #0x0, lsl #48
    aac8:      	b	0xaad0 <_stogir.stack.valid-frame-object-inputs?+0xe0>
    aacc:      	movz	x15, #0x0, lsl #48
    aad0:      	cmp	x15, #0x0
    aad4:      	b.eq	0xab38 <_stogir.stack.valid-frame-object-inputs?+0x148>
    aad8:      	uxtb	w16, w14
    aadc:      	cmp	w16, wzr
    aae0:      	b.eq	0xab08 <_stogir.stack.valid-frame-object-inputs?+0x118>
    aae4:      	lsl	x14, x13, #4
    aae8:      	ldr	x14, [x0]
    aaec:      	add	x13, x14, x13, lsl #4
    aaf0:      	ldr	x14, [x13]
    aaf4:      	ldr	x13, [x13, #0x8]
    aaf8:      	fmov	d31, x13
    aafc:      	mov	x13, x14
    ab00:      	fmov	x14, d31
    ab04:      	b	0xab28 <_stogir.stack.valid-frame-object-inputs?+0x138>
    ab08:      	lsl	x13, x19, #4
    ab0c:      	ldr	x13, [x0, #0x28]
    ab10:      	add	x13, x13, x19, lsl #4
    ab14:      	ldr	x14, [x13]
    ab18:      	ldr	x13, [x13, #0x8]
    ab1c:      	fmov	d31, x13
    ab20:      	mov	x13, x14
    ab24:      	fmov	x14, d31
    ab28:      	mov	x15, x14
    ab2c:      	mov	x14, x13
    ab30:      	mov	x13, #0x1               ; =1
    ab34:      	b	0xab44 <_stogir.stack.valid-frame-object-inputs?+0x154>
    ab38:      	movz	x13, #0x0, lsl #48
    ab3c:      	movz	x14, #0x0, lsl #48
    ab40:      	movz	x15, #0x0, lsl #48
    ab44:      	lsr	w13, w13, #0
    ab48:      	lsr	x16, x13, #0
    ab4c:      	cmp	x16, #0x1
    ab50:      	b.eq	0xab6c <_stogir.stack.valid-frame-object-inputs?+0x17c>
    ab54:      	b.lo	0xab5c <_stogir.stack.valid-frame-object-inputs?+0x16c>
    ab58:      	b	0xab70 <_stogir.stack.valid-frame-object-inputs?+0x180>
    ab5c:      	cmp	x16, #0x0
    ab60:      	b.eq	0xab68 <_stogir.stack.valid-frame-object-inputs?+0x178>
    ab64:      	b	0xab70 <_stogir.stack.valid-frame-object-inputs?+0x180>
    ab68:      	b	0xab74 <_stogir.stack.valid-frame-object-inputs?+0x184>
    ab6c:      	b	0xac48 <_stogir.stack.valid-frame-object-inputs?+0x258>
    ab70:      	b	0xadc0 <_stogir.stack.valid-frame-object-inputs?+0x3d0>
    ab74:      	fmov	d31, x11
    ab78:      	mov	x11, x12
    ab7c:      	fmov	x12, d31
    ab80:      	movz	x1, #0x0, lsl #48
    ab84:      	fmov	d31, x11
    ab88:      	mov	x11, x12
    ab8c:      	fmov	x12, d31
    ab90:      	cmp	x1, #0x0
    ab94:      	b.eq	0xad04 <_stogir.stack.valid-frame-object-inputs?+0x314>
    ab98:      	cmp	x11, #0x0
    ab9c:      	b.ne	0xad04 <_stogir.stack.valid-frame-object-inputs?+0x314>
    aba0:      	lsr	w13, w12, #0
    aba4:      	sxtw	x13, w13
    aba8:      	cmp	x13, #0x0
    abac:      	cset	w14, gt
    abb0:      	movz	x16, #0x0, lsl #48
    abb4:      	sub	x15, x16, x13
    abb8:      	sub	x19, x15, #0x1
    abbc:      	uxtb	w16, w14
    abc0:      	cmp	w16, wzr
    abc4:      	b.eq	0xac04 <_stogir.stack.valid-frame-object-inputs?+0x214>
    abc8:      	ldr	x15, [x0, #0x8]
    abcc:      	cmp	x13, x15
    abd0:      	b.ge	0xaac4 <_stogir.stack.valid-frame-object-inputs?+0xd4>
    abd4:      	ldr	x15, [x3, #0x8]
    abd8:      	cmp	x13, x15
    abdc:      	b.ge	0xaab4 <_stogir.stack.valid-frame-object-inputs?+0xc4>
    abe0:      	lsl	x15, x13, #2
    abe4:      	ldr	x15, [x0, #0x78]
    abe8:      	add	x15, x15, x13, lsl #2
    abec:      	ldr	w15, [x15]
    abf0:      	sxtw	x15, w15
    abf4:      	cmp	x15, #0x0
    abf8:      	cset	w15, ge
    abfc:      	ubfx	x15, x15, #0, #8
    ac00:      	b	0xaab8 <_stogir.stack.valid-frame-object-inputs?+0xc8>
    ac04:      	cmp	x13, #0x0
    ac08:      	b.ge	0xaacc <_stogir.stack.valid-frame-object-inputs?+0xdc>
    ac0c:      	ldr	x20, [x4, #0x8]
    ac10:      	ldr	x21, [x5, #0x8]
    ac14:      	cmp	x20, x21
    ac18:      	b.ne	0xaabc <_stogir.stack.valid-frame-object-inputs?+0xcc>
    ac1c:      	cmp	x15, x20
    ac20:      	b.gt	0xaa44 <_stogir.stack.valid-frame-object-inputs?+0x54>
    ac24:      	lsl	x15, x19, #2
    ac28:      	ldr	x15, [x0, #0x50]
    ac2c:      	add	x15, x15, x19, lsl #2
    ac30:      	ldr	w15, [x15]
    ac34:      	sxtw	x15, w15
    ac38:      	cmp	x15, #0x0
    ac3c:      	cset	w15, gt
    ac40:      	ubfx	x15, x15, #0, #8
    ac44:      	b	0xaa48 <_stogir.stack.valid-frame-object-inputs?+0x58>
    ac48:      	uxtb	w13, w14
    ac4c:      	asr	x19, x14, #32
    ac50:      	str	x14, [x10]
    ac54:      	str	x15, [x10, #0x8]
    ac58:      	cmp	x13, #0x68
    ac5c:      	b.ne	0xac78 <_stogir.stack.valid-frame-object-inputs?+0x288>
    ac60:      	cmp	x19, #0x0
    ac64:      	cset	w1, eq
    ac68:      	ubfx	x1, x1, #0, #8
    ac6c:      	mov	x11, x12
    ac70:      	mov	x12, #0x1               ; =1
    ac74:      	b	0xab84 <_stogir.stack.valid-frame-object-inputs?+0x194>
    ac78:      	cmp	x12, #0x0
    ac7c:      	b.le	0xaaa0 <_stogir.stack.valid-frame-object-inputs?+0xb0>
    ac80:      	cmp	x13, #0x51
    ac84:      	b.ne	0xaaa0 <_stogir.stack.valid-frame-object-inputs?+0xb0>
    ac88:      	cmp	x19, #0x0
    ac8c:      	b.le	0xaaa0 <_stogir.stack.valid-frame-object-inputs?+0xb0>
    ac90:      	cmp	x19, x12
    ac94:      	b.ge	0xaaa0 <_stogir.stack.valid-frame-object-inputs?+0xb0>
    ac98:      	lsr	w15, w15, #0
    ac9c:      	sxtw	x15, w15
    aca0:      	cmp	x15, #0x0
    aca4:      	b.ge	0xaaa0 <_stogir.stack.valid-frame-object-inputs?+0xb0>
    aca8:      	cmp	x15, #0x0
    acac:      	cset	w13, gt
    acb0:      	movz	x16, #0x0, lsl #48
    acb4:      	sub	x14, x16, x15
    acb8:      	sub	x19, x14, #0x1
    acbc:      	uxtb	w16, w13
    acc0:      	cmp	w16, wzr
    acc4:      	b.eq	0xae18 <_stogir.stack.valid-frame-object-inputs?+0x428>
    acc8:      	ldr	x14, [x0, #0x8]
    accc:      	cmp	x15, x14
    acd0:      	b.ge	0xae10 <_stogir.stack.valid-frame-object-inputs?+0x420>
    acd4:      	ldr	x14, [x6, #0x8]
    acd8:      	cmp	x15, x14
    acdc:      	b.ge	0xae5c <_stogir.stack.valid-frame-object-inputs?+0x46c>
    ace0:      	lsl	x14, x15, #2
    ace4:      	ldr	x14, [x0, #0x78]
    ace8:      	add	x14, x14, x15, lsl #2
    acec:      	ldr	w14, [x14]
    acf0:      	sxtw	x14, w14
    acf4:      	cmp	x14, #0x0
    acf8:      	cset	w14, ge
    acfc:      	ubfx	x14, x14, #0, #8
    ad00:      	b	0xae60 <_stogir.stack.valid-frame-object-inputs?+0x470>
    ad04:      	cmp	x1, #0x0
    ad08:      	b.eq	0xad14 <_stogir.stack.valid-frame-object-inputs?+0x324>
    ad0c:      	mov	x1, x11
    ad10:      	b	0xad18 <_stogir.stack.valid-frame-object-inputs?+0x328>
    ad14:      	movz	x1, #0x0, lsl #48
    ad18:      	mov	sp, x9
    ad1c:      	cmp	x1, #0x0
    ad20:      	b.eq	0xad7c <_stogir.stack.valid-frame-object-inputs?+0x38c>
    ad24:      	sxtw	x1, w2
    ad28:      	cmp	x1, #0x0
    ad2c:      	b.ge	0xada0 <_stogir.stack.valid-frame-object-inputs?+0x3b0>
    ad30:      	lsr	w2, w2, #0
    ad34:      	add	x8, x29, #0x10
    ad38:      	mov	w1, w2
    ad3c:      	bl	0xad3c <_stogir.stack.valid-frame-object-inputs?+0x34c>
		000000000000ad3c:  ARM64_RELOC_BRANCH26	_stogir.stack.constant-size
    ad40:      	add	x16, x29, #0x10
    ad44:      	ldr	w0, [x16]
    ad48:      	lsr	x16, x0, #0
    ad4c:      	cmp	x16, #0x1
    ad50:      	b.eq	0xad6c <_stogir.stack.valid-frame-object-inputs?+0x37c>
    ad54:      	b.lo	0xad5c <_stogir.stack.valid-frame-object-inputs?+0x36c>
    ad58:      	b	0xad70 <_stogir.stack.valid-frame-object-inputs?+0x380>
    ad5c:      	cmp	x16, #0x0
    ad60:      	b.eq	0xad68 <_stogir.stack.valid-frame-object-inputs?+0x378>
    ad64:      	b	0xad70 <_stogir.stack.valid-frame-object-inputs?+0x380>
    ad68:      	b	0xada8 <_stogir.stack.valid-frame-object-inputs?+0x3b8>
    ad6c:      	b	0xad74 <_stogir.stack.valid-frame-object-inputs?+0x384>
    ad70:      	b	0xae70 <_stogir.stack.valid-frame-object-inputs?+0x480>
    ad74:      	movz	x0, #0x0, lsl #48
    ad78:      	b	0xadbc <_stogir.stack.valid-frame-object-inputs?+0x3cc>
    ad7c:      	movz	x0, #0x0, lsl #48
    ad80:      	sub	sp, x29, #0x0
    ad84:      	ldr	x19, [sp, #0x30]
    ad88:      	ldr	x20, [sp, #0x38]
    ad8c:      	ldr	x21, [sp, #0x40]
    ad90:      	ldr	x29, [sp]
    ad94:      	ldr	x30, [sp, #0x8]
    ad98:      	add	sp, sp, #0x50
    ad9c:      	ret
    ada0:      	movz	x0, #0x0, lsl #48
    ada4:      	b	0xad80 <_stogir.stack.valid-frame-object-inputs?+0x390>
    ada8:      	add	x16, x29, #0x10
    adac:      	ldr	x0, [x16, #0x8]
    adb0:      	cmp	x0, #0x0
    adb4:      	cset	w0, gt
    adb8:      	ubfx	x0, x0, #0, #8
    adbc:      	b	0xada4 <_stogir.stack.valid-frame-object-inputs?+0x3b4>
    adc0:      	brk	#0
    adc4:      	b	0xadc0 <_stogir.stack.valid-frame-object-inputs?+0x3d0>
    adc8:      	lsl	x13, x19, #4
    adcc:      	ldr	x13, [x0, #0x28]
    add0:      	add	x13, x13, x19, lsl #4
    add4:      	ldr	x13, [x13]
    add8:      	mov	x14, x13
    addc:      	mov	x13, #0x1               ; =1
    ade0:      	b	0xaa54 <_stogir.stack.valid-frame-object-inputs?+0x64>
    ade4:      	movz	x14, #0x0, lsl #48
    ade8:      	cmp	x14, #0x0
    adec:      	b.eq	0xaa4c <_stogir.stack.valid-frame-object-inputs?+0x5c>
    adf0:      	uxtb	w16, w13
    adf4:      	cmp	w16, wzr
    adf8:      	b.eq	0xadc8 <_stogir.stack.valid-frame-object-inputs?+0x3d8>
    adfc:      	lsl	x13, x15, #4
    ae00:      	ldr	x13, [x0]
    ae04:      	add	x13, x13, x15, lsl #4
    ae08:      	ldr	x13, [x13]
    ae0c:      	b	0xadd8 <_stogir.stack.valid-frame-object-inputs?+0x3e8>
    ae10:      	movz	x14, #0x0, lsl #48
    ae14:      	b	0xade8 <_stogir.stack.valid-frame-object-inputs?+0x3f8>
    ae18:      	ldr	x20, [x7, #0x8]
    ae1c:      	ldr	x21, [x8, #0x8]
    ae20:      	cmp	x20, x21
    ae24:      	b.ne	0xade4 <_stogir.stack.valid-frame-object-inputs?+0x3f4>
    ae28:      	cmp	x14, x20
    ae2c:      	b.gt	0xae54 <_stogir.stack.valid-frame-object-inputs?+0x464>
    ae30:      	lsl	x14, x19, #2
    ae34:      	ldr	x14, [x0, #0x50]
    ae38:      	add	x14, x14, x19, lsl #2
    ae3c:      	ldr	w14, [x14]
    ae40:      	sxtw	x14, w14
    ae44:      	cmp	x14, #0x0
    ae48:      	cset	w14, gt
    ae4c:      	ubfx	x14, x14, #0, #8
    ae50:      	b	0xae58 <_stogir.stack.valid-frame-object-inputs?+0x468>
    ae54:      	movz	x14, #0x0, lsl #48
    ae58:      	b	0xade8 <_stogir.stack.valid-frame-object-inputs?+0x3f8>
    ae5c:      	movz	x14, #0x0, lsl #48
    ae60:      	b	0xae14 <_stogir.stack.valid-frame-object-inputs?+0x424>
    ae64:      	ldr	w12, [x10, #0x4]
    ae68:      	sxtw	x12, w12
    ae6c:      	b	0xaaa4 <_stogir.stack.valid-frame-object-inputs?+0xb4>
    ae70:      	brk	#0
    ae74:      	b	0xae70 <_stogir.stack.valid-frame-object-inputs?+0x480>
    ae78:      	brk	#0
    ae7c:      	b	0xae78 <_stogir.stack.valid-frame-object-inputs?+0x488>

000000000000ae80 <_stogir.stack.validate-scope-inputs>:
    ae80:      	sxtw	x1, w1
    ae84:      	cmp	x1, #0x53
    ae88:      	cset	w5, eq
    ae8c:      	uxtb	w16, w5
    ae90:      	cmp	w16, wzr
    ae94:      	b.ne	0xaec8 <_stogir.stack.validate-scope-inputs+0x48>
    ae98:      	cmp	x1, #0x54
    ae9c:      	b.eq	0xaec8 <_stogir.stack.validate-scope-inputs+0x48>
    aea0:      	adrp	x16, 0xa000 <_stogir.switch.switch-inputs+0xd4>
		000000000000aea0:  ARM64_RELOC_PAGE21	l_stogir.452
    aea4:      	ldr	x16, [x16]
		000000000000aea4:  ARM64_RELOC_PAGEOFF12	l_stogir.452
    aea8:      	orr	x0, x16, xzr
    aeac:      	mov	x1, x0
    aeb0:      	mov	x0, #0x1                ; =1
    aeb4:      	mov	x2, #0x22               ; =34
    aeb8:      	str	x0, [x8]
    aebc:      	str	x1, [x8, #0x8]
    aec0:      	str	x2, [x8, #0x10]
    aec4:      	ret
    aec8:      	uxtb	w16, w5
    aecc:      	cmp	w16, wzr
    aed0:      	mov	x16, #0x6               ; =6
    aed4:      	movz	x17, #0x0, lsl #48
    aed8:      	csel	x1, x16, x17, ne
    aedc:      	sxtw	x2, w2
    aee0:      	lsr	w1, w1, #0
    aee4:      	sxtw	x1, w1
    aee8:      	cmp	x2, x1
    aeec:      	b.ne	0xaea0 <_stogir.stack.validate-scope-inputs+0x20>
    aef0:      	sxtw	x3, w3
    aef4:      	cmp	x3, #0x0
    aef8:      	cset	w1, gt
    aefc:      	movz	x16, #0x0, lsl #48
    af00:      	sub	x2, x16, x3
    af04:      	sub	x6, x2, #0x1
    af08:      	uxtb	w16, w1
    af0c:      	cmp	w16, wzr
    af10:      	b.eq	0xaff8 <_stogir.stack.validate-scope-inputs+0x178>
    af14:      	ldr	x2, [x0, #0x8]
    af18:      	cmp	x3, x2
    af1c:      	b.ge	0xaff0 <_stogir.stack.validate-scope-inputs+0x170>
    af20:      	add	x2, x0, #0x78
    af24:      	ldr	x2, [x2, #0x8]
    af28:      	cmp	x3, x2
    af2c:      	b.ge	0xb0a0 <_stogir.stack.validate-scope-inputs+0x220>
    af30:      	lsl	x2, x3, #2
    af34:      	ldr	x2, [x0, #0x78]
    af38:      	add	x2, x2, x3, lsl #2
    af3c:      	ldr	w2, [x2]
    af40:      	sxtw	x2, w2
    af44:      	cmp	x2, #0x0
    af48:      	cset	w2, ge
    af4c:      	ubfx	x2, x2, #0, #8
    af50:      	b	0xb0a4 <_stogir.stack.validate-scope-inputs+0x224>
    af54:      	movz	x1, #0x0, lsl #48
    af58:      	movz	x2, #0x0, lsl #48
    af5c:      	lsr	w1, w1, #0
    af60:      	lsr	x16, x1, #0
    af64:      	cmp	x16, #0x1
    af68:      	b.eq	0xaf84 <_stogir.stack.validate-scope-inputs+0x104>
    af6c:      	b.lo	0xaf74 <_stogir.stack.validate-scope-inputs+0xf4>
    af70:      	b	0xaf88 <_stogir.stack.validate-scope-inputs+0x108>
    af74:      	cmp	x16, #0x0
    af78:      	b.eq	0xaf80 <_stogir.stack.validate-scope-inputs+0x100>
    af7c:      	b	0xaf88 <_stogir.stack.validate-scope-inputs+0x108>
    af80:      	b	0xaf8c <_stogir.stack.validate-scope-inputs+0x10c>
    af84:      	b	0xb044 <_stogir.stack.validate-scope-inputs+0x1c4>
    af88:      	b	0xb288 <_stogir.stack.validate-scope-inputs+0x408>
    af8c:      	adrp	x16, 0xa000 <_stogir.switch.switch-inputs+0xd4>
		000000000000af8c:  ARM64_RELOC_PAGE21	l_stogir.453
    af90:      	ldr	x16, [x16]
		000000000000af90:  ARM64_RELOC_PAGEOFF12	l_stogir.453
    af94:      	orr	x0, x16, xzr
    af98:      	mov	x1, x0
    af9c:      	mov	x0, #0x1                ; =1
    afa0:      	mov	x2, #0x1b               ; =27
    afa4:      	b	0xaeb8 <_stogir.stack.validate-scope-inputs+0x38>
    afa8:      	lsl	x1, x6, #4
    afac:      	ldr	x1, [x0, #0x28]
    afb0:      	add	x1, x1, x6, lsl #4
    afb4:      	ldr	x1, [x1]
    afb8:      	mov	x2, x1
    afbc:      	mov	x1, #0x1                ; =1
    afc0:      	b	0xaf5c <_stogir.stack.validate-scope-inputs+0xdc>
    afc4:      	movz	x2, #0x0, lsl #48
    afc8:      	cmp	x2, #0x0
    afcc:      	b.eq	0xaf54 <_stogir.stack.validate-scope-inputs+0xd4>
    afd0:      	uxtb	w16, w1
    afd4:      	cmp	w16, wzr
    afd8:      	b.eq	0xafa8 <_stogir.stack.validate-scope-inputs+0x128>
    afdc:      	lsl	x1, x3, #4
    afe0:      	ldr	x1, [x0]
    afe4:      	add	x1, x1, x3, lsl #4
    afe8:      	ldr	x1, [x1]
    afec:      	b	0xafb8 <_stogir.stack.validate-scope-inputs+0x138>
    aff0:      	movz	x2, #0x0, lsl #48
    aff4:      	b	0xafc8 <_stogir.stack.validate-scope-inputs+0x148>
    aff8:      	cmp	x3, #0x0
    affc:      	b.ge	0xafc4 <_stogir.stack.validate-scope-inputs+0x144>
    b000:      	add	x7, x0, #0x28
    b004:      	add	x9, x0, #0x50
    b008:      	ldr	x7, [x7, #0x8]
    b00c:      	ldr	x9, [x9, #0x8]
    b010:      	cmp	x7, x9
    b014:      	b.ne	0xb098 <_stogir.stack.validate-scope-inputs+0x218>
    b018:      	cmp	x2, x7
    b01c:      	b.gt	0xb0a8 <_stogir.stack.validate-scope-inputs+0x228>
    b020:      	lsl	x2, x6, #2
    b024:      	ldr	x2, [x0, #0x50]
    b028:      	add	x2, x2, x6, lsl #2
    b02c:      	ldr	w2, [x2]
    b030:      	sxtw	x2, w2
    b034:      	cmp	x2, #0x0
    b038:      	cset	w2, gt
    b03c:      	ubfx	x2, x2, #0, #8
    b040:      	b	0xb0ac <_stogir.stack.validate-scope-inputs+0x22c>
    b044:      	cmp	x3, #0x0
    b048:      	b.le	0xb07c <_stogir.stack.validate-scope-inputs+0x1fc>
    b04c:      	uxtb	w2, w2
    b050:      	cmp	x2, #0x83
    b054:      	cset	w1, lt
    b058:      	uxtb	w16, w1
    b05c:      	cmp	w16, wzr
    b060:      	b.eq	0xb0b0 <_stogir.stack.validate-scope-inputs+0x230>
    b064:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x180>
		000000000000b064:  ARM64_RELOC_PAGE21	l_stogir.454
    b068:      	ldr	x16, [x16]
		000000000000b068:  ARM64_RELOC_PAGEOFF12	l_stogir.454
    b06c:      	orr	x3, x16, xzr
    b070:      	add	x3, x2, x3
    b074:      	ldrb	w3, [x3]
    b078:      	b	0xb0b4 <_stogir.stack.validate-scope-inputs+0x234>
    b07c:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x180>
		000000000000b07c:  ARM64_RELOC_PAGE21	l_stogir.455
    b080:      	ldr	x16, [x16]
		000000000000b080:  ARM64_RELOC_PAGEOFF12	l_stogir.455
    b084:      	orr	x0, x16, xzr
    b088:      	mov	x1, x0
    b08c:      	mov	x0, #0x1                ; =1
    b090:      	mov	x2, #0x1b               ; =27
    b094:      	b	0xafa4 <_stogir.stack.validate-scope-inputs+0x124>
    b098:      	movz	x2, #0x0, lsl #48
    b09c:      	b	0xafc8 <_stogir.stack.validate-scope-inputs+0x148>
    b0a0:      	movz	x2, #0x0, lsl #48
    b0a4:      	b	0xaff4 <_stogir.stack.validate-scope-inputs+0x174>
    b0a8:      	movz	x2, #0x0, lsl #48
    b0ac:      	b	0xb09c <_stogir.stack.validate-scope-inputs+0x21c>
    b0b0:      	movz	x3, #0x0, lsl #48
    b0b4:      	uxtb	w3, w3
    b0b8:      	and	x3, x3, #0x1
    b0bc:      	uxtb	w3, w3
    b0c0:      	cmp	x3, #0x0
    b0c4:      	b.eq	0xb07c <_stogir.stack.validate-scope-inputs+0x1fc>
    b0c8:      	uxtb	w16, w1
    b0cc:      	cmp	w16, wzr
    b0d0:      	b.eq	0xb0ec <_stogir.stack.validate-scope-inputs+0x26c>
    b0d4:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x180>
		000000000000b0d4:  ARM64_RELOC_PAGE21	l_stogir.454
    b0d8:      	ldr	x16, [x16]
		000000000000b0d8:  ARM64_RELOC_PAGEOFF12	l_stogir.454
    b0dc:      	orr	x1, x16, xzr
    b0e0:      	add	x1, x2, x1
    b0e4:      	ldrb	w1, [x1]
    b0e8:      	b	0xb0f0 <_stogir.stack.validate-scope-inputs+0x270>
    b0ec:      	movz	x1, #0x0, lsl #48
    b0f0:      	uxtb	w1, w1
    b0f4:      	and	x1, x1, #0x4
    b0f8:      	uxtb	w1, w1
    b0fc:      	cmp	x1, #0x0
    b100:      	cset	w1, eq
    b104:      	uxtb	w16, w1
    b108:      	cmp	w16, wzr
    b10c:      	cset	x1, eq
    b110:      	cmp	x1, #0x0
    b114:      	b.ne	0xb07c <_stogir.stack.validate-scope-inputs+0x1fc>
    b118:      	uxtb	w16, w5
    b11c:      	cmp	w16, wzr
    b120:      	b.eq	0xb134 <_stogir.stack.validate-scope-inputs+0x2b4>
    b124:      	movz	x0, #0x0, lsl #48
    b128:      	mov	x1, #0x8                ; =8
    b12c:      	movz	x2, #0x0, lsl #48
    b130:      	b	0xb094 <_stogir.stack.validate-scope-inputs+0x214>
    b134:      	sxtw	x4, w4
    b138:      	cmp	x4, #0x0
    b13c:      	cset	w1, gt
    b140:      	movz	x16, #0x0, lsl #48
    b144:      	sub	x2, x16, x4
    b148:      	sub	x3, x2, #0x1
    b14c:      	uxtb	w16, w1
    b150:      	cmp	w16, wzr
    b154:      	b.eq	0xb23c <_stogir.stack.validate-scope-inputs+0x3bc>
    b158:      	ldr	x2, [x0, #0x8]
    b15c:      	cmp	x4, x2
    b160:      	b.ge	0xb234 <_stogir.stack.validate-scope-inputs+0x3b4>
    b164:      	add	x2, x0, #0x78
    b168:      	ldr	x2, [x2, #0x8]
    b16c:      	cmp	x4, x2
    b170:      	b.ge	0xb2e0 <_stogir.stack.validate-scope-inputs+0x460>
    b174:      	lsl	x2, x4, #2
    b178:      	ldr	x2, [x0, #0x78]
    b17c:      	add	x2, x2, x4, lsl #2
    b180:      	ldr	w2, [x2]
    b184:      	sxtw	x2, w2
    b188:      	cmp	x2, #0x0
    b18c:      	cset	w2, ge
    b190:      	ubfx	x2, x2, #0, #8
    b194:      	b	0xb2e4 <_stogir.stack.validate-scope-inputs+0x464>
    b198:      	movz	x0, #0x0, lsl #48
    b19c:      	movz	x1, #0x0, lsl #48
    b1a0:      	lsr	w0, w0, #0
    b1a4:      	lsr	x16, x0, #0
    b1a8:      	cmp	x16, #0x1
    b1ac:      	b.eq	0xb1c8 <_stogir.stack.validate-scope-inputs+0x348>
    b1b0:      	b.lo	0xb1b8 <_stogir.stack.validate-scope-inputs+0x338>
    b1b4:      	b	0xb1cc <_stogir.stack.validate-scope-inputs+0x34c>
    b1b8:      	cmp	x16, #0x0
    b1bc:      	b.eq	0xb1c4 <_stogir.stack.validate-scope-inputs+0x344>
    b1c0:      	b	0xb1cc <_stogir.stack.validate-scope-inputs+0x34c>
    b1c4:      	b	0xb1d0 <_stogir.stack.validate-scope-inputs+0x350>
    b1c8:      	b	0xb290 <_stogir.stack.validate-scope-inputs+0x410>
    b1cc:      	b	0xb2f0 <_stogir.stack.validate-scope-inputs+0x470>
    b1d0:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x180>
		000000000000b1d0:  ARM64_RELOC_PAGE21	l_stogir.456
    b1d4:      	ldr	x16, [x16]
		000000000000b1d4:  ARM64_RELOC_PAGEOFF12	l_stogir.456
    b1d8:      	orr	x0, x16, xzr
    b1dc:      	mov	x1, x0
    b1e0:      	mov	x0, #0x1                ; =1
    b1e4:      	mov	x2, #0x1b               ; =27
    b1e8:      	b	0xb130 <_stogir.stack.validate-scope-inputs+0x2b0>
    b1ec:      	lsl	x1, x3, #4
    b1f0:      	ldr	x0, [x0, #0x28]
    b1f4:      	add	x0, x0, x3, lsl #4
    b1f8:      	ldr	x0, [x0]
    b1fc:      	mov	x1, x0
    b200:      	mov	x0, #0x1                ; =1
    b204:      	b	0xb1a0 <_stogir.stack.validate-scope-inputs+0x320>
    b208:      	movz	x2, #0x0, lsl #48
    b20c:      	cmp	x2, #0x0
    b210:      	b.eq	0xb198 <_stogir.stack.validate-scope-inputs+0x318>
    b214:      	uxtb	w16, w1
    b218:      	cmp	w16, wzr
    b21c:      	b.eq	0xb1ec <_stogir.stack.validate-scope-inputs+0x36c>
    b220:      	lsl	x1, x4, #4
    b224:      	ldr	x0, [x0]
    b228:      	add	x0, x0, x4, lsl #4
    b22c:      	ldr	x0, [x0]
    b230:      	b	0xb1fc <_stogir.stack.validate-scope-inputs+0x37c>
    b234:      	movz	x2, #0x0, lsl #48
    b238:      	b	0xb20c <_stogir.stack.validate-scope-inputs+0x38c>
    b23c:      	cmp	x4, #0x0
    b240:      	b.ge	0xb208 <_stogir.stack.validate-scope-inputs+0x388>
    b244:      	add	x5, x0, #0x28
    b248:      	add	x6, x0, #0x50
    b24c:      	ldr	x5, [x5, #0x8]
    b250:      	ldr	x6, [x6, #0x8]
    b254:      	cmp	x5, x6
    b258:      	b.ne	0xb2d8 <_stogir.stack.validate-scope-inputs+0x458>
    b25c:      	cmp	x2, x5
    b260:      	b.gt	0xb2e8 <_stogir.stack.validate-scope-inputs+0x468>
    b264:      	lsl	x2, x3, #2
    b268:      	ldr	x2, [x0, #0x50]
    b26c:      	add	x2, x2, x3, lsl #2
    b270:      	ldr	w2, [x2]
    b274:      	sxtw	x2, w2
    b278:      	cmp	x2, #0x0
    b27c:      	cset	w2, gt
    b280:      	ubfx	x2, x2, #0, #8
    b284:      	b	0xb2ec <_stogir.stack.validate-scope-inputs+0x46c>
    b288:      	brk	#0
    b28c:      	b	0xb288 <_stogir.stack.validate-scope-inputs+0x408>
    b290:      	lsr	w0, w1, #0
    b294:      	ubfx	x0, x0, #8, #8
    b298:      	cmp	x0, #0x6
    b29c:      	b.ne	0xb2bc <_stogir.stack.validate-scope-inputs+0x43c>
    b2a0:      	uxtb	w1, w1
    b2a4:      	cmp	x1, #0x48
    b2a8:      	b.eq	0xb2bc <_stogir.stack.validate-scope-inputs+0x43c>
    b2ac:      	movz	x0, #0x0, lsl #48
    b2b0:      	mov	x1, #0x8                ; =8
    b2b4:      	movz	x2, #0x0, lsl #48
    b2b8:      	b	0xb2d4 <_stogir.stack.validate-scope-inputs+0x454>
    b2bc:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x180>
		000000000000b2bc:  ARM64_RELOC_PAGE21	l_stogir.457
    b2c0:      	ldr	x16, [x16]
		000000000000b2c0:  ARM64_RELOC_PAGEOFF12	l_stogir.457
    b2c4:      	orr	x0, x16, xzr
    b2c8:      	mov	x1, x0
    b2cc:      	mov	x0, #0x1                ; =1
    b2d0:      	mov	x2, #0x29               ; =41
    b2d4:      	b	0xb1e8 <_stogir.stack.validate-scope-inputs+0x368>
    b2d8:      	movz	x2, #0x0, lsl #48
    b2dc:      	b	0xb20c <_stogir.stack.validate-scope-inputs+0x38c>
    b2e0:      	movz	x2, #0x0, lsl #48
    b2e4:      	b	0xb238 <_stogir.stack.validate-scope-inputs+0x3b8>
    b2e8:      	movz	x2, #0x0, lsl #48
    b2ec:      	b	0xb2dc <_stogir.stack.validate-scope-inputs+0x45c>
    b2f0:      	brk	#0
    b2f4:      	b	0xb2f0 <_stogir.stack.validate-scope-inputs+0x470>

000000000000b2f8 <_stogir.stack.validate-inputs>:
    b2f8:      	sub	sp, sp, #0x110
    b2fc:      	str	x29, [sp]
    b300:      	str	x30, [sp, #0x8]
    b304:      	mov	x29, sp
    b308:      	str	x19, [sp, #0xb8]
    b30c:      	str	x20, [sp, #0xc0]
    b310:      	str	x21, [sp, #0xc8]
    b314:      	str	x22, [sp, #0xd0]
    b318:      	str	x23, [sp, #0xd8]
    b31c:      	str	x24, [sp, #0xe0]
    b320:      	str	x25, [sp, #0xe8]
    b324:      	str	x26, [sp, #0xf0]
    b328:      	str	x27, [sp, #0xf8]
    b32c:      	str	x28, [sp, #0x100]
    b330:      	sxtw	x1, w1
    b334:      	cmp	x1, #0x51
    b338:      	cset	w19, eq
    b33c:      	uxtb	w16, w19
    b340:      	cmp	w16, wzr
    b344:      	b.ne	0xb3b4 <_stogir.stack.validate-inputs+0xbc>
    b348:      	cmp	x1, #0x52
    b34c:      	b.eq	0xb3b4 <_stogir.stack.validate-inputs+0xbc>
    b350:      	str	x8, [sp, #0x90]
    b354:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x180>
		000000000000b354:  ARM64_RELOC_PAGE21	l_stogir.458
    b358:      	ldr	x16, [x16]
		000000000000b358:  ARM64_RELOC_PAGEOFF12	l_stogir.458
    b35c:      	orr	x0, x16, xzr
    b360:      	mov	x1, x0
    b364:      	mov	x0, #0x1                ; =1
    b368:      	mov	x2, #0x29               ; =41
    b36c:      	ldr	x3, [sp, #0x90]
    b370:      	str	x0, [x3]
    b374:      	str	x1, [x3, #0x8]
    b378:      	str	x2, [x3, #0x10]
    b37c:      	ldr	x19, [sp, #0xb8]
    b380:      	ldr	x20, [sp, #0xc0]
    b384:      	ldr	x21, [sp, #0xc8]
    b388:      	ldr	x22, [sp, #0xd0]
    b38c:      	ldr	x23, [sp, #0xd8]
    b390:      	ldr	x24, [sp, #0xe0]
    b394:      	ldr	x25, [sp, #0xe8]
    b398:      	ldr	x26, [sp, #0xf0]
    b39c:      	ldr	x27, [sp, #0xf8]
    b3a0:      	ldr	x28, [sp, #0x100]
    b3a4:      	ldr	x29, [sp]
    b3a8:      	ldr	x30, [sp, #0x8]
    b3ac:      	add	sp, sp, #0x110
    b3b0:      	ret
    b3b4:      	uxtb	w16, w19
    b3b8:      	cmp	w16, wzr
    b3bc:      	mov	x16, #0x6               ; =6
    b3c0:      	movz	x17, #0x0, lsl #48
    b3c4:      	csel	x1, x16, x17, ne
    b3c8:      	sxtw	x2, w2
    b3cc:      	lsr	w1, w1, #0
    b3d0:      	sxtw	x1, w1
    b3d4:      	cmp	x2, x1
    b3d8:      	b.ne	0xb938 <_stogir.stack.validate-inputs+0x640>
    b3dc:      	sxtw	x20, w5
    b3e0:      	uxtb	w16, w19
    b3e4:      	cmp	w16, wzr
    b3e8:      	b.eq	0xb40c <_stogir.stack.validate-inputs+0x114>
    b3ec:      	cmp	x20, #0x0
    b3f0:      	b.eq	0xb40c <_stogir.stack.validate-inputs+0x114>
    b3f4:      	cmp	x20, #0x0
    b3f8:      	b.le	0xb4b4 <_stogir.stack.validate-inputs+0x1bc>
    b3fc:      	sub	x1, x20, #0x1
    b400:      	and	x1, x1, x20
    b404:      	cmp	x1, #0x0
    b408:      	b.ne	0xb4b4 <_stogir.stack.validate-inputs+0x1bc>
    b40c:      	lsr	w3, w3, #0
    b410:      	mov	w1, w3
    b414:      	mov	x21, x8
    b418:      	add	x8, sp, #0x10
    b41c:      	mov	x22, x0
    b420:      	mov	w23, w3
    b424:      	mov	w24, w4
    b428:      	bl	0xb428 <_stogir.stack.validate-inputs+0x130>
		000000000000b428:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    b42c:      	add	x16, sp, #0x10
    b430:      	ldr	w0, [x16]
    b434:      	lsr	x16, x0, #0
    b438:      	cmp	x16, #0x1
    b43c:      	b.eq	0xb458 <_stogir.stack.validate-inputs+0x160>
    b440:      	b.lo	0xb448 <_stogir.stack.validate-inputs+0x150>
    b444:      	b	0xb45c <_stogir.stack.validate-inputs+0x164>
    b448:      	cmp	x16, #0x0
    b44c:      	b.eq	0xb454 <_stogir.stack.validate-inputs+0x15c>
    b450:      	b	0xb45c <_stogir.stack.validate-inputs+0x164>
    b454:      	b	0xb460 <_stogir.stack.validate-inputs+0x168>
    b458:      	b	0xb480 <_stogir.stack.validate-inputs+0x188>
    b45c:      	b	0xb6b0 <_stogir.stack.validate-inputs+0x3b8>
    b460:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x180>
		000000000000b460:  ARM64_RELOC_PAGE21	l_stogir.459
    b464:      	ldr	x16, [x16]
		000000000000b464:  ARM64_RELOC_PAGEOFF12	l_stogir.459
    b468:      	orr	x0, x16, xzr
    b46c:      	str	x21, [sp, #0x90]
    b470:      	mov	x1, x0
    b474:      	mov	x0, #0x1                ; =1
    b478:      	mov	x2, #0x1f               ; =31
    b47c:      	b	0xb36c <_stogir.stack.validate-inputs+0x74>
    b480:      	sxtw	x23, w23
    b484:      	add	x16, sp, #0x10
    b488:      	ldr	x0, [x16, #0x8]
    b48c:      	cmp	x23, #0x0
    b490:      	b.gt	0xb4bc <_stogir.stack.validate-inputs+0x1c4>
    b494:      	str	x21, [sp, #0x90]
    b498:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x180>
		000000000000b498:  ARM64_RELOC_PAGE21	l_stogir.460
    b49c:      	ldr	x16, [x16]
		000000000000b49c:  ARM64_RELOC_PAGEOFF12	l_stogir.460
    b4a0:      	orr	x0, x16, xzr
    b4a4:      	mov	x1, x0
    b4a8:      	mov	x0, #0x1                ; =1
    b4ac:      	mov	x2, #0x1f               ; =31
    b4b0:      	b	0xb47c <_stogir.stack.validate-inputs+0x184>
    b4b4:      	str	x8, [sp, #0x90]
    b4b8:      	b	0xb354 <_stogir.stack.validate-inputs+0x5c>
    b4bc:      	uxtb	w0, w0
    b4c0:      	cmp	x0, #0x83
    b4c4:      	cset	w1, lt
    b4c8:      	uxtb	w16, w1
    b4cc:      	cmp	w16, wzr
    b4d0:      	b.eq	0xb4ec <_stogir.stack.validate-inputs+0x1f4>
    b4d4:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x180>
		000000000000b4d4:  ARM64_RELOC_PAGE21	l_stogir.461
    b4d8:      	ldr	x16, [x16]
		000000000000b4d8:  ARM64_RELOC_PAGEOFF12	l_stogir.461
    b4dc:      	orr	x2, x16, xzr
    b4e0:      	add	x2, x0, x2
    b4e4:      	ldrb	w2, [x2]
    b4e8:      	b	0xb4f0 <_stogir.stack.validate-inputs+0x1f8>
    b4ec:      	movz	x2, #0x0, lsl #48
    b4f0:      	uxtb	w2, w2
    b4f4:      	and	x2, x2, #0x1
    b4f8:      	uxtb	w2, w2
    b4fc:      	cmp	x2, #0x0
    b500:      	b.eq	0xb940 <_stogir.stack.validate-inputs+0x648>
    b504:      	uxtb	w16, w1
    b508:      	cmp	w16, wzr
    b50c:      	b.eq	0xb528 <_stogir.stack.validate-inputs+0x230>
    b510:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x180>
		000000000000b510:  ARM64_RELOC_PAGE21	l_stogir.461
    b514:      	ldr	x16, [x16]
		000000000000b514:  ARM64_RELOC_PAGEOFF12	l_stogir.461
    b518:      	orr	x1, x16, xzr
    b51c:      	add	x0, x0, x1
    b520:      	ldrb	w0, [x0]
    b524:      	b	0xb52c <_stogir.stack.validate-inputs+0x234>
    b528:      	movz	x0, #0x0, lsl #48
    b52c:      	uxtb	w0, w0
    b530:      	and	x0, x0, #0x4
    b534:      	uxtb	w0, w0
    b538:      	cmp	x0, #0x0
    b53c:      	cset	w0, eq
    b540:      	uxtb	w16, w0
    b544:      	cmp	w16, wzr
    b548:      	cset	x0, eq
    b54c:      	cmp	x0, #0x0
    b550:      	b.ne	0xb948 <_stogir.stack.validate-inputs+0x650>
    b554:      	lsr	w24, w24, #0
    b558:      	add	x8, sp, #0x40
    b55c:      	mov	x0, x22
    b560:      	mov	w1, w24
    b564:      	bl	0xb564 <_stogir.stack.validate-inputs+0x26c>
		000000000000b564:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    b568:      	add	x16, sp, #0x40
    b56c:      	ldr	w0, [x16]
    b570:      	lsr	x16, x0, #0
    b574:      	cmp	x16, #0x1
    b578:      	b.eq	0xb594 <_stogir.stack.validate-inputs+0x29c>
    b57c:      	b.lo	0xb584 <_stogir.stack.validate-inputs+0x28c>
    b580:      	b	0xb598 <_stogir.stack.validate-inputs+0x2a0>
    b584:      	cmp	x16, #0x0
    b588:      	b.eq	0xb590 <_stogir.stack.validate-inputs+0x298>
    b58c:      	b	0xb598 <_stogir.stack.validate-inputs+0x2a0>
    b590:      	b	0xb59c <_stogir.stack.validate-inputs+0x2a4>
    b594:      	b	0xb5bc <_stogir.stack.validate-inputs+0x2c4>
    b598:      	b	0xb840 <_stogir.stack.validate-inputs+0x548>
    b59c:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x180>
		000000000000b59c:  ARM64_RELOC_PAGE21	l_stogir.462
    b5a0:      	ldr	x16, [x16]
		000000000000b5a0:  ARM64_RELOC_PAGEOFF12	l_stogir.462
    b5a4:      	orr	x0, x16, xzr
    b5a8:      	str	x21, [sp, #0x90]
    b5ac:      	mov	x1, x0
    b5b0:      	mov	x0, #0x1                ; =1
    b5b4:      	mov	x2, #0x18               ; =24
    b5b8:      	b	0xb4b0 <_stogir.stack.validate-inputs+0x1b8>
    b5bc:      	add	x16, sp, #0x40
    b5c0:      	ldr	x0, [x16, #0x8]
    b5c4:      	lsr	w1, w0, #0
    b5c8:      	ubfx	x1, x1, #8, #8
    b5cc:      	cmp	x1, #0x1
    b5d0:      	b.lt	0xb950 <_stogir.stack.validate-inputs+0x658>
    b5d4:      	cmp	x1, #0xb
    b5d8:      	b.gt	0xb958 <_stogir.stack.validate-inputs+0x660>
    b5dc:      	uxtb	w0, w0
    b5e0:      	cmp	x0, #0x48
    b5e4:      	b.eq	0xb960 <_stogir.stack.validate-inputs+0x668>
    b5e8:      	sxtw	x0, w24
    b5ec:      	cmp	x1, #0x0
    b5f0:      	cset	w23, eq
    b5f4:      	cmp	x1, #0x1
    b5f8:      	cset	w25, eq
    b5fc:      	cmp	x1, #0x2
    b600:      	cset	w26, eq
    b604:      	cmp	x1, #0x7
    b608:      	cset	w27, eq
    b60c:      	cmp	x1, #0x8
    b610:      	cset	w28, eq
    b614:      	cmp	x1, #0x3
    b618:      	cset	w2, eq
    b61c:      	cmp	x1, #0x9
    b620:      	cset	w3, eq
    b624:      	cmp	x1, #0x4
    b628:      	cset	w4, eq
    b62c:      	cmp	x1, #0xa
    b630:      	cset	w5, eq
    b634:      	cmp	x1, #0xd
    b638:      	cset	w6, eq
    b63c:      	cmp	x1, #0x5
    b640:      	cset	w7, eq
    b644:      	cmp	x1, #0xb
    b648:      	cset	w8, eq
    b64c:      	cmp	x1, #0xc
    b650:      	cset	w9, eq
    b654:      	cmp	x1, #0x6
    b658:      	cset	w1, eq
    b65c:      	uxtb	w16, w1
    b660:      	cmp	w16, wzr
    b664:      	mov	x16, #0x8               ; =8
    b668:      	movn	x17, #0x0, lsl #48
    b66c:      	csel	x1, x16, x17, ne
    b670:      	cmp	x0, #0x0
    b674:      	b.ge	0xb968 <_stogir.stack.validate-inputs+0x670>
    b678:      	uxtb	w16, w19
    b67c:      	cmp	w16, wzr
    b680:      	b.eq	0xb7a4 <_stogir.stack.validate-inputs+0x4ac>
    b684:      	cmp	x20, #0x10
    b688:      	b.le	0xb7a4 <_stogir.stack.validate-inputs+0x4ac>
    b68c:      	mov	x0, x20
    b690:      	b	0xb7a8 <_stogir.stack.validate-inputs+0x4b0>
    b694:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x180>
		000000000000b694:  ARM64_RELOC_PAGE21	l_stogir.463
    b698:      	ldr	x16, [x16]
		000000000000b698:  ARM64_RELOC_PAGEOFF12	l_stogir.463
    b69c:      	orr	x0, x16, xzr
    b6a0:      	mov	x1, x0
    b6a4:      	mov	x0, #0x1                ; =1
    b6a8:      	mov	x2, #0x29               ; =41
    b6ac:      	b	0xb5b8 <_stogir.stack.validate-inputs+0x2c0>
    b6b0:      	brk	#0
    b6b4:      	b	0xb6b0 <_stogir.stack.validate-inputs+0x3b8>
    b6b8:      	mov	x0, #0x1                ; =1
    b6bc:      	lsr	w0, w0, #0
    b6c0:      	sxtw	x0, w0
    b6c4:      	and	x0, x0, #0xffffffff
    b6c8:      	mov	x1, x0
    b6cc:      	movz	x0, #0x0, lsl #48
    b6d0:      	movz	x2, #0x0, lsl #48
    b6d4:      	b	0xb6ac <_stogir.stack.validate-inputs+0x3b4>
    b6d8:      	uxtb	w16, w23
    b6dc:      	cmp	w16, wzr
    b6e0:      	b.eq	0xb70c <_stogir.stack.validate-inputs+0x414>
    b6e4:      	movz	x0, #0x0, lsl #48
    b6e8:      	b	0xb6bc <_stogir.stack.validate-inputs+0x3c4>
    b6ec:      	mov	x0, #0x1                ; =1
    b6f0:      	lsr	w0, w0, #0
    b6f4:      	sxtw	x0, w0
    b6f8:      	and	x0, x0, #0xffffffff
    b6fc:      	mov	x1, x0
    b700:      	movz	x0, #0x0, lsl #48
    b704:      	movz	x2, #0x0, lsl #48
    b708:      	b	0xb6d4 <_stogir.stack.validate-inputs+0x3dc>
    b70c:      	uxtb	w16, w25
    b710:      	cmp	w16, wzr
    b714:      	b.ne	0xb6b8 <_stogir.stack.validate-inputs+0x3c0>
    b718:      	uxtb	w16, w26
    b71c:      	cmp	w16, wzr
    b720:      	b.ne	0xb6b8 <_stogir.stack.validate-inputs+0x3c0>
    b724:      	uxtb	w16, w27
    b728:      	cmp	w16, wzr
    b72c:      	b.ne	0xb6b8 <_stogir.stack.validate-inputs+0x3c0>
    b730:      	uxtb	w16, w28
    b734:      	cmp	w16, wzr
    b738:      	b.ne	0xb6b8 <_stogir.stack.validate-inputs+0x3c0>
    b73c:      	uxtb	w16, w19
    b740:      	cmp	w16, wzr
    b744:      	b.ne	0xb900 <_stogir.stack.validate-inputs+0x608>
    b748:      	uxtb	w16, w20
    b74c:      	cmp	w16, wzr
    b750:      	b.ne	0xb900 <_stogir.stack.validate-inputs+0x608>
    b754:      	uxtb	w16, w22
    b758:      	cmp	w16, wzr
    b75c:      	b.ne	0xb918 <_stogir.stack.validate-inputs+0x620>
    b760:      	uxtb	w16, w24
    b764:      	cmp	w16, wzr
    b768:      	b.ne	0xb918 <_stogir.stack.validate-inputs+0x620>
    b76c:      	uxtb	w16, w21
    b770:      	cmp	w16, wzr
    b774:      	b.ne	0xb918 <_stogir.stack.validate-inputs+0x620>
    b778:      	uxtb	w16, w0
    b77c:      	cmp	w16, wzr
    b780:      	b.ne	0xb928 <_stogir.stack.validate-inputs+0x630>
    b784:      	uxtb	w16, w1
    b788:      	cmp	w16, wzr
    b78c:      	b.ne	0xb928 <_stogir.stack.validate-inputs+0x630>
    b790:      	uxtb	w16, w2
    b794:      	cmp	w16, wzr
    b798:      	b.ne	0xb928 <_stogir.stack.validate-inputs+0x630>
    b79c:      	ldr	x0, [sp, #0xb0]
    b7a0:      	b	0xb92c <_stogir.stack.validate-inputs+0x634>
    b7a4:      	mov	x0, #0x10               ; =16
    b7a8:      	lsr	w24, w24, #0
    b7ac:      	mov	w19, w2
    b7b0:      	mov	x2, x0
    b7b4:      	mov	x0, x22
    b7b8:      	mov	w20, w3
    b7bc:      	mov	w22, w4
    b7c0:      	str	w7, [sp, #0x98]
    b7c4:      	str	w8, [sp, #0xa0]
    b7c8:      	add	x8, sp, #0x70
    b7cc:      	str	w9, [sp, #0xa8]
    b7d0:      	str	x1, [sp, #0xb0]
    b7d4:      	mov	w1, w24
    b7d8:      	mov	w24, w5
    b7dc:      	str	x21, [sp, #0x90]
    b7e0:      	mov	w21, w6
    b7e4:      	bl	0xb7e4 <_stogir.stack.validate-inputs+0x4ec>
		000000000000b7e4:  ARM64_RELOC_BRANCH26	_stogir.stack.constant-size-aligned
    b7e8:      	add	x16, sp, #0x70
    b7ec:      	ldr	w0, [x16]
    b7f0:      	lsr	x16, x0, #0
    b7f4:      	cmp	x16, #0x1
    b7f8:      	b.eq	0xb814 <_stogir.stack.validate-inputs+0x51c>
    b7fc:      	b.lo	0xb804 <_stogir.stack.validate-inputs+0x50c>
    b800:      	b	0xb818 <_stogir.stack.validate-inputs+0x520>
    b804:      	cmp	x16, #0x0
    b808:      	b.eq	0xb810 <_stogir.stack.validate-inputs+0x518>
    b80c:      	b	0xb818 <_stogir.stack.validate-inputs+0x520>
    b810:      	b	0xb848 <_stogir.stack.validate-inputs+0x550>
    b814:      	b	0xb81c <_stogir.stack.validate-inputs+0x524>
    b818:      	b	0xb910 <_stogir.stack.validate-inputs+0x618>
    b81c:      	add	x16, sp, #0x70
    b820:      	orr	x0, x16, xzr
    b824:      	add	x0, x0, #0x8
    b828:      	add	x16, sp, #0x70
    b82c:      	ldr	x1, [x16, #0x8]
    b830:      	ldr	x0, [x0, #0x8]
    b834:      	mov	x2, x0
    b838:      	mov	x0, #0x1                ; =1
    b83c:      	b	0xb708 <_stogir.stack.validate-inputs+0x410>
    b840:      	brk	#0
    b844:      	b	0xb840 <_stogir.stack.validate-inputs+0x548>
    b848:      	uxtb	w16, w23
    b84c:      	cmp	w16, wzr
    b850:      	b.eq	0xb85c <_stogir.stack.validate-inputs+0x564>
    b854:      	movz	x0, #0x0, lsl #48
    b858:      	b	0xb6f0 <_stogir.stack.validate-inputs+0x3f8>
    b85c:      	uxtb	w16, w25
    b860:      	cmp	w16, wzr
    b864:      	b.ne	0xb6ec <_stogir.stack.validate-inputs+0x3f4>
    b868:      	uxtb	w16, w26
    b86c:      	cmp	w16, wzr
    b870:      	b.ne	0xb6ec <_stogir.stack.validate-inputs+0x3f4>
    b874:      	uxtb	w16, w27
    b878:      	cmp	w16, wzr
    b87c:      	b.ne	0xb6ec <_stogir.stack.validate-inputs+0x3f4>
    b880:      	uxtb	w16, w28
    b884:      	cmp	w16, wzr
    b888:      	b.ne	0xb6ec <_stogir.stack.validate-inputs+0x3f4>
    b88c:      	uxtb	w16, w19
    b890:      	cmp	w16, wzr
    b894:      	b.ne	0xb908 <_stogir.stack.validate-inputs+0x610>
    b898:      	uxtb	w16, w20
    b89c:      	cmp	w16, wzr
    b8a0:      	b.ne	0xb908 <_stogir.stack.validate-inputs+0x610>
    b8a4:      	uxtb	w16, w22
    b8a8:      	cmp	w16, wzr
    b8ac:      	b.ne	0xb920 <_stogir.stack.validate-inputs+0x628>
    b8b0:      	uxtb	w16, w24
    b8b4:      	cmp	w16, wzr
    b8b8:      	b.ne	0xb920 <_stogir.stack.validate-inputs+0x628>
    b8bc:      	uxtb	w16, w21
    b8c0:      	cmp	w16, wzr
    b8c4:      	b.ne	0xb920 <_stogir.stack.validate-inputs+0x628>
    b8c8:      	ldr	w0, [sp, #0x98]
    b8cc:      	uxtb	w16, w0
    b8d0:      	cmp	w16, wzr
    b8d4:      	b.ne	0xb930 <_stogir.stack.validate-inputs+0x638>
    b8d8:      	ldr	w1, [sp, #0xa0]
    b8dc:      	uxtb	w16, w1
    b8e0:      	cmp	w16, wzr
    b8e4:      	b.ne	0xb930 <_stogir.stack.validate-inputs+0x638>
    b8e8:      	ldr	w2, [sp, #0xa8]
    b8ec:      	uxtb	w16, w2
    b8f0:      	cmp	w16, wzr
    b8f4:      	b.ne	0xb930 <_stogir.stack.validate-inputs+0x638>
    b8f8:      	ldr	x0, [sp, #0xb0]
    b8fc:      	b	0xb934 <_stogir.stack.validate-inputs+0x63c>
    b900:      	mov	x0, #0x2                ; =2
    b904:      	b	0xb6bc <_stogir.stack.validate-inputs+0x3c4>
    b908:      	mov	x0, #0x2                ; =2
    b90c:      	b	0xb6f0 <_stogir.stack.validate-inputs+0x3f8>
    b910:      	brk	#0
    b914:      	b	0xb910 <_stogir.stack.validate-inputs+0x618>
    b918:      	mov	x0, #0x4                ; =4
    b91c:      	b	0xb904 <_stogir.stack.validate-inputs+0x60c>
    b920:      	mov	x0, #0x4                ; =4
    b924:      	b	0xb90c <_stogir.stack.validate-inputs+0x614>
    b928:      	mov	x0, #0x8                ; =8
    b92c:      	b	0xb91c <_stogir.stack.validate-inputs+0x624>
    b930:      	mov	x0, #0x8                ; =8
    b934:      	b	0xb924 <_stogir.stack.validate-inputs+0x62c>
    b938:      	str	x8, [sp, #0x90]
    b93c:      	b	0xb354 <_stogir.stack.validate-inputs+0x5c>
    b940:      	str	x21, [sp, #0x90]
    b944:      	b	0xb498 <_stogir.stack.validate-inputs+0x1a0>
    b948:      	str	x21, [sp, #0x90]
    b94c:      	b	0xb498 <_stogir.stack.validate-inputs+0x1a0>
    b950:      	str	x21, [sp, #0x90]
    b954:      	b	0xb694 <_stogir.stack.validate-inputs+0x39c>
    b958:      	str	x21, [sp, #0x90]
    b95c:      	b	0xb694 <_stogir.stack.validate-inputs+0x39c>
    b960:      	str	x21, [sp, #0x90]
    b964:      	b	0xb694 <_stogir.stack.validate-inputs+0x39c>
    b968:      	str	x21, [sp, #0x90]
    b96c:      	str	x1, [sp, #0xb0]
    b970:      	mov	w19, w2
    b974:      	mov	w20, w3
    b978:      	mov	w22, w4
    b97c:      	mov	w24, w5
    b980:      	mov	w21, w6
    b984:      	mov	w0, w7
    b988:      	mov	w1, w8
    b98c:      	mov	w2, w9
    b990:      	b	0xb6d8 <_stogir.stack.validate-inputs+0x3e0>

000000000000b994 <_stogir.locals.shape>:
    b994:      	sub	sp, sp, #0x40
    b998:      	str	x29, [sp]
    b99c:      	str	x30, [sp, #0x8]
    b9a0:      	mov	x29, sp
    b9a4:      	str	x19, [sp, #0x20]
    b9a8:      	str	x20, [sp, #0x28]
    b9ac:      	str	x21, [sp, #0x30]
    b9b0:      	str	x22, [sp, #0x38]
    b9b4:      	sxtw	x19, w1
    b9b8:      	lsl	x20, x19, #2
    b9bc:      	cmp	x19, #0x0
    b9c0:      	cset	w1, gt
    b9c4:      	movz	x16, #0x0, lsl #48
    b9c8:      	sub	x3, x16, x19
    b9cc:      	sub	x4, x3, #0x1
    b9d0:      	uxtb	w16, w1
    b9d4:      	cmp	w16, wzr
    b9d8:      	b.eq	0xba18 <_stogir.locals.shape+0x84>
    b9dc:      	ldr	x3, [x0, #0x8]
    b9e0:      	cmp	x19, x3
    b9e4:      	b.ge	0xba88 <_stogir.locals.shape+0xf4>
    b9e8:      	add	x3, x0, #0x78
    b9ec:      	ldr	x3, [x3, #0x8]
    b9f0:      	cmp	x19, x3
    b9f4:      	b.ge	0xbc54 <_stogir.locals.shape+0x2c0>
    b9f8:      	ldr	x3, [x0, #0x78]
    b9fc:      	add	x3, x20, x3
    ba00:      	ldr	w3, [x3]
    ba04:      	sxtw	x3, w3
    ba08:      	cmp	x3, #0x0
    ba0c:      	cset	w3, ge
    ba10:      	ubfx	x3, x3, #0, #8
    ba14:      	b	0xbc58 <_stogir.locals.shape+0x2c4>
    ba18:      	cmp	x19, #0x0
    ba1c:      	b.ge	0xba90 <_stogir.locals.shape+0xfc>
    ba20:      	add	x5, x0, #0x28
    ba24:      	add	x6, x0, #0x50
    ba28:      	ldr	x5, [x5, #0x8]
    ba2c:      	ldr	x6, [x6, #0x8]
    ba30:      	cmp	x5, x6
    ba34:      	b.ne	0xba64 <_stogir.locals.shape+0xd0>
    ba38:      	cmp	x3, x5
    ba3c:      	b.gt	0xbd28 <_stogir.locals.shape+0x394>
    ba40:      	lsl	x3, x4, #2
    ba44:      	ldr	x3, [x0, #0x50]
    ba48:      	add	x3, x3, x4, lsl #2
    ba4c:      	ldr	w3, [x3]
    ba50:      	sxtw	x3, w3
    ba54:      	cmp	x3, #0x0
    ba58:      	cset	w3, gt
    ba5c:      	ubfx	x3, x3, #0, #8
    ba60:      	b	0xbd2c <_stogir.locals.shape+0x398>
    ba64:      	movz	x3, #0x0, lsl #48
    ba68:      	b	0xba94 <_stogir.locals.shape+0x100>
    ba6c:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x180>
		000000000000ba6c:  ARM64_RELOC_PAGE21	l_stogir.464
    ba70:      	ldr	x16, [x16]
		000000000000ba70:  ARM64_RELOC_PAGEOFF12	l_stogir.464
    ba74:      	orr	x0, x16, xzr
    ba78:      	mov	x1, x0
    ba7c:      	mov	x0, #0x1                ; =1
    ba80:      	mov	x2, #0x1c               ; =28
    ba84:      	b	0xbb54 <_stogir.locals.shape+0x1c0>
    ba88:      	movz	x3, #0x0, lsl #48
    ba8c:      	b	0xba94 <_stogir.locals.shape+0x100>
    ba90:      	movz	x3, #0x0, lsl #48
    ba94:      	cmp	x3, #0x0
    ba98:      	b.eq	0xbafc <_stogir.locals.shape+0x168>
    ba9c:      	uxtb	w16, w1
    baa0:      	cmp	w16, wzr
    baa4:      	b.eq	0xbacc <_stogir.locals.shape+0x138>
    baa8:      	lsl	x1, x19, #4
    baac:      	ldr	x1, [x0]
    bab0:      	add	x1, x1, x19, lsl #4
    bab4:      	ldr	x3, [x1]
    bab8:      	ldr	x1, [x1, #0x8]
    babc:      	fmov	d31, x1
    bac0:      	mov	x1, x3
    bac4:      	fmov	x3, d31
    bac8:      	b	0xbaec <_stogir.locals.shape+0x158>
    bacc:      	lsl	x1, x4, #4
    bad0:      	ldr	x1, [x0, #0x28]
    bad4:      	add	x1, x1, x4, lsl #4
    bad8:      	ldr	x3, [x1]
    badc:      	ldr	x1, [x1, #0x8]
    bae0:      	fmov	d31, x1
    bae4:      	mov	x1, x3
    bae8:      	fmov	x3, d31
    baec:      	mov	x4, x3
    baf0:      	mov	x3, x1
    baf4:      	mov	x1, #0x1                ; =1
    baf8:      	b	0xbb08 <_stogir.locals.shape+0x174>
    bafc:      	movz	x1, #0x0, lsl #48
    bb00:      	movz	x3, #0x0, lsl #48
    bb04:      	movz	x4, #0x0, lsl #48
    bb08:      	lsr	w1, w1, #0
    bb0c:      	lsr	x16, x1, #0
    bb10:      	cmp	x16, #0x1
    bb14:      	b.eq	0xbb30 <_stogir.locals.shape+0x19c>
    bb18:      	b.lo	0xbb20 <_stogir.locals.shape+0x18c>
    bb1c:      	b	0xbb34 <_stogir.locals.shape+0x1a0>
    bb20:      	cmp	x16, #0x0
    bb24:      	b.eq	0xbb2c <_stogir.locals.shape+0x198>
    bb28:      	b	0xbb34 <_stogir.locals.shape+0x1a0>
    bb2c:      	b	0xbb38 <_stogir.locals.shape+0x1a4>
    bb30:      	b	0xbb80 <_stogir.locals.shape+0x1ec>
    bb34:      	b	0xbd7c <_stogir.locals.shape+0x3e8>
    bb38:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x180>
		000000000000bb38:  ARM64_RELOC_PAGE21	l_stogir.465
    bb3c:      	ldr	x16, [x16]
		000000000000bb3c:  ARM64_RELOC_PAGEOFF12	l_stogir.465
    bb40:      	orr	x0, x16, xzr
    bb44:      	mov	x21, x8
    bb48:      	mov	x1, x0
    bb4c:      	mov	x0, #0x1                ; =1
    bb50:      	mov	x2, #0x16               ; =22
    bb54:      	str	x0, [x21]
    bb58:      	str	x1, [x21, #0x8]
    bb5c:      	str	x2, [x21, #0x10]
    bb60:      	ldr	x19, [sp, #0x20]
    bb64:      	ldr	x20, [sp, #0x28]
    bb68:      	ldr	x21, [sp, #0x30]
    bb6c:      	ldr	x22, [sp, #0x38]
    bb70:      	ldr	x29, [sp]
    bb74:      	ldr	x30, [sp, #0x8]
    bb78:      	add	sp, sp, #0x40
    bb7c:      	ret
    bb80:      	lsr	w2, w2, #0
    bb84:      	lsr	w1, w3, #0
    bb88:      	add	x16, sp, #0x10
    bb8c:      	str	x3, [x16]
    bb90:      	add	x16, sp, #0x10
    bb94:      	str	x4, [x16, #0x8]
    bb98:      	ubfx	x1, x1, #8, #8
    bb9c:      	lsr	w1, w1, #0
    bba0:      	mov	x21, x8
    bba4:      	mov	x22, x0
    bba8:      	mov	w0, w1
    bbac:      	mov	w1, w2
    bbb0:      	bl	0xbbb0 <_stogir.locals.shape+0x21c>
		000000000000bbb0:  ARM64_RELOC_BRANCH26	_stogir.types.size
    bbb4:      	lsr	w0, w0, #0
    bbb8:      	add	x16, sp, #0x10
    bbbc:      	ldr	w1, [x16, #0xc]
    bbc0:      	sxtw	x0, w0
    bbc4:      	sxtw	x1, w1
    bbc8:      	cmp	x1, #0x0
    bbcc:      	b.ne	0xbbd4 <_stogir.locals.shape+0x240>
    bbd0:      	mov	x1, x0
    bbd4:      	add	x16, sp, #0x10
    bbd8:      	ldr	w2, [x16, #0x8]
    bbdc:      	sxtw	x2, w2
    bbe0:      	cmp	x2, #0x0
    bbe4:      	cset	w3, eq
    bbe8:      	ubfx	x3, x3, #0, #8
    bbec:      	cmp	x2, #0x0
    bbf0:      	b.le	0xbc5c <_stogir.locals.shape+0x2c8>
    bbf4:      	add	x4, x22, #0x110
    bbf8:      	add	x5, x4, #0x28
    bbfc:      	ldr	x5, [x5, #0x8]
    bc00:      	cmp	x2, x5
    bc04:      	b.gt	0xbd40 <_stogir.locals.shape+0x3ac>
    bc08:      	sub	x2, x2, #0x1
    bc0c:      	mov	x17, #0x18              ; =24
    bc10:      	mul	x2, x2, x17
    bc14:      	ldr	x5, [x4, #0x28]
    bc18:      	add	x2, x2, x5
    bc1c:      	ldr	x5, [x2]
    bc20:      	ldr	x2, [x2, #0x8]
    bc24:      	ldr	x4, [x4, #0x8]
    bc28:      	cmp	x5, #0x0
    bc2c:      	b.lt	0xbd38 <_stogir.locals.shape+0x3a4>
    bc30:      	cmp	x5, x4
    bc34:      	b.gt	0xbd38 <_stogir.locals.shape+0x3a4>
    bc38:      	cmp	x2, #0x0
    bc3c:      	b.lt	0xbd38 <_stogir.locals.shape+0x3a4>
    bc40:      	sub	x4, x4, x5
    bc44:      	cmp	x2, x4
    bc48:      	b.gt	0xbd38 <_stogir.locals.shape+0x3a4>
    bc4c:      	mov	x2, #0x1                ; =1
    bc50:      	b	0xbd3c <_stogir.locals.shape+0x3a8>
    bc54:      	movz	x3, #0x0, lsl #48
    bc58:      	b	0xba8c <_stogir.locals.shape+0xf8>
    bc5c:      	mov	x2, x3
    bc60:      	cmp	x19, #0x0
    bc64:      	b.le	0xba6c <_stogir.locals.shape+0xd8>
    bc68:      	add	x16, sp, #0x10
    bc6c:      	ldr	w3, [x16]
    bc70:      	uxtb	w3, w3
    bc74:      	cmp	x3, #0x48
    bc78:      	b.ne	0xba6c <_stogir.locals.shape+0xd8>
    bc7c:      	ldr	x3, [x22, #0x78]
    bc80:      	add	x3, x20, x3
    bc84:      	ldr	w3, [x3]
    bc88:      	sxtw	x3, w3
    bc8c:      	cmp	x3, #0x3
    bc90:      	b.ne	0xba6c <_stogir.locals.shape+0xd8>
    bc94:      	cmp	x0, #0x0
    bc98:      	b.le	0xba6c <_stogir.locals.shape+0xd8>
    bc9c:      	cmp	x2, #0x0
    bca0:      	b.eq	0xba6c <_stogir.locals.shape+0xd8>
    bca4:      	cmp	x1, #0x0
    bca8:      	b.le	0xba6c <_stogir.locals.shape+0xd8>
    bcac:      	sub	x2, x1, #0x1
    bcb0:      	and	x2, x2, x1
    bcb4:      	cmp	x2, #0x0
    bcb8:      	b.ne	0xba6c <_stogir.locals.shape+0xd8>
    bcbc:      	add	x16, sp, #0x10
    bcc0:      	ldr	w2, [x16, #0x4]
    bcc4:      	sxtw	x2, w2
    bcc8:      	cmp	x2, #0x0
    bccc:      	cset	w3, gt
    bcd0:      	movz	x16, #0x0, lsl #48
    bcd4:      	sub	x4, x16, x2
    bcd8:      	sub	x5, x4, #0x1
    bcdc:      	uxtb	w16, w3
    bce0:      	cmp	w16, wzr
    bce4:      	b.eq	0xbda8 <_stogir.locals.shape+0x414>
    bce8:      	ldr	x4, [x22, #0x8]
    bcec:      	cmp	x2, x4
    bcf0:      	b.ge	0xbdf4 <_stogir.locals.shape+0x460>
    bcf4:      	add	x4, x22, #0x78
    bcf8:      	ldr	x4, [x4, #0x8]
    bcfc:      	cmp	x2, x4
    bd00:      	b.ge	0xbed8 <_stogir.locals.shape+0x544>
    bd04:      	lsl	x4, x2, #2
    bd08:      	ldr	x4, [x22, #0x78]
    bd0c:      	add	x4, x4, x2, lsl #2
    bd10:      	ldr	w4, [x4]
    bd14:      	sxtw	x4, w4
    bd18:      	cmp	x4, #0x0
    bd1c:      	cset	w4, ge
    bd20:      	ubfx	x4, x4, #0, #8
    bd24:      	b	0xbedc <_stogir.locals.shape+0x548>
    bd28:      	movz	x3, #0x0, lsl #48
    bd2c:      	b	0xba68 <_stogir.locals.shape+0xd4>
    bd30:      	mov	x2, #0x1                ; =1
    bd34:      	b	0xbc60 <_stogir.locals.shape+0x2cc>
    bd38:      	movz	x2, #0x0, lsl #48
    bd3c:      	b	0xbd44 <_stogir.locals.shape+0x3b0>
    bd40:      	movz	x2, #0x0, lsl #48
    bd44:      	lsr	w2, w2, #0
    bd48:      	lsr	x16, x2, #0
    bd4c:      	cmp	x16, #0x1
    bd50:      	b.eq	0xbd6c <_stogir.locals.shape+0x3d8>
    bd54:      	b.lo	0xbd5c <_stogir.locals.shape+0x3c8>
    bd58:      	b	0xbd70 <_stogir.locals.shape+0x3dc>
    bd5c:      	cmp	x16, #0x0
    bd60:      	b.eq	0xbd68 <_stogir.locals.shape+0x3d4>
    bd64:      	b	0xbd70 <_stogir.locals.shape+0x3dc>
    bd68:      	b	0xbd74 <_stogir.locals.shape+0x3e0>
    bd6c:      	b	0xbd30 <_stogir.locals.shape+0x39c>
    bd70:      	b	0xbd84 <_stogir.locals.shape+0x3f0>
    bd74:      	mov	x2, x3
    bd78:      	b	0xbd34 <_stogir.locals.shape+0x3a0>
    bd7c:      	brk	#0
    bd80:      	b	0xbd7c <_stogir.locals.shape+0x3e8>
    bd84:      	brk	#0
    bd88:      	b	0xbd84 <_stogir.locals.shape+0x3f0>
    bd8c:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x180>
		000000000000bd8c:  ARM64_RELOC_PAGE21	l_stogir.466
    bd90:      	ldr	x16, [x16]
		000000000000bd90:  ARM64_RELOC_PAGEOFF12	l_stogir.466
    bd94:      	orr	x0, x16, xzr
    bd98:      	mov	x1, x0
    bd9c:      	mov	x0, #0x1                ; =1
    bda0:      	mov	x2, #0x2c               ; =44
    bda4:      	b	0xba84 <_stogir.locals.shape+0xf0>
    bda8:      	cmp	x2, #0x0
    bdac:      	b.ge	0xbdfc <_stogir.locals.shape+0x468>
    bdb0:      	add	x6, x22, #0x28
    bdb4:      	add	x7, x22, #0x50
    bdb8:      	ldr	x6, [x6, #0x8]
    bdbc:      	ldr	x7, [x7, #0x8]
    bdc0:      	cmp	x6, x7
    bdc4:      	b.ne	0xbed0 <_stogir.locals.shape+0x53c>
    bdc8:      	cmp	x4, x6
    bdcc:      	b.gt	0xbee0 <_stogir.locals.shape+0x54c>
    bdd0:      	lsl	x4, x5, #2
    bdd4:      	ldr	x4, [x22, #0x50]
    bdd8:      	add	x4, x4, x5, lsl #2
    bddc:      	ldr	w4, [x4]
    bde0:      	sxtw	x4, w4
    bde4:      	cmp	x4, #0x0
    bde8:      	cset	w4, gt
    bdec:      	ubfx	x4, x4, #0, #8
    bdf0:      	b	0xbee4 <_stogir.locals.shape+0x550>
    bdf4:      	movz	x4, #0x0, lsl #48
    bdf8:      	b	0xbe00 <_stogir.locals.shape+0x46c>
    bdfc:      	movz	x4, #0x0, lsl #48
    be00:      	cmp	x4, #0x0
    be04:      	b.eq	0xbe44 <_stogir.locals.shape+0x4b0>
    be08:      	uxtb	w16, w3
    be0c:      	cmp	w16, wzr
    be10:      	b.eq	0xbe28 <_stogir.locals.shape+0x494>
    be14:      	lsl	x3, x2, #4
    be18:      	ldr	x3, [x22]
    be1c:      	add	x2, x3, x2, lsl #4
    be20:      	ldr	x2, [x2]
    be24:      	b	0xbe38 <_stogir.locals.shape+0x4a4>
    be28:      	lsl	x2, x5, #4
    be2c:      	ldr	x2, [x22, #0x28]
    be30:      	add	x2, x2, x5, lsl #4
    be34:      	ldr	x2, [x2]
    be38:      	mov	x3, x2
    be3c:      	mov	x2, #0x1                ; =1
    be40:      	b	0xbe4c <_stogir.locals.shape+0x4b8>
    be44:      	movz	x2, #0x0, lsl #48
    be48:      	movz	x3, #0x0, lsl #48
    be4c:      	lsr	w2, w2, #0
    be50:      	lsr	x16, x2, #0
    be54:      	cmp	x16, #0x1
    be58:      	b.eq	0xbe74 <_stogir.locals.shape+0x4e0>
    be5c:      	b.lo	0xbe64 <_stogir.locals.shape+0x4d0>
    be60:      	b	0xbe78 <_stogir.locals.shape+0x4e4>
    be64:      	cmp	x16, #0x0
    be68:      	b.eq	0xbe70 <_stogir.locals.shape+0x4dc>
    be6c:      	b	0xbe78 <_stogir.locals.shape+0x4e4>
    be70:      	b	0xbe7c <_stogir.locals.shape+0x4e8>
    be74:      	b	0xbe98 <_stogir.locals.shape+0x504>
    be78:      	b	0xbf24 <_stogir.locals.shape+0x590>
    be7c:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x180>
		000000000000be7c:  ARM64_RELOC_PAGE21	l_stogir.467
    be80:      	ldr	x16, [x16]
		000000000000be80:  ARM64_RELOC_PAGEOFF12	l_stogir.467
    be84:      	orr	x0, x16, xzr
    be88:      	mov	x1, x0
    be8c:      	mov	x0, #0x1                ; =1
    be90:      	mov	x2, #0x1d               ; =29
    be94:      	b	0xbda4 <_stogir.locals.shape+0x410>
    be98:      	add	x16, sp, #0x10
    be9c:      	ldr	w2, [x16, #0x4]
    bea0:      	sxtw	x2, w2
    bea4:      	cmp	x2, #0x0
    bea8:      	b.le	0xbd8c <_stogir.locals.shape+0x3f8>
    beac:      	uxtb	w3, w3
    beb0:      	cmp	x3, #0x83
    beb4:      	b.ge	0xbee8 <_stogir.locals.shape+0x554>
    beb8:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x180>
		000000000000beb8:  ARM64_RELOC_PAGE21	l_stogir.468
    bebc:      	ldr	x16, [x16]
		000000000000bebc:  ARM64_RELOC_PAGEOFF12	l_stogir.468
    bec0:      	orr	x2, x16, xzr
    bec4:      	add	x2, x3, x2
    bec8:      	ldrb	w2, [x2]
    becc:      	b	0xbeec <_stogir.locals.shape+0x558>
    bed0:      	movz	x4, #0x0, lsl #48
    bed4:      	b	0xbe00 <_stogir.locals.shape+0x46c>
    bed8:      	movz	x4, #0x0, lsl #48
    bedc:      	b	0xbdf8 <_stogir.locals.shape+0x464>
    bee0:      	movz	x4, #0x0, lsl #48
    bee4:      	b	0xbed4 <_stogir.locals.shape+0x540>
    bee8:      	movz	x2, #0x0, lsl #48
    beec:      	uxtb	w2, w2
    bef0:      	and	x2, x2, #0x2
    bef4:      	uxtb	w2, w2
    bef8:      	cmp	x2, #0x0
    befc:      	cset	w2, eq
    bf00:      	uxtb	w16, w2
    bf04:      	cmp	w16, wzr
    bf08:      	cset	x2, eq
    bf0c:      	cmp	x2, #0x0
    bf10:      	b.eq	0xbd8c <_stogir.locals.shape+0x3f8>
    bf14:      	mov	x2, x1
    bf18:      	mov	x1, x0
    bf1c:      	movz	x0, #0x0, lsl #48
    bf20:      	b	0xbda4 <_stogir.locals.shape+0x410>
    bf24:      	brk	#0
    bf28:      	b	0xbf24 <_stogir.locals.shape+0x590>

000000000000bf2c <_stogir.conversion.policy>:
    bf2c:      	sub	sp, sp, #0x70
    bf30:      	str	x29, [sp]
    bf34:      	str	x30, [sp, #0x8]
    bf38:      	mov	x29, sp
    bf3c:      	str	x19, [sp, #0x20]
    bf40:      	str	x20, [sp, #0x28]
    bf44:      	str	x21, [sp, #0x30]
    bf48:      	str	x22, [sp, #0x38]
    bf4c:      	str	x23, [sp, #0x40]
    bf50:      	str	x24, [sp, #0x48]
    bf54:      	str	x25, [sp, #0x50]
    bf58:      	str	x26, [sp, #0x58]
    bf5c:      	str	x27, [sp, #0x60]
    bf60:      	str	x28, [sp, #0x68]
    bf64:      	sxtw	x19, w0
    bf68:      	sxtw	x20, w1
    bf6c:      	sxtw	x21, w2
    bf70:      	cmp	x19, #0x24
    bf74:      	b.ne	0xbfb8 <_stogir.conversion.policy+0x8c>
    bf78:      	cmp	x20, #0xf
    bf7c:      	b.le	0xc1d4 <_stogir.conversion.policy+0x2a8>
    bf80:      	cmp	x20, #0x80
    bf84:      	b.ge	0xc1d4 <_stogir.conversion.policy+0x2a8>
    bf88:      	and	x0, x20, #0xf
    bf8c:      	lsr	w0, w0, #0
    bf90:      	sxtw	x0, w0
    bf94:      	cmp	x0, #0x1
    bf98:      	b.lt	0xc1d4 <_stogir.conversion.policy+0x2a8>
    bf9c:      	cmp	x0, #0xd
    bfa0:      	b.gt	0xc1d4 <_stogir.conversion.policy+0x2a8>
    bfa4:      	mov	x0, #0x1                ; =1
    bfa8:      	b	0xbfb0 <_stogir.conversion.policy+0x84>
    bfac:      	movz	x0, #0x0, lsl #48
    bfb0:      	mov	x22, x0
    bfb4:      	b	0xbfbc <_stogir.conversion.policy+0x90>
    bfb8:      	movz	x22, #0x0, lsl #48
    bfbc:      	sxtw	x23, w3
    bfc0:      	cmp	x20, #0xd
    bfc4:      	cset	w24, eq
    bfc8:      	cmp	x20, #0xc
    bfcc:      	cset	w25, eq
    bfd0:      	cmp	x23, #0x4
    bfd4:      	cset	w26, eq
    bfd8:      	cmp	x23, #0x8
    bfdc:      	cset	w27, eq
    bfe0:      	cmp	x22, #0x0
    bfe4:      	b.eq	0xc4bc <_stogir.conversion.policy+0x590>
    bfe8:      	lsr	w1, w1, #0
    bfec:      	lsr	w3, w3, #0
    bff0:      	mov	w0, w1
    bff4:      	mov	w1, w3
    bff8:      	str	x8, [sp, #0x18]
    bffc:      	mov	w28, w3
    c000:      	str	x23, [sp, #0x10]
    c004:      	mov	w23, w2
    c008:      	bl	0xc008 <_stogir.conversion.policy+0xdc>
		000000000000c008:  ARM64_RELOC_BRANCH26	_stogir.types.size
    c00c:      	lsr	w0, w0, #0
    c010:      	sxtw	x0, w0
    c014:      	b	0xc024 <_stogir.conversion.policy+0xf8>
    c018:      	mov	x0, #0x1                ; =1
    c01c:      	lsr	w0, w0, #0
    c020:      	sxtw	x0, w0
    c024:      	cmp	x21, #0xd
    c028:      	cset	w1, eq
    c02c:      	cmp	x21, #0xc
    c030:      	cset	w2, eq
    c034:      	cmp	x22, #0x0
    c038:      	b.eq	0xc4d0 <_stogir.conversion.policy+0x5a4>
    c03c:      	lsr	w23, w23, #0
    c040:      	lsr	w28, w28, #0
    c044:      	mov	x22, x0
    c048:      	mov	w0, w23
    c04c:      	mov	w23, w1
    c050:      	mov	w1, w28
    c054:      	mov	w28, w2
    c058:      	bl	0xc058 <_stogir.conversion.policy+0x12c>
		000000000000c058:  ARM64_RELOC_BRANCH26	_stogir.types.size
    c05c:      	lsr	w0, w0, #0
    c060:      	sxtw	x0, w0
    c064:      	b	0xc074 <_stogir.conversion.policy+0x148>
    c068:      	mov	x0, #0x1                ; =1
    c06c:      	lsr	w0, w0, #0
    c070:      	sxtw	x0, w0
    c074:      	cmp	x19, #0x21
    c078:      	b.lt	0xc154 <_stogir.conversion.policy+0x228>
    c07c:      	cmp	x19, #0x27
    c080:      	b.gt	0xc154 <_stogir.conversion.policy+0x228>
    c084:      	lsl	x1, x22, #3
    c088:      	lsr	w1, w1, #0
    c08c:      	sxtw	x1, w1
    c090:      	cmp	x1, #0x0
    c094:      	b.le	0xc154 <_stogir.conversion.policy+0x228>
    c098:      	lsl	x0, x0, #3
    c09c:      	lsr	w0, w0, #0
    c0a0:      	sxtw	x0, w0
    c0a4:      	cmp	x0, #0x0
    c0a8:      	b.le	0xc154 <_stogir.conversion.policy+0x228>
    c0ac:      	cmp	x19, #0x26
    c0b0:      	cset	w2, eq
    c0b4:      	cmp	x20, #0x1
    c0b8:      	cset	w3, ge
    c0bc:      	cmp	x20, #0xb
    c0c0:      	cset	w4, le
    c0c4:      	cmp	x21, #0x1
    c0c8:      	cset	w5, ge
    c0cc:      	cmp	x21, #0xb
    c0d0:      	cset	w6, le
    c0d4:      	cmp	x19, #0x25
    c0d8:      	b.lt	0xc35c <_stogir.conversion.policy+0x430>
    c0dc:      	ubfx	x23, x23, #0, #8
    c0e0:      	cmp	x19, #0x25
    c0e4:      	b.ne	0xc3cc <_stogir.conversion.policy+0x4a0>
    c0e8:      	uxtb	w16, w3
    c0ec:      	cmp	w16, wzr
    c0f0:      	b.eq	0xc3c4 <_stogir.conversion.policy+0x498>
    c0f4:      	uxtb	w16, w4
    c0f8:      	cmp	w16, wzr
    c0fc:      	b.eq	0xc3c4 <_stogir.conversion.policy+0x498>
    c100:      	uxtb	w16, w28
    c104:      	cmp	w16, wzr
    c108:      	b.eq	0xc440 <_stogir.conversion.policy+0x514>
    c10c:      	mov	x3, #0x1                ; =1
    c110:      	b	0xc444 <_stogir.conversion.policy+0x518>
    c114:      	uxtb	w16, w26
    c118:      	cmp	w16, wzr
    c11c:      	b.ne	0xc1b4 <_stogir.conversion.policy+0x288>
    c120:      	uxtb	w16, w27
    c124:      	cmp	w16, wzr
    c128:      	b.ne	0xc1b4 <_stogir.conversion.policy+0x288>
    c12c:      	movn	x0, #0x0, lsl #48
    c130:      	b	0xc06c <_stogir.conversion.policy+0x140>
    c134:      	uxtb	w16, w26
    c138:      	cmp	w16, wzr
    c13c:      	b.ne	0xc1c4 <_stogir.conversion.policy+0x298>
    c140:      	uxtb	w16, w27
    c144:      	cmp	w16, wzr
    c148:      	b.ne	0xc1c4 <_stogir.conversion.policy+0x298>
    c14c:      	movn	x0, #0x0, lsl #48
    c150:      	b	0xc01c <_stogir.conversion.policy+0xf0>
    c154:      	adrp	x16, 0xc000 <_stogir.conversion.policy+0xd4>
		000000000000c154:  ARM64_RELOC_PAGE21	l_stogir.469
    c158:      	ldr	x16, [x16]
		000000000000c158:  ARM64_RELOC_PAGEOFF12	l_stogir.469
    c15c:      	orr	x0, x16, xzr
    c160:      	mov	x1, x0
    c164:      	mov	x0, #0x1                ; =1
    c168:      	mov	x2, #0x22               ; =34
    c16c:      	ldr	x3, [sp, #0x18]
    c170:      	str	x0, [x3]
    c174:      	str	x1, [x3, #0x8]
    c178:      	str	x2, [x3, #0x10]
    c17c:      	ldr	x19, [sp, #0x20]
    c180:      	ldr	x20, [sp, #0x28]
    c184:      	ldr	x21, [sp, #0x30]
    c188:      	ldr	x22, [sp, #0x38]
    c18c:      	ldr	x23, [sp, #0x40]
    c190:      	ldr	x24, [sp, #0x48]
    c194:      	ldr	x25, [sp, #0x50]
    c198:      	ldr	x26, [sp, #0x58]
    c19c:      	ldr	x27, [sp, #0x60]
    c1a0:      	ldr	x28, [sp, #0x68]
    c1a4:      	ldr	x29, [sp]
    c1a8:      	ldr	x30, [sp, #0x8]
    c1ac:      	add	sp, sp, #0x70
    c1b0:      	ret
    c1b4:      	cmp	x21, #0x0
    c1b8:      	b.ne	0xc210 <_stogir.conversion.policy+0x2e4>
    c1bc:      	movz	x0, #0x0, lsl #48
    c1c0:      	b	0xc06c <_stogir.conversion.policy+0x140>
    c1c4:      	cmp	x20, #0x0
    c1c8:      	b.ne	0xc288 <_stogir.conversion.policy+0x35c>
    c1cc:      	movz	x0, #0x0, lsl #48
    c1d0:      	b	0xc01c <_stogir.conversion.policy+0xf0>
    c1d4:      	cmp	x21, #0xf
    c1d8:      	b.le	0xbfac <_stogir.conversion.policy+0x80>
    c1dc:      	cmp	x21, #0x80
    c1e0:      	b.ge	0xc208 <_stogir.conversion.policy+0x2dc>
    c1e4:      	and	x0, x21, #0xf
    c1e8:      	lsr	w0, w0, #0
    c1ec:      	sxtw	x0, w0
    c1f0:      	cmp	x0, #0x1
    c1f4:      	b.lt	0xc300 <_stogir.conversion.policy+0x3d4>
    c1f8:      	cmp	x0, #0xd
    c1fc:      	cset	w0, le
    c200:      	ubfx	x0, x0, #0, #8
    c204:      	b	0xc304 <_stogir.conversion.policy+0x3d8>
    c208:      	movz	x0, #0x0, lsl #48
    c20c:      	b	0xbfb0 <_stogir.conversion.policy+0x84>
    c210:      	cmp	x21, #0x1
    c214:      	b.eq	0xc068 <_stogir.conversion.policy+0x13c>
    c218:      	cmp	x21, #0x2
    c21c:      	b.eq	0xc068 <_stogir.conversion.policy+0x13c>
    c220:      	cmp	x21, #0x7
    c224:      	b.eq	0xc068 <_stogir.conversion.policy+0x13c>
    c228:      	cmp	x21, #0x8
    c22c:      	b.eq	0xc068 <_stogir.conversion.policy+0x13c>
    c230:      	cmp	x21, #0x3
    c234:      	b.eq	0xc3f8 <_stogir.conversion.policy+0x4cc>
    c238:      	cmp	x21, #0x9
    c23c:      	b.eq	0xc3f8 <_stogir.conversion.policy+0x4cc>
    c240:      	cmp	x21, #0x4
    c244:      	b.eq	0xc468 <_stogir.conversion.policy+0x53c>
    c248:      	cmp	x21, #0xa
    c24c:      	b.eq	0xc468 <_stogir.conversion.policy+0x53c>
    c250:      	uxtb	w16, w23
    c254:      	cmp	w16, wzr
    c258:      	b.ne	0xc468 <_stogir.conversion.policy+0x53c>
    c25c:      	cmp	x21, #0x5
    c260:      	b.eq	0xc49c <_stogir.conversion.policy+0x570>
    c264:      	cmp	x21, #0xb
    c268:      	b.eq	0xc49c <_stogir.conversion.policy+0x570>
    c26c:      	uxtb	w16, w28
    c270:      	cmp	w16, wzr
    c274:      	b.ne	0xc49c <_stogir.conversion.policy+0x570>
    c278:      	cmp	x21, #0x6
    c27c:      	b.ne	0xc4ac <_stogir.conversion.policy+0x580>
    c280:      	ldr	x0, [sp, #0x10]
    c284:      	b	0xc4b0 <_stogir.conversion.policy+0x584>
    c288:      	cmp	x20, #0x1
    c28c:      	b.eq	0xc018 <_stogir.conversion.policy+0xec>
    c290:      	cmp	x20, #0x2
    c294:      	b.eq	0xc018 <_stogir.conversion.policy+0xec>
    c298:      	cmp	x20, #0x7
    c29c:      	b.eq	0xc018 <_stogir.conversion.policy+0xec>
    c2a0:      	cmp	x20, #0x8
    c2a4:      	b.eq	0xc018 <_stogir.conversion.policy+0xec>
    c2a8:      	cmp	x20, #0x3
    c2ac:      	b.eq	0xc400 <_stogir.conversion.policy+0x4d4>
    c2b0:      	cmp	x20, #0x9
    c2b4:      	b.eq	0xc400 <_stogir.conversion.policy+0x4d4>
    c2b8:      	cmp	x20, #0x4
    c2bc:      	b.eq	0xc470 <_stogir.conversion.policy+0x544>
    c2c0:      	cmp	x20, #0xa
    c2c4:      	b.eq	0xc470 <_stogir.conversion.policy+0x544>
    c2c8:      	uxtb	w16, w24
    c2cc:      	cmp	w16, wzr
    c2d0:      	b.ne	0xc470 <_stogir.conversion.policy+0x544>
    c2d4:      	cmp	x20, #0x5
    c2d8:      	b.eq	0xc4a4 <_stogir.conversion.policy+0x578>
    c2dc:      	cmp	x20, #0xb
    c2e0:      	b.eq	0xc4a4 <_stogir.conversion.policy+0x578>
    c2e4:      	uxtb	w16, w25
    c2e8:      	cmp	w16, wzr
    c2ec:      	b.ne	0xc4a4 <_stogir.conversion.policy+0x578>
    c2f0:      	cmp	x20, #0x6
    c2f4:      	b.ne	0xc4b4 <_stogir.conversion.policy+0x588>
    c2f8:      	ldr	x0, [sp, #0x10]
    c2fc:      	b	0xc4b8 <_stogir.conversion.policy+0x58c>
    c300:      	movz	x0, #0x0, lsl #48
    c304:      	b	0xc20c <_stogir.conversion.policy+0x2e0>
    c308:      	mov	x3, #0x1                ; =1
    c30c:      	cmp	x3, #0x0
    c310:      	b.ne	0xc154 <_stogir.conversion.policy+0x228>
    c314:      	cmp	x19, #0x23
    c318:      	b.eq	0xc32c <_stogir.conversion.policy+0x400>
    c31c:      	uxtb	w16, w2
    c320:      	cmp	w16, wzr
    c324:      	b.ne	0xc32c <_stogir.conversion.policy+0x400>
    c328:      	mov	x0, x1
    c32c:      	and	x0, x0, #0xffffffff
    c330:      	mov	x1, x0
    c334:      	movz	x0, #0x0, lsl #48
    c338:      	movz	x2, #0x0, lsl #48
    c33c:      	b	0xc16c <_stogir.conversion.policy+0x240>
    c340:      	movz	x3, #0x0, lsl #48
    c344:      	cmp	x3, #0x0
    c348:      	cset	w3, ne
    c34c:      	uxtb	w16, w3
    c350:      	cmp	w16, wzr
    c354:      	cset	x3, eq
    c358:      	b	0xc30c <_stogir.conversion.policy+0x3e0>
    c35c:      	cmp	x19, #0x24
    c360:      	b.ne	0xc37c <_stogir.conversion.policy+0x450>
    c364:      	cmp	x1, x0
    c368:      	cset	w3, eq
    c36c:      	uxtb	w16, w3
    c370:      	cmp	w16, wzr
    c374:      	cset	x3, eq
    c378:      	b	0xc30c <_stogir.conversion.policy+0x3e0>
    c37c:      	uxtb	w16, w3
    c380:      	cmp	w16, wzr
    c384:      	b.eq	0xc308 <_stogir.conversion.policy+0x3dc>
    c388:      	uxtb	w16, w4
    c38c:      	cmp	w16, wzr
    c390:      	b.eq	0xc308 <_stogir.conversion.policy+0x3dc>
    c394:      	uxtb	w16, w5
    c398:      	cmp	w16, wzr
    c39c:      	b.eq	0xc438 <_stogir.conversion.policy+0x50c>
    c3a0:      	uxtb	w16, w6
    c3a4:      	cmp	w16, wzr
    c3a8:      	b.eq	0xc438 <_stogir.conversion.policy+0x50c>
    c3ac:      	cmp	x19, #0x23
    c3b0:      	b.ne	0xc48c <_stogir.conversion.policy+0x560>
    c3b4:      	cmp	x0, x1
    c3b8:      	cset	w3, ge
    c3bc:      	ubfx	x3, x3, #0, #8
    c3c0:      	b	0xc498 <_stogir.conversion.policy+0x56c>
    c3c4:      	movz	x3, #0x0, lsl #48
    c3c8:      	b	0xc344 <_stogir.conversion.policy+0x418>
    c3cc:      	uxtb	w16, w2
    c3d0:      	cmp	w16, wzr
    c3d4:      	b.eq	0xc410 <_stogir.conversion.policy+0x4e4>
    c3d8:      	uxtb	w16, w25
    c3dc:      	cmp	w16, wzr
    c3e0:      	b.ne	0xc450 <_stogir.conversion.policy+0x524>
    c3e4:      	uxtb	w16, w24
    c3e8:      	cmp	w16, wzr
    c3ec:      	b.ne	0xc450 <_stogir.conversion.policy+0x524>
    c3f0:      	movz	x3, #0x0, lsl #48
    c3f4:      	b	0xc40c <_stogir.conversion.policy+0x4e0>
    c3f8:      	mov	x0, #0x2                ; =2
    c3fc:      	b	0xc06c <_stogir.conversion.policy+0x140>
    c400:      	mov	x0, #0x2                ; =2
    c404:      	b	0xc01c <_stogir.conversion.policy+0xf0>
    c408:      	movz	x3, #0x0, lsl #48
    c40c:      	b	0xc344 <_stogir.conversion.policy+0x418>
    c410:      	cmp	x19, #0x27
    c414:      	b.ne	0xc340 <_stogir.conversion.policy+0x414>
    c418:      	uxtb	w16, w25
    c41c:      	cmp	w16, wzr
    c420:      	b.ne	0xc478 <_stogir.conversion.policy+0x54c>
    c424:      	uxtb	w16, w24
    c428:      	cmp	w16, wzr
    c42c:      	b.ne	0xc478 <_stogir.conversion.policy+0x54c>
    c430:      	movz	x3, #0x0, lsl #48
    c434:      	b	0xc44c <_stogir.conversion.policy+0x520>
    c438:      	mov	x3, #0x1                ; =1
    c43c:      	b	0xc30c <_stogir.conversion.policy+0x3e0>
    c440:      	mov	x3, x23
    c444:      	b	0xc3c8 <_stogir.conversion.policy+0x49c>
    c448:      	mov	x3, x23
    c44c:      	b	0xc344 <_stogir.conversion.policy+0x418>
    c450:      	uxtb	w16, w5
    c454:      	cmp	w16, wzr
    c458:      	b.eq	0xc408 <_stogir.conversion.policy+0x4dc>
    c45c:      	ubfx	x6, x6, #0, #8
    c460:      	mov	x3, x6
    c464:      	b	0xc40c <_stogir.conversion.policy+0x4e0>
    c468:      	mov	x0, #0x4                ; =4
    c46c:      	b	0xc3fc <_stogir.conversion.policy+0x4d0>
    c470:      	mov	x0, #0x4                ; =4
    c474:      	b	0xc404 <_stogir.conversion.policy+0x4d8>
    c478:      	uxtb	w16, w28
    c47c:      	cmp	w16, wzr
    c480:      	b.eq	0xc448 <_stogir.conversion.policy+0x51c>
    c484:      	mov	x3, #0x1                ; =1
    c488:      	b	0xc44c <_stogir.conversion.policy+0x520>
    c48c:      	cmp	x0, x1
    c490:      	cset	w3, le
    c494:      	ubfx	x3, x3, #0, #8
    c498:      	b	0xc43c <_stogir.conversion.policy+0x510>
    c49c:      	mov	x0, #0x8                ; =8
    c4a0:      	b	0xc46c <_stogir.conversion.policy+0x540>
    c4a4:      	mov	x0, #0x8                ; =8
    c4a8:      	b	0xc474 <_stogir.conversion.policy+0x548>
    c4ac:      	movn	x0, #0x0, lsl #48
    c4b0:      	b	0xc4a0 <_stogir.conversion.policy+0x574>
    c4b4:      	movn	x0, #0x0, lsl #48
    c4b8:      	b	0xc4a8 <_stogir.conversion.policy+0x57c>
    c4bc:      	str	x8, [sp, #0x18]
    c4c0:      	mov	w28, w3
    c4c4:      	str	x23, [sp, #0x10]
    c4c8:      	mov	w23, w2
    c4cc:      	b	0xc134 <_stogir.conversion.policy+0x208>
    c4d0:      	mov	x22, x0
    c4d4:      	mov	w23, w1
    c4d8:      	mov	w28, w2
    c4dc:      	b	0xc114 <_stogir.conversion.policy+0x1e8>

000000000000c4e0 <_stogir.conditional.operands>:
    c4e0:      	sub	sp, sp, #0x30
    c4e4:      	str	x19, [sp, #0x20]
    c4e8:      	str	x20, [sp, #0x28]
    c4ec:      	sxtw	x1, w1
    c4f0:      	cmp	x1, #0x0
    c4f4:      	b.eq	0xc548 <_stogir.conditional.operands+0x68>
    c4f8:      	cmp	x1, #0x0
    c4fc:      	b.lt	0xc51c <_stogir.conditional.operands+0x3c>
    c500:      	cmp	x1, #0xd
    c504:      	b.gt	0xc51c <_stogir.conditional.operands+0x3c>
    c508:      	adrp	x16, 0xc000 <_stogir.conversion.policy+0xd4>
		000000000000c508:  ARM64_RELOC_PAGE21	l_stogir.470
    c50c:      	ldr	x16, [x16]
		000000000000c50c:  ARM64_RELOC_PAGEOFF12	l_stogir.470
    c510:      	orr	x5, x16, xzr
    c514:      	movz	x6, #0x0, lsl #48
    c518:      	b	0xc558 <_stogir.conditional.operands+0x78>
    c51c:      	cmp	x1, #0xf
    c520:      	b.le	0xc548 <_stogir.conditional.operands+0x68>
    c524:      	cmp	x1, #0x80
    c528:      	b.ge	0xc548 <_stogir.conditional.operands+0x68>
    c52c:      	and	x5, x1, #0xf
    c530:      	lsr	w5, w5, #0
    c534:      	sxtw	x5, w5
    c538:      	cmp	x5, #0x1
    c53c:      	b.lt	0xc548 <_stogir.conditional.operands+0x68>
    c540:      	cmp	x5, #0xd
    c544:      	b.le	0xc508 <_stogir.conditional.operands+0x28>
    c548:      	adrp	x16, 0xc000 <_stogir.conversion.policy+0xd4>
		000000000000c548:  ARM64_RELOC_PAGE21	l_stogir.471
    c54c:      	ldr	x16, [x16]
		000000000000c54c:  ARM64_RELOC_PAGEOFF12	l_stogir.471
    c550:      	orr	x5, x16, xzr
    c554:      	mov	x6, #0x2b               ; =43
    c558:      	sxtw	x2, w2
    c55c:      	cmp	x2, #0x0
    c560:      	cset	w7, gt
    c564:      	movz	x16, #0x0, lsl #48
    c568:      	sub	x9, x16, x2
    c56c:      	sub	x10, x9, #0x1
    c570:      	uxtb	w16, w7
    c574:      	cmp	w16, wzr
    c578:      	b.eq	0xc5bc <_stogir.conditional.operands+0xdc>
    c57c:      	ldr	x9, [x0, #0x8]
    c580:      	cmp	x2, x9
    c584:      	b.ge	0xc618 <_stogir.conditional.operands+0x138>
    c588:      	add	x9, x0, #0x78
    c58c:      	ldr	x9, [x9, #0x8]
    c590:      	cmp	x2, x9
    c594:      	b.ge	0xc9b8 <_stogir.conditional.operands+0x4d8>
    c598:      	lsl	x9, x2, #2
    c59c:      	ldr	x9, [x0, #0x78]
    c5a0:      	add	x9, x9, x2, lsl #2
    c5a4:      	ldr	w9, [x9]
    c5a8:      	sxtw	x9, w9
    c5ac:      	cmp	x9, #0x0
    c5b0:      	cset	w9, ge
    c5b4:      	ubfx	x9, x9, #0, #8
    c5b8:      	b	0xc9bc <_stogir.conditional.operands+0x4dc>
    c5bc:      	cmp	x2, #0x0
    c5c0:      	b.ge	0xc620 <_stogir.conditional.operands+0x140>
    c5c4:      	add	x11, x0, #0x28
    c5c8:      	add	x12, x0, #0x50
    c5cc:      	ldr	x11, [x11, #0x8]
    c5d0:      	ldr	x12, [x12, #0x8]
    c5d4:      	cmp	x11, x12
    c5d8:      	b.ne	0xc608 <_stogir.conditional.operands+0x128>
    c5dc:      	cmp	x9, x11
    c5e0:      	b.gt	0xc9c0 <_stogir.conditional.operands+0x4e0>
    c5e4:      	lsl	x9, x10, #2
    c5e8:      	ldr	x9, [x0, #0x50]
    c5ec:      	add	x9, x9, x10, lsl #2
    c5f0:      	ldr	w9, [x9]
    c5f4:      	sxtw	x9, w9
    c5f8:      	cmp	x9, #0x0
    c5fc:      	cset	w9, gt
    c600:      	ubfx	x9, x9, #0, #8
    c604:      	b	0xc9c4 <_stogir.conditional.operands+0x4e4>
    c608:      	movz	x9, #0x0, lsl #48
    c60c:      	b	0xc624 <_stogir.conditional.operands+0x144>
    c610:      	movz	x14, #0x0, lsl #48
    c614:      	b	0xc6cc <_stogir.conditional.operands+0x1ec>
    c618:      	movz	x9, #0x0, lsl #48
    c61c:      	b	0xc624 <_stogir.conditional.operands+0x144>
    c620:      	movz	x9, #0x0, lsl #48
    c624:      	cmp	x9, #0x0
    c628:      	b.eq	0xc668 <_stogir.conditional.operands+0x188>
    c62c:      	uxtb	w16, w7
    c630:      	cmp	w16, wzr
    c634:      	b.eq	0xc64c <_stogir.conditional.operands+0x16c>
    c638:      	lsl	x7, x2, #4
    c63c:      	ldr	x7, [x0]
    c640:      	add	x2, x7, x2, lsl #4
    c644:      	ldr	x2, [x2]
    c648:      	b	0xc65c <_stogir.conditional.operands+0x17c>
    c64c:      	lsl	x2, x10, #4
    c650:      	ldr	x2, [x0, #0x28]
    c654:      	add	x2, x2, x10, lsl #4
    c658:      	ldr	x2, [x2]
    c65c:      	mov	x7, x2
    c660:      	mov	x2, #0x1                ; =1
    c664:      	b	0xc670 <_stogir.conditional.operands+0x190>
    c668:      	movz	x2, #0x0, lsl #48
    c66c:      	movz	x7, #0x0, lsl #48
    c670:      	lsr	w2, w2, #0
    c674:      	lsr	x16, x2, #0
    c678:      	cmp	x16, #0x1
    c67c:      	b.eq	0xc698 <_stogir.conditional.operands+0x1b8>
    c680:      	b.lo	0xc688 <_stogir.conditional.operands+0x1a8>
    c684:      	b	0xc69c <_stogir.conditional.operands+0x1bc>
    c688:      	cmp	x16, #0x0
    c68c:      	b.eq	0xc694 <_stogir.conditional.operands+0x1b4>
    c690:      	b	0xc69c <_stogir.conditional.operands+0x1bc>
    c694:      	b	0xc6a0 <_stogir.conditional.operands+0x1c0>
    c698:      	b	0xc978 <_stogir.conditional.operands+0x498>
    c69c:      	b	0xc9d8 <_stogir.conditional.operands+0x4f8>
    c6a0:      	adrp	x16, 0xc000 <_stogir.conversion.policy+0xd4>
		000000000000c6a0:  ARM64_RELOC_PAGE21	l_stogir.472
    c6a4:      	ldr	x16, [x16]
		000000000000c6a4:  ARM64_RELOC_PAGEOFF12	l_stogir.472
    c6a8:      	orr	x2, x16, xzr
    c6ac:      	mov	x5, #0x16               ; =22
    c6b0:      	b	0xc6e0 <_stogir.conditional.operands+0x200>
    c6b4:      	movz	x14, #0x0, lsl #48
    c6b8:      	fmov	d31, x13
    c6bc:      	mov	x13, x14
    c6c0:      	fmov	x14, d31
    c6c4:      	b	0xc748 <_stogir.conditional.operands+0x268>
    c6c8:      	movz	x14, #0x0, lsl #48
    c6cc:      	b	0xc750 <_stogir.conditional.operands+0x270>
    c6d0:      	adrp	x16, 0xc000 <_stogir.conversion.policy+0xd4>
		000000000000c6d0:  ARM64_RELOC_PAGE21	l_stogir.473
    c6d4:      	ldr	x16, [x16]
		000000000000c6d4:  ARM64_RELOC_PAGEOFF12	l_stogir.473
    c6d8:      	orr	x2, x16, xzr
    c6dc:      	mov	x5, #0x2a               ; =42
    c6e0:      	add	x16, sp, #0x10
    c6e4:      	orr	x6, x16, xzr
    c6e8:      	adrp	x16, 0xc000 <_stogir.conversion.policy+0xd4>
		000000000000c6e8:  ARM64_RELOC_PAGE21	l_stogir.474
    c6ec:      	ldr	x16, [x16]
		000000000000c6ec:  ARM64_RELOC_PAGEOFF12	l_stogir.474
    c6f0:      	orr	x7, x16, xzr
    c6f4:      	adrp	x16, 0xc000 <_stogir.conversion.policy+0xd4>
		000000000000c6f4:  ARM64_RELOC_PAGE21	l_stogir.475
    c6f8:      	ldr	x16, [x16]
		000000000000c6f8:  ARM64_RELOC_PAGEOFF12	l_stogir.475
    c6fc:      	orr	x9, x16, xzr
    c700:      	lsr	w3, w3, #0
    c704:      	lsr	w4, w4, #0
    c708:      	add	x10, x0, #0x78
    c70c:      	add	x11, x0, #0x28
    c710:      	add	x12, x0, #0x50
    c714:      	mov	x16, sp
    c718:      	str	w3, [x16]
    c71c:      	mov	x16, sp
    c720:      	str	w4, [x16, #0x4]
    c724:      	mov	x16, sp
    c728:      	ldr	x3, [x16]
    c72c:      	add	x16, sp, #0x10
    c730:      	str	x3, [x16]
    c734:      	mov	x3, x5
    c738:      	movz	x4, #0x0, lsl #48
    c73c:      	b	0xc820 <_stogir.conditional.operands+0x340>
    c740:      	mov	x14, x13
    c744:      	movz	x13, #0x0, lsl #48
    c748:      	b	0xc75c <_stogir.conditional.operands+0x27c>
    c74c:      	movz	x14, #0x0, lsl #48
    c750:      	fmov	d31, x13
    c754:      	mov	x13, x14
    c758:      	fmov	x14, d31
    c75c:      	cmp	x13, #0x0
    c760:      	b.eq	0xc7a4 <_stogir.conditional.operands+0x2c4>
    c764:      	uxtb	w16, w4
    c768:      	cmp	w16, wzr
    c76c:      	b.eq	0xc784 <_stogir.conditional.operands+0x2a4>
    c770:      	lsl	x4, x5, #4
    c774:      	ldr	x4, [x0]
    c778:      	add	x4, x4, x5, lsl #4
    c77c:      	ldr	x4, [x4]
    c780:      	b	0xc794 <_stogir.conditional.operands+0x2b4>
    c784:      	lsl	x4, x15, #4
    c788:      	ldr	x4, [x0, #0x28]
    c78c:      	add	x4, x4, x15, lsl #4
    c790:      	ldr	x4, [x4]
    c794:      	mov	x5, x4
    c798:      	mov	x13, x14
    c79c:      	mov	x4, #0x1                ; =1
    c7a0:      	b	0xc7b0 <_stogir.conditional.operands+0x2d0>
    c7a4:      	mov	x13, x14
    c7a8:      	movz	x4, #0x0, lsl #48
    c7ac:      	movz	x5, #0x0, lsl #48
    c7b0:      	lsr	w4, w4, #0
    c7b4:      	lsr	x16, x4, #0
    c7b8:      	cmp	x16, #0x1
    c7bc:      	b.eq	0xc7d8 <_stogir.conditional.operands+0x2f8>
    c7c0:      	b.lo	0xc7c8 <_stogir.conditional.operands+0x2e8>
    c7c4:      	b	0xc7dc <_stogir.conditional.operands+0x2fc>
    c7c8:      	cmp	x16, #0x0
    c7cc:      	b.eq	0xc7d4 <_stogir.conditional.operands+0x2f4>
    c7d0:      	b	0xc7dc <_stogir.conditional.operands+0x2fc>
    c7d4:      	b	0xc7e0 <_stogir.conditional.operands+0x300>
    c7d8:      	b	0xc7f0 <_stogir.conditional.operands+0x310>
    c7dc:      	b	0xc9d0 <_stogir.conditional.operands+0x4f0>
    c7e0:      	mov	x2, x7
    c7e4:      	mov	x4, x13
    c7e8:      	mov	x3, #0x10               ; =16
    c7ec:      	b	0xc820 <_stogir.conditional.operands+0x340>
    c7f0:      	uxtb	w4, w5
    c7f4:      	cmp	x4, #0x48
    c7f8:      	b.eq	0xc814 <_stogir.conditional.operands+0x334>
    c7fc:      	cmp	x4, #0x46
    c800:      	b.eq	0xc814 <_stogir.conditional.operands+0x334>
    c804:      	lsr	w5, w5, #0
    c808:      	ubfx	x4, x5, #8, #8
    c80c:      	cmp	x4, x1
    c810:      	b.eq	0xc81c <_stogir.conditional.operands+0x33c>
    c814:      	mov	x2, x9
    c818:      	mov	x3, #0x21               ; =33
    c81c:      	mov	x4, x13
    c820:      	cmp	x4, #0x2
    c824:      	b.ge	0xc850 <_stogir.conditional.operands+0x370>
    c828:      	add	x5, x4, #0x1
    c82c:      	lsl	x13, x4, #2
    c830:      	add	x4, x6, x4, lsl #2
    c834:      	ldr	w4, [x4]
    c838:      	sxtw	x4, w4
    c83c:      	and	x4, x4, #0xffffffff
    c840:      	mov	x13, x5
    c844:      	mov	x5, x4
    c848:      	mov	x4, #0x1                ; =1
    c84c:      	b	0xc85c <_stogir.conditional.operands+0x37c>
    c850:      	mov	x13, x4
    c854:      	movz	x4, #0x0, lsl #48
    c858:      	movz	x5, #0x0, lsl #48
    c85c:      	lsr	w4, w4, #0
    c860:      	lsr	x16, x4, #0
    c864:      	cmp	x16, #0x1
    c868:      	b.eq	0xc884 <_stogir.conditional.operands+0x3a4>
    c86c:      	b.lo	0xc874 <_stogir.conditional.operands+0x394>
    c870:      	b	0xc888 <_stogir.conditional.operands+0x3a8>
    c874:      	cmp	x16, #0x0
    c878:      	b.eq	0xc880 <_stogir.conditional.operands+0x3a0>
    c87c:      	b	0xc888 <_stogir.conditional.operands+0x3a8>
    c880:      	b	0xc8f0 <_stogir.conditional.operands+0x410>
    c884:      	b	0xc88c <_stogir.conditional.operands+0x3ac>
    c888:      	b	0xc9c8 <_stogir.conditional.operands+0x4e8>
    c88c:      	lsr	w5, w5, #0
    c890:      	sxtw	x5, w5
    c894:      	cmp	x5, #0x0
    c898:      	cset	w4, gt
    c89c:      	movz	x16, #0x0, lsl #48
    c8a0:      	sub	x14, x16, x5
    c8a4:      	sub	x15, x14, #0x1
    c8a8:      	uxtb	w16, w4
    c8ac:      	cmp	w16, wzr
    c8b0:      	b.eq	0xc934 <_stogir.conditional.operands+0x454>
    c8b4:      	ldr	x14, [x0, #0x8]
    c8b8:      	cmp	x5, x14
    c8bc:      	b.ge	0xc740 <_stogir.conditional.operands+0x260>
    c8c0:      	ldr	x14, [x10, #0x8]
    c8c4:      	cmp	x5, x14
    c8c8:      	b.ge	0xc6b4 <_stogir.conditional.operands+0x1d4>
    c8cc:      	lsl	x14, x5, #2
    c8d0:      	ldr	x14, [x0, #0x78]
    c8d4:      	add	x14, x14, x5, lsl #2
    c8d8:      	ldr	w14, [x14]
    c8dc:      	sxtw	x14, w14
    c8e0:      	cmp	x14, #0x0
    c8e4:      	cset	w14, ge
    c8e8:      	ubfx	x14, x14, #0, #8
    c8ec:      	b	0xc6b8 <_stogir.conditional.operands+0x1d8>
    c8f0:      	cmp	x3, #0x0
    c8f4:      	b.ne	0xc90c <_stogir.conditional.operands+0x42c>
    c8f8:      	and	x0, x1, #0xffffffff
    c8fc:      	mov	x1, x0
    c900:      	movz	x0, #0x0, lsl #48
    c904:      	movz	x2, #0x0, lsl #48
    c908:      	b	0xc918 <_stogir.conditional.operands+0x438>
    c90c:      	mov	x1, x2
    c910:      	mov	x2, x3
    c914:      	mov	x0, #0x1                ; =1
    c918:      	str	x0, [x8]
    c91c:      	str	x1, [x8, #0x8]
    c920:      	str	x2, [x8, #0x10]
    c924:      	ldr	x19, [sp, #0x20]
    c928:      	ldr	x20, [sp, #0x28]
    c92c:      	add	sp, sp, #0x30
    c930:      	ret
    c934:      	cmp	x5, #0x0
    c938:      	b.ge	0xc74c <_stogir.conditional.operands+0x26c>
    c93c:      	ldr	x19, [x11, #0x8]
    c940:      	ldr	x20, [x12, #0x8]
    c944:      	cmp	x19, x20
    c948:      	b.ne	0xc6c8 <_stogir.conditional.operands+0x1e8>
    c94c:      	cmp	x14, x19
    c950:      	b.gt	0xc610 <_stogir.conditional.operands+0x130>
    c954:      	lsl	x14, x15, #2
    c958:      	ldr	x14, [x0, #0x50]
    c95c:      	add	x14, x14, x15, lsl #2
    c960:      	ldr	w14, [x14]
    c964:      	sxtw	x14, w14
    c968:      	cmp	x14, #0x0
    c96c:      	cset	w14, gt
    c970:      	ubfx	x14, x14, #0, #8
    c974:      	b	0xc614 <_stogir.conditional.operands+0x134>
    c978:      	uxtb	w2, w7
    c97c:      	cmp	x2, #0x48
    c980:      	b.eq	0xc6d0 <_stogir.conditional.operands+0x1f0>
    c984:      	cmp	x2, #0x46
    c988:      	b.eq	0xc6d0 <_stogir.conditional.operands+0x1f0>
    c98c:      	lsr	w7, w7, #0
    c990:      	orr	x2, x7, xzr
    c994:      	ubfx	x2, x2, #8, #8
    c998:      	cmp	x2, #0x0
    c99c:      	b.eq	0xc6d0 <_stogir.conditional.operands+0x1f0>
    c9a0:      	ubfx	x2, x7, #8, #8
    c9a4:      	cmp	x2, #0xd
    c9a8:      	b.gt	0xc6d0 <_stogir.conditional.operands+0x1f0>
    c9ac:      	mov	x2, x5
    c9b0:      	mov	x5, x6
    c9b4:      	b	0xc6e0 <_stogir.conditional.operands+0x200>
    c9b8:      	movz	x9, #0x0, lsl #48
    c9bc:      	b	0xc61c <_stogir.conditional.operands+0x13c>
    c9c0:      	movz	x9, #0x0, lsl #48
    c9c4:      	b	0xc60c <_stogir.conditional.operands+0x12c>
    c9c8:      	brk	#0
    c9cc:      	b	0xc9c8 <_stogir.conditional.operands+0x4e8>
    c9d0:      	brk	#0
    c9d4:      	b	0xc9d0 <_stogir.conditional.operands+0x4f0>
    c9d8:      	brk	#0
    c9dc:      	b	0xc9d8 <_stogir.conditional.operands+0x4f8>

000000000000c9e0 <_stogir.floating.unary?>:
    c9e0:      	sxtw	x0, w0
    c9e4:      	cmp	x0, #0x1f
    c9e8:      	b.ne	0xc9f4 <_stogir.floating.unary?+0x14>
    c9ec:      	mov	x0, #0x1                ; =1
    c9f0:      	b	0xca00 <_stogir.floating.unary?+0x20>
    c9f4:      	cmp	x0, #0x20
    c9f8:      	cset	w0, eq
    c9fc:      	ubfx	x0, x0, #0, #8
    ca00:      	ret

000000000000ca04 <_stogir.floating.comparison?>:
    ca04:      	sxtw	x0, w0
    ca08:      	cmp	x0, #0xe
    ca0c:      	b.lt	0xca20 <_stogir.floating.comparison?+0x1c>
    ca10:      	cmp	x0, #0x19
    ca14:      	cset	w0, le
    ca18:      	ubfx	x0, x0, #0, #8
    ca1c:      	b	0xca24 <_stogir.floating.comparison?+0x20>
    ca20:      	movz	x0, #0x0, lsl #48
    ca24:      	ret

000000000000ca28 <_stogir.floating.operands>:
    ca28:      	sub	sp, sp, #0x90
    ca2c:      	str	x29, [sp]
    ca30:      	str	x30, [sp, #0x8]
    ca34:      	mov	x29, sp
    ca38:      	str	x19, [sp, #0x60]
    ca3c:      	str	x20, [sp, #0x68]
    ca40:      	str	x21, [sp, #0x70]
    ca44:      	str	x22, [sp, #0x78]
    ca48:      	str	x23, [sp, #0x80]
    ca4c:      	sxtw	x1, w1
    ca50:      	sxtw	x19, w2
    ca54:      	cmp	x1, #0x1f
    ca58:      	cset	w2, eq
    ca5c:      	cmp	x1, #0x20
    ca60:      	cset	w6, eq
    ca64:      	cmp	x1, #0xe
    ca68:      	b.lt	0xca98 <_stogir.floating.operands+0x70>
    ca6c:      	cmp	x1, #0x19
    ca70:      	b.gt	0xca98 <_stogir.floating.operands+0x70>
    ca74:      	cmp	x19, #0xc
    ca78:      	b.eq	0xcad4 <_stogir.floating.operands+0xac>
    ca7c:      	cmp	x19, #0xd
    ca80:      	b.eq	0xcad4 <_stogir.floating.operands+0xac>
    ca84:      	adrp	x16, 0xc000 <_stogir.conversion.policy+0xd4>
		000000000000ca84:  ARM64_RELOC_PAGE21	l_stogir.476
    ca88:      	ldr	x16, [x16]
		000000000000ca88:  ARM64_RELOC_PAGEOFF12	l_stogir.476
    ca8c:      	orr	x7, x16, xzr
    ca90:      	mov	x9, #0x22               ; =34
    ca94:      	b	0xcae4 <_stogir.floating.operands+0xbc>
    ca98:      	uxtb	w16, w2
    ca9c:      	cmp	w16, wzr
    caa0:      	b.ne	0xca74 <_stogir.floating.operands+0x4c>
    caa4:      	uxtb	w16, w6
    caa8:      	cmp	w16, wzr
    caac:      	b.ne	0xca74 <_stogir.floating.operands+0x4c>
    cab0:      	cmp	x1, #0x1a
    cab4:      	b.lt	0xcac0 <_stogir.floating.operands+0x98>
    cab8:      	cmp	x1, #0x1d
    cabc:      	b.le	0xca74 <_stogir.floating.operands+0x4c>
    cac0:      	cmp	x1, #0x3a
    cac4:      	b.eq	0xca74 <_stogir.floating.operands+0x4c>
    cac8:      	cmp	x1, #0x3b
    cacc:      	b.eq	0xca74 <_stogir.floating.operands+0x4c>
    cad0:      	b	0xca84 <_stogir.floating.operands+0x5c>
    cad4:      	adrp	x16, 0xc000 <_stogir.conversion.policy+0xd4>
		000000000000cad4:  ARM64_RELOC_PAGE21	l_stogir.477
    cad8:      	ldr	x16, [x16]
		000000000000cad8:  ARM64_RELOC_PAGEOFF12	l_stogir.477
    cadc:      	orr	x7, x16, xzr
    cae0:      	movz	x9, #0x0, lsl #48
    cae4:      	lsr	w3, w3, #0
    cae8:      	add	x16, sp, #0x10
    caec:      	str	w3, [x16]
    caf0:      	uxtb	w16, w2
    caf4:      	cmp	w16, wzr
    caf8:      	b.ne	0xcb80 <_stogir.floating.operands+0x158>
    cafc:      	uxtb	w16, w6
    cb00:      	cmp	w16, wzr
    cb04:      	b.ne	0xcb80 <_stogir.floating.operands+0x158>
    cb08:      	sxtw	x4, w4
    cb0c:      	mov	x2, x4
    cb10:      	b	0xcb88 <_stogir.floating.operands+0x160>
    cb14:      	movz	x1, #0x0, lsl #48
    cb18:      	uxtb	w1, w1
    cb1c:      	and	x1, x1, #0x2
    cb20:      	uxtb	w1, w1
    cb24:      	cmp	x1, #0x0
    cb28:      	cset	w1, eq
    cb2c:      	uxtb	w16, w1
    cb30:      	cmp	w16, wzr
    cb34:      	cset	x1, eq
    cb38:      	cmp	x1, #0x0
    cb3c:      	b.ne	0xcef4 <_stogir.floating.operands+0x4cc>
    cb40:      	cmp	x0, #0x65
    cb44:      	b.eq	0xcef4 <_stogir.floating.operands+0x4cc>
    cb48:      	cmp	x0, #0x66
    cb4c:      	b.eq	0xcef4 <_stogir.floating.operands+0x4cc>
    cb50:      	adrp	x16, 0xc000 <_stogir.conversion.policy+0xd4>
		000000000000cb50:  ARM64_RELOC_PAGE21	l_stogir.478
    cb54:      	ldr	x16, [x16]
		000000000000cb54:  ARM64_RELOC_PAGEOFF12	l_stogir.478
    cb58:      	orr	x0, x16, xzr
    cb5c:      	mov	x1, #0x2d               ; =45
    cb60:      	b	0xcc9c <_stogir.floating.operands+0x274>
    cb64:      	movz	x13, #0x0, lsl #48
    cb68:      	fmov	d31, x9
    cb6c:      	mov	x9, x13
    cb70:      	fmov	x13, d31
    cb74:      	b	0xcbe8 <_stogir.floating.operands+0x1c0>
    cb78:      	movz	x13, #0x0, lsl #48
    cb7c:      	b	0xcbf0 <_stogir.floating.operands+0x1c8>
    cb80:      	sxtw	x3, w3
    cb84:      	mov	x2, x3
    cb88:      	add	x16, sp, #0x20
    cb8c:      	orr	x3, x16, xzr
    cb90:      	adrp	x16, 0xc000 <_stogir.conversion.policy+0xd4>
		000000000000cb90:  ARM64_RELOC_PAGE21	l_stogir.479
    cb94:      	ldr	x16, [x16]
		000000000000cb94:  ARM64_RELOC_PAGEOFF12	l_stogir.479
    cb98:      	orr	x4, x16, xzr
    cb9c:      	adrp	x16, 0xc000 <_stogir.conversion.policy+0xd4>
		000000000000cb9c:  ARM64_RELOC_PAGE21	l_stogir.480
    cba0:      	ldr	x16, [x16]
		000000000000cba0:  ARM64_RELOC_PAGEOFF12	l_stogir.480
    cba4:      	orr	x6, x16, xzr
    cba8:      	add	x10, x0, #0x78
    cbac:      	add	x11, x0, #0x28
    cbb0:      	add	x12, x0, #0x50
    cbb4:      	lsr	w2, w2, #0
    cbb8:      	add	x16, sp, #0x10
    cbbc:      	str	w2, [x16, #0x4]
    cbc0:      	add	x16, sp, #0x10
    cbc4:      	ldr	x2, [x16]
    cbc8:      	add	x16, sp, #0x20
    cbcc:      	str	x2, [x16]
    cbd0:      	mov	x20, x7
    cbd4:      	mov	x21, x9
    cbd8:      	movz	x2, #0x0, lsl #48
    cbdc:      	b	0xccb4 <_stogir.floating.operands+0x28c>
    cbe0:      	mov	x13, x9
    cbe4:      	movz	x9, #0x0, lsl #48
    cbe8:      	b	0xcbfc <_stogir.floating.operands+0x1d4>
    cbec:      	movz	x13, #0x0, lsl #48
    cbf0:      	fmov	d31, x9
    cbf4:      	mov	x9, x13
    cbf8:      	fmov	x13, d31
    cbfc:      	cmp	x9, #0x0
    cc00:      	b.eq	0xcc44 <_stogir.floating.operands+0x21c>
    cc04:      	uxtb	w16, w2
    cc08:      	cmp	w16, wzr
    cc0c:      	b.eq	0xcc24 <_stogir.floating.operands+0x1fc>
    cc10:      	lsl	x2, x7, #4
    cc14:      	ldr	x2, [x0]
    cc18:      	add	x2, x2, x7, lsl #4
    cc1c:      	ldr	x2, [x2]
    cc20:      	b	0xcc34 <_stogir.floating.operands+0x20c>
    cc24:      	lsl	x2, x14, #4
    cc28:      	ldr	x2, [x0, #0x28]
    cc2c:      	add	x2, x2, x14, lsl #4
    cc30:      	ldr	x2, [x2]
    cc34:      	mov	x7, x2
    cc38:      	mov	x9, x13
    cc3c:      	mov	x2, #0x1                ; =1
    cc40:      	b	0xcc50 <_stogir.floating.operands+0x228>
    cc44:      	mov	x9, x13
    cc48:      	movz	x2, #0x0, lsl #48
    cc4c:      	movz	x7, #0x0, lsl #48
    cc50:      	lsr	w2, w2, #0
    cc54:      	lsr	x16, x2, #0
    cc58:      	cmp	x16, #0x1
    cc5c:      	b.eq	0xcc78 <_stogir.floating.operands+0x250>
    cc60:      	b.lo	0xcc68 <_stogir.floating.operands+0x240>
    cc64:      	b	0xcc7c <_stogir.floating.operands+0x254>
    cc68:      	cmp	x16, #0x0
    cc6c:      	b.eq	0xcc74 <_stogir.floating.operands+0x24c>
    cc70:      	b	0xcc7c <_stogir.floating.operands+0x254>
    cc74:      	b	0xcc80 <_stogir.floating.operands+0x258>
    cc78:      	b	0xce9c <_stogir.floating.operands+0x474>
    cc7c:      	b	0xcf08 <_stogir.floating.operands+0x4e0>
    cc80:      	mov	x2, x4
    cc84:      	mov	x7, #0x18               ; =24
    cc88:      	b	0xcca8 <_stogir.floating.operands+0x280>
    cc8c:      	adrp	x16, 0xc000 <_stogir.conversion.policy+0xd4>
		000000000000cc8c:  ARM64_RELOC_PAGE21	l_stogir.481
    cc90:      	ldr	x16, [x16]
		000000000000cc90:  ARM64_RELOC_PAGEOFF12	l_stogir.481
    cc94:      	orr	x0, x16, xzr
    cc98:      	mov	x1, #0x21               ; =33
    cc9c:      	b	0xcd9c <_stogir.floating.operands+0x374>
    cca0:      	mov	x2, x6
    cca4:      	mov	x7, #0x1e               ; =30
    cca8:      	mov	x20, x2
    ccac:      	mov	x21, x7
    ccb0:      	mov	x2, x9
    ccb4:      	cmp	x2, #0x2
    ccb8:      	b.ge	0xcce4 <_stogir.floating.operands+0x2bc>
    ccbc:      	add	x7, x2, #0x1
    ccc0:      	lsl	x9, x2, #2
    ccc4:      	add	x2, x3, x2, lsl #2
    ccc8:      	ldr	w2, [x2]
    cccc:      	sxtw	x2, w2
    ccd0:      	and	x2, x2, #0xffffffff
    ccd4:      	mov	x9, x7
    ccd8:      	mov	x7, x2
    ccdc:      	mov	x2, #0x1                ; =1
    cce0:      	b	0xccf0 <_stogir.floating.operands+0x2c8>
    cce4:      	mov	x9, x2
    cce8:      	movz	x2, #0x0, lsl #48
    ccec:      	movz	x7, #0x0, lsl #48
    ccf0:      	lsr	w2, w2, #0
    ccf4:      	lsr	x16, x2, #0
    ccf8:      	cmp	x16, #0x1
    ccfc:      	b.eq	0xcd18 <_stogir.floating.operands+0x2f0>
    cd00:      	b.lo	0xcd08 <_stogir.floating.operands+0x2e0>
    cd04:      	b	0xcd1c <_stogir.floating.operands+0x2f4>
    cd08:      	cmp	x16, #0x0
    cd0c:      	b.eq	0xcd14 <_stogir.floating.operands+0x2ec>
    cd10:      	b	0xcd1c <_stogir.floating.operands+0x2f4>
    cd14:      	b	0xcd84 <_stogir.floating.operands+0x35c>
    cd18:      	b	0xcd20 <_stogir.floating.operands+0x2f8>
    cd1c:      	b	0xcf00 <_stogir.floating.operands+0x4d8>
    cd20:      	lsr	w7, w7, #0
    cd24:      	sxtw	x7, w7
    cd28:      	cmp	x7, #0x0
    cd2c:      	cset	w2, gt
    cd30:      	movz	x16, #0x0, lsl #48
    cd34:      	sub	x13, x16, x7
    cd38:      	sub	x14, x13, #0x1
    cd3c:      	uxtb	w16, w2
    cd40:      	cmp	w16, wzr
    cd44:      	b.eq	0xce1c <_stogir.floating.operands+0x3f4>
    cd48:      	ldr	x13, [x0, #0x8]
    cd4c:      	cmp	x7, x13
    cd50:      	b.ge	0xcbe0 <_stogir.floating.operands+0x1b8>
    cd54:      	ldr	x13, [x10, #0x8]
    cd58:      	cmp	x7, x13
    cd5c:      	b.ge	0xcb64 <_stogir.floating.operands+0x13c>
    cd60:      	lsl	x13, x7, #2
    cd64:      	ldr	x13, [x0, #0x78]
    cd68:      	add	x13, x13, x7, lsl #2
    cd6c:      	ldr	w13, [x13]
    cd70:      	sxtw	x13, w13
    cd74:      	cmp	x13, #0x0
    cd78:      	cset	w13, ge
    cd7c:      	ubfx	x13, x13, #0, #8
    cd80:      	b	0xcb68 <_stogir.floating.operands+0x140>
    cd84:      	sxtw	x22, w5
    cd88:      	cmp	x22, #0x0
    cd8c:      	b.ne	0xcdb8 <_stogir.floating.operands+0x390>
    cd90:      	mov	x23, x8
    cd94:      	mov	x0, x20
    cd98:      	mov	x1, x21
    cd9c:      	cmp	x1, #0x0
    cda0:      	b.ne	0xce60 <_stogir.floating.operands+0x438>
    cda4:      	and	x0, x19, #0xffffffff
    cda8:      	mov	x1, x0
    cdac:      	movz	x0, #0x0, lsl #48
    cdb0:      	movz	x2, #0x0, lsl #48
    cdb4:      	b	0xce6c <_stogir.floating.operands+0x444>
    cdb8:      	cmp	x1, #0x1d
    cdbc:      	b.ne	0xcf18 <_stogir.floating.operands+0x4f0>
    cdc0:      	lsr	w5, w5, #0
    cdc4:      	mov	w1, w5
    cdc8:      	mov	x23, x8
    cdcc:      	add	x8, sp, #0x30
    cdd0:      	bl	0xcdd0 <_stogir.floating.operands+0x3a8>
		000000000000cdd0:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    cdd4:      	add	x16, sp, #0x30
    cdd8:      	ldr	w0, [x16]
    cddc:      	lsr	x16, x0, #0
    cde0:      	cmp	x16, #0x1
    cde4:      	b.eq	0xce00 <_stogir.floating.operands+0x3d8>
    cde8:      	b.lo	0xcdf0 <_stogir.floating.operands+0x3c8>
    cdec:      	b	0xce04 <_stogir.floating.operands+0x3dc>
    cdf0:      	cmp	x16, #0x0
    cdf4:      	b.eq	0xcdfc <_stogir.floating.operands+0x3d4>
    cdf8:      	b	0xce04 <_stogir.floating.operands+0x3dc>
    cdfc:      	b	0xce08 <_stogir.floating.operands+0x3e0>
    ce00:      	b	0xcec0 <_stogir.floating.operands+0x498>
    ce04:      	b	0xcf10 <_stogir.floating.operands+0x4e8>
    ce08:      	adrp	x16, 0xc000 <_stogir.conversion.policy+0xd4>
		000000000000ce08:  ARM64_RELOC_PAGE21	l_stogir.482
    ce0c:      	ldr	x16, [x16]
		000000000000ce0c:  ARM64_RELOC_PAGEOFF12	l_stogir.482
    ce10:      	orr	x0, x16, xzr
    ce14:      	mov	x1, #0x16               ; =22
    ce18:      	b	0xcb60 <_stogir.floating.operands+0x138>
    ce1c:      	cmp	x7, #0x0
    ce20:      	b.ge	0xcbec <_stogir.floating.operands+0x1c4>
    ce24:      	ldr	x15, [x11, #0x8]
    ce28:      	ldr	x22, [x12, #0x8]
    ce2c:      	cmp	x15, x22
    ce30:      	b.ne	0xcb78 <_stogir.floating.operands+0x150>
    ce34:      	cmp	x13, x15
    ce38:      	b.gt	0xceb8 <_stogir.floating.operands+0x490>
    ce3c:      	lsl	x13, x14, #2
    ce40:      	ldr	x13, [x0, #0x50]
    ce44:      	add	x13, x13, x14, lsl #2
    ce48:      	ldr	w13, [x13]
    ce4c:      	sxtw	x13, w13
    ce50:      	cmp	x13, #0x0
    ce54:      	cset	w13, gt
    ce58:      	ubfx	x13, x13, #0, #8
    ce5c:      	b	0xcebc <_stogir.floating.operands+0x494>
    ce60:      	mov	x2, x1
    ce64:      	mov	x1, x0
    ce68:      	mov	x0, #0x1                ; =1
    ce6c:      	str	x0, [x23]
    ce70:      	str	x1, [x23, #0x8]
    ce74:      	str	x2, [x23, #0x10]
    ce78:      	ldr	x19, [sp, #0x60]
    ce7c:      	ldr	x20, [sp, #0x68]
    ce80:      	ldr	x21, [sp, #0x70]
    ce84:      	ldr	x22, [sp, #0x78]
    ce88:      	ldr	x23, [sp, #0x80]
    ce8c:      	ldr	x29, [sp]
    ce90:      	ldr	x30, [sp, #0x8]
    ce94:      	add	sp, sp, #0x90
    ce98:      	ret
    ce9c:      	lsr	w7, w7, #0
    cea0:      	ubfx	x2, x7, #8, #8
    cea4:      	cmp	x2, x19
    cea8:      	b.ne	0xcca0 <_stogir.floating.operands+0x278>
    ceac:      	mov	x2, x20
    ceb0:      	mov	x7, x21
    ceb4:      	b	0xcca8 <_stogir.floating.operands+0x280>
    ceb8:      	movz	x13, #0x0, lsl #48
    cebc:      	b	0xcb7c <_stogir.floating.operands+0x154>
    cec0:      	add	x16, sp, #0x30
    cec4:      	ldr	x0, [x16, #0x8]
    cec8:      	cmp	x22, #0x0
    cecc:      	b.lt	0xcb50 <_stogir.floating.operands+0x128>
    ced0:      	uxtb	w0, w0
    ced4:      	cmp	x0, #0x83
    ced8:      	b.ge	0xcb14 <_stogir.floating.operands+0xec>
    cedc:      	adrp	x16, 0xc000 <_stogir.conversion.policy+0xd4>
		000000000000cedc:  ARM64_RELOC_PAGE21	l_stogir.483
    cee0:      	ldr	x16, [x16]
		000000000000cee0:  ARM64_RELOC_PAGEOFF12	l_stogir.483
    cee4:      	orr	x1, x16, xzr
    cee8:      	add	x1, x0, x1
    ceec:      	ldrb	w1, [x1]
    cef0:      	b	0xcb18 <_stogir.floating.operands+0xf0>
    cef4:      	mov	x0, x20
    cef8:      	mov	x1, x21
    cefc:      	b	0xcb60 <_stogir.floating.operands+0x138>
    cf00:      	brk	#0
    cf04:      	b	0xcf00 <_stogir.floating.operands+0x4d8>
    cf08:      	brk	#0
    cf0c:      	b	0xcf08 <_stogir.floating.operands+0x4e0>
    cf10:      	brk	#0
    cf14:      	b	0xcf10 <_stogir.floating.operands+0x4e8>
    cf18:      	mov	x23, x8
    cf1c:      	b	0xcc8c <_stogir.floating.operands+0x264>

000000000000cf20 <_stogir.types.signed?>:
    cf20:      	sxtw	x0, w0
    cf24:      	cmp	x0, #0x7
    cf28:      	b.lt	0xcf3c <_stogir.types.signed?+0x1c>
    cf2c:      	cmp	x0, #0xb
    cf30:      	cset	w0, le
    cf34:      	ubfx	x0, x0, #0, #8
    cf38:      	b	0xcf40 <_stogir.types.signed?+0x20>
    cf3c:      	movz	x0, #0x0, lsl #48
    cf40:      	ret

000000000000cf44 <_stogir.integer-binary.logical?>:
    cf44:      	sxtw	x0, w0
    cf48:      	cmp	x0, #0x2e
    cf4c:      	b.ne	0xcf68 <_stogir.integer-binary.logical?+0x24>
    cf50:      	mov	x0, #0x1                ; =1
    cf54:      	b	0xcf64 <_stogir.integer-binary.logical?+0x20>
    cf58:      	cmp	x0, #0x30
    cf5c:      	cset	w0, eq
    cf60:      	ubfx	x0, x0, #0, #8
    cf64:      	ret
    cf68:      	cmp	x0, #0x2f
    cf6c:      	b.ne	0xcf58 <_stogir.integer-binary.logical?+0x14>
    cf70:      	mov	x0, #0x1                ; =1
    cf74:      	b	0xcf64 <_stogir.integer-binary.logical?+0x20>

000000000000cf78 <_inherent$slice$data__i8>:
    cf78:      	ret

000000000000cf7c <_inherent$slice$data__u32>:
    cf7c:      	ret

000000000000cf80 <_inherent$coil.arraylist.ArrayList$slice__stogir.node.Node>:
    cf80:      	sub	sp, sp, #0x10
    cf84:      	mov	x1, sp
    cf88:      	ldr	x2, [x0]
    cf8c:      	ldr	x0, [x0, #0x8]
    cf90:      	str	x2, [x1]
    cf94:      	str	x0, [x1, #0x8]
    cf98:      	ldr	x0, [sp]
    cf9c:      	ldr	x1, [sp, #0x8]
    cfa0:      	add	sp, sp, #0x10
    cfa4:      	ret

000000000000cfa8 <_inherent$slice$at__stogir.node.Node>:
    cfa8:      	lsl	x1, x2, #4
    cfac:      	add	x0, x0, x2, lsl #4
    cfb0:      	ret

000000000000cfb4 <_inherent$slice$new__u8>:
    cfb4:      	sub	sp, sp, #0x10
    cfb8:      	mov	x2, sp
    cfbc:      	str	x0, [x2]
    cfc0:      	str	x1, [x2, #0x8]
    cfc4:      	ldr	x0, [sp]
    cfc8:      	ldr	x1, [sp, #0x8]
    cfcc:      	add	sp, sp, #0x10
    cfd0:      	ret

000000000000cfd4 <_stogir.vector-lanes.operands>:
    cfd4:      	sub	sp, sp, #0x110
    cfd8:      	str	x29, [sp]
    cfdc:      	str	x30, [sp, #0x8]
    cfe0:      	mov	x29, sp
    cfe4:      	str	x19, [sp, #0xc0]
    cfe8:      	str	x20, [sp, #0xc8]
    cfec:      	str	x21, [sp, #0xd0]
    cff0:      	str	x22, [sp, #0xd8]
    cff4:      	str	x23, [sp, #0xe0]
    cff8:      	str	x24, [sp, #0xe8]
    cffc:      	str	x25, [sp, #0xf0]
    d000:      	str	x26, [sp, #0xf8]
    d004:      	str	x27, [sp, #0x100]
    d008:      	str	x28, [sp, #0x108]
    d00c:      	sxtw	x4, w4
    d010:      	cmp	x4, #0x0
    d014:      	cset	w7, gt
    d018:      	movz	x16, #0x0, lsl #48
    d01c:      	sub	x9, x16, x4
    d020:      	sub	x10, x9, #0x1
    d024:      	uxtb	w16, w7
    d028:      	cmp	w16, wzr
    d02c:      	b.eq	0xd070 <_stogir.vector-lanes.operands+0x9c>
    d030:      	ldr	x9, [x0, #0x8]
    d034:      	cmp	x4, x9
    d038:      	b.ge	0xd0d4 <_stogir.vector-lanes.operands+0x100>
    d03c:      	add	x9, x0, #0x78
    d040:      	ldr	x9, [x9, #0x8]
    d044:      	cmp	x4, x9
    d048:      	b.ge	0xd1e4 <_stogir.vector-lanes.operands+0x210>
    d04c:      	lsl	x9, x4, #2
    d050:      	ldr	x9, [x0, #0x78]
    d054:      	add	x9, x9, x4, lsl #2
    d058:      	ldr	w9, [x9]
    d05c:      	sxtw	x9, w9
    d060:      	cmp	x9, #0x0
    d064:      	cset	w9, ge
    d068:      	ubfx	x9, x9, #0, #8
    d06c:      	b	0xd1e8 <_stogir.vector-lanes.operands+0x214>
    d070:      	cmp	x4, #0x0
    d074:      	b.ge	0xd0dc <_stogir.vector-lanes.operands+0x108>
    d078:      	add	x11, x0, #0x28
    d07c:      	add	x12, x0, #0x50
    d080:      	ldr	x11, [x11, #0x8]
    d084:      	ldr	x12, [x12, #0x8]
    d088:      	cmp	x11, x12
    d08c:      	b.ne	0xd0bc <_stogir.vector-lanes.operands+0xe8>
    d090:      	cmp	x9, x11
    d094:      	b.gt	0xd380 <_stogir.vector-lanes.operands+0x3ac>
    d098:      	lsl	x9, x10, #2
    d09c:      	ldr	x9, [x0, #0x50]
    d0a0:      	add	x9, x9, x10, lsl #2
    d0a4:      	ldr	w9, [x9]
    d0a8:      	sxtw	x9, w9
    d0ac:      	cmp	x9, #0x0
    d0b0:      	cset	w9, gt
    d0b4:      	ubfx	x9, x9, #0, #8
    d0b8:      	b	0xd384 <_stogir.vector-lanes.operands+0x3b0>
    d0bc:      	movz	x9, #0x0, lsl #48
    d0c0:      	b	0xd0e0 <_stogir.vector-lanes.operands+0x10c>
    d0c4:      	mov	x2, x1
    d0c8:      	mov	x1, x0
    d0cc:      	mov	x0, #0x1                ; =1
    d0d0:      	b	0xd178 <_stogir.vector-lanes.operands+0x1a4>
    d0d4:      	movz	x9, #0x0, lsl #48
    d0d8:      	b	0xd0e0 <_stogir.vector-lanes.operands+0x10c>
    d0dc:      	movz	x9, #0x0, lsl #48
    d0e0:      	cmp	x9, #0x0
    d0e4:      	b.eq	0xd124 <_stogir.vector-lanes.operands+0x150>
    d0e8:      	uxtb	w16, w7
    d0ec:      	cmp	w16, wzr
    d0f0:      	b.eq	0xd108 <_stogir.vector-lanes.operands+0x134>
    d0f4:      	lsl	x7, x4, #4
    d0f8:      	ldr	x7, [x0]
    d0fc:      	add	x4, x7, x4, lsl #4
    d100:      	ldr	x4, [x4]
    d104:      	b	0xd118 <_stogir.vector-lanes.operands+0x144>
    d108:      	lsl	x4, x10, #4
    d10c:      	ldr	x4, [x0, #0x28]
    d110:      	add	x4, x4, x10, lsl #4
    d114:      	ldr	x4, [x4]
    d118:      	mov	x7, x4
    d11c:      	mov	x4, #0x1                ; =1
    d120:      	b	0xd12c <_stogir.vector-lanes.operands+0x158>
    d124:      	movz	x4, #0x0, lsl #48
    d128:      	movz	x7, #0x0, lsl #48
    d12c:      	lsr	w4, w4, #0
    d130:      	lsr	x16, x4, #0
    d134:      	cmp	x16, #0x1
    d138:      	b.eq	0xd154 <_stogir.vector-lanes.operands+0x180>
    d13c:      	b.lo	0xd144 <_stogir.vector-lanes.operands+0x170>
    d140:      	b	0xd158 <_stogir.vector-lanes.operands+0x184>
    d144:      	cmp	x16, #0x0
    d148:      	b.eq	0xd150 <_stogir.vector-lanes.operands+0x17c>
    d14c:      	b	0xd158 <_stogir.vector-lanes.operands+0x184>
    d150:      	b	0xd15c <_stogir.vector-lanes.operands+0x188>
    d154:      	b	0xd1c0 <_stogir.vector-lanes.operands+0x1ec>
    d158:      	b	0xd714 <_stogir.vector-lanes.operands+0x740>
    d15c:      	adrp	x16, 0xd000 <_stogir.vector-lanes.operands+0x2c>
		000000000000d15c:  ARM64_RELOC_PAGE21	l_stogir.484
    d160:      	ldr	x16, [x16]
		000000000000d160:  ARM64_RELOC_PAGEOFF12	l_stogir.484
    d164:      	orr	x0, x16, xzr
    d168:      	str	x8, [sp, #0xa0]
    d16c:      	mov	x1, x0
    d170:      	mov	x0, #0x1                ; =1
    d174:      	mov	x2, #0x1b               ; =27
    d178:      	ldr	x3, [sp, #0xa0]
    d17c:      	str	x0, [x3]
    d180:      	str	x1, [x3, #0x8]
    d184:      	str	x2, [x3, #0x10]
    d188:      	ldr	x19, [sp, #0xc0]
    d18c:      	ldr	x20, [sp, #0xc8]
    d190:      	ldr	x21, [sp, #0xd0]
    d194:      	ldr	x22, [sp, #0xd8]
    d198:      	ldr	x23, [sp, #0xe0]
    d19c:      	ldr	x24, [sp, #0xe8]
    d1a0:      	ldr	x25, [sp, #0xf0]
    d1a4:      	ldr	x26, [sp, #0xf8]
    d1a8:      	ldr	x27, [sp, #0x100]
    d1ac:      	ldr	x28, [sp, #0x108]
    d1b0:      	ldr	x29, [sp]
    d1b4:      	ldr	x30, [sp, #0x8]
    d1b8:      	add	sp, sp, #0x110
    d1bc:      	ret
    d1c0:      	sxtw	x19, w1
    d1c4:      	sxtw	x1, w2
    d1c8:      	lsr	w4, w7, #0
    d1cc:      	ubfx	x4, x4, #8, #8
    d1d0:      	orr	x20, x4, xzr
    d1d4:      	cmp	x19, #0x3d
    d1d8:      	b.ne	0xd1ec <_stogir.vector-lanes.operands+0x218>
    d1dc:      	mov	x21, x20
    d1e0:      	b	0xd1f0 <_stogir.vector-lanes.operands+0x21c>
    d1e4:      	movz	x9, #0x0, lsl #48
    d1e8:      	b	0xd0d8 <_stogir.vector-lanes.operands+0x104>
    d1ec:      	mov	x21, x1
    d1f0:      	cmp	x19, #0x3d
    d1f4:      	b.eq	0xd1fc <_stogir.vector-lanes.operands+0x228>
    d1f8:      	mov	x1, x20
    d1fc:      	lsr	w22, w21, #0
    d200:      	sxtw	x23, w22
    d204:      	cmp	x23, #0xf
    d208:      	cset	w24, gt
    d20c:      	cmp	x23, #0x80
    d210:      	cset	w25, lt
    d214:      	and	x4, x23, #0xf
    d218:      	lsr	w4, w4, #0
    d21c:      	sxtw	x4, w4
    d220:      	cmp	x4, #0x1
    d224:      	cset	w26, ge
    d228:      	cmp	x4, #0xd
    d22c:      	cset	w27, le
    d230:      	cmp	x19, #0x3d
    d234:      	b.lt	0xd284 <_stogir.vector-lanes.operands+0x2b0>
    d238:      	cmp	x19, #0x3f
    d23c:      	b.gt	0xd284 <_stogir.vector-lanes.operands+0x2b0>
    d240:      	uxtb	w16, w24
    d244:      	cmp	w16, wzr
    d248:      	b.eq	0xd284 <_stogir.vector-lanes.operands+0x2b0>
    d24c:      	uxtb	w16, w25
    d250:      	cmp	w16, wzr
    d254:      	b.eq	0xd284 <_stogir.vector-lanes.operands+0x2b0>
    d258:      	uxtb	w16, w26
    d25c:      	cmp	w16, wzr
    d260:      	b.eq	0xd284 <_stogir.vector-lanes.operands+0x2b0>
    d264:      	uxtb	w16, w27
    d268:      	cmp	w16, wzr
    d26c:      	b.eq	0xd284 <_stogir.vector-lanes.operands+0x2b0>
    d270:      	sxtw	x4, w3
    d274:      	cmp	x4, #0x4
    d278:      	b.eq	0xd744 <_stogir.vector-lanes.operands+0x770>
    d27c:      	cmp	x4, #0x8
    d280:      	b.eq	0xd744 <_stogir.vector-lanes.operands+0x770>
    d284:      	adrp	x16, 0xd000 <_stogir.vector-lanes.operands+0x2c>
		000000000000d284:  ARM64_RELOC_PAGE21	l_stogir.485
    d288:      	ldr	x16, [x16]
		000000000000d288:  ARM64_RELOC_PAGEOFF12	l_stogir.485
    d28c:      	orr	x4, x16, xzr
    d290:      	mov	x28, x4
    d294:      	mov	x4, #0x36               ; =54
    d298:      	sxtw	x7, w5
    d29c:      	sxtw	x9, w6
    d2a0:      	cmp	x9, #0x0
    d2a4:      	cset	w9, eq
    d2a8:      	cmp	x19, #0x3f
    d2ac:      	b.ne	0xd780 <_stogir.vector-lanes.operands+0x7ac>
    d2b0:      	lsr	w1, w1, #0
    d2b4:      	lsr	w3, w3, #0
    d2b8:      	mov	w0, w22
    d2bc:      	mov	w2, w3
    d2c0:      	mov	x19, x8
    d2c4:      	mov	x20, x4
    d2c8:      	mov	x22, x7
    d2cc:      	mov	w23, w9
    d2d0:      	bl	0xd2d0 <_stogir.vector-lanes.operands+0x2fc>
		000000000000d2d0:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.compatible?
    d2d4:      	cmp	x0, #0x0
    d2d8:      	b.eq	0xd3bc <_stogir.vector-lanes.operands+0x3e8>
    d2dc:      	mov	x1, x28
    d2e0:      	movz	x0, #0x0, lsl #48
    d2e4:      	b	0xd3c4 <_stogir.vector-lanes.operands+0x3f0>
    d2e8:      	cmp	x19, #0x3d
    d2ec:      	b.ne	0xd78c <_stogir.vector-lanes.operands+0x7b8>
    d2f0:      	lsr	w2, w2, #0
    d2f4:      	lsr	w3, w3, #0
    d2f8:      	str	x0, [sp, #0x80]
    d2fc:      	mov	w0, w22
    d300:      	str	w3, [sp, #0xb0]
    d304:      	str	x1, [sp, #0xa0]
    d308:      	mov	w1, w2
    d30c:      	mov	w2, w3
    d310:      	str	x4, [sp, #0xa8]
    d314:      	str	w8, [sp, #0xb8]
    d318:      	str	w22, [sp, #0x88]
    d31c:      	mov	x22, x7
    d320:      	str	x28, [sp, #0x90]
    d324:      	mov	w28, w5
    d328:      	str	x21, [sp, #0x98]
    d32c:      	mov	w21, w6
    d330:      	bl	0xd330 <_stogir.vector-lanes.operands+0x35c>
		000000000000d330:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.compatible?
    d334:      	cmp	x0, #0x0
    d338:      	b.ne	0xd3ec <_stogir.vector-lanes.operands+0x418>
    d33c:      	adrp	x16, 0xd000 <_stogir.vector-lanes.operands+0x2c>
		000000000000d33c:  ARM64_RELOC_PAGE21	l_stogir.486
    d340:      	ldr	x16, [x16]
		000000000000d340:  ARM64_RELOC_PAGEOFF12	l_stogir.486
    d344:      	orr	x0, x16, xzr
    d348:      	mov	x1, #0x26               ; =38
    d34c:      	b	0xd3f4 <_stogir.vector-lanes.operands+0x420>
    d350:      	mov	x0, x1
    d354:      	mov	x1, x20
    d358:      	str	x21, [sp, #0x98]
    d35c:      	str	x19, [sp, #0xa0]
    d360:      	cmp	x1, #0x0
    d364:      	b.ne	0xd0c4 <_stogir.vector-lanes.operands+0xf0>
    d368:      	ldr	x0, [sp, #0x98]
    d36c:      	and	x0, x0, #0xffffffff
    d370:      	mov	x1, x0
    d374:      	movz	x0, #0x0, lsl #48
    d378:      	movz	x2, #0x0, lsl #48
    d37c:      	b	0xd0d0 <_stogir.vector-lanes.operands+0xfc>
    d380:      	movz	x9, #0x0, lsl #48
    d384:      	b	0xd0c0 <_stogir.vector-lanes.operands+0xec>
    d388:      	adrp	x16, 0xd000 <_stogir.vector-lanes.operands+0x2c>
		000000000000d388:  ARM64_RELOC_PAGE21	l_stogir.487
    d38c:      	ldr	x16, [x16]
		000000000000d38c:  ARM64_RELOC_PAGEOFF12	l_stogir.487
    d390:      	orr	x0, x16, xzr
    d394:      	mov	x1, #0x20               ; =32
    d398:      	b	0xd360 <_stogir.vector-lanes.operands+0x38c>
    d39c:      	mov	x0, #0x1                ; =1
    d3a0:      	cmp	x0, #0x0
    d3a4:      	b.eq	0xd350 <_stogir.vector-lanes.operands+0x37c>
    d3a8:      	adrp	x16, 0xd000 <_stogir.vector-lanes.operands+0x2c>
		000000000000d3a8:  ARM64_RELOC_PAGE21	l_stogir.488
    d3ac:      	ldr	x16, [x16]
		000000000000d3ac:  ARM64_RELOC_PAGEOFF12	l_stogir.488
    d3b0:      	orr	x0, x16, xzr
    d3b4:      	mov	x1, #0x24               ; =36
    d3b8:      	b	0xd358 <_stogir.vector-lanes.operands+0x384>
    d3bc:      	mov	x1, x28
    d3c0:      	mov	x0, #0x1                ; =1
    d3c4:      	cmp	x0, #0x0
    d3c8:      	b.eq	0xd3d4 <_stogir.vector-lanes.operands+0x400>
    d3cc:      	mov	x0, #0x1                ; =1
    d3d0:      	b	0xd3a0 <_stogir.vector-lanes.operands+0x3cc>
    d3d4:      	cmp	x22, #0x0
    d3d8:      	b.ne	0xd39c <_stogir.vector-lanes.operands+0x3c8>
    d3dc:      	uxtb	w16, w23
    d3e0:      	cmp	w16, wzr
    d3e4:      	cset	x0, eq
    d3e8:      	b	0xd3a0 <_stogir.vector-lanes.operands+0x3cc>
    d3ec:      	ldr	x0, [sp, #0x90]
    d3f0:      	ldr	x1, [sp, #0xa8]
    d3f4:      	cmp	x19, #0x3e
    d3f8:      	b.ne	0xd420 <_stogir.vector-lanes.operands+0x44c>
    d3fc:      	cmp	x20, x23
    d400:      	cset	w2, eq
    d404:      	uxtb	w16, w2
    d408:      	cmp	w16, wzr
    d40c:      	cset	x2, eq
    d410:      	fmov	d31, x0
    d414:      	mov	x0, x2
    d418:      	fmov	x2, d31
    d41c:      	b	0xd428 <_stogir.vector-lanes.operands+0x454>
    d420:      	mov	x2, x0
    d424:      	movz	x0, #0x0, lsl #48
    d428:      	cmp	x0, #0x0
    d42c:      	b.eq	0xd448 <_stogir.vector-lanes.operands+0x474>
    d430:      	adrp	x16, 0xd000 <_stogir.vector-lanes.operands+0x2c>
		000000000000d430:  ARM64_RELOC_PAGE21	l_stogir.489
    d434:      	ldr	x16, [x16]
		000000000000d434:  ARM64_RELOC_PAGEOFF12	l_stogir.489
    d438:      	orr	x0, x16, xzr
    d43c:      	mov	x20, x0
    d440:      	mov	x0, #0x27               ; =39
    d444:      	b	0xd450 <_stogir.vector-lanes.operands+0x47c>
    d448:      	mov	x20, x2
    d44c:      	mov	x0, x1
    d450:      	lsr	w28, w28, #0
    d454:      	add	x8, sp, #0x10
    d458:      	mov	w1, w28
    d45c:      	mov	x28, x0
    d460:      	ldr	x0, [sp, #0x80]
    d464:      	bl	0xd464 <_stogir.vector-lanes.operands+0x490>
		000000000000d464:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    d468:      	add	x16, sp, #0x10
    d46c:      	ldr	w0, [x16]
    d470:      	lsr	x16, x0, #0
    d474:      	cmp	x16, #0x1
    d478:      	b.eq	0xd494 <_stogir.vector-lanes.operands+0x4c0>
    d47c:      	b.lo	0xd484 <_stogir.vector-lanes.operands+0x4b0>
    d480:      	b	0xd498 <_stogir.vector-lanes.operands+0x4c4>
    d484:      	cmp	x16, #0x0
    d488:      	b.eq	0xd490 <_stogir.vector-lanes.operands+0x4bc>
    d48c:      	b	0xd498 <_stogir.vector-lanes.operands+0x4c4>
    d490:      	b	0xd49c <_stogir.vector-lanes.operands+0x4c8>
    d494:      	b	0xd514 <_stogir.vector-lanes.operands+0x540>
    d498:      	b	0xd770 <_stogir.vector-lanes.operands+0x79c>
    d49c:      	adrp	x16, 0xd000 <_stogir.vector-lanes.operands+0x2c>
		000000000000d49c:  ARM64_RELOC_PAGE21	l_stogir.490
    d4a0:      	ldr	x16, [x16]
		000000000000d4a0:  ARM64_RELOC_PAGEOFF12	l_stogir.490
    d4a4:      	orr	x0, x16, xzr
    d4a8:      	mov	x20, x0
    d4ac:      	mov	x22, #0x19              ; =25
    d4b0:      	cmp	x19, #0x3e
    d4b4:      	b.ne	0xd57c <_stogir.vector-lanes.operands+0x5a8>
    d4b8:      	lsr	w21, w21, #0
    d4bc:      	add	x8, sp, #0x50
    d4c0:      	ldr	x0, [sp, #0x80]
    d4c4:      	mov	w1, w21
    d4c8:      	bl	0xd4c8 <_stogir.vector-lanes.operands+0x4f4>
		000000000000d4c8:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    d4cc:      	add	x16, sp, #0x50
    d4d0:      	ldr	w0, [x16]
    d4d4:      	lsr	x16, x0, #0
    d4d8:      	cmp	x16, #0x1
    d4dc:      	b.eq	0xd4f8 <_stogir.vector-lanes.operands+0x524>
    d4e0:      	b.lo	0xd4e8 <_stogir.vector-lanes.operands+0x514>
    d4e4:      	b	0xd4fc <_stogir.vector-lanes.operands+0x528>
    d4e8:      	cmp	x16, #0x0
    d4ec:      	b.eq	0xd4f4 <_stogir.vector-lanes.operands+0x520>
    d4f0:      	b	0xd4fc <_stogir.vector-lanes.operands+0x528>
    d4f4:      	b	0xd500 <_stogir.vector-lanes.operands+0x52c>
    d4f8:      	b	0xd644 <_stogir.vector-lanes.operands+0x670>
    d4fc:      	b	0xd778 <_stogir.vector-lanes.operands+0x7a4>
    d500:      	adrp	x16, 0xd000 <_stogir.vector-lanes.operands+0x2c>
		000000000000d500:  ARM64_RELOC_PAGE21	l_stogir.491
    d504:      	ldr	x16, [x16]
		000000000000d504:  ARM64_RELOC_PAGEOFF12	l_stogir.491
    d508:      	orr	x0, x16, xzr
    d50c:      	mov	x1, #0x20               ; =32
    d510:      	b	0xd398 <_stogir.vector-lanes.operands+0x3c4>
    d514:      	add	x16, sp, #0x10
    d518:      	orr	x0, x16, xzr
    d51c:      	add	x0, x0, #0x8
    d520:      	add	x16, sp, #0x10
    d524:      	ldr	x1, [x16, #0x8]
    d528:      	add	x16, sp, #0x40
    d52c:      	str	x1, [x16]
    d530:      	lsr	w1, w1, #0
    d534:      	ldr	x0, [x0, #0x8]
    d538:      	add	x16, sp, #0x40
    d53c:      	str	x0, [x16, #0x8]
    d540:      	ubfx	x0, x1, #8, #8
    d544:      	cmp	x0, #0x1
    d548:      	b.lt	0xd5a8 <_stogir.vector-lanes.operands+0x5d4>
    d54c:      	cmp	x0, #0xb
    d550:      	b.gt	0xd5a8 <_stogir.vector-lanes.operands+0x5d4>
    d554:      	add	x16, sp, #0x40
    d558:      	ldr	w0, [x16]
    d55c:      	uxtb	w0, w0
    d560:      	cmp	x0, #0x48
    d564:      	b.eq	0xd5a8 <_stogir.vector-lanes.operands+0x5d4>
    d568:      	cmp	x0, #0x46
    d56c:      	b.eq	0xd5a8 <_stogir.vector-lanes.operands+0x5d4>
    d570:      	mov	x0, x20
    d574:      	mov	x1, x28
    d578:      	b	0xd5b8 <_stogir.vector-lanes.operands+0x5e4>
    d57c:      	ldr	w0, [sp, #0xb8]
    d580:      	uxtb	w16, w0
    d584:      	cmp	w16, wzr
    d588:      	b.eq	0xd388 <_stogir.vector-lanes.operands+0x3b4>
    d58c:      	mov	x0, x20
    d590:      	mov	x1, x22
    d594:      	b	0xd398 <_stogir.vector-lanes.operands+0x3c4>
    d598:      	mov	x0, x2
    d59c:      	mov	x20, x0
    d5a0:      	mov	x22, x1
    d5a4:      	b	0xd4b0 <_stogir.vector-lanes.operands+0x4dc>
    d5a8:      	adrp	x16, 0xd000 <_stogir.vector-lanes.operands+0x2c>
		000000000000d5a8:  ARM64_RELOC_PAGE21	l_stogir.492
    d5ac:      	ldr	x16, [x16]
		000000000000d5ac:  ARM64_RELOC_PAGEOFF12	l_stogir.492
    d5b0:      	orr	x0, x16, xzr
    d5b4:      	mov	x1, #0x2b               ; =43
    d5b8:      	cmp	x22, #0x0
    d5bc:      	b.ge	0xd5e8 <_stogir.vector-lanes.operands+0x614>
    d5c0:      	add	x16, sp, #0x40
    d5c4:      	ldr	w2, [x16]
    d5c8:      	uxtb	w3, w2
    d5cc:      	ubfx	x2, x2, #8, #8
    d5d0:      	cmp	x3, x2
    d5d4:      	b.eq	0xd6ac <_stogir.vector-lanes.operands+0x6d8>
    d5d8:      	cmp	x3, #0x49
    d5dc:      	b.eq	0xd6ac <_stogir.vector-lanes.operands+0x6d8>
    d5e0:      	movz	x2, #0x0, lsl #48
    d5e4:      	b	0xd634 <_stogir.vector-lanes.operands+0x660>
    d5e8:      	mov	x2, x0
    d5ec:      	movz	x0, #0x0, lsl #48
    d5f0:      	cmp	x0, #0x0
    d5f4:      	b.eq	0xd598 <_stogir.vector-lanes.operands+0x5c4>
    d5f8:      	adrp	x16, 0xd000 <_stogir.vector-lanes.operands+0x2c>
		000000000000d5f8:  ARM64_RELOC_PAGE21	l_stogir.493
    d5fc:      	ldr	x16, [x16]
		000000000000d5fc:  ARM64_RELOC_PAGEOFF12	l_stogir.493
    d600:      	orr	x0, x16, xzr
    d604:      	mov	x1, #0x28               ; =40
    d608:      	b	0xd59c <_stogir.vector-lanes.operands+0x5c8>
    d60c:      	movn	x4, #0x0, lsl #48
    d610:      	ubfx	x2, x2, #0, #32
    d614:      	ubfx	x3, x3, #0, #32
    d618:      	lsl	x3, x3, #32
    d61c:      	orr	x2, x3, x2
    d620:      	lsr	w4, w4, #0
    d624:      	sxtw	x4, w4
    d628:      	cmp	x2, x4
    d62c:      	cset	w2, hs
    d630:      	ubfx	x2, x2, #0, #8
    d634:      	fmov	d31, x0
    d638:      	mov	x0, x2
    d63c:      	fmov	x2, d31
    d640:      	b	0xd5f0 <_stogir.vector-lanes.operands+0x61c>
    d644:      	add	x16, sp, #0x50
    d648:      	ldr	x0, [x16, #0x8]
    d64c:      	uxtb	w1, w0
    d650:      	cmp	x1, #0x48
    d654:      	b.eq	0xd698 <_stogir.vector-lanes.operands+0x6c4>
    d658:      	cmp	x1, #0x46
    d65c:      	b.eq	0xd698 <_stogir.vector-lanes.operands+0x6c4>
    d660:      	ldr	w1, [sp, #0xb0]
    d664:      	lsr	w1, w1, #0
    d668:      	lsr	w0, w0, #0
    d66c:      	ubfx	x0, x0, #8, #8
    d670:      	lsr	w0, w0, #0
    d674:      	mov	w2, w1
    d678:      	mov	w1, w0
    d67c:      	ldr	w0, [sp, #0x88]
    d680:      	bl	0xd680 <_stogir.vector-lanes.operands+0x6ac>
		000000000000d680:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.compatible?
    d684:      	cmp	x0, #0x0
    d688:      	b.eq	0xd698 <_stogir.vector-lanes.operands+0x6c4>
    d68c:      	mov	x0, x20
    d690:      	mov	x1, x22
    d694:      	b	0xd6a8 <_stogir.vector-lanes.operands+0x6d4>
    d698:      	adrp	x16, 0xd000 <_stogir.vector-lanes.operands+0x2c>
		000000000000d698:  ARM64_RELOC_PAGE21	l_stogir.494
    d69c:      	ldr	x16, [x16]
		000000000000d69c:  ARM64_RELOC_PAGEOFF12	l_stogir.494
    d6a0:      	orr	x0, x16, xzr
    d6a4:      	mov	x1, #0x27               ; =39
    d6a8:      	b	0xd510 <_stogir.vector-lanes.operands+0x53c>
    d6ac:      	add	x16, sp, #0x40
    d6b0:      	ldr	w2, [x16, #0x8]
    d6b4:      	add	x16, sp, #0x40
    d6b8:      	ldr	w3, [x16, #0xc]
    d6bc:      	uxtb	w16, w24
    d6c0:      	cmp	w16, wzr
    d6c4:      	b.eq	0xd71c <_stogir.vector-lanes.operands+0x748>
    d6c8:      	uxtb	w16, w25
    d6cc:      	cmp	w16, wzr
    d6d0:      	b.eq	0xd71c <_stogir.vector-lanes.operands+0x748>
    d6d4:      	uxtb	w16, w26
    d6d8:      	cmp	w16, wzr
    d6dc:      	b.eq	0xd71c <_stogir.vector-lanes.operands+0x748>
    d6e0:      	uxtb	w16, w27
    d6e4:      	cmp	w16, wzr
    d6e8:      	b.eq	0xd71c <_stogir.vector-lanes.operands+0x748>
    d6ec:      	ubfx	x4, x23, #4, #32
    d6f0:      	sxtw	x4, w4
    d6f4:      	sub	x4, x4, #0x1
    d6f8:      	lsr	w4, w4, #0
    d6fc:      	sxtw	x4, w4
    d700:      	mov	x16, #0x1               ; =1
    d704:      	lsl	x4, x16, x4
    d708:      	lsr	w4, w4, #0
    d70c:      	sxtw	x4, w4
    d710:      	b	0xd610 <_stogir.vector-lanes.operands+0x63c>
    d714:      	brk	#0
    d718:      	b	0xd714 <_stogir.vector-lanes.operands+0x740>
    d71c:      	cmp	x23, #0x0
    d720:      	b.lt	0xd60c <_stogir.vector-lanes.operands+0x638>
    d724:      	cmp	x23, #0xd
    d728:      	b.gt	0xd60c <_stogir.vector-lanes.operands+0x638>
    d72c:      	cmp	x23, #0x0
    d730:      	cset	w4, eq
    d734:      	uxtb	w16, w4
    d738:      	cmp	w16, wzr
    d73c:      	cset	x4, eq
    d740:      	b	0xd610 <_stogir.vector-lanes.operands+0x63c>
    d744:      	uxtb	w7, w7
    d748:      	cmp	x7, #0x48
    d74c:      	b.eq	0xd284 <_stogir.vector-lanes.operands+0x2b0>
    d750:      	cmp	x7, #0x46
    d754:      	b.eq	0xd284 <_stogir.vector-lanes.operands+0x2b0>
    d758:      	adrp	x16, 0xd000 <_stogir.vector-lanes.operands+0x2c>
		000000000000d758:  ARM64_RELOC_PAGE21	l_stogir.495
    d75c:      	ldr	x16, [x16]
		000000000000d75c:  ARM64_RELOC_PAGEOFF12	l_stogir.495
    d760:      	orr	x4, x16, xzr
    d764:      	mov	x28, x4
    d768:      	movz	x4, #0x0, lsl #48
    d76c:      	b	0xd298 <_stogir.vector-lanes.operands+0x2c4>
    d770:      	brk	#0
    d774:      	b	0xd770 <_stogir.vector-lanes.operands+0x79c>
    d778:      	brk	#0
    d77c:      	b	0xd778 <_stogir.vector-lanes.operands+0x7a4>
    d780:      	mov	x1, x8
    d784:      	mov	w8, w9
    d788:      	b	0xd2e8 <_stogir.vector-lanes.operands+0x314>
    d78c:      	str	x21, [sp, #0x98]
    d790:      	str	x1, [sp, #0xa0]
    d794:      	str	x0, [sp, #0x80]
    d798:      	str	w3, [sp, #0xb0]
    d79c:      	mov	w21, w6
    d7a0:      	str	w22, [sp, #0x88]
    d7a4:      	mov	x22, x7
    d7a8:      	str	w8, [sp, #0xb8]
    d7ac:      	str	x28, [sp, #0x90]
    d7b0:      	mov	w28, w5
    d7b4:      	str	x4, [sp, #0xa8]
    d7b8:      	b	0xd3ec <_stogir.vector-lanes.operands+0x418>

000000000000d7bc <_stogir.vector-comparison.operation?>:
    d7bc:      	sxtw	x0, w0
    d7c0:      	cmp	x0, #0xe
    d7c4:      	b.lt	0xd7d8 <_stogir.vector-comparison.operation?+0x1c>
    d7c8:      	cmp	x0, #0x19
    d7cc:      	cset	w0, le
    d7d0:      	ubfx	x0, x0, #0, #8
    d7d4:      	b	0xd7dc <_stogir.vector-comparison.operation?+0x20>
    d7d8:      	movz	x0, #0x0, lsl #48
    d7dc:      	ret

000000000000d7e0 <_stogir.vector-comparison.operands>:
    d7e0:      	sub	sp, sp, #0xc0
    d7e4:      	str	x29, [sp]
    d7e8:      	str	x30, [sp, #0x8]
    d7ec:      	mov	x29, sp
    d7f0:      	str	x19, [sp, #0x70]
    d7f4:      	str	x20, [sp, #0x78]
    d7f8:      	str	x21, [sp, #0x80]
    d7fc:      	str	x22, [sp, #0x88]
    d800:      	str	x23, [sp, #0x90]
    d804:      	str	x24, [sp, #0x98]
    d808:      	str	x25, [sp, #0xa0]
    d80c:      	str	x26, [sp, #0xa8]
    d810:      	str	x27, [sp, #0xb0]
    d814:      	adrp	x16, 0xd000 <_stogir.vector-lanes.operands+0x2c>
		000000000000d814:  ARM64_RELOC_PAGE21	l_stogir.496
    d818:      	ldr	x16, [x16]
		000000000000d818:  ARM64_RELOC_PAGEOFF12	l_stogir.496
    d81c:      	orr	x19, x16, xzr
    d820:      	lsr	w4, w4, #0
    d824:      	mov	x20, x8
    d828:      	add	x8, sp, #0x10
    d82c:      	mov	x21, x0
    d830:      	mov	w22, w1
    d834:      	mov	w1, w4
    d838:      	mov	w23, w2
    d83c:      	mov	w24, w3
    d840:      	mov	w25, w5
    d844:      	bl	0xd844 <_stogir.vector-comparison.operands+0x64>
		000000000000d844:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    d848:      	add	x16, sp, #0x10
    d84c:      	ldr	w0, [x16]
    d850:      	lsr	x16, x0, #0
    d854:      	cmp	x16, #0x1
    d858:      	b.eq	0xd874 <_stogir.vector-comparison.operands+0x94>
    d85c:      	b.lo	0xd864 <_stogir.vector-comparison.operands+0x84>
    d860:      	b	0xd878 <_stogir.vector-comparison.operands+0x98>
    d864:      	cmp	x16, #0x0
    d868:      	b.eq	0xd870 <_stogir.vector-comparison.operands+0x90>
    d86c:      	b	0xd878 <_stogir.vector-comparison.operands+0x98>
    d870:      	b	0xd87c <_stogir.vector-comparison.operands+0x9c>
    d874:      	b	0xd8c8 <_stogir.vector-comparison.operands+0xe8>
    d878:      	b	0xda50 <_stogir.vector-comparison.operands+0x270>
    d87c:      	mov	x1, x19
    d880:      	mov	x0, #0x1                ; =1
    d884:      	mov	x2, #0x21               ; =33
    d888:      	str	x0, [x20]
    d88c:      	str	x1, [x20, #0x8]
    d890:      	str	x2, [x20, #0x10]
    d894:      	ldr	x19, [sp, #0x70]
    d898:      	ldr	x20, [sp, #0x78]
    d89c:      	ldr	x21, [sp, #0x80]
    d8a0:      	ldr	x22, [sp, #0x88]
    d8a4:      	ldr	x23, [sp, #0x90]
    d8a8:      	ldr	x24, [sp, #0x98]
    d8ac:      	ldr	x25, [sp, #0xa0]
    d8b0:      	ldr	x26, [sp, #0xa8]
    d8b4:      	ldr	x27, [sp, #0xb0]
    d8b8:      	ldr	x29, [sp]
    d8bc:      	ldr	x30, [sp, #0x8]
    d8c0:      	add	sp, sp, #0xc0
    d8c4:      	ret
    d8c8:      	lsr	w25, w25, #0
    d8cc:      	add	x16, sp, #0x10
    d8d0:      	ldr	x26, [x16, #0x8]
    d8d4:      	add	x8, sp, #0x40
    d8d8:      	mov	x0, x21
    d8dc:      	mov	w1, w25
    d8e0:      	bl	0xd8e0 <_stogir.vector-comparison.operands+0x100>
		000000000000d8e0:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    d8e4:      	add	x16, sp, #0x40
    d8e8:      	ldr	w0, [x16]
    d8ec:      	lsr	x16, x0, #0
    d8f0:      	cmp	x16, #0x1
    d8f4:      	b.eq	0xd910 <_stogir.vector-comparison.operands+0x130>
    d8f8:      	b.lo	0xd900 <_stogir.vector-comparison.operands+0x120>
    d8fc:      	b	0xd914 <_stogir.vector-comparison.operands+0x134>
    d900:      	cmp	x16, #0x0
    d904:      	b.eq	0xd90c <_stogir.vector-comparison.operands+0x12c>
    d908:      	b	0xd914 <_stogir.vector-comparison.operands+0x134>
    d90c:      	b	0xd918 <_stogir.vector-comparison.operands+0x138>
    d910:      	b	0xd928 <_stogir.vector-comparison.operands+0x148>
    d914:      	b	0xda58 <_stogir.vector-comparison.operands+0x278>
    d918:      	mov	x1, x19
    d91c:      	mov	x0, #0x1                ; =1
    d920:      	mov	x2, #0x21               ; =33
    d924:      	b	0xd888 <_stogir.vector-comparison.operands+0xa8>
    d928:      	sxtw	x0, w24
    d92c:      	add	x16, sp, #0x40
    d930:      	ldr	x19, [x16, #0x8]
    d934:      	cmp	x0, #0x4
    d938:      	b.eq	0xd960 <_stogir.vector-comparison.operands+0x180>
    d93c:      	cmp	x0, #0x8
    d940:      	b.eq	0xd960 <_stogir.vector-comparison.operands+0x180>
    d944:      	adrp	x16, 0xd000 <_stogir.vector-lanes.operands+0x2c>
		000000000000d944:  ARM64_RELOC_PAGE21	l_stogir.497
    d948:      	ldr	x16, [x16]
		000000000000d948:  ARM64_RELOC_PAGEOFF12	l_stogir.497
    d94c:      	orr	x0, x16, xzr
    d950:      	mov	x1, x0
    d954:      	mov	x0, #0x1                ; =1
    d958:      	mov	x2, #0x33               ; =51
    d95c:      	b	0xd924 <_stogir.vector-comparison.operands+0x144>
    d960:      	lsr	w22, w22, #0
    d964:      	lsr	w0, w26, #0
    d968:      	ubfx	x21, x0, #8, #8
    d96c:      	orr	x0, x21, xzr
    d970:      	lsr	w0, w0, #0
    d974:      	mov	w1, w0
    d978:      	mov	w0, w22
    d97c:      	bl	0xd97c <_stogir.vector-comparison.operands+0x19c>
		000000000000d97c:  ARM64_RELOC_BRANCH26	_stogir.vector-comparison.valid-type?
    d980:      	cmp	x0, #0x0
    d984:      	b.eq	0xd944 <_stogir.vector-comparison.operands+0x164>
    d988:      	lsr	w0, w19, #0
    d98c:      	ubfx	x0, x0, #8, #8
    d990:      	cmp	x21, x0
    d994:      	b.ne	0xd944 <_stogir.vector-comparison.operands+0x164>
    d998:      	uxtb	w26, w26
    d99c:      	cmp	x26, #0x48
    d9a0:      	b.eq	0xd944 <_stogir.vector-comparison.operands+0x164>
    d9a4:      	cmp	x26, #0x46
    d9a8:      	b.eq	0xd944 <_stogir.vector-comparison.operands+0x164>
    d9ac:      	uxtb	w19, w19
    d9b0:      	cmp	x19, #0x48
    d9b4:      	b.eq	0xd944 <_stogir.vector-comparison.operands+0x164>
    d9b8:      	cmp	x19, #0x46
    d9bc:      	b.eq	0xd944 <_stogir.vector-comparison.operands+0x164>
    d9c0:      	sxtw	x23, w23
    d9c4:      	cmp	x23, #0xf
    d9c8:      	cset	w0, gt
    d9cc:      	uxtb	w16, w0
    d9d0:      	cmp	w16, wzr
    d9d4:      	b.eq	0xd944 <_stogir.vector-comparison.operands+0x164>
    d9d8:      	cmp	x23, #0x80
    d9dc:      	cset	w1, lt
    d9e0:      	uxtb	w16, w1
    d9e4:      	cmp	w16, wzr
    d9e8:      	b.eq	0xd944 <_stogir.vector-comparison.operands+0x164>
    d9ec:      	and	x2, x23, #0xf
    d9f0:      	lsr	w2, w2, #0
    d9f4:      	sxtw	x2, w2
    d9f8:      	cmp	x2, #0x1
    d9fc:      	cset	w3, ge
    da00:      	uxtb	w16, w3
    da04:      	cmp	w16, wzr
    da08:      	b.eq	0xd944 <_stogir.vector-comparison.operands+0x164>
    da0c:      	cmp	x2, #0xd
    da10:      	cset	w4, le
    da14:      	uxtb	w16, w4
    da18:      	cmp	w16, wzr
    da1c:      	b.eq	0xd944 <_stogir.vector-comparison.operands+0x164>
    da20:      	cmp	x23, #0x0
    da24:      	cset	w5, ge
    da28:      	cmp	x23, #0xd
    da2c:      	cset	w6, le
    da30:      	uxtb	w16, w5
    da34:      	cmp	w16, wzr
    da38:      	b.eq	0xda60 <_stogir.vector-comparison.operands+0x280>
    da3c:      	uxtb	w16, w6
    da40:      	cmp	w16, wzr
    da44:      	b.eq	0xda60 <_stogir.vector-comparison.operands+0x280>
    da48:      	mov	x7, x2
    da4c:      	b	0xda94 <_stogir.vector-comparison.operands+0x2b4>
    da50:      	brk	#0
    da54:      	b	0xda50 <_stogir.vector-comparison.operands+0x270>
    da58:      	brk	#0
    da5c:      	b	0xda58 <_stogir.vector-comparison.operands+0x278>
    da60:      	uxtb	w16, w0
    da64:      	cmp	w16, wzr
    da68:      	b.eq	0xda90 <_stogir.vector-comparison.operands+0x2b0>
    da6c:      	uxtb	w16, w1
    da70:      	cmp	w16, wzr
    da74:      	b.eq	0xda90 <_stogir.vector-comparison.operands+0x2b0>
    da78:      	uxtb	w16, w3
    da7c:      	cmp	w16, wzr
    da80:      	b.eq	0xda90 <_stogir.vector-comparison.operands+0x2b0>
    da84:      	uxtb	w16, w4
    da88:      	cmp	w16, wzr
    da8c:      	b.ne	0xda48 <_stogir.vector-comparison.operands+0x268>
    da90:      	movn	x7, #0x0, lsl #48
    da94:      	lsr	w7, w7, #0
    da98:      	sxtw	x7, w7
    da9c:      	cmp	x7, #0x1
    daa0:      	b.lt	0xd944 <_stogir.vector-comparison.operands+0x164>
    daa4:      	cmp	x7, #0xb
    daa8:      	b.gt	0xd944 <_stogir.vector-comparison.operands+0x164>
    daac:      	uxtb	w16, w0
    dab0:      	cmp	w16, wzr
    dab4:      	b.eq	0xdb04 <_stogir.vector-comparison.operands+0x324>
    dab8:      	uxtb	w16, w1
    dabc:      	cmp	w16, wzr
    dac0:      	b.eq	0xdb04 <_stogir.vector-comparison.operands+0x324>
    dac4:      	uxtb	w16, w3
    dac8:      	cmp	w16, wzr
    dacc:      	b.eq	0xdb04 <_stogir.vector-comparison.operands+0x324>
    dad0:      	uxtb	w16, w4
    dad4:      	cmp	w16, wzr
    dad8:      	b.eq	0xdb04 <_stogir.vector-comparison.operands+0x324>
    dadc:      	ubfx	x7, x23, #4, #32
    dae0:      	sxtw	x7, w7
    dae4:      	sub	x7, x7, #0x1
    dae8:      	lsr	w7, w7, #0
    daec:      	sxtw	x7, w7
    daf0:      	mov	x16, #0x1               ; =1
    daf4:      	lsl	x7, x16, x7
    daf8:      	lsr	w7, w7, #0
    dafc:      	sxtw	x7, w7
    db00:      	b	0xdb74 <_stogir.vector-comparison.operands+0x394>
    db04:      	uxtb	w16, w5
    db08:      	cmp	w16, wzr
    db0c:      	b.eq	0xdb70 <_stogir.vector-comparison.operands+0x390>
    db10:      	uxtb	w16, w6
    db14:      	cmp	w16, wzr
    db18:      	b.eq	0xdb70 <_stogir.vector-comparison.operands+0x390>
    db1c:      	cmp	x23, #0x0
    db20:      	cset	w7, eq
    db24:      	uxtb	w16, w7
    db28:      	cmp	w16, wzr
    db2c:      	cset	x7, eq
    db30:      	b	0xdb74 <_stogir.vector-comparison.operands+0x394>
    db34:      	movn	x8, #0x0, lsl #48
    db38:      	lsr	w7, w7, #0
    db3c:      	sxtw	x7, w7
    db40:      	lsr	w8, w8, #0
    db44:      	sxtw	x8, w8
    db48:      	cmp	x7, x8
    db4c:      	b.ne	0xd944 <_stogir.vector-comparison.operands+0x164>
    db50:      	uxtb	w16, w5
    db54:      	cmp	w16, wzr
    db58:      	b.eq	0xdc24 <_stogir.vector-comparison.operands+0x444>
    db5c:      	uxtb	w16, w6
    db60:      	cmp	w16, wzr
    db64:      	b.eq	0xdc24 <_stogir.vector-comparison.operands+0x444>
    db68:      	mov	x0, x2
    db6c:      	b	0xdc58 <_stogir.vector-comparison.operands+0x478>
    db70:      	movn	x7, #0x0, lsl #48
    db74:      	and	x8, x21, #0xf
    db78:      	cmp	x21, #0xd
    db7c:      	cset	w19, le
    db80:      	cmp	x21, #0xf
    db84:      	cset	w22, gt
    db88:      	cmp	x21, #0x80
    db8c:      	cset	w23, lt
    db90:      	lsr	w8, w8, #0
    db94:      	sxtw	x25, w8
    db98:      	cmp	x25, #0x1
    db9c:      	cset	w26, ge
    dba0:      	cmp	x25, #0xd
    dba4:      	cset	w27, le
    dba8:      	uxtb	w16, w22
    dbac:      	cmp	w16, wzr
    dbb0:      	b.eq	0xdc00 <_stogir.vector-comparison.operands+0x420>
    dbb4:      	uxtb	w16, w23
    dbb8:      	cmp	w16, wzr
    dbbc:      	b.eq	0xdc00 <_stogir.vector-comparison.operands+0x420>
    dbc0:      	uxtb	w16, w26
    dbc4:      	cmp	w16, wzr
    dbc8:      	b.eq	0xdc00 <_stogir.vector-comparison.operands+0x420>
    dbcc:      	uxtb	w16, w27
    dbd0:      	cmp	w16, wzr
    dbd4:      	b.eq	0xdc00 <_stogir.vector-comparison.operands+0x420>
    dbd8:      	ubfx	x8, x21, #4, #32
    dbdc:      	sxtw	x8, w8
    dbe0:      	sub	x8, x8, #0x1
    dbe4:      	lsr	w8, w8, #0
    dbe8:      	sxtw	x8, w8
    dbec:      	mov	x16, #0x1               ; =1
    dbf0:      	lsl	x8, x16, x8
    dbf4:      	lsr	w8, w8, #0
    dbf8:      	sxtw	x8, w8
    dbfc:      	b	0xdb38 <_stogir.vector-comparison.operands+0x358>
    dc00:      	uxtb	w16, w19
    dc04:      	cmp	w16, wzr
    dc08:      	b.eq	0xdb34 <_stogir.vector-comparison.operands+0x354>
    dc0c:      	cmp	x21, #0x0
    dc10:      	cset	w8, eq
    dc14:      	uxtb	w16, w8
    dc18:      	cmp	w16, wzr
    dc1c:      	cset	x8, eq
    dc20:      	b	0xdb38 <_stogir.vector-comparison.operands+0x358>
    dc24:      	uxtb	w16, w0
    dc28:      	cmp	w16, wzr
    dc2c:      	b.eq	0xdc54 <_stogir.vector-comparison.operands+0x474>
    dc30:      	uxtb	w16, w1
    dc34:      	cmp	w16, wzr
    dc38:      	b.eq	0xdc54 <_stogir.vector-comparison.operands+0x474>
    dc3c:      	uxtb	w16, w3
    dc40:      	cmp	w16, wzr
    dc44:      	b.eq	0xdc54 <_stogir.vector-comparison.operands+0x474>
    dc48:      	uxtb	w16, w4
    dc4c:      	cmp	w16, wzr
    dc50:      	b.ne	0xdb68 <_stogir.vector-comparison.operands+0x388>
    dc54:      	movn	x0, #0x0, lsl #48
    dc58:      	lsr	w24, w24, #0
    dc5c:      	lsr	w0, w0, #0
    dc60:      	lsr	w0, w0, #0
    dc64:      	mov	w1, w24
    dc68:      	bl	0xdc68 <_stogir.vector-comparison.operands+0x488>
		000000000000dc68:  ARM64_RELOC_BRANCH26	_stogir.types.scalar-size
    dc6c:      	uxtb	w16, w19
    dc70:      	cmp	w16, wzr
    dc74:      	b.ne	0xdca8 <_stogir.vector-comparison.operands+0x4c8>
    dc78:      	uxtb	w16, w22
    dc7c:      	cmp	w16, wzr
    dc80:      	b.eq	0xdcec <_stogir.vector-comparison.operands+0x50c>
    dc84:      	uxtb	w16, w23
    dc88:      	cmp	w16, wzr
    dc8c:      	b.eq	0xdcec <_stogir.vector-comparison.operands+0x50c>
    dc90:      	uxtb	w16, w26
    dc94:      	cmp	w16, wzr
    dc98:      	b.eq	0xdcec <_stogir.vector-comparison.operands+0x50c>
    dc9c:      	uxtb	w16, w27
    dca0:      	cmp	w16, wzr
    dca4:      	b.eq	0xdcec <_stogir.vector-comparison.operands+0x50c>
    dca8:      	mov	x1, x25
    dcac:      	lsr	w0, w0, #0
    dcb0:      	sxtw	x19, w0
    dcb4:      	lsr	w1, w1, #0
    dcb8:      	lsr	w1, w1, #0
    dcbc:      	mov	w0, w1
    dcc0:      	mov	w1, w24
    dcc4:      	bl	0xdcc4 <_stogir.vector-comparison.operands+0x4e4>
		000000000000dcc4:  ARM64_RELOC_BRANCH26	_stogir.types.scalar-size
    dcc8:      	lsr	w0, w0, #0
    dccc:      	sxtw	x0, w0
    dcd0:      	cmp	x19, x0
    dcd4:      	b.ne	0xd944 <_stogir.vector-comparison.operands+0x164>
    dcd8:      	and	x0, x21, #0xffffffff
    dcdc:      	mov	x1, x0
    dce0:      	movz	x0, #0x0, lsl #48
    dce4:      	movz	x2, #0x0, lsl #48
    dce8:      	b	0xd95c <_stogir.vector-comparison.operands+0x17c>
    dcec:      	movn	x1, #0x0, lsl #48
    dcf0:      	b	0xdcac <_stogir.vector-comparison.operands+0x4cc>

000000000000dcf4 <_stogir.vector-arithmetic.operation?>:
    dcf4:      	sxtw	x0, w0
    dcf8:      	cmp	x0, #0x1f
    dcfc:      	b.eq	0xdd58 <_stogir.vector-arithmetic.operation?+0x64>
    dd00:      	cmp	x0, #0x20
    dd04:      	b.eq	0xdd58 <_stogir.vector-arithmetic.operation?+0x64>
    dd08:      	cmp	x0, #0x2d
    dd0c:      	b.eq	0xdd58 <_stogir.vector-arithmetic.operation?+0x64>
    dd10:      	cmp	x0, #0x36
    dd14:      	b.eq	0xdd58 <_stogir.vector-arithmetic.operation?+0x64>
    dd18:      	cmp	x0, #0x37
    dd1c:      	b.eq	0xdd58 <_stogir.vector-arithmetic.operation?+0x64>
    dd20:      	cmp	x0, #0x38
    dd24:      	b.eq	0xdd58 <_stogir.vector-arithmetic.operation?+0x64>
    dd28:      	cmp	x0, #0x39
    dd2c:      	b.eq	0xdd58 <_stogir.vector-arithmetic.operation?+0x64>
    dd30:      	cmp	x0, #0x3a
    dd34:      	b.eq	0xdd60 <_stogir.vector-arithmetic.operation?+0x6c>
    dd38:      	cmp	x0, #0x3b
    dd3c:      	b.eq	0xdd60 <_stogir.vector-arithmetic.operation?+0x6c>
    dd40:      	cmp	x0, #0x31
    dd44:      	b.lt	0xdd78 <_stogir.vector-arithmetic.operation?+0x84>
    dd48:      	cmp	x0, #0x35
    dd4c:      	b.gt	0xdd78 <_stogir.vector-arithmetic.operation?+0x84>
    dd50:      	mov	x0, #0x1                ; =1
    dd54:      	b	0xdd74 <_stogir.vector-arithmetic.operation?+0x80>
    dd58:      	mov	x0, #0x1                ; =1
    dd5c:      	ret
    dd60:      	mov	x0, #0x1                ; =1
    dd64:      	b	0xdd5c <_stogir.vector-arithmetic.operation?+0x68>
    dd68:      	cmp	x0, #0x30
    dd6c:      	cset	w0, eq
    dd70:      	ubfx	x0, x0, #0, #8
    dd74:      	b	0xdd64 <_stogir.vector-arithmetic.operation?+0x70>
    dd78:      	cmp	x0, #0x1a
    dd7c:      	b.ne	0xdd88 <_stogir.vector-arithmetic.operation?+0x94>
    dd80:      	mov	x0, #0x1                ; =1
    dd84:      	b	0xdd74 <_stogir.vector-arithmetic.operation?+0x80>
    dd88:      	cmp	x0, #0x1b
    dd8c:      	b.ne	0xdd98 <_stogir.vector-arithmetic.operation?+0xa4>
    dd90:      	mov	x0, #0x1                ; =1
    dd94:      	b	0xdd74 <_stogir.vector-arithmetic.operation?+0x80>
    dd98:      	cmp	x0, #0x1c
    dd9c:      	b.ne	0xdda8 <_stogir.vector-arithmetic.operation?+0xb4>
    dda0:      	mov	x0, #0x1                ; =1
    dda4:      	b	0xdd74 <_stogir.vector-arithmetic.operation?+0x80>
    dda8:      	cmp	x0, #0x1d
    ddac:      	b.ne	0xddb8 <_stogir.vector-arithmetic.operation?+0xc4>
    ddb0:      	mov	x0, #0x1                ; =1
    ddb4:      	b	0xdd74 <_stogir.vector-arithmetic.operation?+0x80>
    ddb8:      	cmp	x0, #0x1e
    ddbc:      	b.ne	0xddc8 <_stogir.vector-arithmetic.operation?+0xd4>
    ddc0:      	mov	x0, #0x1                ; =1
    ddc4:      	b	0xdd74 <_stogir.vector-arithmetic.operation?+0x80>
    ddc8:      	cmp	x0, #0x2e
    ddcc:      	b.ne	0xddd8 <_stogir.vector-arithmetic.operation?+0xe4>
    ddd0:      	mov	x0, #0x1                ; =1
    ddd4:      	b	0xdd74 <_stogir.vector-arithmetic.operation?+0x80>
    ddd8:      	cmp	x0, #0x2f
    dddc:      	b.ne	0xdd68 <_stogir.vector-arithmetic.operation?+0x74>
    dde0:      	mov	x0, #0x1                ; =1
    dde4:      	b	0xdd74 <_stogir.vector-arithmetic.operation?+0x80>

000000000000dde8 <_stogir.vector-arithmetic.unary?>:
    dde8:      	sxtw	x0, w0
    ddec:      	cmp	x0, #0x1f
    ddf0:      	b.ne	0xde0c <_stogir.vector-arithmetic.unary?+0x24>
    ddf4:      	mov	x0, #0x1                ; =1
    ddf8:      	b	0xde08 <_stogir.vector-arithmetic.unary?+0x20>
    ddfc:      	cmp	x0, #0x39
    de00:      	cset	w0, eq
    de04:      	ubfx	x0, x0, #0, #8
    de08:      	ret
    de0c:      	cmp	x0, #0x20
    de10:      	b.ne	0xde1c <_stogir.vector-arithmetic.unary?+0x34>
    de14:      	mov	x0, #0x1                ; =1
    de18:      	b	0xde08 <_stogir.vector-arithmetic.unary?+0x20>
    de1c:      	cmp	x0, #0x2d
    de20:      	b.ne	0xde2c <_stogir.vector-arithmetic.unary?+0x44>
    de24:      	mov	x0, #0x1                ; =1
    de28:      	b	0xde08 <_stogir.vector-arithmetic.unary?+0x20>
    de2c:      	cmp	x0, #0x36
    de30:      	b.ne	0xde3c <_stogir.vector-arithmetic.unary?+0x54>
    de34:      	mov	x0, #0x1                ; =1
    de38:      	b	0xde08 <_stogir.vector-arithmetic.unary?+0x20>
    de3c:      	cmp	x0, #0x37
    de40:      	b.ne	0xde4c <_stogir.vector-arithmetic.unary?+0x64>
    de44:      	mov	x0, #0x1                ; =1
    de48:      	b	0xde08 <_stogir.vector-arithmetic.unary?+0x20>
    de4c:      	cmp	x0, #0x38
    de50:      	b.ne	0xddfc <_stogir.vector-arithmetic.unary?+0x14>
    de54:      	mov	x0, #0x1                ; =1
    de58:      	b	0xde08 <_stogir.vector-arithmetic.unary?+0x20>

000000000000de5c <_stogir.vector-arithmetic.operands>:
    de5c:      	sub	sp, sp, #0x80
    de60:      	str	x29, [sp]
    de64:      	str	x30, [sp, #0x8]
    de68:      	mov	x29, sp
    de6c:      	str	x19, [sp, #0x30]
    de70:      	str	x20, [sp, #0x38]
    de74:      	str	x21, [sp, #0x40]
    de78:      	str	x22, [sp, #0x48]
    de7c:      	str	x23, [sp, #0x50]
    de80:      	str	x24, [sp, #0x58]
    de84:      	str	x25, [sp, #0x60]
    de88:      	str	x26, [sp, #0x68]
    de8c:      	str	x27, [sp, #0x70]
    de90:      	str	x28, [sp, #0x78]
    de94:      	lsr	w1, w1, #0
    de98:      	lsr	w2, w2, #0
    de9c:      	mov	x19, x8
    dea0:      	mov	x20, x0
    dea4:      	mov	w0, w1
    dea8:      	mov	w21, w1
    deac:      	mov	w1, w2
    deb0:      	mov	w22, w2
    deb4:      	mov	w23, w3
    deb8:      	mov	w24, w4
    debc:      	mov	w25, w5
    dec0:      	bl	0xdec0 <_stogir.vector-arithmetic.operands+0x64>
		000000000000dec0:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.valid-type?
    dec4:      	cmp	x0, #0x0
    dec8:      	b.eq	0xdee0 <_stogir.vector-arithmetic.operands+0x84>
    decc:      	adrp	x16, 0xd000 <_stogir.vector-lanes.operands+0x2c>
		000000000000decc:  ARM64_RELOC_PAGE21	l_stogir.498
    ded0:      	ldr	x16, [x16]
		000000000000ded0:  ARM64_RELOC_PAGEOFF12	l_stogir.498
    ded4:      	orr	x0, x16, xzr
    ded8:      	movz	x1, #0x0, lsl #48
    dedc:      	b	0xdef0 <_stogir.vector-arithmetic.operands+0x94>
    dee0:      	adrp	x16, 0xd000 <_stogir.vector-lanes.operands+0x2c>
		000000000000dee0:  ARM64_RELOC_PAGE21	l_stogir.499
    dee4:      	ldr	x16, [x16]
		000000000000dee4:  ARM64_RELOC_PAGEOFF12	l_stogir.499
    dee8:      	orr	x0, x16, xzr
    deec:      	mov	x1, #0x37               ; =55
    def0:      	sxtw	x21, w21
    def4:      	sxtw	x22, w22
    def8:      	sxtw	x23, w23
    defc:      	sxtw	x24, w24
    df00:      	adrp	x16, 0xd000 <_stogir.vector-lanes.operands+0x2c>
		000000000000df00:  ARM64_RELOC_PAGE21	l_stogir.500
    df04:      	ldr	x16, [x16]
		000000000000df04:  ARM64_RELOC_PAGEOFF12	l_stogir.500
    df08:      	orr	x2, x16, xzr
    df0c:      	adrp	x16, 0xd000 <_stogir.vector-lanes.operands+0x2c>
		000000000000df0c:  ARM64_RELOC_PAGE21	l_stogir.501
    df10:      	ldr	x16, [x16]
		000000000000df10:  ARM64_RELOC_PAGEOFF12	l_stogir.501
    df14:      	orr	x3, x16, xzr
    df18:      	add	x4, x20, #0x78
    df1c:      	add	x5, x20, #0x28
    df20:      	add	x6, x20, #0x50
    df24:      	cmp	x21, #0x31
    df28:      	cset	w7, ge
    df2c:      	cmp	x21, #0x35
    df30:      	cset	w8, le
    df34:      	cmp	x21, #0x1f
    df38:      	cset	w9, eq
    df3c:      	cmp	x21, #0x20
    df40:      	cset	w10, eq
    df44:      	cmp	x21, #0x2d
    df48:      	cset	w11, eq
    df4c:      	cmp	x21, #0x36
    df50:      	cset	w12, eq
    df54:      	cmp	x21, #0x37
    df58:      	cset	w13, eq
    df5c:      	cmp	x21, #0x38
    df60:      	cset	w14, eq
    df64:      	cmp	x21, #0x39
    df68:      	cset	w15, eq
    df6c:      	mov	x26, x1
    df70:      	mov	x1, x0
    df74:      	movz	x0, #0x0, lsl #48
    df78:      	b	0xe058 <_stogir.vector-arithmetic.operands+0x1fc>
    df7c:      	movz	x2, #0x0, lsl #48
    df80:      	b	0xdf90 <_stogir.vector-arithmetic.operands+0x134>
    df84:      	movz	x2, #0x0, lsl #48
    df88:      	b	0xdf98 <_stogir.vector-arithmetic.operands+0x13c>
    df8c:      	movz	x2, #0x0, lsl #48
    df90:      	b	0xdfa8 <_stogir.vector-arithmetic.operands+0x14c>
    df94:      	movz	x2, #0x0, lsl #48
    df98:      	str	x4, [sp, #0x20]
    df9c:      	str	x5, [sp, #0x28]
    dfa0:      	b	0xdfa8 <_stogir.vector-arithmetic.operands+0x14c>
    dfa4:      	movz	x2, #0x0, lsl #48
    dfa8:      	cmp	x2, #0x0
    dfac:      	b.eq	0xdfec <_stogir.vector-arithmetic.operands+0x190>
    dfb0:      	uxtb	w16, w28
    dfb4:      	cmp	w16, wzr
    dfb8:      	b.eq	0xdfd0 <_stogir.vector-arithmetic.operands+0x174>
    dfbc:      	lsl	x2, x1, #4
    dfc0:      	ldr	x2, [x20]
    dfc4:      	add	x1, x2, x1, lsl #4
    dfc8:      	ldr	x1, [x1]
    dfcc:      	b	0xdfe0 <_stogir.vector-arithmetic.operands+0x184>
    dfd0:      	lsl	x1, x3, #4
    dfd4:      	ldr	x1, [x20, #0x28]
    dfd8:      	add	x1, x1, x3, lsl #4
    dfdc:      	ldr	x1, [x1]
    dfe0:      	mov	x2, x1
    dfe4:      	mov	x1, #0x1                ; =1
    dfe8:      	b	0xdff4 <_stogir.vector-arithmetic.operands+0x198>
    dfec:      	movz	x1, #0x0, lsl #48
    dff0:      	movz	x2, #0x0, lsl #48
    dff4:      	lsr	w1, w1, #0
    dff8:      	lsr	x16, x1, #0
    dffc:      	cmp	x16, #0x1
    e000:      	b.eq	0xe01c <_stogir.vector-arithmetic.operands+0x1c0>
    e004:      	b.lo	0xe00c <_stogir.vector-arithmetic.operands+0x1b0>
    e008:      	b	0xe020 <_stogir.vector-arithmetic.operands+0x1c4>
    e00c:      	cmp	x16, #0x0
    e010:      	b.eq	0xe018 <_stogir.vector-arithmetic.operands+0x1bc>
    e014:      	b	0xe020 <_stogir.vector-arithmetic.operands+0x1c4>
    e018:      	b	0xe024 <_stogir.vector-arithmetic.operands+0x1c8>
    e01c:      	b	0xe19c <_stogir.vector-arithmetic.operands+0x340>
    e020:      	b	0xe3e8 <_stogir.vector-arithmetic.operands+0x58c>
    e024:      	ldr	x1, [sp, #0x10]
    e028:      	mov	x2, #0x21               ; =33
    e02c:      	b	0xe038 <_stogir.vector-arithmetic.operands+0x1dc>
    e030:      	ldr	x1, [sp, #0x18]
    e034:      	mov	x2, #0x32               ; =50
    e038:      	add	x0, x0, #0x1
    e03c:      	lsr	w0, w0, #0
    e040:      	sxtw	x0, w0
    e044:      	ldr	x3, [sp, #0x18]
    e048:      	ldr	x4, [sp, #0x20]
    e04c:      	ldr	x5, [sp, #0x28]
    e050:      	mov	x26, x2
    e054:      	ldr	x2, [sp, #0x10]
    e058:      	uxtb	w16, w9
    e05c:      	cmp	w16, wzr
    e060:      	b.ne	0xe0bc <_stogir.vector-arithmetic.operands+0x260>
    e064:      	uxtb	w16, w10
    e068:      	cmp	w16, wzr
    e06c:      	b.ne	0xe0bc <_stogir.vector-arithmetic.operands+0x260>
    e070:      	uxtb	w16, w11
    e074:      	cmp	w16, wzr
    e078:      	b.ne	0xe0bc <_stogir.vector-arithmetic.operands+0x260>
    e07c:      	uxtb	w16, w12
    e080:      	cmp	w16, wzr
    e084:      	b.ne	0xe0bc <_stogir.vector-arithmetic.operands+0x260>
    e088:      	uxtb	w16, w13
    e08c:      	cmp	w16, wzr
    e090:      	b.ne	0xe0bc <_stogir.vector-arithmetic.operands+0x260>
    e094:      	uxtb	w16, w14
    e098:      	cmp	w16, wzr
    e09c:      	b.ne	0xe0bc <_stogir.vector-arithmetic.operands+0x260>
    e0a0:      	uxtb	w16, w15
    e0a4:      	cmp	w16, wzr
    e0a8:      	b.ne	0xe0bc <_stogir.vector-arithmetic.operands+0x260>
    e0ac:      	mov	x27, x26
    e0b0:      	mov	x26, x1
    e0b4:      	mov	x1, #0x2                ; =2
    e0b8:      	b	0xe0c8 <_stogir.vector-arithmetic.operands+0x26c>
    e0bc:      	mov	x27, x26
    e0c0:      	mov	x26, x1
    e0c4:      	mov	x1, #0x1                ; =1
    e0c8:      	cmp	x0, x1
    e0cc:      	b.ge	0xe1fc <_stogir.vector-arithmetic.operands+0x3a0>
    e0d0:      	cmp	x0, #0x0
    e0d4:      	b.ne	0xe0e0 <_stogir.vector-arithmetic.operands+0x284>
    e0d8:      	mov	x1, x23
    e0dc:      	b	0xe0e4 <_stogir.vector-arithmetic.operands+0x288>
    e0e0:      	mov	x1, x24
    e0e4:      	lsr	w1, w1, #0
    e0e8:      	sxtw	x1, w1
    e0ec:      	cmp	x1, #0x0
    e0f0:      	cset	w28, gt
    e0f4:      	str	x2, [sp, #0x10]
    e0f8:      	movz	x16, #0x0, lsl #48
    e0fc:      	sub	x2, x16, x1
    e100:      	str	x3, [sp, #0x18]
    e104:      	sub	x3, x2, #0x1
    e108:      	uxtb	w16, w28
    e10c:      	cmp	w16, wzr
    e110:      	b.eq	0xe150 <_stogir.vector-arithmetic.operands+0x2f4>
    e114:      	ldr	x2, [x20, #0x8]
    e118:      	cmp	x1, x2
    e11c:      	b.ge	0xdf94 <_stogir.vector-arithmetic.operands+0x138>
    e120:      	ldr	x2, [x4, #0x8]
    e124:      	cmp	x1, x2
    e128:      	b.ge	0xdf84 <_stogir.vector-arithmetic.operands+0x128>
    e12c:      	lsl	x2, x1, #2
    e130:      	ldr	x2, [x20, #0x78]
    e134:      	add	x2, x2, x1, lsl #2
    e138:      	ldr	w2, [x2]
    e13c:      	sxtw	x2, w2
    e140:      	cmp	x2, #0x0
    e144:      	cset	w2, ge
    e148:      	ubfx	x2, x2, #0, #8
    e14c:      	b	0xdf88 <_stogir.vector-arithmetic.operands+0x12c>
    e150:      	cmp	x1, #0x0
    e154:      	b.ge	0xe4e4 <_stogir.vector-arithmetic.operands+0x688>
    e158:      	str	x4, [sp, #0x20]
    e15c:      	ldr	x4, [x5, #0x8]
    e160:      	str	x5, [sp, #0x28]
    e164:      	ldr	x5, [x6, #0x8]
    e168:      	cmp	x4, x5
    e16c:      	b.ne	0xdf8c <_stogir.vector-arithmetic.operands+0x130>
    e170:      	cmp	x2, x4
    e174:      	b.gt	0xdf7c <_stogir.vector-arithmetic.operands+0x120>
    e178:      	lsl	x2, x3, #2
    e17c:      	ldr	x2, [x20, #0x50]
    e180:      	add	x2, x2, x3, lsl #2
    e184:      	ldr	w2, [x2]
    e188:      	sxtw	x2, w2
    e18c:      	cmp	x2, #0x0
    e190:      	cset	w2, gt
    e194:      	ubfx	x2, x2, #0, #8
    e198:      	b	0xdf80 <_stogir.vector-arithmetic.operands+0x124>
    e19c:      	lsr	w1, w2, #0
    e1a0:      	ubfx	x1, x1, #8, #8
    e1a4:      	cmp	x1, x22
    e1a8:      	b.eq	0xe1dc <_stogir.vector-arithmetic.operands+0x380>
    e1ac:      	cmp	x0, #0x1
    e1b0:      	b.ne	0xe030 <_stogir.vector-arithmetic.operands+0x1d4>
    e1b4:      	uxtb	w16, w7
    e1b8:      	cmp	w16, wzr
    e1bc:      	b.eq	0xe030 <_stogir.vector-arithmetic.operands+0x1d4>
    e1c0:      	uxtb	w16, w8
    e1c4:      	cmp	w16, wzr
    e1c8:      	b.eq	0xe030 <_stogir.vector-arithmetic.operands+0x1d4>
    e1cc:      	cmp	x1, #0x1
    e1d0:      	b.lt	0xe030 <_stogir.vector-arithmetic.operands+0x1d4>
    e1d4:      	cmp	x1, #0xb
    e1d8:      	b.gt	0xe030 <_stogir.vector-arithmetic.operands+0x1d4>
    e1dc:      	uxtb	w2, w2
    e1e0:      	cmp	x2, #0x48
    e1e4:      	b.eq	0xe030 <_stogir.vector-arithmetic.operands+0x1d4>
    e1e8:      	cmp	x2, #0x46
    e1ec:      	b.eq	0xe030 <_stogir.vector-arithmetic.operands+0x1d4>
    e1f0:      	mov	x1, x26
    e1f4:      	mov	x2, x27
    e1f8:      	b	0xe038 <_stogir.vector-arithmetic.operands+0x1dc>
    e1fc:      	sxtw	x25, w25
    e200:      	cmp	x25, #0x0
    e204:      	b.ne	0xe218 <_stogir.vector-arithmetic.operands+0x3bc>
    e208:      	mov	x1, x26
    e20c:      	mov	x2, x27
    e210:      	movz	x0, #0x0, lsl #48
    e214:      	b	0xe224 <_stogir.vector-arithmetic.operands+0x3c8>
    e218:      	mov	x1, x26
    e21c:      	mov	x2, x27
    e220:      	mov	x0, #0x1                ; =1
    e224:      	cmp	x0, #0x0
    e228:      	b.eq	0xe23c <_stogir.vector-arithmetic.operands+0x3e0>
    e22c:      	cmp	x21, #0x1d
    e230:      	b.ne	0xe330 <_stogir.vector-arithmetic.operands+0x4d4>
    e234:      	mov	x0, #0x1                ; =1
    e238:      	b	0xe33c <_stogir.vector-arithmetic.operands+0x4e0>
    e23c:      	mov	x0, x1
    e240:      	mov	x1, x2
    e244:      	cmp	x1, #0x0
    e248:      	b.ne	0xe260 <_stogir.vector-arithmetic.operands+0x404>
    e24c:      	and	x0, x22, #0xffffffff
    e250:      	mov	x1, x0
    e254:      	movz	x0, #0x0, lsl #48
    e258:      	movz	x2, #0x0, lsl #48
    e25c:      	b	0xe26c <_stogir.vector-arithmetic.operands+0x410>
    e260:      	mov	x2, x1
    e264:      	mov	x1, x0
    e268:      	mov	x0, #0x1                ; =1
    e26c:      	str	x0, [x19]
    e270:      	str	x1, [x19, #0x8]
    e274:      	str	x2, [x19, #0x10]
    e278:      	ldr	x19, [sp, #0x30]
    e27c:      	ldr	x20, [sp, #0x38]
    e280:      	ldr	x21, [sp, #0x40]
    e284:      	ldr	x22, [sp, #0x48]
    e288:      	ldr	x23, [sp, #0x50]
    e28c:      	ldr	x24, [sp, #0x58]
    e290:      	ldr	x25, [sp, #0x60]
    e294:      	ldr	x26, [sp, #0x68]
    e298:      	ldr	x27, [sp, #0x70]
    e29c:      	ldr	x28, [sp, #0x78]
    e2a0:      	ldr	x29, [sp]
    e2a4:      	ldr	x30, [sp, #0x8]
    e2a8:      	add	sp, sp, #0x80
    e2ac:      	ret
    e2b0:      	mov	x0, #0x1                ; =1
    e2b4:      	cmp	x0, #0x0
    e2b8:      	b.eq	0xe2d0 <_stogir.vector-arithmetic.operands+0x474>
    e2bc:      	adrp	x16, 0xe000 <_stogir.vector-arithmetic.operands+0x1a4>
		000000000000e2bc:  ARM64_RELOC_PAGE21	l_stogir.502
    e2c0:      	ldr	x16, [x16]
		000000000000e2c0:  ARM64_RELOC_PAGEOFF12	l_stogir.502
    e2c4:      	orr	x0, x16, xzr
    e2c8:      	mov	x1, #0x23               ; =35
    e2cc:      	b	0xe244 <_stogir.vector-arithmetic.operands+0x3e8>
    e2d0:      	cmp	x25, #0x0
    e2d4:      	cset	w0, gt
    e2d8:      	movz	x16, #0x0, lsl #48
    e2dc:      	sub	x3, x16, x25
    e2e0:      	sub	x4, x3, #0x1
    e2e4:      	uxtb	w16, w0
    e2e8:      	cmp	w16, wzr
    e2ec:      	b.eq	0xe39c <_stogir.vector-arithmetic.operands+0x540>
    e2f0:      	ldr	x3, [x20, #0x8]
    e2f4:      	cmp	x25, x3
    e2f8:      	b.ge	0xe3f0 <_stogir.vector-arithmetic.operands+0x594>
    e2fc:      	add	x3, x20, #0x78
    e300:      	ldr	x3, [x3, #0x8]
    e304:      	cmp	x25, x3
    e308:      	b.ge	0xe4c0 <_stogir.vector-arithmetic.operands+0x664>
    e30c:      	lsl	x3, x25, #2
    e310:      	ldr	x3, [x20, #0x78]
    e314:      	add	x3, x3, x25, lsl #2
    e318:      	ldr	w3, [x3]
    e31c:      	sxtw	x3, w3
    e320:      	cmp	x3, #0x0
    e324:      	cset	w3, ge
    e328:      	ubfx	x3, x3, #0, #8
    e32c:      	b	0xe4c4 <_stogir.vector-arithmetic.operands+0x668>
    e330:      	cmp	x21, #0x1e
    e334:      	cset	w0, eq
    e338:      	ubfx	x0, x0, #0, #8
    e33c:      	cmp	x0, #0x0
    e340:      	b.eq	0xe2b0 <_stogir.vector-arithmetic.operands+0x454>
    e344:      	movz	x0, #0x0, lsl #48
    e348:      	b	0xe2b4 <_stogir.vector-arithmetic.operands+0x458>
    e34c:      	movz	x0, #0x0, lsl #48
    e350:      	uxtb	w0, w0
    e354:      	and	x0, x0, #0x2
    e358:      	uxtb	w0, w0
    e35c:      	cmp	x0, #0x0
    e360:      	cset	w0, eq
    e364:      	uxtb	w16, w0
    e368:      	cmp	w16, wzr
    e36c:      	cset	x0, eq
    e370:      	cmp	x0, #0x0
    e374:      	b.ne	0xe4c8 <_stogir.vector-arithmetic.operands+0x66c>
    e378:      	cmp	x3, #0x65
    e37c:      	b.eq	0xe4c8 <_stogir.vector-arithmetic.operands+0x66c>
    e380:      	cmp	x3, #0x66
    e384:      	b.eq	0xe4c8 <_stogir.vector-arithmetic.operands+0x66c>
    e388:      	adrp	x16, 0xe000 <_stogir.vector-arithmetic.operands+0x1a4>
		000000000000e388:  ARM64_RELOC_PAGE21	l_stogir.503
    e38c:      	ldr	x16, [x16]
		000000000000e38c:  ARM64_RELOC_PAGEOFF12	l_stogir.503
    e390:      	orr	x0, x16, xzr
    e394:      	mov	x1, #0x34               ; =52
    e398:      	b	0xe2cc <_stogir.vector-arithmetic.operands+0x470>
    e39c:      	cmp	x25, #0x0
    e3a0:      	b.ge	0xe3f8 <_stogir.vector-arithmetic.operands+0x59c>
    e3a4:      	add	x5, x20, #0x28
    e3a8:      	add	x6, x20, #0x50
    e3ac:      	ldr	x5, [x5, #0x8]
    e3b0:      	ldr	x6, [x6, #0x8]
    e3b4:      	cmp	x5, x6
    e3b8:      	b.ne	0xe4b8 <_stogir.vector-arithmetic.operands+0x65c>
    e3bc:      	cmp	x3, x5
    e3c0:      	b.gt	0xe4d4 <_stogir.vector-arithmetic.operands+0x678>
    e3c4:      	lsl	x3, x4, #2
    e3c8:      	ldr	x3, [x20, #0x50]
    e3cc:      	add	x3, x3, x4, lsl #2
    e3d0:      	ldr	w3, [x3]
    e3d4:      	sxtw	x3, w3
    e3d8:      	cmp	x3, #0x0
    e3dc:      	cset	w3, gt
    e3e0:      	ubfx	x3, x3, #0, #8
    e3e4:      	b	0xe4d8 <_stogir.vector-arithmetic.operands+0x67c>
    e3e8:      	brk	#0
    e3ec:      	b	0xe3e8 <_stogir.vector-arithmetic.operands+0x58c>
    e3f0:      	movz	x3, #0x0, lsl #48
    e3f4:      	b	0xe3fc <_stogir.vector-arithmetic.operands+0x5a0>
    e3f8:      	movz	x3, #0x0, lsl #48
    e3fc:      	cmp	x3, #0x0
    e400:      	b.eq	0xe440 <_stogir.vector-arithmetic.operands+0x5e4>
    e404:      	uxtb	w16, w0
    e408:      	cmp	w16, wzr
    e40c:      	b.eq	0xe424 <_stogir.vector-arithmetic.operands+0x5c8>
    e410:      	lsl	x0, x25, #4
    e414:      	ldr	x0, [x20]
    e418:      	add	x0, x0, x25, lsl #4
    e41c:      	ldr	x0, [x0]
    e420:      	b	0xe434 <_stogir.vector-arithmetic.operands+0x5d8>
    e424:      	lsl	x0, x4, #4
    e428:      	ldr	x0, [x20, #0x28]
    e42c:      	add	x0, x0, x4, lsl #4
    e430:      	ldr	x0, [x0]
    e434:      	mov	x3, x0
    e438:      	mov	x0, #0x1                ; =1
    e43c:      	b	0xe448 <_stogir.vector-arithmetic.operands+0x5ec>
    e440:      	movz	x0, #0x0, lsl #48
    e444:      	movz	x3, #0x0, lsl #48
    e448:      	lsr	w0, w0, #0
    e44c:      	lsr	x16, x0, #0
    e450:      	cmp	x16, #0x1
    e454:      	b.eq	0xe470 <_stogir.vector-arithmetic.operands+0x614>
    e458:      	b.lo	0xe460 <_stogir.vector-arithmetic.operands+0x604>
    e45c:      	b	0xe474 <_stogir.vector-arithmetic.operands+0x618>
    e460:      	cmp	x16, #0x0
    e464:      	b.eq	0xe46c <_stogir.vector-arithmetic.operands+0x610>
    e468:      	b	0xe474 <_stogir.vector-arithmetic.operands+0x618>
    e46c:      	b	0xe478 <_stogir.vector-arithmetic.operands+0x61c>
    e470:      	b	0xe48c <_stogir.vector-arithmetic.operands+0x630>
    e474:      	b	0xe4dc <_stogir.vector-arithmetic.operands+0x680>
    e478:      	adrp	x16, 0xe000 <_stogir.vector-arithmetic.operands+0x1a4>
		000000000000e478:  ARM64_RELOC_PAGE21	l_stogir.504
    e47c:      	ldr	x16, [x16]
		000000000000e47c:  ARM64_RELOC_PAGEOFF12	l_stogir.504
    e480:      	orr	x0, x16, xzr
    e484:      	mov	x1, #0x1d               ; =29
    e488:      	b	0xe398 <_stogir.vector-arithmetic.operands+0x53c>
    e48c:      	cmp	x25, #0x0
    e490:      	b.le	0xe388 <_stogir.vector-arithmetic.operands+0x52c>
    e494:      	uxtb	w3, w3
    e498:      	cmp	x3, #0x83
    e49c:      	b.ge	0xe34c <_stogir.vector-arithmetic.operands+0x4f0>
    e4a0:      	adrp	x16, 0xe000 <_stogir.vector-arithmetic.operands+0x1a4>
		000000000000e4a0:  ARM64_RELOC_PAGE21	l_stogir.505
    e4a4:      	ldr	x16, [x16]
		000000000000e4a4:  ARM64_RELOC_PAGEOFF12	l_stogir.505
    e4a8:      	orr	x0, x16, xzr
    e4ac:      	add	x0, x3, x0
    e4b0:      	ldrb	w0, [x0]
    e4b4:      	b	0xe350 <_stogir.vector-arithmetic.operands+0x4f4>
    e4b8:      	movz	x3, #0x0, lsl #48
    e4bc:      	b	0xe3fc <_stogir.vector-arithmetic.operands+0x5a0>
    e4c0:      	movz	x3, #0x0, lsl #48
    e4c4:      	b	0xe3f4 <_stogir.vector-arithmetic.operands+0x598>
    e4c8:      	mov	x0, x1
    e4cc:      	mov	x1, x2
    e4d0:      	b	0xe398 <_stogir.vector-arithmetic.operands+0x53c>
    e4d4:      	movz	x3, #0x0, lsl #48
    e4d8:      	b	0xe4bc <_stogir.vector-arithmetic.operands+0x660>
    e4dc:      	brk	#0
    e4e0:      	b	0xe4dc <_stogir.vector-arithmetic.operands+0x680>
    e4e4:      	str	x4, [sp, #0x20]
    e4e8:      	str	x5, [sp, #0x28]
    e4ec:      	b	0xdfa4 <_stogir.vector-arithmetic.operands+0x148>

000000000000e4f0 <_stogir.types.base-type>:
    e4f0:      	sxtw	x0, w0
    e4f4:      	and	x1, x0, #0xf
    e4f8:      	lsr	w1, w1, #0
    e4fc:      	sxtw	x1, w1
    e500:      	cmp	x0, #0x0
    e504:      	b.lt	0xe518 <_stogir.types.base-type+0x28>
    e508:      	cmp	x0, #0xd
    e50c:      	b.gt	0xe518 <_stogir.types.base-type+0x28>
    e510:      	mov	x0, x1
    e514:      	b	0xe53c <_stogir.types.base-type+0x4c>
    e518:      	cmp	x0, #0xf
    e51c:      	b.le	0xe538 <_stogir.types.base-type+0x48>
    e520:      	cmp	x0, #0x80
    e524:      	b.ge	0xe538 <_stogir.types.base-type+0x48>
    e528:      	cmp	x1, #0x1
    e52c:      	b.lt	0xe538 <_stogir.types.base-type+0x48>
    e530:      	cmp	x1, #0xd
    e534:      	b.le	0xe510 <_stogir.types.base-type+0x20>
    e538:      	movn	x0, #0x0, lsl #48
    e53c:      	ret

000000000000e540 <_stogir.types.lanes>:
    e540:      	sxtw	x0, w0
    e544:      	cmp	x0, #0xf
    e548:      	b.le	0xe598 <_stogir.types.lanes+0x58>
    e54c:      	cmp	x0, #0x80
    e550:      	b.ge	0xe598 <_stogir.types.lanes+0x58>
    e554:      	and	x1, x0, #0xf
    e558:      	lsr	w1, w1, #0
    e55c:      	sxtw	x1, w1
    e560:      	cmp	x1, #0x1
    e564:      	b.lt	0xe598 <_stogir.types.lanes+0x58>
    e568:      	cmp	x1, #0xd
    e56c:      	b.gt	0xe598 <_stogir.types.lanes+0x58>
    e570:      	ubfx	x0, x0, #4, #32
    e574:      	sxtw	x0, w0
    e578:      	sub	x0, x0, #0x1
    e57c:      	lsr	w0, w0, #0
    e580:      	sxtw	x0, w0
    e584:      	mov	x16, #0x1               ; =1
    e588:      	lsl	x0, x16, x0
    e58c:      	lsr	w0, w0, #0
    e590:      	sxtw	x0, w0
    e594:      	b	0xe5c4 <_stogir.types.lanes+0x84>
    e598:      	cmp	x0, #0x0
    e59c:      	b.lt	0xe5c0 <_stogir.types.lanes+0x80>
    e5a0:      	cmp	x0, #0xd
    e5a4:      	b.gt	0xe5c0 <_stogir.types.lanes+0x80>
    e5a8:      	cmp	x0, #0x0
    e5ac:      	cset	w0, eq
    e5b0:      	uxtb	w16, w0
    e5b4:      	cmp	w16, wzr
    e5b8:      	cset	x0, eq
    e5bc:      	b	0xe5c4 <_stogir.types.lanes+0x84>
    e5c0:      	movn	x0, #0x0, lsl #48
    e5c4:      	ret

000000000000e5c8 <_coil.core.Get$slice$get__u8>:
    e5c8:      	lsr	x1, x2, #0
    e5cc:      	add	x0, x0, x2
    e5d0:      	ldrb	w0, [x0]
    e5d4:      	ret

000000000000e5d8 <_stogir.checked.valid-type?>:
    e5d8:      	sxtw	x0, w0
    e5dc:      	cmp	x0, #0x1
    e5e0:      	b.lt	0xe604 <_stogir.checked.valid-type?+0x2c>
    e5e4:      	cmp	x0, #0xb
    e5e8:      	b.gt	0xe604 <_stogir.checked.valid-type?+0x2c>
    e5ec:      	cmp	x0, #0x1
    e5f0:      	cset	w0, eq
    e5f4:      	uxtb	w16, w0
    e5f8:      	cmp	w16, wzr
    e5fc:      	cset	x0, eq
    e600:      	b	0xe608 <_stogir.checked.valid-type?+0x30>
    e604:      	movz	x0, #0x0, lsl #48
    e608:      	ret

000000000000e60c <_coil.core.Iterable$slice$iter__i32>:
    e60c:      	str	x0, [x8]
    e610:      	str	x1, [x8, #0x8]
    e614:      	movz	x17, #0x0, lsl #48
    e618:      	str	x17, [x8, #0x10]
    e61c:      	ret

000000000000e620 <_coil.core.Iterator$coil.slice.SliceIter$next__i32>:
    e620:      	sub	sp, sp, #0x10
    e624:      	mov	x1, sp
    e628:      	ldr	x2, [x0, #0x10]
    e62c:      	ldr	x3, [x0]
    e630:      	ldr	x4, [x0, #0x8]
    e634:      	cmp	x2, x4
    e638:      	b.ge	0xe664 <_coil.core.Iterator$coil.slice.SliceIter$next__i32+0x44>
    e63c:      	add	x4, x2, #0x1
    e640:      	lsl	x5, x2, #2
    e644:      	add	x2, x3, x2, lsl #2
    e648:      	str	x4, [x0, #0x10]
    e64c:      	ldr	w0, [x2]
    e650:      	sxtw	x0, w0
    e654:      	and	x0, x0, #0xffffffff
    e658:      	mov	x2, x0
    e65c:      	mov	x0, #0x1                ; =1
    e660:      	b	0xe66c <_coil.core.Iterator$coil.slice.SliceIter$next__i32+0x4c>
    e664:      	movz	x0, #0x0, lsl #48
    e668:      	movz	x2, #0x0, lsl #48
    e66c:      	str	x0, [x1]
    e670:      	str	x2, [x1, #0x8]
    e674:      	ldr	x0, [sp]
    e678:      	ldr	x1, [sp, #0x8]
    e67c:      	add	sp, sp, #0x10
    e680:      	ret

000000000000e684 <_stogir.terminal.previous-input>:
    e684:      	sxtw	x1, w1
    e688:      	cmp	x1, #0x0
    e68c:      	b.ne	0xe6ac <_stogir.terminal.previous-input+0x28>
    e690:      	movz	x0, #0x0, lsl #48
    e694:      	movz	x1, #0x0, lsl #48
    e698:      	movz	x2, #0x0, lsl #48
    e69c:      	str	x0, [x8]
    e6a0:      	str	x1, [x8, #0x8]
    e6a4:      	str	x2, [x8, #0x10]
    e6a8:      	ret
    e6ac:      	cmp	x1, #0x0
    e6b0:      	cset	w2, gt
    e6b4:      	movz	x16, #0x0, lsl #48
    e6b8:      	sub	x3, x16, x1
    e6bc:      	sub	x4, x3, #0x1
    e6c0:      	uxtb	w16, w2
    e6c4:      	cmp	w16, wzr
    e6c8:      	b.eq	0xe728 <_stogir.terminal.previous-input+0xa4>
    e6cc:      	ldr	x3, [x0, #0x8]
    e6d0:      	cmp	x1, x3
    e6d4:      	b.ge	0xe774 <_stogir.terminal.previous-input+0xf0>
    e6d8:      	add	x3, x0, #0x78
    e6dc:      	ldr	x3, [x3, #0x8]
    e6e0:      	cmp	x1, x3
    e6e4:      	b.ge	0xe84c <_stogir.terminal.previous-input+0x1c8>
    e6e8:      	lsl	x3, x1, #2
    e6ec:      	ldr	x3, [x0, #0x78]
    e6f0:      	add	x3, x3, x1, lsl #2
    e6f4:      	ldr	w3, [x3]
    e6f8:      	sxtw	x3, w3
    e6fc:      	cmp	x3, #0x0
    e700:      	cset	w3, ge
    e704:      	ubfx	x3, x3, #0, #8
    e708:      	b	0xe850 <_stogir.terminal.previous-input+0x1cc>
    e70c:      	adrp	x16, 0xe000 <_stogir.vector-arithmetic.operands+0x1a4>
		000000000000e70c:  ARM64_RELOC_PAGE21	l_stogir.506
    e710:      	ldr	x16, [x16]
		000000000000e710:  ARM64_RELOC_PAGEOFF12	l_stogir.506
    e714:      	orr	x0, x16, xzr
    e718:      	mov	x1, x0
    e71c:      	mov	x0, #0x1                ; =1
    e720:      	mov	x2, #0x2e               ; =46
    e724:      	b	0xe69c <_stogir.terminal.previous-input+0x18>
    e728:      	cmp	x1, #0x0
    e72c:      	b.ge	0xe77c <_stogir.terminal.previous-input+0xf8>
    e730:      	add	x5, x0, #0x28
    e734:      	add	x6, x0, #0x50
    e738:      	ldr	x5, [x5, #0x8]
    e73c:      	ldr	x6, [x6, #0x8]
    e740:      	cmp	x5, x6
    e744:      	b.ne	0xe844 <_stogir.terminal.previous-input+0x1c0>
    e748:      	cmp	x3, x5
    e74c:      	b.gt	0xe854 <_stogir.terminal.previous-input+0x1d0>
    e750:      	lsl	x3, x4, #2
    e754:      	ldr	x3, [x0, #0x50]
    e758:      	add	x3, x3, x4, lsl #2
    e75c:      	ldr	w3, [x3]
    e760:      	sxtw	x3, w3
    e764:      	cmp	x3, #0x0
    e768:      	cset	w3, gt
    e76c:      	ubfx	x3, x3, #0, #8
    e770:      	b	0xe858 <_stogir.terminal.previous-input+0x1d4>
    e774:      	movz	x3, #0x0, lsl #48
    e778:      	b	0xe780 <_stogir.terminal.previous-input+0xfc>
    e77c:      	movz	x3, #0x0, lsl #48
    e780:      	cmp	x3, #0x0
    e784:      	b.eq	0xe7c4 <_stogir.terminal.previous-input+0x140>
    e788:      	uxtb	w16, w2
    e78c:      	cmp	w16, wzr
    e790:      	b.eq	0xe7a8 <_stogir.terminal.previous-input+0x124>
    e794:      	lsl	x2, x1, #4
    e798:      	ldr	x0, [x0]
    e79c:      	add	x0, x0, x1, lsl #4
    e7a0:      	ldr	x0, [x0]
    e7a4:      	b	0xe7b8 <_stogir.terminal.previous-input+0x134>
    e7a8:      	lsl	x2, x4, #4
    e7ac:      	ldr	x0, [x0, #0x28]
    e7b0:      	add	x0, x0, x4, lsl #4
    e7b4:      	ldr	x0, [x0]
    e7b8:      	mov	x2, x0
    e7bc:      	mov	x0, #0x1                ; =1
    e7c0:      	b	0xe7cc <_stogir.terminal.previous-input+0x148>
    e7c4:      	movz	x0, #0x0, lsl #48
    e7c8:      	movz	x2, #0x0, lsl #48
    e7cc:      	lsr	w0, w0, #0
    e7d0:      	lsr	x16, x0, #0
    e7d4:      	cmp	x16, #0x1
    e7d8:      	b.eq	0xe7f4 <_stogir.terminal.previous-input+0x170>
    e7dc:      	b.lo	0xe7e4 <_stogir.terminal.previous-input+0x160>
    e7e0:      	b	0xe7f8 <_stogir.terminal.previous-input+0x174>
    e7e4:      	cmp	x16, #0x0
    e7e8:      	b.eq	0xe7f0 <_stogir.terminal.previous-input+0x16c>
    e7ec:      	b	0xe7f8 <_stogir.terminal.previous-input+0x174>
    e7f0:      	b	0xe7fc <_stogir.terminal.previous-input+0x178>
    e7f4:      	b	0xe818 <_stogir.terminal.previous-input+0x194>
    e7f8:      	b	0xe89c <_stogir.terminal.previous-input+0x218>
    e7fc:      	adrp	x16, 0xe000 <_stogir.vector-arithmetic.operands+0x1a4>
		000000000000e7fc:  ARM64_RELOC_PAGE21	l_stogir.507
    e800:      	ldr	x16, [x16]
		000000000000e800:  ARM64_RELOC_PAGEOFF12	l_stogir.507
    e804:      	orr	x0, x16, xzr
    e808:      	mov	x1, x0
    e80c:      	mov	x0, #0x1                ; =1
    e810:      	mov	x2, #0x1d               ; =29
    e814:      	b	0xe724 <_stogir.terminal.previous-input+0xa0>
    e818:      	cmp	x1, #0x0
    e81c:      	b.le	0xe70c <_stogir.terminal.previous-input+0x88>
    e820:      	uxtb	w2, w2
    e824:      	cmp	x2, #0x83
    e828:      	b.ge	0xe85c <_stogir.terminal.previous-input+0x1d8>
    e82c:      	adrp	x16, 0xe000 <_stogir.vector-arithmetic.operands+0x1a4>
		000000000000e82c:  ARM64_RELOC_PAGE21	l_stogir.508
    e830:      	ldr	x16, [x16]
		000000000000e830:  ARM64_RELOC_PAGEOFF12	l_stogir.508
    e834:      	orr	x0, x16, xzr
    e838:      	add	x0, x2, x0
    e83c:      	ldrb	w0, [x0]
    e840:      	b	0xe860 <_stogir.terminal.previous-input+0x1dc>
    e844:      	movz	x3, #0x0, lsl #48
    e848:      	b	0xe780 <_stogir.terminal.previous-input+0xfc>
    e84c:      	movz	x3, #0x0, lsl #48
    e850:      	b	0xe778 <_stogir.terminal.previous-input+0xf4>
    e854:      	movz	x3, #0x0, lsl #48
    e858:      	b	0xe848 <_stogir.terminal.previous-input+0x1c4>
    e85c:      	movz	x0, #0x0, lsl #48
    e860:      	uxtb	w0, w0
    e864:      	and	x0, x0, #0x8
    e868:      	uxtb	w0, w0
    e86c:      	cmp	x0, #0x0
    e870:      	cset	w0, eq
    e874:      	uxtb	w16, w0
    e878:      	cmp	w16, wzr
    e87c:      	cset	x0, eq
    e880:      	cmp	x0, #0x0
    e884:      	b.eq	0xe70c <_stogir.terminal.previous-input+0x88>
    e888:      	and	x0, x1, #0xffffffff
    e88c:      	mov	x1, x0
    e890:      	movz	x0, #0x0, lsl #48
    e894:      	movz	x2, #0x0, lsl #48
    e898:      	b	0xe724 <_stogir.terminal.previous-input+0xa0>
    e89c:      	brk	#0
    e8a0:      	b	0xe89c <_stogir.terminal.previous-input+0x218>

000000000000e8a4 <_stogir.switch.selector-type>:
    e8a4:      	sxtw	x1, w1
    e8a8:      	cmp	x1, #0x0
    e8ac:      	cset	w2, gt
    e8b0:      	movz	x16, #0x0, lsl #48
    e8b4:      	sub	x3, x16, x1
    e8b8:      	sub	x4, x3, #0x1
    e8bc:      	uxtb	w16, w2
    e8c0:      	cmp	w16, wzr
    e8c4:      	b.eq	0xe908 <_stogir.switch.selector-type+0x64>
    e8c8:      	ldr	x3, [x0, #0x8]
    e8cc:      	cmp	x1, x3
    e8d0:      	b.ge	0xe95c <_stogir.switch.selector-type+0xb8>
    e8d4:      	add	x3, x0, #0x78
    e8d8:      	ldr	x3, [x3, #0x8]
    e8dc:      	cmp	x1, x3
    e8e0:      	b.ge	0xea60 <_stogir.switch.selector-type+0x1bc>
    e8e4:      	lsl	x3, x1, #2
    e8e8:      	ldr	x3, [x0, #0x78]
    e8ec:      	add	x3, x3, x1, lsl #2
    e8f0:      	ldr	w3, [x3]
    e8f4:      	sxtw	x3, w3
    e8f8:      	cmp	x3, #0x0
    e8fc:      	cset	w3, ge
    e900:      	ubfx	x3, x3, #0, #8
    e904:      	b	0xea64 <_stogir.switch.selector-type+0x1c0>
    e908:      	cmp	x1, #0x0
    e90c:      	b.ge	0xe964 <_stogir.switch.selector-type+0xc0>
    e910:      	add	x5, x0, #0x28
    e914:      	add	x6, x0, #0x50
    e918:      	ldr	x5, [x5, #0x8]
    e91c:      	ldr	x6, [x6, #0x8]
    e920:      	cmp	x5, x6
    e924:      	b.ne	0xe954 <_stogir.switch.selector-type+0xb0>
    e928:      	cmp	x3, x5
    e92c:      	b.gt	0xea68 <_stogir.switch.selector-type+0x1c4>
    e930:      	lsl	x3, x4, #2
    e934:      	ldr	x3, [x0, #0x50]
    e938:      	add	x3, x3, x4, lsl #2
    e93c:      	ldr	w3, [x3]
    e940:      	sxtw	x3, w3
    e944:      	cmp	x3, #0x0
    e948:      	cset	w3, gt
    e94c:      	ubfx	x3, x3, #0, #8
    e950:      	b	0xea6c <_stogir.switch.selector-type+0x1c8>
    e954:      	movz	x3, #0x0, lsl #48
    e958:      	b	0xe968 <_stogir.switch.selector-type+0xc4>
    e95c:      	movz	x3, #0x0, lsl #48
    e960:      	b	0xe968 <_stogir.switch.selector-type+0xc4>
    e964:      	movz	x3, #0x0, lsl #48
    e968:      	cmp	x3, #0x0
    e96c:      	b.eq	0xe9ac <_stogir.switch.selector-type+0x108>
    e970:      	uxtb	w16, w2
    e974:      	cmp	w16, wzr
    e978:      	b.eq	0xe990 <_stogir.switch.selector-type+0xec>
    e97c:      	lsl	x2, x1, #4
    e980:      	ldr	x0, [x0]
    e984:      	add	x0, x0, x1, lsl #4
    e988:      	ldr	x0, [x0]
    e98c:      	b	0xe9a0 <_stogir.switch.selector-type+0xfc>
    e990:      	lsl	x1, x4, #4
    e994:      	ldr	x0, [x0, #0x28]
    e998:      	add	x0, x0, x4, lsl #4
    e99c:      	ldr	x0, [x0]
    e9a0:      	mov	x1, x0
    e9a4:      	mov	x0, #0x1                ; =1
    e9a8:      	b	0xe9b4 <_stogir.switch.selector-type+0x110>
    e9ac:      	movz	x0, #0x0, lsl #48
    e9b0:      	movz	x1, #0x0, lsl #48
    e9b4:      	lsr	w0, w0, #0
    e9b8:      	lsr	x16, x0, #0
    e9bc:      	cmp	x16, #0x1
    e9c0:      	b.eq	0xe9dc <_stogir.switch.selector-type+0x138>
    e9c4:      	b.lo	0xe9cc <_stogir.switch.selector-type+0x128>
    e9c8:      	b	0xe9e0 <_stogir.switch.selector-type+0x13c>
    e9cc:      	cmp	x16, #0x0
    e9d0:      	b.eq	0xe9d8 <_stogir.switch.selector-type+0x134>
    e9d4:      	b	0xe9e0 <_stogir.switch.selector-type+0x13c>
    e9d8:      	b	0xe9e4 <_stogir.switch.selector-type+0x140>
    e9dc:      	b	0xea28 <_stogir.switch.selector-type+0x184>
    e9e0:      	b	0xea70 <_stogir.switch.selector-type+0x1cc>
    e9e4:      	adrp	x16, 0xe000 <_stogir.vector-arithmetic.operands+0x1a4>
		000000000000e9e4:  ARM64_RELOC_PAGE21	l_stogir.509
    e9e8:      	ldr	x16, [x16]
		000000000000e9e8:  ARM64_RELOC_PAGEOFF12	l_stogir.509
    e9ec:      	orr	x0, x16, xzr
    e9f0:      	mov	x1, x0
    e9f4:      	mov	x0, #0x1                ; =1
    e9f8:      	mov	x2, #0x17               ; =23
    e9fc:      	b	0xea18 <_stogir.switch.selector-type+0x174>
    ea00:      	adrp	x16, 0xe000 <_stogir.vector-arithmetic.operands+0x1a4>
		000000000000ea00:  ARM64_RELOC_PAGE21	l_stogir.510
    ea04:      	ldr	x16, [x16]
		000000000000ea04:  ARM64_RELOC_PAGEOFF12	l_stogir.510
    ea08:      	orr	x0, x16, xzr
    ea0c:      	mov	x1, x0
    ea10:      	mov	x0, #0x1                ; =1
    ea14:      	mov	x2, #0x20               ; =32
    ea18:      	str	x0, [x8]
    ea1c:      	str	x1, [x8, #0x8]
    ea20:      	str	x2, [x8, #0x10]
    ea24:      	ret
    ea28:      	lsr	w0, w1, #0
    ea2c:      	ubfx	x0, x0, #8, #8
    ea30:      	cmp	x0, #0x1
    ea34:      	b.lt	0xea00 <_stogir.switch.selector-type+0x15c>
    ea38:      	cmp	x0, #0xb
    ea3c:      	b.gt	0xea00 <_stogir.switch.selector-type+0x15c>
    ea40:      	uxtb	w1, w1
    ea44:      	cmp	x1, #0x48
    ea48:      	b.eq	0xea00 <_stogir.switch.selector-type+0x15c>
    ea4c:      	and	x0, x0, #0xffffffff
    ea50:      	mov	x1, x0
    ea54:      	movz	x0, #0x0, lsl #48
    ea58:      	movz	x2, #0x0, lsl #48
    ea5c:      	b	0xea18 <_stogir.switch.selector-type+0x174>
    ea60:      	movz	x3, #0x0, lsl #48
    ea64:      	b	0xe960 <_stogir.switch.selector-type+0xbc>
    ea68:      	movz	x3, #0x0, lsl #48
    ea6c:      	b	0xe958 <_stogir.switch.selector-type+0xb4>
    ea70:      	brk	#0
    ea74:      	b	0xea70 <_stogir.switch.selector-type+0x1cc>

000000000000ea78 <_stogir.switch.key>:
    ea78:      	sub	sp, sp, #0x30
    ea7c:      	str	x19, [sp]
    ea80:      	str	x20, [sp, #0x8]
    ea84:      	str	x21, [sp, #0x10]
    ea88:      	str	x22, [sp, #0x18]
    ea8c:      	str	x23, [sp, #0x20]
    ea90:      	sxtw	x2, w2
    ea94:      	cmp	x2, #0x1
    ea98:      	b.lt	0xeb14 <_stogir.switch.key+0x9c>
    ea9c:      	cmp	x2, #0xb
    eaa0:      	cset	w3, le
    eaa4:      	uxtb	w16, w3
    eaa8:      	cmp	w16, wzr
    eaac:      	b.eq	0xeb14 <_stogir.switch.key+0x9c>
    eab0:      	sxtw	x1, w1
    eab4:      	cmp	x1, #0x0
    eab8:      	cset	w4, gt
    eabc:      	movz	x16, #0x0, lsl #48
    eac0:      	sub	x5, x16, x1
    eac4:      	sub	x6, x5, #0x1
    eac8:      	uxtb	w16, w4
    eacc:      	cmp	w16, wzr
    ead0:      	b.eq	0xeb98 <_stogir.switch.key+0x120>
    ead4:      	ldr	x5, [x0, #0x8]
    ead8:      	cmp	x1, x5
    eadc:      	b.ge	0xebe4 <_stogir.switch.key+0x16c>
    eae0:      	add	x5, x0, #0x78
    eae4:      	ldr	x5, [x5, #0x8]
    eae8:      	cmp	x1, x5
    eaec:      	b.ge	0xed50 <_stogir.switch.key+0x2d8>
    eaf0:      	lsl	x5, x1, #2
    eaf4:      	ldr	x5, [x0, #0x78]
    eaf8:      	add	x5, x5, x1, lsl #2
    eafc:      	ldr	w5, [x5]
    eb00:      	sxtw	x5, w5
    eb04:      	cmp	x5, #0x0
    eb08:      	cset	w5, ge
    eb0c:      	ubfx	x5, x5, #0, #8
    eb10:      	b	0xed54 <_stogir.switch.key+0x2dc>
    eb14:      	adrp	x16, 0xe000 <_stogir.vector-arithmetic.operands+0x1a4>
		000000000000eb14:  ARM64_RELOC_PAGE21	l_stogir.511
    eb18:      	ldr	x16, [x16]
		000000000000eb18:  ARM64_RELOC_PAGEOFF12	l_stogir.511
    eb1c:      	orr	x0, x16, xzr
    eb20:      	mov	x1, x0
    eb24:      	mov	x0, #0x1                ; =1
    eb28:      	mov	x2, #0x24               ; =36
    eb2c:      	str	x0, [x8]
    eb30:      	str	x1, [x8, #0x8]
    eb34:      	str	x2, [x8, #0x10]
    eb38:      	ldr	x19, [sp]
    eb3c:      	ldr	x20, [sp, #0x8]
    eb40:      	ldr	x21, [sp, #0x10]
    eb44:      	ldr	x22, [sp, #0x18]
    eb48:      	ldr	x23, [sp, #0x20]
    eb4c:      	add	sp, sp, #0x30
    eb50:      	ret
    eb54:      	mov	x23, #0x1               ; =1
    eb58:      	cmp	x1, #0x0
    eb5c:      	b.ge	0xeb7c <_stogir.switch.key+0x104>
    eb60:      	lsr	w1, w4, #0
    eb64:      	uxtb	w4, w4
    eb68:      	ubfx	x1, x1, #8, #8
    eb6c:      	cmp	x4, x1
    eb70:      	b.eq	0xedf8 <_stogir.switch.key+0x380>
    eb74:      	cmp	x4, #0x49
    eb78:      	b.eq	0xedf8 <_stogir.switch.key+0x380>
    eb7c:      	adrp	x16, 0xe000 <_stogir.vector-arithmetic.operands+0x1a4>
		000000000000eb7c:  ARM64_RELOC_PAGE21	l_stogir.512
    eb80:      	ldr	x16, [x16]
		000000000000eb80:  ARM64_RELOC_PAGEOFF12	l_stogir.512
    eb84:      	orr	x0, x16, xzr
    eb88:      	mov	x1, x0
    eb8c:      	mov	x0, #0x1                ; =1
    eb90:      	mov	x2, #0x30               ; =48
    eb94:      	b	0xeb2c <_stogir.switch.key+0xb4>
    eb98:      	cmp	x1, #0x0
    eb9c:      	b.ge	0xebec <_stogir.switch.key+0x174>
    eba0:      	add	x7, x0, #0x28
    eba4:      	add	x9, x0, #0x50
    eba8:      	ldr	x7, [x7, #0x8]
    ebac:      	ldr	x9, [x9, #0x8]
    ebb0:      	cmp	x7, x9
    ebb4:      	b.ne	0xed48 <_stogir.switch.key+0x2d0>
    ebb8:      	cmp	x5, x7
    ebbc:      	b.gt	0xedf0 <_stogir.switch.key+0x378>
    ebc0:      	lsl	x5, x6, #2
    ebc4:      	ldr	x5, [x0, #0x50]
    ebc8:      	add	x5, x5, x6, lsl #2
    ebcc:      	ldr	w5, [x5]
    ebd0:      	sxtw	x5, w5
    ebd4:      	cmp	x5, #0x0
    ebd8:      	cset	w5, gt
    ebdc:      	ubfx	x5, x5, #0, #8
    ebe0:      	b	0xedf4 <_stogir.switch.key+0x37c>
    ebe4:      	movz	x5, #0x0, lsl #48
    ebe8:      	b	0xebf0 <_stogir.switch.key+0x178>
    ebec:      	movz	x5, #0x0, lsl #48
    ebf0:      	cmp	x5, #0x0
    ebf4:      	b.eq	0xec58 <_stogir.switch.key+0x1e0>
    ebf8:      	uxtb	w16, w4
    ebfc:      	cmp	w16, wzr
    ec00:      	b.eq	0xec28 <_stogir.switch.key+0x1b0>
    ec04:      	lsl	x4, x1, #4
    ec08:      	ldr	x0, [x0]
    ec0c:      	add	x0, x0, x1, lsl #4
    ec10:      	ldr	x4, [x0]
    ec14:      	ldr	x0, [x0, #0x8]
    ec18:      	fmov	d31, x0
    ec1c:      	mov	x0, x4
    ec20:      	fmov	x4, d31
    ec24:      	b	0xec48 <_stogir.switch.key+0x1d0>
    ec28:      	lsl	x4, x6, #4
    ec2c:      	ldr	x0, [x0, #0x28]
    ec30:      	add	x0, x0, x6, lsl #4
    ec34:      	ldr	x4, [x0]
    ec38:      	ldr	x0, [x0, #0x8]
    ec3c:      	fmov	d31, x0
    ec40:      	mov	x0, x4
    ec44:      	fmov	x4, d31
    ec48:      	mov	x5, x4
    ec4c:      	mov	x4, x0
    ec50:      	mov	x0, #0x1                ; =1
    ec54:      	b	0xec64 <_stogir.switch.key+0x1ec>
    ec58:      	movz	x0, #0x0, lsl #48
    ec5c:      	movz	x4, #0x0, lsl #48
    ec60:      	movz	x5, #0x0, lsl #48
    ec64:      	lsr	w0, w0, #0
    ec68:      	lsr	x16, x0, #0
    ec6c:      	cmp	x16, #0x1
    ec70:      	b.eq	0xec8c <_stogir.switch.key+0x214>
    ec74:      	b.lo	0xec7c <_stogir.switch.key+0x204>
    ec78:      	b	0xec90 <_stogir.switch.key+0x218>
    ec7c:      	cmp	x16, #0x0
    ec80:      	b.eq	0xec88 <_stogir.switch.key+0x210>
    ec84:      	b	0xec90 <_stogir.switch.key+0x218>
    ec88:      	b	0xec94 <_stogir.switch.key+0x21c>
    ec8c:      	b	0xecb0 <_stogir.switch.key+0x238>
    ec90:      	b	0xee9c <_stogir.switch.key+0x424>
    ec94:      	adrp	x16, 0xe000 <_stogir.vector-arithmetic.operands+0x1a4>
		000000000000ec94:  ARM64_RELOC_PAGE21	l_stogir.513
    ec98:      	ldr	x16, [x16]
		000000000000ec98:  ARM64_RELOC_PAGEOFF12	l_stogir.513
    ec9c:      	orr	x0, x16, xzr
    eca0:      	mov	x1, x0
    eca4:      	mov	x0, #0x1                ; =1
    eca8:      	mov	x2, #0x1c               ; =28
    ecac:      	b	0xeb94 <_stogir.switch.key+0x11c>
    ecb0:      	cmp	x2, #0x1
    ecb4:      	cset	w0, eq
    ecb8:      	cmp	x2, #0x0
    ecbc:      	cset	w6, eq
    ecc0:      	cmp	x2, #0x2
    ecc4:      	cset	w7, eq
    ecc8:      	cmp	x2, #0x7
    eccc:      	cset	w9, eq
    ecd0:      	cmp	x2, #0x8
    ecd4:      	cset	w10, eq
    ecd8:      	cmp	x2, #0x3
    ecdc:      	cset	w11, eq
    ece0:      	cmp	x2, #0x9
    ece4:      	cset	w12, eq
    ece8:      	cmp	x2, #0x4
    ecec:      	cset	w13, eq
    ecf0:      	cmp	x2, #0xa
    ecf4:      	cset	w14, eq
    ecf8:      	cmp	x2, #0xd
    ecfc:      	cset	w15, eq
    ed00:      	cmp	x2, #0x5
    ed04:      	cset	w19, eq
    ed08:      	cmp	x2, #0xb
    ed0c:      	cset	w20, eq
    ed10:      	cmp	x2, #0xc
    ed14:      	cset	w21, eq
    ed18:      	cmp	x2, #0x6
    ed1c:      	cset	w22, eq
    ed20:      	uxtb	w16, w22
    ed24:      	cmp	w16, wzr
    ed28:      	mov	x16, #0x8               ; =8
    ed2c:      	movn	x17, #0x0, lsl #48
    ed30:      	csel	x22, x16, x17, ne
    ed34:      	uxtb	w16, w6
    ed38:      	cmp	w16, wzr
    ed3c:      	b.eq	0xed58 <_stogir.switch.key+0x2e0>
    ed40:      	movz	x23, #0x0, lsl #48
    ed44:      	b	0xeb58 <_stogir.switch.key+0xe0>
    ed48:      	movz	x5, #0x0, lsl #48
    ed4c:      	b	0xebf0 <_stogir.switch.key+0x178>
    ed50:      	movz	x5, #0x0, lsl #48
    ed54:      	b	0xebe8 <_stogir.switch.key+0x170>
    ed58:      	uxtb	w16, w0
    ed5c:      	cmp	w16, wzr
    ed60:      	b.ne	0xeb54 <_stogir.switch.key+0xdc>
    ed64:      	uxtb	w16, w7
    ed68:      	cmp	w16, wzr
    ed6c:      	b.ne	0xeb54 <_stogir.switch.key+0xdc>
    ed70:      	uxtb	w16, w9
    ed74:      	cmp	w16, wzr
    ed78:      	b.ne	0xeb54 <_stogir.switch.key+0xdc>
    ed7c:      	uxtb	w16, w10
    ed80:      	cmp	w16, wzr
    ed84:      	b.ne	0xeb54 <_stogir.switch.key+0xdc>
    ed88:      	uxtb	w16, w11
    ed8c:      	cmp	w16, wzr
    ed90:      	b.ne	0xee94 <_stogir.switch.key+0x41c>
    ed94:      	uxtb	w16, w12
    ed98:      	cmp	w16, wzr
    ed9c:      	b.ne	0xee94 <_stogir.switch.key+0x41c>
    eda0:      	uxtb	w16, w13
    eda4:      	cmp	w16, wzr
    eda8:      	b.ne	0xef6c <_stogir.switch.key+0x4f4>
    edac:      	uxtb	w16, w14
    edb0:      	cmp	w16, wzr
    edb4:      	b.ne	0xef6c <_stogir.switch.key+0x4f4>
    edb8:      	uxtb	w16, w15
    edbc:      	cmp	w16, wzr
    edc0:      	b.ne	0xef6c <_stogir.switch.key+0x4f4>
    edc4:      	uxtb	w16, w19
    edc8:      	cmp	w16, wzr
    edcc:      	b.ne	0xef74 <_stogir.switch.key+0x4fc>
    edd0:      	uxtb	w16, w20
    edd4:      	cmp	w16, wzr
    edd8:      	b.ne	0xef74 <_stogir.switch.key+0x4fc>
    eddc:      	uxtb	w16, w21
    ede0:      	cmp	w16, wzr
    ede4:      	b.ne	0xef74 <_stogir.switch.key+0x4fc>
    ede8:      	mov	x23, x22
    edec:      	b	0xef78 <_stogir.switch.key+0x500>
    edf0:      	movz	x5, #0x0, lsl #48
    edf4:      	b	0xed4c <_stogir.switch.key+0x2d4>
    edf8:      	cmp	x1, x2
    edfc:      	b.ne	0xeb7c <_stogir.switch.key+0x104>
    ee00:      	lsr	w23, w23, #0
    ee04:      	lsr	w1, w5, #0
    ee08:      	sxtw	x23, w23
    ee0c:      	ubfx	x1, x1, #0, #32
    ee10:      	lsr	x4, x5, #32
    ee14:      	lsl	x5, x23, #3
    ee18:      	ubfx	x4, x4, #0, #32
    ee1c:      	lsr	w5, w5, #0
    ee20:      	lsl	x4, x4, #32
    ee24:      	sxtw	x5, w5
    ee28:      	orr	x1, x4, x1
    ee2c:      	cmp	x5, #0x40
    ee30:      	b.ge	0xee40 <_stogir.switch.key+0x3c8>
    ee34:      	lsr	x4, x1, x5
    ee38:      	cmp	x4, #0x0
    ee3c:      	b.ne	0xeb7c <_stogir.switch.key+0x104>
    ee40:      	uxtb	w16, w0
    ee44:      	cmp	w16, wzr
    ee48:      	b.eq	0xee54 <_stogir.switch.key+0x3dc>
    ee4c:      	cmp	x1, #0x1
    ee50:      	b.hi	0xeb7c <_stogir.switch.key+0x104>
    ee54:      	cmp	x2, #0x7
    ee58:      	b.lt	0xee7c <_stogir.switch.key+0x404>
    ee5c:      	uxtb	w16, w3
    ee60:      	cmp	w16, wzr
    ee64:      	b.eq	0xee7c <_stogir.switch.key+0x404>
    ee68:      	uxtb	w16, w6
    ee6c:      	cmp	w16, wzr
    ee70:      	b.eq	0xeed4 <_stogir.switch.key+0x45c>
    ee74:      	movz	x0, #0x0, lsl #48
    ee78:      	b	0xeea8 <_stogir.switch.key+0x430>
    ee7c:      	movz	x0, #0x0, lsl #48
    ee80:      	eor	x0, x0, x1
    ee84:      	mov	x1, x0
    ee88:      	movz	x0, #0x0, lsl #48
    ee8c:      	movz	x2, #0x0, lsl #48
    ee90:      	b	0xeb94 <_stogir.switch.key+0x11c>
    ee94:      	mov	x23, #0x2               ; =2
    ee98:      	b	0xeb58 <_stogir.switch.key+0xe0>
    ee9c:      	brk	#0
    eea0:      	b	0xee9c <_stogir.switch.key+0x424>
    eea4:      	mov	x0, #0x1                ; =1
    eea8:      	lsr	w0, w0, #0
    eeac:      	sxtw	x0, w0
    eeb0:      	lsl	x0, x0, #3
    eeb4:      	lsr	w0, w0, #0
    eeb8:      	sxtw	x0, w0
    eebc:      	sub	x0, x0, #0x1
    eec0:      	lsr	w0, w0, #0
    eec4:      	sxtw	x0, w0
    eec8:      	mov	x16, #0x1               ; =1
    eecc:      	lsl	x0, x16, x0
    eed0:      	b	0xee80 <_stogir.switch.key+0x408>
    eed4:      	uxtb	w16, w0
    eed8:      	cmp	w16, wzr
    eedc:      	b.ne	0xeea4 <_stogir.switch.key+0x42c>
    eee0:      	uxtb	w16, w7
    eee4:      	cmp	w16, wzr
    eee8:      	b.ne	0xeea4 <_stogir.switch.key+0x42c>
    eeec:      	uxtb	w16, w9
    eef0:      	cmp	w16, wzr
    eef4:      	b.ne	0xeea4 <_stogir.switch.key+0x42c>
    eef8:      	uxtb	w16, w10
    eefc:      	cmp	w16, wzr
    ef00:      	b.ne	0xeea4 <_stogir.switch.key+0x42c>
    ef04:      	uxtb	w16, w11
    ef08:      	cmp	w16, wzr
    ef0c:      	b.ne	0xef7c <_stogir.switch.key+0x504>
    ef10:      	uxtb	w16, w12
    ef14:      	cmp	w16, wzr
    ef18:      	b.ne	0xef7c <_stogir.switch.key+0x504>
    ef1c:      	uxtb	w16, w13
    ef20:      	cmp	w16, wzr
    ef24:      	b.ne	0xef84 <_stogir.switch.key+0x50c>
    ef28:      	uxtb	w16, w14
    ef2c:      	cmp	w16, wzr
    ef30:      	b.ne	0xef84 <_stogir.switch.key+0x50c>
    ef34:      	uxtb	w16, w15
    ef38:      	cmp	w16, wzr
    ef3c:      	b.ne	0xef84 <_stogir.switch.key+0x50c>
    ef40:      	uxtb	w16, w19
    ef44:      	cmp	w16, wzr
    ef48:      	b.ne	0xef8c <_stogir.switch.key+0x514>
    ef4c:      	uxtb	w16, w20
    ef50:      	cmp	w16, wzr
    ef54:      	b.ne	0xef8c <_stogir.switch.key+0x514>
    ef58:      	uxtb	w16, w21
    ef5c:      	cmp	w16, wzr
    ef60:      	b.ne	0xef8c <_stogir.switch.key+0x514>
    ef64:      	mov	x0, x22
    ef68:      	b	0xef90 <_stogir.switch.key+0x518>
    ef6c:      	mov	x23, #0x4               ; =4
    ef70:      	b	0xee98 <_stogir.switch.key+0x420>
    ef74:      	mov	x23, #0x8               ; =8
    ef78:      	b	0xef70 <_stogir.switch.key+0x4f8>
    ef7c:      	mov	x0, #0x2                ; =2
    ef80:      	b	0xeea8 <_stogir.switch.key+0x430>
    ef84:      	mov	x0, #0x4                ; =4
    ef88:      	b	0xef80 <_stogir.switch.key+0x508>
    ef8c:      	mov	x0, #0x8                ; =8
    ef90:      	b	0xef88 <_stogir.switch.key+0x510>

000000000000ef94 <_stogir.stack.entry-allocation?>:
    ef94:      	sub	sp, sp, #0x10
    ef98:      	add	x2, x0, #0x78
    ef9c:      	add	x3, x0, #0x28
    efa0:      	add	x4, x0, #0x50
    efa4:      	add	x5, x0, #0x78
    efa8:      	add	x6, x0, #0x28
    efac:      	add	x7, x0, #0x50
    efb0:      	sxtw	x1, w1
    efb4:      	mov	x9, x1
    efb8:      	mov	x1, #0x1                ; =1
    efbc:      	movz	x8, #0x0, lsl #48
    efc0:      	b	0xf110 <_stogir.stack.entry-allocation?+0x17c>
    efc4:      	movz	x12, #0x0, lsl #48
    efc8:      	b	0xf040 <_stogir.stack.entry-allocation?+0xac>
    efcc:      	movz	x10, #0x0, lsl #48
    efd0:      	movz	x11, #0x0, lsl #48
    efd4:      	lsr	w10, w10, #0
    efd8:      	lsr	x16, x10, #0
    efdc:      	cmp	x16, #0x1
    efe0:      	b.eq	0xeffc <_stogir.stack.entry-allocation?+0x68>
    efe4:      	b.lo	0xefec <_stogir.stack.entry-allocation?+0x58>
    efe8:      	b	0xf000 <_stogir.stack.entry-allocation?+0x6c>
    efec:      	cmp	x16, #0x0
    eff0:      	b.eq	0xeff8 <_stogir.stack.entry-allocation?+0x64>
    eff4:      	b	0xf000 <_stogir.stack.entry-allocation?+0x6c>
    eff8:      	b	0xf020 <_stogir.stack.entry-allocation?+0x8c>
    effc:      	b	0xf004 <_stogir.stack.entry-allocation?+0x70>
    f000:      	b	0xf35c <_stogir.stack.entry-allocation?+0x3c8>
    f004:      	uxtb	w10, w11
    f008:      	lsr	w11, w11, #0
    f00c:      	ubfx	x11, x11, #8, #8
    f010:      	cmp	x10, x11
    f014:      	b.eq	0xf34c <_stogir.stack.entry-allocation?+0x3b8>
    f018:      	cmp	x10, #0x49
    f01c:      	b.eq	0xf34c <_stogir.stack.entry-allocation?+0x3b8>
    f020:      	movz	x1, #0x0, lsl #48
    f024:      	fmov	d31, x8
    f028:      	mov	x8, x9
    f02c:      	fmov	x9, d31
    f030:      	b	0xf1fc <_stogir.stack.entry-allocation?+0x268>
    f034:      	movz	x12, #0x0, lsl #48
    f038:      	b	0xf048 <_stogir.stack.entry-allocation?+0xb4>
    f03c:      	movz	x12, #0x0, lsl #48
    f040:      	b	0xf050 <_stogir.stack.entry-allocation?+0xbc>
    f044:      	movz	x12, #0x0, lsl #48
    f048:      	b	0xf050 <_stogir.stack.entry-allocation?+0xbc>
    f04c:      	movz	x12, #0x0, lsl #48
    f050:      	cmp	x12, #0x0
    f054:      	b.eq	0xf0b8 <_stogir.stack.entry-allocation?+0x124>
    f058:      	uxtb	w16, w11
    f05c:      	cmp	w16, wzr
    f060:      	b.eq	0xf088 <_stogir.stack.entry-allocation?+0xf4>
    f064:      	lsl	x11, x10, #4
    f068:      	ldr	x11, [x0]
    f06c:      	add	x10, x11, x10, lsl #4
    f070:      	ldr	x11, [x10]
    f074:      	ldr	x10, [x10, #0x8]
    f078:      	fmov	d31, x10
    f07c:      	mov	x10, x11
    f080:      	fmov	x11, d31
    f084:      	b	0xf0a8 <_stogir.stack.entry-allocation?+0x114>
    f088:      	lsl	x10, x13, #4
    f08c:      	ldr	x10, [x0, #0x28]
    f090:      	add	x10, x10, x13, lsl #4
    f094:      	ldr	x11, [x10]
    f098:      	ldr	x10, [x10, #0x8]
    f09c:      	fmov	d31, x10
    f0a0:      	mov	x10, x11
    f0a4:      	fmov	x11, d31
    f0a8:      	mov	x12, x11
    f0ac:      	mov	x11, x10
    f0b0:      	mov	x10, #0x1               ; =1
    f0b4:      	b	0xf0c4 <_stogir.stack.entry-allocation?+0x130>
    f0b8:      	movz	x10, #0x0, lsl #48
    f0bc:      	movz	x11, #0x0, lsl #48
    f0c0:      	movz	x12, #0x0, lsl #48
    f0c4:      	lsr	w10, w10, #0
    f0c8:      	lsr	x16, x10, #0
    f0cc:      	cmp	x16, #0x1
    f0d0:      	b.eq	0xf0ec <_stogir.stack.entry-allocation?+0x158>
    f0d4:      	b.lo	0xf0dc <_stogir.stack.entry-allocation?+0x148>
    f0d8:      	b	0xf0f0 <_stogir.stack.entry-allocation?+0x15c>
    f0dc:      	cmp	x16, #0x0
    f0e0:      	b.eq	0xf0e8 <_stogir.stack.entry-allocation?+0x154>
    f0e4:      	b	0xf0f0 <_stogir.stack.entry-allocation?+0x15c>
    f0e8:      	b	0xf0f4 <_stogir.stack.entry-allocation?+0x160>
    f0ec:      	b	0xf1c8 <_stogir.stack.entry-allocation?+0x234>
    f0f0:      	b	0xf2a8 <_stogir.stack.entry-allocation?+0x314>
    f0f4:      	fmov	d31, x8
    f0f8:      	mov	x8, x9
    f0fc:      	fmov	x9, d31
    f100:      	movz	x1, #0x0, lsl #48
    f104:      	fmov	d31, x8
    f108:      	mov	x8, x9
    f10c:      	fmov	x9, d31
    f110:      	cmp	x1, #0x0
    f114:      	b.eq	0xf28c <_stogir.stack.entry-allocation?+0x2f8>
    f118:      	cmp	x8, #0x0
    f11c:      	b.ne	0xf28c <_stogir.stack.entry-allocation?+0x2f8>
    f120:      	lsr	w10, w9, #0
    f124:      	sxtw	x10, w10
    f128:      	cmp	x10, #0x0
    f12c:      	cset	w11, gt
    f130:      	movz	x16, #0x0, lsl #48
    f134:      	sub	x12, x16, x10
    f138:      	sub	x13, x12, #0x1
    f13c:      	uxtb	w16, w11
    f140:      	cmp	w16, wzr
    f144:      	b.eq	0xf184 <_stogir.stack.entry-allocation?+0x1f0>
    f148:      	ldr	x12, [x0, #0x8]
    f14c:      	cmp	x10, x12
    f150:      	b.ge	0xf044 <_stogir.stack.entry-allocation?+0xb0>
    f154:      	ldr	x12, [x2, #0x8]
    f158:      	cmp	x10, x12
    f15c:      	b.ge	0xf034 <_stogir.stack.entry-allocation?+0xa0>
    f160:      	lsl	x12, x10, #2
    f164:      	ldr	x12, [x0, #0x78]
    f168:      	add	x12, x12, x10, lsl #2
    f16c:      	ldr	w12, [x12]
    f170:      	sxtw	x12, w12
    f174:      	cmp	x12, #0x0
    f178:      	cset	w12, ge
    f17c:      	ubfx	x12, x12, #0, #8
    f180:      	b	0xf038 <_stogir.stack.entry-allocation?+0xa4>
    f184:      	cmp	x10, #0x0
    f188:      	b.ge	0xf04c <_stogir.stack.entry-allocation?+0xb8>
    f18c:      	ldr	x14, [x3, #0x8]
    f190:      	ldr	x15, [x4, #0x8]
    f194:      	cmp	x14, x15
    f198:      	b.ne	0xf03c <_stogir.stack.entry-allocation?+0xa8>
    f19c:      	cmp	x12, x14
    f1a0:      	b.gt	0xefc4 <_stogir.stack.entry-allocation?+0x30>
    f1a4:      	lsl	x12, x13, #2
    f1a8:      	ldr	x12, [x0, #0x50]
    f1ac:      	add	x12, x12, x13, lsl #2
    f1b0:      	ldr	w12, [x12]
    f1b4:      	sxtw	x12, w12
    f1b8:      	cmp	x12, #0x0
    f1bc:      	cset	w12, gt
    f1c0:      	ubfx	x12, x12, #0, #8
    f1c4:      	b	0xefc8 <_stogir.stack.entry-allocation?+0x34>
    f1c8:      	uxtb	w10, w11
    f1cc:      	asr	x13, x11, #32
    f1d0:      	mov	x16, sp
    f1d4:      	str	x11, [x16]
    f1d8:      	mov	x16, sp
    f1dc:      	str	x12, [x16, #0x8]
    f1e0:      	cmp	x10, #0x68
    f1e4:      	b.ne	0xf200 <_stogir.stack.entry-allocation?+0x26c>
    f1e8:      	cmp	x13, #0x0
    f1ec:      	cset	w1, eq
    f1f0:      	ubfx	x1, x1, #0, #8
    f1f4:      	mov	x8, x9
    f1f8:      	mov	x9, #0x1                ; =1
    f1fc:      	b	0xf104 <_stogir.stack.entry-allocation?+0x170>
    f200:      	cmp	x9, #0x0
    f204:      	b.le	0xf020 <_stogir.stack.entry-allocation?+0x8c>
    f208:      	cmp	x10, #0x51
    f20c:      	b.ne	0xf020 <_stogir.stack.entry-allocation?+0x8c>
    f210:      	cmp	x13, #0x0
    f214:      	b.le	0xf020 <_stogir.stack.entry-allocation?+0x8c>
    f218:      	cmp	x13, x9
    f21c:      	b.ge	0xf020 <_stogir.stack.entry-allocation?+0x8c>
    f220:      	lsr	w12, w12, #0
    f224:      	sxtw	x12, w12
    f228:      	cmp	x12, #0x0
    f22c:      	b.ge	0xf020 <_stogir.stack.entry-allocation?+0x8c>
    f230:      	cmp	x12, #0x0
    f234:      	cset	w10, gt
    f238:      	movz	x16, #0x0, lsl #48
    f23c:      	sub	x11, x16, x12
    f240:      	sub	x13, x11, #0x1
    f244:      	uxtb	w16, w10
    f248:      	cmp	w16, wzr
    f24c:      	b.eq	0xf300 <_stogir.stack.entry-allocation?+0x36c>
    f250:      	ldr	x11, [x0, #0x8]
    f254:      	cmp	x12, x11
    f258:      	b.ge	0xf2f8 <_stogir.stack.entry-allocation?+0x364>
    f25c:      	ldr	x11, [x5, #0x8]
    f260:      	cmp	x12, x11
    f264:      	b.ge	0xf344 <_stogir.stack.entry-allocation?+0x3b0>
    f268:      	lsl	x11, x12, #2
    f26c:      	ldr	x11, [x0, #0x78]
    f270:      	add	x11, x11, x12, lsl #2
    f274:      	ldr	w11, [x11]
    f278:      	sxtw	x11, w11
    f27c:      	cmp	x11, #0x0
    f280:      	cset	w11, ge
    f284:      	ubfx	x11, x11, #0, #8
    f288:      	b	0xf348 <_stogir.stack.entry-allocation?+0x3b4>
    f28c:      	cmp	x1, #0x0
    f290:      	b.eq	0xf29c <_stogir.stack.entry-allocation?+0x308>
    f294:      	mov	x0, x8
    f298:      	b	0xf2a0 <_stogir.stack.entry-allocation?+0x30c>
    f29c:      	movz	x0, #0x0, lsl #48
    f2a0:      	add	sp, sp, #0x10
    f2a4:      	ret
    f2a8:      	brk	#0
    f2ac:      	b	0xf2a8 <_stogir.stack.entry-allocation?+0x314>
    f2b0:      	lsl	x10, x13, #4
    f2b4:      	ldr	x10, [x0, #0x28]
    f2b8:      	add	x10, x10, x13, lsl #4
    f2bc:      	ldr	x10, [x10]
    f2c0:      	mov	x11, x10
    f2c4:      	mov	x10, #0x1               ; =1
    f2c8:      	b	0xefd4 <_stogir.stack.entry-allocation?+0x40>
    f2cc:      	movz	x11, #0x0, lsl #48
    f2d0:      	cmp	x11, #0x0
    f2d4:      	b.eq	0xefcc <_stogir.stack.entry-allocation?+0x38>
    f2d8:      	uxtb	w16, w10
    f2dc:      	cmp	w16, wzr
    f2e0:      	b.eq	0xf2b0 <_stogir.stack.entry-allocation?+0x31c>
    f2e4:      	lsl	x10, x12, #4
    f2e8:      	ldr	x10, [x0]
    f2ec:      	add	x10, x10, x12, lsl #4
    f2f0:      	ldr	x10, [x10]
    f2f4:      	b	0xf2c0 <_stogir.stack.entry-allocation?+0x32c>
    f2f8:      	movz	x11, #0x0, lsl #48
    f2fc:      	b	0xf2d0 <_stogir.stack.entry-allocation?+0x33c>
    f300:      	ldr	x14, [x6, #0x8]
    f304:      	ldr	x15, [x7, #0x8]
    f308:      	cmp	x14, x15
    f30c:      	b.ne	0xf2cc <_stogir.stack.entry-allocation?+0x338>
    f310:      	cmp	x11, x14
    f314:      	b.gt	0xf33c <_stogir.stack.entry-allocation?+0x3a8>
    f318:      	lsl	x11, x13, #2
    f31c:      	ldr	x11, [x0, #0x50]
    f320:      	add	x11, x11, x13, lsl #2
    f324:      	ldr	w11, [x11]
    f328:      	sxtw	x11, w11
    f32c:      	cmp	x11, #0x0
    f330:      	cset	w11, gt
    f334:      	ubfx	x11, x11, #0, #8
    f338:      	b	0xf340 <_stogir.stack.entry-allocation?+0x3ac>
    f33c:      	movz	x11, #0x0, lsl #48
    f340:      	b	0xf2d0 <_stogir.stack.entry-allocation?+0x33c>
    f344:      	movz	x11, #0x0, lsl #48
    f348:      	b	0xf2fc <_stogir.stack.entry-allocation?+0x368>
    f34c:      	mov	x16, sp
    f350:      	ldr	w9, [x16, #0x4]
    f354:      	sxtw	x9, w9
    f358:      	b	0xf024 <_stogir.stack.entry-allocation?+0x90>
    f35c:      	brk	#0
    f360:      	b	0xf35c <_stogir.stack.entry-allocation?+0x3c8>

000000000000f364 <_stogir.stack.constant-size>:
    f364:      	sub	sp, sp, #0x10
    f368:      	str	x29, [sp]
    f36c:      	str	x30, [sp, #0x8]
    f370:      	mov	x29, sp
    f374:      	mov	x2, sp
    f378:      	sxtw	x1, w1
    f37c:      	sub	sp, sp, #0x10
    f380:      	mov	x3, sp
    f384:      	cmp	x1, #0x0
    f388:      	cset	w4, gt
    f38c:      	movz	x16, #0x0, lsl #48
    f390:      	sub	x5, x16, x1
    f394:      	sub	x6, x5, #0x1
    f398:      	uxtb	w16, w4
    f39c:      	cmp	w16, wzr
    f3a0:      	b.eq	0xf3e4 <_stogir.stack.constant-size+0x80>
    f3a4:      	ldr	x5, [x0, #0x8]
    f3a8:      	cmp	x1, x5
    f3ac:      	b.ge	0xf438 <_stogir.stack.constant-size+0xd4>
    f3b0:      	add	x5, x0, #0x78
    f3b4:      	ldr	x5, [x5, #0x8]
    f3b8:      	cmp	x1, x5
    f3bc:      	b.ge	0xf5ac <_stogir.stack.constant-size+0x248>
    f3c0:      	lsl	x5, x1, #2
    f3c4:      	ldr	x5, [x0, #0x78]
    f3c8:      	add	x5, x5, x1, lsl #2
    f3cc:      	ldr	w5, [x5]
    f3d0:      	sxtw	x5, w5
    f3d4:      	cmp	x5, #0x0
    f3d8:      	cset	w5, ge
    f3dc:      	ubfx	x5, x5, #0, #8
    f3e0:      	b	0xf5b0 <_stogir.stack.constant-size+0x24c>
    f3e4:      	cmp	x1, #0x0
    f3e8:      	b.ge	0xf440 <_stogir.stack.constant-size+0xdc>
    f3ec:      	add	x7, x0, #0x28
    f3f0:      	add	x9, x0, #0x50
    f3f4:      	ldr	x7, [x7, #0x8]
    f3f8:      	ldr	x9, [x9, #0x8]
    f3fc:      	cmp	x7, x9
    f400:      	b.ne	0xf430 <_stogir.stack.constant-size+0xcc>
    f404:      	cmp	x5, x7
    f408:      	b.gt	0xf634 <_stogir.stack.constant-size+0x2d0>
    f40c:      	lsl	x5, x6, #2
    f410:      	ldr	x5, [x0, #0x50]
    f414:      	add	x5, x5, x6, lsl #2
    f418:      	ldr	w5, [x5]
    f41c:      	sxtw	x5, w5
    f420:      	cmp	x5, #0x0
    f424:      	cset	w5, gt
    f428:      	ubfx	x5, x5, #0, #8
    f42c:      	b	0xf638 <_stogir.stack.constant-size+0x2d4>
    f430:      	movz	x5, #0x0, lsl #48
    f434:      	b	0xf444 <_stogir.stack.constant-size+0xe0>
    f438:      	movz	x5, #0x0, lsl #48
    f43c:      	b	0xf444 <_stogir.stack.constant-size+0xe0>
    f440:      	movz	x5, #0x0, lsl #48
    f444:      	cmp	x5, #0x0
    f448:      	b.eq	0xf4ac <_stogir.stack.constant-size+0x148>
    f44c:      	uxtb	w16, w4
    f450:      	cmp	w16, wzr
    f454:      	b.eq	0xf47c <_stogir.stack.constant-size+0x118>
    f458:      	lsl	x4, x1, #4
    f45c:      	ldr	x0, [x0]
    f460:      	add	x0, x0, x1, lsl #4
    f464:      	ldr	x4, [x0]
    f468:      	ldr	x0, [x0, #0x8]
    f46c:      	fmov	d31, x0
    f470:      	mov	x0, x4
    f474:      	fmov	x4, d31
    f478:      	b	0xf49c <_stogir.stack.constant-size+0x138>
    f47c:      	lsl	x4, x6, #4
    f480:      	ldr	x0, [x0, #0x28]
    f484:      	add	x0, x0, x6, lsl #4
    f488:      	ldr	x4, [x0]
    f48c:      	ldr	x0, [x0, #0x8]
    f490:      	fmov	d31, x0
    f494:      	mov	x0, x4
    f498:      	fmov	x4, d31
    f49c:      	mov	x5, x4
    f4a0:      	mov	x4, x0
    f4a4:      	mov	x0, #0x1                ; =1
    f4a8:      	b	0xf4b8 <_stogir.stack.constant-size+0x154>
    f4ac:      	movz	x0, #0x0, lsl #48
    f4b0:      	movz	x4, #0x0, lsl #48
    f4b4:      	movz	x5, #0x0, lsl #48
    f4b8:      	lsr	w0, w0, #0
    f4bc:      	lsr	x16, x0, #0
    f4c0:      	cmp	x16, #0x1
    f4c4:      	b.eq	0xf4e0 <_stogir.stack.constant-size+0x17c>
    f4c8:      	b.lo	0xf4d0 <_stogir.stack.constant-size+0x16c>
    f4cc:      	b	0xf4e4 <_stogir.stack.constant-size+0x180>
    f4d0:      	cmp	x16, #0x0
    f4d4:      	b.eq	0xf4dc <_stogir.stack.constant-size+0x178>
    f4d8:      	b	0xf4e4 <_stogir.stack.constant-size+0x180>
    f4dc:      	b	0xf4e8 <_stogir.stack.constant-size+0x184>
    f4e0:      	b	0xf58c <_stogir.stack.constant-size+0x228>
    f4e4:      	b	0xf6ec <_stogir.stack.constant-size+0x388>
    f4e8:      	adrp	x16, 0xf000 <_stogir.stack.entry-allocation?+0x6c>
		000000000000f4e8:  ARM64_RELOC_PAGE21	l_stogir.514
    f4ec:      	ldr	x16, [x16]
		000000000000f4ec:  ARM64_RELOC_PAGEOFF12	l_stogir.514
    f4f0:      	orr	x0, x16, xzr
    f4f4:      	mov	x1, x0
    f4f8:      	mov	x0, #0x1                ; =1
    f4fc:      	mov	x3, #0x18               ; =24
    f500:      	b	0xf568 <_stogir.stack.constant-size+0x204>
    f504:      	mov	x4, #0x1                ; =1
    f508:      	ldr	w5, [x3, #0x8]
    f50c:      	ldr	w6, [x3, #0xc]
    f510:      	cmp	x1, #0x0
    f514:      	b.ge	0xf550 <_stogir.stack.constant-size+0x1ec>
    f518:      	cmp	x0, #0x1
    f51c:      	b.lt	0xf550 <_stogir.stack.constant-size+0x1ec>
    f520:      	cmp	x0, #0xb
    f524:      	cset	w1, le
    f528:      	uxtb	w16, w1
    f52c:      	cmp	w16, wzr
    f530:      	b.eq	0xf550 <_stogir.stack.constant-size+0x1ec>
    f534:      	ldr	w3, [x3]
    f538:      	uxtb	w7, w3
    f53c:      	ubfx	x3, x3, #8, #8
    f540:      	cmp	x7, x3
    f544:      	b.eq	0xf63c <_stogir.stack.constant-size+0x2d8>
    f548:      	cmp	x7, #0x49
    f54c:      	b.eq	0xf63c <_stogir.stack.constant-size+0x2d8>
    f550:      	adrp	x16, 0xf000 <_stogir.stack.entry-allocation?+0x6c>
		000000000000f550:  ARM64_RELOC_PAGE21	l_stogir.515
    f554:      	ldr	x16, [x16]
		000000000000f554:  ARM64_RELOC_PAGEOFF12	l_stogir.515
    f558:      	orr	x0, x16, xzr
    f55c:      	mov	x1, x0
    f560:      	mov	x0, #0x1                ; =1
    f564:      	mov	x3, #0x30               ; =48
    f568:      	mov	sp, x2
    f56c:      	str	x0, [x8]
    f570:      	str	x1, [x8, #0x8]
    f574:      	str	x3, [x8, #0x10]
    f578:      	sub	sp, x29, #0x0
    f57c:      	ldr	x29, [sp]
    f580:      	ldr	x30, [sp, #0x8]
    f584:      	add	sp, sp, #0x10
    f588:      	ret
    f58c:      	lsr	w0, w4, #0
    f590:      	str	x4, [x3]
    f594:      	str	x5, [x3, #0x8]
    f598:      	ubfx	x0, x0, #8, #8
    f59c:      	cmp	x0, #0x0
    f5a0:      	b.ne	0xf5b4 <_stogir.stack.constant-size+0x250>
    f5a4:      	movz	x4, #0x0, lsl #48
    f5a8:      	b	0xf508 <_stogir.stack.constant-size+0x1a4>
    f5ac:      	movz	x5, #0x0, lsl #48
    f5b0:      	b	0xf43c <_stogir.stack.constant-size+0xd8>
    f5b4:      	cmp	x0, #0x1
    f5b8:      	b.eq	0xf504 <_stogir.stack.constant-size+0x1a0>
    f5bc:      	cmp	x0, #0x2
    f5c0:      	b.eq	0xf504 <_stogir.stack.constant-size+0x1a0>
    f5c4:      	cmp	x0, #0x7
    f5c8:      	b.eq	0xf504 <_stogir.stack.constant-size+0x1a0>
    f5cc:      	cmp	x0, #0x8
    f5d0:      	b.eq	0xf504 <_stogir.stack.constant-size+0x1a0>
    f5d4:      	cmp	x0, #0x3
    f5d8:      	b.eq	0xf6e4 <_stogir.stack.constant-size+0x380>
    f5dc:      	cmp	x0, #0x9
    f5e0:      	b.eq	0xf6e4 <_stogir.stack.constant-size+0x380>
    f5e4:      	cmp	x0, #0x4
    f5e8:      	b.eq	0xf6f4 <_stogir.stack.constant-size+0x390>
    f5ec:      	cmp	x0, #0xa
    f5f0:      	b.eq	0xf6f4 <_stogir.stack.constant-size+0x390>
    f5f4:      	cmp	x0, #0xd
    f5f8:      	b.eq	0xf6f4 <_stogir.stack.constant-size+0x390>
    f5fc:      	cmp	x0, #0x5
    f600:      	b.eq	0xf6fc <_stogir.stack.constant-size+0x398>
    f604:      	cmp	x0, #0xb
    f608:      	b.eq	0xf6fc <_stogir.stack.constant-size+0x398>
    f60c:      	cmp	x0, #0xc
    f610:      	b.eq	0xf6fc <_stogir.stack.constant-size+0x398>
    f614:      	cmp	x0, #0x6
    f618:      	cset	w4, eq
    f61c:      	uxtb	w16, w4
    f620:      	cmp	w16, wzr
    f624:      	mov	x16, #0x8               ; =8
    f628:      	movn	x17, #0x0, lsl #48
    f62c:      	csel	x4, x16, x17, ne
    f630:      	b	0xf700 <_stogir.stack.constant-size+0x39c>
    f634:      	movz	x5, #0x0, lsl #48
    f638:      	b	0xf434 <_stogir.stack.constant-size+0xd0>
    f63c:      	lsr	w4, w4, #0
    f640:      	sxtw	x4, w4
    f644:      	cmp	x4, #0x0
    f648:      	b.le	0xf550 <_stogir.stack.constant-size+0x1ec>
    f64c:      	ubfx	x5, x5, #0, #32
    f650:      	ubfx	x6, x6, #0, #32
    f654:      	lsl	x3, x6, #32
    f658:      	orr	x3, x3, x5
    f65c:      	cmp	x4, #0x8
    f660:      	b.ge	0xf67c <_stogir.stack.constant-size+0x318>
    f664:      	lsl	x5, x4, #3
    f668:      	lsr	w5, w5, #0
    f66c:      	sxtw	x5, w5
    f670:      	lsr	x5, x3, x5
    f674:      	cmp	x5, #0x0
    f678:      	b.ne	0xf550 <_stogir.stack.constant-size+0x1ec>
    f67c:      	cmp	x0, #0x7
    f680:      	b.lt	0xf6bc <_stogir.stack.constant-size+0x358>
    f684:      	uxtb	w16, w1
    f688:      	cmp	w16, wzr
    f68c:      	b.eq	0xf6bc <_stogir.stack.constant-size+0x358>
    f690:      	lsl	x0, x4, #3
    f694:      	lsr	w0, w0, #0
    f698:      	sxtw	x0, w0
    f69c:      	sub	x0, x0, #0x1
    f6a0:      	lsr	w0, w0, #0
    f6a4:      	sxtw	x0, w0
    f6a8:      	mov	x16, #0x1               ; =1
    f6ac:      	lsl	x0, x16, x0
    f6b0:      	and	x0, x0, x3
    f6b4:      	cmp	x0, #0x0
    f6b8:      	b.ne	0xf550 <_stogir.stack.constant-size+0x1ec>
    f6bc:      	mov	x17, #-0x10             ; =-16
    f6c0:      	movk	x17, #0x7fff, lsl #48
    f6c4:      	cmp	x3, x17
    f6c8:      	b.hi	0xf550 <_stogir.stack.constant-size+0x1ec>
    f6cc:      	add	x0, x3, #0xf
    f6d0:      	and	x0, x0, #0xfffffffffffffff0
    f6d4:      	mov	x1, x0
    f6d8:      	movz	x0, #0x0, lsl #48
    f6dc:      	movz	x3, #0x0, lsl #48
    f6e0:      	b	0xf568 <_stogir.stack.constant-size+0x204>
    f6e4:      	mov	x4, #0x2                ; =2
    f6e8:      	b	0xf508 <_stogir.stack.constant-size+0x1a4>
    f6ec:      	brk	#0
    f6f0:      	b	0xf6ec <_stogir.stack.constant-size+0x388>
    f6f4:      	mov	x4, #0x4                ; =4
    f6f8:      	b	0xf6e8 <_stogir.stack.constant-size+0x384>
    f6fc:      	mov	x4, #0x8                ; =8
    f700:      	b	0xf6f8 <_stogir.stack.constant-size+0x394>

000000000000f704 <_stogir.frame.valid-alignment?>:
    f704:      	cmp	x0, #0x0
    f708:      	b.le	0xf724 <_stogir.frame.valid-alignment?+0x20>
    f70c:      	sub	x1, x0, #0x1
    f710:      	and	x0, x1, x0
    f714:      	cmp	x0, #0x0
    f718:      	cset	w0, eq
    f71c:      	ubfx	x0, x0, #0, #8
    f720:      	b	0xf728 <_stogir.frame.valid-alignment?+0x24>
    f724:      	movz	x0, #0x0, lsl #48
    f728:      	ret

000000000000f72c <_stogir.stack.constant-size-aligned>:
    f72c:      	sub	sp, sp, #0x10
    f730:      	cmp	x2, #0x10
    f734:      	b.lt	0xf7b4 <_stogir.stack.constant-size-aligned+0x88>
    f738:      	cmp	x2, #0x0
    f73c:      	b.le	0xf7b4 <_stogir.stack.constant-size-aligned+0x88>
    f740:      	sub	x3, x2, #0x1
    f744:      	and	x3, x3, x2
    f748:      	cmp	x3, #0x0
    f74c:      	b.ne	0xf7b4 <_stogir.stack.constant-size-aligned+0x88>
    f750:      	sxtw	x1, w1
    f754:      	cmp	x1, #0x0
    f758:      	cset	w3, gt
    f75c:      	movz	x16, #0x0, lsl #48
    f760:      	sub	x4, x16, x1
    f764:      	sub	x5, x4, #0x1
    f768:      	uxtb	w16, w3
    f76c:      	cmp	w16, wzr
    f770:      	b.eq	0xf854 <_stogir.stack.constant-size-aligned+0x128>
    f774:      	ldr	x4, [x0, #0x8]
    f778:      	cmp	x1, x4
    f77c:      	b.ge	0xf8a0 <_stogir.stack.constant-size-aligned+0x174>
    f780:      	add	x4, x0, #0x78
    f784:      	ldr	x4, [x4, #0x8]
    f788:      	cmp	x1, x4
    f78c:      	b.ge	0xf99c <_stogir.stack.constant-size-aligned+0x270>
    f790:      	lsl	x4, x1, #2
    f794:      	ldr	x4, [x0, #0x78]
    f798:      	add	x4, x4, x1, lsl #2
    f79c:      	ldr	w4, [x4]
    f7a0:      	sxtw	x4, w4
    f7a4:      	cmp	x4, #0x0
    f7a8:      	cset	w4, ge
    f7ac:      	ubfx	x4, x4, #0, #8
    f7b0:      	b	0xf9a0 <_stogir.stack.constant-size-aligned+0x274>
    f7b4:      	adrp	x16, 0xf000 <_stogir.stack.entry-allocation?+0x6c>
		000000000000f7b4:  ARM64_RELOC_PAGE21	l_stogir.516
    f7b8:      	ldr	x16, [x16]
		000000000000f7b8:  ARM64_RELOC_PAGEOFF12	l_stogir.516
    f7bc:      	orr	x0, x16, xzr
    f7c0:      	mov	x1, x0
    f7c4:      	mov	x0, #0x1                ; =1
    f7c8:      	mov	x2, #0x20               ; =32
    f7cc:      	str	x0, [x8]
    f7d0:      	str	x1, [x8, #0x8]
    f7d4:      	str	x2, [x8, #0x10]
    f7d8:      	add	sp, sp, #0x10
    f7dc:      	ret
    f7e0:      	mov	x3, #0x1                ; =1
    f7e4:      	mov	x16, sp
    f7e8:      	ldr	w4, [x16, #0x8]
    f7ec:      	mov	x16, sp
    f7f0:      	ldr	w5, [x16, #0xc]
    f7f4:      	cmp	x1, #0x0
    f7f8:      	b.ge	0xf838 <_stogir.stack.constant-size-aligned+0x10c>
    f7fc:      	cmp	x0, #0x1
    f800:      	b.lt	0xf838 <_stogir.stack.constant-size-aligned+0x10c>
    f804:      	cmp	x0, #0xb
    f808:      	cset	w1, le
    f80c:      	uxtb	w16, w1
    f810:      	cmp	w16, wzr
    f814:      	b.eq	0xf838 <_stogir.stack.constant-size-aligned+0x10c>
    f818:      	mov	x16, sp
    f81c:      	ldr	w6, [x16]
    f820:      	uxtb	w7, w6
    f824:      	ubfx	x6, x6, #8, #8
    f828:      	cmp	x7, x6
    f82c:      	b.eq	0xfa2c <_stogir.stack.constant-size-aligned+0x300>
    f830:      	cmp	x7, #0x49
    f834:      	b.eq	0xfa2c <_stogir.stack.constant-size-aligned+0x300>
    f838:      	adrp	x16, 0xf000 <_stogir.stack.entry-allocation?+0x6c>
		000000000000f838:  ARM64_RELOC_PAGE21	l_stogir.517
    f83c:      	ldr	x16, [x16]
		000000000000f83c:  ARM64_RELOC_PAGEOFF12	l_stogir.517
    f840:      	orr	x0, x16, xzr
    f844:      	mov	x1, x0
    f848:      	mov	x0, #0x1                ; =1
    f84c:      	mov	x2, #0x30               ; =48
    f850:      	b	0xf7cc <_stogir.stack.constant-size-aligned+0xa0>
    f854:      	cmp	x1, #0x0
    f858:      	b.ge	0xf8a8 <_stogir.stack.constant-size-aligned+0x17c>
    f85c:      	add	x6, x0, #0x28
    f860:      	add	x7, x0, #0x50
    f864:      	ldr	x6, [x6, #0x8]
    f868:      	ldr	x7, [x7, #0x8]
    f86c:      	cmp	x6, x7
    f870:      	b.ne	0xf994 <_stogir.stack.constant-size-aligned+0x268>
    f874:      	cmp	x4, x6
    f878:      	b.gt	0xfa24 <_stogir.stack.constant-size-aligned+0x2f8>
    f87c:      	lsl	x4, x5, #2
    f880:      	ldr	x4, [x0, #0x50]
    f884:      	add	x4, x4, x5, lsl #2
    f888:      	ldr	w4, [x4]
    f88c:      	sxtw	x4, w4
    f890:      	cmp	x4, #0x0
    f894:      	cset	w4, gt
    f898:      	ubfx	x4, x4, #0, #8
    f89c:      	b	0xfa28 <_stogir.stack.constant-size-aligned+0x2fc>
    f8a0:      	movz	x4, #0x0, lsl #48
    f8a4:      	b	0xf8ac <_stogir.stack.constant-size-aligned+0x180>
    f8a8:      	movz	x4, #0x0, lsl #48
    f8ac:      	cmp	x4, #0x0
    f8b0:      	b.eq	0xf914 <_stogir.stack.constant-size-aligned+0x1e8>
    f8b4:      	uxtb	w16, w3
    f8b8:      	cmp	w16, wzr
    f8bc:      	b.eq	0xf8e4 <_stogir.stack.constant-size-aligned+0x1b8>
    f8c0:      	lsl	x3, x1, #4
    f8c4:      	ldr	x0, [x0]
    f8c8:      	add	x0, x0, x1, lsl #4
    f8cc:      	ldr	x3, [x0]
    f8d0:      	ldr	x0, [x0, #0x8]
    f8d4:      	fmov	d31, x0
    f8d8:      	mov	x0, x3
    f8dc:      	fmov	x3, d31
    f8e0:      	b	0xf904 <_stogir.stack.constant-size-aligned+0x1d8>
    f8e4:      	lsl	x3, x5, #4
    f8e8:      	ldr	x0, [x0, #0x28]
    f8ec:      	add	x0, x0, x5, lsl #4
    f8f0:      	ldr	x3, [x0]
    f8f4:      	ldr	x0, [x0, #0x8]
    f8f8:      	fmov	d31, x0
    f8fc:      	mov	x0, x3
    f900:      	fmov	x3, d31
    f904:      	mov	x4, x3
    f908:      	mov	x3, x0
    f90c:      	mov	x0, #0x1                ; =1
    f910:      	b	0xf920 <_stogir.stack.constant-size-aligned+0x1f4>
    f914:      	movz	x0, #0x0, lsl #48
    f918:      	movz	x3, #0x0, lsl #48
    f91c:      	movz	x4, #0x0, lsl #48
    f920:      	lsr	w0, w0, #0
    f924:      	lsr	x16, x0, #0
    f928:      	cmp	x16, #0x1
    f92c:      	b.eq	0xf948 <_stogir.stack.constant-size-aligned+0x21c>
    f930:      	b.lo	0xf938 <_stogir.stack.constant-size-aligned+0x20c>
    f934:      	b	0xf94c <_stogir.stack.constant-size-aligned+0x220>
    f938:      	cmp	x16, #0x0
    f93c:      	b.eq	0xf944 <_stogir.stack.constant-size-aligned+0x218>
    f940:      	b	0xf94c <_stogir.stack.constant-size-aligned+0x220>
    f944:      	b	0xf950 <_stogir.stack.constant-size-aligned+0x224>
    f948:      	b	0xf96c <_stogir.stack.constant-size-aligned+0x240>
    f94c:      	b	0xfaec <_stogir.stack.constant-size-aligned+0x3c0>
    f950:      	adrp	x16, 0xf000 <_stogir.stack.entry-allocation?+0x6c>
		000000000000f950:  ARM64_RELOC_PAGE21	l_stogir.518
    f954:      	ldr	x16, [x16]
		000000000000f954:  ARM64_RELOC_PAGEOFF12	l_stogir.518
    f958:      	orr	x0, x16, xzr
    f95c:      	mov	x1, x0
    f960:      	mov	x0, #0x1                ; =1
    f964:      	mov	x2, #0x18               ; =24
    f968:      	b	0xf850 <_stogir.stack.constant-size-aligned+0x124>
    f96c:      	lsr	w0, w3, #0
    f970:      	mov	x16, sp
    f974:      	str	x3, [x16]
    f978:      	mov	x16, sp
    f97c:      	str	x4, [x16, #0x8]
    f980:      	ubfx	x0, x0, #8, #8
    f984:      	cmp	x0, #0x0
    f988:      	b.ne	0xf9a4 <_stogir.stack.constant-size-aligned+0x278>
    f98c:      	movz	x3, #0x0, lsl #48
    f990:      	b	0xf7e4 <_stogir.stack.constant-size-aligned+0xb8>
    f994:      	movz	x4, #0x0, lsl #48
    f998:      	b	0xf8ac <_stogir.stack.constant-size-aligned+0x180>
    f99c:      	movz	x4, #0x0, lsl #48
    f9a0:      	b	0xf8a4 <_stogir.stack.constant-size-aligned+0x178>
    f9a4:      	cmp	x0, #0x1
    f9a8:      	b.eq	0xf7e0 <_stogir.stack.constant-size-aligned+0xb4>
    f9ac:      	cmp	x0, #0x2
    f9b0:      	b.eq	0xf7e0 <_stogir.stack.constant-size-aligned+0xb4>
    f9b4:      	cmp	x0, #0x7
    f9b8:      	b.eq	0xf7e0 <_stogir.stack.constant-size-aligned+0xb4>
    f9bc:      	cmp	x0, #0x8
    f9c0:      	b.eq	0xf7e0 <_stogir.stack.constant-size-aligned+0xb4>
    f9c4:      	cmp	x0, #0x3
    f9c8:      	b.eq	0xfae4 <_stogir.stack.constant-size-aligned+0x3b8>
    f9cc:      	cmp	x0, #0x9
    f9d0:      	b.eq	0xfae4 <_stogir.stack.constant-size-aligned+0x3b8>
    f9d4:      	cmp	x0, #0x4
    f9d8:      	b.eq	0xfaf4 <_stogir.stack.constant-size-aligned+0x3c8>
    f9dc:      	cmp	x0, #0xa
    f9e0:      	b.eq	0xfaf4 <_stogir.stack.constant-size-aligned+0x3c8>
    f9e4:      	cmp	x0, #0xd
    f9e8:      	b.eq	0xfaf4 <_stogir.stack.constant-size-aligned+0x3c8>
    f9ec:      	cmp	x0, #0x5
    f9f0:      	b.eq	0xfafc <_stogir.stack.constant-size-aligned+0x3d0>
    f9f4:      	cmp	x0, #0xb
    f9f8:      	b.eq	0xfafc <_stogir.stack.constant-size-aligned+0x3d0>
    f9fc:      	cmp	x0, #0xc
    fa00:      	b.eq	0xfafc <_stogir.stack.constant-size-aligned+0x3d0>
    fa04:      	cmp	x0, #0x6
    fa08:      	cset	w3, eq
    fa0c:      	uxtb	w16, w3
    fa10:      	cmp	w16, wzr
    fa14:      	mov	x16, #0x8               ; =8
    fa18:      	movn	x17, #0x0, lsl #48
    fa1c:      	csel	x3, x16, x17, ne
    fa20:      	b	0xfb00 <_stogir.stack.constant-size-aligned+0x3d4>
    fa24:      	movz	x4, #0x0, lsl #48
    fa28:      	b	0xf998 <_stogir.stack.constant-size-aligned+0x26c>
    fa2c:      	lsr	w3, w3, #0
    fa30:      	sxtw	x3, w3
    fa34:      	cmp	x3, #0x0
    fa38:      	b.le	0xf838 <_stogir.stack.constant-size-aligned+0x10c>
    fa3c:      	ubfx	x4, x4, #0, #32
    fa40:      	ubfx	x5, x5, #0, #32
    fa44:      	lsl	x5, x5, #32
    fa48:      	orr	x4, x5, x4
    fa4c:      	cmp	x3, #0x8
    fa50:      	b.ge	0xfa6c <_stogir.stack.constant-size-aligned+0x340>
    fa54:      	lsl	x5, x3, #3
    fa58:      	lsr	w5, w5, #0
    fa5c:      	sxtw	x5, w5
    fa60:      	lsr	x5, x4, x5
    fa64:      	cmp	x5, #0x0
    fa68:      	b.ne	0xf838 <_stogir.stack.constant-size-aligned+0x10c>
    fa6c:      	cmp	x0, #0x7
    fa70:      	b.lt	0xfaac <_stogir.stack.constant-size-aligned+0x380>
    fa74:      	uxtb	w16, w1
    fa78:      	cmp	w16, wzr
    fa7c:      	b.eq	0xfaac <_stogir.stack.constant-size-aligned+0x380>
    fa80:      	lsl	x0, x3, #3
    fa84:      	lsr	w0, w0, #0
    fa88:      	sxtw	x0, w0
    fa8c:      	sub	x0, x0, #0x1
    fa90:      	lsr	w0, w0, #0
    fa94:      	sxtw	x0, w0
    fa98:      	mov	x16, #0x1               ; =1
    fa9c:      	lsl	x0, x16, x0
    faa0:      	and	x0, x0, x4
    faa4:      	cmp	x0, #0x0
    faa8:      	b.ne	0xf838 <_stogir.stack.constant-size-aligned+0x10c>
    faac:      	sub	x0, x2, #0x1
    fab0:      	mov	x16, #0x7fffffffffffffff ; =9223372036854775807
    fab4:      	sub	x0, x16, x0
    fab8:      	cmp	x4, x0
    fabc:      	b.hi	0xf838 <_stogir.stack.constant-size-aligned+0x10c>
    fac0:      	sub	x0, x2, #0x1
    fac4:      	movz	x16, #0x0, lsl #48
    fac8:      	sub	x1, x16, x2
    facc:      	add	x0, x0, x4
    fad0:      	and	x0, x1, x0
    fad4:      	mov	x1, x0
    fad8:      	movz	x0, #0x0, lsl #48
    fadc:      	movz	x2, #0x0, lsl #48
    fae0:      	b	0xf850 <_stogir.stack.constant-size-aligned+0x124>
    fae4:      	mov	x3, #0x2                ; =2
    fae8:      	b	0xf7e4 <_stogir.stack.constant-size-aligned+0xb8>
    faec:      	brk	#0
    faf0:      	b	0xfaec <_stogir.stack.constant-size-aligned+0x3c0>
    faf4:      	mov	x3, #0x4                ; =4
    faf8:      	b	0xfae8 <_stogir.stack.constant-size-aligned+0x3bc>
    fafc:      	mov	x3, #0x8                ; =8
    fb00:      	b	0xfaf8 <_stogir.stack.constant-size-aligned+0x3cc>

000000000000fb04 <_stogir.numeric-conversion.operation?>:
    fb04:      	sxtw	x0, w0
    fb08:      	cmp	x0, #0x25
    fb0c:      	b.lt	0xfb20 <_stogir.numeric-conversion.operation?+0x1c>
    fb10:      	cmp	x0, #0x27
    fb14:      	cset	w0, le
    fb18:      	ubfx	x0, x0, #0, #8
    fb1c:      	b	0xfb24 <_stogir.numeric-conversion.operation?+0x20>
    fb20:      	movz	x0, #0x0, lsl #48
    fb24:      	ret

000000000000fb28 <_stogir.numeric-conversion.valid-types?>:
    fb28:      	sxtw	x0, w0
    fb2c:      	sxtw	x1, w1
    fb30:      	sxtw	x2, w2
    fb34:      	cmp	x2, #0xc
    fb38:      	cset	w3, eq
    fb3c:      	cmp	x2, #0xd
    fb40:      	cset	w4, eq
    fb44:      	ubfx	x4, x4, #0, #8
    fb48:      	cmp	x0, #0x25
    fb4c:      	b.ne	0xfb74 <_stogir.numeric-conversion.valid-types?+0x4c>
    fb50:      	cmp	x1, #0x1
    fb54:      	b.lt	0xfbdc <_stogir.numeric-conversion.valid-types?+0xb4>
    fb58:      	cmp	x1, #0xb
    fb5c:      	b.gt	0xfbdc <_stogir.numeric-conversion.valid-types?+0xb4>
    fb60:      	uxtb	w16, w3
    fb64:      	cmp	w16, wzr
    fb68:      	b.eq	0xfbec <_stogir.numeric-conversion.valid-types?+0xc4>
    fb6c:      	mov	x0, #0x1                ; =1
    fb70:      	b	0xfbf0 <_stogir.numeric-conversion.valid-types?+0xc8>
    fb74:      	cmp	x1, #0xc
    fb78:      	cset	w5, eq
    fb7c:      	cmp	x1, #0xd
    fb80:      	cset	w1, eq
    fb84:      	cmp	x0, #0x26
    fb88:      	b.ne	0xfbac <_stogir.numeric-conversion.valid-types?+0x84>
    fb8c:      	uxtb	w16, w5
    fb90:      	cmp	w16, wzr
    fb94:      	b.ne	0xfbfc <_stogir.numeric-conversion.valid-types?+0xd4>
    fb98:      	uxtb	w16, w1
    fb9c:      	cmp	w16, wzr
    fba0:      	b.ne	0xfbfc <_stogir.numeric-conversion.valid-types?+0xd4>
    fba4:      	movz	x0, #0x0, lsl #48
    fba8:      	b	0xfbd8 <_stogir.numeric-conversion.valid-types?+0xb0>
    fbac:      	cmp	x0, #0x27
    fbb0:      	b.ne	0xfbe4 <_stogir.numeric-conversion.valid-types?+0xbc>
    fbb4:      	uxtb	w16, w5
    fbb8:      	cmp	w16, wzr
    fbbc:      	b.ne	0xfc14 <_stogir.numeric-conversion.valid-types?+0xec>
    fbc0:      	uxtb	w16, w1
    fbc4:      	cmp	w16, wzr
    fbc8:      	b.ne	0xfc14 <_stogir.numeric-conversion.valid-types?+0xec>
    fbcc:      	movz	x0, #0x0, lsl #48
    fbd0:      	b	0xfbf8 <_stogir.numeric-conversion.valid-types?+0xd0>
    fbd4:      	movz	x0, #0x0, lsl #48
    fbd8:      	b	0xfbe8 <_stogir.numeric-conversion.valid-types?+0xc0>
    fbdc:      	movz	x0, #0x0, lsl #48
    fbe0:      	b	0xfbe8 <_stogir.numeric-conversion.valid-types?+0xc0>
    fbe4:      	movz	x0, #0x0, lsl #48
    fbe8:      	ret
    fbec:      	mov	x0, x4
    fbf0:      	b	0xfbe0 <_stogir.numeric-conversion.valid-types?+0xb8>
    fbf4:      	mov	x0, x4
    fbf8:      	b	0xfbe8 <_stogir.numeric-conversion.valid-types?+0xc0>
    fbfc:      	cmp	x2, #0x1
    fc00:      	b.lt	0xfbd4 <_stogir.numeric-conversion.valid-types?+0xac>
    fc04:      	cmp	x2, #0xb
    fc08:      	cset	w0, le
    fc0c:      	ubfx	x0, x0, #0, #8
    fc10:      	b	0xfbd8 <_stogir.numeric-conversion.valid-types?+0xb0>
    fc14:      	uxtb	w16, w3
    fc18:      	cmp	w16, wzr
    fc1c:      	b.eq	0xfbf4 <_stogir.numeric-conversion.valid-types?+0xcc>
    fc20:      	mov	x0, #0x1                ; =1
    fc24:      	b	0xfbf8 <_stogir.numeric-conversion.valid-types?+0xd0>

000000000000fc28 <_inherent$slice$new__stogir.node.Node>:
    fc28:      	sub	sp, sp, #0x10
    fc2c:      	mov	x2, sp
    fc30:      	str	x0, [x2]
    fc34:      	str	x1, [x2, #0x8]
    fc38:      	ldr	x0, [sp]
    fc3c:      	ldr	x1, [sp, #0x8]
    fc40:      	add	sp, sp, #0x10
    fc44:      	ret

000000000000fc48 <_inherent$slice$data__stogir.node.Node>:
    fc48:      	ret

000000000000fc4c <_coil.slice.element-ref__stogir.node.Node>:
    fc4c:      	ret

000000000000fc50 <_stogir.vector-lanes.ordinary?>:
    fc50:      	ldr	w0, [x0]
    fc54:      	uxtb	w0, w0
    fc58:      	cmp	x0, #0x48
    fc5c:      	b.ne	0xfc68 <_stogir.vector-lanes.ordinary?+0x18>
    fc60:      	movz	x0, #0x0, lsl #48
    fc64:      	b	0xfc7c <_stogir.vector-lanes.ordinary?+0x2c>
    fc68:      	cmp	x0, #0x46
    fc6c:      	cset	w0, eq
    fc70:      	uxtb	w16, w0
    fc74:      	cmp	w16, wzr
    fc78:      	cset	x0, eq
    fc7c:      	ret

000000000000fc80 <_stogir.vector-lanes.compatible?>:
    fc80:      	sxtw	x0, w0
    fc84:      	and	x3, x0, #0xf
    fc88:      	cmp	x0, #0xf
    fc8c:      	cset	w4, gt
    fc90:      	cmp	x0, #0x80
    fc94:      	cset	w5, lt
    fc98:      	lsr	w3, w3, #0
    fc9c:      	sxtw	x3, w3
    fca0:      	cmp	x3, #0x1
    fca4:      	cset	w6, ge
    fca8:      	cmp	x3, #0xd
    fcac:      	cset	w7, le
    fcb0:      	cmp	x0, #0x0
    fcb4:      	b.lt	0xfcc8 <_stogir.vector-lanes.compatible?+0x48>
    fcb8:      	cmp	x0, #0xd
    fcbc:      	b.gt	0xfcc8 <_stogir.vector-lanes.compatible?+0x48>
    fcc0:      	mov	x0, x3
    fcc4:      	b	0xfcfc <_stogir.vector-lanes.compatible?+0x7c>
    fcc8:      	uxtb	w16, w4
    fccc:      	cmp	w16, wzr
    fcd0:      	b.eq	0xfcf8 <_stogir.vector-lanes.compatible?+0x78>
    fcd4:      	uxtb	w16, w5
    fcd8:      	cmp	w16, wzr
    fcdc:      	b.eq	0xfcf8 <_stogir.vector-lanes.compatible?+0x78>
    fce0:      	uxtb	w16, w6
    fce4:      	cmp	w16, wzr
    fce8:      	b.eq	0xfcf8 <_stogir.vector-lanes.compatible?+0x78>
    fcec:      	uxtb	w16, w7
    fcf0:      	cmp	w16, wzr
    fcf4:      	b.ne	0xfcc0 <_stogir.vector-lanes.compatible?+0x40>
    fcf8:      	movn	x0, #0x0, lsl #48
    fcfc:      	uxtb	w16, w4
    fd00:      	cmp	w16, wzr
    fd04:      	b.eq	0xfd60 <_stogir.vector-lanes.compatible?+0xe0>
    fd08:      	uxtb	w16, w5
    fd0c:      	cmp	w16, wzr
    fd10:      	b.eq	0xfd60 <_stogir.vector-lanes.compatible?+0xe0>
    fd14:      	uxtb	w16, w6
    fd18:      	cmp	w16, wzr
    fd1c:      	b.eq	0xfd60 <_stogir.vector-lanes.compatible?+0xe0>
    fd20:      	uxtb	w16, w7
    fd24:      	cmp	w16, wzr
    fd28:      	b.eq	0xfd60 <_stogir.vector-lanes.compatible?+0xe0>
    fd2c:      	sxtw	x2, w2
    fd30:      	cmp	x2, #0x4
    fd34:      	cset	w3, eq
    fd38:      	cmp	x2, #0x8
    fd3c:      	cset	w4, eq
    fd40:      	uxtb	w16, w3
    fd44:      	cmp	w16, wzr
    fd48:      	b.ne	0xfd70 <_stogir.vector-lanes.compatible?+0xf0>
    fd4c:      	uxtb	w16, w4
    fd50:      	cmp	w16, wzr
    fd54:      	b.ne	0xfd70 <_stogir.vector-lanes.compatible?+0xf0>
    fd58:      	movz	x0, #0x0, lsl #48
    fd5c:      	b	0xfd6c <_stogir.vector-lanes.compatible?+0xec>
    fd60:      	movz	x0, #0x0, lsl #48
    fd64:      	ret
    fd68:      	movz	x0, #0x0, lsl #48
    fd6c:      	b	0xfd64 <_stogir.vector-lanes.compatible?+0xe4>
    fd70:      	sxtw	x1, w1
    fd74:      	cmp	x1, #0x0
    fd78:      	b.lt	0xfd68 <_stogir.vector-lanes.compatible?+0xe8>
    fd7c:      	cmp	x1, #0xd
    fd80:      	b.gt	0xfd68 <_stogir.vector-lanes.compatible?+0xe8>
    fd84:      	cmp	x1, #0x0
    fd88:      	b.le	0xfda4 <_stogir.vector-lanes.compatible?+0x124>
    fd8c:      	lsr	w0, w0, #0
    fd90:      	sxtw	x0, w0
    fd94:      	cmp	x0, x1
    fd98:      	b.ne	0xfdac <_stogir.vector-lanes.compatible?+0x12c>
    fd9c:      	mov	x0, #0x1                ; =1
    fda0:      	b	0xfda8 <_stogir.vector-lanes.compatible?+0x128>
    fda4:      	movz	x0, #0x0, lsl #48
    fda8:      	b	0xfd6c <_stogir.vector-lanes.compatible?+0xec>
    fdac:      	cmp	x0, #0x1
    fdb0:      	b.lt	0xfdec <_stogir.vector-lanes.compatible?+0x16c>
    fdb4:      	cmp	x0, #0xb
    fdb8:      	b.gt	0xfdec <_stogir.vector-lanes.compatible?+0x16c>
    fdbc:      	cmp	x1, #0x1
    fdc0:      	b.lt	0xfdf4 <_stogir.vector-lanes.compatible?+0x174>
    fdc4:      	cmp	x1, #0xb
    fdc8:      	b.gt	0xfdf4 <_stogir.vector-lanes.compatible?+0x174>
    fdcc:      	uxtb	w16, w3
    fdd0:      	cmp	w16, wzr
    fdd4:      	b.ne	0xfe20 <_stogir.vector-lanes.compatible?+0x1a0>
    fdd8:      	uxtb	w16, w4
    fddc:      	cmp	w16, wzr
    fde0:      	b.ne	0xfe20 <_stogir.vector-lanes.compatible?+0x1a0>
    fde4:      	movn	x0, #0x0, lsl #48
    fde8:      	b	0xfe34 <_stogir.vector-lanes.compatible?+0x1b4>
    fdec:      	movz	x0, #0x0, lsl #48
    fdf0:      	b	0xfda0 <_stogir.vector-lanes.compatible?+0x120>
    fdf4:      	movz	x0, #0x0, lsl #48
    fdf8:      	b	0xfdf0 <_stogir.vector-lanes.compatible?+0x170>
    fdfc:      	mov	x1, #0x1                ; =1
    fe00:      	lsr	w0, w0, #0
    fe04:      	sxtw	x0, w0
    fe08:      	lsr	w1, w1, #0
    fe0c:      	sxtw	x1, w1
    fe10:      	cmp	x0, x1
    fe14:      	cset	w0, eq
    fe18:      	ubfx	x0, x0, #0, #8
    fe1c:      	b	0xfdf8 <_stogir.vector-lanes.compatible?+0x178>
    fe20:      	cmp	x0, #0x0
    fe24:      	b.ne	0xfed4 <_stogir.vector-lanes.compatible?+0x254>
    fe28:      	movz	x0, #0x0, lsl #48
    fe2c:      	b	0xfe34 <_stogir.vector-lanes.compatible?+0x1b4>
    fe30:      	mov	x0, #0x1                ; =1
    fe34:      	uxtb	w16, w3
    fe38:      	cmp	w16, wzr
    fe3c:      	b.ne	0xfe54 <_stogir.vector-lanes.compatible?+0x1d4>
    fe40:      	uxtb	w16, w4
    fe44:      	cmp	w16, wzr
    fe48:      	b.ne	0xfe54 <_stogir.vector-lanes.compatible?+0x1d4>
    fe4c:      	movn	x1, #0x0, lsl #48
    fe50:      	b	0xfe00 <_stogir.vector-lanes.compatible?+0x180>
    fe54:      	cmp	x1, #0x0
    fe58:      	b.ne	0xfe64 <_stogir.vector-lanes.compatible?+0x1e4>
    fe5c:      	movz	x1, #0x0, lsl #48
    fe60:      	b	0xfe00 <_stogir.vector-lanes.compatible?+0x180>
    fe64:      	cmp	x1, #0x1
    fe68:      	b.eq	0xfdfc <_stogir.vector-lanes.compatible?+0x17c>
    fe6c:      	cmp	x1, #0x2
    fe70:      	b.eq	0xfdfc <_stogir.vector-lanes.compatible?+0x17c>
    fe74:      	cmp	x1, #0x7
    fe78:      	b.eq	0xfdfc <_stogir.vector-lanes.compatible?+0x17c>
    fe7c:      	cmp	x1, #0x8
    fe80:      	b.eq	0xfdfc <_stogir.vector-lanes.compatible?+0x17c>
    fe84:      	cmp	x1, #0x3
    fe88:      	b.eq	0xff44 <_stogir.vector-lanes.compatible?+0x2c4>
    fe8c:      	cmp	x1, #0x9
    fe90:      	b.eq	0xff44 <_stogir.vector-lanes.compatible?+0x2c4>
    fe94:      	cmp	x1, #0x4
    fe98:      	b.eq	0xff54 <_stogir.vector-lanes.compatible?+0x2d4>
    fe9c:      	cmp	x1, #0xa
    fea0:      	b.eq	0xff54 <_stogir.vector-lanes.compatible?+0x2d4>
    fea4:      	cmp	x1, #0xd
    fea8:      	b.eq	0xff54 <_stogir.vector-lanes.compatible?+0x2d4>
    feac:      	cmp	x1, #0x5
    feb0:      	b.eq	0xff64 <_stogir.vector-lanes.compatible?+0x2e4>
    feb4:      	cmp	x1, #0xb
    feb8:      	b.eq	0xff64 <_stogir.vector-lanes.compatible?+0x2e4>
    febc:      	cmp	x1, #0xc
    fec0:      	b.eq	0xff64 <_stogir.vector-lanes.compatible?+0x2e4>
    fec4:      	cmp	x1, #0x6
    fec8:      	b.ne	0xff74 <_stogir.vector-lanes.compatible?+0x2f4>
    fecc:      	mov	x1, x2
    fed0:      	b	0xff78 <_stogir.vector-lanes.compatible?+0x2f8>
    fed4:      	cmp	x0, #0x1
    fed8:      	b.eq	0xfe30 <_stogir.vector-lanes.compatible?+0x1b0>
    fedc:      	cmp	x0, #0x2
    fee0:      	b.eq	0xfe30 <_stogir.vector-lanes.compatible?+0x1b0>
    fee4:      	cmp	x0, #0x7
    fee8:      	b.eq	0xfe30 <_stogir.vector-lanes.compatible?+0x1b0>
    feec:      	cmp	x0, #0x8
    fef0:      	b.eq	0xfe30 <_stogir.vector-lanes.compatible?+0x1b0>
    fef4:      	cmp	x0, #0x3
    fef8:      	b.eq	0xff4c <_stogir.vector-lanes.compatible?+0x2cc>
    fefc:      	cmp	x0, #0x9
    ff00:      	b.eq	0xff4c <_stogir.vector-lanes.compatible?+0x2cc>
    ff04:      	cmp	x0, #0x4
    ff08:      	b.eq	0xff5c <_stogir.vector-lanes.compatible?+0x2dc>
    ff0c:      	cmp	x0, #0xa
    ff10:      	b.eq	0xff5c <_stogir.vector-lanes.compatible?+0x2dc>
    ff14:      	cmp	x0, #0xd
    ff18:      	b.eq	0xff5c <_stogir.vector-lanes.compatible?+0x2dc>
    ff1c:      	cmp	x0, #0x5
    ff20:      	b.eq	0xff6c <_stogir.vector-lanes.compatible?+0x2ec>
    ff24:      	cmp	x0, #0xb
    ff28:      	b.eq	0xff6c <_stogir.vector-lanes.compatible?+0x2ec>
    ff2c:      	cmp	x0, #0xc
    ff30:      	b.eq	0xff6c <_stogir.vector-lanes.compatible?+0x2ec>
    ff34:      	cmp	x0, #0x6
    ff38:      	b.ne	0xff7c <_stogir.vector-lanes.compatible?+0x2fc>
    ff3c:      	mov	x0, x2
    ff40:      	b	0xff80 <_stogir.vector-lanes.compatible?+0x300>
    ff44:      	mov	x1, #0x2                ; =2
    ff48:      	b	0xfe00 <_stogir.vector-lanes.compatible?+0x180>
    ff4c:      	mov	x0, #0x2                ; =2
    ff50:      	b	0xfe34 <_stogir.vector-lanes.compatible?+0x1b4>
    ff54:      	mov	x1, #0x4                ; =4
    ff58:      	b	0xff48 <_stogir.vector-lanes.compatible?+0x2c8>
    ff5c:      	mov	x0, #0x4                ; =4
    ff60:      	b	0xff50 <_stogir.vector-lanes.compatible?+0x2d0>
    ff64:      	mov	x1, #0x8                ; =8
    ff68:      	b	0xff58 <_stogir.vector-lanes.compatible?+0x2d8>
    ff6c:      	mov	x0, #0x8                ; =8
    ff70:      	b	0xff60 <_stogir.vector-lanes.compatible?+0x2e0>
    ff74:      	movn	x1, #0x0, lsl #48
    ff78:      	b	0xff68 <_stogir.vector-lanes.compatible?+0x2e8>
    ff7c:      	movn	x0, #0x0, lsl #48
    ff80:      	b	0xff70 <_stogir.vector-lanes.compatible?+0x2f0>

000000000000ff84 <_stogir.symbols.numeric?>:
    ff84:      	ldr	w0, [x0]
    ff88:      	uxtb	w1, w0
    ff8c:      	ubfx	x0, x0, #8, #8
    ff90:      	cmp	x1, x0
    ff94:      	b.ne	0xffa0 <_stogir.symbols.numeric?+0x1c>
    ff98:      	mov	x0, #0x1                ; =1
    ff9c:      	b	0xffac <_stogir.symbols.numeric?+0x28>
    ffa0:      	cmp	x1, #0x49
    ffa4:      	cset	w0, eq
    ffa8:      	ubfx	x0, x0, #0, #8
    ffac:      	ret

000000000000ffb0 <_stogir.node.constant-bits>:
    ffb0:      	ldr	w1, [x0, #0x8]
    ffb4:      	ubfx	x1, x1, #0, #32
    ffb8:      	ldr	w0, [x0, #0xc]
    ffbc:      	ubfx	x0, x0, #0, #32
    ffc0:      	lsl	x0, x0, #32
    ffc4:      	orr	x0, x0, x1
    ffc8:      	ret

000000000000ffcc <_stogir.vector-comparison.valid-type?>:
    ffcc:      	sxtw	x0, w0
    ffd0:      	cmp	x0, #0xe
    ffd4:      	b.lt	0x10070 <_stogir.vector-comparison.valid-type?+0xa4>
    ffd8:      	cmp	x0, #0x19
    ffdc:      	b.gt	0x10070 <_stogir.vector-comparison.valid-type?+0xa4>
    ffe0:      	sxtw	x1, w1
    ffe4:      	cmp	x1, #0xf
    ffe8:      	cset	w2, gt
    ffec:      	uxtb	w16, w2
    fff0:      	cmp	w16, wzr
    fff4:      	b.eq	0x10078 <_stogir.vector-comparison.valid-type?+0xac>
    fff8:      	cmp	x1, #0x80
    fffc:      	cset	w3, lt
   10000:      	uxtb	w16, w3
   10004:      	cmp	w16, wzr
   10008:      	b.eq	0x10078 <_stogir.vector-comparison.valid-type?+0xac>
   1000c:      	and	x4, x1, #0xf
   10010:      	lsr	w4, w4, #0
   10014:      	sxtw	x4, w4
   10018:      	cmp	x4, #0x1
   1001c:      	cset	w5, ge
   10020:      	uxtb	w16, w5
   10024:      	cmp	w16, wzr
   10028:      	b.eq	0x10078 <_stogir.vector-comparison.valid-type?+0xac>
   1002c:      	cmp	x4, #0xd
   10030:      	cset	w6, le
   10034:      	uxtb	w16, w6
   10038:      	cmp	w16, wzr
   1003c:      	b.eq	0x10078 <_stogir.vector-comparison.valid-type?+0xac>
   10040:      	cmp	x1, #0x0
   10044:      	cset	w7, ge
   10048:      	cmp	x1, #0xd
   1004c:      	cset	w1, le
   10050:      	uxtb	w16, w7
   10054:      	cmp	w16, wzr
   10058:      	b.eq	0x10088 <_stogir.vector-comparison.valid-type?+0xbc>
   1005c:      	uxtb	w16, w1
   10060:      	cmp	w16, wzr
   10064:      	b.eq	0x10088 <_stogir.vector-comparison.valid-type?+0xbc>
   10068:      	mov	x8, x4
   1006c:      	b	0x100bc <_stogir.vector-comparison.valid-type?+0xf0>
   10070:      	movz	x0, #0x0, lsl #48
   10074:      	ret
   10078:      	movz	x0, #0x0, lsl #48
   1007c:      	b	0x10074 <_stogir.vector-comparison.valid-type?+0xa8>
   10080:      	mov	x0, #0x1                ; =1
   10084:      	b	0x1007c <_stogir.vector-comparison.valid-type?+0xb0>
   10088:      	uxtb	w16, w2
   1008c:      	cmp	w16, wzr
   10090:      	b.eq	0x100b8 <_stogir.vector-comparison.valid-type?+0xec>
   10094:      	uxtb	w16, w3
   10098:      	cmp	w16, wzr
   1009c:      	b.eq	0x100b8 <_stogir.vector-comparison.valid-type?+0xec>
   100a0:      	uxtb	w16, w5
   100a4:      	cmp	w16, wzr
   100a8:      	b.eq	0x100b8 <_stogir.vector-comparison.valid-type?+0xec>
   100ac:      	uxtb	w16, w6
   100b0:      	cmp	w16, wzr
   100b4:      	b.ne	0x10068 <_stogir.vector-comparison.valid-type?+0x9c>
   100b8:      	movn	x8, #0x0, lsl #48
   100bc:      	lsr	w8, w8, #0
   100c0:      	sxtw	x8, w8
   100c4:      	cmp	x8, #0xc
   100c8:      	b.eq	0x10080 <_stogir.vector-comparison.valid-type?+0xb4>
   100cc:      	cmp	x8, #0xd
   100d0:      	b.eq	0x10080 <_stogir.vector-comparison.valid-type?+0xb4>
   100d4:      	uxtb	w16, w7
   100d8:      	cmp	w16, wzr
   100dc:      	b.eq	0x100fc <_stogir.vector-comparison.valid-type?+0x130>
   100e0:      	uxtb	w16, w1
   100e4:      	cmp	w16, wzr
   100e8:      	b.eq	0x100fc <_stogir.vector-comparison.valid-type?+0x130>
   100ec:      	mov	x1, x4
   100f0:      	b	0x10130 <_stogir.vector-comparison.valid-type?+0x164>
   100f4:      	movz	x0, #0x0, lsl #48
   100f8:      	b	0x10084 <_stogir.vector-comparison.valid-type?+0xb8>
   100fc:      	uxtb	w16, w2
   10100:      	cmp	w16, wzr
   10104:      	b.eq	0x1012c <_stogir.vector-comparison.valid-type?+0x160>
   10108:      	uxtb	w16, w3
   1010c:      	cmp	w16, wzr
   10110:      	b.eq	0x1012c <_stogir.vector-comparison.valid-type?+0x160>
   10114:      	uxtb	w16, w5
   10118:      	cmp	w16, wzr
   1011c:      	b.eq	0x1012c <_stogir.vector-comparison.valid-type?+0x160>
   10120:      	uxtb	w16, w6
   10124:      	cmp	w16, wzr
   10128:      	b.ne	0x100ec <_stogir.vector-comparison.valid-type?+0x120>
   1012c:      	movn	x1, #0x0, lsl #48
   10130:      	lsr	w1, w1, #0
   10134:      	sxtw	x1, w1
   10138:      	cmp	x1, #0x1
   1013c:      	b.lt	0x100f4 <_stogir.vector-comparison.valid-type?+0x128>
   10140:      	cmp	x1, #0xb
   10144:      	b.gt	0x100f4 <_stogir.vector-comparison.valid-type?+0x128>
   10148:      	cmp	x0, #0x17
   1014c:      	cset	w0, le
   10150:      	ubfx	x0, x0, #0, #8
   10154:      	b	0x100f8 <_stogir.vector-comparison.valid-type?+0x12c>

0000000000010158 <_stogir.vector-arithmetic.extrema?>:
   10158:      	sxtw	x0, w0
   1015c:      	cmp	x0, #0x3a
   10160:      	b.ne	0x1016c <_stogir.vector-arithmetic.extrema?+0x14>
   10164:      	mov	x0, #0x1                ; =1
   10168:      	b	0x10178 <_stogir.vector-arithmetic.extrema?+0x20>
   1016c:      	cmp	x0, #0x3b
   10170:      	cset	w0, eq
   10174:      	ubfx	x0, x0, #0, #8
   10178:      	ret

000000000001017c <_stogir.vector-arithmetic.shift?>:
   1017c:      	sxtw	x0, w0
   10180:      	cmp	x0, #0x31
   10184:      	b.lt	0x10198 <_stogir.vector-arithmetic.shift?+0x1c>
   10188:      	cmp	x0, #0x35
   1018c:      	cset	w0, le
   10190:      	ubfx	x0, x0, #0, #8
   10194:      	b	0x1019c <_stogir.vector-arithmetic.shift?+0x20>
   10198:      	movz	x0, #0x0, lsl #48
   1019c:      	ret

00000000000101a0 <_stogir.vector-arithmetic.valid-type?>:
   101a0:      	sub	sp, sp, #0x30
   101a4:      	str	x29, [sp]
   101a8:      	str	x30, [sp, #0x8]
   101ac:      	mov	x29, sp
   101b0:      	str	x19, [sp, #0x10]
   101b4:      	str	x20, [sp, #0x18]
   101b8:      	str	x21, [sp, #0x20]
   101bc:      	str	x22, [sp, #0x28]
   101c0:      	sxtw	x1, w1
   101c4:      	cmp	x1, #0xf
   101c8:      	cset	w2, gt
   101cc:      	cmp	x1, #0x80
   101d0:      	cset	w3, lt
   101d4:      	and	x4, x1, #0xf
   101d8:      	lsr	w4, w4, #0
   101dc:      	sxtw	x4, w4
   101e0:      	cmp	x4, #0x1
   101e4:      	cset	w5, ge
   101e8:      	cmp	x4, #0xd
   101ec:      	cset	w6, le
   101f0:      	cmp	x1, #0x0
   101f4:      	b.lt	0x10208 <_stogir.vector-arithmetic.valid-type?+0x68>
   101f8:      	cmp	x1, #0xd
   101fc:      	b.gt	0x10208 <_stogir.vector-arithmetic.valid-type?+0x68>
   10200:      	mov	x1, x4
   10204:      	b	0x1023c <_stogir.vector-arithmetic.valid-type?+0x9c>
   10208:      	uxtb	w16, w2
   1020c:      	cmp	w16, wzr
   10210:      	b.eq	0x10238 <_stogir.vector-arithmetic.valid-type?+0x98>
   10214:      	uxtb	w16, w3
   10218:      	cmp	w16, wzr
   1021c:      	b.eq	0x10238 <_stogir.vector-arithmetic.valid-type?+0x98>
   10220:      	uxtb	w16, w5
   10224:      	cmp	w16, wzr
   10228:      	b.eq	0x10238 <_stogir.vector-arithmetic.valid-type?+0x98>
   1022c:      	uxtb	w16, w6
   10230:      	cmp	w16, wzr
   10234:      	b.ne	0x10200 <_stogir.vector-arithmetic.valid-type?+0x60>
   10238:      	movn	x1, #0x0, lsl #48
   1023c:      	uxtb	w16, w2
   10240:      	cmp	w16, wzr
   10244:      	b.eq	0x10430 <_stogir.vector-arithmetic.valid-type?+0x290>
   10248:      	uxtb	w16, w3
   1024c:      	cmp	w16, wzr
   10250:      	b.eq	0x10430 <_stogir.vector-arithmetic.valid-type?+0x290>
   10254:      	uxtb	w16, w5
   10258:      	cmp	w16, wzr
   1025c:      	b.eq	0x10430 <_stogir.vector-arithmetic.valid-type?+0x290>
   10260:      	uxtb	w16, w6
   10264:      	cmp	w16, wzr
   10268:      	b.eq	0x10430 <_stogir.vector-arithmetic.valid-type?+0x290>
   1026c:      	sxtw	x2, w0
   10270:      	cmp	x2, #0x1f
   10274:      	cset	w19, eq
   10278:      	cmp	x2, #0x20
   1027c:      	cset	w20, eq
   10280:      	cmp	x2, #0x2e
   10284:      	cset	w3, eq
   10288:      	cmp	x2, #0x2f
   1028c:      	cset	w4, eq
   10290:      	cmp	x2, #0x30
   10294:      	cset	w5, eq
   10298:      	cmp	x2, #0x1e
   1029c:      	cset	w6, eq
   102a0:      	cmp	x2, #0x31
   102a4:      	cset	w7, ge
   102a8:      	cmp	x2, #0x35
   102ac:      	cset	w8, le
   102b0:      	cmp	x2, #0x3a
   102b4:      	cset	w9, eq
   102b8:      	cmp	x2, #0x3b
   102bc:      	cset	w10, eq
   102c0:      	cmp	x2, #0x2d
   102c4:      	cset	w11, eq
   102c8:      	cmp	x2, #0x36
   102cc:      	cset	w12, eq
   102d0:      	cmp	x2, #0x37
   102d4:      	cset	w13, eq
   102d8:      	cmp	x2, #0x38
   102dc:      	cset	w14, eq
   102e0:      	cmp	x2, #0x39
   102e4:      	cset	w15, eq
   102e8:      	uxtb	w16, w19
   102ec:      	cmp	w16, wzr
   102f0:      	b.ne	0x1036c <_stogir.vector-arithmetic.valid-type?+0x1cc>
   102f4:      	uxtb	w16, w20
   102f8:      	cmp	w16, wzr
   102fc:      	b.ne	0x1036c <_stogir.vector-arithmetic.valid-type?+0x1cc>
   10300:      	uxtb	w16, w11
   10304:      	cmp	w16, wzr
   10308:      	b.ne	0x1036c <_stogir.vector-arithmetic.valid-type?+0x1cc>
   1030c:      	uxtb	w16, w12
   10310:      	cmp	w16, wzr
   10314:      	b.ne	0x1036c <_stogir.vector-arithmetic.valid-type?+0x1cc>
   10318:      	uxtb	w16, w13
   1031c:      	cmp	w16, wzr
   10320:      	b.ne	0x1036c <_stogir.vector-arithmetic.valid-type?+0x1cc>
   10324:      	uxtb	w16, w14
   10328:      	cmp	w16, wzr
   1032c:      	b.ne	0x1036c <_stogir.vector-arithmetic.valid-type?+0x1cc>
   10330:      	uxtb	w16, w15
   10334:      	cmp	w16, wzr
   10338:      	b.ne	0x1036c <_stogir.vector-arithmetic.valid-type?+0x1cc>
   1033c:      	uxtb	w16, w9
   10340:      	cmp	w16, wzr
   10344:      	b.ne	0x1036c <_stogir.vector-arithmetic.valid-type?+0x1cc>
   10348:      	uxtb	w16, w10
   1034c:      	cmp	w16, wzr
   10350:      	b.ne	0x1036c <_stogir.vector-arithmetic.valid-type?+0x1cc>
   10354:      	uxtb	w16, w7
   10358:      	cmp	w16, wzr
   1035c:      	b.eq	0x1054c <_stogir.vector-arithmetic.valid-type?+0x3ac>
   10360:      	uxtb	w16, w8
   10364:      	cmp	w16, wzr
   10368:      	b.eq	0x1054c <_stogir.vector-arithmetic.valid-type?+0x3ac>
   1036c:      	lsr	w1, w1, #0
   10370:      	sxtw	x2, w1
   10374:      	cmp	x2, #0xc
   10378:      	cset	w21, eq
   1037c:      	cmp	x2, #0xd
   10380:      	cset	w22, eq
   10384:      	uxtb	w16, w19
   10388:      	cmp	w16, wzr
   1038c:      	b.ne	0x10460 <_stogir.vector-arithmetic.valid-type?+0x2c0>
   10390:      	uxtb	w16, w20
   10394:      	cmp	w16, wzr
   10398:      	b.ne	0x10460 <_stogir.vector-arithmetic.valid-type?+0x2c0>
   1039c:      	uxtb	w16, w11
   103a0:      	cmp	w16, wzr
   103a4:      	b.ne	0x10460 <_stogir.vector-arithmetic.valid-type?+0x2c0>
   103a8:      	uxtb	w16, w12
   103ac:      	cmp	w16, wzr
   103b0:      	b.ne	0x10460 <_stogir.vector-arithmetic.valid-type?+0x2c0>
   103b4:      	uxtb	w16, w13
   103b8:      	cmp	w16, wzr
   103bc:      	b.ne	0x10460 <_stogir.vector-arithmetic.valid-type?+0x2c0>
   103c0:      	uxtb	w16, w14
   103c4:      	cmp	w16, wzr
   103c8:      	b.ne	0x10460 <_stogir.vector-arithmetic.valid-type?+0x2c0>
   103cc:      	uxtb	w16, w15
   103d0:      	cmp	w16, wzr
   103d4:      	b.ne	0x10460 <_stogir.vector-arithmetic.valid-type?+0x2c0>
   103d8:      	cmp	x2, #0x1
   103dc:      	cset	w0, eq
   103e0:      	cmp	x2, #0x1
   103e4:      	cset	w1, ge
   103e8:      	cmp	x2, #0xb
   103ec:      	cset	w2, le
   103f0:      	uxtb	w16, w7
   103f4:      	cmp	w16, wzr
   103f8:      	b.eq	0x104b8 <_stogir.vector-arithmetic.valid-type?+0x318>
   103fc:      	uxtb	w16, w8
   10400:      	cmp	w16, wzr
   10404:      	b.eq	0x104b8 <_stogir.vector-arithmetic.valid-type?+0x318>
   10408:      	uxtb	w16, w1
   1040c:      	cmp	w16, wzr
   10410:      	b.eq	0x10544 <_stogir.vector-arithmetic.valid-type?+0x3a4>
   10414:      	uxtb	w16, w2
   10418:      	cmp	w16, wzr
   1041c:      	b.eq	0x10544 <_stogir.vector-arithmetic.valid-type?+0x3a4>
   10420:      	uxtb	w16, w0
   10424:      	cmp	w16, wzr
   10428:      	cset	x0, eq
   1042c:      	b	0x10548 <_stogir.vector-arithmetic.valid-type?+0x3a8>
   10430:      	movz	x0, #0x0, lsl #48
   10434:      	ldr	x19, [sp, #0x10]
   10438:      	ldr	x20, [sp, #0x18]
   1043c:      	ldr	x21, [sp, #0x20]
   10440:      	ldr	x22, [sp, #0x28]
   10444:      	ldr	x29, [sp]
   10448:      	ldr	x30, [sp, #0x8]
   1044c:      	add	sp, sp, #0x30
   10450:      	ret
   10454:      	ubfx	x20, x20, #0, #8
   10458:      	mov	x0, x20
   1045c:      	b	0x10434 <_stogir.vector-arithmetic.valid-type?+0x294>
   10460:      	lsr	w0, w0, #0
   10464:      	lsr	w1, w1, #0
   10468:      	bl	0x10468 <_stogir.vector-arithmetic.valid-type?+0x2c8>
		0000000000010468:  ARM64_RELOC_BRANCH26	_stogir.integer-unary.valid-type?
   1046c:      	cmp	x0, #0x0
   10470:      	b.eq	0x1047c <_stogir.vector-arithmetic.valid-type?+0x2dc>
   10474:      	mov	x0, #0x1                ; =1
   10478:      	b	0x1045c <_stogir.vector-arithmetic.valid-type?+0x2bc>
   1047c:      	uxtb	w16, w21
   10480:      	cmp	w16, wzr
   10484:      	b.ne	0x1049c <_stogir.vector-arithmetic.valid-type?+0x2fc>
   10488:      	uxtb	w16, w22
   1048c:      	cmp	w16, wzr
   10490:      	b.ne	0x1049c <_stogir.vector-arithmetic.valid-type?+0x2fc>
   10494:      	movz	x0, #0x0, lsl #48
   10498:      	b	0x1045c <_stogir.vector-arithmetic.valid-type?+0x2bc>
   1049c:      	uxtb	w16, w19
   104a0:      	cmp	w16, wzr
   104a4:      	b.eq	0x10454 <_stogir.vector-arithmetic.valid-type?+0x2b4>
   104a8:      	mov	x0, #0x1                ; =1
   104ac:      	b	0x1045c <_stogir.vector-arithmetic.valid-type?+0x2bc>
   104b0:      	movz	x0, #0x0, lsl #48
   104b4:      	b	0x1045c <_stogir.vector-arithmetic.valid-type?+0x2bc>
   104b8:      	uxtb	w16, w3
   104bc:      	cmp	w16, wzr
   104c0:      	b.ne	0x1052c <_stogir.vector-arithmetic.valid-type?+0x38c>
   104c4:      	uxtb	w16, w4
   104c8:      	cmp	w16, wzr
   104cc:      	b.ne	0x1052c <_stogir.vector-arithmetic.valid-type?+0x38c>
   104d0:      	uxtb	w16, w5
   104d4:      	cmp	w16, wzr
   104d8:      	b.ne	0x1052c <_stogir.vector-arithmetic.valid-type?+0x38c>
   104dc:      	uxtb	w16, w21
   104e0:      	cmp	w16, wzr
   104e4:      	b.ne	0x105a4 <_stogir.vector-arithmetic.valid-type?+0x404>
   104e8:      	uxtb	w16, w22
   104ec:      	cmp	w16, wzr
   104f0:      	b.ne	0x105a4 <_stogir.vector-arithmetic.valid-type?+0x404>
   104f4:      	uxtb	w16, w1
   104f8:      	cmp	w16, wzr
   104fc:      	b.eq	0x105b4 <_stogir.vector-arithmetic.valid-type?+0x414>
   10500:      	uxtb	w16, w2
   10504:      	cmp	w16, wzr
   10508:      	b.eq	0x105b4 <_stogir.vector-arithmetic.valid-type?+0x414>
   1050c:      	uxtb	w16, w0
   10510:      	cmp	w16, wzr
   10514:      	b.eq	0x105bc <_stogir.vector-arithmetic.valid-type?+0x41c>
   10518:      	uxtb	w16, w9
   1051c:      	cmp	w16, wzr
   10520:      	b.eq	0x105c4 <_stogir.vector-arithmetic.valid-type?+0x424>
   10524:      	mov	x0, #0x1                ; =1
   10528:      	b	0x105cc <_stogir.vector-arithmetic.valid-type?+0x42c>
   1052c:      	uxtb	w16, w1
   10530:      	cmp	w16, wzr
   10534:      	b.eq	0x104b0 <_stogir.vector-arithmetic.valid-type?+0x310>
   10538:      	ubfx	x2, x2, #0, #8
   1053c:      	mov	x0, x2
   10540:      	b	0x104b4 <_stogir.vector-arithmetic.valid-type?+0x314>
   10544:      	movz	x0, #0x0, lsl #48
   10548:      	b	0x104b4 <_stogir.vector-arithmetic.valid-type?+0x314>
   1054c:      	cmp	x2, #0x1a
   10550:      	b.eq	0x1036c <_stogir.vector-arithmetic.valid-type?+0x1cc>
   10554:      	cmp	x2, #0x1b
   10558:      	b.eq	0x1036c <_stogir.vector-arithmetic.valid-type?+0x1cc>
   1055c:      	cmp	x2, #0x1c
   10560:      	b.eq	0x1036c <_stogir.vector-arithmetic.valid-type?+0x1cc>
   10564:      	cmp	x2, #0x1d
   10568:      	b.eq	0x1036c <_stogir.vector-arithmetic.valid-type?+0x1cc>
   1056c:      	uxtb	w16, w6
   10570:      	cmp	w16, wzr
   10574:      	b.ne	0x1036c <_stogir.vector-arithmetic.valid-type?+0x1cc>
   10578:      	uxtb	w16, w3
   1057c:      	cmp	w16, wzr
   10580:      	b.ne	0x1036c <_stogir.vector-arithmetic.valid-type?+0x1cc>
   10584:      	uxtb	w16, w4
   10588:      	cmp	w16, wzr
   1058c:      	b.ne	0x1036c <_stogir.vector-arithmetic.valid-type?+0x1cc>
   10590:      	uxtb	w16, w5
   10594:      	cmp	w16, wzr
   10598:      	b.ne	0x1036c <_stogir.vector-arithmetic.valid-type?+0x1cc>
   1059c:      	movz	x0, #0x0, lsl #48
   105a0:      	b	0x1045c <_stogir.vector-arithmetic.valid-type?+0x2bc>
   105a4:      	uxtb	w16, w6
   105a8:      	cmp	w16, wzr
   105ac:      	cset	x0, eq
   105b0:      	b	0x104b4 <_stogir.vector-arithmetic.valid-type?+0x314>
   105b4:      	movz	x0, #0x0, lsl #48
   105b8:      	b	0x105b0 <_stogir.vector-arithmetic.valid-type?+0x410>
   105bc:      	mov	x0, #0x1                ; =1
   105c0:      	b	0x105b8 <_stogir.vector-arithmetic.valid-type?+0x418>
   105c4:      	ubfx	x10, x10, #0, #8
   105c8:      	mov	x0, x10
   105cc:      	b	0x105c0 <_stogir.vector-arithmetic.valid-type?+0x420>

00000000000105d0 <_coil.core.Len$slice$len__i32>:
   105d0:      	mov	x0, x1
   105d4:      	ret

00000000000105d8 <_inherent$slice$data__i32>:
   105d8:      	ret

00000000000105dc <_stogir.opcode.terminator?>:
   105dc:      	sxtw	x0, w0
   105e0:      	cmp	x0, #0x0
   105e4:      	b.lt	0x1060c <_stogir.opcode.terminator?+0x30>
   105e8:      	cmp	x0, #0x83
   105ec:      	b.ge	0x1060c <_stogir.opcode.terminator?+0x30>
   105f0:      	adrp	x16, 0x10000 <_stogir.vector-comparison.valid-type?+0x34>
		00000000000105f0:  ARM64_RELOC_PAGE21	l_stogir.519
   105f4:      	ldr	x16, [x16]
		00000000000105f4:  ARM64_RELOC_PAGEOFF12	l_stogir.519
   105f8:      	orr	x1, x16, xzr
   105fc:      	lsr	x2, x0, #0
   10600:      	add	x0, x1, x0
   10604:      	ldrb	w0, [x0]
   10608:      	b	0x10610 <_stogir.opcode.terminator?+0x34>
   1060c:      	movz	x0, #0x0, lsl #48
   10610:      	uxtb	w0, w0
   10614:      	and	x0, x0, #0x8
   10618:      	uxtb	w0, w0
   1061c:      	cmp	x0, #0x0
   10620:      	cset	w0, eq
   10624:      	uxtb	w16, w0
   10628:      	cmp	w16, wzr
   1062c:      	cset	x0, eq
   10630:      	ret

0000000000010634 <_stogir.switch.sign-mask>:
   10634:      	sxtw	x0, w0
   10638:      	cmp	x0, #0x7
   1063c:      	b.lt	0x10658 <_stogir.switch.sign-mask+0x24>
   10640:      	cmp	x0, #0xb
   10644:      	b.gt	0x10658 <_stogir.switch.sign-mask+0x24>
   10648:      	cmp	x0, #0x0
   1064c:      	b.ne	0x10690 <_stogir.switch.sign-mask+0x5c>
   10650:      	movz	x0, #0x0, lsl #48
   10654:      	b	0x10664 <_stogir.switch.sign-mask+0x30>
   10658:      	movz	x0, #0x0, lsl #48
   1065c:      	ret
   10660:      	mov	x0, #0x1                ; =1
   10664:      	lsr	w0, w0, #0
   10668:      	sxtw	x0, w0
   1066c:      	lsl	x0, x0, #3
   10670:      	lsr	w0, w0, #0
   10674:      	sxtw	x0, w0
   10678:      	sub	x0, x0, #0x1
   1067c:      	lsr	w0, w0, #0
   10680:      	sxtw	x0, w0
   10684:      	mov	x16, #0x1               ; =1
   10688:      	lsl	x0, x16, x0
   1068c:      	b	0x1065c <_stogir.switch.sign-mask+0x28>
   10690:      	cmp	x0, #0x1
   10694:      	b.eq	0x10660 <_stogir.switch.sign-mask+0x2c>
   10698:      	cmp	x0, #0x2
   1069c:      	b.eq	0x10660 <_stogir.switch.sign-mask+0x2c>
   106a0:      	cmp	x0, #0x7
   106a4:      	b.eq	0x10660 <_stogir.switch.sign-mask+0x2c>
   106a8:      	cmp	x0, #0x8
   106ac:      	b.eq	0x10660 <_stogir.switch.sign-mask+0x2c>
   106b0:      	cmp	x0, #0x3
   106b4:      	b.eq	0x10710 <_stogir.switch.sign-mask+0xdc>
   106b8:      	cmp	x0, #0x9
   106bc:      	b.eq	0x10710 <_stogir.switch.sign-mask+0xdc>
   106c0:      	cmp	x0, #0x4
   106c4:      	b.eq	0x10718 <_stogir.switch.sign-mask+0xe4>
   106c8:      	cmp	x0, #0xa
   106cc:      	b.eq	0x10718 <_stogir.switch.sign-mask+0xe4>
   106d0:      	cmp	x0, #0xd
   106d4:      	b.eq	0x10718 <_stogir.switch.sign-mask+0xe4>
   106d8:      	cmp	x0, #0x5
   106dc:      	b.eq	0x10720 <_stogir.switch.sign-mask+0xec>
   106e0:      	cmp	x0, #0xb
   106e4:      	b.eq	0x10720 <_stogir.switch.sign-mask+0xec>
   106e8:      	cmp	x0, #0xc
   106ec:      	b.eq	0x10720 <_stogir.switch.sign-mask+0xec>
   106f0:      	cmp	x0, #0x6
   106f4:      	cset	w0, eq
   106f8:      	uxtb	w16, w0
   106fc:      	cmp	w16, wzr
   10700:      	mov	x16, #0x8               ; =8
   10704:      	movn	x17, #0x0, lsl #48
   10708:      	csel	x0, x16, x17, ne
   1070c:      	b	0x10724 <_stogir.switch.sign-mask+0xf0>
   10710:      	mov	x0, #0x2                ; =2
   10714:      	b	0x10664 <_stogir.switch.sign-mask+0x30>
   10718:      	mov	x0, #0x4                ; =4
   1071c:      	b	0x10714 <_stogir.switch.sign-mask+0xe0>
   10720:      	mov	x0, #0x8                ; =8
   10724:      	b	0x1071c <_stogir.switch.sign-mask+0xe8>
