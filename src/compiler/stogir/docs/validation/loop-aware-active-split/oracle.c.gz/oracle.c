
#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <inttypes.h>
#include <stdio.h>
typedef int32_t ir_live_pos;
typedef int32_t ir_ref;
typedef struct ir_live_range {ir_live_pos start,end;struct ir_live_range *next;} ir_live_range;
typedef struct {ir_live_range range;ir_live_pos end;} ir_live_interval;
typedef struct {ir_ref start,end;uint32_t loop_depth,loop_header,idom,flags;} ir_block;
typedef struct {ir_block *cfg_blocks;uint32_t *cfg_map;uint32_t cfg_blocks_count;} ir_ctx;
#define IR_ASSERT assert
#define IR_BB_LOOP_HEADER 1
#define IR_LIVE_POS_TO_REF(p) ((p)/2)
#define IR_LOAD_LIVE_POS_FROM_REF(r) ((r)*2)
#define IR_DEF_LIVE_POS_FROM_REF(r) ((r)*2+1)
static bool ir_ival_has_hole_between(ir_live_interval *ival, ir_live_pos from, ir_live_pos to)
{
	ir_live_range *r = &ival->range;

	while (r) {
		if (from < r->start) {
			return 1;
		} else if (to <= r->end) {
			return 0;
		}
		r = r->next;
	}
	return 0;
}
static ir_block *ir_block_from_live_pos(ir_ctx *ctx, ir_live_pos pos)
{
	ir_ref ref = IR_LIVE_POS_TO_REF(pos);
	uint32_t b = ctx->cfg_map[ref];

	while (!b) {
		ref--;
		IR_ASSERT(ref > 0);
		b = ctx->cfg_map[ref];
	}
	IR_ASSERT(b <= ctx->cfg_blocks_count);
	return &ctx->cfg_blocks[b];
}
static ir_live_pos ir_find_optimal_split_position(ir_ctx *ctx, ir_live_interval *ival, ir_live_pos min_pos, ir_live_pos max_pos, bool prefer_max)
{
	ir_block *min_bb, *max_bb;

	if (min_pos == max_pos) {
		return max_pos;
	}

	IR_ASSERT(min_pos < max_pos);
	IR_ASSERT(min_pos >= ival->range.start);
	IR_ASSERT(max_pos < ival->end);

	min_bb = ir_block_from_live_pos(ctx, min_pos);
	max_bb = ir_block_from_live_pos(ctx, max_pos);

	if (min_bb == max_bb
	 || ir_ival_has_hole_between(ival, min_pos, max_pos)) {  // TODO: ???
		return (prefer_max) ? max_pos : min_pos;
	}

	if (max_bb->loop_depth > 0) {
		/* Split at the end of the loop entry */
		do {
			ir_block *bb;

			if (max_bb->flags & IR_BB_LOOP_HEADER) {
				bb = max_bb;
			} else {
				IR_ASSERT(max_bb->loop_header);
				bb = &ctx->cfg_blocks[max_bb->loop_header];
			}
			bb = &ctx->cfg_blocks[bb->idom];
			if (IR_DEF_LIVE_POS_FROM_REF(bb->end) < min_pos) {
				break;
			}
			max_bb = bb;
		} while (max_bb->loop_depth > 0);

		if (IR_DEF_LIVE_POS_FROM_REF(max_bb->end) < max_pos) {
			return IR_DEF_LIVE_POS_FROM_REF(max_bb->end);
		}
	}

	if (IR_LOAD_LIVE_POS_FROM_REF(max_bb->start) > min_pos) {
		return IR_LOAD_LIVE_POS_FROM_REF(max_bb->start);
	} else {
		// TODO: "min_bb" is in a deeper loop than "max_bb" ???
		return max_pos;
	}
}
int main(void) {
 ir_block blocks[8]={{0},{0,4,0,0,1,0},{5,9,1,0,1,1},{10,14,1,2,2,0},
 {15,19,2,2,3,1},{20,24,2,4,4,0},{25,29,1,2,4,0},{30,34,0,0,2,0}};
 uint32_t mapping[35];for(unsigned i=0;i<35;i++)mapping[i]=i/5+1;
 ir_ctx ctx={blocks,mapping,7};
 for(int shape=0;shape<4;shape++) {
  ir_live_range b={0,0,0},c={0,0,0};ir_live_interval v={{0,70,0},70};
  if(shape==1){v.range.end=20;b=(ir_live_range){25,70,0};v.range.next=&b;}
  if(shape==2){v.range.end=45;b=(ir_live_range){46,70,0};v.range.next=&b;}
  if(shape==3){v.range.end=10;b=(ir_live_range){15,35,&c};c=(ir_live_range){40,70,0};v.range.next=&b;}
  uint64_t hash=UINT64_C(1469598103934665603);int count=0;
  for(int lo=0;lo<70;lo++)for(int hi=lo;hi<70;hi++)for(int pref=0;pref<2;pref++){
   int selected=ir_find_optimal_split_position(&ctx,&v,lo,hi,pref);
   hash=(hash^(uint64_t)selected)*UINT64_C(1099511628211);count++;
  }
  printf("%d %d %" PRIu64 "\n",shape,count,hash);
 }
}
