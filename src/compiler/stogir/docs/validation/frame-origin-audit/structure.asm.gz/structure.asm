
build/frame-origin-audit/emitter.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000000005ece0 <_stogir.verify.structure>:
   5ece0:      	sub	sp, sp, #0xf0
   5ece4:      	str	x29, [sp, #0x10]
   5ece8:      	str	x30, [sp, #0x18]
   5ecec:      	add	x29, sp, #0x10
   5ecf0:      	str	x19, [sp, #0x98]
   5ecf4:      	str	x20, [sp, #0xa0]
   5ecf8:      	str	x21, [sp, #0xa8]
   5ecfc:      	str	x22, [sp, #0xb0]
   5ed00:      	str	x23, [sp, #0xb8]
   5ed04:      	str	x24, [sp, #0xc0]
   5ed08:      	str	x25, [sp, #0xc8]
   5ed0c:      	str	x26, [sp, #0xd0]
   5ed10:      	str	x27, [sp, #0xd8]
   5ed14:      	str	x28, [sp, #0xe0]
   5ed18:      	add	x1, x0, #0x78
   5ed1c:      	ldr	x2, [x0, #0x8]
   5ed20:      	ldr	x1, [x1, #0x8]
   5ed24:      	cmp	x2, x1
   5ed28:      	b.ne	0x5ed58 <_stogir.verify.structure+0x78>
   5ed2c:      	adrp	x19, 0x5e000 <_stogir.graph.intern-constant!+0x100>
		000000000005ed2c:  ARM64_RELOC_PAGE21	l_stogir.8445
   5ed30:      	ldr	x19, [x19]
		000000000005ed30:  ARM64_RELOC_PAGEOFF12	l_stogir.8445
   5ed34:      	movz	x20, #0x0, lsl #48
   5ed38:      	b	0x5ed64 <_stogir.verify.structure+0x84>
   5ed3c:      	ldr	x0, [sp, #0x68]
   5ed40:      	ldr	x1, [sp, #0x70]
   5ed44:      	add	x0, x1, x0
   5ed48:      	ldr	x1, [sp, #0x60]
   5ed4c:      	add	x1, x1, #0x1
   5ed50:      	sxtw	x1, w1
   5ed54:      	b	0x5ed8c <_stogir.verify.structure+0xac>
   5ed58:      	adrp	x19, 0x5e000 <_stogir.graph.intern-constant!+0x100>
		000000000005ed58:  ARM64_RELOC_PAGE21	l_stogir.8446
   5ed5c:      	ldr	x19, [x19]
		000000000005ed5c:  ARM64_RELOC_PAGEOFF12	l_stogir.8446
   5ed60:      	mov	x20, #0x2c              ; =44
   5ed64:      	add	x21, x0, #0x110
   5ed68:      	add	x22, x21, #0x28
   5ed6c:      	mov	x23, #0x1               ; =1
   5ed70:      	movz	x24, #0x0, lsl #48
   5ed74:      	b	0x5edcc <_stogir.verify.structure+0xec>
   5ed78:      	adrp	x16, 0x5e000 <_stogir.graph.intern-constant!+0x100>
		000000000005ed78:  ARM64_RELOC_PAGE21	l_stogir.8447
   5ed7c:      	ldr	x16, [x16]
		000000000005ed7c:  ARM64_RELOC_PAGEOFF12	l_stogir.8447
   5ed80:      	str	x16, [sp, #0x48]
   5ed84:      	mov	x16, #0x16              ; =22
   5ed88:      	str	x16, [sp, #0x58]
   5ed8c:      	b	0x5edb4 <_stogir.verify.structure+0xd4>
   5ed90:      	mov	x1, x24
   5ed94:      	str	x8, [sp, #0x40]
   5ed98:      	str	x0, [sp, #0x38]
   5ed9c:      	mov	x0, x23
   5eda0:      	adrp	x16, 0x5e000 <_stogir.graph.intern-constant!+0x100>
		000000000005eda0:  ARM64_RELOC_PAGE21	l_stogir.8448
   5eda4:      	ldr	x16, [x16]
		000000000005eda4:  ARM64_RELOC_PAGEOFF12	l_stogir.8448
   5eda8:      	str	x16, [sp, #0x48]
   5edac:      	mov	x16, #0x23              ; =35
   5edb0:      	str	x16, [sp, #0x58]
   5edb4:      	ldr	x8, [sp, #0x40]
   5edb8:      	mov	x23, x0
   5edbc:      	ldr	x0, [sp, #0x38]
   5edc0:      	mov	x24, x1
   5edc4:      	ldr	x19, [sp, #0x48]
   5edc8:      	ldr	x20, [sp, #0x58]
   5edcc:      	cmp	x20, #0x0
   5edd0:      	b.ne	0x5f48c <_stogir.verify.structure+0x7ac>
   5edd4:      	ldr	x1, [x0, #0x8]
   5edd8:      	cmp	x23, x1
   5eddc:      	b.ge	0x5f4a0 <_stogir.verify.structure+0x7c0>
   5ede0:      	ldr	x1, [x0]
   5ede4:      	add	x1, x1, x23, lsl #4
   5ede8:      	ldr	x1, [x1]
   5edec:      	ldr	x2, [x0, #0x78]
   5edf0:      	ldr	w2, [x2, x23, lsl #2]
   5edf4:      	sxtw	x25, w2
   5edf8:      	cmp	x25, #0x0
   5edfc:      	b.lt	0x5ed90 <_stogir.verify.structure+0xb0>
   5ee00:      	mov	x17, #0xffff            ; =65535
   5ee04:      	cmp	x25, x17
   5ee08:      	b.gt	0x5f4b4 <_stogir.verify.structure+0x7d4>
   5ee0c:      	uxtb	w2, w1
   5ee10:      	orr	x26, x2, xzr
   5ee14:      	cmp	x26, #0x83
   5ee18:      	cset	w27, lt
   5ee1c:      	uxtb	w16, w27
   5ee20:      	cmp	w16, wzr
   5ee24:      	b.eq	0x5f4c8 <_stogir.verify.structure+0x7e8>
   5ee28:      	ubfx	x1, x1, #0, #32
   5ee2c:      	ubfx	x2, x1, #8, #8
   5ee30:      	orr	x3, x2, xzr
   5ee34:      	cmp	x3, #0xd
   5ee38:      	b.le	0x5ee64 <_stogir.verify.structure+0x184>
   5ee3c:      	cmp	x3, #0xf
   5ee40:      	b.le	0x5f4dc <_stogir.verify.structure+0x7fc>
   5ee44:      	cmp	x3, #0x80
   5ee48:      	b.ge	0x5f4f0 <_stogir.verify.structure+0x810>
   5ee4c:      	and	w2, w2, #0xf
   5ee50:      	ubfx	x2, x2, #0, #32
   5ee54:      	cmp	x2, #0x1
   5ee58:      	b.lt	0x5f504 <_stogir.verify.structure+0x824>
   5ee5c:      	cmp	x2, #0xd
   5ee60:      	b.gt	0x5f518 <_stogir.verify.structure+0x838>
   5ee64:      	uxtb	w16, w27
   5ee68:      	cmp	w16, wzr
   5ee6c:      	b.eq	0x5f2e8 <_stogir.verify.structure+0x608>
   5ee70:      	adrp	x17, 0x5e000 <_stogir.graph.intern-constant!+0x100>
		000000000005ee70:  ARM64_RELOC_PAGE21	l_stogir.8449
   5ee74:      	ldr	x17, [x17]
		000000000005ee74:  ARM64_RELOC_PAGEOFF12	l_stogir.8449
   5ee78:      	ldrsb	w2, [x26, x17]
   5ee7c:      	sxtb	w2, w2
   5ee80:      	b	0x5f2ec <_stogir.verify.structure+0x60c>
   5ee84:      	ldr	x0, [sp, #0x58]
   5ee88:      	cmp	x0, #0x0
   5ee8c:      	b.ne	0x5f52c <_stogir.verify.structure+0x84c>
   5ee90:      	and	x1, x1, #0xffffffff
   5ee94:      	movz	x2, #0x0, lsl #48
   5ee98:      	movz	x0, #0x0, lsl #48
   5ee9c:      	b	0x5eea4 <_stogir.verify.structure+0x1c4>
   5eea0:      	mov	x2, #0x1                ; =1
   5eea4:      	ldr	x3, [sp, #0x40]
   5eea8:      	str	x2, [x3]
   5eeac:      	str	x1, [x3, #0x8]
   5eeb0:      	str	x0, [x3, #0x10]
   5eeb4:      	ldr	x19, [sp, #0x98]
   5eeb8:      	ldr	x20, [sp, #0xa0]
   5eebc:      	ldr	x21, [sp, #0xa8]
   5eec0:      	ldr	x22, [sp, #0xb0]
   5eec4:      	ldr	x23, [sp, #0xb8]
   5eec8:      	ldr	x24, [sp, #0xc0]
   5eecc:      	ldr	x25, [sp, #0xc8]
   5eed0:      	ldr	x26, [sp, #0xd0]
   5eed4:      	ldr	x27, [sp, #0xd8]
   5eed8:      	ldr	x28, [sp, #0xe0]
   5eedc:      	ldr	x29, [sp, #0x10]
   5eee0:      	ldr	x30, [sp, #0x18]
   5eee4:      	add	sp, sp, #0xf0
   5eee8:      	ret
   5eeec:      	mov	w12, w7
   5eef0:      	lsl	w12, w12, #2
   5eef4:      	ubfx	x12, x12, #0, #32
   5eef8:      	lsr	x11, x11, x12
   5eefc:      	and	w11, w11, #0xf
   5ef00:      	b	0x5ef2c <_stogir.verify.structure+0x24c>
   5ef04:      	mov	w1, w25
   5ef08:      	mov	x25, x0
   5ef0c:      	ldr	x0, [sp, #0x38]
   5ef10:      	bl	0x5ef10 <_stogir.verify.structure+0x230>
		000000000005ef10:  ARM64_RELOC_BRANCH26	_stogir.graph.contains?
   5ef14:      	cmp	x0, #0x0
   5ef18:      	b.eq	0x5f378 <_stogir.verify.structure+0x698>
   5ef1c:      	ldr	w0, [sp, #0x90]
   5ef20:      	ldr	w1, [sp, #0x88]
   5ef24:      	b	0x5efcc <_stogir.verify.structure+0x2ec>
   5ef28:      	movz	w11, #0x0, lsl #16
   5ef2c:      	b	0x5ef34 <_stogir.verify.structure+0x254>
   5ef30:      	movz	w11, #0x0, lsl #16
   5ef34:      	str	x8, [sp, #0x40]
   5ef38:      	str	x0, [sp, #0x38]
   5ef3c:      	str	w1, [sp, #0x50]
   5ef40:      	str	x4, [sp, #0x78]
   5ef44:      	str	x6, [sp, #0x80]
   5ef48:      	str	x25, [sp, #0x30]
   5ef4c:      	mov	w25, w2
   5ef50:      	mov	w2, w5
   5ef54:      	str	x19, [sp, #0x48]
   5ef58:      	mov	w19, w3
   5ef5c:      	str	x20, [sp, #0x58]
   5ef60:      	mov	w20, w10
   5ef64:      	str	x24, [sp, #0x60]
   5ef68:      	mov	w24, w11
   5ef6c:      	str	x23, [sp, #0x68]
   5ef70:      	mov	w23, w7
   5ef74:      	str	x28, [sp, #0x70]
   5ef78:      	mov	w28, w9
   5ef7c:      	bl	0x5ef7c <_stogir.verify.structure+0x29c>
		000000000005ef7c:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
   5ef80:      	ubfx	x0, x0, #0, #32
   5ef84:      	lsr	x16, x0, #0
   5ef88:      	cmp	x16, #0x1
   5ef8c:      	b.eq	0x5efa8 <_stogir.verify.structure+0x2c8>
   5ef90:      	b.lo	0x5ef98 <_stogir.verify.structure+0x2b8>
   5ef94:      	b	0x5efac <_stogir.verify.structure+0x2cc>
   5ef98:      	cmp	x16, #0x0
   5ef9c:      	b.eq	0x5efa4 <_stogir.verify.structure+0x2c4>
   5efa0:      	b	0x5efac <_stogir.verify.structure+0x2cc>
   5efa4:      	b	0x5efb0 <_stogir.verify.structure+0x2d0>
   5efa8:      	b	0x5f080 <_stogir.verify.structure+0x3a0>
   5efac:      	b	0x5f40c <_stogir.verify.structure+0x72c>
   5efb0:      	mov	w0, w25
   5efb4:      	mov	w1, w19
   5efb8:      	adrp	x16, 0x5e000 <_stogir.graph.intern-constant!+0x100>
		000000000005efb8:  ARM64_RELOC_PAGE21	l_stogir.8450
   5efbc:      	ldr	x16, [x16]
		000000000005efbc:  ARM64_RELOC_PAGEOFF12	l_stogir.8450
   5efc0:      	str	x16, [sp, #0x48]
   5efc4:      	mov	x16, #0x17              ; =23
   5efc8:      	str	x16, [sp, #0x58]
   5efcc:      	ldr	x2, [sp, #0x78]
   5efd0:      	add	x2, x2, #0x1
   5efd4:      	sxtw	x2, w2
   5efd8:      	ldr	x23, [sp, #0x68]
   5efdc:      	ldr	x24, [sp, #0x60]
   5efe0:      	ldr	x8, [sp, #0x40]
   5efe4:      	ldr	x25, [sp, #0x30]
   5efe8:      	ldr	x28, [sp, #0x70]
   5efec:      	mov	w3, w1
   5eff0:      	ldr	w1, [sp, #0x50]
   5eff4:      	mov	x4, x2
   5eff8:      	mov	w2, w0
   5effc:      	ldr	x0, [sp, #0x38]
   5f000:      	ldr	x19, [sp, #0x48]
   5f004:      	ldr	x20, [sp, #0x58]
   5f008:      	cmp	x20, #0x0
   5f00c:      	b.ne	0x5f020 <_stogir.verify.structure+0x340>
   5f010:      	cmp	x4, x25
   5f014:      	cset	w5, le
   5f018:      	ubfx	x5, x5, #0, #8
   5f01c:      	b	0x5f024 <_stogir.verify.structure+0x344>
   5f020:      	movz	x5, #0x0, lsl #48
   5f024:      	cmp	x5, #0x0
   5f028:      	b.eq	0x5f534 <_stogir.verify.structure+0x854>
   5f02c:      	orr	w5, w4, wzr
   5f030:      	sxtw	x6, w5
   5f034:      	sub	w7, w5, #0x1
   5f038:      	cmp	x6, #0x0
   5f03c:      	cset	w9, gt
   5f040:      	cmp	x6, #0x4
   5f044:      	cset	w10, gt
   5f048:      	uxtb	w16, w27
   5f04c:      	cmp	w16, wzr
   5f050:      	b.eq	0x5ef30 <_stogir.verify.structure+0x250>
   5f054:      	adrp	x16, 0x5f000 <_stogir.verify.structure+0x320>
		000000000005f054:  ARM64_RELOC_PAGE21	l_stogir.8451
   5f058:      	ldr	x16, [x16]
		000000000005f058:  ARM64_RELOC_PAGEOFF12	l_stogir.8451
   5f05c:      	ldr	w11, [x16, x26, lsl #2]
   5f060:      	uxtb	w16, w9
   5f064:      	cmp	w16, wzr
   5f068:      	b.eq	0x5ef28 <_stogir.verify.structure+0x248>
   5f06c:      	uxtb	w16, w10
   5f070:      	cmp	w16, wzr
   5f074:      	b.eq	0x5eeec <_stogir.verify.structure+0x20c>
   5f078:      	mov	w12, #0x4               ; =4
   5f07c:      	b	0x5eef0 <_stogir.verify.structure+0x210>
   5f080:      	ubfx	x24, x24, #0, #32
   5f084:      	adrp	x16, 0x5f000 <_stogir.verify.structure+0x320>
		000000000005f084:  ARM64_RELOC_PAGE21	l_stogir.8452
   5f088:      	ldr	x16, [x16]
		000000000005f088:  ARM64_RELOC_PAGEOFF12	l_stogir.8452
   5f08c:      	ldr	w0, [x16]
   5f090:      	cmp	x24, x0
   5f094:      	b.ne	0x5f0a0 <_stogir.verify.structure+0x3c0>
   5f098:      	mov	x0, #0x1                ; =1
   5f09c:      	b	0x5f0b8 <_stogir.verify.structure+0x3d8>
   5f0a0:      	adrp	x16, 0x5f000 <_stogir.verify.structure+0x320>
		000000000005f0a0:  ARM64_RELOC_PAGE21	l_stogir.8453
   5f0a4:      	ldr	x16, [x16]
		000000000005f0a4:  ARM64_RELOC_PAGEOFF12	l_stogir.8453
   5f0a8:      	ldr	w0, [x16]
   5f0ac:      	cmp	x24, x0
   5f0b0:      	cset	w0, eq
   5f0b4:      	ubfx	x0, x0, #0, #8
   5f0b8:      	cmp	x0, #0x0
   5f0bc:      	b.eq	0x5f554 <_stogir.verify.structure+0x874>
   5f0c0:      	str	w19, [sp, #0x88]
   5f0c4:      	mov	x19, x0
   5f0c8:      	ldr	x0, [sp, #0x38]
   5f0cc:      	str	w25, [sp, #0x90]
   5f0d0:      	mov	w25, w1
   5f0d4:      	bl	0x5f0d4 <_stogir.verify.structure+0x3f4>
		000000000005f0d4:  ARM64_RELOC_BRANCH26	_stogir.graph.borrow-node
   5f0d8:      	cmp	x0, #0x0
   5f0dc:      	cset	w1, eq
   5f0e0:      	uxtb	w16, w1
   5f0e4:      	cmp	w16, wzr
   5f0e8:      	cset	x1, eq
   5f0ec:      	cmp	x1, #0x0
   5f0f0:      	b.eq	0x5f118 <_stogir.verify.structure+0x438>
   5f0f4:      	ldr	w0, [x0]
   5f0f8:      	uxtb	w0, w0
   5f0fc:      	cmp	x0, #0x48
   5f100:      	b.ne	0x5f118 <_stogir.verify.structure+0x438>
   5f104:      	adrp	x16, 0x5f000 <_stogir.verify.structure+0x320>
		000000000005f104:  ARM64_RELOC_PAGE21	l_stogir.8454
   5f108:      	ldr	x16, [x16]
		000000000005f108:  ARM64_RELOC_PAGEOFF12	l_stogir.8454
   5f10c:      	str	x16, [sp, #0x48]
   5f110:      	mov	x16, #0x25              ; =37
   5f114:      	str	x16, [sp, #0x58]
   5f118:      	b	0x5f120 <_stogir.verify.structure+0x440>
   5f11c:      	movz	x1, #0x0, lsl #48
   5f120:      	sxtw	x0, w25
   5f124:      	adrp	x16, 0x5f000 <_stogir.verify.structure+0x320>
		000000000005f124:  ARM64_RELOC_PAGE21	l_stogir.8455
   5f128:      	ldr	x16, [x16]
		000000000005f128:  ARM64_RELOC_PAGEOFF12	l_stogir.8455
   5f12c:      	ldr	w2, [x16]
   5f130:      	cmp	x24, x2
   5f134:      	b.ne	0x5f1e0 <_stogir.verify.structure+0x500>
   5f138:      	cmp	x0, #0x0
   5f13c:      	b.le	0x5f198 <_stogir.verify.structure+0x4b8>
   5f140:      	ldr	x2, [x22, #0x8]
   5f144:      	cmp	x0, x2
   5f148:      	b.gt	0x5f198 <_stogir.verify.structure+0x4b8>
   5f14c:      	sub	x2, x0, #0x1
   5f150:      	ldr	x3, [x21, #0x28]
   5f154:      	mov	x17, #0x18              ; =24
   5f158:      	mul	x2, x2, x17
   5f15c:      	add	x4, x2, x3
   5f160:      	ldr	x2, [x2, x3]
   5f164:      	ldr	x3, [x4, #0x8]
   5f168:      	ldr	x4, [x21, #0x8]
   5f16c:      	cmp	x2, #0x0
   5f170:      	b.lt	0x5f338 <_stogir.verify.structure+0x658>
   5f174:      	cmp	x2, x4
   5f178:      	b.gt	0x5f338 <_stogir.verify.structure+0x658>
   5f17c:      	cmp	x3, #0x0
   5f180:      	b.lt	0x5f338 <_stogir.verify.structure+0x658>
   5f184:      	sub	x2, x4, x2
   5f188:      	cmp	x3, x2
   5f18c:      	b.gt	0x5f338 <_stogir.verify.structure+0x658>
   5f190:      	mov	w2, #0x1                ; =1
   5f194:      	b	0x5f33c <_stogir.verify.structure+0x65c>
   5f198:      	movz	w2, #0x0, lsl #16
   5f19c:      	ubfx	x2, x2, #0, #32
   5f1a0:      	lsr	x16, x2, #0
   5f1a4:      	cmp	x16, #0x1
   5f1a8:      	b.eq	0x5f1c4 <_stogir.verify.structure+0x4e4>
   5f1ac:      	b.lo	0x5f1b4 <_stogir.verify.structure+0x4d4>
   5f1b0:      	b	0x5f1c8 <_stogir.verify.structure+0x4e8>
   5f1b4:      	cmp	x16, #0x0
   5f1b8:      	b.eq	0x5f1c0 <_stogir.verify.structure+0x4e0>
   5f1bc:      	b	0x5f1c8 <_stogir.verify.structure+0x4e8>
   5f1c0:      	b	0x5f1cc <_stogir.verify.structure+0x4ec>
   5f1c4:      	b	0x5f1e0 <_stogir.verify.structure+0x500>
   5f1c8:      	b	0x5f484 <_stogir.verify.structure+0x7a4>
   5f1cc:      	adrp	x16, 0x5f000 <_stogir.verify.structure+0x320>
		000000000005f1cc:  ARM64_RELOC_PAGE21	l_stogir.8456
   5f1d0:      	ldr	x16, [x16]
		000000000005f1d0:  ARM64_RELOC_PAGEOFF12	l_stogir.8456
   5f1d4:      	str	x16, [sp, #0x48]
   5f1d8:      	mov	x16, #0x21              ; =33
   5f1dc:      	str	x16, [sp, #0x58]
   5f1e0:      	cmp	x24, #0xf
   5f1e4:      	b.hs	0x5f568 <_stogir.verify.structure+0x888>
   5f1e8:      	mov	x16, #0x1               ; =1
   5f1ec:      	lsl	x2, x16, x24
   5f1f0:      	mov	w17, #0x5e1c            ; =24092
   5f1f4:      	and	w2, w2, w17
   5f1f8:      	ubfx	x2, x2, #0, #32
   5f1fc:      	cmp	x2, #0x0
   5f200:      	b.eq	0x5f574 <_stogir.verify.structure+0x894>
   5f204:      	cmp	x19, #0x0
   5f208:      	b.eq	0x5ef04 <_stogir.verify.structure+0x224>
   5f20c:      	mov	x25, x0
   5f210:      	mov	x0, x1
   5f214:      	b	0x5ef14 <_stogir.verify.structure+0x234>
   5f218:      	orr	w1, w23, wzr
   5f21c:      	cmp	x26, #0x78
   5f220:      	cset	w2, eq
   5f224:      	cmp	x3, #0x0
   5f228:      	cset	w3, eq
   5f22c:      	mov	x4, #0x1                ; =1
   5f230:      	b	0x5f008 <_stogir.verify.structure+0x328>
   5f234:      	nop
   5f238:      	movz	x2, #0x0, lsl #48
   5f23c:      	cmp	x2, #0x0
   5f240:      	b.eq	0x5f218 <_stogir.verify.structure+0x538>
   5f244:      	add	x2, x1, x23
   5f248:      	ldr	x4, [x0, #0x78]
   5f24c:      	ldr	w2, [x4, x2, lsl #2]
   5f250:      	sxtw	x2, w2
   5f254:      	cmn	x2, #0x1
   5f258:      	b.eq	0x5f268 <_stogir.verify.structure+0x588>
   5f25c:      	adrp	x19, 0x5f000 <_stogir.verify.structure+0x320>
		000000000005f25c:  ARM64_RELOC_PAGE21	l_stogir.8457
   5f260:      	ldr	x19, [x19]
		000000000005f260:  ARM64_RELOC_PAGEOFF12	l_stogir.8457
   5f264:      	mov	x20, #0x1b              ; =27
   5f268:      	add	x1, x1, #0x1
   5f26c:      	cmp	x20, #0x0
   5f270:      	b.ne	0x5f238 <_stogir.verify.structure+0x558>
   5f274:      	cmp	x1, x28
   5f278:      	cset	w2, lt
   5f27c:      	ubfx	x2, x2, #0, #8
   5f280:      	b	0x5f23c <_stogir.verify.structure+0x55c>
   5f284:      	mov	w2, #-0x2               ; =-2
   5f288:      	sxtw	x2, w2
   5f28c:      	cmn	x2, #0x1
   5f290:      	b.ne	0x5f2ac <_stogir.verify.structure+0x5cc>
   5f294:      	ubfx	x1, x1, #16, #16
   5f298:      	cmp	x25, x1
   5f29c:      	b.eq	0x5f2ac <_stogir.verify.structure+0x5cc>
   5f2a0:      	adrp	x19, 0x5f000 <_stogir.verify.structure+0x320>
		000000000005f2a0:  ARM64_RELOC_PAGE21	l_stogir.8458
   5f2a4:      	ldr	x19, [x19]
		000000000005f2a4:  ARM64_RELOC_PAGEOFF12	l_stogir.8458
   5f2a8:      	mov	x20, #0x24              ; =36
   5f2ac:      	add	x1, x25, #0x4
   5f2b0:      	ldr	x2, [x0, #0x8]
   5f2b4:      	asr	x16, x1, #63
   5f2b8:      	lsr	x16, x16, #62
   5f2bc:      	add	x1, x1, x16
   5f2c0:      	asr	x1, x1, #2
   5f2c4:      	orr	x28, x1, xzr
   5f2c8:      	add	x1, x28, x23
   5f2cc:      	cmp	x1, x2
   5f2d0:      	b.le	0x5f2e0 <_stogir.verify.structure+0x600>
   5f2d4:      	adrp	x19, 0x5f000 <_stogir.verify.structure+0x320>
		000000000005f2d4:  ARM64_RELOC_PAGE21	l_stogir.8459
   5f2d8:      	ldr	x19, [x19]
		000000000005f2d8:  ARM64_RELOC_PAGEOFF12	l_stogir.8459
   5f2dc:      	mov	x20, #0x15              ; =21
   5f2e0:      	mov	x1, #0x1                ; =1
   5f2e4:      	b	0x5f26c <_stogir.verify.structure+0x58c>
   5f2e8:      	mov	w2, #-0x2               ; =-2
   5f2ec:      	sxtw	x2, w2
   5f2f0:      	cmp	x2, #0x0
   5f2f4:      	b.lt	0x5f318 <_stogir.verify.structure+0x638>
   5f2f8:      	uxtb	w16, w27
   5f2fc:      	cmp	w16, wzr
   5f300:      	b.eq	0x5f340 <_stogir.verify.structure+0x660>
   5f304:      	adrp	x17, 0x5f000 <_stogir.verify.structure+0x320>
		000000000005f304:  ARM64_RELOC_PAGE21	l_stogir.8449
   5f308:      	ldr	x17, [x17]
		000000000005f308:  ARM64_RELOC_PAGEOFF12	l_stogir.8449
   5f30c:      	ldrsb	w2, [x26, x17]
   5f310:      	sxtb	w2, w2
   5f314:      	b	0x5f344 <_stogir.verify.structure+0x664>
   5f318:      	uxtb	w16, w27
   5f31c:      	cmp	w16, wzr
   5f320:      	b.eq	0x5f284 <_stogir.verify.structure+0x5a4>
   5f324:      	adrp	x17, 0x5f000 <_stogir.verify.structure+0x320>
		000000000005f324:  ARM64_RELOC_PAGE21	l_stogir.8460
   5f328:      	ldr	x17, [x17]
		000000000005f328:  ARM64_RELOC_PAGEOFF12	l_stogir.8460
   5f32c:      	ldrsb	w2, [x26, x17]
   5f330:      	sxtb	w2, w2
   5f334:      	b	0x5f288 <_stogir.verify.structure+0x5a8>
   5f338:      	movz	w2, #0x0, lsl #16
   5f33c:      	b	0x5f19c <_stogir.verify.structure+0x4bc>
   5f340:      	mov	w2, #-0x2               ; =-2
   5f344:      	sxtw	x2, w2
   5f348:      	cmp	x25, x2
   5f34c:      	b.eq	0x5f318 <_stogir.verify.structure+0x638>
   5f350:      	str	x8, [sp, #0x40]
   5f354:      	str	x0, [sp, #0x38]
   5f358:      	mov	x0, x23
   5f35c:      	mov	x1, x24
   5f360:      	adrp	x16, 0x5f000 <_stogir.verify.structure+0x320>
		000000000005f360:  ARM64_RELOC_PAGE21	l_stogir.8461
   5f364:      	ldr	x16, [x16]
		000000000005f364:  ARM64_RELOC_PAGEOFF12	l_stogir.8461
   5f368:      	str	x16, [sp, #0x48]
   5f36c:      	mov	x16, #0x23              ; =35
   5f370:      	str	x16, [sp, #0x58]
   5f374:      	b	0x5ed54 <_stogir.verify.structure+0x74>
   5f378:      	cmp	x25, #0x0
   5f37c:      	b.ne	0x5f580 <_stogir.verify.structure+0x8a0>
   5f380:      	uxtb	w16, w27
   5f384:      	cmp	w16, wzr
   5f388:      	b.eq	0x5f414 <_stogir.verify.structure+0x734>
   5f38c:      	adrp	x16, 0x5f000 <_stogir.verify.structure+0x320>
		000000000005f38c:  ARM64_RELOC_PAGE21	l_stogir.8451
   5f390:      	ldr	x16, [x16]
		000000000005f390:  ARM64_RELOC_PAGEOFF12	l_stogir.8451
   5f394:      	ldr	w0, [x16, x26, lsl #2]
   5f398:      	uxtb	w16, w28
   5f39c:      	cmp	w16, wzr
   5f3a0:      	b.eq	0x5f45c <_stogir.verify.structure+0x77c>
   5f3a4:      	uxtb	w16, w20
   5f3a8:      	cmp	w16, wzr
   5f3ac:      	b.eq	0x5f3b4 <_stogir.verify.structure+0x6d4>
   5f3b0:      	mov	w23, #0x4               ; =4
   5f3b4:      	lsl	w1, w23, #2
   5f3b8:      	ubfx	x1, x1, #0, #32
   5f3bc:      	lsr	x0, x0, x1
   5f3c0:      	and	w0, w0, #0xf
   5f3c4:      	b	0x5f460 <_stogir.verify.structure+0x780>
   5f3c8:      	ldr	w0, [sp, #0x90]
   5f3cc:      	uxtb	w16, w0
   5f3d0:      	cmp	w16, wzr
   5f3d4:      	b.eq	0x5f58c <_stogir.verify.structure+0x8ac>
   5f3d8:      	ldr	w1, [sp, #0x88]
   5f3dc:      	uxtb	w16, w1
   5f3e0:      	cmp	w16, wzr
   5f3e4:      	b.eq	0x5f3f4 <_stogir.verify.structure+0x714>
   5f3e8:      	ldr	x5, [sp, #0x80]
   5f3ec:      	cmp	x5, #0x2
   5f3f0:      	b.eq	0x5ef24 <_stogir.verify.structure+0x244>
   5f3f4:      	adrp	x16, 0x5f000 <_stogir.verify.structure+0x320>
		000000000005f3f4:  ARM64_RELOC_PAGE21	l_stogir.8462
   5f3f8:      	ldr	x16, [x16]
		000000000005f3f8:  ARM64_RELOC_PAGEOFF12	l_stogir.8462
   5f3fc:      	str	x16, [sp, #0x48]
   5f400:      	mov	x16, #0x1a              ; =26
   5f404:      	str	x16, [sp, #0x58]
   5f408:      	b	0x5ef24 <_stogir.verify.structure+0x244>
   5f40c:      	brk	#0
   5f410:      	b	0x5f40c <_stogir.verify.structure+0x72c>
   5f414:      	movz	w0, #0x0, lsl #16
   5f418:      	adrp	x16, 0x5f000 <_stogir.verify.structure+0x320>
		000000000005f418:  ARM64_RELOC_PAGE21	l_stogir.8463
   5f41c:      	ldr	x16, [x16]
		000000000005f41c:  ARM64_RELOC_PAGEOFF12	l_stogir.8463
   5f420:      	ldr	w1, [x16]
   5f424:      	ubfx	x0, x0, #0, #32
   5f428:      	cmp	x0, x1
   5f42c:      	b.ne	0x5f43c <_stogir.verify.structure+0x75c>
   5f430:      	ldr	w0, [sp, #0x90]
   5f434:      	ldr	w1, [sp, #0x88]
   5f438:      	b	0x5ef24 <_stogir.verify.structure+0x244>
   5f43c:      	adrp	x16, 0x5f000 <_stogir.verify.structure+0x320>
		000000000005f43c:  ARM64_RELOC_PAGE21	l_stogir.8464
   5f440:      	ldr	x16, [x16]
		000000000005f440:  ARM64_RELOC_PAGEOFF12	l_stogir.8464
   5f444:      	ldr	w1, [x16]
   5f448:      	cmp	x0, x1
   5f44c:      	b.ne	0x5f464 <_stogir.verify.structure+0x784>
   5f450:      	ldr	w0, [sp, #0x90]
   5f454:      	ldr	w1, [sp, #0x88]
   5f458:      	b	0x5ef24 <_stogir.verify.structure+0x244>
   5f45c:      	movz	w0, #0x0, lsl #16
   5f460:      	b	0x5f418 <_stogir.verify.structure+0x738>
   5f464:      	adrp	x16, 0x5f000 <_stogir.verify.structure+0x320>
		000000000005f464:  ARM64_RELOC_PAGE21	l_stogir.8465
   5f468:      	ldr	x16, [x16]
		000000000005f468:  ARM64_RELOC_PAGEOFF12	l_stogir.8465
   5f46c:      	ldr	w1, [x16]
   5f470:      	cmp	x0, x1
   5f474:      	b.ne	0x5f3c8 <_stogir.verify.structure+0x6e8>
   5f478:      	ldr	w0, [sp, #0x90]
   5f47c:      	ldr	w1, [sp, #0x88]
   5f480:      	b	0x5ef24 <_stogir.verify.structure+0x244>
   5f484:      	brk	#0
   5f488:      	b	0x5f484 <_stogir.verify.structure+0x7a4>
   5f48c:      	mov	x1, x24
   5f490:      	str	x8, [sp, #0x40]
   5f494:      	str	x19, [sp, #0x48]
   5f498:      	str	x20, [sp, #0x58]
   5f49c:      	b	0x5ee84 <_stogir.verify.structure+0x1a4>
   5f4a0:      	mov	x1, x24
   5f4a4:      	str	x8, [sp, #0x40]
   5f4a8:      	str	x19, [sp, #0x48]
   5f4ac:      	str	x20, [sp, #0x58]
   5f4b0:      	b	0x5ee84 <_stogir.verify.structure+0x1a4>
   5f4b4:      	mov	x1, x24
   5f4b8:      	str	x8, [sp, #0x40]
   5f4bc:      	str	x0, [sp, #0x38]
   5f4c0:      	mov	x0, x23
   5f4c4:      	b	0x5eda0 <_stogir.verify.structure+0xc0>
   5f4c8:      	mov	x1, x24
   5f4cc:      	str	x8, [sp, #0x40]
   5f4d0:      	str	x0, [sp, #0x38]
   5f4d4:      	mov	x0, x23
   5f4d8:      	b	0x5ed78 <_stogir.verify.structure+0x98>
   5f4dc:      	mov	x1, x24
   5f4e0:      	str	x8, [sp, #0x40]
   5f4e4:      	str	x0, [sp, #0x38]
   5f4e8:      	mov	x0, x23
   5f4ec:      	b	0x5ed78 <_stogir.verify.structure+0x98>
   5f4f0:      	mov	x1, x24
   5f4f4:      	str	x8, [sp, #0x40]
   5f4f8:      	str	x0, [sp, #0x38]
   5f4fc:      	mov	x0, x23
   5f500:      	b	0x5ed78 <_stogir.verify.structure+0x98>
   5f504:      	mov	x1, x24
   5f508:      	str	x8, [sp, #0x40]
   5f50c:      	str	x0, [sp, #0x38]
   5f510:      	mov	x0, x23
   5f514:      	b	0x5ed78 <_stogir.verify.structure+0x98>
   5f518:      	mov	x1, x24
   5f51c:      	str	x8, [sp, #0x40]
   5f520:      	str	x0, [sp, #0x38]
   5f524:      	mov	x0, x23
   5f528:      	b	0x5ed78 <_stogir.verify.structure+0x98>
   5f52c:      	ldr	x1, [sp, #0x48]
   5f530:      	b	0x5eea0 <_stogir.verify.structure+0x1c0>
   5f534:      	str	x23, [sp, #0x68]
   5f538:      	str	x24, [sp, #0x60]
   5f53c:      	str	x8, [sp, #0x40]
   5f540:      	str	x0, [sp, #0x38]
   5f544:      	str	x28, [sp, #0x70]
   5f548:      	str	x19, [sp, #0x48]
   5f54c:      	str	x20, [sp, #0x58]
   5f550:      	b	0x5ed3c <_stogir.verify.structure+0x5c>
   5f554:      	str	w25, [sp, #0x90]
   5f558:      	mov	w25, w1
   5f55c:      	str	w19, [sp, #0x88]
   5f560:      	mov	x19, x0
   5f564:      	b	0x5f11c <_stogir.verify.structure+0x43c>
   5f568:      	ldr	w0, [sp, #0x90]
   5f56c:      	ldr	w1, [sp, #0x88]
   5f570:      	b	0x5ef24 <_stogir.verify.structure+0x244>
   5f574:      	ldr	w0, [sp, #0x90]
   5f578:      	ldr	w1, [sp, #0x88]
   5f57c:      	b	0x5ef24 <_stogir.verify.structure+0x244>
   5f580:      	ldr	w0, [sp, #0x90]
   5f584:      	ldr	w1, [sp, #0x88]
   5f588:      	b	0x5f3f4 <_stogir.verify.structure+0x714>
   5f58c:      	ldr	w1, [sp, #0x88]
   5f590:      	b	0x5f3f4 <_stogir.verify.structure+0x714>
   5f594:      	udf	#0x0
