
build/symbol-word-compare/candidate.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <_symbol_words>:
       0:      	sub	sp, sp, #0x20
       4:      	str	x19, [sp]
       8:      	str	x20, [sp, #0x8]
       c:      	str	x21, [sp, #0x10]
      10:      	add	x3, x1, #0x0
      14:      	add	x4, x1, #0x1
      18:      	add	x5, x1, #0x2
      1c:      	add	x6, x1, #0x3
      20:      	add	x7, x1, #0x4
      24:      	add	x8, x1, #0x5
      28:      	add	x9, x1, #0x6
      2c:      	add	x10, x1, #0x7
      30:      	add	x11, x1, #0x8
      34:      	add	x12, x1, #0x9
      38:      	add	x13, x1, #0xa
      3c:      	add	x14, x1, #0xb
      40:      	add	x15, x1, #0xc
      44:      	add	x19, x1, #0xd
      48:      	add	x20, x1, #0xe
      4c:      	add	x1, x1, #0xf
      50:      	movz	x21, #0x0, lsl #48
      54:      	b	0x180 <_symbol_words+0x180>
      58:      	adrp	x17, 0x0 <_symbol_words>
		0000000000000058:  ARM64_RELOC_PAGE21	L_stogir_0000000000000000
      5c:      	add	x17, x17, #0x0
		000000000000005c:  ARM64_RELOC_PAGEOFF12	L_stogir_0000000000000000
      60:      	str	x17, [x2]
      64:      	cmp	x21, x5
      68:      	b.ne	0x78 <_symbol_words+0x78>
      6c:      	adrp	x17, 0x0 <_symbol_words>
		000000000000006c:  ARM64_RELOC_PAGE21	L_stogir_0000000000000001
      70:      	add	x17, x17, #0x0
		0000000000000070:  ARM64_RELOC_PAGEOFF12	L_stogir_0000000000000001
      74:      	str	x17, [x2]
      78:      	cmp	x21, x6
      7c:      	b.ne	0x8c <_symbol_words+0x8c>
      80:      	adrp	x17, 0x0 <_symbol_words>
		0000000000000080:  ARM64_RELOC_PAGE21	L_stogir_0000000000000002
      84:      	add	x17, x17, #0x0
		0000000000000084:  ARM64_RELOC_PAGEOFF12	L_stogir_0000000000000002
      88:      	str	x17, [x2]
      8c:      	cmp	x21, x7
      90:      	b.ne	0xa0 <_symbol_words+0xa0>
      94:      	adrp	x17, 0x0 <_symbol_words>
		0000000000000094:  ARM64_RELOC_PAGE21	L_stogir_0000000000000003
      98:      	add	x17, x17, #0x0
		0000000000000098:  ARM64_RELOC_PAGEOFF12	L_stogir_0000000000000003
      9c:      	str	x17, [x2]
      a0:      	cmp	x21, x8
      a4:      	b.ne	0xb4 <_symbol_words+0xb4>
      a8:      	adrp	x17, 0x0 <_symbol_words>
		00000000000000a8:  ARM64_RELOC_PAGE21	L_stogir_0000000000000004
      ac:      	add	x17, x17, #0x0
		00000000000000ac:  ARM64_RELOC_PAGEOFF12	L_stogir_0000000000000004
      b0:      	str	x17, [x2]
      b4:      	cmp	x21, x9
      b8:      	b.ne	0xc8 <_symbol_words+0xc8>
      bc:      	adrp	x17, 0x0 <_symbol_words>
		00000000000000bc:  ARM64_RELOC_PAGE21	L_stogir_0000000000000005
      c0:      	add	x17, x17, #0x0
		00000000000000c0:  ARM64_RELOC_PAGEOFF12	L_stogir_0000000000000005
      c4:      	str	x17, [x2]
      c8:      	cmp	x21, x10
      cc:      	b.ne	0xdc <_symbol_words+0xdc>
      d0:      	adrp	x17, 0x0 <_symbol_words>
		00000000000000d0:  ARM64_RELOC_PAGE21	L_stogir_0000000000000006
      d4:      	add	x17, x17, #0x0
		00000000000000d4:  ARM64_RELOC_PAGEOFF12	L_stogir_0000000000000006
      d8:      	str	x17, [x2]
      dc:      	cmp	x21, x11
      e0:      	b.ne	0xf0 <_symbol_words+0xf0>
      e4:      	adrp	x17, 0x0 <_symbol_words>
		00000000000000e4:  ARM64_RELOC_PAGE21	L_stogir_0000000000000007
      e8:      	add	x17, x17, #0x0
		00000000000000e8:  ARM64_RELOC_PAGEOFF12	L_stogir_0000000000000007
      ec:      	str	x17, [x2]
      f0:      	cmp	x21, x12
      f4:      	b.ne	0x104 <_symbol_words+0x104>
      f8:      	adrp	x17, 0x0 <_symbol_words>
		00000000000000f8:  ARM64_RELOC_PAGE21	L_stogir_0000000000000008
      fc:      	add	x17, x17, #0x0
		00000000000000fc:  ARM64_RELOC_PAGEOFF12	L_stogir_0000000000000008
     100:      	str	x17, [x2]
     104:      	cmp	x21, x13
     108:      	b.ne	0x118 <_symbol_words+0x118>
     10c:      	adrp	x17, 0x0 <_symbol_words>
		000000000000010c:  ARM64_RELOC_PAGE21	L_stogir_0000000000000009
     110:      	add	x17, x17, #0x0
		0000000000000110:  ARM64_RELOC_PAGEOFF12	L_stogir_0000000000000009
     114:      	str	x17, [x2]
     118:      	cmp	x21, x14
     11c:      	b.ne	0x12c <_symbol_words+0x12c>
     120:      	adrp	x17, 0x0 <_symbol_words>
		0000000000000120:  ARM64_RELOC_PAGE21	L_stogir_000000000000000a
     124:      	add	x17, x17, #0x0
		0000000000000124:  ARM64_RELOC_PAGEOFF12	L_stogir_000000000000000a
     128:      	str	x17, [x2]
     12c:      	cmp	x21, x15
     130:      	b.ne	0x140 <_symbol_words+0x140>
     134:      	adrp	x17, 0x0 <_symbol_words>
		0000000000000134:  ARM64_RELOC_PAGE21	L_stogir_000000000000000b
     138:      	add	x17, x17, #0x0
		0000000000000138:  ARM64_RELOC_PAGEOFF12	L_stogir_000000000000000b
     13c:      	str	x17, [x2]
     140:      	cmp	x21, x19
     144:      	b.ne	0x154 <_symbol_words+0x154>
     148:      	adrp	x17, 0x0 <_symbol_words>
		0000000000000148:  ARM64_RELOC_PAGE21	L_stogir_000000000000000c
     14c:      	add	x17, x17, #0x0
		000000000000014c:  ARM64_RELOC_PAGEOFF12	L_stogir_000000000000000c
     150:      	str	x17, [x2]
     154:      	cmp	x21, x20
     158:      	b.ne	0x168 <_symbol_words+0x168>
     15c:      	adrp	x17, 0x0 <_symbol_words>
		000000000000015c:  ARM64_RELOC_PAGE21	L_stogir_000000000000000d
     160:      	add	x17, x17, #0x0
		0000000000000160:  ARM64_RELOC_PAGEOFF12	L_stogir_000000000000000d
     164:      	str	x17, [x2]
     168:      	cmp	x21, x1
     16c:      	b.ne	0x17c <_symbol_words+0x17c>
     170:      	adrp	x17, 0x0 <_symbol_words>
		0000000000000170:  ARM64_RELOC_PAGE21	L_stogir_000000000000000e
     174:      	add	x17, x17, #0x0
		0000000000000174:  ARM64_RELOC_PAGEOFF12	L_stogir_000000000000000e
     178:      	str	x17, [x2]
     17c:      	add	x21, x21, #0x1
     180:      	cmp	x21, x0
     184:      	b.hs	0x1a8 <_symbol_words+0x1a8>
     188:      	cmp	x21, x3
     18c:      	b.ne	0x19c <_symbol_words+0x19c>
     190:      	adrp	x17, 0x0 <_symbol_words>
		0000000000000190:  ARM64_RELOC_PAGE21	L_stogir_000000000000000f
     194:      	add	x17, x17, #0x0
		0000000000000194:  ARM64_RELOC_PAGEOFF12	L_stogir_000000000000000f
     198:      	str	x17, [x2]
     19c:      	cmp	x21, x4
     1a0:      	b.eq	0x58 <_symbol_words+0x58>
     1a4:      	b	0x64 <_symbol_words+0x64>
     1a8:      	mov	x0, x21
     1ac:      	ldr	x19, [sp]
     1b0:      	ldr	x20, [sp, #0x8]
     1b4:      	ldr	x21, [sp, #0x10]
     1b8:      	add	sp, sp, #0x20
     1bc:      	ret
